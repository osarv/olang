; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"compiler/check:factRead" = type { i64, i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1, { i64, ptr } }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/check:payloadItem" = type { i32, ptr }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:unsetCand" = type { i64, i64, i64, i1, i64, %"compiler/source:Span", i32, i1 }
%"compiler/definit:Verdict" = type { i1, %"compiler/source:Span", i32, %"compiler/source:Span" }
%"compiler/check:ValueAsk" = type { i32, i64, %"compiler/source:Span", i32, i64, { i64, [3 x i64] }, i1, { i64, [3 x i64] } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 10
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_37018c2ebf0da22a_371c8892c4c63a5e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = icmp slt i64 %t40, %t44
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t55 = icmp slt i64 %t49, %t52
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 32
  br i1 %t66, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 %t69
  %t74 = load i8, ptr %t73, !tbaa !32
  %t76 = icmp eq i8 %t74, 10
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp eq i8 %t85, 9
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 41
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l49, !tbaa !21
  store i1 %t100, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l34, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb25
bb25:
  br label %bb6
bb26:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = add i64 %t111, %a3
  %t117 = trunc i64 %t115 to i32
  %t120 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t110, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l63
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindsType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t22, ptr %l12
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  call void @__olang_scope_close(ptr %s1)
  store i1 %t24, ptr %rv
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_357157b7b16ebf19_d0077534c0a9b60d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyRefusal(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb10
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t29, i64 %t30)
  store i64 %t33, ptr %l19
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l15, !tbaa !29
  %t35 = load i64, ptr %l19, !tbaa !24
  %t36 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t34, i64 %t35)
  store ptr %t36, ptr %l20
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t39 = getelementptr %"compiler/ast:Func", ptr %t37, i32 0, i32 7
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t44, ptr %l23, !tbaa !27
  br label %bb9
bb9:
  %t46 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t46, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb10:
  %t47 = load { i64, [2 x i64] }, ptr %l2
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  %t52 = load { i64, [2 x i64] }, ptr %l2
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 2
  br i1 %t55, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7a179da39a9781e9_720543b731edd2ed)
  unreachable
bb21:
  %t61 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l36, !tbaa !24
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = mul i64 %t63, 1
  %t65 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = mul i64 %t72, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t74, ptr %l10, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecNumber(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %rv = alloca i1
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t14 = icmp sle i32 %t12, 14
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseZero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l33 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca %"compiler/typed:Make"
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %a3)
  store i32 %t16, ptr %l21
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l22
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 36
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l25
  br label %bb3
bb3:
  %t26 = load i64, ptr %l25, !tbaa !24
  store i64 %t26, ptr %l5, !tbaa !24
  store i1 true, ptr %l6, !tbaa !21
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  store i64 %t31, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb5, label %bb6
bb5:
  br label %bb25
bb6:
  br label %bb7
bb7:
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %l33, !tbaa !27
  %t42 = load i64, ptr %l8, !tbaa !24
  %t44 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i32, ptr %t45, i64 %t42
  %t47 = load i32, ptr %t46, !tbaa !33
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v0, ptr %t49, %"compiler/source:Span" %t50, i32 %t47)
  store ptr %t55, ptr %l39
  br label %bb8
bb8:
  %t56 = load ptr, ptr %l39, !tbaa !29
  store ptr %t56, ptr %l11, !tbaa !29
  %t57 = load ptr, ptr %l11, !tbaa !29
  store ptr %t57, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t58 = load ptr, ptr %l40, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 0
  store i1 %t64, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l41, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  %t66 = load ptr, ptr %l11, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t68, i32 0, i32 2
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l12, !tbaa !24
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp ne i64 %t72, 0
  br i1 %t74, label %bb14, label %bb15
bb14:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ea1bc73a77e68519_ca6969815981751d)
  unreachable
bb22:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 36
  %t79 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t78, ptr %t79)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l8, !tbaa !24
  br label %bb4
bb25:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 36
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t88, i64 %t89)
  store { i64, ptr } %t92, ptr %l56
  br label %bb26
bb26:
  %t93 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t93, ptr %l13, !tbaa !27
  %t94 = load i1, ptr %l6, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  store ptr null, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t97 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t97, ptr %l59
  store i32 %a2, ptr %l60, !tbaa !23
  %t99 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t103 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v1, ptr %v1, ptr %v1, i32 1, i64 0, { i64, ptr } %t99, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t103, ptr %l64
  br label %bb30
bb30:
  %t104 = load %"compiler/typed:Make", ptr %l64
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/typed:Make" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 7, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l59
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l60, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  store ptr %t117, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/generic:Context"
  %l20 = alloca %"compiler/generic:Context"
  %l25 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca { i64, i32 }
  %l46 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t21 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t20, i64 160, i1 false)
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t21, ptr %s0, ptr %l18)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t21, i64 160, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l20, i64 160, i1 false)
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t31 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %s0, ptr %t26, ptr %l4, ptr %t27)
  store i32 %t31, ptr %l25
  br label %bb8
bb8:
  %t32 = load i32, ptr %l25, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t37 = icmp ne i32 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v2, ptr %t42, i32 %t43, ptr %t44)
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l33, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp2
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v2, ptr %v2, ptr %t49, ptr %t50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l36
  br label %bb12
bb12:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t55
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v2, ptr %v2, ptr %t56, ptr %t55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l38
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t60 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t65 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t61, ptr %t62)
  store { i64, i32 } %t65, ptr %l41
  br label %bb15
bb15:
  %t66 = load { i64, i32 }, ptr %l41
  store { i64, i32 } %t66, ptr %l6
  %t67 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  %t70 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp sge i64 %t77, 64
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t84 = load ptr, ptr %lp2
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l53, !tbaa !24
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = shl i64 1, %t89
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t85, i32 %t86, i64 %t90)
  store i32 %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = load i32, ptr %l55, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t95, i32 %t96)
  br label %bb23
bb23:
  %t97 = load ptr, ptr %lp2
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Item"
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l67 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i64
  %l84 = alloca i1
  %l88 = alloca i1
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca i64
  %l101 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l141 = alloca i32
  %l147 = alloca i64
  %l149 = alloca i32
  %l153 = alloca i32
  %l159 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/diagmsg:Msg"
  %l178 = alloca i64
  %l184 = alloca ptr
  %l187 = alloca %"compiler/source:Span"
  %l188 = alloca %"compiler/diagmsg:Msg"
  %l189 = alloca i64
  %l195 = alloca i1
  %l201 = alloca i1
  %l203 = alloca i1
  %l205 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca %"compiler/diagmsg:Msg"
  %l210 = alloca i64
  %l214 = alloca i1
  %l221 = alloca i1
  %l224 = alloca i1
  %l225 = alloca ptr
  %l228 = alloca %"compiler/source:Span"
  %l229 = alloca %"compiler/diagmsg:Msg"
  %l230 = alloca i64
  %l233 = alloca i1
  %l238 = alloca i32
  %l243 = alloca ptr
  %l248 = alloca i32
  %l249 = alloca { i64, ptr }
  %l256 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l264 = alloca %"compiler/diagmsg:Msg"
  %l265 = alloca i64
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb9
bb6:
  %t22 = load i64, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l41, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l41, !tbaa !24
  store i64 %t38, ptr %l38, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l38, !tbaa !24
  store i64 %t39, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb138
bb12:
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l59, !tbaa !27
  %t59 = load i64, ptr %l10, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr ptr, ptr %t62, i64 %t59
  %t64 = load ptr, ptr %t63, !tbaa !39
  store ptr %t64, ptr %l11, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i64, ptr %l10, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l64
  br label %bb14
bb14:
  %t71 = load ptr, ptr %l64, !tbaa !29
  store ptr %t71, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l10, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = sub i64 %t78, 1
  %t83 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %s3, ptr %t76, i64 %t80)
  store ptr %t83, ptr %l72
  br label %bb17
bb16:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb18
bb17:
  %t84 = load ptr, ptr %l72, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Clause", ptr %t84, i32 0, i32 2
  %t87 = load i1, ptr %t86, !tbaa !21
  store i1 %t87, ptr %l67, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l67, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l75, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l11, !tbaa !29
  %t95 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store %"compiler/source:Span" %t95, ptr %l78
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t96 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
  store %"compiler/diagmsg:Msg" %t96, ptr %l79
  br label %bb22
bb22:
  %t97 = load ptr, ptr %l75, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l78
  %t99 = load %"compiler/diagmsg:Msg", ptr %l79
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t97, %"compiler/source:Span" %t98, %"compiler/diagmsg:Msg" %t99)
  store i64 %t100, ptr %l80
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb24:
  %t102 = load i64, ptr %l10, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load ptr, ptr %l12, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Clause", ptr %t106, i32 0, i32 2
  %t109 = load i1, ptr %t108, !tbaa !21
  %t111 = xor i1 %t109, true
  store i1 %t111, ptr %l84, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb27
bb27:
  %t113 = load i1, ptr %l84, !tbaa !21
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Clause", ptr %t114, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l88, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l88, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %l93
  br label %bb33
bb32:
  br label %bb71
bb33:
  %t125 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l10, !tbaa !24
  store i64 %t126, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l14, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t134 = load i64, ptr %l16, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb39
bb36:
  %t138 = load i64, ptr %l15, !tbaa !24
  %t139 = load i64, ptr %l14, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l16, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb38
bb38:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb40
bb40:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb41, label %bb42
bb41:
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load i64, ptr %l18, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store ptr %l13, ptr %l119, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t178 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v2, ptr %v2, ptr %t174, i64 %t172)
  store ptr %t178, ptr %l122
  br label %bb44
bb44:
  %t179 = load ptr, ptr %l119, !tbaa !29
  %t180 = load ptr, ptr %l122, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s5, ptr %v2, ptr %t179, ptr %t180)
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t181 = load i64, ptr %l18, !tbaa !24
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l18, !tbaa !24
  br label %bb40
bb47:
  store i1 true, ptr %l20, !tbaa !21
  %t185 = load ptr, ptr %l12, !tbaa !29
  %t187 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 1
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  store i64 %t192, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t194 = load i64, ptr %l22, !tbaa !24
  %t195 = load i64, ptr %l23, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb49, label %bb50
bb49:
  br label %bb64
bb50:
  br label %bb51
bb51:
  %t202 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t202, ptr %l133, !tbaa !27
  %t203 = load i64, ptr %l22, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr %"compiler/typed:Item", ptr %t206, i64 %t203
  %t208 = load %"compiler/typed:Item", ptr %t207
  store %"compiler/typed:Item" %t208, ptr %l24
  %t210 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t211 = load i64, ptr %t210, !tbaa !24
  %t213 = icmp slt i64 %t211, 0
  br i1 %t213, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb54
bb53:
  %t215 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t216 = load i64, ptr %t215, !tbaa !24
  %t218 = icmp sge i64 %t216, 64
  store i1 %t218, ptr %l138, !tbaa !21
  br label %bb54
bb54:
  %t220 = load i1, ptr %l138, !tbaa !21
  br i1 %t220, label %bb55, label %bb56
bb55:
  %t221 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  store i32 %t222, ptr %l141, !tbaa !23
  br label %bb58
bb56:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t232 = getelementptr %"compiler/typed:Item", ptr %l24, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  store i64 %t233, ptr %l147, !tbaa !24
  %t234 = load i64, ptr %l147, !tbaa !24
  %t235 = load i64, ptr %l147, !tbaa !24
  %t236 = shl i64 1, %t235
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t229, i32 %t231, i64 %t236)
  store i32 %t240, ptr %l149
  br label %bb57
bb57:
  %t241 = load i32, ptr %l149, !tbaa !23
  store i32 %t241, ptr %l141, !tbaa !23
  br label %bb58
bb58:
  %t242 = load i32, ptr %l141, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %s5, ptr %t243, i32 %t242, ptr %l13)
  store i32 %t248, ptr %l153
  br label %bb59
bb59:
  %t249 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t250 = load i32, ptr %l153, !tbaa !23
  %t252 = icmp ne i32 %t250, %t249
  br i1 %t252, label %bb60, label %bb61
bb60:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t256 = add i64 %t254, 1
  store i64 %t256, ptr %l22, !tbaa !24
  br label %bb48
bb64:
  %t258 = load i1, ptr %l20, !tbaa !21
  br i1 %t258, label %bb65, label %bb66
bb65:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l159, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t265 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t261, ptr %t262)
  store %"compiler/source:Span" %t265, ptr %l162
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t266 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t266, ptr %l163
  br label %bb68
bb68:
  %t267 = load ptr, ptr %l159, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l162
  %t269 = load %"compiler/diagmsg:Msg", ptr %l163
  %t270 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t267, %"compiler/source:Span" %t268, %"compiler/diagmsg:Msg" %t269)
  store i64 %t270, ptr %l164
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb70:
  call void @__olang_scope_close(ptr %s5)
  br label %bb71
bb71:
  %t272 = load ptr, ptr %l11, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Catch", ptr %t272, i32 0, i32 3
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t279 = icmp sgt i64 %t277, 0
  store i1 %t279, ptr %l26, !tbaa !21
  %t283 = xor i1 %a3, true
  br i1 %t283, label %bb72, label %bb73
bb72:
  %t285 = load i1, ptr %l26, !tbaa !21
  br i1 %t285, label %bb74, label %bb75
bb73:
  br label %bb80
bb74:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l173, !tbaa !29
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l11, !tbaa !29
  %t292 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t288, ptr %t289)
  store %"compiler/source:Span" %t292, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t293 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
  store %"compiler/diagmsg:Msg" %t293, ptr %l177
  br label %bb77
bb77:
  %t294 = load ptr, ptr %l173, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l176
  %t296 = load %"compiler/diagmsg:Msg", ptr %l177
  %t297 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t294, %"compiler/source:Span" %t295, %"compiler/diagmsg:Msg" %t296)
  store i64 %t297, ptr %l178
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb80:
  %t299 = load i32, ptr %l4, !tbaa !23
  %t300 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t303 = icmp eq i32 %t299, %t300
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load i1, ptr %l26, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb82:
  br label %bb89
bb83:
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l184, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l11, !tbaa !29
  %t312 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t308, ptr %t309)
  store %"compiler/source:Span" %t312, ptr %l187
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t313 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
  store %"compiler/diagmsg:Msg" %t313, ptr %l188
  br label %bb86
bb86:
  %t314 = load ptr, ptr %l184, !tbaa !29
  %t315 = load %"compiler/source:Span", ptr %l187
  %t316 = load %"compiler/diagmsg:Msg", ptr %l188
  %t317 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t314, %"compiler/source:Span" %t315, %"compiler/diagmsg:Msg" %t316)
  store i64 %t317, ptr %l189
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb88:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb89:
  %t319 = load ptr, ptr %l12, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Clause", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb90, label %bb91
bb90:
  %t328 = load ptr, ptr %l12, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Clause", ptr %t328, i32 0, i32 3
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e)
  unreachable
bb93:
  br label %bb94
bb94:
  %t335 = load ptr, ptr %l12, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Clause", ptr %t335, i32 0, i32 3
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l201
  br label %bb95
bb95:
  %t341 = load i1, ptr %l201, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb96
bb96:
  %t342 = load i1, ptr %l195, !tbaa !21
  store i1 %t342, ptr %l27, !tbaa !21
  %t343 = load i1, ptr %l27, !tbaa !21
  br i1 %t343, label %bb97, label %bb98
bb97:
  %t345 = load i1, ptr %l26, !tbaa !21
  store i1 %t345, ptr %l203, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb99
bb99:
  %t347 = load i1, ptr %l203, !tbaa !21
  br i1 %t347, label %bb100, label %bb101
bb100:
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l205, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l11, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t349, ptr %t350)
  store %"compiler/source:Span" %t353, ptr %l208
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t354 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
  store %"compiler/diagmsg:Msg" %t354, ptr %l209
  br label %bb103
bb103:
  %t355 = load ptr, ptr %l205, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l208
  %t357 = load %"compiler/diagmsg:Msg", ptr %l209
  %t358 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t355, %"compiler/source:Span" %t356, %"compiler/diagmsg:Msg" %t357)
  store i64 %t358, ptr %l210
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb105:
  %t360 = load i1, ptr %l27, !tbaa !21
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb106, label %bb107
bb106:
  %t364 = load i1, ptr %l26, !tbaa !21
  %t366 = xor i1 %t364, true
  store i1 %t366, ptr %l214, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb108
bb108:
  %t368 = load i1, ptr %l214, !tbaa !21
  br i1 %t368, label %bb109, label %bb110
bb109:
  %t369 = load ptr, ptr %l11, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Catch", ptr %t369, i32 0, i32 2
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t376 = icmp sgt i64 %t374, 0
  br i1 %t376, label %bb111, label %bb112
bb110:
  br label %bb121
bb111:
  %t378 = load ptr, ptr %l11, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Catch", ptr %t378, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  %t383 = call i1 @compiler_2fcheck_2elastIsValue(ptr %v1, { i64, ptr } %t381)
  store i1 %t383, ptr %l224
  br label %bb113
bb112:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb114
bb113:
  %t384 = load i1, ptr %l224, !tbaa !21
  store i1 %t384, ptr %l221, !tbaa !21
  br label %bb114
bb114:
  %t385 = load i1, ptr %l221, !tbaa !21
  br i1 %t385, label %bb115, label %bb116
bb115:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb116:
  br label %bb117
bb117:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l225, !tbaa !29
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l11, !tbaa !29
  %t391 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t387, ptr %t388)
  store %"compiler/source:Span" %t391, ptr %l228
  br label %bb118
bb118:
  %t392 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
  store %"compiler/diagmsg:Msg" %t392, ptr %l229
  br label %bb119
bb119:
  %t393 = load ptr, ptr %l225, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l228
  %t395 = load %"compiler/diagmsg:Msg", ptr %l229
  %t396 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t393, %"compiler/source:Span" %t394, %"compiler/diagmsg:Msg" %t395)
  store i64 %t396, ptr %l230
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb121:
  %t398 = load i1, ptr %l26, !tbaa !21
  br i1 %t398, label %bb122, label %bb123
bb122:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/generic:Program", ptr %t403, i32 0, i32 2
  %t406 = load i32, ptr %l4, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t405, i32 %t406)
  store i32 %t409, ptr %l238
  br label %bb124
bb123:
  store i1 false, ptr %l233, !tbaa !21
  br label %bb125
bb124:
  %t410 = load i32, ptr %l238, !range !{i32 0, i32 33}
  %t412 = trunc i64 22 to i32
  %t413 = icmp eq i32 %t410, %t412
  store i1 %t413, ptr %l233, !tbaa !21
  br label %bb125
bb125:
  %t415 = load i1, ptr %l233, !tbaa !21
  br i1 %t415, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/check:Checker", ptr %t416, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !29
  %t421 = getelementptr %"compiler/generic:Program", ptr %t419, i32 0, i32 2
  store ptr %t421, ptr %l243, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr %"compiler/check:Checker", ptr %t422, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !29
  %t427 = getelementptr %"compiler/generic:Program", ptr %t425, i32 0, i32 2
  %t428 = load i32, ptr %l4, !tbaa !23
  %t431 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l248
  br label %bb128
bb127:
  br label %bb136
bb128:
  %t432 = load ptr, ptr %l243, !tbaa !29
  %t433 = load i32, ptr %l248, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s21, ptr %t432, i32 %t433)
  store { i64, ptr } %t434, ptr %l249
  br label %bb129
bb129:
  %t435 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  store i64 %t436, ptr %l28, !tbaa !24
  %t438 = load ptr, ptr %l11, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Catch", ptr %t438, i32 0, i32 3
  %t441 = load { i64, ptr }, ptr %t440, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = load i64, ptr %l28, !tbaa !24
  %t447 = icmp ne i64 %t443, %t444
  br i1 %t447, label %bb130, label %bb131
bb130:
  %t449 = load ptr, ptr %l0, !tbaa !29
  store ptr %t449, ptr %l256, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l11, !tbaa !29
  %t454 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store %"compiler/source:Span" %t454, ptr %l259
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t455 = load i64, ptr %l28, !tbaa !24
  %t456 = load ptr, ptr %l11, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Catch", ptr %t456, i32 0, i32 3
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t464 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %t455, i64 %t461)
  store %"compiler/diagmsg:Msg" %t464, ptr %l264
  br label %bb133
bb133:
  %t465 = load ptr, ptr %l256, !tbaa !29
  %t466 = load %"compiler/source:Span", ptr %l259
  %t467 = load %"compiler/diagmsg:Msg", ptr %l264
  %t468 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t465, %"compiler/source:Span" %t466, %"compiler/diagmsg:Msg" %t467)
  store i64 %t468, ptr %l265
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb135:
  call void @__olang_scope_close(ptr %s21)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s3)
  br label %bb137
bb137:
  %t470 = load i64, ptr %l9, !tbaa !24
  %t472 = add i64 %t470, 1
  store i64 %t472, ptr %l9, !tbaa !24
  br label %bb10
bb138:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyAll(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l32 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 36
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t32, ptr %t27, i64 %a2)
  store ptr %t38, ptr %l26
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load ptr, ptr %l26, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t39, ptr %t40)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l5, !tbaa !24
  br label %bb2
bb9:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 36
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t47, i64 %t48)
  store { i64, ptr } %t51, ptr %l32
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca i32
  %l62 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i1
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca i32
  %l82 = alloca ptr
  %l86 = alloca ptr
  %l87 = alloca i1
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l102 = alloca ptr
  %l107 = alloca ptr
  %l110 = alloca %"compiler/typed:Elem"
  %l114 = alloca ptr
  %l115 = alloca i1
  %l124 = alloca %"compiler/source:Span"
  %l125 = alloca i32
  %l130 = alloca ptr
  %l135 = alloca %"compiler/typed:Payload"
  %l139 = alloca ptr
  %l140 = alloca i1
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca i32
  %l156 = alloca ptr
  %l160 = alloca i32
  %l163 = alloca ptr
  %l164 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %rv = alloca ptr
  %t38 = alloca { i64, [4 x i64] }, align 8
  %t89 = alloca { i64, [4 x i64] }, align 8
  %t145 = alloca { i64, [4 x i64] }, align 8
  %t219 = alloca { i64, [4 x i64] }, align 8
  %t285 = alloca { i64, [4 x i64] }, align 8
  %t347 = alloca { i64, [4 x i64] }, align 8
  %t392 = alloca { i64, [4 x i64] }, align 8
  %t428 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t30, i32 0, i32 3
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l6, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t34 = load %"compiler/source:Span", ptr %l3
  %t35 = load i32, ptr %l4, !tbaa !23
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i32, ptr %l6, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 0
  store i64 1, ptr %t39
  %t41 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t34, 0
  %t43 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t41, i32 %t35, 1
  %t45 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t43, i64 %t36, 2
  %t47 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t45, i32 %t37, 3
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t47, ptr %t48
  %t49 = load { i64, [4 x i64] }, ptr %t38
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t49, ptr %t51
  store ptr %t51, ptr %rv
  br label %ret
bb6:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t54 = load ptr, ptr %l47, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb7, label %bb8
bb7:
  %t57 = load ptr, ptr %l47, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 2
  store i1 %t60, ptr %l48, !tbaa !21
  br label %bb8
bb8:
  %t61 = load i1, ptr %l48, !tbaa !21
  br i1 %t61, label %bb9, label %bb10
bb9:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  store %"compiler/source:Span" %t66, ptr %l7
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 1
  %t72 = load i32, ptr %t71
  store i32 %t72, ptr %l8, !tbaa !23
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l9, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t80 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t80, ptr %l57
  %t81 = load i32, ptr %l8, !tbaa !23
  store i32 %t81, ptr %l58, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l9, !tbaa !29
  %t84 = load i64, ptr %l2, !tbaa !24
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t82, ptr %t83, i64 %t84)
  store ptr %t88, ptr %l62
  br label %bb12
bb12:
  store { i64, [4 x i64] } zeroinitializer, ptr %t89
  %t90 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 0
  store i64 2, ptr %t90
  %t91 = load %"compiler/source:Span", ptr %l57
  %t92 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t91, 0
  %t93 = load i32, ptr %l58, !tbaa !23
  %t94 = insertvalue { %"compiler/source:Span", i32, ptr } %t92, i32 %t93, 1
  %t95 = load ptr, ptr %l62, !tbaa !29
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } %t94, ptr %t95, 2
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t96, ptr %t97
  %t98 = load { i64, [4 x i64] }, ptr %t89
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t98, ptr %t100
  store ptr %t100, ptr %rv
  br label %ret
bb13:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t103 = load ptr, ptr %l65, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb14, label %bb15
bb14:
  %t106 = load ptr, ptr %l65, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l66, !tbaa !21
  br label %bb15
bb15:
  %t110 = load i1, ptr %l66, !tbaa !21
  br i1 %t110, label %bb16, label %bb17
bb16:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t113, i32 0, i32 0
  %t115 = load %"compiler/source:Span", ptr %t114
  store %"compiler/source:Span" %t115, ptr %l10
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l11, !tbaa !23
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l12, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t131, i32 0, i32 3
  %t133 = load i64, ptr %t132
  store i64 %t133, ptr %l13, !tbaa !24
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t135 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t135, ptr %l77
  %t136 = load i32, ptr %l11, !tbaa !23
  store i32 %t136, ptr %l78, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l12, !tbaa !29
  %t139 = load i64, ptr %l2, !tbaa !24
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t137, ptr %t138, i64 %t139)
  store ptr %t143, ptr %l82
  br label %bb19
bb19:
  %t144 = load i64, ptr %l13, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t145
  %t146 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 0
  store i64 3, ptr %t146
  %t147 = load %"compiler/source:Span", ptr %l77
  %t148 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t147, 0
  %t149 = load i32, ptr %l78, !tbaa !23
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t148, i32 %t149, 1
  %t151 = load ptr, ptr %l82, !tbaa !29
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t150, ptr %t151, 2
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t152, i64 %t144, 3
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t154, ptr %t155
  %t156 = load { i64, [4 x i64] }, ptr %t145
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t156, ptr %t158
  store ptr %t158, ptr %rv
  br label %ret
bb20:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t161 = load ptr, ptr %l86, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb21, label %bb22
bb21:
  %t164 = load ptr, ptr %l86, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 8}
  %t167 = icmp eq i64 %t165, 4
  store i1 %t167, ptr %l87, !tbaa !21
  br label %bb22
bb22:
  %t168 = load i1, ptr %l87, !tbaa !21
  br i1 %t168, label %bb23, label %bb24
bb23:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t171, i32 0, i32 0
  %t173 = load %"compiler/source:Span", ptr %t172
  store %"compiler/source:Span" %t173, ptr %l14
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l15, !tbaa !23
  %t181 = load ptr, ptr %l1, !tbaa !29
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t187 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t187, ptr %l96
  %t188 = load i32, ptr %l15, !tbaa !23
  store i32 %t188, ptr %l97, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l16, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Elem", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t194 = load i64, ptr %l2, !tbaa !24
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v0, ptr %t189, ptr %t193, i64 %t194)
  store ptr %t198, ptr %l102
  br label %bb26
bb26:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l16, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Elem", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t204 = load i64, ptr %l2, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t199, ptr %t203, i64 %t204)
  store ptr %t208, ptr %l107
  br label %bb27
bb27:
  %t209 = load ptr, ptr %l16, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Elem", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %t211, !range !{i32 0, i32 3}
  %t213 = load ptr, ptr %l102, !tbaa !29
  %t214 = load ptr, ptr %l107, !tbaa !29
  %t216 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v2, ptr %t213, ptr %t214, i32 %t212)
  store %"compiler/typed:Elem" %t216, ptr %l110
  br label %bb28
bb28:
  %t217 = load %"compiler/typed:Elem", ptr %l110
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Elem" %t217, ptr %t218
  store { i64, [4 x i64] } zeroinitializer, ptr %t219
  %t220 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 0
  store i64 4, ptr %t220
  %t221 = load %"compiler/source:Span", ptr %l96
  %t222 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t221, 0
  %t223 = load i32, ptr %l97, !tbaa !23
  %t224 = insertvalue { %"compiler/source:Span", i32, ptr } %t222, i32 %t223, 1
  %t226 = insertvalue { %"compiler/source:Span", i32, ptr } %t224, ptr %t218, 2
  %t227 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t226, ptr %t227
  %t228 = load { i64, [4 x i64] }, ptr %t219
  %t230 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t228, ptr %t230
  store ptr %t230, ptr %rv
  br label %ret
bb29:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t233 = load ptr, ptr %l114, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb30, label %bb31
bb30:
  %t236 = load ptr, ptr %l114, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 8}
  %t239 = icmp eq i64 %t237, 5
  store i1 %t239, ptr %l115, !tbaa !21
  br label %bb31
bb31:
  %t240 = load i1, ptr %l115, !tbaa !21
  br i1 %t240, label %bb32, label %bb33
bb32:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [4 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l17
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t249, i32 0, i32 1
  %t251 = load i32, ptr %t250
  store i32 %t251, ptr %l18, !tbaa !23
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [4 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l19, !tbaa !29
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t259 = load %"compiler/source:Span", ptr %l17
  store %"compiler/source:Span" %t259, ptr %l124
  %t260 = load i32, ptr %l18, !tbaa !23
  store i32 %t260, ptr %l125, !tbaa !23
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l19, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Payload", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t266 = load i64, ptr %l2, !tbaa !24
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyPlace(ptr %v0, ptr %v1, ptr %v0, ptr %t261, ptr %t265, i64 %t266)
  store ptr %t270, ptr %l130
  br label %bb35
bb35:
  %t271 = load ptr, ptr %l19, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Payload", ptr %t271, i32 0, i32 1
  %t274 = load i64, ptr %t273, !tbaa !24
  %t275 = load ptr, ptr %l19, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Payload", ptr %t275, i32 0, i32 2
  %t278 = load i32, ptr %t277, !range !{i32 0, i32 3}
  %t279 = load ptr, ptr %l130, !tbaa !29
  %t282 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v2, ptr %t279, i64 %t274, i32 %t278)
  store %"compiler/typed:Payload" %t282, ptr %l135
  br label %bb36
bb36:
  %t283 = load %"compiler/typed:Payload", ptr %l135
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Payload" %t283, ptr %t284
  store { i64, [4 x i64] } zeroinitializer, ptr %t285
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 0
  store i64 5, ptr %t286
  %t287 = load %"compiler/source:Span", ptr %l124
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t287, 0
  %t289 = load i32, ptr %l125, !tbaa !23
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, i32 %t289, 1
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr } %t290, ptr %t284, 2
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t292, ptr %t293
  %t294 = load { i64, [4 x i64] }, ptr %t285
  %t296 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t294, ptr %t296
  store ptr %t296, ptr %rv
  br label %ret
bb37:
  %t298 = load ptr, ptr %l1, !tbaa !29
  store ptr %t298, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t299 = load ptr, ptr %l139, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb38, label %bb39
bb38:
  %t302 = load ptr, ptr %l139, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 8}
  %t305 = icmp eq i64 %t303, 6
  store i1 %t305, ptr %l140, !tbaa !21
  br label %bb39
bb39:
  %t306 = load i1, ptr %l140, !tbaa !21
  br i1 %t306, label %bb40, label %bb41
bb40:
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr { i64, [4 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t309, i32 0, i32 0
  %t311 = load %"compiler/source:Span", ptr %t310
  store %"compiler/source:Span" %t311, ptr %l20
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t315, i32 0, i32 1
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l21, !tbaa !23
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t321, i32 0, i32 2
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l22, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [4 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t327, i32 0, i32 3
  %t329 = load i32, ptr %t328
  store i32 %t329, ptr %l23, !tbaa !23
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t331 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t331, ptr %l151
  %t332 = load i32, ptr %l21, !tbaa !23
  store i32 %t332, ptr %l152, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l22, !tbaa !29
  %t335 = load i64, ptr %l2, !tbaa !24
  %t339 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t333, ptr %t334, i64 %t335)
  store ptr %t339, ptr %l156
  br label %bb43
bb43:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load i32, ptr %l23, !tbaa !23
  %t342 = load i64, ptr %l2, !tbaa !24
  %t346 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %t340, i32 %t341, i64 %t342)
  store i32 %t346, ptr %l160
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 0
  store i64 6, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l151
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l152, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t350, i32 %t351, 1
  %t353 = load ptr, ptr %l156, !tbaa !29
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t352, ptr %t353, 2
  %t355 = load i32, ptr %l160, !tbaa !23
  %t356 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t354, i32 %t355, 3
  %t357 = getelementptr { i64, [4 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t356, ptr %t357
  %t358 = load { i64, [4 x i64] }, ptr %t347
  %t360 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t358, ptr %t360
  store ptr %t360, ptr %rv
  br label %ret
bb45:
  %t362 = load ptr, ptr %l1, !tbaa !29
  store ptr %t362, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t363 = load ptr, ptr %l163, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb46, label %bb47
bb46:
  %t366 = load ptr, ptr %l163, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 8}
  %t369 = icmp eq i64 %t367, 0
  store i1 %t369, ptr %l164, !tbaa !21
  br label %bb47
bb47:
  %t370 = load i1, ptr %l164, !tbaa !21
  br i1 %t370, label %bb48, label %bb49
bb48:
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t373, i32 0, i32 0
  %t375 = load %"compiler/source:Span", ptr %t374
  store %"compiler/source:Span" %t375, ptr %l24
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [4 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t379, i32 0, i32 1
  %t381 = load i32, ptr %t380
  store i32 %t381, ptr %l25, !tbaa !23
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t385, i32 0, i32 2
  %t387 = load i32, ptr %t386
  store i32 %t387, ptr %l26, !tbaa !23
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t389 = load %"compiler/source:Span", ptr %l24
  %t390 = load i32, ptr %l25, !tbaa !23
  %t391 = load i32, ptr %l26, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t392
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t392, i32 0, i32 0
  store i64 0, ptr %t393
  %t395 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t389, 0
  %t397 = insertvalue { %"compiler/source:Span", i32, i32 } %t395, i32 %t390, 1
  %t399 = insertvalue { %"compiler/source:Span", i32, i32 } %t397, i32 %t391, 2
  %t400 = getelementptr { i64, [4 x i64] }, ptr %t392, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t399, ptr %t400
  %t401 = load { i64, [4 x i64] }, ptr %t392
  %t403 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t401, ptr %t403
  store ptr %t403, ptr %rv
  br label %ret
bb51:
  %t405 = load ptr, ptr %l1, !tbaa !29
  store ptr %t405, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t406 = load ptr, ptr %l178, !tbaa !29
  %t407 = icmp ne ptr %t406, null
  br i1 %t407, label %bb52, label %bb53
bb52:
  %t409 = load ptr, ptr %l178, !tbaa !29
  %t410 = load i64, ptr %t409, !range !{i64 0, i64 8}
  %t412 = icmp eq i64 %t410, 7
  store i1 %t412, ptr %l179, !tbaa !21
  br label %bb53
bb53:
  %t413 = load i1, ptr %l179, !tbaa !21
  br i1 %t413, label %bb54, label %bb55
bb54:
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t416 = getelementptr { i64, [4 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { %"compiler/source:Span", i32 }, ptr %t416, i32 0, i32 0
  %t418 = load %"compiler/source:Span", ptr %t417
  store %"compiler/source:Span" %t418, ptr %l27
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr { i64, [4 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", i32 }, ptr %t422, i32 0, i32 1
  %t424 = load i32, ptr %t423
  store i32 %t424, ptr %l28, !tbaa !23
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t426 = load %"compiler/source:Span", ptr %l27
  %t427 = load i32, ptr %l28, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 0
  store i64 7, ptr %t429
  %t431 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t426, 0
  %t433 = insertvalue { %"compiler/source:Span", i32 } %t431, i32 %t427, 1
  %t434 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t433, ptr %t434
  %t435 = load { i64, [4 x i64] }, ptr %t428
  %t437 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t435, ptr %t437
  store ptr %t437, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_aa0d5e524103d919_41af477b1830b7e5)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l29 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l62 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 4
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l29, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t38, ptr %t36, ptr %t40)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l5, !tbaa !24
  br label %bb6
bb12:
  br label %bb50
bb13:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t49 = load ptr, ptr %l37, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t52 = load ptr, ptr %l37, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 6
  store i1 %t55, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l38, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  br label %bb38
bb18:
  %t63 = load ptr, ptr %l8, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Call", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l9, !tbaa !29
  %t68 = load ptr, ptr %l9, !tbaa !29
  store ptr %t68, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t69 = load ptr, ptr %l45, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 5}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l46, !tbaa !21
  br label %bb20
bb20:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l10, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t84 = load i32, ptr %l10, !tbaa !23
  %t86 = sext i32 %t84 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t83, i64 %t86)
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_1e68dbdbde35cba9_f30fa4c89b16ec2d)
  unreachable
bb30:
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Call", ptr %t89, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t98 = load i64, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t106 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t106, ptr %l62, !tbaa !27
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 %t107
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t114, ptr %t112, ptr %t116)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t120 = load i64, ptr %l12, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l12, !tbaa !24
  br label %bb31
bb37:
  br label %bb50
bb38:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t125 = load ptr, ptr %l70, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t128 = load ptr, ptr %l70, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 18}
  %t131 = icmp eq i64 %t129, 17
  store i1 %t131, ptr %l71, !tbaa !21
  br label %bb40
bb40:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb41, label %bb42
bb41:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l15, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l15, !tbaa !29
  %t141 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBodies(ptr %v0, ptr %v1, ptr %v2, ptr %t139, ptr %t140, ptr %t141)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_af264802bedcf8d8_5deeb41ed3d90c7c)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t23 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  %t37 = extractvalue { i64, [2 x i64] } %t33, 0
  %t38 = icmp eq i64 %t37, 1
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8d3e5410ed2a27a9_4efdc57dac874585)
  unreachable
bb15:
  %t40 = load i1, ptr %l21, !tbaa !21
  store i1 %t40, ptr %l7, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_1dfbc037cdd154d8_cf42e6f659c8aed4)
  unreachable
bb21:
  %t41 = load i1, ptr %l7, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur0(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l5, !tbaa !29
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecided(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l5 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eleaves(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t7, ptr %l5
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 49
  store i1 true, ptr %t10, !tbaa !21
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultCopiesRecv(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i32
  %l11 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l25 = alloca i32
  %l30 = alloca i32
  %l36 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t4, i64 %a1)
  store i32 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l2, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l16
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l11, !tbaa !29
  %t27 = load i32, ptr %l16, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t28, ptr %l17
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t38, ptr %l23, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i32, ptr %t40, i64 0
  %t42 = load i32, ptr %t41, !tbaa !33
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t37, i32 %t42)
  store i32 %t45, ptr %l25
  br label %bb7
bb7:
  %t46 = load i32, ptr %l25, !tbaa !23
  store i32 %t46, ptr %l4, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l4, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l30
  br label %bb8
bb8:
  %t57 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t59 = trunc i64 25 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l36, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l41
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t84, i32 %t85)
  store i64 %t88, ptr %l46
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  %t95 = load i32, ptr %l4, !tbaa !23
  %t98 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l51
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l36, !tbaa !29
  %t100 = load i32, ptr %l41, !tbaa !23
  %t101 = load i64, ptr %l46, !tbaa !24
  %t102 = load i64, ptr %l51, !tbaa !24
  %t103 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %t99, i32 %t100, i64 %t101, i64 %t102, i64 0)
  store i1 %t103, ptr %l52
  br label %bb15
bb15:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l40 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca { i64, [3 x i64] }
  %l55 = alloca %"compiler/diagmsg:Msg"
  %l56 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca i1
  %l70 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i1
  %l92 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t19 = load ptr, ptr %l24, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb10
bb8:
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 8}
  %t25 = icmp eq i64 %t23, 1
  store i1 %t25, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t26 = load i1, ptr %l25, !tbaa !21
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l22, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  store %"compiler/source:Span" %t32, ptr %l2
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load ptr, ptr %t37
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  %t50 = getelementptr { i64, [4 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t50, i32 0, i32 3
  %t52 = load i32, ptr %t51
  store i32 %t52, ptr %l4, !tbaa !23
  br label %bb13
bb12:
  br label %bb25
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i32, ptr %l4, !tbaa !23
  %t63 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t57, i64 %t58, i32 %t59)
  store ptr %t63, ptr %l40
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l40, !tbaa !29
  store ptr %t64, ptr %l5, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:VarDecl", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %t74)
  store i1 %t76, ptr %l47
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i1, ptr %l47, !tbaa !21
  store i1 %t77, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t78 = load i1, ptr %l44, !tbaa !21
  br i1 %t78, label %bb19, label %bb20
bb19:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/load:Loader", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l2
  %t93 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t89, %"compiler/source:Span" %t90)
  store { i64, [3 x i64] } %t93, ptr %l54
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t94 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v0, { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l51, !tbaa !29
  %t96 = load { i64, [3 x i64] }, ptr %l54
  %t97 = load %"compiler/diagmsg:Msg", ptr %l55
  %t98 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v0, ptr %t95, { i64, [3 x i64] } %t96, %"compiler/diagmsg:Msg" %t97)
  store i64 %t98, ptr %l56
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %bb56
bb25:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t100 = load ptr, ptr %l57, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 9
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb28, label %bb29
bb28:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t110, i32 0, i32 4
  %t112 = load { i64, ptr }, ptr %t111
  store { i64, ptr } %t112, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t114 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t114, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb32, label %bb33
bb32:
  br label %bb37
bb33:
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t128, ptr %l70, !tbaa !27
  %t129 = load i64, ptr %l8, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr ptr, ptr %t132, i64 %t129
  %t134 = load ptr, ptr %t133, !tbaa !39
  %t136 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t136, ptr %t134)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l8, !tbaa !24
  br label %bb31
bb37:
  br label %bb56
bb38:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t146 = load ptr, ptr %l78, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb39, label %bb40
bb39:
  %t149 = load ptr, ptr %l78, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t153 = load i1, ptr %l79, !tbaa !21
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Call", ptr %t160, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 0
  store i64 %t167, ptr %l14, !tbaa !24
  br label %bb44
bb44:
  %t169 = load i64, ptr %l13, !tbaa !24
  %t170 = load i64, ptr %l14, !tbaa !24
  %t173 = icmp slt i64 %t169, %t170
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t177 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t177, ptr %l92, !tbaa !27
  %t178 = load i64, ptr %l13, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr ptr, ptr %t181, i64 %t178
  %t183 = load ptr, ptr %t182, !tbaa !39
  %t185 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t185, ptr %t183)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t190 = load i64, ptr %l13, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l13, !tbaa !24
  br label %bb44
bb50:
  br label %bb56
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_5535019c26f71449_86439f2d3bbcfbb5)
  unreachable
bb56:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l42 = alloca i64
  %t22 = alloca { i64, [1 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca { i64, [1 x i64] }, align 8
  %t94 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  store i1 %t10, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:ForIn", ptr %t14, i32 0, i32 0
  %t17 = load i32, ptr %t16, !tbaa !23
  store i32 %t17, ptr %l15, !tbaa !23
  %t18 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t18, ptr %l16
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t19)
  store i32 %t21, ptr %l18
  br label %bb6
bb5:
  br label %bb10
bb6:
  store { i64, [1 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [1 x i64] }, ptr %t22
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = load %"compiler/source:Span", ptr %l16
  %t28 = load i32, ptr %l18, !tbaa !23
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t25, i32 %t26, %"compiler/source:Span" %t27, i32 %t28, i32 1, { i64, [1 x i64] } %t24)
  store i64 %t31, ptr %l21
  br label %bb7
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l23
  %t37 = trunc i64 %t32 to i32
  store i32 %t37, ptr %l26, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t41 = load i64, ptr %l3, !tbaa !24
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t39, %"compiler/source:Span" %t40, i64 %t41)
  store ptr %t45, ptr %l30
  br label %bb8
bb8:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load %"compiler/source:Span", ptr %l23
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t48, 0
  %t50 = load i32, ptr %l26, !tbaa !23
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr } %t49, i32 %t50, 1
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = insertvalue { %"compiler/source:Span", i32, ptr } %t51, ptr %t52, 2
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t53, ptr %t54
  %t55 = load { i64, [3 x i64] }, ptr %t46
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t55, ptr %t57
  %t58 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t58, ptr %t57)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l33, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:ForIn", ptr %t61, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  store i32 %t64, ptr %l35, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l36
  %t66 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t66)
  store i32 %t69, ptr %l39
  br label %bb11
bb11:
  store { i64, [1 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [1 x i64] }, ptr %t70, i32 0, i32 0
  store i64 4, ptr %t71
  %t72 = load { i64, [1 x i64] }, ptr %t70
  %t73 = load ptr, ptr %l33, !tbaa !29
  %t74 = load i32, ptr %l35, !tbaa !23
  %t75 = load %"compiler/source:Span", ptr %l36
  %t76 = load i32, ptr %l39, !tbaa !23
  %t79 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t73, i32 %t74, %"compiler/source:Span" %t75, i32 %t76, i32 1, { i64, [1 x i64] } %t72)
  store i64 %t79, ptr %l42
  br label %bb12
bb12:
  %t80 = load i64, ptr %l42, !tbaa !24
  store i64 %t80, ptr %l6, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v2, ptr %t81, i64 %t82, ptr %t83)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = load ptr, ptr %l4, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t91, 1
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t93, 2
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [3 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t103, ptr %t105
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t87, ptr %t105)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i32
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca ptr
  %l103 = alloca i32
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %t9, %"compiler/source:Span" %a1, i64 %t11, i64 %t12)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l32
  br label %bb9
bb9:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l5
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t26, %t27
  store i64 %t30, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 28
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l38
  br label %bb10
bb10:
  %t37 = load i64, ptr %l38, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l45, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l45, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store ptr %l5, ptr %l63, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 28
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t86, i64 %t82)
  store i32 %t90, ptr %l67
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l63, !tbaa !29
  %t92 = load i32, ptr %l67, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t91, i32 %t92)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l10, !tbaa !24
  br label %bb17
bb24:
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l12, !tbaa !24
  %t99 = load i64, ptr %l2, !tbaa !24
  %t100 = load i64, ptr %l3, !tbaa !24
  %t103 = add i64 %t99, %t100
  store i64 %t103, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t105 = load i64, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l12, !tbaa !24
  %t109 = icmp sgt i64 %t105, %t106
  br i1 %t109, label %bb25, label %bb26
bb25:
  %t111 = load i64, ptr %l14, !tbaa !24
  %t113 = icmp sgt i64 %t111, 0
  br i1 %t113, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb27:
  %t115 = load i64, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t119 = sub i64 %t115, %t116
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = sub i64 %t123, 1
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sdiv i64 %t125, %t126
  store i64 %t129, ptr %l80, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb29
bb29:
  %t131 = load i64, ptr %l80, !tbaa !24
  store i64 %t131, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t132 = load i64, ptr %l77, !tbaa !24
  store i64 %t132, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  %t133 = load i64, ptr %l16, !tbaa !24
  %t134 = load i64, ptr %l15, !tbaa !24
  %t137 = icmp slt i64 %t133, %t134
  %t139 = xor i1 %t137, true
  br i1 %t139, label %bb32, label %bb33
bb32:
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t141 = load i64, ptr %l12, !tbaa !24
  %t142 = load i64, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l14, !tbaa !24
  %t146 = mul i64 %t142, %t143
  %t149 = add i64 %t141, %t146
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/check:frame", ptr %t151, i32 0, i32 29
  store ptr %t153, ptr %l99, !tbaa !29
  %t154 = load ptr, ptr %l4, !tbaa !29
  %t156 = getelementptr %"compiler/check:frame", ptr %t154, i32 0, i32 28
  %t160 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t156, i64 %t149)
  store i32 %t160, ptr %l103
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t162 = load i32, ptr %l103, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t161, i32 %t162)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t163 = load i64, ptr %l16, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l16, !tbaa !24
  br label %bb31
bb38:
  %t167 = load ptr, ptr %l4, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 28
  %t170 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t169, i64 %t170)
  br label %bb39
bb39:
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb40
bb40:
  %t174 = load i64, ptr %l19, !tbaa !24
  store i64 %t174, ptr %l110, !tbaa !24
  %t175 = load ptr, ptr %l18, !tbaa !29
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t175)
  store i64 %t177, ptr %l112
  br label %bb41
bb41:
  %t178 = load i64, ptr %l110, !tbaa !24
  %t179 = load i64, ptr %l112, !tbaa !24
  %t180 = icmp slt i64 %t178, %t179
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t184 = load ptr, ptr %l18, !tbaa !29
  %t185 = load i64, ptr %l19, !tbaa !24
  %t188 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t184, i64 %t185)
  store i32 %t188, ptr %l117
  br label %bb45
bb45:
  %t189 = load i32, ptr %l117, !tbaa !23
  %t190 = load ptr, ptr %l4, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t192, i32 %t189)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l19, !tbaa !24
  br label %bb40
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca %"compiler/generic:Desc"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i64
  %l39 = alloca i32
  %l42 = alloca i1
  %l50 = alloca %"compiler/generic:Desc"
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i64, ptr %l15, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i64, ptr %l24, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_dd139b797ad07c59_48ae02fb28d54045)
  unreachable
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i64 %t47, ptr %l27
  br label %bb20
bb20:
  %t48 = load i64, ptr %l27, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb21, label %bb22
bb21:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t59 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNamed(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  store i64 %t59, ptr %l33
  br label %bb24
bb24:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = icmp sge i64 %t61, 0
  br i1 %t63, label %bb25, label %bb26
bb25:
  %t65 = load i64, ptr %l4, !tbaa !24
  store i64 %t65, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i32 %t71, ptr %l39
  br label %bb28
bb28:
  %t72 = load i32, ptr %l39, !tbaa !23
  store i32 %t72, ptr %l5, !tbaa !23
  %t73 = load i32, ptr %l5, !tbaa !23
  %t75 = icmp slt i32 %t73, 0
  br i1 %t75, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb31
bb30:
  %t77 = load i32, ptr %l5, !tbaa !23
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t81 = icmp eq i32 %t77, %t78
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb31
bb31:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb32, label %bb33
bb32:
  store i64 -1, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i32, ptr %l5, !tbaa !23
  %t92 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t88, i32 %t89)
  store %"compiler/generic:Desc" %t92, ptr %l50
  br label %bb35
bb35:
  %t93 = load %"compiler/generic:Desc", ptr %l50
  store %"compiler/generic:Desc" %t93, ptr %l6
  %t94 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t99 = icmp eq i64 %t95, %t96
  br i1 %t99, label %bb36, label %bb37
bb36:
  %t101 = getelementptr %"compiler/generic:Desc", ptr %l6, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l54, !tbaa !24
  br label %bb38
bb37:
  store i64 -1, ptr %l54, !tbaa !24
  br label %bb38
bb38:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnFact(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l10 = alloca %"compiler/check:factRead"
  %l11 = alloca i64
  %l14 = alloca %"compiler/check:factRead"
  %l17 = alloca { i64, ptr }
  %l19 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %l30 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i64
  %l43 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca %"compiler/effects:Facts"
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l77 = alloca { i64, ptr }
  %l80 = alloca %"compiler/check:factRead"
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca ptr
  %l96 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l110 = alloca %"compiler/diagmsg:Msg"
  %l111 = alloca i64
  %l114 = alloca ptr
  %l118 = alloca i64
  %l122 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca i64
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca i64
  %l142 = alloca { i64, ptr }
  %l145 = alloca %"compiler/check:factRead"
  %l149 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca i32
  %l154 = alloca i1
  %l155 = alloca i64
  %l156 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a4)
  store { i64, ptr } %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %t7)
  store i32 %t9, ptr %l19
  br label %bb2
bb2:
  %t10 = load i32, ptr %l19, !range !{i32 0, i32 10}
  store i32 %t10, ptr %l6
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = call i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %t11)
  store i1 %t13, ptr %l21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l21, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  %t15 = load i32, ptr %l6, !range !{i32 0, i32 10}
  %t17 = trunc i64 9 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i1, ptr %l7, !tbaa !21
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l24, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l24, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l30
  br label %bb10
bb10:
  %t31 = load i64, ptr %l30, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t37 = load i1, ptr %l7, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l35, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t40, ptr %l36
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t41, ptr %l37, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v0, ptr %t42, i64 %t43, { i64, ptr } %t44)
  store i1 %t48, ptr %l41
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t49 = load i1, ptr %l41, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l42, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l35, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l36
  %t52 = load i32, ptr %l37, !tbaa !23
  %t53 = load i64, ptr %l42, !tbaa !24
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t50, %"compiler/source:Span" %t51, i32 %t52, i64 %t53)
  store ptr %t54, ptr %l43
  br label %bb20
bb20:
  %t55 = load ptr, ptr %l43, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t60, i64 %t61)
  store i1 %t64, ptr %l48
  br label %bb22
bb22:
  %t65 = load i1, ptr %l48, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 61
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t71 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t74 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t75 = add i64 %t72, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t80 = extractvalue { i64, ptr } %t70, 1
  %t81 = extractvalue { i64, ptr } %t70, 0
  %t82 = add i64 %t78, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t71, i64 %t72)
  %t84 = getelementptr i8, ptr %t83, i64 %t72
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t69)
  %t86 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t86, ptr %t76, i64 %t77)
  %t87 = getelementptr i8, ptr %t86, i64 %t77
  call void @olang_textcopy(ptr %t87, ptr %t80, i64 %t81)
  %t88 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t83, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t99 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %s4, ptr %t68, { i64, ptr } %t96)
  %t100 = extractvalue { i32, i1 } %t99, 1
  %t101 = extractvalue { i32, i1 } %t99, 0
  store i32 %t101, ptr %l57
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb26, label %ok.103, !prof !99
ok.103:
  store i1 %t100, ptr %l56
  br label %bb25
bb24:
  br label %bb43
bb25:
  %t104 = load i1, ptr %l56, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t105)
  store ptr %t107, ptr %l59
  br label %bb28
bb28:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t111 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %t109, i64 %t108)
  store %"compiler/effects:Facts" %t111, ptr %l61
  br label %bb29
bb29:
  %t112 = load i32, ptr %l6, !range !{i32 0, i32 10}
  %t115 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s4, ptr %l61, i32 %t112)
  store i1 %t115, ptr %l64
  br label %bb30
bb30:
  %t116 = load i1, ptr %l64, !tbaa !21
  store i1 %t116, ptr %l49, !tbaa !21
  br label %bb31
bb31:
  %t117 = load i1, ptr %l49, !tbaa !21
  %t118 = load i64, ptr %l8, !tbaa !24
  store i64 %t118, ptr %l65, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t119, ptr %l66, !tbaa !27
  store i1 %t117, ptr %l67, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t121)
  store ptr %t123, ptr %l69
  br label %bb32
bb32:
  %t124 = load ptr, ptr %l69, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 2
  %t127 = load i64, ptr %t126, !tbaa !24
  store i64 %t127, ptr %l71, !tbaa !24
  %t128 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t128, ptr %l72
  %t129 = ptrtoint ptr %v0 to i64
  store i64 %t129, ptr %l73, !tbaa !24
  %t130 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactRead_2e6
  br i1 %t130, label %bb33, label %bb34
bb33:
  %t132 = call ptr @__olang_region_make(ptr %v0)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l73, !tbaa !24
  br label %bb34
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s4, ptr %t134, %"compiler/source:Span" %t135)
  store { i64, ptr } %t138, ptr %l77
  br label %bb35
bb35:
  %t139 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = load i64, ptr %l73
  %t143 = inttoptr i64 %t142 to ptr
  %t144 = call ptr @__olang_scope_alloc(ptr %t143, i64 %t141)
  call void @olang_textcopy(ptr %t144, ptr %t140, i64 %t141)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t148 = load i64, ptr %l73
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = extractvalue { i64, ptr } %t146, 0
  %t151 = extractvalue { i64, ptr } %t146, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %t149, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  %t156 = load i64, ptr %l65, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t158 = load i1, ptr %l67, !tbaa !21
  %t159 = load i64, ptr %l71, !tbaa !24
  %t160 = load %"compiler/source:Span", ptr %l72
  %t162 = call %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v0, ptr %v0, i64 -1, i64 %t156, { i64, ptr } %t157, i1 %t158, i64 %t159, %"compiler/source:Span" %t160, { i64, ptr } %t155)
  store %"compiler/check:factRead" %t162, ptr %l80
  br label %bb36
bb36:
  %t163 = load %"compiler/check:factRead", ptr %l80
  store %"compiler/check:factRead" %t163, ptr %l10
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 60
  %t167 = load %"compiler/check:factRead", ptr %l10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t166, %"compiler/check:factRead" %t167)
  br label %bb37
bb37:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l84, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t171, ptr %l85
  %t172 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t172, ptr %l86, !tbaa !23
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v0, ptr %t173, ptr %l10)
  store i1 %t176, ptr %l89
  br label %bb38
bb38:
  %t177 = load i1, ptr %l89, !tbaa !21
  br i1 %t177, label %bb39, label %bb40
bb39:
  store i64 1, ptr %l90, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb41
bb41:
  %t178 = load ptr, ptr %l84, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l85
  %t180 = load i32, ptr %l86, !tbaa !23
  %t181 = load i64, ptr %l90, !tbaa !24
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t178, %"compiler/source:Span" %t179, i32 %t180, i64 %t181)
  store ptr %t182, ptr %l91
  br label %bb42
bb42:
  %t183 = load ptr, ptr %l91, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t183, ptr %rv
  br label %ret
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t187 = load i64, ptr %l8, !tbaa !24
  %t191 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %t185, ptr %t186, i64 %t187)
  store i64 %t191, ptr %l96
  br label %bb44
bb44:
  %t192 = load i64, ptr %l96, !tbaa !24
  store i64 %t192, ptr %l11, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t195 = icmp slt i64 %t193, 0
  br i1 %t195, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l100
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l101, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t204 = load i64, ptr %l8, !tbaa !24
  %t207 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s7, ptr %t203, i64 %t204)
  store ptr %t207, ptr %l105
  br label %bb47
bb46:
  br label %bb52
bb47:
  %t208 = load ptr, ptr %l105, !tbaa !29
  %t210 = getelementptr %"compiler/ast:Func", ptr %t208, i32 0, i32 2
  %t211 = load i32, ptr %t210, !tbaa !23
  %t212 = load ptr, ptr %l101, !tbaa !29
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t212, i32 %t211)
  store { i64, ptr } %t214, ptr %l108
  br label %bb48
bb48:
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t218 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t216, { i64, ptr } %t215)
  store %"compiler/diagmsg:Msg" %t218, ptr %l110
  br label %bb49
bb49:
  %t219 = load ptr, ptr %l99, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l100
  %t221 = load %"compiler/diagmsg:Msg", ptr %l110
  %t222 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t219, %"compiler/source:Span" %t220, %"compiler/diagmsg:Msg" %t221)
  store i64 %t222, ptr %l111
  br label %bb50
bb50:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  %t227 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t223, %"compiler/source:Span" %t224)
  store ptr %t227, ptr %l114
  br label %bb51
bb51:
  %t228 = load ptr, ptr %l114, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t228, ptr %rv
  br label %ret
bb52:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l11, !tbaa !24
  %t234 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t230, i64 %t231)
  store i64 %t234, ptr %l118
  br label %bb53
bb53:
  %t235 = load i64, ptr %l11, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t238 = call i64 @__olang_fmt_i64(ptr null, i64 %t235)
  %t239 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t243 = extractvalue { i64, ptr } %t236, 1
  %t244 = extractvalue { i64, ptr } %t236, 0
  %t245 = add i64 %t241, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  %t247 = call i64 @__olang_fmt_i64(ptr %t246, i64 %t235)
  %t248 = getelementptr i8, ptr %t246, i64 %t238
  call void @olang_textcopy(ptr %t248, ptr %t239, i64 %t240)
  %t249 = getelementptr i8, ptr %t248, i64 %t240
  call void @olang_textcopy(ptr %t249, ptr %t243, i64 %t244)
  %t250 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t246, 1
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 61
  %t259 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %s0, ptr %t255, { i64, ptr } %t251)
  %t260 = extractvalue { i32, i1 } %t259, 1
  %t261 = extractvalue { i32, i1 } %t259, 0
  store i32 %t261, ptr %l127
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb55, label %ok.263, !prof !99
ok.263:
  store i1 %t260, ptr %l126
  br label %bb54
bb54:
  %t264 = load i1, ptr %l126, !tbaa !21
  store i1 %t264, ptr %l122, !tbaa !21
  br label %bb58
bb55:
  br label %bb56
bb56:
  %t265 = load i32, ptr %l6, !range !{i32 0, i32 10}
  %t267 = call i1 @compiler_2feffects_2eConservative(i32 %t265)
  store i1 %t267, ptr %l129
  br label %bb57
bb57:
  %t268 = load i1, ptr %l129, !tbaa !21
  store i1 %t268, ptr %l122, !tbaa !21
  br label %bb58
bb58:
  %t269 = load i1, ptr %l122, !tbaa !21
  %t270 = load i64, ptr %l11, !tbaa !24
  store i64 %t270, ptr %l130, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t271, ptr %l131, !tbaa !27
  store i1 %t269, ptr %l132, !tbaa !21
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t273)
  store ptr %t275, ptr %l134
  br label %bb59
bb59:
  %t276 = load ptr, ptr %l134, !tbaa !29
  %t278 = getelementptr %"compiler/check:frame", ptr %t276, i32 0, i32 2
  %t279 = load i64, ptr %t278, !tbaa !24
  store i64 %t279, ptr %l136, !tbaa !24
  %t280 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t280, ptr %l137
  %t281 = ptrtoint ptr %v0 to i64
  store i64 %t281, ptr %l138, !tbaa !24
  %t282 = load i1, ptr @olang_2esole_2ecompiler_2fcheck_3afactRead_2e6
  br i1 %t282, label %bb60, label %bb61
bb60:
  %t284 = call ptr @__olang_region_make(ptr %v0)
  %t285 = ptrtoint ptr %t284 to i64
  store i64 %t285, ptr %l138, !tbaa !24
  br label %bb61
bb61:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  %t290 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t286, %"compiler/source:Span" %t287)
  store { i64, ptr } %t290, ptr %l142
  br label %bb62
bb62:
  %t291 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = extractvalue { i64, ptr } %t291, 0
  %t294 = load i64, ptr %l138
  %t295 = inttoptr i64 %t294 to ptr
  %t296 = call ptr @__olang_scope_alloc(ptr %t295, i64 %t293)
  call void @olang_textcopy(ptr %t296, ptr %t292, i64 %t293)
  %t297 = insertvalue { i64, ptr } undef, i64 %t293, 0
  %t298 = insertvalue { i64, ptr } %t297, ptr %t296, 1
  %t300 = load i64, ptr %l138
  %t301 = inttoptr i64 %t300 to ptr
  %t302 = extractvalue { i64, ptr } %t298, 0
  %t303 = extractvalue { i64, ptr } %t298, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %t301, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  %t308 = load i64, ptr %l130, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t310 = load i1, ptr %l132, !tbaa !21
  %t311 = load i64, ptr %l136, !tbaa !24
  %t312 = load %"compiler/source:Span", ptr %l137
  %t314 = call %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t308, i64 -1, { i64, ptr } %t309, i1 %t310, i64 %t311, %"compiler/source:Span" %t312, { i64, ptr } %t307)
  store %"compiler/check:factRead" %t314, ptr %l145
  br label %bb63
bb63:
  %t315 = load %"compiler/check:factRead", ptr %l145
  store %"compiler/check:factRead" %t315, ptr %l14
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = getelementptr %"compiler/check:Checker", ptr %t316, i32 0, i32 60
  %t319 = load %"compiler/check:factRead", ptr %l14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t318, %"compiler/check:factRead" %t319)
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l149, !tbaa !29
  %t323 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t323, ptr %l150
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t324, ptr %l151, !tbaa !23
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t328 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v0, ptr %t325, ptr %l14)
  store i1 %t328, ptr %l154
  br label %bb65
bb65:
  %t329 = load i1, ptr %l154, !tbaa !21
  br i1 %t329, label %bb66, label %bb67
bb66:
  store i64 1, ptr %l155, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb68
bb68:
  %t330 = load ptr, ptr %l149, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l150
  %t332 = load i32, ptr %l151, !tbaa !23
  %t333 = load i64, ptr %l155, !tbaa !24
  %t334 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t330, %"compiler/source:Span" %t331, i32 %t332, i64 %t333)
  store ptr %t334, ptr %l156
  br label %bb69
bb69:
  %t335 = load ptr, ptr %l156, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t335, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/check:reflList"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, i64, i64 }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l32 = alloca %"compiler/check:reflList"
  %l39 = alloca ptr
  %l42 = alloca i64
  %l45 = alloca i64
  %l53 = alloca { i64, i64, i64 }
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca i1
  %l91 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca %"compiler/diagmsg:Msg"
  %l99 = alloca i64
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca i32
  %l121 = alloca { i64, ptr }
  %l122 = alloca %"compiler/typed:Seq"
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l142 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l160 = alloca ptr
  %l163 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i32
  %l168 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i32
  %l177 = alloca i64
  %l178 = alloca ptr
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/source:Span"
  %l181 = alloca i32
  %l183 = alloca ptr
  %l185 = alloca { i64, ptr }
  %l188 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t176 = alloca { i64, [3 x i64] }, align 8
  %t193 = alloca { i64, [3 x i64] }, align 8
  %t218 = alloca { i64, [5 x i64] }, align 8
  %t357 = alloca { i64, [5 x i64] }, align 8
  %t369 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %t6, %"compiler/source:Span" %t7, ptr %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:ForIn", ptr %t13, i32 0, i32 2
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t19 = call %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %t12, ptr %t16)
  store %"compiler/check:reflList" %t19, ptr %l32
  br label %bb5
bb5:
  %t20 = load %"compiler/check:reflList", ptr %l32
  store %"compiler/check:reflList" %t20, ptr %l3
  %t21 = getelementptr %"compiler/check:reflList", ptr %l3, i32 0, i32 0
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load %"compiler/check:reflList", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %t24, %"compiler/source:Span" %t25, ptr %t26, %"compiler/check:reflList" %t27)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l39
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l39, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 28
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t38)
  store i64 %t40, ptr %l42
  br label %bb11
bb11:
  %t41 = load i64, ptr %l42, !tbaa !24
  store i64 %t41, ptr %l5, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 37
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l45
  br label %bb12
bb12:
  %t47 = load i64, ptr %l45, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 17
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 16
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load %"compiler/source:Span", ptr %l1
  %t63 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t58, i32 1, %"compiler/source:Span" %t59)
  store { i64, i64, i64 } %t63, ptr %l53
  br label %bb13
bb13:
  %t64 = load { i64, i64, i64 }, ptr %l53
  store { i64, i64, i64 } %t64, ptr %l9
  %t65 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  %t68 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l11, !tbaa !24
  %t71 = getelementptr { i64, i64, i64 }, ptr %l9, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l12, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v0, ptr %s0, ptr %t74, %"compiler/source:Span" %t75, ptr %t76, ptr null, i32 %t77)
  store ptr %t82, ptr %l61
  br label %bb14
bb14:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l12, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v0, ptr %t83, i64 %t84, i64 %t85, i64 %t86, i64 %t87)
  store ptr %t93, ptr %l67
  br label %bb15
bb15:
  %t94 = load ptr, ptr %l67, !tbaa !29
  store ptr %t94, ptr %l13, !tbaa !29
  %t95 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t96 = load i32, ptr %t95, !tbaa !23
  %t97 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = add i32 %t98, 3
  %t103 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t96, i32 %t100)
  store %"compiler/source:Span" %t103, ptr %l71
  br label %bb16
bb16:
  %t104 = load %"compiler/source:Span", ptr %l71
  store %"compiler/source:Span" %t104, ptr %l14
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:ForIn", ptr %t105, i32 0, i32 3
  %t108 = load i1, ptr %t107, !tbaa !21
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb17, label %bb18
bb17:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/check:frame", ptr %t112, i32 0, i32 17
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  store i1 %t119, ptr %l75, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb19
bb19:
  %t121 = load i1, ptr %l75, !tbaa !21
  br i1 %t121, label %bb20, label %bb21
bb20:
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l80, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t123, ptr %l81
  %t124 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0)
  store %"compiler/diagmsg:Msg" %t124, ptr %l82
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t125 = load ptr, ptr %l80, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l81
  %t127 = load %"compiler/diagmsg:Msg", ptr %l82
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t125, %"compiler/source:Span" %t126, %"compiler/diagmsg:Msg" %t127)
  store i64 %t128, ptr %l83
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t131 = getelementptr %"compiler/ast:ForIn", ptr %t129, i32 0, i32 3
  %t132 = load i1, ptr %t131, !tbaa !21
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 17
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = icmp eq i64 %t137, %t138
  store i1 %t141, ptr %l86, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t143 = load i1, ptr %l86, !tbaa !21
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 16
  %t147 = load i64, ptr %t146, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = icmp eq i64 %t147, %t148
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb30
bb30:
  %t153 = load i1, ptr %l91, !tbaa !21
  br i1 %t153, label %bb31, label %bb32
bb31:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l96, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t155, ptr %l97
  %t156 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0)
  store %"compiler/diagmsg:Msg" %t156, ptr %l98
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t157 = load ptr, ptr %l96, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l97
  %t159 = load %"compiler/diagmsg:Msg", ptr %l98
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t157, %"compiler/source:Span" %t158, %"compiler/diagmsg:Msg" %t159)
  store i64 %t160, ptr %l99
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t162 = load i64, ptr %l7, !tbaa !24
  %t165 = getelementptr %"compiler/check:frame", ptr %t161, i32 0, i32 17
  store i64 %t162, ptr %t165, !tbaa !24
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr %"compiler/ast:ForIn", ptr %t166, i32 0, i32 3
  %t169 = load i1, ptr %t168, !tbaa !21
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb36, label %bb37
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  %t175 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 0
  store i64 11, ptr %t177
  %t179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t174, 0
  %t181 = insertvalue { %"compiler/source:Span", ptr } %t179, ptr %t175, 1
  %t182 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t181, ptr %t182
  %t183 = load { i64, [3 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t183, ptr %t185
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t173, ptr %t185)
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 37
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 0
  store i64 11, ptr %t194
  %t196 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t191, 0
  %t198 = insertvalue { %"compiler/source:Span", ptr } %t196, ptr %t192, 1
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t198, ptr %t199
  %t200 = load { i64, [3 x i64] }, ptr %t193
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t200, ptr %t202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t190, ptr %t202)
  br label %bb40
bb40:
  %t205 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t205, ptr %l116
  %t206 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t206, ptr %l117, !tbaa !23
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 37
  %t210 = load i64, ptr %l6, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l121
  br label %bb41
bb41:
  %t214 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t215 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t214, ptr null, i1 false)
  store %"compiler/typed:Seq" %t215, ptr %l122
  br label %bb42
bb42:
  %t216 = load %"compiler/typed:Seq", ptr %l122
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Seq" %t216, ptr %t217
  store { i64, [5 x i64] } zeroinitializer, ptr %t218
  %t219 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 0
  store i64 12, ptr %t219
  %t220 = load %"compiler/source:Span", ptr %l116
  %t221 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t220, 0
  %t222 = load i32, ptr %l117, !tbaa !23
  %t223 = insertvalue { %"compiler/source:Span", i32, ptr } %t221, i32 %t222, 1
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } %t223, ptr %t217, 2
  %t226 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t225, ptr %t226
  %t227 = load { i64, [5 x i64] }, ptr %t218
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t227, ptr %t229
  store ptr %t229, ptr %l15, !tbaa !29
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l126
  br label %bb43
bb43:
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  %t233 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %t233
  store ptr %t233, ptr %l16, !tbaa !29
  %t235 = load ptr, ptr %l4, !tbaa !29
  %t237 = getelementptr %"compiler/check:frame", ptr %t235, i32 0, i32 28
  %t239 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t237)
  store i64 %t239, ptr %l130
  br label %bb44
bb44:
  %t240 = load i64, ptr %l130, !tbaa !24
  store i64 %t240, ptr %l17, !tbaa !24
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/ast:ForIn", ptr %t241, i32 0, i32 5
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t248 = icmp sgt i64 %t246, 0
  br i1 %t248, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s6
  %t250 = load ptr, ptr %l4, !tbaa !29
  %t252 = getelementptr %"compiler/check:frame", ptr %t250, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t252, i64 -2)
  br label %bb47
bb46:
  br label %bb66
bb47:
  %t254 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/check:frame", ptr %t254, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t256, i64 -2)
  br label %bb48
bb48:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i64, ptr %l5, !tbaa !24
  %t260 = load i64, ptr %l17, !tbaa !24
  %t264 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s6, ptr %t258, i64 %t259, i64 %t260)
  store { i64, ptr } %t264, ptr %l142
  br label %bb49
bb49:
  %t265 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t265, ptr %l18, !tbaa !27
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t268 = getelementptr %"compiler/ast:ForIn", ptr %t266, i32 0, i32 5
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  store i64 %t273, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  %t275 = load i64, ptr %l20, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = icmp slt i64 %t275, %t276
  %t281 = xor i1 %t279, true
  br i1 %t281, label %bb51, label %bb52
bb51:
  br label %bb57
bb52:
  br label %bb53
bb53:
  %t283 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t283, ptr %l151, !tbaa !27
  %t284 = load i64, ptr %l20, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr ptr, ptr %t287, i64 %t284
  %t289 = load ptr, ptr %t288, !tbaa !39
  %t291 = load ptr, ptr %l16, !tbaa !29
  store ptr %t291, ptr %l154, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t295 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t296 = load ptr, ptr %l16, !tbaa !29
  %t302 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %s6, ptr %v0, ptr %v0, ptr %t292, ptr %t289, i32 %t294, i1 false, { i64, ptr } %t295, ptr %t296)
  store ptr %t302, ptr %l160
  br label %bb54
bb54:
  %t303 = load ptr, ptr %l154, !tbaa !29
  %t304 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t303, ptr %t304)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t305 = load i64, ptr %l20, !tbaa !24
  %t307 = add i64 %t305, 1
  store i64 %t307, ptr %l20, !tbaa !24
  br label %bb50
bb57:
  %t309 = load ptr, ptr %l4, !tbaa !29
  %t311 = getelementptr %"compiler/check:frame", ptr %t309, i32 0, i32 10
  %t313 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t311)
  %t314 = extractvalue { i32, i64 } %t313, 1
  %t315 = extractvalue { i32, i64 } %t313, 0
  store i32 %t315, ptr %l167
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb59, label %ok.317, !prof !99
ok.317:
  store i64 %t314, ptr %l166
  br label %bb58
bb58:
  %t318 = load i64, ptr %l166, !tbaa !24
  store i64 %t318, ptr %l163, !tbaa !24
  br label %bb61
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t319 = load ptr, ptr %l4, !tbaa !29
  %t321 = getelementptr %"compiler/check:frame", ptr %t319, i32 0, i32 11
  %t323 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t321)
  %t324 = extractvalue { i32, i64 } %t323, 1
  %t325 = extractvalue { i32, i64 } %t323, 0
  store i32 %t325, ptr %l172
  %t326 = icmp ne i32 %t325, 0
  br i1 %t326, label %bb63, label %ok.327, !prof !99
ok.327:
  store i64 %t324, ptr %l171
  br label %bb62
bb62:
  %t328 = load i64, ptr %l171, !tbaa !24
  store i64 %t328, ptr %l168, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i64, ptr %l5, !tbaa !24
  %t331 = load i64, ptr %l17, !tbaa !24
  %t332 = load ptr, ptr %l16, !tbaa !29
  %t337 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t329, i64 %t330, i64 %t331, ptr %t332)
  store i64 %t337, ptr %l177
  br label %bb67
bb67:
  %t338 = load i64, ptr %l177, !tbaa !24
  store i64 %t338, ptr %l23, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l178, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t340, ptr %l179
  %t341 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t341, ptr %l180
  %t342 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t342, ptr %l181, !tbaa !23
  %t343 = load ptr, ptr %l15, !tbaa !29
  store ptr %t343, ptr %l183, !tbaa !29
  %t345 = load ptr, ptr %l16, !tbaa !29
  %t347 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t345)
  store { i64, ptr } %t347, ptr %l185
  br label %bb68
bb68:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = icmp sgt i64 %t348, 0
  %t351 = load ptr, ptr %l183, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t354 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t351, { i64, ptr } %t352, i1 false, i1 false, i1 %t350)
  store %"compiler/typed:Try" %t354, ptr %l188
  br label %bb69
bb69:
  %t355 = load %"compiler/typed:Try", ptr %l188
  %t356 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t355, ptr %t356
  store { i64, [5 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 0
  store i64 14, ptr %t358
  %t359 = load %"compiler/source:Span", ptr %l180
  %t360 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t359, 0
  %t361 = load i32, ptr %l181, !tbaa !23
  %t362 = insertvalue { %"compiler/source:Span", i32, ptr } %t360, i32 %t361, 1
  %t364 = insertvalue { %"compiler/source:Span", i32, ptr } %t362, ptr %t356, 2
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t357, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t364, ptr %t365
  %t366 = load { i64, [5 x i64] }, ptr %t357
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t366, ptr %t368
  store { i64, [3 x i64] } zeroinitializer, ptr %t369
  %t370 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 0
  store i64 2, ptr %t370
  %t371 = load %"compiler/source:Span", ptr %l179
  %t372 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t371, 0
  %t374 = insertvalue { %"compiler/source:Span", ptr } %t372, ptr %t368, 1
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t369, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t374, ptr %t375
  %t376 = load { i64, [3 x i64] }, ptr %t369
  %t378 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t376, ptr %t378
  %t379 = load ptr, ptr %l178, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t379, ptr %t378)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l20 = alloca %"compiler/check:Gap"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t17)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:frame", ptr %t20, i32 0, i32 18
  store i1 true, ptr %t22, !tbaa !21
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 15
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t32 = call %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v1, ptr %v0, i64 %t26, %"compiler/source:Span" %a1, { i64, ptr } %a2)
  store %"compiler/check:Gap" %t32, ptr %l20
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load %"compiler/check:Gap", ptr %l20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v0, ptr %t33, %"compiler/check:Gap" %t34)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/names:Ref"
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l25 = alloca i1
  %l32 = alloca i32
  %l37 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l54 = alloca %"compiler/names:Ref"
  %l57 = alloca i1
  %l64 = alloca i32
  %l69 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l18
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 2
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t35 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t32, i64 %t29, i32 %t31)
  store %"compiler/names:Ref" %t35, ptr %l22
  br label %bb7
bb7:
  %t36 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t36, ptr %l3
  %t37 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 0
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 9}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = getelementptr %"compiler/names:Ref", ptr %l3, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t60 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t52, i64 %t54, i64 %t56)
  store i32 %t60, ptr %l32
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t61 = load i32, ptr %l32, !tbaa !23
  store i32 %t61, ptr %l4, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l37
  br label %bb14
bb14:
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sgt i64 %t72, 0
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = load i32, ptr %l4, !tbaa !23
  store i32 %t75, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  br label %bb43
bb19:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb20, label %bb21
bb20:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 30}
  %t84 = icmp eq i64 %t82, 14
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb21
bb21:
  %t85 = load i1, ptr %l41, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t88, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l5
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l48, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t99)
  store ptr %t101, ptr %l50
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l50, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t111 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t108, i64 %t105, i32 %t107)
  store %"compiler/names:Ref" %t111, ptr %l54
  br label %bb26
bb26:
  %t112 = load %"compiler/names:Ref", ptr %l54
  store %"compiler/names:Ref" %t112, ptr %l6
  %t113 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t114 = load i32, ptr %t113, !range !{i32 0, i32 9}
  %t116 = trunc i64 4 to i32
  %t117 = icmp eq i32 %t114, %t116
  br i1 %t117, label %bb27, label %bb28
bb27:
  %t119 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  store i1 %t122, ptr %l57, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l57, !tbaa !21
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t129 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t132 = load i64, ptr %t131, !tbaa !24
  %t136 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t128, i64 %t130, i64 %t132)
  store i32 %t136, ptr %l64
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t137 = load i32, ptr %l64, !tbaa !23
  store i32 %t137, ptr %l7, !tbaa !23
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l7, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l69
  br label %bb33
bb33:
  %t148 = load i64, ptr %l69, !tbaa !24
  %t149 = icmp sgt i64 %t148, 0
  br i1 %t149, label %bb34, label %bb35
bb34:
  %t151 = load i32, ptr %l7, !tbaa !23
  store i32 %t151, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_369dcc443ccea639_2a432d0faa4fb925)
  unreachable
bb43:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s1, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t36 = icmp eq i32 %t30, %a2
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %rv = alloca ptr
  %t28 = alloca { i64, [1 x i64] }, align 8
  %t45 = alloca { i64, [3 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v2, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb15
bb4:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ab1100555885b989_2cac6a0e3d43e9fd)
  unreachable
bb14:
  br label %bb15
bb15:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l16
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t24)
  store i32 %t27, ptr %l19
  br label %bb16
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l16
  %t33 = load i32, ptr %l19, !tbaa !23
  %t36 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t31, i32 0, %"compiler/source:Span" %t32, i32 %t33, i32 2, { i64, [1 x i64] } %t30)
  store i64 %t36, ptr %l22
  br label %bb17
bb17:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t44 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 0
  store i64 0, ptr %t46
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t39, 0
  %t50 = insertvalue { %"compiler/source:Span", i32, ptr } %t48, i32 %t42, 1
  %t52 = insertvalue { %"compiler/source:Span", i32, ptr } %t50, ptr %t44, 2
  %t53 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t52, ptr %t53
  %t54 = load { i64, [3 x i64] }, ptr %t45
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t54, ptr %t56
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t38, ptr %t56)
  br label %bb18
bb18:
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l31
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t60)
  store i32 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = trunc i64 %t64 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t70 = load %"compiler/source:Span", ptr %l31
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t70, 0
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = insertvalue { %"compiler/source:Span", i32, i32 } %t71, i32 %t72, 1
  %t75 = insertvalue { %"compiler/source:Span", i32, i32 } %t73, i32 %t66, 2
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t75, ptr %t76
  %t77 = load { i64, [4 x i64] }, ptr %t68
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t77, ptr %t79
  store ptr %t79, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l17 = alloca i32
  %l22 = alloca i32
  %l25 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca i1
  %l38 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i32
  %l61 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i64
  %l81 = alloca i64
  %l88 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l131 = alloca i32
  %l132 = alloca i1
  %l135 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca i1
  %l145 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i1
  %l155 = alloca ptr
  %l160 = alloca i32
  %l163 = alloca i1
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 12
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t11, i32 %a1)
  store i32 %t15, ptr %l17
  br label %bb4
bb4:
  %t16 = load i32, ptr %l17, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l22
  br label %bb5
bb5:
  %t27 = load i32, ptr %l22, !range !{i32 0, i32 33}
  store i32 %t27, ptr %l4
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l25, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l30
  br label %bb9
bb9:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = add i64 %t44, 1
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i32, ptr %l30, !tbaa !23
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t47, i32 %t48, i64 %t46)
  store i1 %t50, ptr %l33
  br label %bb10
bb10:
  %t51 = load i1, ptr %l33, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb11:
  %t52 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t54 = trunc i64 22 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t59 = trunc i64 23 to i32
  %t60 = icmp eq i32 %t57, %t59
  br i1 %t60, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l3, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l43
  br label %bb17
bb17:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l43, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t74, i32 %t75, i64 %t73)
  store i1 %t77, ptr %l45
  br label %bb18
bb18:
  %t78 = load i1, ptr %l45, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
bb19:
  %t79 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t81 = trunc i64 18 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95)
  unreachable
bb28:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l53
  br label %bb29
bb29:
  %t95 = load i1, ptr %l53, !tbaa !21
  %t96 = xor i1 %t95, true
  br i1 %t96, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/generic:Program", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %l3, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l60
  br label %bb33
bb33:
  %t109 = load i32, ptr %l60, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l66
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l61, !tbaa !29
  %t122 = load i32, ptr %l66, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t123, ptr %l67
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t124, ptr %l6, !tbaa !27
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l5, !tbaa !23
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t130, i32 %t131)
  store i64 %t134, ptr %l72
  br label %bb36
bb36:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l7, !tbaa !24
  %t138 = icmp sge i64 %t136, 0
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l76, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 0
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/load:Loader", ptr %t147, i32 0, i32 10
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l81
  br label %bb39
bb38:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb40
bb39:
  %t152 = load i64, ptr %l76, !tbaa !24
  %t153 = load i64, ptr %l81, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  store i1 %t154, ptr %l75, !tbaa !21
  br label %bb40
bb40:
  %t156 = load i1, ptr %l75, !tbaa !21
  br i1 %t156, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:Checker", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/generic:Program", ptr %t160, i32 0, i32 0
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 10
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l88
  br label %bb43
bb42:
  br label %bb84
bb43:
  %t170 = load ptr, ptr %l88, !tbaa !29
  %t172 = getelementptr %"compiler/load:Module", ptr %t170, i32 0, i32 2
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l8, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/load:Loader", ptr %t181, i32 0, i32 10
  %t184 = load i64, ptr %l7, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l96
  br label %bb44
bb44:
  %t188 = load ptr, ptr %l96, !tbaa !29
  %t190 = getelementptr %"compiler/load:Module", ptr %t188, i32 0, i32 3
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t193, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t195, ptr %l101
  br label %bb47
bb46:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb56
bb47:
  %t196 = load i1, ptr %l101, !tbaa !21
  br i1 %t196, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb51
bb49:
  %t197 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t199 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t197, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i1 %t199, ptr %l104
  br label %bb50
bb50:
  %t200 = load i1, ptr %l104, !tbaa !21
  store i1 %t200, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t201 = load i1, ptr %l102, !tbaa !21
  br i1 %t201, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb55
bb53:
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t204 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t202, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t204, ptr %l107
  br label %bb54
bb54:
  %t205 = load i1, ptr %l107, !tbaa !21
  store i1 %t205, ptr %l105, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l105, !tbaa !21
  store i1 %t206, ptr %l99, !tbaa !21
  br label %bb56
bb56:
  %t207 = load i1, ptr %l99, !tbaa !21
  br i1 %t207, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t209, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t211, ptr %l110
  br label %bb60
bb60:
  %t212 = load i1, ptr %l110, !tbaa !21
  br i1 %t212, label %bb61, label %bb62
bb61:
  %t213 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t213, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t215, ptr %l113
  br label %bb63
bb62:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb64
bb63:
  %t216 = load i1, ptr %l113, !tbaa !21
  store i1 %t216, ptr %l111, !tbaa !21
  br label %bb64
bb64:
  %t217 = load i1, ptr %l111, !tbaa !21
  br i1 %t217, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb72
bb66:
  %t218 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t218, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t220, ptr %l116
  br label %bb67
bb67:
  %t221 = load i1, ptr %l116, !tbaa !21
  br i1 %t221, label %bb68, label %bb69
bb68:
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t222, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t224, ptr %l119
  br label %bb70
bb69:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb71
bb70:
  %t225 = load i1, ptr %l119, !tbaa !21
  store i1 %t225, ptr %l117, !tbaa !21
  br label %bb71
bb71:
  %t226 = load i1, ptr %l117, !tbaa !21
  store i1 %t226, ptr %l114, !tbaa !21
  br label %bb72
bb72:
  %t227 = load i1, ptr %l114, !tbaa !21
  br i1 %t227, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t231 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s7, { i64, ptr } %t229, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i1 %t231, ptr %l122
  br label %bb76
bb76:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb77, label %bb78
bb77:
  %t233 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t235 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t233, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i1 %t235, ptr %l125
  br label %bb79
bb78:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb80
bb79:
  %t236 = load i1, ptr %l125, !tbaa !21
  store i1 %t236, ptr %l123, !tbaa !21
  br label %bb80
bb80:
  %t237 = load i1, ptr %l123, !tbaa !21
  br i1 %t237, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s7)
  store i1 true, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s7)
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l5, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l131
  br label %bb85
bb85:
  %t249 = load i32, ptr %l131, !range !{i32 0, i32 6}
  store i32 %t249, ptr %l9
  %t250 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t252 = trunc i64 0 to i32
  %t253 = icmp eq i32 %t250, %t252
  br i1 %t253, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l135, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l3, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l140
  br label %bb89
bb89:
  %t266 = load i64, ptr %l2, !tbaa !24
  %t267 = load ptr, ptr %l135, !tbaa !29
  %t268 = load i32, ptr %l140, !tbaa !23
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t267, i32 %t268, i64 %t266)
  store i1 %t270, ptr %l142
  br label %bb90
bb90:
  %t271 = load i1, ptr %l142, !tbaa !21
  store i1 %t271, ptr %l132, !tbaa !21
  br label %bb108
bb91:
  %t272 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t274 = trunc i64 1 to i32
  %t275 = icmp eq i32 %t272, %t274
  br i1 %t275, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb97
bb94:
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l145, !tbaa !29
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l3, !tbaa !23
  %t287 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t283, i32 %t284)
  store i32 %t287, ptr %l150
  br label %bb95
bb95:
  %t288 = load i64, ptr %l2, !tbaa !24
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t290 = load i32, ptr %l150, !tbaa !23
  %t292 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %t289, i32 %t290, i64 %t288)
  store i1 %t292, ptr %l152
  br label %bb96
bb96:
  %t293 = load i1, ptr %l152, !tbaa !21
  store i1 %t293, ptr %l132, !tbaa !21
  br label %bb108
bb97:
  %t294 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t296 = trunc i64 4 to i32
  %t297 = icmp eq i32 %t294, %t296
  br i1 %t297, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb103
bb100:
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l155, !tbaa !29
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l160
  br label %bb101
bb101:
  %t310 = load i64, ptr %l2, !tbaa !24
  %t312 = add i64 %t310, 1
  %t313 = load ptr, ptr %l155, !tbaa !29
  %t314 = load i32, ptr %l160, !tbaa !23
  %t316 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsHandle(ptr %v0, ptr %t313, i32 %t314, i64 %t312)
  store i1 %t316, ptr %l163
  br label %bb102
bb102:
  %t317 = load i1, ptr %l163, !tbaa !21
  store i1 %t317, ptr %l132, !tbaa !21
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4)
  unreachable
bb108:
  %t318 = load i1, ptr %l132, !tbaa !21
  store i1 %t318, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/generic:Context", ptr %t6, i32 0, i32 2
  %t9 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb5
bb4:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 6}
  %t14 = trunc i64 4 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb8
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l11, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLength(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/check:laneNode"
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"compiler/check:laneNode"
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i64
  %l46 = alloca %"compiler/check:laneNode"
  %l50 = alloca i1
  %l53 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l65 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l77 = alloca i64
  %l84 = alloca %"compiler/source:Span"
  %l86 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l92 = alloca { i64, ptr }
  %l100 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca i64
  %s0 = alloca %olang.scope
  %t146 = alloca { i64, [5 x i64] }, align 8
  %t204 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %s0, ptr %t3, i64 %t4, ptr %l4)
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 39
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t10, i64 %t11)
  store %"compiler/check:laneNode" %t14, ptr %l22
  br label %bb3
bb3:
  %t15 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sge i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l27, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l28
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t24)
  store i32 %t26, ptr %l30
  br label %bb6
bb5:
  store ptr null, ptr %l26, !tbaa !29
  br label %bb8
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l28
  %t30 = load i32, ptr %l30, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t28, %"compiler/source:Span" %t29, i32 %t30, i64 %t27)
  store ptr %t32, ptr %l32
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l32, !tbaa !29
  store ptr %t33, ptr %l26, !tbaa !29
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l26, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  store ptr %l4, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l9, !tbaa !24
  store i64 %t37, ptr %l35, !tbaa !24
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t38)
  store i64 %t40, ptr %l37
  br label %bb10
bb10:
  %t41 = load i64, ptr %l35, !tbaa !24
  %t42 = load i64, ptr %l37, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  br label %bb41
bb12:
  br label %bb13
bb13:
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t47, i64 %t48)
  store i64 %t51, ptr %l42
  br label %bb14
bb14:
  %t52 = load i64, ptr %l42, !tbaa !24
  store i64 %t52, ptr %l10, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 39
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store %"compiler/check:laneNode" %t59, ptr %l46
  br label %bb15
bb15:
  %t60 = load %"compiler/check:laneNode", ptr %l46
  store %"compiler/check:laneNode" %t60, ptr %l11
  %t61 = getelementptr %"compiler/check:laneNode", ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t66 = icmp ne i64 %t62, %t63
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb18
bb17:
  %t68 = getelementptr %"compiler/check:laneNode", ptr %l11, i32 0, i32 9
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  store i1 %t71, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l50, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  br label %bb40
bb20:
  br label %bb21
bb21:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:laneVals", ptr %t74, i32 0, i32 1
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t76, i64 %t77)
  %t81 = extractvalue { i32, i64 } %t80, 1
  %t82 = extractvalue { i32, i64 } %t80, 0
  store i32 %t82, ptr %l58
  %t83 = icmp ne i32 %t82, 0
  br i1 %t83, label %bb23, label %ok.84, !prof !99
ok.84:
  store i64 %t81, ptr %l57
  br label %bb22
bb22:
  %t85 = load i64, ptr %l57, !tbaa !24
  store i64 %t85, ptr %l53, !tbaa !24
  br label %bb25
bb23:
  br label %bb24
bb24:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb25
bb25:
  %t86 = load i64, ptr %l53, !tbaa !24
  store i64 %t86, ptr %l12, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t89 = icmp slt i64 %t87, 0
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l61, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l62
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t93)
  store i32 %t95, ptr %l64
  br label %bb29
bb29:
  store i32 22, ptr %l65
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l1
  %t98 = load i64, ptr %l12, !tbaa !24
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t96, %"compiler/source:Span" %t97, i64 %t98)
  store ptr %t102, ptr %l69
  br label %bb30
bb30:
  %t103 = load ptr, ptr %l61, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l62
  %t105 = load i32, ptr %l64, !tbaa !23
  %t106 = load i32, ptr %l65, !range !{i32 0, i32 52}
  %t107 = load ptr, ptr %l69, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t103, %"compiler/source:Span" %t104, i32 %t105, i32 %t106, ptr %t107, ptr null)
  store ptr %t108, ptr %l70
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l70, !tbaa !29
  store ptr %t109, ptr %l13, !tbaa !29
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb32, label %bb33
bb32:
  %t114 = load ptr, ptr %l13, !tbaa !29
  store ptr %t114, ptr %l6, !tbaa !29
  br label %bb39
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 36
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l77
  br label %bb34
bb34:
  %t122 = load i64, ptr %l77, !tbaa !24
  store i64 %t122, ptr %l14, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 36
  %t126 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t125, ptr %t126)
  br label %bb35
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 36
  %t132 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t131, ptr %t132)
  br label %bb36
bb36:
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l84
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t136)
  store i32 %t138, ptr %l86
  br label %bb37
bb37:
  store i32 38, ptr %l87
  store i32 1, ptr %l88
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 36
  %t142 = load i64, ptr %l14, !tbaa !24
  %t145 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t141, i64 %t142)
  store { i64, ptr } %t145, ptr %l92
  br label %bb38
bb38:
  store { i64, [5 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 0
  store i64 9, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l84
  %t149 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t148, 0
  %t150 = load i32, ptr %l86, !tbaa !23
  %t151 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t149, i32 %t150, 1
  %t152 = load i32, ptr %l87, !range !{i32 0, i32 52}
  %t153 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t151, i32 %t152, 2
  %t154 = load i32, ptr %l88, !range !{i32 0, i32 3}
  %t155 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t153, i32 %t154, 3
  %t156 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t157 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t155, { i64, ptr } %t156, 4
  %t158 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t157, ptr %t158
  %t159 = load { i64, [5 x i64] }, ptr %t146
  %t161 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t159, ptr %t161
  store ptr %t161, ptr %l6, !tbaa !29
  store i1 true, ptr %l7, !tbaa !21
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t163 = load i64, ptr %l9, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l9, !tbaa !24
  br label %bb9
bb41:
  %t167 = load ptr, ptr %l6, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb42, label %bb43
bb42:
  %t173 = load i64, ptr %l5, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb47
bb44:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb46
bb45:
  %t177 = load i1, ptr %l7, !tbaa !21
  store i1 %t177, ptr %l103, !tbaa !21
  br label %bb46
bb46:
  %t179 = load i1, ptr %l103, !tbaa !21
  store i1 %t179, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t180 = load i1, ptr %l100, !tbaa !21
  br i1 %t180, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %l3, !tbaa !29
  store ptr %t181, ptr %l105, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l106, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t183, ptr %l107
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t184)
  store i32 %t186, ptr %l109
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t187 = load ptr, ptr %l106, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l107
  %t189 = load i32, ptr %l109, !tbaa !23
  %t190 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t187, %"compiler/source:Span" %t188, i32 %t189)
  store i64 %t190, ptr %l110
  br label %bb51
bb51:
  %t191 = load i64, ptr %l110, !tbaa !24
  %t192 = load ptr, ptr %l105, !tbaa !29
  %t193 = getelementptr %"compiler/check:laneVals", ptr %t192, i32 0, i32 0
  store i64 %t191, ptr %t193, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t196 = load ptr, ptr %l3, !tbaa !29
  %t198 = getelementptr %"compiler/check:laneVals", ptr %t196, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = trunc i64 %t199 to i32
  %t203 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t195, 0
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, i32 %t201, 1
  %t211 = insertvalue { %"compiler/source:Span", i32, ptr } %t209, ptr %t203, 2
  %t212 = getelementptr { i64, [3 x i64] }, ptr %t204, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t211, ptr %t212
  %t213 = load { i64, [3 x i64] }, ptr %t204
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t213, ptr %t215
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t194, ptr %t215)
  br label %bb52
bb52:
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 15
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i32 %t30, ptr %l24
  br label %bb12
bb12:
  %t31 = load i32, ptr %l24, !tbaa !23
  %t32 = icmp sge i32 %t31, 0
  store i1 %t32, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 30}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l34
  br label %bb19
bb19:
  %t54 = load i1, ptr %l34, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 8
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t72, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l45
  br label %bb26
bb26:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store i1 %t86, ptr %l49
  br label %bb29
bb28:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb30
bb29:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 30}
  %t96 = icmp eq i64 %t94, 23
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb38, label %bb39
bb38:
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l64, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  store ptr %t127, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 5
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_ddeebe9155436d6a_19ee353760b572b6)
  unreachable
bb44:
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l71, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t148, ptr %t147)
  store i1 %t150, ptr %l77
  br label %bb46
bb46:
  %t151 = load i1, ptr %l77, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb37
bb52:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Match", ptr %t160, i32 0, i32 3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp sgt i64 %t165, 0
  store i1 %t167, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_7406e676cee1d8f8_b07044052169e244)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalNote(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l6 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l14 = alloca %"compiler/typed:Local"
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i64
  %l41 = alloca { i64, [3 x i64] }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca { i64, [3 x i64] }
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca ptr
  %l89 = alloca i64
  %l92 = alloca { i64, [3 x i64] }
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l10
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 7
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t10, i64 %t11)
  store %"compiler/typed:Local" %t14, ptr %l14
  br label %bb5
bb5:
  %t15 = load %"compiler/typed:Local", ptr %l14
  store %"compiler/typed:Local" %t15, ptr %l4
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l16
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l16, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 %t23)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, ptr %l20
  br label %bb7
bb7:
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, ptr %l5
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t34 = call { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31)
  %t35 = extractvalue { i32, %"compiler/source:Span" } %t34, 1
  %t36 = extractvalue { i32, %"compiler/source:Span" } %t34, 0
  store i32 %t36, ptr %l26
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb9, label %ok.38, !prof !99
ok.38:
  store %"compiler/source:Span" %t35, ptr %l25
  br label %bb8
bb8:
  %t39 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t39, ptr %l21
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t40 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t40, ptr %l27
  br label %bb11
bb11:
  %t41 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t41, ptr %l21
  br label %bb12
bb12:
  %t42 = load %"compiler/source:Span", ptr %l21
  store %"compiler/source:Span" %t42, ptr %l6
  %t43 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 0
  %t44 = load i32, ptr %t43, !tbaa !23
  %t46 = icmp sge i32 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t54 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51)
  store i1 %t54, ptr %l33
  br label %bb15
bb14:
  br label %bb34
bb15:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l37, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l6
  %t71 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t67, %"compiler/source:Span" %t68)
  store { i64, [3 x i64] } %t71, ptr %l41
  br label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l61, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l62, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l6
  %t87 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t83, %"compiler/source:Span" %t84)
  store { i64, [3 x i64] } %t87, ptr %l65
  br label %bb25
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t88, i32 %t90)
  store { i64, ptr } %t93, ptr %l44
  br label %bb19
bb19:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t94, i32 %t96)
  store { i64, ptr } %t99, ptr %l47
  br label %bb20
bb20:
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l48, !tbaa !27
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l3, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l51
  br label %bb21
bb21:
  %t112 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l52, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l3, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l55
  br label %bb22
bb22:
  %t124 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t135 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t131, { i64, ptr } %t132, { i64, ptr } %t133, { i64, ptr } %t130)
  store %"compiler/diagmsg:Msg" %t135, ptr %l57
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l37, !tbaa !29
  %t137 = load i64, ptr %l38, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l41
  %t139 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138, %"compiler/diagmsg:Msg" %t139)
  br label %bb24
bb24:
  br label %bb33
bb25:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t142 = load i32, ptr %t141, !tbaa !23
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t140, i32 %t142)
  store { i64, ptr } %t145, ptr %l68
  br label %bb26
bb26:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t148 = load i32, ptr %t147, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t146, i32 %t148)
  store { i64, ptr } %t151, ptr %l71
  br label %bb27
bb27:
  %t152 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l72, !tbaa !27
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t159, i32 %t160)
  store { i64, ptr } %t163, ptr %l75
  br label %bb28
bb28:
  %t164 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l76, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l6
  %t175 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store { i64, ptr } %t175, ptr %l79
  br label %bb29
bb29:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l3, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l82
  br label %bb30
bb30:
  %t181 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t188 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t193 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t188, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t191, { i64, ptr } %t187)
  store %"compiler/diagmsg:Msg" %t193, ptr %l84
  br label %bb31
bb31:
  %t194 = load ptr, ptr %l61, !tbaa !29
  %t195 = load i64, ptr %l62, !tbaa !24
  %t196 = load { i64, [3 x i64] }, ptr %l65
  %t197 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t194, i64 %t195, { i64, [3 x i64] } %t196, %"compiler/diagmsg:Msg" %t197)
  br label %bb32
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 0
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = getelementptr %"compiler/load:Loader", ptr %t204, i32 0, i32 4
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l88, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  store i64 %t208, ptr %l89, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t211 = load %"compiler/source:Span", ptr %t210
  %t214 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t209, %"compiler/source:Span" %t211)
  store { i64, [3 x i64] } %t214, ptr %l92
  br label %bb35
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t220 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t215, i32 %t217)
  store { i64, ptr } %t220, ptr %l95
  br label %bb36
bb36:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t223 = load i32, ptr %t222, !tbaa !23
  %t226 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t221, i32 %t223)
  store { i64, ptr } %t226, ptr %l98
  br label %bb37
bb37:
  %t227 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l102
  br label %bb38
bb38:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l105
  br label %bb39
bb39:
  %t245 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t252 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t256 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t254, { i64, ptr } %t251)
  store %"compiler/diagmsg:Msg" %t256, ptr %l107
  br label %bb40
bb40:
  %t257 = load ptr, ptr %l88, !tbaa !29
  %t258 = load i64, ptr %l89, !tbaa !24
  %t259 = load { i64, [3 x i64] }, ptr %l92
  %t260 = load %"compiler/diagmsg:Msg", ptr %l107
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t257, i64 %t258, { i64, [3 x i64] } %t259, %"compiler/diagmsg:Msg" %t260)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l39 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l52 = alloca i32
  %l60 = alloca i1
  %l61 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l79 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i32
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i32
  %l108 = alloca i32
  %l109 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp eq i32 %t7, %t8
  store i1 %t11, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb7
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l1, !tbaa !23
  %t21 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t19, i32 %t20, i32 %t21)
  store i1 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l10, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t31 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t29, i32 %t30, i32 %t31)
  store i1 %t35, ptr %l21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb15
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t39 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t43, ptr %l26
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb15
bb15:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l1, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t47, i32 %t48)
  store i1 %t51, ptr %l30
  br label %bb19
bb19:
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb20, label %bb21
bb20:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l2, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l34
  br label %bb22
bb21:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb23
bb22:
  %t58 = load i1, ptr %l34, !tbaa !21
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb24, label %bb25
bb24:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t63, i32 %t64, i32 %t65)
  store i32 %t69, ptr %l39
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t70 = load i32, ptr %l39, !tbaa !23
  %t71 = icmp sge i32 %t70, 0
  store i1 %t71, ptr %rv
  br label %ret
bb27:
  %t73 = load i32, ptr %l1, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l46
  br label %bb30
bb29:
  br label %bb35
bb30:
  %t84 = load i1, ptr %l46, !tbaa !21
  br i1 %t84, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb34
bb32:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l52
  br label %bb33
bb33:
  %t95 = load i32, ptr %l52, !range !{i32 0, i32 33}
  %t97 = trunc i64 21 to i32
  %t98 = icmp eq i32 %t95, %t97
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb34
bb34:
  %t100 = load i1, ptr %l47, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
bb35:
  %t101 = load i32, ptr %l2, !tbaa !23
  %t102 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t105 = icmp eq i32 %t101, %t102
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l60
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t112 = load i1, ptr %l60, !tbaa !21
  br i1 %t112, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb42
bb40:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l1, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l66
  br label %bb41
bb41:
  %t123 = load i32, ptr %l66, !range !{i32 0, i32 33}
  %t125 = trunc i64 21 to i32
  %t126 = icmp eq i32 %t123, %t125
  store i1 %t126, ptr %l61, !tbaa !21
  br label %bb42
bb42:
  %t128 = load i1, ptr %l61, !tbaa !21
  store i1 %t128, ptr %rv
  br label %ret
bb43:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l1, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l71
  br label %bb44
bb44:
  %t134 = load i1, ptr %l71, !tbaa !21
  br i1 %t134, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb48
bb46:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t135, i32 %t136)
  store i1 %t139, ptr %l75
  br label %bb47
bb47:
  %t140 = load i1, ptr %l75, !tbaa !21
  store i1 %t140, ptr %l72, !tbaa !21
  br label %bb48
bb48:
  %t141 = load i1, ptr %l72, !tbaa !21
  br i1 %t141, label %bb49, label %bb50
bb49:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l76, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l1, !tbaa !23
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l79
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l82
  br label %bb52
bb52:
  %t153 = load ptr, ptr %l76, !tbaa !29
  %t154 = load i32, ptr %l79, !tbaa !23
  %t155 = load i32, ptr %l82, !tbaa !23
  %t156 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t153, i32 %t154, i32 %t155)
  store i1 %t156, ptr %l83
  br label %bb53
bb53:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb54, label %bb55
bb54:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l1, !tbaa !23
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t158, i32 %t159)
  store i1 %t162, ptr %l87
  br label %bb56
bb55:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb70
bb56:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t163, i32 %t164)
  store i1 %t167, ptr %l90
  br label %bb57
bb57:
  %t168 = load i1, ptr %l87, !tbaa !21
  %t169 = load i1, ptr %l90, !tbaa !21
  %t170 = icmp eq i1 %t168, %t169
  br i1 %t170, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb63
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l93, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l1, !tbaa !23
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l96
  br label %bb60
bb60:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l2, !tbaa !23
  %t182 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l99
  br label %bb61
bb61:
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = load i32, ptr %l96, !tbaa !23
  %t185 = load i32, ptr %l99, !tbaa !23
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t183, i32 %t184, i32 %t185)
  store i1 %t186, ptr %l100
  br label %bb62
bb62:
  %t187 = load i1, ptr %l100, !tbaa !21
  store i1 %t187, ptr %l92, !tbaa !21
  br label %bb63
bb63:
  %t188 = load i1, ptr %l92, !tbaa !21
  br i1 %t188, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb69
bb65:
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l102, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i32, ptr %l2, !tbaa !23
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l105
  br label %bb66
bb66:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t199, ptr %l108
  br label %bb67
bb67:
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i32, ptr %l105, !tbaa !23
  %t202 = load i32, ptr %l108, !tbaa !23
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t200, i32 %t201, i32 %t202)
  store i1 %t203, ptr %l109
  br label %bb68
bb68:
  %t204 = load i1, ptr %l109, !tbaa !21
  store i1 %t204, ptr %l101, !tbaa !21
  br label %bb69
bb69:
  %t205 = load i1, ptr %l101, !tbaa !21
  store i1 %t205, ptr %l84, !tbaa !21
  br label %bb70
bb70:
  %t206 = load i1, ptr %l84, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb71:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i64
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i32, ptr %t26, i64 %t23
  %t28 = load i32, ptr %t27, !tbaa !33
  store i32 %t28, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb9
bb9:
  %t47 = load i32, ptr %l27, !range !{i32 0, i32 33}
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l38
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i32, ptr %l38, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t70, ptr %l39
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l5, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i32, ptr %l47, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l48
  br label %bb15
bb15:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load i64, ptr %l39, !tbaa !24
  %t94 = icmp ne i64 %t92, %t91
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb2
bb21:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l15 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i64
  %l30 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca i1
  %l69 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l92 = alloca i32
  %l94 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %l109 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i32, ptr %l15, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t26 = trunc i64 25 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l25
  br label %bb13
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp eq i64 %t44, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l20, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb19
bb19:
  %t65 = load i64, ptr %l2, !tbaa !24
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load i32, ptr %l35, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t66, i32 %t67, i64 %t65)
  store i1 %t69, ptr %l37
  br label %bb20
bb20:
  %t70 = load i1, ptr %l37, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t73 = trunc i64 19 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l40, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb25
bb25:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load i32, ptr %l45, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t88, i32 %t89, i64 %t87)
  store i1 %t91, ptr %l47
  br label %bb26
bb26:
  %t92 = load i1, ptr %l47, !tbaa !21
  br i1 %t92, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb31
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l49, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t103, ptr %l54
  br label %bb29
bb29:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t106 = load i32, ptr %l54, !tbaa !23
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t105, i32 %t106, i64 %t104)
  store i1 %t108, ptr %l56
  br label %bb30
bb30:
  %t109 = load i1, ptr %l56, !tbaa !21
  store i1 %t109, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l48, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb32:
  %t111 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t113 = trunc i64 20 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l59, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l64
  br label %bb36
bb36:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load i32, ptr %l64, !tbaa !23
  %t131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t128, i32 %t129, i64 %t127)
  store i1 %t131, ptr %l66
  br label %bb37
bb37:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
bb38:
  %t133 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t135 = trunc i64 21 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb54
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l1, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l74
  br label %bb42
bb42:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l69, !tbaa !29
  %t151 = load i32, ptr %l74, !tbaa !23
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t150, i32 %t151, i64 %t149)
  store i1 %t153, ptr %l76
  br label %bb43
bb43:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb48
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l78, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = load i32, ptr %l1, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l83
  br label %bb46
bb46:
  %t166 = load i64, ptr %l2, !tbaa !24
  %t167 = load ptr, ptr %l78, !tbaa !29
  %t168 = load i32, ptr %l83, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t167, i32 %t168, i64 %t166)
  store i1 %t170, ptr %l85
  br label %bb47
bb47:
  %t171 = load i1, ptr %l85, !tbaa !21
  store i1 %t171, ptr %l77, !tbaa !21
  br label %bb48
bb48:
  %t172 = load i1, ptr %l77, !tbaa !21
  br i1 %t172, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb53
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l87, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l1, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t179, i32 %t180)
  store i32 %t183, ptr %l92
  br label %bb51
bb51:
  %t184 = load i64, ptr %l2, !tbaa !24
  %t185 = load ptr, ptr %l87, !tbaa !29
  %t186 = load i32, ptr %l92, !tbaa !23
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t185, i32 %t186, i64 %t184)
  store i1 %t188, ptr %l94
  br label %bb52
bb52:
  %t189 = load i1, ptr %l94, !tbaa !21
  store i1 %t189, ptr %l86, !tbaa !21
  br label %bb53
bb53:
  %t190 = load i1, ptr %l86, !tbaa !21
  store i1 %t190, ptr %rv
  br label %ret
bb54:
  %t191 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t193 = trunc i64 22 to i32
  %t194 = icmp eq i32 %t191, %t193
  br i1 %t194, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  %t196 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t198 = trunc i64 23 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l99, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  %t208 = load i32, ptr %l1, !tbaa !23
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t211, ptr %l104
  br label %bb60
bb60:
  %t212 = load i64, ptr %l2, !tbaa !24
  %t213 = load ptr, ptr %l99, !tbaa !29
  %t214 = load i32, ptr %l104, !tbaa !23
  %t216 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t213, i32 %t214, i64 %t212)
  store i1 %t216, ptr %l106
  br label %bb61
bb61:
  %t217 = load i1, ptr %l106, !tbaa !21
  store i1 %t217, ptr %rv
  br label %ret
bb62:
  %t218 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t220 = trunc i64 29 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l109, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = load i32, ptr %l1, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l114
  br label %bb66
bb66:
  %t234 = load i64, ptr %l2, !tbaa !24
  %t235 = load ptr, ptr %l109, !tbaa !29
  %t236 = load i32, ptr %l114, !tbaa !23
  %t238 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t235, i32 %t236, i64 %t234)
  store i1 %t238, ptr %l116
  br label %bb67
bb67:
  %t239 = load i1, ptr %l116, !tbaa !21
  store i1 %t239, ptr %rv
  br label %ret
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store i1 false, ptr %rv
  br label %ret
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d8c36506bebb6839_82dbce7e68d1cca5)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %lp8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %lp36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l66 = alloca i64
  %l69 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l125 = alloca { i64, ptr }
  %l134 = alloca i32
  %l135 = alloca i32
  %l138 = alloca { i64, ptr }
  %l142 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/diagmsg:Msg"
  %l162 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"compiler/source:Span"
  %l171 = alloca %"compiler/diagmsg:Msg"
  %l174 = alloca { i64, ptr }
  %l176 = alloca %"compiler/diagmsg:Msg"
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"compiler/diagmsg:Msg"
  %l182 = alloca i64
  %l190 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l193 = alloca %"compiler/diagmsg:Msg"
  %l194 = alloca i64
  %l210 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l214 = alloca %"compiler/source:Span"
  %l215 = alloca i64
  %l218 = alloca { i64, ptr }
  %l220 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca i64
  %l229 = alloca i64
  %l232 = alloca i64
  %l257 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l265 = alloca i64
  %l268 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l293 = alloca %"compiler/source:Span"
  %l305 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t38 = alloca i64
  %t582 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @compiler_2fcheck_2ehasNamed(ptr %v2, { i64, ptr } %t1)
  store i1 %t3, ptr %l45
  br label %bb1
bb1:
  %t4 = load i1, ptr %l45, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l50, !tbaa !24
  %t14 = load i64, ptr %l50, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l50, !tbaa !24
  %t18 = icmp sle i64 %t17, 1152921504606846975
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb7:
  %t20 = load i64, ptr %l50, !tbaa !24
  %t21 = mul i64 %t20, 8
  %t22 = call ptr @__olang_scope_alloc_zeroed(ptr %v4, i64 %t21)
  %t23 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t25, ptr %lp8
  %t27 = load ptr, ptr %lp8
  store { i64, ptr } %t24, ptr %t27, !tbaa !27
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l54, !tbaa !24
  %t29 = load i64, ptr %l54, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_2a22705e3675cc6a_15625908cbc104fe)
  unreachable
bb9:
  %t32 = load i64, ptr %l54, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb11:
  %t35 = load i64, ptr %l54, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, %t35
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i64, ptr %t37, i64 %t42
  store i64 -1, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t37, 1
  store { i64, ptr } %t47, ptr %l9, !tbaa !27
  %t49 = load i64, ptr %l4, !tbaa !24
  store i64 %t49, ptr %l58, !tbaa !24
  %t50 = load i64, ptr %l58, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33)
  unreachable
bb13:
  %t53 = load i64, ptr %l58, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210)
  unreachable
bb15:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb20
bb17:
  %t73 = load i64, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l13, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l69, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l69, !tbaa !24
  store i64 %t89, ptr %l66, !tbaa !24
  br label %bb20
bb20:
  %t90 = load i64, ptr %l66, !tbaa !24
  store i64 %t90, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb21
bb21:
  %t91 = load i64, ptr %l15, !tbaa !24
  %t92 = load i64, ptr %l14, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb22, label %bb23
bb22:
  br label %bb84
bb23:
  br label %bb24
bb24:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l15, !tbaa !24
  %t101 = load i64, ptr %l13, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l16, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t109, ptr %l87, !tbaa !27
  %t110 = load i64, ptr %l16, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr ptr, ptr %t113, i64 %t110
  %t115 = load ptr, ptr %t114, !tbaa !39
  store ptr %t115, ptr %l17, !tbaa !29
  %t117 = load ptr, ptr %l17, !tbaa !29
  store ptr %t117, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t118 = load ptr, ptr %l90, !tbaa !29
  %t119 = icmp ne ptr %t118, null
  br i1 %t119, label %bb25, label %bb26
bb25:
  %t121 = load ptr, ptr %l90, !tbaa !29
  %t122 = load i64, ptr %t121, !range !{i64 0, i64 30}
  %t124 = icmp eq i64 %t122, 26
  store i1 %t124, ptr %l91, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l91, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t126 = load ptr, ptr %l17, !tbaa !29
  %t128 = getelementptr { i64, [4 x i64] }, ptr %t126, i32 0, i32 1
  %t129 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t128, i32 0, i32 0
  %t130 = load %"compiler/source:Span", ptr %t129
  store %"compiler/source:Span" %t130, ptr %l18
  %t132 = load ptr, ptr %l17, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t134, i32 0, i32 1
  %t136 = load i32, ptr %t135
  store i32 %t136, ptr %l19, !tbaa !23
  %t138 = load ptr, ptr %l17, !tbaa !29
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t140, i32 0, i32 2
  %t142 = load ptr, ptr %t141
  store ptr %t142, ptr %l20, !tbaa !29
  br label %bb29
bb28:
  br label %bb68
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 true, ptr %l6, !tbaa !21
  store i64 -1, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  %t144 = load i64, ptr %l4, !tbaa !24
  store i64 %t144, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t146 = load i64, ptr %l23, !tbaa !24
  %t147 = load i64, ptr %l22, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb30, label %bb31
bb30:
  %t152 = load i64, ptr %l24, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb35
bb32:
  %t156 = load i64, ptr %l23, !tbaa !24
  %t157 = load i64, ptr %l22, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l24, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l24, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l107, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb34
bb34:
  %t172 = load i64, ptr %l107, !tbaa !24
  store i64 %t172, ptr %l104, !tbaa !24
  br label %bb35
bb35:
  %t173 = load i64, ptr %l104, !tbaa !24
  store i64 %t173, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb36
bb36:
  %t174 = load i64, ptr %l26, !tbaa !24
  %t175 = load i64, ptr %l25, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb37, label %bb38
bb37:
  br label %bb44
bb38:
  br label %bb39
bb39:
  %t182 = load i64, ptr %l22, !tbaa !24
  %t183 = load i64, ptr %l26, !tbaa !24
  %t184 = load i64, ptr %l24, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l27, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t192, ptr %l125, !tbaa !27
  %t193 = load i64, ptr %l27, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr ptr, ptr %t196, i64 %t193
  %t198 = load ptr, ptr %t197, !tbaa !39
  %t200 = getelementptr %"compiler/ast:Param", ptr %t198, i32 0, i32 1
  %t201 = load i32, ptr %t200, !tbaa !23
  %t202 = load i32, ptr %l19, !tbaa !23
  %t205 = icmp eq i32 %t201, %t202
  br i1 %t205, label %bb40, label %bb41
bb40:
  %t207 = load i64, ptr %l27, !tbaa !24
  store i64 %t207, ptr %l21, !tbaa !24
  br label %bb42
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t209 = load i64, ptr %l26, !tbaa !24
  %t211 = add i64 %t209, 1
  store i64 %t211, ptr %l26, !tbaa !24
  br label %bb36
bb44:
  %t213 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  store i32 %t214, ptr %l134, !tbaa !23
  %t215 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  store i32 %t216, ptr %l135, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i32, ptr %l19, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t217, i32 %t218)
  store { i64, ptr } %t221, ptr %l138
  br label %bb45
bb45:
  %t222 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t225 = trunc i64 %t223 to i32
  %t226 = load i32, ptr %l135, !tbaa !23
  %t228 = add i32 %t226, %t225
  %t229 = load i32, ptr %l134, !tbaa !23
  %t231 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t229, i32 %t228)
  store %"compiler/source:Span" %t231, ptr %l142
  br label %bb46
bb46:
  %t232 = load %"compiler/source:Span", ptr %l142
  store %"compiler/source:Span" %t232, ptr %l28
  %t233 = load i64, ptr %l21, !tbaa !24
  %t235 = icmp slt i64 %t233, 0
  br i1 %t235, label %bb47, label %bb48
bb47:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l28
  %t239 = load i32, ptr %l19, !tbaa !23
  %t240 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v3, ptr %t237, %"compiler/source:Span" %t238, i32 %t239, { i64, ptr } %t240, { i64, ptr } %a3)
  br label %bb49
bb48:
  %t247 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t247, ptr %l150, !tbaa !27
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  %t255 = getelementptr %"compiler/ast:Param", ptr %t253, i32 0, i32 3
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = icmp eq ptr %t256, null
  br i1 %t258, label %bb50, label %bb51
bb49:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb67
bb50:
  %t260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t260, ptr %l155, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t261, ptr %l156
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i32, ptr %l19, !tbaa !23
  %t266 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v0, ptr %t262, i32 %t263)
  store { i64, ptr } %t266, ptr %l159
  br label %bb52
bb51:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t268 = load ptr, ptr %lp8
  %t270 = getelementptr { i64, ptr }, ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr ptr, ptr %t271, i64 %t267
  %t273 = load ptr, ptr %t272, !tbaa !39
  %t275 = icmp eq ptr %t273, null
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb55, label %bb56
bb52:
  %t279 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 0
  %t281 = extractvalue { i64, ptr } %t279, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v0, { i64, ptr } %t285)
  store %"compiler/diagmsg:Msg" %t287, ptr %l161
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l155, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l156
  %t290 = load %"compiler/diagmsg:Msg", ptr %l161
  %t291 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t288, %"compiler/source:Span" %t289, %"compiler/diagmsg:Msg" %t290)
  store i64 %t291, ptr %l162
  br label %bb54
bb54:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb66
bb55:
  %t292 = load ptr, ptr %l0, !tbaa !29
  store ptr %t292, ptr %l167, !tbaa !29
  %t293 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t293, ptr %l168
  %t294 = load i64, ptr %l21, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i1, ptr %t297, i64 %t294
  %t299 = load i1, ptr %t298, !tbaa !31
  br i1 %t299, label %bb57, label %bb58
bb56:
  %t301 = load i64, ptr %l21, !tbaa !24
  %t302 = load ptr, ptr %l20, !tbaa !29
  %t305 = load ptr, ptr %lp8
  %t307 = getelementptr { i64, ptr }, ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t301
  store ptr %t302, ptr %t309, !tbaa !39
  %t310 = load i64, ptr %l21, !tbaa !24
  %t311 = load i64, ptr %l16, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i64, ptr %t315, i64 %t310
  store i64 %t311, ptr %t316, !tbaa !34
  %t317 = load i64, ptr %l21, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr i1, ptr %t320, i64 %t317
  store i1 true, ptr %t321, !tbaa !31
  br label %bb65
bb57:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l19, !tbaa !23
  %t326 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v0, ptr %t322, i32 %t323)
  store { i64, ptr } %t326, ptr %l174
  br label %bb59
bb58:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i32, ptr %l19, !tbaa !23
  %t331 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v0, ptr %t327, i32 %t328)
  store { i64, ptr } %t331, ptr %l179
  br label %bb61
bb59:
  %t332 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t333 = extractvalue { i64, ptr } %t332, 0
  %t334 = extractvalue { i64, ptr } %t332, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  %t340 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %v0, ptr %v0, { i64, ptr } %t338)
  store %"compiler/diagmsg:Msg" %t340, ptr %l176
  br label %bb60
bb60:
  %t341 = load %"compiler/diagmsg:Msg", ptr %l176
  store %"compiler/diagmsg:Msg" %t341, ptr %l171
  br label %bb63
bb61:
  %t342 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t343 = extractvalue { i64, ptr } %t342, 0
  %t344 = extractvalue { i64, ptr } %t342, 1
  %t345 = mul i64 %t343, 1
  %t346 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t345)
  call void @llvm.memcpy.p0.p0.i64(ptr %t346, ptr %t344, i64 %t345, i1 false)
  %t347 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t348 = insertvalue { i64, ptr } %t347, ptr %t346, 1
  %t350 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v0, { i64, ptr } %t348)
  store %"compiler/diagmsg:Msg" %t350, ptr %l181
  br label %bb62
bb62:
  %t351 = load %"compiler/diagmsg:Msg", ptr %l181
  store %"compiler/diagmsg:Msg" %t351, ptr %l171
  br label %bb63
bb63:
  %t352 = load ptr, ptr %l167, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l168
  %t354 = load %"compiler/diagmsg:Msg", ptr %l171
  %t355 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t352, %"compiler/source:Span" %t353, %"compiler/diagmsg:Msg" %t354)
  store i64 %t355, ptr %l182
  br label %bb64
bb64:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s4)
  br label %bb82
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t356 = load i1, ptr %l6, !tbaa !21
  br i1 %t356, label %bb72, label %bb73
bb72:
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l190, !tbaa !29
  %t359 = load ptr, ptr %l17, !tbaa !29
  %t361 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t359)
  store %"compiler/source:Span" %t361, ptr %l192
  br label %bb74
bb73:
  %t362 = load i64, ptr %l5, !tbaa !24
  %t363 = load i64, ptr %l4, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  br i1 %t366, label %bb77, label %bb78
bb74:
  %t368 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
  store %"compiler/diagmsg:Msg" %t368, ptr %l193
  br label %bb75
bb75:
  %t369 = load ptr, ptr %l190, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l192
  %t371 = load %"compiler/diagmsg:Msg", ptr %l193
  %t372 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t369, %"compiler/source:Span" %t370, %"compiler/diagmsg:Msg" %t371)
  store i64 %t372, ptr %l194
  br label %bb76
bb76:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb80
bb77:
  %t373 = load i64, ptr %l5, !tbaa !24
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t377 = load ptr, ptr %lp8
  %t379 = getelementptr { i64, ptr }, ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr ptr, ptr %t380, i64 %t373
  store ptr %t374, ptr %t381, !tbaa !39
  %t382 = load i64, ptr %l5, !tbaa !24
  %t383 = load i64, ptr %l16, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr i64, ptr %t387, i64 %t382
  store i64 %t383, ptr %t388, !tbaa !34
  br label %bb79
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t389 = load i64, ptr %l5, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l5, !tbaa !24
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e)
  unreachable
bb82:
  br label %bb83
bb83:
  %t393 = load i64, ptr %l15, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l15, !tbaa !24
  br label %bb21
bb84:
  %t397 = load i64, ptr %l5, !tbaa !24
  %t398 = load i64, ptr %l4, !tbaa !24
  %t401 = icmp sgt i64 %t397, %t398
  br i1 %t401, label %bb85, label %bb86
bb85:
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l210, !tbaa !29
  %t404 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t404, ptr %l211, !tbaa !27
  %t405 = load i64, ptr %l4, !tbaa !24
  %t407 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !27
  %t409 = getelementptr ptr, ptr %t408, i64 %t405
  %t410 = load ptr, ptr %t409, !tbaa !39
  %t412 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t410)
  store %"compiler/source:Span" %t412, ptr %l214
  br label %bb87
bb86:
  br label %bb93
bb87:
  %t413 = load i64, ptr %l4, !tbaa !24
  store i64 %t413, ptr %l215, !tbaa !24
  %t414 = load i64, ptr %l4, !tbaa !24
  %t416 = icmp eq i64 %t414, 1
  br i1 %t416, label %bb88, label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l218, !tbaa !27
  br label %bb90
bb89:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l218, !tbaa !27
  br label %bb90
bb90:
  %t418 = load i64, ptr %l5, !tbaa !24
  %t419 = load i64, ptr %l215, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t422 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 %t419, { i64, ptr } %t420, i64 %t418)
  store %"compiler/diagmsg:Msg" %t422, ptr %l220
  br label %bb91
bb91:
  %t423 = load ptr, ptr %l210, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l214
  %t425 = load %"compiler/diagmsg:Msg", ptr %l220
  %t426 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t423, %"compiler/source:Span" %t424, %"compiler/diagmsg:Msg" %t425)
  store i64 %t426, ptr %l221
  br label %bb92
bb92:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb93
bb93:
  %t427 = load i1, ptr %l7, !tbaa !21
  br i1 %t427, label %bb94, label %bb95
bb94:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t431 = getelementptr %"compiler/check:Checker", ptr %t429, i32 0, i32 153
  store i1 true, ptr %t431, !tbaa !21
  %t432 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t432, ptr %rv
  br label %ret
bb95:
  br label %bb96
bb96:
  store i64 -1, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t434 = load i64, ptr %l4, !tbaa !24
  store i64 %t434, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t436 = load i64, ptr %l31, !tbaa !24
  %t437 = load i64, ptr %l30, !tbaa !24
  %t440 = icmp sgt i64 %t436, %t437
  br i1 %t440, label %bb97, label %bb98
bb97:
  %t442 = load i64, ptr %l32, !tbaa !24
  %t444 = icmp sgt i64 %t442, 0
  br i1 %t444, label %bb99, label %bb100
bb98:
  store i64 0, ptr %l229, !tbaa !24
  br label %bb102
bb99:
  %t446 = load i64, ptr %l31, !tbaa !24
  %t447 = load i64, ptr %l30, !tbaa !24
  %t450 = sub i64 %t446, %t447
  %t451 = load i64, ptr %l32, !tbaa !24
  %t454 = add i64 %t450, %t451
  %t456 = sub i64 %t454, 1
  %t457 = load i64, ptr %l32, !tbaa !24
  %t460 = sdiv i64 %t456, %t457
  store i64 %t460, ptr %l232, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l232, !tbaa !24
  br label %bb101
bb101:
  %t462 = load i64, ptr %l232, !tbaa !24
  store i64 %t462, ptr %l229, !tbaa !24
  br label %bb102
bb102:
  %t463 = load i64, ptr %l229, !tbaa !24
  store i64 %t463, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb103
bb103:
  %t464 = load i64, ptr %l34, !tbaa !24
  %t465 = load i64, ptr %l33, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb104, label %bb105
bb104:
  br label %bb111
bb105:
  br label %bb106
bb106:
  %t472 = load i64, ptr %l30, !tbaa !24
  %t473 = load i64, ptr %l34, !tbaa !24
  %t474 = load i64, ptr %l32, !tbaa !24
  %t477 = mul i64 %t473, %t474
  %t480 = add i64 %t472, %t477
  store i64 %t480, ptr %l35, !tbaa !24
  %t482 = load i64, ptr %l35, !tbaa !24
  %t483 = load ptr, ptr %lp8
  %t485 = getelementptr { i64, ptr }, ptr %t483, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr ptr, ptr %t486, i64 %t482
  %t488 = load ptr, ptr %t487, !tbaa !39
  %t490 = icmp eq ptr %t488, null
  %t492 = xor i1 %t490, true
  br i1 %t492, label %bb107, label %bb108
bb107:
  %t494 = load i64, ptr %l35, !tbaa !24
  store i64 %t494, ptr %l29, !tbaa !24
  br label %bb109
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t496 = load i64, ptr %l34, !tbaa !24
  %t498 = add i64 %t496, 1
  store i64 %t498, ptr %l34, !tbaa !24
  br label %bb103
bb111:
  %t500 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v4, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t500, ptr %l257
  br label %bb112
bb112:
  %t501 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store ptr %t501, ptr %lp36
  %t502 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l257
  %t503 = load ptr, ptr %lp36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t502, ptr %t503
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t504, i32 0, i32 154
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t506)
  br label %bb113
bb113:
  store i64 0, ptr %l37, !tbaa !24
  %t508 = load i64, ptr %l29, !tbaa !24
  %t510 = add i64 %t508, 1
  store i64 %t510, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t512 = load i64, ptr %l38, !tbaa !24
  %t513 = load i64, ptr %l37, !tbaa !24
  %t516 = icmp sgt i64 %t512, %t513
  br i1 %t516, label %bb114, label %bb115
bb114:
  %t518 = load i64, ptr %l39, !tbaa !24
  %t520 = icmp sgt i64 %t518, 0
  br i1 %t520, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l265, !tbaa !24
  br label %bb119
bb116:
  %t522 = load i64, ptr %l38, !tbaa !24
  %t523 = load i64, ptr %l37, !tbaa !24
  %t526 = sub i64 %t522, %t523
  %t527 = load i64, ptr %l39, !tbaa !24
  %t530 = add i64 %t526, %t527
  %t532 = sub i64 %t530, 1
  %t533 = load i64, ptr %l39, !tbaa !24
  %t536 = sdiv i64 %t532, %t533
  store i64 %t536, ptr %l268, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l268, !tbaa !24
  br label %bb118
bb118:
  %t538 = load i64, ptr %l268, !tbaa !24
  store i64 %t538, ptr %l265, !tbaa !24
  br label %bb119
bb119:
  %t539 = load i64, ptr %l265, !tbaa !24
  store i64 %t539, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb120
bb120:
  %t540 = load i64, ptr %l41, !tbaa !24
  %t541 = load i64, ptr %l40, !tbaa !24
  %t544 = icmp slt i64 %t540, %t541
  %t546 = xor i1 %t544, true
  br i1 %t546, label %bb121, label %bb122
bb121:
  br label %bb132
bb122:
  br label %bb123
bb123:
  %t548 = load i64, ptr %l37, !tbaa !24
  %t549 = load i64, ptr %l41, !tbaa !24
  %t550 = load i64, ptr %l39, !tbaa !24
  %t553 = mul i64 %t549, %t550
  %t556 = add i64 %t548, %t553
  store i64 %t556, ptr %l42, !tbaa !24
  %t558 = load i64, ptr %l42, !tbaa !24
  %t559 = load ptr, ptr %lp8
  %t561 = getelementptr { i64, ptr }, ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = getelementptr ptr, ptr %t562, i64 %t558
  %t564 = load ptr, ptr %t563, !tbaa !39
  store ptr %t564, ptr %l43, !tbaa !29
  %t566 = load ptr, ptr %l43, !tbaa !29
  %t568 = icmp eq ptr %t566, null
  br i1 %t568, label %bb124, label %bb125
bb124:
  %t570 = load ptr, ptr %lp36
  store ptr %t570, ptr %l290, !tbaa !29
  %t571 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t571, ptr %l291, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l291, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr ptr, ptr %t573, i64 0
  %t575 = load ptr, ptr %t574, !tbaa !39
  %t577 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t575)
  store %"compiler/source:Span" %t577, ptr %l293
  br label %bb126
bb125:
  %t578 = load ptr, ptr %lp36
  %t579 = load ptr, ptr %l43, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t578, ptr %t579)
  br label %bb128
bb126:
  store { i64, [4 x i64] } zeroinitializer, ptr %t582
  %t583 = getelementptr { i64, [4 x i64] }, ptr %t582, i32 0, i32 0
  store i64 25, ptr %t583
  %t584 = load %"compiler/source:Span", ptr %l293
  %t585 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t584, 0
  %t586 = getelementptr { i64, [4 x i64] }, ptr %t582, i32 0, i32 1
  store { %"compiler/source:Span" } %t585, ptr %t586
  %t587 = load { i64, [4 x i64] }, ptr %t582
  %t589 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 40, i64 8)
  store { i64, [4 x i64] } %t587, ptr %t589
  %t590 = load ptr, ptr %l290, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t590, ptr %t589)
  br label %bb127
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t594 = getelementptr %"compiler/check:Checker", ptr %t592, i32 0, i32 154
  %t595 = load i64, ptr %l42, !tbaa !24
  %t597 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !27
  %t599 = getelementptr i64, ptr %t598, i64 %t595
  %t600 = load i64, ptr %t599, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t594, i64 %t600)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t603 = load i64, ptr %l41, !tbaa !24
  %t605 = add i64 %t603, 1
  store i64 %t605, ptr %l41, !tbaa !24
  br label %bb120
bb132:
  %t607 = load ptr, ptr %lp36
  %t609 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v4, ptr %v4, ptr %t607)
  store { i64, ptr } %t609, ptr %l305
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s0)
  %t610 = load { i64, ptr }, ptr %l305, !tbaa !27
  store { i64, ptr } %t610, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoValueCase(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l13 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l40 = alloca i1
  %l43 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t4, i32 %a1, i64 %a2)
  store i32 %t10, ptr %l13
  br label %bb1
bb1:
  %t11 = load i32, ptr %l13, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  store ptr %t24, ptr %l20, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 2
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l25
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t36 = load i32, ptr %l25, !tbaa !23
  %t37 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t35, i32 %t36)
  store { i64, ptr } %t37, ptr %l26
  br label %bb6
bb6:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l33, !tbaa !27
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 %t52
  %t57 = load i32, ptr %t56, !tbaa !33
  store i32 %t57, ptr %l7, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l40
  br label %bb11
bb11:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l7, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l43
  br label %bb15
bb15:
  %t75 = load i32, ptr %l43, !tbaa !23
  store i32 %t75, ptr %l8, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i32, ptr %l8, !tbaa !23
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t76, i32 %t77)
  store i1 %t80, ptr %l46
  br label %bb16
bb16:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  store ptr %t87, ptr %l50, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l55
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb21
bb19:
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load i32, ptr %l55, !tbaa !23
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t98, i32 %t99)
  store { i64, ptr } %t100, ptr %l56
  br label %bb20
bb20:
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t104 = icmp eq i64 %t102, 0
  store i1 %t104, ptr %l47, !tbaa !21
  br label %bb21
bb21:
  %t106 = load i1, ptr %l47, !tbaa !21
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t108 = load i64, ptr %l5, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l5, !tbaa !24
  br label %bb7
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotRecord(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l38 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load i1, ptr %l13, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l18, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t35, ptr %l16, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l23
  br label %bb9
bb9:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t48, ptr %l25, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l27, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l26, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t62, ptr %l25, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l29, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t73, i32 %t74)
  store i32 %t77, ptr %l34
  br label %bb13
bb13:
  %t78 = load ptr, ptr %l29, !tbaa !29
  %t79 = load i32, ptr %l34, !tbaa !23
  %t80 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t78, i32 %t79)
  store ptr %t80, ptr %l35
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l35, !tbaa !29
  store ptr %t81, ptr %l2, !tbaa !29
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  br i1 %t84, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeDecl", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l38, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t94, ptr %l43, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  store i64 %t96, ptr %l44, !tbaa !24
  %t97 = load i64, ptr %l44, !tbaa !24
  %t98 = mul i64 %t97, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  %t100 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l45, !tbaa !27
  %t102 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %t105, i64 %t107, i1 false)
  %t108 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t108, ptr %l43, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:TypeDecl", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l3, !tbaa !29
  %t115 = load ptr, ptr %l3, !tbaa !29
  store ptr %t115, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t116 = load ptr, ptr %l49, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb21, label %bb22
bb21:
  %t119 = load ptr, ptr %l49, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 0
  store i1 %t122, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t123 = load i1, ptr %l50, !tbaa !21
  br i1 %t123, label %bb23, label %bb24
bb23:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr { i64, [6 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2fcheck_2erecordBody(ptr %v0, ptr %v1, ptr %t130)
  store { i64, ptr } %t132, ptr %l56
  br label %bb26
bb26:
  %t133 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t133, ptr %l48, !tbaa !27
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l57, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t134, ptr %l48, !tbaa !27
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_9d659989a3d8e899_e17dd41770304f7d)
  unreachable
bb32:
  %t136 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l59, !tbaa !24
  %t138 = load i64, ptr %l59, !tbaa !24
  %t139 = mul i64 %t138, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  store { i64, ptr } %t142, ptr %l60, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = load i64, ptr %l59, !tbaa !24
  %t148 = mul i64 %t147, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t144, ptr %t146, i64 %t148, i1 false)
  %t149 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t149, ptr %l48, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t150, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 36
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i32
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca i32
  %l54 = alloca { i64, ptr }
  %l56 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t10, i64 %t11)
  store i32 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i32, ptr %l11, !tbaa !23
  store i32 %t15, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i32, ptr %l19, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l20
  br label %bb6
bb6:
  %t35 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t42 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t40)
  store i64 %t42, ptr %l24
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l22, !tbaa !29
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t45, ptr %l25
  br label %bb8
bb8:
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %t49, i64 %t50, i32 %a2)
  store i32 %t55, ptr %l30
  br label %bb11
bb10:
  br label %bb21
bb11:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l3, !tbaa !23
  %t57 = load i32, ptr %l3, !tbaa !23
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t61 = icmp eq i32 %t57, %t58
  br i1 %t61, label %bb12, label %bb13
bb12:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t63, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 2
  store ptr %t70, ptr %l37, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l3, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb15
bb15:
  %t81 = load ptr, ptr %l37, !tbaa !29
  %t82 = load i32, ptr %l42, !tbaa !23
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t81, i32 %t82)
  store { i64, ptr } %t83, ptr %l43
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t84, ptr %l4, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t91, ptr %l47, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 1
  %t95 = load i32, ptr %t94, !tbaa !33
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t90, i32 %t95)
  store i32 %t98, ptr %l49
  br label %bb17
bb17:
  %t99 = load i32, ptr %l49, !range !{i32 0, i32 33}
  %t101 = trunc i64 25 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb18, label %bb19
bb18:
  %t104 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t104, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l54, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i32, ptr %t109, i64 1
  %t111 = load i32, ptr %t110, !tbaa !33
  %t114 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t106, i32 %t111)
  store i32 %t114, ptr %l56
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t115 = load i32, ptr %l56, !tbaa !23
  store i32 %t115, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/generic:Origin" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorigin(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l10 = alloca i32
  %l11 = alloca %"compiler/generic:Origin"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/generic:Origin"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 2
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l5, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l6
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %t12)
  store i32 %t14, ptr %l10
  br label %bb3
bb3:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load %"compiler/source:Span", ptr %l6
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %s0, i64 %t15, %"compiler/source:Span" %t16, i64 %t17, i32 %t18)
  store %"compiler/generic:Origin" %t19, ptr %l11
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load %"compiler/generic:Origin", ptr %l11
  store %"compiler/generic:Origin" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/generic:Origin", ptr %rv
  ret %"compiler/generic:Origin" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:Desc"
  %l2 = alloca %"compiler/generic:Desc"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l9 = alloca i32
  %l16 = alloca %"compiler/generic:Desc"
  %l23 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/generic:Desc" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t8 = load i32, ptr %t7, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t8)
  store i32 %t11, ptr %l9
  br label %bb1
bb1:
  %t12 = load i32, ptr %l9, !range !{i32 0, i32 33}
  %t14 = trunc i64 21 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t23 = load i32, ptr %t22, !tbaa !23
  %t26 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t21, i32 %t23)
  store %"compiler/generic:Desc" %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load %"compiler/generic:Desc", ptr %l16
  store %"compiler/generic:Desc" %t27, ptr %l2
  %t28 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescFunc, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Desc", ptr %l2, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t43 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t38, i64 %t40)
  store ptr %t43, ptr %l23
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Sig", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  store { i64, ptr } %t50, ptr %l3, !tbaa !27
  %t52 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t53 = load i64, ptr %t52, !tbaa !24
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = icmp slt i64 %t53, %t56
  br i1 %t59, label %bb9, label %bb10
bb9:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr ptr, ptr %t66, i64 %t63
  %t68 = load ptr, ptr %t67, !tbaa !39
  %t70 = getelementptr %"compiler/ast:Param", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l31, !tbaa !29
  br label %bb11
bb10:
  store ptr null, ptr %l31, !tbaa !29
  br label %bb11
bb11:
  %t73 = load ptr, ptr %l31, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
bb12:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 1
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %v1, ptr %t77, i32 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb13
bb13:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l4, !tbaa !27
  %t84 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp sge i64 %t85, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  store ptr null, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  %t95 = getelementptr %"compiler/generic:Desc", ptr %l1, i32 0, i32 3
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = getelementptr %"compiler/ast:Param", ptr %t101, i32 0, i32 3
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca i32
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l71 = alloca i32
  %l78 = alloca i32
  %l86 = alloca ptr
  %l90 = alloca i1
  %l93 = alloca i32
  %l101 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l137 = alloca i64
  %l140 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca i32
  %l164 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l186 = alloca ptr
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i32
  %l190 = alloca ptr
  %l192 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca %"compiler/typed:Cond"
  %l205 = alloca i64
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca i32
  %l213 = alloca { i64, ptr }
  %l216 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t291 = alloca { i64, [4 x i64] }, align 8
  %t321 = alloca { i64, [4 x i64] }, align 8
  %t370 = alloca { i64, [5 x i64] }, align 8
  %t414 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l4, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i1, ptr %l22, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l27
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t17 = load i32, ptr %l27, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l29
  store i32 94, ptr %l30
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l32
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t25 = load %"compiler/source:Span", ptr %l1
  %t30 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v0, ptr %t22, ptr %t23, i32 %t24, %"compiler/source:Span" %t25)
  store ptr %t30, ptr %l37
  br label %bb5
bb5:
  %t31 = load i32, ptr %l5, !tbaa !23
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l32
  %t34 = load ptr, ptr %l37, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v0, ptr %t32, %"compiler/source:Span" %t33, ptr %t34, i32 %t31)
  store ptr %t36, ptr %l39
  br label %bb6
bb6:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l40, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l41
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l1
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t39, ptr %t40, i32 %t41, %"compiler/source:Span" %t42)
  store ptr %t47, ptr %l46
  br label %bb7
bb7:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l41
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v0, ptr %v0, ptr %t49, %"compiler/source:Span" %t50, ptr %t51, i32 %t48)
  store ptr %t53, ptr %l48
  br label %bb8
bb8:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l29
  %t56 = load i32, ptr %l30, !range !{i32 0, i32 114}
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = load ptr, ptr %l48, !tbaa !29
  %t59 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t54, %"compiler/source:Span" %t55, i32 %t56, ptr %t57, ptr %t58)
  store ptr %t59, ptr %l49
  br label %bb9
bb9:
  %t60 = load ptr, ptr %l49, !tbaa !29
  store ptr %t60, ptr %rv
  br label %ret
bb10:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l55
  br label %bb11
bb11:
  %t72 = load i32, ptr %l55, !range !{i32 0, i32 33}
  store i32 %t72, ptr %l6
  store i32 0, ptr %l7, !tbaa !23
  %t73 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t75 = trunc i64 23 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t78 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t83 = load i1, ptr %l58, !tbaa !21
  br i1 %t83, label %bb15, label %bb16
bb15:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l65
  br label %bb17
bb16:
  %t94 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t96 = trunc i64 18 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb18, label %bb19
bb17:
  %t99 = load i32, ptr %l65, !tbaa !23
  store i32 %t99, ptr %l7, !tbaa !23
  br label %bb36
bb18:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l71
  br label %bb20
bb19:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb21
bb20:
  %t105 = load i32, ptr %l71, !range !{i32 0, i32 6}
  %t107 = trunc i64 0 to i32
  %t108 = icmp eq i32 %t105, %t107
  store i1 %t108, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l68, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load i32, ptr %l4, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t116, i32 %t117)
  store i32 %t120, ptr %l78
  br label %bb24
bb23:
  %t121 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t123 = trunc i64 19 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb25, label %bb26
bb24:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l7, !tbaa !23
  br label %bb35
bb25:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t131 = load i32, ptr %l4, !tbaa !23
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t127, %"compiler/source:Span" %t128, ptr %t129, ptr %t130, i32 %t131)
  store ptr %t137, ptr %l86
  br label %bb27
bb26:
  %t138 = load i32, ptr %l6, !range !{i32 0, i32 33}
  %t140 = trunc i64 18 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb28, label %bb29
bb27:
  %t143 = load ptr, ptr %l86, !tbaa !29
  store ptr %t143, ptr %rv
  br label %ret
bb28:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i32, ptr %l4, !tbaa !23
  %t149 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l93
  br label %bb30
bb29:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb31
bb30:
  %t150 = load i32, ptr %l93, !range !{i32 0, i32 6}
  %t152 = trunc i64 1 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l90, !tbaa !21
  br label %bb31
bb31:
  %t155 = load i1, ptr %l90, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t160 = load i32, ptr %l4, !tbaa !23
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t156, %"compiler/source:Span" %t157, ptr %t158, ptr %t159, i32 %t160)
  store ptr %t166, ptr %l101
  br label %bb34
bb33:
  store ptr null, ptr %rv
  br label %ret
bb34:
  %t168 = load ptr, ptr %l101, !tbaa !29
  store ptr %t168, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 37
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l106
  br label %bb37
bb37:
  %t175 = load i64, ptr %l106, !tbaa !24
  store i64 %t175, ptr %l8, !tbaa !24
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l107, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l108
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t180 = load i32, ptr %l4, !tbaa !23
  %t181 = load %"compiler/source:Span", ptr %l1
  %t186 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v0, ptr %t178, ptr %t179, i32 %t180, %"compiler/source:Span" %t181)
  store ptr %t186, ptr %l113
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l107, !tbaa !29
  %t188 = load %"compiler/source:Span", ptr %l108
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v0, ptr %v3, ptr %t187, %"compiler/source:Span" %t188, ptr %t189)
  store ptr %t190, ptr %l114
  br label %bb39
bb39:
  %t191 = load ptr, ptr %l114, !tbaa !29
  store ptr %t191, ptr %l9, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t193, ptr %l116
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t196 = load i32, ptr %l4, !tbaa !23
  %t197 = load %"compiler/source:Span", ptr %l1
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t194, ptr %t195, i32 %t196, %"compiler/source:Span" %t197)
  store ptr %t202, ptr %l121
  br label %bb40
bb40:
  %t203 = load ptr, ptr %l115, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l116
  %t205 = load ptr, ptr %l121, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v0, ptr %v3, ptr %t203, %"compiler/source:Span" %t204, ptr %t205)
  store ptr %t206, ptr %l122
  br label %bb41
bb41:
  %t207 = load ptr, ptr %l122, !tbaa !29
  store ptr %t207, ptr %l10, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l7, !tbaa !23
  %t217 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t213, i32 %t214)
  store { i64, ptr } %t217, ptr %l127
  br label %bb42
bb42:
  %t218 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t218, ptr %l11, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  %t221 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t219, %"compiler/source:Span" %t220, i32 %t221, i64 1)
  store ptr %t225, ptr %l131
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l131, !tbaa !29
  store ptr %t226, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t227, 0
  store i64 %t229, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l14, !tbaa !24
  %t232 = load i64, ptr %l13, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb44, label %bb45
bb44:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb49
bb46:
  %t241 = load i64, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l13, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l15, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l140, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb48
bb48:
  %t257 = load i64, ptr %l140, !tbaa !24
  store i64 %t257, ptr %l137, !tbaa !24
  br label %bb49
bb49:
  %t258 = load i64, ptr %l137, !tbaa !24
  store i64 %t258, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb50
bb50:
  %t259 = load i64, ptr %l17, !tbaa !24
  %t260 = load i64, ptr %l16, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb51, label %bb52
bb51:
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t268 = load i64, ptr %l17, !tbaa !24
  %t269 = load i64, ptr %l15, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l18, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l158, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t278, ptr %l159
  store i32 94, ptr %l160
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load %"compiler/source:Span", ptr %l1
  %t281 = load %"compiler/source:Span", ptr %l1
  %t282 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t282, ptr %l164, !tbaa !27
  %t283 = load i64, ptr %l18, !tbaa !24
  %t285 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr i32, ptr %t286, i64 %t283
  %t288 = load i32, ptr %t287, !tbaa !33
  %t289 = load ptr, ptr %l9, !tbaa !29
  %t290 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 0
  store i64 3, ptr %t292
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t281, 0
  %t296 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t294, i32 %t288, 1
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t296, ptr %t289, 2
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t298, i64 %t290, 3
  %t301 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t300, ptr %t301
  %t302 = load { i64, [4 x i64] }, ptr %t291
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t302, ptr %t304
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t279, %"compiler/source:Span" %t280, ptr %t304)
  store ptr %t308, ptr %l171
  br label %bb54
bb54:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load %"compiler/source:Span", ptr %l1
  %t312 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t312, ptr %l175, !tbaa !27
  %t313 = load i64, ptr %l18, !tbaa !24
  %t315 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i32, ptr %t316, i64 %t313
  %t318 = load i32, ptr %t317, !tbaa !33
  %t319 = load ptr, ptr %l10, !tbaa !29
  %t320 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t321
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 0
  store i64 3, ptr %t322
  %t324 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t311, 0
  %t326 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t324, i32 %t318, 1
  %t328 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t326, ptr %t319, 2
  %t330 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t328, i64 %t320, 3
  %t331 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t330, ptr %t331
  %t332 = load { i64, [4 x i64] }, ptr %t321
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t332, ptr %t334
  %t338 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t309, %"compiler/source:Span" %t310, ptr %t334)
  store ptr %t338, ptr %l182
  br label %bb55
bb55:
  %t339 = load ptr, ptr %l158, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l159
  %t341 = load i32, ptr %l160, !range !{i32 0, i32 114}
  %t342 = load ptr, ptr %l171, !tbaa !29
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v0, ptr %v0, ptr %v3, ptr %t339, %"compiler/source:Span" %t340, i32 %t341, ptr %t342, ptr %t343)
  store ptr %t344, ptr %l183
  br label %bb56
bb56:
  %t345 = load ptr, ptr %l183, !tbaa !29
  store ptr %t345, ptr %l19, !tbaa !29
  %t346 = load i64, ptr %l18, !tbaa !24
  %t348 = icmp eq i64 %t346, 0
  br i1 %t348, label %bb57, label %bb58
bb57:
  %t350 = load ptr, ptr %l19, !tbaa !29
  store ptr %t350, ptr %l186, !tbaa !29
  br label %bb61
bb58:
  %t352 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t352, ptr %l188
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t353, ptr %l189, !tbaa !23
  %t354 = load ptr, ptr %l12, !tbaa !29
  store ptr %t354, ptr %l190, !tbaa !29
  %t355 = load ptr, ptr %l19, !tbaa !29
  store ptr %t355, ptr %l192, !tbaa !29
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  %t359 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t357, %"compiler/source:Span" %t358, i32 %t359, i64 0)
  store ptr %t363, ptr %l196
  br label %bb59
bb59:
  %t364 = load ptr, ptr %l190, !tbaa !29
  %t365 = load ptr, ptr %l192, !tbaa !29
  %t366 = load ptr, ptr %l196, !tbaa !29
  %t367 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t364, ptr %t365, ptr %t366)
  store %"compiler/typed:Cond" %t367, ptr %l197
  br label %bb60
bb60:
  %t368 = load %"compiler/typed:Cond", ptr %l197
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t368, ptr %t369
  store { i64, [5 x i64] } zeroinitializer, ptr %t370
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 0
  store i64 11, ptr %t371
  %t372 = load %"compiler/source:Span", ptr %l188
  %t373 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t372, 0
  %t374 = load i32, ptr %l189, !tbaa !23
  %t375 = insertvalue { %"compiler/source:Span", i32, ptr } %t373, i32 %t374, 1
  %t377 = insertvalue { %"compiler/source:Span", i32, ptr } %t375, ptr %t369, 2
  %t378 = getelementptr { i64, [5 x i64] }, ptr %t370, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t377, ptr %t378
  %t379 = load { i64, [5 x i64] }, ptr %t370
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t379, ptr %t381
  store ptr %t381, ptr %l186, !tbaa !29
  br label %bb61
bb61:
  %t383 = load ptr, ptr %l186, !tbaa !29
  store ptr %t383, ptr %l12, !tbaa !29
  br label %bb62
bb62:
  %t384 = load i64, ptr %l17, !tbaa !24
  %t386 = add i64 %t384, 1
  store i64 %t386, ptr %l17, !tbaa !24
  br label %bb50
bb63:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 37
  %t392 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t390)
  store i64 %t392, ptr %l205
  br label %bb64
bb64:
  %t393 = load i64, ptr %l8, !tbaa !24
  %t394 = load i64, ptr %l205, !tbaa !24
  %t396 = icmp sgt i64 %t394, %t393
  br i1 %t396, label %bb65, label %bb66
bb65:
  %t398 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t398, ptr %l208
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t399, ptr %l209, !tbaa !23
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 37
  %t403 = load i64, ptr %l8, !tbaa !24
  %t406 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t402, i64 %t403)
  store { i64, ptr } %t406, ptr %l213
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t407 = load ptr, ptr %l12, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t411 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t409, ptr %t407, i1 false)
  store %"compiler/typed:Seq" %t411, ptr %l216
  br label %bb68
bb68:
  %t412 = load %"compiler/typed:Seq", ptr %l216
  %t413 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t412, ptr %t413
  store { i64, [5 x i64] } zeroinitializer, ptr %t414
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 0
  store i64 12, ptr %t415
  %t416 = load %"compiler/source:Span", ptr %l208
  %t417 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t416, 0
  %t418 = load i32, ptr %l209, !tbaa !23
  %t419 = insertvalue { %"compiler/source:Span", i32, ptr } %t417, i32 %t418, 1
  %t421 = insertvalue { %"compiler/source:Span", i32, ptr } %t419, ptr %t413, 2
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t414, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t421, ptr %t422
  %t423 = load { i64, [5 x i64] }, ptr %t414
  %t425 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t423, ptr %t425
  store ptr %t425, ptr %rv
  br label %ret
bb69:
  %t427 = load ptr, ptr %l12, !tbaa !29
  store ptr %t427, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l69 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Path", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %a0, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = add i64 %t14, 1
  store i64 %t16, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l7, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l26, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  store i64 %t64, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb13, label %bb14
bb13:
  %t70 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t70, ptr %l48, !tbaa !27
  %t71 = load i64, ptr %l11, !tbaa !24
  %t73 = sub i64 %t71, 1
  %t75 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = icmp ne i8 %t78, 46
  store i1 %t80, ptr %l47, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t82 = load i1, ptr %l47, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = sub i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  br label %bb12
bb20:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  %t93 = icmp eq i64 %t89, %t90
  br i1 %t93, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Path", ptr %t95, i32 0, i32 0
  %t98 = getelementptr %"compiler/source:Span", ptr %t97, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t100 = load i64, ptr %l11, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t105 = add i32 %t99, %t102
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Path", ptr %t106, i32 0, i32 0
  %t109 = getelementptr %"compiler/source:Span", ptr %t108, i32 0, i32 0
  %t110 = load i32, ptr %t109, !tbaa !23
  %t111 = load i64, ptr %l4, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  %t116 = add i32 %t110, %t113
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t105, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l69
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  %t120 = load %"compiler/source:Span", ptr %l69
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb24:
  %t121 = load i64, ptr %l11, !tbaa !24
  %t123 = sub i64 %t121, 1
  store i64 %t123, ptr %l4, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Path", ptr %t129, i32 0, i32 0
  %t132 = load %"compiler/source:Span", ptr %t131
  store %"compiler/source:Span" %t132, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = add i64 %t134, 1
  store i64 %t136, ptr %l9, !tbaa !24
  br label %bb8
bb29:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/ast:Path", ptr %t138, i32 0, i32 0
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epayloadItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i1
  %l27 = alloca ptr
  %l33 = alloca { i64, i32 }
  %l40 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l60 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca %"compiler/check:payloadItem"
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l81 = alloca %"compiler/check:payloadItem"
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 9}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l19, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 2
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l4, !tbaa !27
  br label %bb6
bb5:
  br label %bb41
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s1, ptr %t26)
  store ptr %t28, ptr %l27
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l27, !tbaa !29
  store ptr %t29, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %lp2
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t34
  call void @__olang_scope_close(ptr %s1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t41 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s1, ptr %t37, ptr %t38)
  store { i64, i32 } %t41, ptr %l33
  br label %bb11
bb11:
  %t42 = load { i64, i32 }, ptr %l33
  store { i64, i32 } %t42, ptr %l6
  %t43 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t46 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  store i32 %t47, ptr %l8, !tbaa !23
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %lp2
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53
  call void @__olang_scope_close(ptr %s1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l8, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l45
  br label %bb15
bb15:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %s1, ptr %t71, i32 %t72, i64 %t70)
  store { i64, ptr } %t74, ptr %l47
  br label %bb16
bb16:
  %t75 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t75, ptr %l9, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb18, label %bb19
bb18:
  br label %bb40
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l11, !tbaa !24
  store i64 %t90, ptr %l13, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t92, ptr %l56, !tbaa !27
  %t93 = load i64, ptr %l11, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l14, !tbaa !29
  %t100 = load ptr, ptr %l14, !tbaa !29
  store ptr %t100, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t101 = load ptr, ptr %l59, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb21, label %bb22
bb21:
  %t104 = load ptr, ptr %l59, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 9}
  %t107 = icmp eq i64 %t105, 8
  store i1 %t107, ptr %l60, !tbaa !21
  br label %bb22
bb22:
  %t108 = load i1, ptr %l60, !tbaa !21
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t109 = load ptr, ptr %l14, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t111, i32 0, i32 1
  %t113 = load i32, ptr %t112
  store i32 %t113, ptr %l15, !tbaa !23
  %t115 = load ptr, ptr %l14, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l16, !tbaa !29
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t121 = load ptr, ptr %lp2
  store ptr %t121, ptr %l67, !tbaa !29
  %t122 = load i32, ptr %l15, !tbaa !23
  %t123 = load ptr, ptr %l16, !tbaa !29
  %t126 = call %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v1, ptr %v2, i32 %t122, ptr %t123)
  store %"compiler/check:payloadItem" %t126, ptr %l70
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l67, !tbaa !29
  %t128 = load %"compiler/check:payloadItem", ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v2, ptr %v2, ptr %t127, %"compiler/check:payloadItem" %t128)
  br label %bb27
bb27:
  br label %bb38
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb37
bb31:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t135 = icmp slt i64 %t129, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %lp2
  store ptr %t137, ptr %l75, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t138, ptr %l76, !tbaa !27
  %t139 = load i64, ptr %l13, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  %t146 = getelementptr %"compiler/ast:Param", ptr %t144, i32 0, i32 1
  %t147 = load i32, ptr %t146, !tbaa !23
  %t148 = load ptr, ptr %l14, !tbaa !29
  %t151 = call %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v1, ptr %v2, i32 %t147, ptr %t148)
  store %"compiler/check:payloadItem" %t151, ptr %l81
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t152 = load ptr, ptr %l75, !tbaa !29
  %t153 = load %"compiler/check:payloadItem", ptr %l81
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v2, ptr %v2, ptr %t152, %"compiler/check:payloadItem" %t153)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_99a2219cf20f55d9_bdfeae2ff747ebc5)
  unreachable
bb38:
  br label %bb39
bb39:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l11, !tbaa !24
  br label %bb17
bb40:
  call void @__olang_scope_close(ptr %s1)
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_aa9d1041871ddc08_900eaa132351bb14)
  unreachable
bb46:
  %t158 = load ptr, ptr %lp2
  %t159 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l55 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l64 = alloca ptr
  %l71 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca %"compiler/source:Span"
  %l82 = alloca %"compiler/diagmsg:Msg"
  %l83 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca i32
  %l97 = alloca ptr
  %s2 = alloca %olang.scope
  %t121 = alloca { i64, [1 x i64] }, align 8
  %t139 = alloca { i64, [3 x i64] }, align 8
  %t184 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb45
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 30}
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 43
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  store ptr %t90, ptr %l55, !tbaa !29
  %t92 = load ptr, ptr %l55, !tbaa !29
  %t93 = call ptr @__olang_scope_of(ptr %t92, ptr null)
  %t94 = ptrtoint ptr %t93 to i64
  %t96 = inttoptr i64 %t94 to ptr
  %t97 = load ptr, ptr %l55, !tbaa !29
  %t98 = call i32 @compiler_2fcheck_2etypeOf(ptr %t96, ptr %t97)
  store i32 %t98, ptr %l57
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = load i32, ptr %l53, !tbaa !23
  %t101 = load i32, ptr %l57, !tbaa !23
  %t102 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l58
  br label %bb29
bb29:
  %t103 = load i1, ptr %l58, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t106 = load i1, ptr %l49, !tbaa !21
  br i1 %t106, label %bb31, label %bb32
bb31:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l3, !tbaa !29
  %t109 = load i32, ptr %l4, !tbaa !23
  %t110 = load %"compiler/source:Span", ptr %l6
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t107, ptr %t108, i32 %t109, %"compiler/source:Span" %t110)
  store ptr %t115, ptr %l64
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t116 = load ptr, ptr %l64, !tbaa !29
  store ptr %t116, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t119 = load %"compiler/source:Span", ptr %l6
  %t120 = load i32, ptr %l4, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [1 x i64] }, ptr %t121, i32 0, i32 0
  store i64 4, ptr %t122
  %t123 = load { i64, [1 x i64] }, ptr %t121
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t117, i32 %t118, %"compiler/source:Span" %t119, i32 %t120, i32 1, { i64, [1 x i64] } %t123)
  store i64 %t130, ptr %l71
  br label %bb35
bb35:
  %t131 = load i64, ptr %l71, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l6
  %t136 = trunc i64 %t131 to i32
  %t138 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t139
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 0
  store i64 0, ptr %t140
  %t142 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t133, 0
  %t144 = insertvalue { %"compiler/source:Span", i32, ptr } %t142, i32 %t136, 1
  %t146 = insertvalue { %"compiler/source:Span", i32, ptr } %t144, ptr %t138, 2
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t146, ptr %t147
  %t148 = load { i64, [3 x i64] }, ptr %t139
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t148, ptr %t150
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t132, ptr %t150)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb37:
  br i1 true, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t153, ptr %l80, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t154, ptr %l81
  %t155 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
  store %"compiler/diagmsg:Msg" %t155, ptr %l82
  br label %bb41
bb41:
  %t156 = load ptr, ptr %l80, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l81
  %t158 = load %"compiler/diagmsg:Msg", ptr %l82
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t156, %"compiler/source:Span" %t157, %"compiler/diagmsg:Msg" %t158)
  store i64 %t159, ptr %l83
  br label %bb42
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_fb06dcd16342dc9_94e70e479081575d)
  unreachable
bb44:
  br label %ret
bb45:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t164 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t160, ptr %t161)
  store ptr %t164, ptr %l86
  br label %bb46
bb46:
  %t165 = load ptr, ptr %l86, !tbaa !29
  store ptr %t165, ptr %l9, !tbaa !29
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb47, label %bb48
bb47:
  br label %ret
bb48:
  br label %bb49
bb49:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l89, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t171, ptr %l90
  %t172 = load ptr, ptr %l9, !tbaa !29
  store ptr %t172, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l92, !tbaa !29
  %t174 = load ptr, ptr %l3, !tbaa !29
  store ptr %t174, ptr %l93, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  %t177 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t175)
  store i32 %t177, ptr %l95
  br label %bb50
bb50:
  %t178 = load %"compiler/source:Span", ptr %l5
  %t179 = load ptr, ptr %l92, !tbaa !29
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = load i32, ptr %l95, !tbaa !23
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v2, ptr %v0, ptr %t179, ptr %t180, i32 %t181, %"compiler/source:Span" %t178)
  store ptr %t183, ptr %l97
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 0
  store i64 1, ptr %t185
  %t186 = load %"compiler/source:Span", ptr %l90
  %t187 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t186, 0
  %t188 = load ptr, ptr %l91, !tbaa !29
  %t189 = insertvalue { %"compiler/source:Span", ptr, ptr } %t187, ptr %t188, 1
  %t190 = load ptr, ptr %l97, !tbaa !29
  %t191 = insertvalue { %"compiler/source:Span", ptr, ptr } %t189, ptr %t190, 2
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t191, ptr %t192
  %t193 = load { i64, [3 x i64] }, ptr %t184
  %t195 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t193, ptr %t195
  %t196 = load ptr, ptr %l89, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t196, ptr %t195)
  br label %bb52
bb52:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadFact(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:factRead", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/check:factRead", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s0, ptr %t11, i64 %t15)
  store { i64, ptr } %t18, ptr %l12
  br label %bb3
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/check:factRead", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t30 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t23, i64 %t27)
  store ptr %t30, ptr %l18
  br label %bb4
bb3:
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %l7, !tbaa !27
  br label %bb6
bb4:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Func", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %t34, !tbaa !23
  %t36 = load ptr, ptr %l13, !tbaa !29
  %t38 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s0, ptr %t36, i32 %t35)
  store { i64, ptr } %t38, ptr %l21
  br label %bb5
bb5:
  %t39 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t41 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = add i64 %t40, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t39, i64 %t40)
  %t46 = getelementptr i8, ptr %t45, i64 %t40
  call void @olang_textcopy(ptr %t46, ptr %t42, i64 %t43)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  br label %bb6
bb6:
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t57, ptr %l2, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/check:factRead", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efileIdentity(ptr %v0, ptr %s0, ptr %t58, i64 %t62)
  store { i64, ptr } %t65, ptr %l27
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/check:factRead", ptr %t66, i32 0, i32 5
  %t69 = getelementptr %"compiler/source:Span", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr %"compiler/check:factRead", ptr %t71, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t76 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t78 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t86 = sext i32 %t70 to i64
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %t86)
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t74, 1
  %t94 = extractvalue { i64, ptr } %t74, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t100 = extractvalue { i64, ptr } %t75, 1
  %t101 = extractvalue { i64, ptr } %t75, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t76, i64 %t77)
  %t104 = getelementptr i8, ptr %t103, i64 %t77
  call void @olang_textcopy(ptr %t104, ptr %t79, i64 %t80)
  %t105 = getelementptr i8, ptr %t104, i64 %t80
  call void @olang_textcopy(ptr %t105, ptr %t82, i64 %t83)
  %t106 = getelementptr i8, ptr %t105, i64 %t83
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t86)
  %t108 = getelementptr i8, ptr %t106, i64 %t87
  call void @olang_textcopy(ptr %t108, ptr %t89, i64 %t90)
  %t109 = getelementptr i8, ptr %t108, i64 %t90
  call void @olang_textcopy(ptr %t109, ptr %t93, i64 %t94)
  %t110 = getelementptr i8, ptr %t109, i64 %t94
  call void @olang_textcopy(ptr %t110, ptr %t96, i64 %t97)
  %t111 = getelementptr i8, ptr %t110, i64 %t97
  call void @olang_textcopy(ptr %t111, ptr %t100, i64 %t101)
  %t112 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t103, 1
  store { i64, ptr } %t113, ptr %l3, !tbaa !27
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 3
  %t121 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr %"compiler/check:factRead", ptr %t122, i32 0, i32 3
  %t125 = load i1, ptr %t124, !tbaa !21
  %t127 = select i1 %t125, ptr @.c32, ptr @.c33
  %t128 = select i1 %t125, i64 4, i64 5
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t127, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t134 = extractvalue { i64, ptr } %t131, 1
  %t135 = mul i64 %t133, 1
  %t136 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t135)
  call void @llvm.memcpy.p0.p0.i64(ptr %t136, ptr %t134, i64 %t135, i1 false)
  %t137 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t136, 1
  call void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %s0, ptr %s0, ptr %t120, { i64, ptr } %t121, { i64, ptr } %t138, i1 true)
  br label %bb8
bb8:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 3
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/check:factRead", ptr %t148, i32 0, i32 4
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t156 = call { i32, { i64, ptr } } @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eRead(ptr %v0, ptr %s0, ptr %s0, ptr %t147, i64 %t151, { i64, ptr } %t152)
  %t157 = extractvalue { i32, { i64, ptr } } %t156, 1
  %t158 = extractvalue { i32, { i64, ptr } } %t156, 0
  store i32 %t158, ptr %l50
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb10, label %ok.160, !prof !99
ok.160:
  store { i64, ptr } %t157, ptr %l49
  br label %bb9
bb9:
  %t161 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t161, ptr %l42, !tbaa !27
  br label %bb12
bb10:
  br label %bb11
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t162, ptr %l42, !tbaa !27
  br label %bb12
bb12:
  %t164 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t172, ptr %l54
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load i1, ptr %l54, !tbaa !21
  store i1 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflRendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca %"compiler/check:reflVal"
  %l5 = alloca %"compiler/check:reflVal"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %a0, ptr %a1)
  store %"compiler/check:reflVal" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load %"compiler/check:reflVal", ptr %l5
  store %"compiler/check:reflVal" %t6, ptr %l2
  %t7 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 0
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t13 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t19 = icmp eq i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t39 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t38, 1
  store { i32, { i64, ptr } } %t39, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t45 = icmp eq i64 %t41, %t42
  br i1 %t45, label %bb8, label %bb9
bb8:
  %t47 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t48)
  %t51 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t50)
  %t52 = call i64 @__olang_fmt_i64(ptr %t51, i64 %t48)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t54, 1
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t57 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 1
  %t58 = load i64, ptr %t57, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t62 = icmp eq i64 %t58, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = getelementptr %"compiler/check:reflVal", ptr %l2, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp eq i64 %t65, 1
  br i1 %t67, label %bb13, label %bb14
bb12:
  br label %bb16
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t69, ptr %l26, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t71, ptr %l26, !tbaa !27
  br label %bb15
bb15:
  %t73 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l31, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = mul i64 %t75, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l32, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = load i64, ptr %l31, !tbaa !24
  %t85 = mul i64 %t84, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t81, ptr %t83, i64 %t85, i1 false)
  %t86 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t86, ptr %l26, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t88 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t87, 1
  store { i32, { i64, ptr } } %t88, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s0)
  %t90 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 142
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Call", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l23, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Call", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l48, !tbaa !29
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i32, ptr %l51, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l52
  br label %bb16
bb16:
  %t87 = load i1, ptr %l52, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store i1 %t94, ptr %l57
  br label %bb19
bb18:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i1, ptr %l57, !tbaa !21
  store i1 %t95, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l53, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i1 %t102, ptr %l62
  br label %bb23
bb22:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb24
bb23:
  %t103 = load i1, ptr %l62, !tbaa !21
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l7, !tbaa !24
  br label %bb11
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca %"compiler/typed:Local"
  %l46 = alloca ptr
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l79 = alloca i32
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l98 = alloca i1
  %l102 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l112 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l113 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sgt i64 %t5, 48
  store i1 %t7, ptr %l26, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l29, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l30, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l6, !tbaa !23
  br label %bb11
bb10:
  br label %bb67
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 14
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l38
  br label %bb12
bb12:
  %t32 = load i32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l38, !tbaa !29
  %t35 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t33, i32 %t32)
  store %"compiler/typed:Local" %t35, ptr %l40
  br label %bb13
bb13:
  %t36 = load %"compiler/typed:Local", ptr %l40
  store %"compiler/typed:Local" %t36, ptr %l7
  %t37 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t38 = load i32, ptr %t37, !range !{i32 0, i32 7}
  %t40 = trunc i64 0 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 14
  %t46 = load i64, ptr %l1, !tbaa !24
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store ptr %t49, ptr %l46
  br label %bb16
bb15:
  br label %bb44
bb16:
  %t50 = load ptr, ptr %l46, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Body", ptr %t50, i32 0, i32 5
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l48
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l48)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l50
  br label %bb17
bb17:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l8)
  store i64 %t58, ptr %l52
  br label %bb18
bb18:
  %t59 = load i64, ptr %l52, !tbaa !24
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t60 = load i64, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t66 = load i64, ptr %l11, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb24
bb21:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l11, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l59, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t86 = load i64, ptr %l59, !tbaa !24
  store i64 %t86, ptr %l56, !tbaa !24
  br label %bb24
bb24:
  %t87 = load i64, ptr %l56, !tbaa !24
  store i64 %t87, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb26, label %bb27
bb26:
  br label %bb43
bb27:
  br label %bb28
bb28:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l11, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l14, !tbaa !24
  %t109 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %s3, ptr %l8, i64 %t106)
  store i32 %t109, ptr %l79
  br label %bb29
bb29:
  %t110 = load i32, ptr %l6, !tbaa !23
  %t111 = load i32, ptr %l79, !tbaa !23
  %t113 = icmp eq i32 %t111, %t110
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load i64, ptr %l1, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t121 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t115, i64 %t116, i64 %t117)
  store i1 %t121, ptr %l86
  br label %bb32
bb31:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb33
bb32:
  %t122 = load i1, ptr %l86, !tbaa !21
  store i1 %t122, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t123 = load i1, ptr %l82, !tbaa !21
  br i1 %t123, label %bb34, label %bb35
bb34:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t125 = load i64, ptr %l14, !tbaa !24
  %t128 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v2, ptr %t124, i64 %t125)
  store i1 %t128, ptr %l90
  br label %bb36
bb35:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb36:
  %t129 = load i1, ptr %l90, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t132 = load i1, ptr %l87, !tbaa !21
  br i1 %t132, label %bb38, label %bb39
bb38:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t134 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t133, i64 %t134)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l13, !tbaa !24
  br label %bb25
bb43:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb44:
  %t141 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t142 = load i32, ptr %t141, !range !{i32 0, i32 7}
  %t144 = trunc i64 5 to i32
  %t145 = icmp eq i32 %t142, %t144
  br i1 %t145, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb48
bb46:
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t148 = load i32, ptr %l6, !tbaa !23
  %t150 = sext i32 %t148 to i64
  %t153 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v3, ptr %t147, i64 %t150)
  store i1 %t153, ptr %l102
  br label %bb47
bb47:
  %t154 = load i1, ptr %l102, !tbaa !21
  store i1 %t154, ptr %l98, !tbaa !21
  br label %bb48
bb48:
  %t155 = load i1, ptr %l98, !tbaa !21
  br i1 %t155, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb50:
  br label %bb51
bb51:
  %t156 = load ptr, ptr %l4, !tbaa !29
  %t157 = load i32, ptr %l6, !tbaa !23
  %t159 = sext i32 %t157 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v3, ptr %t156, i64 %t159, i1 true)
  br label %bb52
bb52:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 87
  store ptr %t164, ptr %l108, !tbaa !29
  %t165 = load i64, ptr %l1, !tbaa !24
  %t166 = load i32, ptr %l6, !tbaa !23
  %t168 = sext i32 %t166 to i64
  %t171 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t165, i64 %t168)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t171, ptr %l112
  br label %bb53
bb53:
  %t172 = load ptr, ptr %l108, !tbaa !29
  %t173 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l112
  %t174 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H9a57a0a969606bc6b56c6db08d26f577(ptr %v0, ptr %v0, ptr %t172, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t173)
  %t175 = extractvalue { i32, ptr } %t174, 1
  %t176 = extractvalue { i32, ptr } %t174, 0
  store i32 %t176, ptr %l114
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb55, label %ok.178, !prof !99
ok.178:
  store ptr %t175, ptr %l113
  br label %bb54
bb54:
  %t179 = load ptr, ptr %l113, !tbaa !29
  store ptr %t179, ptr %l106, !tbaa !29
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb57:
  %t180 = load ptr, ptr %l106, !tbaa !29
  store ptr %t180, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb58
bb58:
  %t183 = load i64, ptr %l17, !tbaa !24
  store i64 %t183, ptr %l116, !tbaa !24
  %t184 = load ptr, ptr %l16, !tbaa !29
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l118
  br label %bb59
bb59:
  %t187 = load i64, ptr %l116, !tbaa !24
  %t188 = load i64, ptr %l118, !tbaa !24
  %t189 = icmp slt i64 %t187, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb60, label %bb61
bb60:
  br label %bb66
bb61:
  br label %bb62
bb62:
  %t193 = load ptr, ptr %l16, !tbaa !29
  %t194 = load i64, ptr %l17, !tbaa !24
  %t197 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t193, i64 %t194)
  store ptr %t197, ptr %l123
  br label %bb63
bb63:
  %t198 = load ptr, ptr %l123, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t205 = load i64, ptr %l5, !tbaa !24
  %t207 = add i64 %t205, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v0, ptr %v2, ptr %v3, ptr %t199, i64 %t200, ptr %t198, ptr %t203, ptr %t204, i64 %t207)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t214 = load i64, ptr %l17, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l17, !tbaa !24
  br label %bb58
bb66:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb67:
  %t218 = load ptr, ptr %l2, !tbaa !29
  store ptr %t218, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t219 = load ptr, ptr %l134, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb68, label %bb69
bb68:
  %t222 = load ptr, ptr %l134, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 8}
  %t225 = icmp eq i64 %t223, 2
  store i1 %t225, ptr %l135, !tbaa !21
  br label %bb69
bb69:
  %t226 = load i1, ptr %l135, !tbaa !21
  br i1 %t226, label %bb70, label %bb71
bb70:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = getelementptr { i64, [4 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t229, i32 0, i32 2
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l19, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i64, ptr %l1, !tbaa !24
  %t235 = load ptr, ptr %l19, !tbaa !29
  %t237 = load ptr, ptr %l3, !tbaa !29
  %t238 = load ptr, ptr %l4, !tbaa !29
  %t239 = load i64, ptr %l5, !tbaa !24
  %t241 = add i64 %t239, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t233, i64 %t234, ptr %t235, ptr %t237, ptr %t238, i64 %t241)
  br label %bb73
bb73:
  br label %bb107
bb74:
  %t248 = load ptr, ptr %l2, !tbaa !29
  store ptr %t248, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t249 = load ptr, ptr %l148, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l148, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 8}
  %t255 = icmp eq i64 %t253, 3
  store i1 %t255, ptr %l149, !tbaa !21
  br label %bb76
bb76:
  %t256 = load i1, ptr %l149, !tbaa !21
  br i1 %t256, label %bb77, label %bb78
bb77:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l20, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l1, !tbaa !24
  %t265 = load ptr, ptr %l20, !tbaa !29
  %t267 = load ptr, ptr %l3, !tbaa !29
  %t268 = load ptr, ptr %l4, !tbaa !29
  %t269 = load i64, ptr %l5, !tbaa !24
  %t271 = add i64 %t269, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t263, i64 %t264, ptr %t265, ptr %t267, ptr %t268, i64 %t271)
  br label %bb80
bb80:
  br label %bb107
bb81:
  %t278 = load ptr, ptr %l2, !tbaa !29
  store ptr %t278, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t279 = load ptr, ptr %l162, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb82, label %bb83
bb82:
  %t282 = load ptr, ptr %l162, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 8}
  %t285 = icmp eq i64 %t283, 4
  store i1 %t285, ptr %l163, !tbaa !21
  br label %bb83
bb83:
  %t286 = load i1, ptr %l163, !tbaa !21
  br i1 %t286, label %bb84, label %bb85
bb84:
  %t287 = load ptr, ptr %l2, !tbaa !29
  %t289 = getelementptr { i64, [4 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l21, !tbaa !29
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load i64, ptr %l1, !tbaa !24
  %t295 = load ptr, ptr %l21, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Elem", ptr %t295, i32 0, i32 0
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t301 = load ptr, ptr %l4, !tbaa !29
  %t302 = load i64, ptr %l5, !tbaa !24
  %t304 = add i64 %t302, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t293, i64 %t294, ptr %t298, ptr %t300, ptr %t301, i64 %t304)
  br label %bb87
bb87:
  br label %bb107
bb88:
  %t311 = load ptr, ptr %l2, !tbaa !29
  store ptr %t311, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t312 = load ptr, ptr %l177, !tbaa !29
  %t313 = icmp ne ptr %t312, null
  br i1 %t313, label %bb89, label %bb90
bb89:
  %t315 = load ptr, ptr %l177, !tbaa !29
  %t316 = load i64, ptr %t315, !range !{i64 0, i64 8}
  %t318 = icmp eq i64 %t316, 5
  store i1 %t318, ptr %l178, !tbaa !21
  br label %bb90
bb90:
  %t319 = load i1, ptr %l178, !tbaa !21
  br i1 %t319, label %bb91, label %bb92
bb91:
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t322 = getelementptr { i64, [4 x i64] }, ptr %t320, i32 0, i32 1
  %t323 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t322, i32 0, i32 2
  %t324 = load ptr, ptr %t323
  store ptr %t324, ptr %l22, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i64, ptr %l1, !tbaa !24
  %t328 = load ptr, ptr %l22, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Payload", ptr %t328, i32 0, i32 0
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = load ptr, ptr %l3, !tbaa !29
  %t334 = load ptr, ptr %l4, !tbaa !29
  %t335 = load i64, ptr %l5, !tbaa !24
  %t337 = add i64 %t335, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t326, i64 %t327, ptr %t331, ptr %t333, ptr %t334, i64 %t337)
  br label %bb94
bb94:
  br label %bb107
bb95:
  %t344 = load ptr, ptr %l2, !tbaa !29
  store ptr %t344, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t345 = load ptr, ptr %l192, !tbaa !29
  %t346 = icmp ne ptr %t345, null
  br i1 %t346, label %bb96, label %bb97
bb96:
  %t348 = load ptr, ptr %l192, !tbaa !29
  %t349 = load i64, ptr %t348, !range !{i64 0, i64 8}
  %t351 = icmp eq i64 %t349, 6
  store i1 %t351, ptr %l193, !tbaa !21
  br label %bb97
bb97:
  %t352 = load i1, ptr %l193, !tbaa !21
  br i1 %t352, label %bb98, label %bb99
bb98:
  %t353 = load ptr, ptr %l2, !tbaa !29
  %t355 = getelementptr { i64, [4 x i64] }, ptr %t353, i32 0, i32 1
  %t356 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t355, i32 0, i32 2
  %t357 = load ptr, ptr %t356
  store ptr %t357, ptr %l23, !tbaa !29
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i64, ptr %l1, !tbaa !24
  %t361 = load ptr, ptr %l23, !tbaa !29
  %t363 = load ptr, ptr %l3, !tbaa !29
  %t364 = load ptr, ptr %l4, !tbaa !29
  %t365 = load i64, ptr %l5, !tbaa !24
  %t367 = add i64 %t365, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t359, i64 %t360, ptr %t361, ptr %t363, ptr %t364, i64 %t367)
  br label %bb101
bb101:
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_8771b1e868207559_9b4adf6aba3e467d)
  unreachable
bb107:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l85 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l13, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t12)
  store i32 %t15, ptr %l16
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t18, ptr %l17
  br label %bb5
bb5:
  %t19 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  %t22 = and i64 %t20, %t19
  %t24 = icmp ne i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t27)
  store ptr %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l23, !tbaa !29
  %t32 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  store i64 %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l24, !tbaa !24
  %t34 = icmp sge i64 %t33, 0
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb14
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t37)
  store ptr %t39, ptr %l29
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load ptr, ptr %l29, !tbaa !29
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i1 %t42, ptr %l30
  br label %bb13
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t46 = load ptr, ptr %l32, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 2
  store i1 %t52, ptr %l33, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store i1 %t64, ptr %l40
  br label %bb21
bb21:
  %t65 = load i1, ptr %l40, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb76
bb22:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t67 = load ptr, ptr %l41, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 3
  store i1 %t73, ptr %l42, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l3, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t86, ptr %l50
  br label %bb28
bb28:
  %t87 = load i1, ptr %l50, !tbaa !21
  store i1 %t87, ptr %l31, !tbaa !21
  br label %bb76
bb29:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t89 = load ptr, ptr %l51, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb30, label %bb31
bb30:
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 10
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb31
bb31:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb32, label %bb33
bb32:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Slice", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t111 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i1 %t111, ptr %l61
  br label %bb35
bb35:
  %t112 = load i1, ptr %l61, !tbaa !21
  store i1 %t112, ptr %l31, !tbaa !21
  br label %bb76
bb36:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t114 = load ptr, ptr %l62, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb37, label %bb38
bb37:
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 6
  store i1 %t120, ptr %l63, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l63, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l5, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  store i1 %t133, ptr %l31, !tbaa !21
  br label %bb76
bb43:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t135 = load ptr, ptr %l71, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb44, label %bb45
bb44:
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 18}
  %t141 = icmp eq i64 %t139, 9
  store i1 %t141, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t142 = load i1, ptr %l72, !tbaa !21
  br i1 %t142, label %bb46, label %bb47
bb46:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [5 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t145, i32 0, i32 2
  %t147 = load i32, ptr %t146, !range !{i32 0, i32 52}
  store i32 %t147, ptr %l6
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  br label %bb48
bb47:
  br label %bb57
bb48:
  %t155 = load i32, ptr %l6, !range !{i32 0, i32 52}
  %t157 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t155)
  store i1 %t157, ptr %l80
  br label %bb49
bb49:
  %t158 = load i1, ptr %l80, !tbaa !21
  br i1 %t158, label %bb50, label %bb51
bb50:
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t163 = icmp sgt i64 %t161, 0
  store i1 %t163, ptr %l81, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l87, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 0
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t175 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t166, ptr %t171)
  store i1 %t175, ptr %l90
  br label %bb55
bb54:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb56
bb55:
  %t176 = load i1, ptr %l90, !tbaa !21
  store i1 %t176, ptr %l85, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l85, !tbaa !21
  store i1 %t177, ptr %l31, !tbaa !21
  br label %bb76
bb57:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l91, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 18}
  %t185 = icmp eq i64 %t183, 5
  store i1 %t185, ptr %l92, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l92, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  br label %bb70
bb61:
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t188 = load ptr, ptr %l95, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb62, label %bb63
bb62:
  %t191 = load ptr, ptr %l95, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  br label %bb63
bb63:
  %t195 = load i1, ptr %l96, !tbaa !21
  br i1 %t195, label %bb64, label %bb65
bb64:
  br label %bb70
bb65:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb66, label %bb67
bb66:
  %t200 = load ptr, ptr %l99, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 0
  store i1 %t203, ptr %l100, !tbaa !21
  br label %bb67
bb67:
  %t204 = load i1, ptr %l100, !tbaa !21
  br i1 %t204, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb76
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_62c5ac3e914a4019_8e197c98e172d865)
  unreachable
bb76:
  %t205 = load i1, ptr %l31, !tbaa !21
  store i1 %t205, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/diagmsg:Msg"
  %l10 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l53 = alloca { i64, ptr }
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l64 = alloca { i64, ptr }
  %l67 = alloca %"compiler/diagmsg:Msg"
  %l68 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca { i64, ptr }
  %l78 = alloca %"compiler/diagmsg:Msg"
  %l79 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i64
  %l91 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb19
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l16, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l19
  br label %bb6
bb5:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i32, ptr %l19, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l20
  br label %bb7
bb7:
  %t23 = load i1, ptr %l20, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t28)
  store ptr %t30, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %t31, ptr %t32)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %t39, ptr %t40)
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb19:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t48)
  store i32 %t50, ptr %l34
  br label %bb20
bb20:
  %t51 = load i32, ptr %l34, !tbaa !23
  store i32 %t51, ptr %l4, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l35, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade)
  unreachable
bb22:
  br label %bb23
bb23:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l36, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %t59, ptr %t58)
  store i32 %t61, ptr %l40
  br label %bb24
bb24:
  %t62 = load i32, ptr %l4, !tbaa !23
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l40, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %s0, ptr %t63, i32 %t64, i32 %t62)
  store { i64, ptr } %t66, ptr %l42
  br label %bb25
bb25:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l5, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i32, ptr %l4, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t68, i32 %t69)
  store { i64, ptr } %t72, ptr %l45
  br label %bb26
bb26:
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t79, { i64, ptr } %t80)
  store %"compiler/diagmsg:Msg" %t83, ptr %l48
  br label %bb27
bb27:
  %t84 = load %"compiler/diagmsg:Msg", ptr %l48
  store %"compiler/diagmsg:Msg" %t84, ptr %l6
  %t85 = load i64, ptr %l3, !tbaa !24
  %t87 = icmp eq i64 %t85, 1
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i32, ptr %l4, !tbaa !23
  %t93 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t89, i32 %t90)
  store { i64, ptr } %t93, ptr %l53
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t100, { i64, ptr } %t101)
  store %"compiler/diagmsg:Msg" %t104, ptr %l56
  br label %bb31
bb31:
  %t105 = load %"compiler/diagmsg:Msg", ptr %l6
  store %"compiler/diagmsg:Msg" %t105, ptr %l57
  %t106 = load %"compiler/diagmsg:Msg", ptr %l56
  store %"compiler/diagmsg:Msg" %t106, ptr %l6
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t107, label %bb32, label %bb33
bb32:
  %t109 = getelementptr %"compiler/diagmsg:Msg", ptr %l57, i32 0, i32 1
  %t110 = load { i64, ptr }, ptr %t109
  %t111 = extractvalue { i64, ptr } %t110, 1
  call void @__olang_region_release(ptr %t111)
  store { i64, ptr } zeroinitializer, ptr %t109
  br label %bb33
bb33:
  %t112 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t112, label %bb34, label %bb35
bb34:
  %t114 = getelementptr %"compiler/diagmsg:Msg", ptr %l57, i32 0, i32 2
  %t115 = load { i64, ptr }, ptr %t114
  %t116 = extractvalue { i64, ptr } %t115, 1
  call void @__olang_region_release(ptr %t116)
  store { i64, ptr } zeroinitializer, ptr %t114
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t117 = load i64, ptr %l3, !tbaa !24
  %t119 = icmp eq i64 %t117, 2
  br i1 %t119, label %bb37, label %bb38
bb37:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l4, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t125, ptr %l64
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t126 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = mul i64 %t127, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t129)
  call void @llvm.memcpy.p0.p0.i64(ptr %t130, ptr %t128, i64 %t129, i1 false)
  %t131 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  %t133 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t132, { i64, ptr } %t133)
  store %"compiler/diagmsg:Msg" %t136, ptr %l67
  br label %bb40
bb40:
  %t137 = load %"compiler/diagmsg:Msg", ptr %l6
  store %"compiler/diagmsg:Msg" %t137, ptr %l68
  %t138 = load %"compiler/diagmsg:Msg", ptr %l67
  store %"compiler/diagmsg:Msg" %t138, ptr %l6
  %t139 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t139, label %bb41, label %bb42
bb41:
  %t141 = getelementptr %"compiler/diagmsg:Msg", ptr %l68, i32 0, i32 1
  %t142 = load { i64, ptr }, ptr %t141
  %t143 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release(ptr %t143)
  store { i64, ptr } zeroinitializer, ptr %t141
  br label %bb42
bb42:
  %t144 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t144, label %bb43, label %bb44
bb43:
  %t146 = getelementptr %"compiler/diagmsg:Msg", ptr %l68, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146
  %t148 = extractvalue { i64, ptr } %t147, 1
  call void @__olang_region_release(ptr %t148)
  store { i64, ptr } zeroinitializer, ptr %t146
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t149 = load i64, ptr %l3, !tbaa !24
  %t151 = icmp eq i64 %t149, 3
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i32, ptr %l4, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t157, ptr %l75
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t158 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t165 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t168 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t164, { i64, ptr } %t165)
  store %"compiler/diagmsg:Msg" %t168, ptr %l78
  br label %bb49
bb49:
  %t169 = load %"compiler/diagmsg:Msg", ptr %l6
  store %"compiler/diagmsg:Msg" %t169, ptr %l79
  %t170 = load %"compiler/diagmsg:Msg", ptr %l78
  store %"compiler/diagmsg:Msg" %t170, ptr %l6
  %t171 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1
  br i1 %t171, label %bb50, label %bb51
bb50:
  %t173 = getelementptr %"compiler/diagmsg:Msg", ptr %l79, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173
  %t175 = extractvalue { i64, ptr } %t174, 1
  call void @__olang_region_release(ptr %t175)
  store { i64, ptr } zeroinitializer, ptr %t173
  br label %bb51
bb51:
  %t176 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t176, label %bb52, label %bb53
bb52:
  %t178 = getelementptr %"compiler/diagmsg:Msg", ptr %l79, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178
  %t180 = extractvalue { i64, ptr } %t179, 1
  call void @__olang_region_release(ptr %t180)
  store { i64, ptr } zeroinitializer, ptr %t178
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = load %"compiler/diagmsg:Msg", ptr %l6
  %t187 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t181, %"compiler/source:Span" %a2, %"compiler/diagmsg:Msg" %t183)
  store i64 %t187, ptr %l85
  br label %bb55
bb55:
  %t188 = load i64, ptr %l85, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l86, !tbaa !29
  store i64 %t188, ptr %l87, !tbaa !24
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  br i1 %t193, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_658c1f9b991d3291_83ad80e13fec4285)
  unreachable
bb57:
  br label %bb58
bb58:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %s0, ptr %t195)
  store ptr %t197, ptr %l91
  br label %bb59
bb59:
  %t198 = load ptr, ptr %l86, !tbaa !29
  %t199 = load i64, ptr %l87, !tbaa !24
  %t200 = load ptr, ptr %l91, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %s0, ptr %t198, i64 %t199, ptr %t200)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l14
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l20
  br label %bb14
bb14:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleUnset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:unsetCand"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/definit:Verdict"
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, [3 x i64] }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l26 = alloca i64
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/check:unsetCand"
  %l44 = alloca i1
  %l45 = alloca i64
  %l48 = alloca i64
  %l50 = alloca i1
  %l54 = alloca ptr
  %l63 = alloca ptr
  %l69 = alloca %"compiler/definit:Verdict"
  %l84 = alloca ptr
  %l89 = alloca i1
  %l90 = alloca i1
  %l92 = alloca i1
  %l97 = alloca i1
  %l103 = alloca ptr
  %l123 = alloca ptr
  %l128 = alloca ptr
  %l132 = alloca %"compiler/typed:Local"
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i64
  %l138 = alloca { i64, ptr }
  %l141 = alloca i1
  %l142 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l151 = alloca i64
  %l154 = alloca ptr
  %l161 = alloca { i64, [3 x i64] }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l168 = alloca %"compiler/diagmsg:Msg"
  %l169 = alloca i64
  %l170 = alloca ptr
  %l177 = alloca { i64, [3 x i64] }
  %l178 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l184 = alloca %"compiler/diagmsg:Msg"
  %l185 = alloca i64
  %l188 = alloca i1
  %l190 = alloca %"compiler/diagmsg:Msg"
  %l193 = alloca %"compiler/diagmsg:Msg"
  %l196 = alloca %"compiler/diagmsg:Msg"
  %l199 = alloca %"compiler/diagmsg:Msg"
  %l202 = alloca %"compiler/diagmsg:Msg"
  %l205 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca %"compiler/diagmsg:Msg"
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t214 = alloca { i64, [3 x i64] }, align 8
  %t342 = alloca { i64, [3 x i64] }, align 8
  %t372 = alloca { i64, [3 x i64] }, align 8
  %t489 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 112
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eLen__H7de3be79b8c6c838ec83b81887d1384a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i64, ptr %l26, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %t17, !tbaa !29
  store ptr %t18, ptr %l1, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 112
  store ptr %t22, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load i64, ptr %l3, !tbaa !24
  store i64 %t24, ptr %l34, !tbaa !24
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eLen__H7de3be79b8c6c838ec83b81887d1384a(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l36
  br label %bb6
bb6:
  %t28 = load i64, ptr %l34, !tbaa !24
  %t29 = load i64, ptr %l36, !tbaa !24
  %t30 = icmp slt i64 %t28, %t29
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb113
bb8:
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i64, ptr %l3, !tbaa !24
  %t38 = call %"compiler/check:unsetCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eAt_3ccompiler_2fcheck_3aunsetCand_3e(ptr %v0, ptr %t34, i64 %t35)
  store %"compiler/check:unsetCand" %t38, ptr %l41
  br label %bb10
bb10:
  %t39 = load %"compiler/check:unsetCand", ptr %l41
  store %"compiler/check:unsetCand" %t39, ptr %l4
  %t40 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb14
bb12:
  %t45 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 0
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l45, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 14
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l48
  br label %bb13
bb13:
  %t52 = load i64, ptr %l45, !tbaa !24
  %t53 = load i64, ptr %l48, !tbaa !24
  %t54 = icmp sge i64 %t52, %t53
  store i1 %t54, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb18
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 14
  %t60 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t61)
  store ptr %t64, ptr %l54
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l54, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 11
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  store i1 %t70, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l50, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t73, i64 %t75)
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb112
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 14
  %t81 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t80, i64 %t82)
  store ptr %t85, ptr %l63
  br label %bb23
bb23:
  %t86 = load ptr, ptr %l63, !tbaa !29
  store ptr %t86, ptr %l5, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = trunc i64 %t89 to i32
  %t93 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 7
  %t94 = load i1, ptr %t93, !tbaa !21
  %t98 = call %"compiler/definit:Verdict" @compiler_2fdefinit_2eVerdict_2eJudge(ptr %v0, ptr %t87, i32 %t91, i1 %t94)
  store %"compiler/definit:Verdict" %t98, ptr %l69
  br label %bb24
bb24:
  %t99 = load %"compiler/definit:Verdict", ptr %l69
  store %"compiler/definit:Verdict" %t99, ptr %l6
  %t100 = getelementptr %"compiler/definit:Verdict", ptr %l6, i32 0, i32 0
  %t101 = load i1, ptr %t100, !tbaa !21
  %t103 = getelementptr %"compiler/definit:Verdict", ptr %l6, i32 0, i32 1
  %t104 = load %"compiler/source:Span", ptr %t103
  store %"compiler/source:Span" %t104, ptr %l8
  %t106 = getelementptr %"compiler/definit:Verdict", ptr %l6, i32 0, i32 2
  %t107 = load i32, ptr %t106, !range !{i32 0, i32 6}
  store i32 %t107, ptr %l9
  %t109 = getelementptr %"compiler/definit:Verdict", ptr %l6, i32 0, i32 3
  %t110 = load %"compiler/source:Span", ptr %t109
  store %"compiler/source:Span" %t110, ptr %l10
  %t114 = xor i1 %t101, true
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t116, i64 %t118)
  br label %bb27
bb26:
  br label %bb44
bb27:
  %t121 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 4
  %t122 = load i64, ptr %t121, !tbaa !24
  %t124 = icmp sge i64 %t122, 0
  br i1 %t124, label %bb28, label %bb29
bb28:
  %t126 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 4
  %t127 = load i64, ptr %t126, !tbaa !24
  store i1 true, ptr %l12, !tbaa !21
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 111
  %t135 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eRefMu_H262fdcc49aab606e6e6c369788183545(ptr %v0, ptr %v0, ptr %t131, i64 %t127)
  store ptr %t135, ptr %l84
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t136 = load ptr, ptr %l84, !tbaa !29
  %t138 = load i1, ptr %l12, !tbaa !21
  %t141 = getelementptr %"compiler/check:ValueAsk", ptr %t136, i32 0, i32 6
  store i1 %t138, ptr %t141, !tbaa !21
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t144 = load i32, ptr %t143, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLowers(ptr %v0, ptr %t142, i32 %t144)
  store i1 %t147, ptr %l89
  br label %bb32
bb32:
  %t148 = load i1, ptr %l89, !tbaa !21
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t149 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 3
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb39
bb35:
  store i1 true, ptr %l92, !tbaa !21
  br label %bb38
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t159 = load i32, ptr %t158, !tbaa !23
  %t162 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t157, i32 %t159)
  store i1 %t162, ptr %l97
  br label %bb37
bb37:
  %t163 = load i1, ptr %l97, !tbaa !21
  %t164 = xor i1 %t163, true
  store i1 %t164, ptr %l92, !tbaa !21
  br label %bb38
bb38:
  %t166 = load i1, ptr %l92, !tbaa !21
  store i1 %t166, ptr %l90, !tbaa !21
  br label %bb39
bb39:
  %t167 = load i1, ptr %l90, !tbaa !21
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t168 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 1
  %t169 = load i64, ptr %t168, !tbaa !24
  store i1 true, ptr %l15, !tbaa !21
  %t171 = load ptr, ptr %l5, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Body", ptr %t171, i32 0, i32 7
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v0, ptr %t173, i64 %t169)
  store ptr %t177, ptr %l103
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t178 = load ptr, ptr %l103, !tbaa !29
  %t180 = load i1, ptr %l15, !tbaa !21
  %t183 = getelementptr %"compiler/typed:Local", ptr %t178, i32 0, i32 6
  store i1 %t180, ptr %t183, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb112
bb44:
  %t184 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 3
  %t185 = load i1, ptr %t184, !tbaa !21
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb45, label %bb46
bb45:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 2
  %t191 = load i64, ptr %t190, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t189, i64 %t191)
  br label %bb47
bb46:
  br label %bb52
bb47:
  %t194 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 4
  %t195 = load i64, ptr %t194, !tbaa !24
  %t197 = icmp sge i64 %t195, 0
  br i1 %t197, label %bb48, label %bb49
bb48:
  %t199 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 4
  %t200 = load i64, ptr %t199, !tbaa !24
  %t202 = load ptr, ptr %l5, !tbaa !29
  %t204 = getelementptr %"compiler/typed:Body", ptr %t202, i32 0, i32 3
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = sext i32 %t207 to i64
  %t210 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t211 = load i32, ptr %t210, !tbaa !23
  %t213 = sext i32 %t211 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t214
  %t215 = getelementptr { i64, [3 x i64] }, ptr %t214, i32 0, i32 0
  store i64 3, ptr %t215
  %t217 = insertvalue { i64, i64, i64 } undef, i64 %t205, 0
  %t219 = insertvalue { i64, i64, i64 } %t217, i64 %t209, 1
  %t221 = insertvalue { i64, i64, i64 } %t219, i64 %t213, 2
  %t222 = getelementptr { i64, [3 x i64] }, ptr %t214, i32 0, i32 1
  store { i64, i64, i64 } %t221, ptr %t222
  %t223 = load { i64, [3 x i64] }, ptr %t214
  store { i64, [3 x i64] } %t223, ptr %l18
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 111
  %t231 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eRefMu_H262fdcc49aab606e6e6c369788183545(ptr %v0, ptr %v0, ptr %t227, i64 %t200)
  store ptr %t231, ptr %l123
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t232 = load ptr, ptr %l123, !tbaa !29
  %t234 = load { i64, [3 x i64] }, ptr %l18
  %t237 = getelementptr %"compiler/check:ValueAsk", ptr %t232, i32 0, i32 7
  store { i64, [3 x i64] } %t234, ptr %t237
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb112
bb52:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 2
  %t240 = load i64, ptr %t239, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t238, i64 %t240)
  br label %bb53
bb53:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l128, !tbaa !29
  %t244 = load ptr, ptr %l5, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Body", ptr %t244, i32 0, i32 7
  %t247 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 1
  %t248 = load i64, ptr %t247, !tbaa !24
  %t251 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t246, i64 %t248)
  store %"compiler/typed:Local" %t251, ptr %l132
  br label %bb54
bb54:
  %t252 = getelementptr %"compiler/typed:Local", ptr %l132, i32 0, i32 0
  %t253 = load i32, ptr %t252, !tbaa !23
  %t254 = load ptr, ptr %l128, !tbaa !29
  %t256 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t254, i32 %t253)
  store { i64, ptr } %t256, ptr %l134
  br label %bb55
bb55:
  %t257 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t257, ptr %l20, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l135, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t258, ptr %l136, !tbaa !27
  %t259 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l137, !tbaa !24
  %t261 = load i64, ptr %l137, !tbaa !24
  %t262 = mul i64 %t261, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l138, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = load i64, ptr %l137, !tbaa !24
  %t271 = mul i64 %t270, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t267, ptr %t269, i64 %t271, i1 false)
  %t272 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t272, ptr %l21, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %t273, i32 %t275)
  store i1 %t278, ptr %l141
  br label %bb56
bb56:
  %t279 = load i1, ptr %l141, !tbaa !21
  br i1 %t279, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s10
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l142, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 2
  %t287 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t288 = load i32, ptr %t287, !tbaa !23
  %t291 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t286, i32 %t288)
  store i32 %t291, ptr %l147
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t292 = load ptr, ptr %l142, !tbaa !29
  %t293 = load i32, ptr %l147, !tbaa !23
  %t294 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t292, i32 %t293)
  store { i64, ptr } %t294, ptr %l148
  br label %bb60
bb60:
  %t295 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t297 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = add i64 %t296, %t299
  %t301 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t303 = add i64 %t300, %t302
  %t304 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t303)
  call void @olang_textcopy(ptr %t304, ptr %t295, i64 %t296)
  %t305 = getelementptr i8, ptr %t304, i64 %t296
  call void @olang_textcopy(ptr %t305, ptr %t298, i64 %t299)
  %t306 = getelementptr i8, ptr %t305, i64 %t299
  call void @olang_textcopy(ptr %t306, ptr %t301, i64 %t302)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t304, 1
  store { i64, ptr } %t308, ptr %l149, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l151, !tbaa !24
  %t314 = load i64, ptr %l151, !tbaa !24
  %t315 = icmp eq i64 %t310, %t314
  br i1 %t315, label %bb61, label %bb62
bb61:
  %t317 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = load i64, ptr %l151, !tbaa !24
  %t322 = mul i64 %t321, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t318, ptr %t320, i64 %t322, i1 false)
  br label %bb63
bb62:
  %t323 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t323, ptr %l21, !tbaa !27
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  store i64 -1, ptr %l22, !tbaa !24
  %t324 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 7
  %t325 = load i1, ptr %t324, !tbaa !21
  br i1 %t325, label %bb65, label %bb66
bb65:
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l154, !tbaa !29
  %t328 = load ptr, ptr %l5, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Body", ptr %t328, i32 0, i32 3
  %t331 = load i64, ptr %t330, !tbaa !24
  %t332 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 5
  %t333 = getelementptr %"compiler/source:Span", ptr %t332, i32 0, i32 0
  %t334 = load i32, ptr %t333, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t337 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 5
  %t338 = getelementptr %"compiler/source:Span", ptr %t337, i32 0, i32 1
  %t339 = load i32, ptr %t338, !tbaa !23
  %t341 = sext i32 %t339 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t342
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t342, i32 0, i32 0
  store i64 3, ptr %t343
  %t345 = insertvalue { i64, i64, i64 } undef, i64 %t331, 0
  %t347 = insertvalue { i64, i64, i64 } %t345, i64 %t336, 1
  %t349 = insertvalue { i64, i64, i64 } %t347, i64 %t341, 2
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t342, i32 0, i32 1
  store { i64, i64, i64 } %t349, ptr %t350
  %t351 = load { i64, [3 x i64] }, ptr %t342
  store { i64, [3 x i64] } %t351, ptr %l161
  %t352 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t352, ptr %l162, !tbaa !27
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t355 = load i32, ptr %t354, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t353, i32 %t355)
  store { i64, ptr } %t358, ptr %l165
  br label %bb67
bb66:
  %t359 = load ptr, ptr %l1, !tbaa !29
  store ptr %t359, ptr %l170, !tbaa !29
  %t360 = load ptr, ptr %l5, !tbaa !29
  %t362 = getelementptr %"compiler/typed:Body", ptr %t360, i32 0, i32 3
  %t363 = load i64, ptr %t362, !tbaa !24
  %t364 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t365 = load i32, ptr %t364, !tbaa !23
  %t367 = sext i32 %t365 to i64
  %t368 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t369 = load i32, ptr %t368, !tbaa !23
  %t371 = sext i32 %t369 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t372
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 0
  store i64 3, ptr %t373
  %t375 = insertvalue { i64, i64, i64 } undef, i64 %t363, 0
  %t377 = insertvalue { i64, i64, i64 } %t375, i64 %t367, 1
  %t379 = insertvalue { i64, i64, i64 } %t377, i64 %t371, 2
  %t380 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  store { i64, i64, i64 } %t379, ptr %t380
  %t381 = load { i64, [3 x i64] }, ptr %t372
  store { i64, [3 x i64] } %t381, ptr %l177
  %t382 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t382, ptr %l178, !tbaa !27
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 6
  %t385 = load i32, ptr %t384, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t383, i32 %t385)
  store { i64, ptr } %t388, ptr %l181
  br label %bb70
bb67:
  %t389 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t396 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t397 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t400 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldUnassigned(ptr %v0, ptr %v0, ptr %s3, ptr %v0, { i64, ptr } %t397, { i64, ptr } %t395, { i64, ptr } %t396)
  store %"compiler/diagmsg:Msg" %t400, ptr %l168
  br label %bb68
bb68:
  %t401 = load ptr, ptr %l154, !tbaa !29
  %t402 = load { i64, [3 x i64] }, ptr %l161
  %t403 = load %"compiler/diagmsg:Msg", ptr %l168
  %t404 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t401, { i64, [3 x i64] } %t402, %"compiler/diagmsg:Msg" %t403)
  store i64 %t404, ptr %l169
  br label %bb69
bb69:
  %t405 = load i64, ptr %l169, !tbaa !24
  store i64 %t405, ptr %l22, !tbaa !24
  br label %bb73
bb70:
  %t406 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t406, 0
  %t408 = extractvalue { i64, ptr } %t406, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  %t413 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t417 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadUnassigned(ptr %v0, ptr %v0, ptr %s3, ptr %v0, { i64, ptr } %t414, { i64, ptr } %t412, { i64, ptr } %t413)
  store %"compiler/diagmsg:Msg" %t417, ptr %l184
  br label %bb71
bb71:
  %t418 = load ptr, ptr %l170, !tbaa !29
  %t419 = load { i64, [3 x i64] }, ptr %l177
  %t420 = load %"compiler/diagmsg:Msg", ptr %l184
  %t421 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v0, ptr %t418, { i64, [3 x i64] } %t419, %"compiler/diagmsg:Msg" %t420)
  store i64 %t421, ptr %l185
  br label %bb72
bb72:
  %t422 = load i64, ptr %l185, !tbaa !24
  store i64 %t422, ptr %l22, !tbaa !24
  br label %bb73
bb73:
  %t423 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t425 = trunc i64 0 to i32
  %t426 = icmp eq i32 %t423, %t425
  br i1 %t426, label %bb74, label %bb75
bb74:
  %t428 = getelementptr %"compiler/check:unsetCand", ptr %l4, i32 0, i32 7
  %t429 = load i1, ptr %t428, !tbaa !21
  store i1 %t429, ptr %l188, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb76
bb76:
  %t431 = load i1, ptr %l188, !tbaa !21
  br i1 %t431, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s3)
  br label %bb112
bb78:
  br label %bb79
bb79:
  %t432 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t434 = trunc i64 0 to i32
  %t435 = icmp eq i32 %t432, %t434
  br i1 %t435, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t437 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedDecl(ptr %v0)
  store %"compiler/diagmsg:Msg" %t437, ptr %l193
  br label %bb83
bb83:
  %t438 = load %"compiler/diagmsg:Msg", ptr %l193
  store %"compiler/diagmsg:Msg" %t438, ptr %l190
  br label %bb110
bb84:
  %t439 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t441 = trunc i64 1 to i32
  %t442 = icmp eq i32 %t439, %t441
  br i1 %t442, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t444 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedNoElse(ptr %v0)
  store %"compiler/diagmsg:Msg" %t444, ptr %l196
  br label %bb88
bb88:
  %t445 = load %"compiler/diagmsg:Msg", ptr %l196
  store %"compiler/diagmsg:Msg" %t445, ptr %l190
  br label %bb110
bb89:
  %t446 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t448 = trunc i64 2 to i32
  %t449 = icmp eq i32 %t446, %t448
  br i1 %t449, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t451 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedBranch(ptr %v0)
  store %"compiler/diagmsg:Msg" %t451, ptr %l199
  br label %bb93
bb93:
  %t452 = load %"compiler/diagmsg:Msg", ptr %l199
  store %"compiler/diagmsg:Msg" %t452, ptr %l190
  br label %bb110
bb94:
  %t453 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t455 = trunc i64 3 to i32
  %t456 = icmp eq i32 %t453, %t455
  br i1 %t456, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t458 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedLoop(ptr %v0)
  store %"compiler/diagmsg:Msg" %t458, ptr %l202
  br label %bb98
bb98:
  %t459 = load %"compiler/diagmsg:Msg", ptr %l202
  store %"compiler/diagmsg:Msg" %t459, ptr %l190
  br label %bb110
bb99:
  %t460 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t462 = trunc i64 4 to i32
  %t463 = icmp eq i32 %t460, %t462
  br i1 %t463, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t465 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedArm(ptr %v0)
  store %"compiler/diagmsg:Msg" %t465, ptr %l205
  br label %bb103
bb103:
  %t466 = load %"compiler/diagmsg:Msg", ptr %l205
  store %"compiler/diagmsg:Msg" %t466, ptr %l190
  br label %bb110
bb104:
  %t467 = load i32, ptr %l9, !range !{i32 0, i32 6}
  %t469 = trunc i64 5 to i32
  %t470 = icmp eq i32 %t467, %t469
  br i1 %t470, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t472 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedClause(ptr %v0)
  store %"compiler/diagmsg:Msg" %t472, ptr %l208
  br label %bb108
bb108:
  %t473 = load %"compiler/diagmsg:Msg", ptr %l208
  store %"compiler/diagmsg:Msg" %t473, ptr %l190
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_f865849e169fa2c9_a08c637f3ac5dd5)
  unreachable
bb110:
  %t474 = load %"compiler/diagmsg:Msg", ptr %l190
  %t475 = load ptr, ptr %l1, !tbaa !29
  %t476 = load i64, ptr %l22, !tbaa !24
  %t477 = load ptr, ptr %l5, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Body", ptr %t477, i32 0, i32 3
  %t480 = load i64, ptr %t479, !tbaa !24
  %t481 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t482 = load i32, ptr %t481, !tbaa !23
  %t484 = sext i32 %t482 to i64
  %t485 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t486 = load i32, ptr %t485, !tbaa !23
  %t488 = sext i32 %t486 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t489
  %t490 = getelementptr { i64, [3 x i64] }, ptr %t489, i32 0, i32 0
  store i64 3, ptr %t490
  %t492 = insertvalue { i64, i64, i64 } undef, i64 %t480, 0
  %t494 = insertvalue { i64, i64, i64 } %t492, i64 %t484, 1
  %t496 = insertvalue { i64, i64, i64 } %t494, i64 %t488, 2
  %t497 = getelementptr { i64, [3 x i64] }, ptr %t489, i32 0, i32 1
  store { i64, i64, i64 } %t496, ptr %t497
  %t498 = load { i64, [3 x i64] }, ptr %t489
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v0, ptr %t475, i64 %t476, { i64, [3 x i64] } %t498, %"compiler/diagmsg:Msg" %t474)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s3)
  br label %bb112
bb112:
  %t504 = load i64, ptr %l3, !tbaa !24
  %t506 = add i64 %t504, 1
  store i64 %t506, ptr %l3, !tbaa !24
  br label %bb5
bb113:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca %"compiler/typed:Local"
  %l27 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l32 = alloca %"compiler/typed:Local"
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca i1
  %l75 = alloca i1
  %l78 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l114 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesImmut(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i1 false)
  store i1 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i1, ptr %l12, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l1, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l15, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 8}
  %t15 = icmp eq i64 %t13, 0
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr { i64, [4 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l2, !tbaa !23
  br label %bb9
bb8:
  br label %bb18
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l22
  br label %bb10
bb10:
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = load ptr, ptr %l22, !tbaa !29
  %t29 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t27, i32 %t26)
  store %"compiler/typed:Local" %t29, ptr %l24
  br label %bb11
bb11:
  %t30 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 4
  %t31 = load i32, ptr %t30, !range !{i32 0, i32 7}
  %t33 = trunc i64 5 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t37)
  store ptr %t39, ptr %l30
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb14:
  %t40 = load i32, ptr %l2, !tbaa !23
  %t41 = load ptr, ptr %l30, !tbaa !29
  %t43 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t41, i32 %t40)
  store %"compiler/typed:Local" %t43, ptr %l32
  br label %bb15
bb15:
  %t44 = getelementptr %"compiler/typed:Local", ptr %l32, i32 0, i32 2
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t46, i32 %t45)
  store i1 %t48, ptr %l34
  br label %bb16
bb16:
  %t49 = load i1, ptr %l34, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t52 = load i1, ptr %l27, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l14, !tbaa !21
  br label %bb72
bb18:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t56 = load ptr, ptr %l37, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 1
  store i1 %t62, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l38, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t66, i32 0, i32 2
  %t68 = load i64, ptr %t67
  store i64 %t68, ptr %l3, !tbaa !24
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t72, i32 0, i32 3
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l4, !tbaa !23
  br label %bb23
bb22:
  br label %bb33
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i32, ptr %l4, !tbaa !23
  %t85 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %s3, ptr %t79, i64 %t80, i32 %t81)
  store ptr %t85, ptr %l49
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l49, !tbaa !29
  %t87 = icmp eq ptr %t86, null
  br i1 %t87, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb32
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t93 = load i64, ptr %l3, !tbaa !24
  %t94 = load i32, ptr %l4, !tbaa !23
  %t98 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t92, i64 %t93, i32 %t94)
  store ptr %t98, ptr %l56
  br label %bb27
bb27:
  %t99 = load ptr, ptr %l56, !tbaa !29
  store ptr %t99, ptr %l5, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_238986d309dff67a_df3b69a02a086cde)
  unreachable
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/ast:VarDecl", ptr %t104, i32 0, i32 2
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = call i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %t108)
  store i1 %t110, ptr %l62
  br label %bb31
bb31:
  %t111 = load i1, ptr %l62, !tbaa !21
  store i1 %t111, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t112 = load i1, ptr %l51, !tbaa !21
  store i1 %t112, ptr %l14, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb33:
  %t113 = load ptr, ptr %l1, !tbaa !29
  store ptr %t113, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t114 = load ptr, ptr %l63, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb34, label %bb35
bb34:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 8}
  %t120 = icmp eq i64 %t118, 2
  store i1 %t120, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t121 = load i1, ptr %l64, !tbaa !21
  br i1 %t121, label %bb36, label %bb37
bb36:
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l69, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t132 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t129)
  store i32 %t132, ptr %l72
  br label %bb39
bb39:
  %t133 = load ptr, ptr %l69, !tbaa !29
  %t134 = load i32, ptr %l72, !tbaa !23
  %t135 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t133, i32 %t134)
  store i1 %t135, ptr %l73
  br label %bb40
bb40:
  %t136 = load i1, ptr %l73, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb45
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  store ptr %t144, ptr %l78, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t148 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t145)
  store i32 %t148, ptr %l81
  br label %bb43
bb43:
  %t149 = load ptr, ptr %l78, !tbaa !29
  %t150 = load i32, ptr %l81, !tbaa !23
  %t151 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t149, i32 %t150)
  store i64 %t151, ptr %l82
  br label %bb44
bb44:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t153 = load i64, ptr %l82, !tbaa !24
  %t155 = and i64 %t153, %t152
  %t157 = icmp ne i64 %t155, 0
  store i1 %t157, ptr %l75, !tbaa !21
  br label %bb45
bb45:
  %t159 = load i1, ptr %l75, !tbaa !21
  store i1 %t159, ptr %l14, !tbaa !21
  br label %bb72
bb46:
  %t160 = load ptr, ptr %l1, !tbaa !29
  store ptr %t160, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t161 = load ptr, ptr %l86, !tbaa !29
  %t162 = icmp ne ptr %t161, null
  br i1 %t162, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l86, !tbaa !29
  %t165 = load i64, ptr %t164, !range !{i64 0, i64 8}
  %t167 = icmp eq i64 %t165, 3
  store i1 %t167, ptr %l87, !tbaa !21
  br label %bb48
bb48:
  %t168 = load i1, ptr %l87, !tbaa !21
  br i1 %t168, label %bb49, label %bb50
bb49:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr { i64, [4 x i64] }, ptr %t169, i32 0, i32 1
  %t172 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t171, i32 0, i32 2
  %t173 = load ptr, ptr %t172
  store ptr %t173, ptr %l7, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l7, !tbaa !29
  %t179 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t175, ptr %t176)
  store i1 %t179, ptr %l94
  br label %bb52
bb52:
  %t180 = load i1, ptr %l94, !tbaa !21
  store i1 %t180, ptr %l14, !tbaa !21
  br label %bb72
bb53:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t182 = load ptr, ptr %l95, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb54, label %bb55
bb54:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 8}
  %t188 = icmp eq i64 %t186, 4
  store i1 %t188, ptr %l96, !tbaa !21
  br label %bb55
bb55:
  %t189 = load i1, ptr %l96, !tbaa !21
  br i1 %t189, label %bb56, label %bb57
bb56:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l8, !tbaa !29
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l8, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Elem", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t203 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t196, ptr %t200)
  store i1 %t203, ptr %l104
  br label %bb59
bb59:
  %t204 = load i1, ptr %l104, !tbaa !21
  store i1 %t204, ptr %l14, !tbaa !21
  br label %bb72
bb60:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t206 = load ptr, ptr %l105, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb61, label %bb62
bb61:
  %t209 = load ptr, ptr %l105, !tbaa !29
  %t210 = load i64, ptr %t209, !range !{i64 0, i64 8}
  %t212 = icmp eq i64 %t210, 5
  store i1 %t212, ptr %l106, !tbaa !21
  br label %bb62
bb62:
  %t213 = load i1, ptr %l106, !tbaa !21
  br i1 %t213, label %bb63, label %bb64
bb63:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [4 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t216, i32 0, i32 2
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l9, !tbaa !29
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Payload", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslicedWritable(ptr %v0, ptr %v1, ptr %t220, ptr %t224)
  store i1 %t227, ptr %l114
  br label %bb66
bb66:
  %t228 = load i1, ptr %l114, !tbaa !21
  store i1 %t228, ptr %l14, !tbaa !21
  br label %bb72
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_f7f48d742623e788_feac04c086d410bc)
  unreachable
bb72:
  %t229 = load i1, ptr %l14, !tbaa !21
  store i1 %t229, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotContract(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca i64
  %l22 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l40 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca i32
  %l84 = alloca i64
  %l87 = alloca i64
  %rv = alloca i64
  %t138 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 5}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, i64, i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { i32, i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb30
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l18, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t26, i32 %t27)
  store { i64, ptr } %t30, ptr %l22
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = load i64, ptr %l18, !tbaa !24
  %t35 = srem i64 %t33, %t32
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load i64, ptr %l4, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t40, i32 %t41, i64 %t42)
  store i64 %t46, ptr %l29
  br label %bb7
bb7:
  %t47 = load i64, ptr %l29, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 64
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t53, i64 %t54)
  %t58 = extractvalue { i32, i64 } %t57, 1
  %t59 = extractvalue { i32, i64 } %t57, 0
  store i32 %t59, ptr %l36
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb9, label %ok.61, !prof !99
ok.61:
  store i64 %t58, ptr %l35
  br label %bb8
bb8:
  %t62 = load i64, ptr %l35, !tbaa !24
  store i64 %t62, ptr %l30, !tbaa !24
  br label %bb11
bb9:
  br label %bb10
bb10:
  store i64 -2, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l30, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp ne i64 %t64, -2
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  store i64 -1, ptr %l7, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l44
  br label %bb15
bb15:
  %t79 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr %"compiler/generic:AnySlot", ptr %t83, i64 %t80
  %t85 = load %"compiler/generic:AnySlot", ptr %t84
  %t86 = load ptr, ptr %l40, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v0, ptr %t86, %"compiler/generic:AnySlot" %t85)
  store ptr %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load ptr, ptr %l48, !tbaa !29
  store ptr %t89, ptr %l8, !tbaa !29
  %t90 = load ptr, ptr %l8, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = load ptr, ptr %l8, !tbaa !29
  %t98 = getelementptr %"compiler/ast:Func", ptr %t96, i32 0, i32 3
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Sig", ptr %t99, i32 0, i32 5
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  %t106 = xor i1 %t104, true
  store i1 %t106, ptr %l52, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t108 = load i1, ptr %l52, !tbaa !21
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  store ptr %t114, ptr %l60, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i32, ptr %l2, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t118, i32 %t119)
  store { i64, ptr } %t122, ptr %l64
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t123 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t123, ptr %l65, !tbaa !27
  %t124 = load i64, ptr %l4, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/generic:AnySlot", ptr %t127, i64 %t124
  %t129 = getelementptr %"compiler/generic:AnySlot", ptr %t128, i32 0, i32 1
  %t130 = load i32, ptr %t129, !tbaa !23
  %t131 = load ptr, ptr %l60, !tbaa !29
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t130)
  store i32 %t133, ptr %l68
  br label %bb23
bb23:
  %t134 = load i32, ptr %l68, !tbaa !23
  store i32 %t134, ptr %l9, !tbaa !23
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l69, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t137 = load i64, ptr %l4, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t138
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t138, i32 0, i32 0
  store i64 10, ptr %t139
  %t141 = insertvalue { i32, i64 } undef, i32 %t136, 0
  %t143 = insertvalue { i32, i64 } %t141, i64 %t137, 1
  %t144 = getelementptr { i64, [2 x i64] }, ptr %t138, i32 0, i32 1
  store { i32, i64 } %t143, ptr %t144
  %t145 = load { i64, [2 x i64] }, ptr %t138
  store { i64, [2 x i64] } %t145, ptr %l72
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i32, ptr %l2, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l76
  br label %bb24
bb24:
  %t154 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t154, ptr %l77, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr %"compiler/generic:AnySlot", ptr %t158, i64 %t155
  %t160 = getelementptr %"compiler/generic:AnySlot", ptr %t159, i32 0, i32 5
  %t161 = load i32, ptr %t160, !tbaa !23
  store i32 %t161, ptr %l79, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %l9, !tbaa !23
  %t171 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t167, i32 %t168)
  store i64 %t171, ptr %l84
  br label %bb25
bb25:
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/ast:Func", ptr %t172, i32 0, i32 0
  %t175 = load %"compiler/source:Span", ptr %t174
  %t176 = load ptr, ptr %l69, !tbaa !29
  %t177 = load { i64, [2 x i64] }, ptr %l72
  %t178 = load i32, ptr %l79, !tbaa !23
  %t179 = load i64, ptr %l84, !tbaa !24
  %t181 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t176, { i64, [2 x i64] } %t177, i32 %t178, i64 %t179, %"compiler/source:Span" %t175)
  store i64 %t181, ptr %l87
  br label %bb26
bb26:
  %t182 = load i64, ptr %l87, !tbaa !24
  store i64 %t182, ptr %l7, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 19
  %t186 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t185, i64 %t186, i64 2)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 64
  %t195 = load i64, ptr %l5, !tbaa !24
  %t196 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t194, i64 %t195, i64 %t196)
  br label %bb29
bb29:
  %t200 = load i64, ptr %l7, !tbaa !24
  store i64 %t200, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i64 -1, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_61cd02582a530769_6431634bdc3c1a5d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca i32
  %l38 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l70 = alloca %"compiler/diagmsg:Msg"
  %l71 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca i1
  %l89 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca i32
  %l118 = alloca { i64, ptr }
  %t130 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [5 x i64] }, align 8
  %t229 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v0, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l12, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l15, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t12, ptr %l16
  %t13 = load i1, ptr %l3, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i32 81, ptr %l18
  br label %bb7
bb6:
  store i32 82, ptr %l18
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l22, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l24
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l22, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l24
  %t24 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t22, %"compiler/source:Span" %t23, i64 2)
  store %"compiler/source:Span" %t24, ptr %l25
  br label %bb9
bb9:
  %t25 = icmp sge i64 0, 0
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = icmp sle i64 0, 1152921504606846975
  br i1 %t27, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb12:
  %t29 = mul i64 0, 8
  %t30 = insertvalue { i64, ptr } undef, i64 0, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t32 = load ptr, ptr %l15, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l16
  %t34 = load i32, ptr %l18, !range !{i32 0, i32 114}
  %t35 = load ptr, ptr %l21, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l25
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i32 %t34, ptr %t35, ptr null, %"compiler/source:Span" %t36, i64 -1, { i64, ptr } %t31)
  store i1 %t38, ptr %l29
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce)
  unreachable
bb14:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l30, !tbaa !29
  %t41 = load ptr, ptr %l4, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l33
  br label %bb18
bb18:
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb19
bb19:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t48)
  store i32 %t50, ptr %l35
  br label %bb20
bb20:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t52, i32 %t53)
  store i1 %t56, ptr %l38
  br label %bb21
bb21:
  %t57 = load i1, ptr %l38, !tbaa !21
  %t58 = xor i1 %t57, true
  br i1 %t58, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb23:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l5, !tbaa !23
  %t64 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l43
  br label %bb24
bb24:
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i32, ptr %l5, !tbaa !23
  %t73 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l48
  br label %bb27
bb26:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb28
bb27:
  %t74 = load i1, ptr %l48, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t78 = load i1, ptr %l40, !tbaa !21
  br i1 %t78, label %bb30, label %bb31
bb30:
  %t79 = load i32, ptr %l5, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp ne i32 %t79, %t80
  br i1 %t83, label %bb32, label %bb33
bb31:
  br label %bb44
bb32:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t88 = load i32, ptr %l5, !tbaa !23
  %t89 = load i1, ptr %l3, !tbaa !21
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v0, ptr %t85, %"compiler/source:Span" %t86, ptr %t87, i32 %t88, i1 %t89)
  store i1 %t95, ptr %l59
  br label %bb34
bb33:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb35
bb34:
  %t96 = load i1, ptr %l59, !tbaa !21
  %t97 = xor i1 %t96, true
  store i1 %t97, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t99 = load i1, ptr %l53, !tbaa !21
  br i1 %t99, label %bb36, label %bb37
bb36:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l61, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l62, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t102)
  store %"compiler/source:Span" %t104, ptr %l64
  br label %bb38
bb37:
  br label %bb43
bb38:
  %t105 = load ptr, ptr %l62, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l64
  %t107 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t105, %"compiler/source:Span" %t106, i64 2)
  store %"compiler/source:Span" %t107, ptr %l65
  br label %bb39
bb39:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i32, ptr %l5, !tbaa !23
  %t112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t108, i32 %t109)
  store { i64, ptr } %t112, ptr %l68
  br label %bb40
bb40:
  %t113 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  %t121 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v0, { i64, ptr } %t119)
  store %"compiler/diagmsg:Msg" %t121, ptr %l70
  br label %bb41
bb41:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l65
  %t124 = load %"compiler/diagmsg:Msg", ptr %l70
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t122, %"compiler/source:Span" %t123, %"compiler/diagmsg:Msg" %t124)
  store i64 %t125, ptr %l71
  br label %bb42
bb42:
  br label %bb43
bb43:
  br label %ret
bb44:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 0
  store i64 7, ptr %t131
  %t133 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t128, 0
  %t135 = insertvalue { %"compiler/source:Span", i32 } %t133, i32 %t129, 1
  %t136 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t135, ptr %t136
  %t137 = load { i64, [4 x i64] }, ptr %t130
  %t139 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t137, ptr %t139
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t126, %"compiler/source:Span" %t127, ptr %t139)
  store ptr %t143, ptr %l78
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l78, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l79, !tbaa !29
  %t146 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t146, ptr %l80
  %t147 = load i32, ptr %l5, !tbaa !23
  store i32 %t147, ptr %l81, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l5, !tbaa !23
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l87
  br label %bb46
bb46:
  %t159 = load ptr, ptr %l84, !tbaa !29
  %t160 = load i32, ptr %l87, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t159, i32 %t160)
  store i1 %t161, ptr %l88
  br label %bb47
bb47:
  %t162 = load i1, ptr %l88, !tbaa !21
  br i1 %t162, label %bb48, label %bb49
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l5, !tbaa !23
  %t167 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l92
  br label %bb50
bb49:
  store i64 1, ptr %l89, !tbaa !24
  br label %bb52
bb50:
  %t168 = load i32, ptr %l92, !tbaa !23
  %t169 = call i64 @compiler_2fcheck_2efloatBits(i32 %t168, double 0x3ff0000000000000)
  store i64 %t169, ptr %l93
  br label %bb51
bb51:
  %t170 = load i64, ptr %l93, !tbaa !24
  store i64 %t170, ptr %l89, !tbaa !24
  br label %bb52
bb52:
  %t171 = load ptr, ptr %l79, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l80
  %t173 = load i32, ptr %l81, !tbaa !23
  %t174 = load i64, ptr %l89, !tbaa !24
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t171, %"compiler/source:Span" %t172, i32 %t173, i64 %t174)
  store ptr %t175, ptr %l94
  br label %bb53
bb53:
  %t176 = load ptr, ptr %l94, !tbaa !29
  store ptr %t176, ptr %l7, !tbaa !29
  %t177 = load i1, ptr %l3, !tbaa !21
  br i1 %t177, label %bb54, label %bb55
bb54:
  store i32 3, ptr %l96
  br label %bb56
bb55:
  store i32 4, ptr %l96
  br label %bb56
bb56:
  %t181 = load i32, ptr %l96, !range !{i32 0, i32 52}
  store i32 %t181, ptr %l8
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 36
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l101
  br label %bb57
bb57:
  %t187 = load i64, ptr %l101, !tbaa !24
  store i64 %t187, ptr %l9, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 36
  %t191 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t190, ptr %t191)
  br label %bb58
bb58:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 36
  %t197 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t196, ptr %t197)
  br label %bb59
bb59:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l108, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t201, ptr %l109
  %t202 = load ptr, ptr %l4, !tbaa !29
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t203, ptr %l111
  %t204 = load i32, ptr %l5, !tbaa !23
  store i32 %t204, ptr %l112, !tbaa !23
  %t205 = load i32, ptr %l8, !range !{i32 0, i32 52}
  store i32 %t205, ptr %l113
  store i32 0, ptr %l114
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 36
  %t209 = load i64, ptr %l9, !tbaa !24
  %t212 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t208, i64 %t209)
  store { i64, ptr } %t212, ptr %l118
  br label %bb60
bb60:
  store { i64, [5 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 0
  store i64 9, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l111
  %t216 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t215, 0
  %t217 = load i32, ptr %l112, !tbaa !23
  %t218 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t216, i32 %t217, 1
  %t219 = load i32, ptr %l113, !range !{i32 0, i32 52}
  %t220 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t218, i32 %t219, 2
  %t221 = load i32, ptr %l114, !range !{i32 0, i32 3}
  %t222 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t220, i32 %t221, 3
  %t223 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t224 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t222, { i64, ptr } %t223, 4
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t224, ptr %t225
  %t226 = load { i64, [5 x i64] }, ptr %t213
  %t228 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t226, ptr %t228
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 1, ptr %t230
  %t231 = load %"compiler/source:Span", ptr %l109
  %t232 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t231, 0
  %t233 = load ptr, ptr %l110, !tbaa !29
  %t234 = insertvalue { %"compiler/source:Span", ptr, ptr } %t232, ptr %t233, 1
  %t236 = insertvalue { %"compiler/source:Span", ptr, ptr } %t234, ptr %t228, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  %t241 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t241, ptr %t240)
  br label %bb61
bb61:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, i64, i64 }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, i64, i64, i64, i64 }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %lp44 = alloca ptr
  %l45 = alloca ptr
  %lp46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i32
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i64
  %l91 = alloca ptr
  %l94 = alloca i1
  %l95 = alloca i1
  %l99 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i64
  %l112 = alloca i32
  %l116 = alloca i32
  %l119 = alloca i32
  %l123 = alloca i32
  %l127 = alloca i32
  %l128 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l131 = alloca i32
  %l135 = alloca ptr
  %l136 = alloca ptr
  %l139 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i1
  %l154 = alloca i1
  %l157 = alloca i32
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l167 = alloca %"compiler/diagmsg:Msg"
  %l168 = alloca i64
  %l173 = alloca ptr
  %l176 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l188 = alloca %"compiler/source:Span"
  %l189 = alloca i32
  %l192 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca { i64, ptr }
  %l197 = alloca i32
  %l198 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l211 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l222 = alloca ptr
  %l226 = alloca i64
  %l227 = alloca ptr
  %l228 = alloca ptr
  %l231 = alloca %"compiler/source:Span"
  %l232 = alloca ptr
  %l233 = alloca %"compiler/source:Span"
  %l234 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l239 = alloca %"compiler/source:Span"
  %l240 = alloca %"compiler/source:Span"
  %l241 = alloca i32
  %l245 = alloca { i64, ptr }
  %l246 = alloca %"compiler/typed:Seq"
  %l251 = alloca i1
  %l252 = alloca i1
  %l254 = alloca i1
  %l255 = alloca i1
  %l258 = alloca i32
  %l262 = alloca i1
  %l263 = alloca i64
  %l268 = alloca ptr
  %l269 = alloca %"compiler/source:Span"
  %l270 = alloca i64
  %l273 = alloca { i64, ptr }
  %l276 = alloca %"compiler/diagmsg:Msg"
  %l277 = alloca i64
  %l282 = alloca ptr
  %l285 = alloca ptr
  %l289 = alloca %"compiler/source:Span"
  %l292 = alloca i32
  %l293 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca i32
  %l297 = alloca %"compiler/source:Span"
  %l298 = alloca i32
  %l301 = alloca ptr
  %l303 = alloca i32
  %l304 = alloca { i64, ptr }
  %l306 = alloca i32
  %l308 = alloca i1
  %l309 = alloca ptr
  %l310 = alloca %"compiler/source:Span"
  %l314 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l321 = alloca ptr
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l330 = alloca ptr
  %l335 = alloca ptr
  %l340 = alloca ptr
  %l343 = alloca i1
  %l344 = alloca i1
  %l347 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca %"compiler/source:Span"
  %l350 = alloca %"compiler/diagmsg:Msg"
  %l351 = alloca i64
  %l356 = alloca ptr
  %l359 = alloca i32
  %l367 = alloca i1
  %l369 = alloca ptr
  %l370 = alloca %"compiler/source:Span"
  %l371 = alloca { i64, ptr }
  %l374 = alloca { i64, ptr }
  %l376 = alloca %"compiler/diagmsg:Msg"
  %l377 = alloca i64
  %l382 = alloca ptr
  %l386 = alloca i1
  %l391 = alloca i64
  %l394 = alloca ptr
  %l395 = alloca %"compiler/source:Span"
  %l398 = alloca { i64, ptr }
  %l399 = alloca { i64, ptr }
  %l404 = alloca i64
  %l405 = alloca %"compiler/diagmsg:Msg"
  %l406 = alloca i64
  %l411 = alloca ptr
  %l415 = alloca i1
  %l419 = alloca i64
  %l424 = alloca ptr
  %l425 = alloca %"compiler/source:Span"
  %l426 = alloca i64
  %l429 = alloca { i64, ptr }
  %l432 = alloca %"compiler/diagmsg:Msg"
  %l433 = alloca i64
  %l438 = alloca ptr
  %l443 = alloca ptr
  %l446 = alloca ptr
  %l447 = alloca %"compiler/source:Span"
  %l450 = alloca i32
  %l453 = alloca i32
  %l456 = alloca ptr
  %l458 = alloca ptr
  %l459 = alloca { i64, ptr }
  %l461 = alloca ptr
  %l463 = alloca i32
  %l464 = alloca ptr
  %l467 = alloca i32
  %l473 = alloca ptr
  %l477 = alloca i1
  %l479 = alloca ptr
  %l480 = alloca { i64, ptr }
  %l482 = alloca %"compiler/source:Span"
  %l485 = alloca { i64, ptr }
  %l487 = alloca %"compiler/diagmsg:Msg"
  %l488 = alloca i64
  %l491 = alloca ptr
  %l495 = alloca i32
  %l497 = alloca i32
  %l499 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l502 = alloca %"compiler/source:Span"
  %l504 = alloca i32
  %l507 = alloca ptr
  %l515 = alloca ptr
  %l518 = alloca i32
  %l522 = alloca i1
  %l527 = alloca i1
  %l528 = alloca i1
  %l530 = alloca ptr
  %l532 = alloca ptr
  %l535 = alloca i1
  %l539 = alloca ptr
  %l540 = alloca %"compiler/source:Span"
  %l543 = alloca %"compiler/diagmsg:Msg"
  %l544 = alloca i64
  %l549 = alloca ptr
  %l553 = alloca i32
  %l555 = alloca i32
  %l557 = alloca ptr
  %l558 = alloca %"compiler/source:Span"
  %l559 = alloca i32
  %l560 = alloca i32
  %l564 = alloca ptr
  %l566 = alloca { i64, ptr }
  %l569 = alloca ptr
  %l571 = alloca ptr
  %l574 = alloca i1
  %l575 = alloca i1
  %l579 = alloca i1
  %l582 = alloca i32
  %l585 = alloca i1
  %l587 = alloca ptr
  %l589 = alloca ptr
  %l592 = alloca i1
  %l596 = alloca ptr
  %l598 = alloca ptr
  %l601 = alloca ptr
  %l603 = alloca ptr
  %l604 = alloca %"compiler/source:Span"
  %l605 = alloca i32
  %l606 = alloca i32
  %l610 = alloca ptr
  %l611 = alloca ptr
  %l614 = alloca i1
  %l615 = alloca i1
  %l619 = alloca i1
  %l620 = alloca ptr
  %l623 = alloca i32
  %l624 = alloca i1
  %l625 = alloca i1
  %l628 = alloca i32
  %l631 = alloca i1
  %l633 = alloca ptr
  %l635 = alloca ptr
  %l638 = alloca i1
  %l640 = alloca ptr
  %l644 = alloca ptr
  %l647 = alloca i32
  %l648 = alloca i32
  %l653 = alloca i32
  %l656 = alloca i64
  %l657 = alloca ptr
  %l658 = alloca %"compiler/source:Span"
  %l661 = alloca i32
  %l662 = alloca i64
  %l663 = alloca ptr
  %l664 = alloca %"compiler/source:Span"
  %l667 = alloca i32
  %l671 = alloca ptr
  %l674 = alloca ptr
  %l675 = alloca %"compiler/source:Span"
  %l677 = alloca i32
  %l678 = alloca i64
  %l679 = alloca ptr
  %l680 = alloca %"compiler/source:Span"
  %l683 = alloca i32
  %l684 = alloca ptr
  %l685 = alloca ptr
  %l686 = alloca { i64, ptr }
  %l687 = alloca ptr
  %l689 = alloca i32
  %l690 = alloca ptr
  %l691 = alloca { i64, ptr }
  %l693 = alloca %"compiler/source:Span"
  %l694 = alloca ptr
  %l699 = alloca i64
  %l703 = alloca { i64, i64, i64 }
  %l707 = alloca ptr
  %l708 = alloca %"compiler/source:Span"
  %l709 = alloca ptr
  %l710 = alloca %"compiler/source:Span"
  %l712 = alloca i32
  %l713 = alloca i32
  %l717 = alloca ptr
  %l718 = alloca ptr
  %l719 = alloca { i64, i64, i64, i64, i64 }
  %l725 = alloca %"compiler/source:Span"
  %l726 = alloca i32
  %l730 = alloca ptr
  %l733 = alloca %"compiler/source:Span"
  %l734 = alloca i32
  %l735 = alloca ptr
  %l739 = alloca ptr
  %l741 = alloca %"compiler/typed:Elem"
  %l767 = alloca ptr
  %l768 = alloca %"compiler/source:Span"
  %l769 = alloca i32
  %l773 = alloca ptr
  %l774 = alloca ptr
  %l775 = alloca ptr
  %l779 = alloca i32
  %l781 = alloca %"compiler/typed:Collect"
  %l784 = alloca %"compiler/source:Span"
  %l785 = alloca i32
  %l789 = alloca { i64, ptr }
  %l791 = alloca %"compiler/typed:Seq"
  %l796 = alloca i1
  %l797 = alloca i1
  %l801 = alloca i1
  %l803 = alloca ptr
  %l805 = alloca ptr
  %l808 = alloca i1
  %l810 = alloca ptr
  %l813 = alloca i1
  %l816 = alloca i1
  %l818 = alloca ptr
  %l821 = alloca %"compiler/source:Span"
  %l822 = alloca %"compiler/diagmsg:Msg"
  %l823 = alloca i64
  %l826 = alloca ptr
  %l830 = alloca %"compiler/source:Span"
  %l832 = alloca i32
  %l837 = alloca i1
  %l838 = alloca i1
  %l842 = alloca i1
  %l844 = alloca ptr
  %l846 = alloca ptr
  %l849 = alloca i1
  %l851 = alloca ptr
  %l854 = alloca i1
  %l857 = alloca i1
  %l859 = alloca ptr
  %l862 = alloca %"compiler/source:Span"
  %l863 = alloca %"compiler/diagmsg:Msg"
  %l864 = alloca i64
  %l867 = alloca ptr
  %l871 = alloca i64
  %l872 = alloca ptr
  %l873 = alloca %"compiler/source:Span"
  %l874 = alloca ptr
  %l875 = alloca { i64, ptr }
  %l876 = alloca ptr
  %l877 = alloca { i64, ptr }
  %l879 = alloca %"compiler/source:Span"
  %l880 = alloca %"compiler/source:Span"
  %l881 = alloca i32
  %l885 = alloca { i64, ptr }
  %l886 = alloca %"compiler/typed:Seq"
  %l891 = alloca i1
  %l894 = alloca i1
  %l897 = alloca i1
  %l900 = alloca i1
  %l903 = alloca i1
  %l906 = alloca i1
  %l913 = alloca i1
  %l915 = alloca ptr
  %l916 = alloca %"compiler/source:Span"
  %l919 = alloca { i64, ptr }
  %l921 = alloca %"compiler/diagmsg:Msg"
  %l922 = alloca i64
  %l925 = alloca ptr
  %l929 = alloca ptr
  %l930 = alloca %"compiler/source:Span"
  %l933 = alloca { i64, ptr }
  %l935 = alloca %"compiler/diagmsg:Msg"
  %l936 = alloca i64
  %l939 = alloca ptr
  %l942 = alloca ptr
  %l945 = alloca ptr
  %l948 = alloca %"compiler/source:Span"
  %l949 = alloca %"compiler/diagmsg:Msg"
  %l950 = alloca i64
  %l953 = alloca ptr
  %l955 = alloca ptr
  %l956 = alloca ptr
  %l959 = alloca %"compiler/source:Span"
  %l960 = alloca i1
  %l963 = alloca ptr
  %l973 = alloca i1
  %l976 = alloca i1
  %l978 = alloca ptr
  %l981 = alloca %"compiler/source:Span"
  %l982 = alloca %"compiler/diagmsg:Msg"
  %l983 = alloca i64
  %l986 = alloca ptr
  %l992 = alloca ptr
  %l993 = alloca %"compiler/source:Span"
  %l994 = alloca i64
  %l997 = alloca { i64, ptr }
  %l1000 = alloca %"compiler/diagmsg:Msg"
  %l1001 = alloca i64
  %l1004 = alloca ptr
  %l1008 = alloca i64
  %l1010 = alloca ptr
  %l1011 = alloca %"compiler/source:Span"
  %l1017 = alloca i32
  %l1028 = alloca { i64, ptr }
  %l1032 = alloca ptr
  %l1036 = alloca ptr
  %l1041 = alloca i32
  %l1044 = alloca %"compiler/source:Span"
  %l1045 = alloca i32
  %l1046 = alloca i32
  %l1047 = alloca i32
  %l1051 = alloca { i64, ptr }
  %l1055 = alloca i1
  %l1056 = alloca i1
  %l1062 = alloca i32
  %l1064 = alloca ptr
  %l1067 = alloca i32
  %l1068 = alloca i1
  %l1069 = alloca ptr
  %l1070 = alloca %"compiler/source:Span"
  %l1071 = alloca ptr
  %l1074 = alloca i32
  %l1075 = alloca { i64, ptr }
  %l1077 = alloca %"compiler/diagmsg:Msg"
  %l1078 = alloca i64
  %l1081 = alloca ptr
  %l1084 = alloca ptr
  %l1087 = alloca i32
  %l1088 = alloca i1
  %l1089 = alloca i1
  %l1092 = alloca i1
  %l1093 = alloca ptr
  %l1094 = alloca %"compiler/source:Span"
  %l1095 = alloca ptr
  %l1098 = alloca i32
  %l1099 = alloca { i64, ptr }
  %l1101 = alloca %"compiler/diagmsg:Msg"
  %l1102 = alloca i64
  %l1105 = alloca ptr
  %l1109 = alloca i1
  %l1110 = alloca ptr
  %l1111 = alloca ptr
  %l1112 = alloca %"compiler/source:Span"
  %l1113 = alloca %"compiler/source:Span"
  %l1118 = alloca i32
  %l1122 = alloca ptr
  %l1125 = alloca i1
  %l1129 = alloca ptr
  %l1132 = alloca i32
  %l1134 = alloca %"compiler/source:Span"
  %l1137 = alloca i64
  %l1141 = alloca %"compiler/source:Span"
  %l1144 = alloca i32
  %l1145 = alloca i32
  %l1149 = alloca { i64, ptr }
  %l1153 = alloca i32
  %l1155 = alloca %"compiler/typed:Make"
  %l1160 = alloca i1
  %l1161 = alloca i1
  %l1169 = alloca ptr
  %l1170 = alloca %"compiler/source:Span"
  %l1171 = alloca ptr
  %l1172 = alloca %"compiler/source:Span"
  %l1174 = alloca i32
  %l1178 = alloca ptr
  %l1179 = alloca ptr
  %l1183 = alloca ptr
  %l1184 = alloca { i64, ptr }
  %l1185 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %rv = alloca ptr
  %t239 = alloca { i64, [4 x i64] }, align 8
  %t375 = alloca { i64, [5 x i64] }, align 8
  %t474 = alloca { i64, [4 x i64] }, align 8
  %t1231 = alloca { i64, [3 x i64] }, align 8
  %t1286 = alloca { i64, [3 x i64] }, align 8
  %t1371 = alloca { i64, [4 x i64] }, align 8
  %t1400 = alloca { i64, [4 x i64] }, align 8
  %t1422 = alloca { i64, [5 x i64] }, align 8
  %t1434 = alloca { i64, [3 x i64] }, align 8
  %t1496 = alloca { i64, [5 x i64] }, align 8
  %t1524 = alloca { i64, [5 x i64] }, align 8
  %t1608 = alloca { i64, [5 x i64] }, align 8
  %t1722 = alloca { i64, [5 x i64] }, align 8
  %t1984 = alloca { i64, [5 x i64] }, align 8
  %t2056 = alloca { i64, [5 x i64] }, align 8
  %t2206 = alloca { i64, [4 x i64] }, align 8
  %t2281 = alloca { i64, [5 x i64] }, align 8
  %t2325 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l63, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2)
  store i32 %t5, ptr %l66
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l63, !tbaa !29
  %t7 = load i32, ptr %l66, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l67
  br label %bb2
bb2:
  %t9 = load i32, ptr %l67, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l7, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l70
  br label %bb3
bb3:
  %t15 = load i32, ptr %l70, !tbaa !23
  store i32 %t15, ptr %l8, !tbaa !23
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t18, ptr %l72
  br label %bb4
bb4:
  %t19 = load i1, ptr %l72, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t24 = icmp sgt i64 %t22, 0
  store i1 %t24, ptr %l73, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l73, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l8, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l82
  br label %bb10
bb9:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb11
bb10:
  %t37 = load i1, ptr %l82, !tbaa !21
  store i1 %t37, ptr %l77, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l77, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l83, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t40, ptr %l84
  %t41 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v0, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t41, ptr %l85
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t42 = load ptr, ptr %l83, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l84
  %t44 = load %"compiler/diagmsg:Msg", ptr %l85
  %t45 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t42, %"compiler/source:Span" %t43, %"compiler/diagmsg:Msg" %t44)
  store i64 %t45, ptr %l86
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t46, { i64, ptr } %t47)
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t50, %"compiler/source:Span" %t51)
  store ptr %t54, ptr %l91
  br label %bb17
bb17:
  %t55 = load ptr, ptr %l91, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb18:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t59, ptr %l94
  br label %bb19
bb19:
  %t60 = load i1, ptr %l94, !tbaa !21
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t61 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp eq i64 %t63, 0
  store i1 %t65, ptr %l95, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb22
bb22:
  %t67 = load i1, ptr %l95, !tbaa !21
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l8, !tbaa !23
  %t77 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t73, i32 %t74)
  store i1 %t77, ptr %l104
  br label %bb25
bb24:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb26
bb25:
  %t78 = load i1, ptr %l104, !tbaa !21
  store i1 %t78, ptr %l99, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l99, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l8, !tbaa !23
  %t89 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t85, i32 %t86)
  store i64 %t89, ptr %l109
  br label %bb29
bb28:
  br label %bb41
bb29:
  %t90 = load i64, ptr %l109, !tbaa !24
  store i64 %t90, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = icmp eq i64 %t91, 64
  br i1 %t93, label %bb30, label %bb31
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 2
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t100, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i32 %t102, ptr %l116
  br label %bb32
bb31:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t105 = icmp eq i64 %t103, 32
  br i1 %t105, label %bb33, label %bb34
bb32:
  %t107 = load i32, ptr %l116, !tbaa !23
  store i32 %t107, ptr %l112, !tbaa !23
  br label %bb38
bb33:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t113, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i32 %t115, ptr %l123
  br label %bb35
bb34:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s2, ptr %t121, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i32 %t123, ptr %l127
  br label %bb36
bb35:
  %t124 = load i32, ptr %l123, !tbaa !23
  store i32 %t124, ptr %l119, !tbaa !23
  br label %bb37
bb36:
  %t125 = load i32, ptr %l127, !tbaa !23
  store i32 %t125, ptr %l119, !tbaa !23
  br label %bb37
bb37:
  %t126 = load i32, ptr %l119, !tbaa !23
  store i32 %t126, ptr %l112, !tbaa !23
  br label %bb38
bb38:
  %t127 = load i32, ptr %l112, !tbaa !23
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l128, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l129
  store i32 %t127, ptr %l130, !tbaa !23
  store i32 21, ptr %l131
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l1
  %t137 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v2, ptr %t131, ptr %t132, %"compiler/source:Span" %t133)
  store ptr %t137, ptr %l135
  br label %bb39
bb39:
  %t138 = load ptr, ptr %l128, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l129
  %t140 = load i32, ptr %l130, !tbaa !23
  %t141 = load i32, ptr %l131, !range !{i32 0, i32 52}
  %t142 = load ptr, ptr %l135, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v2, ptr %v0, ptr %v5, ptr %t138, %"compiler/source:Span" %t139, i32 %t140, i32 %t141, ptr %t142, ptr null)
  store ptr %t143, ptr %l136
  br label %bb40
bb40:
  %t144 = load ptr, ptr %l136, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t144, ptr %rv
  br label %ret
bb41:
  %t146 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t146, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t148, ptr %l139
  br label %bb42
bb42:
  %t149 = load i1, ptr %l139, !tbaa !21
  br i1 %t149, label %bb43, label %bb44
bb43:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l7, !tbaa !23
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l143
  br label %bb45
bb44:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb46
bb45:
  %t155 = load i1, ptr %l143, !tbaa !21
  store i1 %t155, ptr %l140, !tbaa !21
  br label %bb46
bb46:
  %t156 = load i1, ptr %l140, !tbaa !21
  br i1 %t156, label %bb47, label %bb48
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load %"compiler/source:Span", ptr %l2
  %t160 = load i32, ptr %l7, !tbaa !23
  %t161 = load ptr, ptr %l4, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v2, ptr %v4, ptr %v5, ptr %t157, %"compiler/source:Span" %t158, %"compiler/source:Span" %t159, i32 %t160, ptr %t161, { i64, ptr } %t162)
  store ptr %t169, ptr %l150
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t170 = load ptr, ptr %l150, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t170, ptr %rv
  br label %ret
bb50:
  %t172 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t172, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t174, ptr %l153
  br label %bb51
bb51:
  %t175 = load i1, ptr %l153, !tbaa !21
  br i1 %t175, label %bb52, label %bb53
bb52:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l7, !tbaa !23
  %t180 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l157
  br label %bb54
bb53:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb55
bb54:
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t182 = load i32, ptr %l157, !tbaa !23
  %t184 = icmp ne i32 %t182, %t181
  store i1 %t184, ptr %l154, !tbaa !21
  br label %bb55
bb55:
  %t186 = load i1, ptr %l154, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s4
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = icmp ne i64 %t189, 2
  br i1 %t191, label %bb58, label %bb59
bb57:
  br label %bb97
bb58:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l163, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t194, ptr %l164
  %t195 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t199 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 2, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, i64 %t197)
  store %"compiler/diagmsg:Msg" %t199, ptr %l167
  br label %bb60
bb59:
  br label %bb64
bb60:
  %t200 = load ptr, ptr %l163, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l164
  %t202 = load %"compiler/diagmsg:Msg", ptr %l167
  %t203 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t200, %"compiler/source:Span" %t201, %"compiler/diagmsg:Msg" %t202)
  store i64 %t203, ptr %l168
  br label %bb61
bb61:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t204, { i64, ptr } %t205)
  br label %bb62
bb62:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l1
  %t212 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t208, %"compiler/source:Span" %t209)
  store ptr %t212, ptr %l173
  br label %bb63
bb63:
  %t213 = load ptr, ptr %l173, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t213, ptr %rv
  br label %ret
bb64:
  %t215 = load ptr, ptr %l4, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t215)
  store ptr %t217, ptr %l176
  br label %bb65
bb65:
  %t218 = load ptr, ptr %l176, !tbaa !29
  store ptr %t218, ptr %l11, !tbaa !29
  %t219 = load ptr, ptr %l11, !tbaa !29
  %t221 = icmp eq ptr %t219, null
  br i1 %t221, label %bb66, label %bb67
bb66:
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t225 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t223)
  store %"compiler/source:Span" %t225, ptr %l180
  br label %bb68
bb67:
  br label %bb72
bb68:
  %t226 = load ptr, ptr %l4, !tbaa !29
  %t229 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t226)
  store i32 %t229, ptr %l183
  br label %bb69
bb69:
  %t230 = load ptr, ptr %l4, !tbaa !29
  store ptr %t230, ptr %l184, !tbaa !29
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l185, !tbaa !29
  store i32 8, ptr %l186
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t232)
  store %"compiler/source:Span" %t234, ptr %l188
  br label %bb70
bb70:
  %t235 = load ptr, ptr %l185, !tbaa !29
  %t236 = load i32, ptr %l186, !range !{i32 0, i32 9}
  %t237 = load %"compiler/source:Span", ptr %l188
  %t238 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t235, i32 %t236, %"compiler/source:Span" %t237)
  store i32 %t238, ptr %l189
  br label %bb71
bb71:
  store { i64, [4 x i64] } zeroinitializer, ptr %t239
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 0
  store i64 6, ptr %t240
  %t241 = load %"compiler/source:Span", ptr %l180
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t241, 0
  %t243 = load i32, ptr %l183, !tbaa !23
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t242, i32 %t243, 1
  %t245 = load ptr, ptr %l184, !tbaa !29
  %t246 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t244, ptr %t245, 2
  %t247 = load i32, ptr %l189, !tbaa !23
  %t248 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t246, i32 %t247, 3
  %t249 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t248, ptr %t249
  %t250 = load { i64, [4 x i64] }, ptr %t239
  %t252 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store { i64, [4 x i64] } %t250, ptr %t252
  store ptr %t252, ptr %l11, !tbaa !29
  br label %bb72
bb72:
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l192, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %t255)
  store i32 %t257, ptr %l194
  br label %bb73
bb73:
  %t258 = mul i64 1, 4
  %t259 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 1, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l195, !tbaa !27
  %t262 = load i32, ptr %l194, !tbaa !23
  %t263 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 0
  store i32 %t262, ptr %t265, !tbaa !33
  %t266 = load %"compiler/source:Span", ptr %l2
  %t267 = load ptr, ptr %l192, !tbaa !29
  %t268 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s4, ptr %t267, { i64, ptr } %t268, %"compiler/source:Span" %t266, i1 false)
  store i32 %t270, ptr %l197
  br label %bb74
bb74:
  %t271 = load i32, ptr %l197, !range !{i32 0, i32 3}
  store i32 %t271, ptr %l12
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l198, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t273, ptr %l199
  %t274 = load ptr, ptr %l11, !tbaa !29
  %t276 = icmp eq ptr %t274, null
  br i1 %t276, label %bb75, label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_abac8132a300fc4a_61eef78091b78ca6)
  unreachable
bb76:
  br label %bb77
bb77:
  %t278 = load ptr, ptr %l11, !tbaa !29
  store ptr %t278, ptr %l202, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t279, ptr %l203, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  store i64 %t281, ptr %l204, !tbaa !24
  %t282 = icmp sge i64 0, 0
  br i1 %t282, label %bb78, label %bb79
bb78:
  %t284 = icmp sle i64 0, 1
  br i1 %t284, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_740060cd3c65d53f_5a6edac2e2ccbc3b)
  unreachable
bb80:
  %t286 = load i64, ptr %l204, !tbaa !24
  %t287 = icmp sle i64 1, %t286
  br i1 %t287, label %bb82, label %bb83
bb81:
  call void @__olang_check_failed(ptr @olang_loc_740060cd3c65d53f_5a6edac2e2ccbc3b)
  unreachable
bb82:
  %t289 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr ptr, ptr %t290, i64 0
  %t293 = insertvalue { i64, ptr } undef, i64 1, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  %t295 = load i32, ptr %l12, !range !{i32 0, i32 3}
  %t296 = load ptr, ptr %l198, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l199
  %t298 = load ptr, ptr %l202, !tbaa !29
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v5, ptr %v4, ptr %v5, ptr %t296, %"compiler/source:Span" %t297, ptr %t298, { i64, ptr } %t294, i32 %t295)
  store ptr %t301, ptr %l211
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_740060cd3c65d53f_5a6edac2e2ccbc3b)
  unreachable
bb84:
  %t302 = load ptr, ptr %l211, !tbaa !29
  store ptr %t302, ptr %l13, !tbaa !29
  %t303 = load ptr, ptr %l13, !tbaa !29
  %t305 = icmp eq ptr %t303, null
  br i1 %t305, label %bb85, label %bb86
bb85:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t308, ptr %l215, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 1
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t314 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t318 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v4, ptr %v0, ptr %t307, ptr %t312, i32 %t314)
  store ptr %t318, ptr %l219
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l1
  %t323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t319, %"compiler/source:Span" %t320)
  store ptr %t323, ptr %l222
  br label %bb88
bb88:
  %t324 = load ptr, ptr %l222, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t324, ptr %rv
  br label %ret
bb89:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 37
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t328)
  store i64 %t330, ptr %l226
  br label %bb90
bb90:
  %t331 = load i64, ptr %l226, !tbaa !24
  store i64 %t331, ptr %l14, !tbaa !24
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l227, !tbaa !29
  %t333 = load ptr, ptr %l13, !tbaa !29
  store ptr %t333, ptr %l228, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t338 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %t334, ptr %t335)
  store %"compiler/source:Span" %t338, ptr %l231
  br label %bb91
bb91:
  %t339 = load ptr, ptr %l227, !tbaa !29
  %t340 = load ptr, ptr %l228, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l231
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v5, ptr %t339, ptr %t340, %"compiler/source:Span" %t341)
  br label %bb92
bb92:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l232, !tbaa !29
  %t343 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t343, ptr %l233
  %t344 = load ptr, ptr %l13, !tbaa !29
  store ptr %t344, ptr %l234, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t345, ptr %l235, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr ptr, ptr %t347, i64 1
  %t349 = load ptr, ptr %t348, !tbaa !39
  store ptr %t349, ptr %l236, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t350, ptr %l237, !tbaa !27
  %t351 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = getelementptr ptr, ptr %t352, i64 1
  %t354 = load ptr, ptr %t353, !tbaa !39
  %t356 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t354)
  store %"compiler/source:Span" %t356, ptr %l239
  br label %bb93
bb93:
  %t357 = load ptr, ptr %l232, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l233
  %t359 = load ptr, ptr %l234, !tbaa !29
  %t360 = load ptr, ptr %l236, !tbaa !29
  %t361 = load %"compiler/source:Span", ptr %l239
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v5, ptr %v4, ptr %s4, ptr %t357, %"compiler/source:Span" %t358, ptr %t359, ptr %t360, %"compiler/source:Span" %t361, ptr null, i1 false)
  br label %bb94
bb94:
  %t362 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t362, ptr %l240
  %t363 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t363, ptr %l241, !tbaa !23
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr %"compiler/check:Checker", ptr %t364, i32 0, i32 37
  %t367 = load i64, ptr %l14, !tbaa !24
  %t370 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t366, i64 %t367)
  store { i64, ptr } %t370, ptr %l245
  br label %bb95
bb95:
  %t371 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t372 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v5, ptr %v5, { i64, ptr } %t371, ptr null, i1 false)
  store %"compiler/typed:Seq" %t372, ptr %l246
  br label %bb96
bb96:
  %t373 = load %"compiler/typed:Seq", ptr %l246
  %t374 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Seq" %t373, ptr %t374
  store { i64, [5 x i64] } zeroinitializer, ptr %t375
  %t376 = getelementptr { i64, [5 x i64] }, ptr %t375, i32 0, i32 0
  store i64 12, ptr %t376
  %t377 = load %"compiler/source:Span", ptr %l240
  %t378 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t377, 0
  %t379 = load i32, ptr %l241, !tbaa !23
  %t380 = insertvalue { %"compiler/source:Span", i32, ptr } %t378, i32 %t379, 1
  %t382 = insertvalue { %"compiler/source:Span", i32, ptr } %t380, ptr %t374, 2
  %t383 = getelementptr { i64, [5 x i64] }, ptr %t375, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t382, ptr %t383
  %t384 = load { i64, [5 x i64] }, ptr %t375
  %t386 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t384, ptr %t386
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t386, ptr %rv
  br label %ret
bb97:
  %t388 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t390 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t388, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t390, ptr %l251
  br label %bb98
bb98:
  %t391 = load i1, ptr %l251, !tbaa !21
  br i1 %t391, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l252, !tbaa !21
  br label %bb102
bb100:
  %t392 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t394 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t392, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t394, ptr %l254
  br label %bb101
bb101:
  %t395 = load i1, ptr %l254, !tbaa !21
  store i1 %t395, ptr %l252, !tbaa !21
  br label %bb102
bb102:
  %t396 = load i1, ptr %l252, !tbaa !21
  br i1 %t396, label %bb103, label %bb104
bb103:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l7, !tbaa !23
  %t401 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t397, i32 %t398)
  store i32 %t401, ptr %l258
  br label %bb105
bb104:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb106
bb105:
  %t402 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t403 = load i32, ptr %l258, !tbaa !23
  %t405 = icmp ne i32 %t403, %t402
  store i1 %t405, ptr %l255, !tbaa !21
  br label %bb106
bb106:
  %t407 = load i1, ptr %l255, !tbaa !21
  br i1 %t407, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s8
  %t408 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t410 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s8, { i64, ptr } %t408, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t410, ptr %l262
  br label %bb109
bb108:
  br label %bb150
bb109:
  %t411 = load i1, ptr %l262, !tbaa !21
  br i1 %t411, label %bb110, label %bb111
bb110:
  store i64 1, ptr %l263, !tbaa !24
  br label %bb112
bb111:
  store i64 2, ptr %l263, !tbaa !24
  br label %bb112
bb112:
  %t412 = load i64, ptr %l263, !tbaa !24
  store i64 %t412, ptr %l15, !tbaa !24
  %t413 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = load i64, ptr %l15, !tbaa !24
  %t419 = icmp ne i64 %t415, %t416
  br i1 %t419, label %bb113, label %bb114
bb113:
  %t421 = load ptr, ptr %l0, !tbaa !29
  store ptr %t421, ptr %l268, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t422, ptr %l269
  %t423 = load i64, ptr %l15, !tbaa !24
  store i64 %t423, ptr %l270, !tbaa !24
  %t424 = load i64, ptr %l15, !tbaa !24
  %t426 = icmp eq i64 %t424, 1
  br i1 %t426, label %bb115, label %bb116
bb114:
  br label %bb122
bb115:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l273, !tbaa !27
  br label %bb117
bb116:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l273, !tbaa !27
  br label %bb117
bb117:
  %t428 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t431 = load i64, ptr %l270, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t434 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 %t431, { i64, ptr } %t432, i64 %t430)
  store %"compiler/diagmsg:Msg" %t434, ptr %l276
  br label %bb118
bb118:
  %t435 = load ptr, ptr %l268, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l269
  %t437 = load %"compiler/diagmsg:Msg", ptr %l276
  %t438 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t435, %"compiler/source:Span" %t436, %"compiler/diagmsg:Msg" %t437)
  store i64 %t438, ptr %l277
  br label %bb119
bb119:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t439, { i64, ptr } %t440)
  br label %bb120
bb120:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l1
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t443, %"compiler/source:Span" %t444)
  store ptr %t447, ptr %l282
  br label %bb121
bb121:
  %t448 = load ptr, ptr %l282, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t448, ptr %rv
  br label %ret
bb122:
  %t450 = load ptr, ptr %l4, !tbaa !29
  %t452 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t450)
  store ptr %t452, ptr %l285
  br label %bb123
bb123:
  %t453 = load ptr, ptr %l285, !tbaa !29
  store ptr %t453, ptr %l16, !tbaa !29
  %t454 = load ptr, ptr %l16, !tbaa !29
  %t456 = icmp eq ptr %t454, null
  br i1 %t456, label %bb124, label %bb125
bb124:
  %t458 = load ptr, ptr %l3, !tbaa !29
  %t460 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t458)
  store %"compiler/source:Span" %t460, ptr %l289
  br label %bb126
bb125:
  br label %bb130
bb126:
  %t461 = load ptr, ptr %l4, !tbaa !29
  %t464 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t461)
  store i32 %t464, ptr %l292
  br label %bb127
bb127:
  %t465 = load ptr, ptr %l4, !tbaa !29
  store ptr %t465, ptr %l293, !tbaa !29
  %t466 = load ptr, ptr %l0, !tbaa !29
  store ptr %t466, ptr %l294, !tbaa !29
  store i32 8, ptr %l295
  %t467 = load ptr, ptr %l3, !tbaa !29
  %t469 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t467)
  store %"compiler/source:Span" %t469, ptr %l297
  br label %bb128
bb128:
  %t470 = load ptr, ptr %l294, !tbaa !29
  %t471 = load i32, ptr %l295, !range !{i32 0, i32 9}
  %t472 = load %"compiler/source:Span", ptr %l297
  %t473 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t470, i32 %t471, %"compiler/source:Span" %t472)
  store i32 %t473, ptr %l298
  br label %bb129
bb129:
  store { i64, [4 x i64] } zeroinitializer, ptr %t474
  %t475 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 0
  store i64 6, ptr %t475
  %t476 = load %"compiler/source:Span", ptr %l289
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t476, 0
  %t478 = load i32, ptr %l292, !tbaa !23
  %t479 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t477, i32 %t478, 1
  %t480 = load ptr, ptr %l293, !tbaa !29
  %t481 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t479, ptr %t480, 2
  %t482 = load i32, ptr %l298, !tbaa !23
  %t483 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t481, i32 %t482, 3
  %t484 = getelementptr { i64, [4 x i64] }, ptr %t474, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t483, ptr %t484
  %t485 = load { i64, [4 x i64] }, ptr %t474
  %t487 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store { i64, [4 x i64] } %t485, ptr %t487
  store ptr %t487, ptr %l16, !tbaa !29
  br label %bb130
bb130:
  %t489 = load ptr, ptr %l0, !tbaa !29
  store ptr %t489, ptr %l301, !tbaa !29
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %t490)
  store i32 %t492, ptr %l303
  br label %bb131
bb131:
  %t493 = mul i64 1, 4
  %t494 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t493)
  %t495 = insertvalue { i64, ptr } undef, i64 1, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  store { i64, ptr } %t496, ptr %l304, !tbaa !27
  %t497 = load i32, ptr %l303, !tbaa !23
  %t498 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !27
  %t500 = getelementptr i32, ptr %t499, i64 0
  store i32 %t497, ptr %t500, !tbaa !33
  %t501 = load %"compiler/source:Span", ptr %l2
  %t502 = load ptr, ptr %l301, !tbaa !29
  %t503 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t505 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s8, ptr %t502, { i64, ptr } %t503, %"compiler/source:Span" %t501, i1 false)
  store i32 %t505, ptr %l306
  br label %bb132
bb132:
  %t506 = load i32, ptr %l306, !range !{i32 0, i32 3}
  store i32 %t506, ptr %l17
  %t507 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t509 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s8, { i64, ptr } %t507, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t509, ptr %l308
  br label %bb133
bb133:
  %t510 = load i1, ptr %l308, !tbaa !21
  br i1 %t510, label %bb134, label %bb135
bb134:
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l309, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t512, ptr %l310
  %t513 = load ptr, ptr %l16, !tbaa !29
  %t515 = icmp eq ptr %t513, null
  br i1 %t515, label %bb136, label %bb137
bb135:
  br label %bb140
bb136:
  call void @__olang_check_failed(ptr @olang_loc_2cb8a0e94f65b35c_b9489d26c7426678)
  unreachable
bb137:
  br label %bb138
bb138:
  %t517 = load ptr, ptr %l16, !tbaa !29
  %t518 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t518, ptr %l314, !tbaa !27
  %t519 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr ptr, ptr %t520, i64 0
  %t522 = load ptr, ptr %t521, !tbaa !39
  %t524 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t524, ptr %l317, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l317, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr ptr, ptr %t526, i64 1
  %t528 = load ptr, ptr %t527, !tbaa !39
  %t530 = load i32, ptr %l17, !range !{i32 0, i32 3}
  %t531 = load ptr, ptr %l309, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l310
  %t537 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v5, ptr %v4, ptr %v4, ptr %v5, ptr %t531, %"compiler/source:Span" %t532, ptr %t517, ptr %t522, ptr %t528, i32 %t530)
  store ptr %t537, ptr %l321
  br label %bb139
bb139:
  %t538 = load ptr, ptr %l321, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t538, ptr %rv
  br label %ret
bb140:
  %t540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t540, ptr %l323, !tbaa !29
  %t541 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t541, ptr %l324
  %t542 = load ptr, ptr %l16, !tbaa !29
  %t544 = icmp eq ptr %t542, null
  br i1 %t544, label %bb141, label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_56b27b3a434e6e4b_829f47044d523297)
  unreachable
bb142:
  br label %bb143
bb143:
  %t546 = load ptr, ptr %l16, !tbaa !29
  %t547 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t548 = load i32, ptr %l17, !range !{i32 0, i32 3}
  %t549 = load ptr, ptr %l323, !tbaa !29
  %t550 = load %"compiler/source:Span", ptr %l324
  %t554 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v5, ptr %v4, ptr %v5, ptr %t549, %"compiler/source:Span" %t550, ptr %t546, { i64, ptr } %t547, i32 %t548)
  store ptr %t554, ptr %l330
  br label %bb144
bb144:
  %t555 = load ptr, ptr %l330, !tbaa !29
  store ptr %t555, ptr %l18, !tbaa !29
  %t556 = load ptr, ptr %l18, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb145, label %bb146
bb145:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t561 = load %"compiler/source:Span", ptr %l1
  %t564 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t560, %"compiler/source:Span" %t561)
  store ptr %t564, ptr %l335
  br label %bb147
bb146:
  br label %bb148
bb147:
  %t565 = load ptr, ptr %l335, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t565, ptr %rv
  br label %ret
bb148:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l1
  %t569 = load ptr, ptr %l18, !tbaa !29
  %t573 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v5, ptr %v5, ptr %t567, %"compiler/source:Span" %t568, ptr %t569)
  store ptr %t573, ptr %l340
  br label %bb149
bb149:
  %t574 = load ptr, ptr %l340, !tbaa !29
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t574, ptr %rv
  br label %ret
bb150:
  %t576 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t578 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t576, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t578, ptr %l343
  br label %bb151
bb151:
  %t579 = load i1, ptr %l343, !tbaa !21
  br i1 %t579, label %bb152, label %bb153
bb152:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t581 = load i32, ptr %l7, !tbaa !23
  %t584 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t580, i32 %t581)
  store i1 %t584, ptr %l347
  br label %bb154
bb153:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb155
bb154:
  %t585 = load i1, ptr %l347, !tbaa !21
  store i1 %t585, ptr %l344, !tbaa !21
  br label %bb155
bb155:
  %t586 = load i1, ptr %l344, !tbaa !21
  br i1 %t586, label %bb156, label %bb157
bb156:
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l348, !tbaa !29
  %t588 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t588, ptr %l349
  %t589 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNeedsType(ptr %v0)
  store %"compiler/diagmsg:Msg" %t589, ptr %l350
  br label %bb158
bb157:
  br label %bb162
bb158:
  %t590 = load ptr, ptr %l348, !tbaa !29
  %t591 = load %"compiler/source:Span", ptr %l349
  %t592 = load %"compiler/diagmsg:Msg", ptr %l350
  %t593 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t590, %"compiler/source:Span" %t591, %"compiler/diagmsg:Msg" %t592)
  store i64 %t593, ptr %l351
  br label %bb159
bb159:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t594, { i64, ptr } %t595)
  br label %bb160
bb160:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l1
  %t602 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t598, %"compiler/source:Span" %t599)
  store ptr %t602, ptr %l356
  br label %bb161
bb161:
  %t603 = load ptr, ptr %l356, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t603, ptr %rv
  br label %ret
bb162:
  %t605 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t607 = call i32 @compiler_2fcheck_2ebitOp(ptr %v3, { i64, ptr } %t605)
  store i32 %t607, ptr %l359
  br label %bb163
bb163:
  %t608 = load i32, ptr %l359, !range !{i32 0, i32 52}
  store i32 %t608, ptr %l19
  %t609 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t611 = trunc i64 29 to i32
  %t612 = icmp eq i32 %t609, %t611
  %t614 = xor i1 %t612, true
  br i1 %t614, label %bb164, label %bb165
bb164:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/check:Checker", ptr %t616, i32 0, i32 1
  %t619 = load ptr, ptr %t618, !tbaa !29
  %t621 = getelementptr %"compiler/generic:Program", ptr %t619, i32 0, i32 2
  %t622 = load i32, ptr %l8, !tbaa !23
  %t625 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t621, i32 %t622)
  store i1 %t625, ptr %l367
  br label %bb166
bb165:
  br label %bb238
bb166:
  %t626 = load i1, ptr %l367, !tbaa !21
  %t627 = xor i1 %t626, true
  br i1 %t627, label %bb167, label %bb168
bb167:
  %t629 = load ptr, ptr %l0, !tbaa !29
  store ptr %t629, ptr %l369, !tbaa !29
  %t630 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t630, ptr %l370
  %t631 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t631, ptr %l371, !tbaa !27
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = load i32, ptr %l7, !tbaa !23
  %t636 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t632, i32 %t633)
  store { i64, ptr } %t636, ptr %l374
  br label %bb169
bb168:
  br label %bb174
bb169:
  %t637 = load { i64, ptr }, ptr %l374, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t637, 0
  %t639 = extractvalue { i64, ptr } %t637, 1
  %t640 = mul i64 %t638, 1
  %t641 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t640)
  call void @llvm.memcpy.p0.p0.i64(ptr %t641, ptr %t639, i64 %t640, i1 false)
  %t642 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t641, 1
  %t644 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t646 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v3, ptr %v0, ptr %v0, { i64, ptr } %t644, { i64, ptr } %t643)
  store %"compiler/diagmsg:Msg" %t646, ptr %l376
  br label %bb170
bb170:
  %t647 = load ptr, ptr %l369, !tbaa !29
  %t648 = load %"compiler/source:Span", ptr %l370
  %t649 = load %"compiler/diagmsg:Msg", ptr %l376
  %t650 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t647, %"compiler/source:Span" %t648, %"compiler/diagmsg:Msg" %t649)
  store i64 %t650, ptr %l377
  br label %bb171
bb171:
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t651, { i64, ptr } %t652)
  br label %bb172
bb172:
  %t655 = load ptr, ptr %l0, !tbaa !29
  %t656 = load %"compiler/source:Span", ptr %l1
  %t659 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t655, %"compiler/source:Span" %t656)
  store ptr %t659, ptr %l382
  br label %bb173
bb173:
  %t660 = load ptr, ptr %l382, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t660, ptr %rv
  br label %ret
bb174:
  %t662 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t664 = trunc i64 36 to i32
  %t665 = icmp eq i32 %t662, %t664
  br i1 %t665, label %bb175, label %bb176
bb175:
  %t667 = load ptr, ptr %l0, !tbaa !29
  %t669 = getelementptr %"compiler/check:Checker", ptr %t667, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !29
  %t672 = getelementptr %"compiler/generic:Program", ptr %t670, i32 0, i32 2
  %t673 = load i32, ptr %l8, !tbaa !23
  %t676 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t672, i32 %t673)
  store i64 %t676, ptr %l391
  br label %bb177
bb176:
  store i1 false, ptr %l386, !tbaa !21
  br label %bb178
bb177:
  %t677 = load i64, ptr %l391, !tbaa !24
  %t678 = srem i64 %t677, 8
  %t680 = icmp ne i64 %t678, 0
  store i1 %t680, ptr %l386, !tbaa !21
  br label %bb178
bb178:
  %t682 = load i1, ptr %l386, !tbaa !21
  br i1 %t682, label %bb179, label %bb180
bb179:
  %t683 = load ptr, ptr %l0, !tbaa !29
  store ptr %t683, ptr %l394, !tbaa !29
  %t684 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t684, ptr %l395
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i32, ptr %l7, !tbaa !23
  %t689 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t685, i32 %t686)
  store { i64, ptr } %t689, ptr %l398
  br label %bb181
bb180:
  br label %bb187
bb181:
  %t690 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t690, 0
  %t692 = extractvalue { i64, ptr } %t690, 1
  %t693 = mul i64 %t691, 1
  %t694 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t693)
  call void @llvm.memcpy.p0.p0.i64(ptr %t694, ptr %t692, i64 %t693, i1 false)
  %t695 = insertvalue { i64, ptr } undef, i64 %t691, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t694, 1
  store { i64, ptr } %t696, ptr %l399, !tbaa !27
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = getelementptr %"compiler/check:Checker", ptr %t697, i32 0, i32 1
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = getelementptr %"compiler/generic:Program", ptr %t700, i32 0, i32 2
  %t703 = load i32, ptr %l8, !tbaa !23
  %t706 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t702, i32 %t703)
  store i64 %t706, ptr %l404
  br label %bb182
bb182:
  %t707 = load { i64, ptr }, ptr %l399, !tbaa !27
  %t708 = load i64, ptr %l404, !tbaa !24
  %t709 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %v0, ptr %v0, { i64, ptr } %t707, i64 %t708)
  store %"compiler/diagmsg:Msg" %t709, ptr %l405
  br label %bb183
bb183:
  %t710 = load ptr, ptr %l394, !tbaa !29
  %t711 = load %"compiler/source:Span", ptr %l395
  %t712 = load %"compiler/diagmsg:Msg", ptr %l405
  %t713 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t710, %"compiler/source:Span" %t711, %"compiler/diagmsg:Msg" %t712)
  store i64 %t713, ptr %l406
  br label %bb184
bb184:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t715 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t714, { i64, ptr } %t715)
  br label %bb185
bb185:
  %t718 = load ptr, ptr %l0, !tbaa !29
  %t719 = load %"compiler/source:Span", ptr %l1
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t718, %"compiler/source:Span" %t719)
  store ptr %t722, ptr %l411
  br label %bb186
bb186:
  %t723 = load ptr, ptr %l411, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t723, ptr %rv
  br label %ret
bb187:
  %t725 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t727 = trunc i64 34 to i32
  %t728 = icmp eq i32 %t725, %t727
  br i1 %t728, label %bb188, label %bb189
bb188:
  store i1 true, ptr %l415, !tbaa !21
  br label %bb190
bb189:
  %t730 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t732 = trunc i64 35 to i32
  %t733 = icmp eq i32 %t730, %t732
  store i1 %t733, ptr %l415, !tbaa !21
  br label %bb190
bb190:
  %t735 = load i1, ptr %l415, !tbaa !21
  store i1 %t735, ptr %l20, !tbaa !21
  %t736 = load i1, ptr %l20, !tbaa !21
  br i1 %t736, label %bb191, label %bb192
bb191:
  store i64 1, ptr %l419, !tbaa !24
  br label %bb193
bb192:
  store i64 0, ptr %l419, !tbaa !24
  br label %bb193
bb193:
  %t738 = load i64, ptr %l419, !tbaa !24
  store i64 %t738, ptr %l21, !tbaa !24
  %t739 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = load i64, ptr %l21, !tbaa !24
  %t745 = icmp ne i64 %t741, %t742
  br i1 %t745, label %bb194, label %bb195
bb194:
  %t747 = load ptr, ptr %l0, !tbaa !29
  store ptr %t747, ptr %l424, !tbaa !29
  %t748 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t748, ptr %l425
  %t749 = load i64, ptr %l21, !tbaa !24
  store i64 %t749, ptr %l426, !tbaa !24
  %t750 = load i64, ptr %l21, !tbaa !24
  %t752 = icmp eq i64 %t750, 1
  br i1 %t752, label %bb196, label %bb197
bb195:
  br label %bb203
bb196:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l429, !tbaa !27
  br label %bb198
bb197:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l429, !tbaa !27
  br label %bb198
bb198:
  %t754 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t756 = extractvalue { i64, ptr } %t754, 0
  %t757 = load i64, ptr %l426, !tbaa !24
  %t758 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t760 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 %t757, { i64, ptr } %t758, i64 %t756)
  store %"compiler/diagmsg:Msg" %t760, ptr %l432
  br label %bb199
bb199:
  %t761 = load ptr, ptr %l424, !tbaa !29
  %t762 = load %"compiler/source:Span", ptr %l425
  %t763 = load %"compiler/diagmsg:Msg", ptr %l432
  %t764 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t761, %"compiler/source:Span" %t762, %"compiler/diagmsg:Msg" %t763)
  store i64 %t764, ptr %l433
  br label %bb200
bb200:
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t766 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t765, { i64, ptr } %t766)
  br label %bb201
bb201:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t770 = load %"compiler/source:Span", ptr %l1
  %t773 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t769, %"compiler/source:Span" %t770)
  store ptr %t773, ptr %l438
  br label %bb202
bb202:
  %t774 = load ptr, ptr %l438, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t774, ptr %rv
  br label %ret
bb203:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t777 = load ptr, ptr %l4, !tbaa !29
  %t778 = load %"compiler/source:Span", ptr %l1
  %t782 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v5, ptr %t776, ptr %t777, %"compiler/source:Span" %t778)
  store ptr %t782, ptr %l443
  br label %bb204
bb204:
  %t783 = load ptr, ptr %l443, !tbaa !29
  store ptr %t783, ptr %l22, !tbaa !29
  %t784 = load i1, ptr %l20, !tbaa !21
  %t786 = xor i1 %t784, true
  br i1 %t786, label %bb205, label %bb206
bb205:
  %t788 = load ptr, ptr %l0, !tbaa !29
  store ptr %t788, ptr %l446, !tbaa !29
  %t789 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t789, ptr %l447
  %t790 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t792 = trunc i64 36 to i32
  %t793 = icmp eq i32 %t790, %t792
  br i1 %t793, label %bb207, label %bb208
bb206:
  br label %bb212
bb207:
  %t795 = load i32, ptr %l7, !tbaa !23
  store i32 %t795, ptr %l450, !tbaa !23
  br label %bb210
bb208:
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t799 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t797)
  store i32 %t799, ptr %l453
  br label %bb209
bb209:
  %t800 = load i32, ptr %l453, !tbaa !23
  store i32 %t800, ptr %l450, !tbaa !23
  br label %bb210
bb210:
  %t801 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t802 = load ptr, ptr %l22, !tbaa !29
  %t803 = load ptr, ptr %l446, !tbaa !29
  %t804 = load %"compiler/source:Span", ptr %l447
  %t805 = load i32, ptr %l450, !tbaa !23
  %t808 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v0, ptr %v5, ptr %t803, %"compiler/source:Span" %t804, i32 %t805, i32 %t801, ptr %t802, ptr null)
  store ptr %t808, ptr %l456
  br label %bb211
bb211:
  %t809 = load ptr, ptr %l456, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t809, ptr %rv
  br label %ret
bb212:
  %t811 = load ptr, ptr %l0, !tbaa !29
  store ptr %t811, ptr %l458, !tbaa !29
  %t812 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t812, ptr %l459, !tbaa !27
  %t813 = getelementptr { i64, ptr }, ptr %l459, i32 0, i32 1
  %t814 = load ptr, ptr %t813, !tbaa !27
  %t815 = getelementptr ptr, ptr %t814, i64 0
  %t816 = load ptr, ptr %t815, !tbaa !39
  store ptr %t816, ptr %l461, !tbaa !29
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t820 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t818)
  store i32 %t820, ptr %l463
  br label %bb213
bb213:
  %t821 = load ptr, ptr %l458, !tbaa !29
  %t822 = load ptr, ptr %l461, !tbaa !29
  %t823 = load i32, ptr %l463, !tbaa !23
  %t824 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v4, ptr %v5, ptr %t821, ptr %t822, i32 %t823)
  store ptr %t824, ptr %l464
  br label %bb214
bb214:
  %t825 = load ptr, ptr %l464, !tbaa !29
  store ptr %t825, ptr %l23, !tbaa !29
  %t826 = load ptr, ptr %l23, !tbaa !29
  %t829 = call i32 @compiler_2fcheck_2etypeOf(ptr %v5, ptr %t826)
  store i32 %t829, ptr %l467
  br label %bb215
bb215:
  %t830 = load i32, ptr %l467, !tbaa !23
  store i32 %t830, ptr %l24, !tbaa !23
  %t831 = load i32, ptr %l24, !tbaa !23
  %t832 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t835 = icmp eq i32 %t831, %t832
  br i1 %t835, label %bb216, label %bb217
bb216:
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t838 = load %"compiler/source:Span", ptr %l1
  %t841 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t837, %"compiler/source:Span" %t838)
  store ptr %t841, ptr %l473
  br label %bb218
bb217:
  br label %bb219
bb218:
  %t842 = load ptr, ptr %l473, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t842, ptr %rv
  br label %ret
bb219:
  %t844 = load ptr, ptr %l0, !tbaa !29
  %t845 = load i32, ptr %l24, !tbaa !23
  %t848 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t844, i32 %t845)
  store i1 %t848, ptr %l477
  br label %bb220
bb220:
  %t849 = load i1, ptr %l477, !tbaa !21
  %t850 = xor i1 %t849, true
  br i1 %t850, label %bb221, label %bb222
bb221:
  %t852 = load ptr, ptr %l0, !tbaa !29
  store ptr %t852, ptr %l479, !tbaa !29
  %t853 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t853, ptr %l480, !tbaa !27
  %t854 = getelementptr { i64, ptr }, ptr %l480, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = getelementptr ptr, ptr %t855, i64 0
  %t857 = load ptr, ptr %t856, !tbaa !39
  %t859 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t857)
  store %"compiler/source:Span" %t859, ptr %l482
  br label %bb223
bb222:
  br label %bb228
bb223:
  %t860 = load ptr, ptr %l0, !tbaa !29
  %t861 = load i32, ptr %l24, !tbaa !23
  %t864 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t860, i32 %t861)
  store { i64, ptr } %t864, ptr %l485
  br label %bb224
bb224:
  %t865 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t866 = extractvalue { i64, ptr } %t865, 0
  %t867 = extractvalue { i64, ptr } %t865, 1
  %t868 = mul i64 %t866, 1
  %t869 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t868)
  call void @llvm.memcpy.p0.p0.i64(ptr %t869, ptr %t867, i64 %t868, i1 false)
  %t870 = insertvalue { i64, ptr } undef, i64 %t866, 0
  %t871 = insertvalue { i64, ptr } %t870, ptr %t869, 1
  %t873 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %v0, ptr %v0, { i64, ptr } %t871)
  store %"compiler/diagmsg:Msg" %t873, ptr %l487
  br label %bb225
bb225:
  %t874 = load ptr, ptr %l479, !tbaa !29
  %t875 = load %"compiler/source:Span", ptr %l482
  %t876 = load %"compiler/diagmsg:Msg", ptr %l487
  %t877 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t874, %"compiler/source:Span" %t875, %"compiler/diagmsg:Msg" %t876)
  store i64 %t877, ptr %l488
  br label %bb226
bb226:
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t879 = load %"compiler/source:Span", ptr %l1
  %t882 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t878, %"compiler/source:Span" %t879)
  store ptr %t882, ptr %l491
  br label %bb227
bb227:
  %t883 = load ptr, ptr %l491, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t883, ptr %rv
  br label %ret
bb228:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load i32, ptr %l24, !tbaa !23
  %t889 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t885, i32 %t886)
  store i32 %t889, ptr %l495
  br label %bb229
bb229:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t890)
  store i32 %t892, ptr %l497
  br label %bb230
bb230:
  %t893 = load i32, ptr %l495, !tbaa !23
  %t894 = load i32, ptr %l497, !tbaa !23
  %t895 = icmp ne i32 %t893, %t894
  br i1 %t895, label %bb231, label %bb232
bb231:
  %t897 = load ptr, ptr %l0, !tbaa !29
  store ptr %t897, ptr %l499, !tbaa !29
  %t898 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t898, ptr %l500, !tbaa !27
  %t899 = getelementptr { i64, ptr }, ptr %l500, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = getelementptr ptr, ptr %t900, i64 0
  %t902 = load ptr, ptr %t901, !tbaa !39
  %t904 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t902)
  store %"compiler/source:Span" %t904, ptr %l502
  br label %bb233
bb232:
  br label %bb236
bb233:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t907 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t905)
  store i32 %t907, ptr %l504
  br label %bb234
bb234:
  %t908 = load ptr, ptr %l23, !tbaa !29
  %t909 = load ptr, ptr %l499, !tbaa !29
  %t910 = load %"compiler/source:Span", ptr %l502
  %t911 = load i32, ptr %l504, !tbaa !23
  %t914 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v0, ptr %v5, ptr %t909, %"compiler/source:Span" %t910, i32 %t911, i32 20, ptr %t908, ptr null)
  store ptr %t914, ptr %l507
  br label %bb235
bb235:
  %t915 = load ptr, ptr %l507, !tbaa !29
  store ptr %t915, ptr %l23, !tbaa !29
  br label %bb236
bb236:
  %t916 = load ptr, ptr %l0, !tbaa !29
  %t917 = load %"compiler/source:Span", ptr %l1
  %t918 = load i32, ptr %l7, !tbaa !23
  %t919 = load i32, ptr %l19, !range !{i32 0, i32 52}
  %t920 = load ptr, ptr %l22, !tbaa !29
  %t921 = load ptr, ptr %l23, !tbaa !29
  %t929 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v5, ptr %v5, ptr %v5, ptr %t916, %"compiler/source:Span" %t917, i32 %t918, i32 %t919, ptr %t920, ptr %t921)
  store ptr %t929, ptr %l515
  br label %bb237
bb237:
  %t930 = load ptr, ptr %l515, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t930, ptr %rv
  br label %ret
bb238:
  %t932 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t934 = call i32 @compiler_2fcheck_2esatOp(ptr %v3, { i64, ptr } %t932)
  store i32 %t934, ptr %l518
  br label %bb239
bb239:
  %t935 = load i32, ptr %l518, !range !{i32 0, i32 52}
  store i32 %t935, ptr %l25
  %t936 = load i32, ptr %l25, !range !{i32 0, i32 52}
  %t938 = trunc i64 29 to i32
  %t939 = icmp eq i32 %t936, %t938
  %t941 = xor i1 %t939, true
  br i1 %t941, label %bb240, label %bb241
bb240:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t945 = getelementptr %"compiler/check:Checker", ptr %t943, i32 0, i32 1
  %t946 = load ptr, ptr %t945, !tbaa !29
  %t948 = getelementptr %"compiler/generic:Program", ptr %t946, i32 0, i32 2
  %t949 = load i32, ptr %l8, !tbaa !23
  %t952 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t948, i32 %t949)
  store i1 %t952, ptr %l527
  br label %bb242
bb241:
  store i1 false, ptr %l522, !tbaa !21
  br label %bb243
bb242:
  %t953 = load i1, ptr %l527, !tbaa !21
  store i1 %t953, ptr %l522, !tbaa !21
  br label %bb243
bb243:
  %t954 = load i1, ptr %l522, !tbaa !21
  br i1 %t954, label %bb244, label %bb245
bb244:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t957 = getelementptr %"compiler/check:Checker", ptr %t955, i32 0, i32 1
  %t958 = load ptr, ptr %t957, !tbaa !29
  store ptr %t958, ptr %l530, !tbaa !29
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t961 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t959)
  store ptr %t961, ptr %l532
  br label %bb246
bb245:
  store i1 false, ptr %l528, !tbaa !21
  br label %bb248
bb246:
  %t962 = load ptr, ptr %l532, !tbaa !29
  %t964 = getelementptr %"compiler/check:frame", ptr %t962, i32 0, i32 1
  %t965 = load i64, ptr %t964, !tbaa !24
  %t966 = load ptr, ptr %l530, !tbaa !29
  %t968 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t966, i64 %t965)
  store i1 %t968, ptr %l535
  br label %bb247
bb247:
  %t969 = load i1, ptr %l535, !tbaa !21
  store i1 %t969, ptr %l528, !tbaa !21
  br label %bb248
bb248:
  %t970 = load i1, ptr %l528, !tbaa !21
  br i1 %t970, label %bb249, label %bb250
bb249:
  %t971 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t973 = extractvalue { i64, ptr } %t971, 0
  %t975 = icmp ne i64 %t973, 1
  br i1 %t975, label %bb251, label %bb252
bb250:
  br label %bb265
bb251:
  %t977 = load ptr, ptr %l0, !tbaa !29
  store ptr %t977, ptr %l539, !tbaa !29
  %t978 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t978, ptr %l540
  %t979 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t979, 0
  %t983 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, i64 %t981)
  store %"compiler/diagmsg:Msg" %t983, ptr %l543
  br label %bb253
bb252:
  br label %bb257
bb253:
  %t984 = load ptr, ptr %l539, !tbaa !29
  %t985 = load %"compiler/source:Span", ptr %l540
  %t986 = load %"compiler/diagmsg:Msg", ptr %l543
  %t987 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t984, %"compiler/source:Span" %t985, %"compiler/diagmsg:Msg" %t986)
  store i64 %t987, ptr %l544
  br label %bb254
bb254:
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v4, ptr %t988, { i64, ptr } %t989)
  br label %bb255
bb255:
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t993 = load %"compiler/source:Span", ptr %l1
  %t996 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t992, %"compiler/source:Span" %t993)
  store ptr %t996, ptr %l549
  br label %bb256
bb256:
  %t997 = load ptr, ptr %l549, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t997, ptr %rv
  br label %ret
bb257:
  %t999 = load i32, ptr %l25, !range !{i32 0, i32 52}
  %t1001 = trunc i64 51 to i32
  %t1002 = icmp eq i32 %t999, %t1001
  br i1 %t1002, label %bb258, label %bb259
bb258:
  %t1004 = load ptr, ptr %l0, !tbaa !29
  %t1006 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1004)
  store i32 %t1006, ptr %l555
  br label %bb260
bb259:
  %t1007 = load i32, ptr %l7, !tbaa !23
  store i32 %t1007, ptr %l553, !tbaa !23
  br label %bb261
bb260:
  %t1009 = load i32, ptr %l555, !tbaa !23
  store i32 %t1009, ptr %l553, !tbaa !23
  br label %bb261
bb261:
  %t1010 = load i32, ptr %l553, !tbaa !23
  store i32 %t1010, ptr %l26, !tbaa !23
  %t1011 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1011, ptr %l557, !tbaa !29
  %t1012 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1012, ptr %l558
  %t1013 = load i32, ptr %l7, !tbaa !23
  store i32 %t1013, ptr %l559, !tbaa !23
  %t1014 = load i32, ptr %l25, !range !{i32 0, i32 52}
  store i32 %t1014, ptr %l560
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load ptr, ptr %l4, !tbaa !29
  %t1017 = load %"compiler/source:Span", ptr %l1
  %t1021 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v2, ptr %t1015, ptr %t1016, %"compiler/source:Span" %t1017)
  store ptr %t1021, ptr %l564
  br label %bb262
bb262:
  %t1022 = load ptr, ptr %l0, !tbaa !29
  %t1023 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1023, ptr %l566, !tbaa !27
  %t1024 = getelementptr { i64, ptr }, ptr %l566, i32 0, i32 1
  %t1025 = load ptr, ptr %t1024, !tbaa !27
  %t1026 = getelementptr ptr, ptr %t1025, i64 0
  %t1027 = load ptr, ptr %t1026, !tbaa !39
  %t1028 = load i32, ptr %l26, !tbaa !23
  %t1032 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v4, ptr %v0, ptr %t1022, ptr %t1027, i32 %t1028)
  store ptr %t1032, ptr %l569
  br label %bb263
bb263:
  %t1033 = load ptr, ptr %l569, !tbaa !29
  %t1034 = load ptr, ptr %l557, !tbaa !29
  %t1035 = load %"compiler/source:Span", ptr %l558
  %t1036 = load i32, ptr %l559, !tbaa !23
  %t1037 = load i32, ptr %l560, !range !{i32 0, i32 52}
  %t1038 = load ptr, ptr %l564, !tbaa !29
  %t1040 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v2, ptr %v0, ptr %v5, ptr %t1034, %"compiler/source:Span" %t1035, i32 %t1036, i32 %t1037, ptr %t1038, ptr %t1033)
  store ptr %t1040, ptr %l571
  br label %bb264
bb264:
  %t1041 = load ptr, ptr %l571, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1041, ptr %rv
  br label %ret
bb265:
  %t1043 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1045 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1043, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t1045, ptr %l574
  br label %bb266
bb266:
  %t1046 = load i1, ptr %l574, !tbaa !21
  br i1 %t1046, label %bb267, label %bb268
bb267:
  %t1047 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1049 = extractvalue { i64, ptr } %t1047, 0
  %t1051 = icmp eq i64 %t1049, 0
  store i1 %t1051, ptr %l575, !tbaa !21
  br label %bb269
bb268:
  store i1 false, ptr %l575, !tbaa !21
  br label %bb269
bb269:
  %t1053 = load i1, ptr %l575, !tbaa !21
  br i1 %t1053, label %bb270, label %bb271
bb270:
  %t1054 = load ptr, ptr %l0, !tbaa !29
  %t1055 = load i32, ptr %l7, !tbaa !23
  %t1058 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t1054, i32 %t1055)
  store i32 %t1058, ptr %l582
  br label %bb272
bb271:
  store i1 false, ptr %l579, !tbaa !21
  br label %bb273
bb272:
  %t1059 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1060 = load i32, ptr %l582, !tbaa !23
  %t1062 = icmp ne i32 %t1060, %t1059
  store i1 %t1062, ptr %l579, !tbaa !21
  br label %bb273
bb273:
  %t1064 = load i1, ptr %l579, !tbaa !21
  br i1 %t1064, label %bb274, label %bb275
bb274:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  %t1067 = getelementptr %"compiler/check:Checker", ptr %t1065, i32 0, i32 1
  %t1068 = load ptr, ptr %t1067, !tbaa !29
  store ptr %t1068, ptr %l587, !tbaa !29
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1071 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1069)
  store ptr %t1071, ptr %l589
  br label %bb276
bb275:
  store i1 false, ptr %l585, !tbaa !21
  br label %bb278
bb276:
  %t1072 = load ptr, ptr %l589, !tbaa !29
  %t1074 = getelementptr %"compiler/check:frame", ptr %t1072, i32 0, i32 1
  %t1075 = load i64, ptr %t1074, !tbaa !24
  %t1076 = load ptr, ptr %l587, !tbaa !29
  %t1078 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t1076, i64 %t1075)
  store i1 %t1078, ptr %l592
  br label %bb277
bb277:
  %t1079 = load i1, ptr %l592, !tbaa !21
  store i1 %t1079, ptr %l585, !tbaa !21
  br label %bb278
bb278:
  %t1080 = load i1, ptr %l585, !tbaa !21
  br i1 %t1080, label %bb279, label %bb280
bb279:
  %t1081 = load ptr, ptr %l0, !tbaa !29
  %t1083 = getelementptr %"compiler/check:Checker", ptr %t1081, i32 0, i32 1
  %t1084 = load ptr, ptr %t1083, !tbaa !29
  %t1086 = getelementptr %"compiler/generic:Program", ptr %t1084, i32 0, i32 0
  %t1087 = load ptr, ptr %t1086, !tbaa !29
  %t1089 = getelementptr %"compiler/load:Loader", ptr %t1087, i32 0, i32 10
  store ptr %t1089, ptr %l596, !tbaa !29
  %t1090 = load ptr, ptr %l0, !tbaa !29
  %t1092 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1090)
  store ptr %t1092, ptr %l598
  br label %bb281
bb280:
  br label %bb285
bb281:
  %t1093 = load ptr, ptr %l598, !tbaa !29
  %t1095 = getelementptr %"compiler/check:frame", ptr %t1093, i32 0, i32 1
  %t1096 = load i64, ptr %t1095, !tbaa !24
  %t1097 = load ptr, ptr %l596, !tbaa !29
  %t1099 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t1097, i64 %t1096)
  store ptr %t1099, ptr %l601
  br label %bb282
bb282:
  %t1100 = load ptr, ptr %l601, !tbaa !29
  %t1102 = getelementptr %"compiler/load:Module", ptr %t1100, i32 0, i32 5
  store i1 true, ptr %t1102, !tbaa !21
  %t1103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1103, ptr %l603, !tbaa !29
  %t1104 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1104, ptr %l604
  %t1105 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t1105, ptr %l605, !tbaa !23
  store i32 29, ptr %l606
  %t1106 = load ptr, ptr %l0, !tbaa !29
  %t1107 = load ptr, ptr %l4, !tbaa !29
  %t1108 = load %"compiler/source:Span", ptr %l1
  %t1112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v2, ptr %t1106, ptr %t1107, %"compiler/source:Span" %t1108)
  store ptr %t1112, ptr %l610
  br label %bb283
bb283:
  %t1113 = load ptr, ptr %l603, !tbaa !29
  %t1114 = load %"compiler/source:Span", ptr %l604
  %t1115 = load i32, ptr %l605, !tbaa !23
  %t1116 = load i32, ptr %l606, !range !{i32 0, i32 52}
  %t1117 = load ptr, ptr %l610, !tbaa !29
  %t1118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v2, ptr %v0, ptr %v5, ptr %t1113, %"compiler/source:Span" %t1114, i32 %t1115, i32 %t1116, ptr %t1117, ptr null)
  store ptr %t1118, ptr %l611
  br label %bb284
bb284:
  %t1119 = load ptr, ptr %l611, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1119, ptr %rv
  br label %ret
bb285:
  %t1121 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1121, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t1123, ptr %l614
  br label %bb286
bb286:
  %t1124 = load i1, ptr %l614, !tbaa !21
  br i1 %t1124, label %bb287, label %bb288
bb287:
  %t1125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1125, 0
  %t1129 = icmp eq i64 %t1127, 1
  store i1 %t1129, ptr %l615, !tbaa !21
  br label %bb289
bb288:
  store i1 false, ptr %l615, !tbaa !21
  br label %bb289
bb289:
  %t1131 = load i1, ptr %l615, !tbaa !21
  br i1 %t1131, label %bb290, label %bb291
bb290:
  %t1132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1132, ptr %l620, !tbaa !29
  %t1133 = load ptr, ptr %l4, !tbaa !29
  %t1136 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1133)
  store i32 %t1136, ptr %l623
  br label %bb292
bb291:
  store i1 false, ptr %l619, !tbaa !21
  br label %bb294
bb292:
  %t1137 = load ptr, ptr %l620, !tbaa !29
  %t1138 = load i32, ptr %l623, !tbaa !23
  %t1139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1137, i32 %t1138)
  store i1 %t1139, ptr %l624
  br label %bb293
bb293:
  %t1140 = load i1, ptr %l624, !tbaa !21
  store i1 %t1140, ptr %l619, !tbaa !21
  br label %bb294
bb294:
  %t1141 = load i1, ptr %l619, !tbaa !21
  br i1 %t1141, label %bb295, label %bb296
bb295:
  %t1142 = load ptr, ptr %l0, !tbaa !29
  %t1143 = load i32, ptr %l7, !tbaa !23
  %t1146 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t1142, i32 %t1143)
  store i32 %t1146, ptr %l628
  br label %bb297
bb296:
  store i1 false, ptr %l625, !tbaa !21
  br label %bb298
bb297:
  %t1147 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1148 = load i32, ptr %l628, !tbaa !23
  %t1150 = icmp ne i32 %t1148, %t1147
  store i1 %t1150, ptr %l625, !tbaa !21
  br label %bb298
bb298:
  %t1152 = load i1, ptr %l625, !tbaa !21
  br i1 %t1152, label %bb299, label %bb300
bb299:
  %t1153 = load ptr, ptr %l0, !tbaa !29
  %t1155 = getelementptr %"compiler/check:Checker", ptr %t1153, i32 0, i32 1
  %t1156 = load ptr, ptr %t1155, !tbaa !29
  store ptr %t1156, ptr %l633, !tbaa !29
  %t1157 = load ptr, ptr %l0, !tbaa !29
  %t1159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1157)
  store ptr %t1159, ptr %l635
  br label %bb301
bb300:
  store i1 false, ptr %l631, !tbaa !21
  br label %bb303
bb301:
  %t1160 = load ptr, ptr %l635, !tbaa !29
  %t1162 = getelementptr %"compiler/check:frame", ptr %t1160, i32 0, i32 1
  %t1163 = load i64, ptr %t1162, !tbaa !24
  %t1164 = load ptr, ptr %l633, !tbaa !29
  %t1166 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t1164, i64 %t1163)
  store i1 %t1166, ptr %l638
  br label %bb302
bb302:
  %t1167 = load i1, ptr %l638, !tbaa !21
  store i1 %t1167, ptr %l631, !tbaa !21
  br label %bb303
bb303:
  %t1168 = load i1, ptr %l631, !tbaa !21
  br i1 %t1168, label %bb304, label %bb305
bb304:
  %t1169 = load ptr, ptr %l0, !tbaa !29
  %t1171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t1169)
  store ptr %t1171, ptr %l640
  br label %bb306
bb305:
  br label %bb340
bb306:
  %t1172 = load ptr, ptr %l640, !tbaa !29
  %t1174 = getelementptr %"compiler/typed:Body", ptr %t1172, i32 0, i32 18
  store i1 true, ptr %t1174, !tbaa !21
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1177 = getelementptr %"compiler/check:Checker", ptr %t1175, i32 0, i32 1
  %t1178 = load ptr, ptr %t1177, !tbaa !29
  %t1180 = getelementptr %"compiler/generic:Program", ptr %t1178, i32 0, i32 2
  store ptr %t1180, ptr %l644, !tbaa !29
  %t1181 = load ptr, ptr %l0, !tbaa !29
  %t1182 = load i32, ptr %l7, !tbaa !23
  %t1185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t1181, i32 %t1182)
  store i32 %t1185, ptr %l647
  br label %bb307
bb307:
  %t1186 = load ptr, ptr %l644, !tbaa !29
  %t1187 = load i32, ptr %l647, !tbaa !23
  %t1188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t1186, i32 %t1187)
  store i32 %t1188, ptr %l648
  br label %bb308
bb308:
  %t1189 = load i32, ptr %l648, !tbaa !23
  store i32 %t1189, ptr %l27, !tbaa !23
  %t1190 = load ptr, ptr %l0, !tbaa !29
  %t1192 = getelementptr %"compiler/check:Checker", ptr %t1190, i32 0, i32 1
  %t1193 = load ptr, ptr %t1192, !tbaa !29
  %t1195 = getelementptr %"compiler/generic:Program", ptr %t1193, i32 0, i32 2
  %t1196 = load i32, ptr %l27, !tbaa !23
  %t1199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t1195, i32 %t1196, i32 0)
  store i32 %t1199, ptr %l653
  br label %bb309
bb309:
  %t1200 = load i32, ptr %l653, !tbaa !23
  store i32 %t1200, ptr %l28, !tbaa !23
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1203 = getelementptr %"compiler/check:Checker", ptr %t1201, i32 0, i32 37
  %t1205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1203)
  store i64 %t1205, ptr %l656
  br label %bb310
bb310:
  %t1206 = load i64, ptr %l656, !tbaa !24
  store i64 %t1206, ptr %l29, !tbaa !24
  %t1207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1207, ptr %l657, !tbaa !29
  %t1208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1208, ptr %l658
  %t1209 = load ptr, ptr %l4, !tbaa !29
  %t1212 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t1209)
  store i32 %t1212, ptr %l661
  br label %bb311
bb311:
  %t1213 = load ptr, ptr %l657, !tbaa !29
  %t1214 = load %"compiler/source:Span", ptr %l658
  %t1215 = load i32, ptr %l661, !tbaa !23
  %t1216 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t1213, %"compiler/source:Span" %t1214, i32 %t1215)
  store i64 %t1216, ptr %l662
  br label %bb312
bb312:
  %t1217 = load i64, ptr %l662, !tbaa !24
  store i64 %t1217, ptr %l30, !tbaa !24
  %t1218 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1218, ptr %l663, !tbaa !29
  %t1219 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1219, ptr %l664
  %t1220 = load i64, ptr %l30, !tbaa !24
  %t1222 = trunc i64 %t1220 to i32
  store i32 %t1222, ptr %l667, !tbaa !23
  %t1224 = load ptr, ptr %l0, !tbaa !29
  %t1225 = load ptr, ptr %l4, !tbaa !29
  %t1226 = load %"compiler/source:Span", ptr %l1
  %t1230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v0, ptr %t1224, ptr %t1225, %"compiler/source:Span" %t1226)
  store ptr %t1230, ptr %l671
  br label %bb313
bb313:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1231
  %t1232 = getelementptr { i64, [3 x i64] }, ptr %t1231, i32 0, i32 0
  store i64 0, ptr %t1232
  %t1233 = load %"compiler/source:Span", ptr %l664
  %t1234 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1233, 0
  %t1235 = load i32, ptr %l667, !tbaa !23
  %t1236 = insertvalue { %"compiler/source:Span", i32, ptr } %t1234, i32 %t1235, 1
  %t1237 = load ptr, ptr %l671, !tbaa !29
  %t1238 = insertvalue { %"compiler/source:Span", i32, ptr } %t1236, ptr %t1237, 2
  %t1239 = getelementptr { i64, [3 x i64] }, ptr %t1231, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1238, ptr %t1239
  %t1240 = load { i64, [3 x i64] }, ptr %t1231
  %t1242 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1240, ptr %t1242
  %t1243 = load ptr, ptr %l663, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1243, ptr %t1242)
  br label %bb314
bb314:
  %t1245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1245, ptr %l674, !tbaa !29
  %t1246 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1246, ptr %l675
  %t1247 = load ptr, ptr %l0, !tbaa !29
  %t1249 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1247)
  store i32 %t1249, ptr %l677
  br label %bb315
bb315:
  %t1250 = load ptr, ptr %l674, !tbaa !29
  %t1251 = load %"compiler/source:Span", ptr %l675
  %t1252 = load i32, ptr %l677, !tbaa !23
  %t1253 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t1250, %"compiler/source:Span" %t1251, i32 %t1252)
  store i64 %t1253, ptr %l678
  br label %bb316
bb316:
  %t1254 = load i64, ptr %l678, !tbaa !24
  store i64 %t1254, ptr %l31, !tbaa !24
  %t1255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1255, ptr %l679, !tbaa !29
  %t1256 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1256, ptr %l680
  %t1257 = load i64, ptr %l31, !tbaa !24
  %t1259 = trunc i64 %t1257 to i32
  store i32 %t1259, ptr %l683, !tbaa !23
  %t1261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1261, ptr %l684, !tbaa !29
  %t1262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1262, ptr %l685, !tbaa !29
  %t1263 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1263, ptr %l686, !tbaa !27
  %t1264 = getelementptr { i64, ptr }, ptr %l686, i32 0, i32 1
  %t1265 = load ptr, ptr %t1264, !tbaa !27
  %t1266 = getelementptr ptr, ptr %t1265, i64 0
  %t1267 = load ptr, ptr %t1266, !tbaa !39
  store ptr %t1267, ptr %l687, !tbaa !29
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1268)
  store i32 %t1270, ptr %l689
  br label %bb317
bb317:
  %t1271 = load ptr, ptr %l685, !tbaa !29
  %t1272 = load ptr, ptr %l687, !tbaa !29
  %t1273 = load i32, ptr %l689, !tbaa !23
  %t1274 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v4, ptr %v0, ptr %t1271, ptr %t1272, i32 %t1273)
  store ptr %t1274, ptr %l690
  br label %bb318
bb318:
  %t1275 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1275, ptr %l691, !tbaa !27
  %t1276 = getelementptr { i64, ptr }, ptr %l691, i32 0, i32 1
  %t1277 = load ptr, ptr %t1276, !tbaa !27
  %t1278 = getelementptr ptr, ptr %t1277, i64 0
  %t1279 = load ptr, ptr %t1278, !tbaa !39
  %t1281 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t1279)
  store %"compiler/source:Span" %t1281, ptr %l693
  br label %bb319
bb319:
  %t1282 = load ptr, ptr %l684, !tbaa !29
  %t1283 = load ptr, ptr %l690, !tbaa !29
  %t1284 = load %"compiler/source:Span", ptr %l693
  %t1285 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v0, ptr %t1282, ptr %t1283, %"compiler/source:Span" %t1284)
  store ptr %t1285, ptr %l694
  br label %bb320
bb320:
  store { i64, [3 x i64] } zeroinitializer, ptr %t1286
  %t1287 = getelementptr { i64, [3 x i64] }, ptr %t1286, i32 0, i32 0
  store i64 0, ptr %t1287
  %t1288 = load %"compiler/source:Span", ptr %l680
  %t1289 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1288, 0
  %t1290 = load i32, ptr %l683, !tbaa !23
  %t1291 = insertvalue { %"compiler/source:Span", i32, ptr } %t1289, i32 %t1290, 1
  %t1292 = load ptr, ptr %l694, !tbaa !29
  %t1293 = insertvalue { %"compiler/source:Span", i32, ptr } %t1291, ptr %t1292, 2
  %t1294 = getelementptr { i64, [3 x i64] }, ptr %t1286, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1293, ptr %t1294
  %t1295 = load { i64, [3 x i64] }, ptr %t1286
  %t1297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1295, ptr %t1297
  %t1298 = load ptr, ptr %l679, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1298, ptr %t1297)
  br label %bb321
bb321:
  %t1300 = load ptr, ptr %l0, !tbaa !29
  %t1302 = getelementptr %"compiler/check:Checker", ptr %t1300, i32 0, i32 37
  %t1304 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1302)
  store i64 %t1304, ptr %l699
  br label %bb322
bb322:
  %t1305 = load i64, ptr %l699, !tbaa !24
  store i64 %t1305, ptr %l32, !tbaa !24
  %t1306 = load ptr, ptr %l0, !tbaa !29
  %t1307 = load %"compiler/source:Span", ptr %l1
  %t1311 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t1306, i32 9, %"compiler/source:Span" %t1307)
  store { i64, i64, i64 } %t1311, ptr %l703
  br label %bb323
bb323:
  %t1312 = load { i64, i64, i64 }, ptr %l703
  store { i64, i64, i64 } %t1312, ptr %l33
  %t1313 = getelementptr { i64, i64, i64 }, ptr %l33, i32 0, i32 0
  %t1314 = load i64, ptr %t1313, !tbaa !24
  store i64 %t1314, ptr %l34, !tbaa !24
  %t1316 = getelementptr { i64, i64, i64 }, ptr %l33, i32 0, i32 1
  %t1317 = load i64, ptr %t1316, !tbaa !24
  store i64 %t1317, ptr %l35, !tbaa !24
  %t1319 = getelementptr { i64, i64, i64 }, ptr %l33, i32 0, i32 2
  %t1320 = load i64, ptr %t1319, !tbaa !24
  store i64 %t1320, ptr %l36, !tbaa !24
  %t1322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1322, ptr %l707, !tbaa !29
  %t1323 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1323, ptr %l708
  %t1324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1324, ptr %l709, !tbaa !29
  %t1325 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1325, ptr %l710
  %t1326 = load ptr, ptr %l0, !tbaa !29
  %t1328 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t1326)
  store i32 %t1328, ptr %l712
  br label %bb324
bb324:
  store i32 22, ptr %l713
  %t1329 = load ptr, ptr %l0, !tbaa !29
  %t1330 = load %"compiler/source:Span", ptr %l1
  %t1331 = load i64, ptr %l30, !tbaa !24
  %t1335 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t1329, %"compiler/source:Span" %t1330, i64 %t1331)
  store ptr %t1335, ptr %l717
  br label %bb325
bb325:
  %t1336 = load ptr, ptr %l709, !tbaa !29
  %t1337 = load %"compiler/source:Span", ptr %l710
  %t1338 = load i32, ptr %l712, !tbaa !23
  %t1339 = load i32, ptr %l713, !range !{i32 0, i32 52}
  %t1340 = load ptr, ptr %l717, !tbaa !29
  %t1341 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1336, %"compiler/source:Span" %t1337, i32 %t1338, i32 %t1339, ptr %t1340, ptr null)
  store ptr %t1341, ptr %l718
  br label %bb326
bb326:
  %t1342 = load ptr, ptr %l707, !tbaa !29
  %t1343 = load %"compiler/source:Span", ptr %l708
  %t1344 = load ptr, ptr %l718, !tbaa !29
  %t1345 = call { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v0, ptr %t1342, %"compiler/source:Span" %t1343, ptr %t1344, i64 0)
  store { i64, i64, i64, i64, i64 } %t1345, ptr %l719
  br label %bb327
bb327:
  %t1346 = load { i64, i64, i64, i64, i64 }, ptr %l719
  store { i64, i64, i64, i64, i64 } %t1346, ptr %l37
  %t1347 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 0
  %t1348 = load i64, ptr %t1347, !tbaa !24
  store i64 %t1348, ptr %l38, !tbaa !24
  %t1350 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 1
  %t1351 = load i64, ptr %t1350, !tbaa !24
  store i64 %t1351, ptr %l39, !tbaa !24
  %t1353 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 2
  %t1354 = load i64, ptr %t1353, !tbaa !24
  store i64 %t1354, ptr %l40, !tbaa !24
  %t1356 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 3
  %t1357 = load i64, ptr %t1356, !tbaa !24
  store i64 %t1357, ptr %l41, !tbaa !24
  %t1359 = getelementptr { i64, i64, i64, i64, i64 }, ptr %l37, i32 0, i32 4
  %t1360 = load i64, ptr %t1359, !tbaa !24
  store i64 %t1360, ptr %l42, !tbaa !24
  %t1362 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1362, ptr %l725
  %t1363 = load i32, ptr %l7, !tbaa !23
  store i32 %t1363, ptr %l726, !tbaa !23
  %t1364 = load ptr, ptr %l0, !tbaa !29
  %t1365 = load %"compiler/source:Span", ptr %l1
  %t1366 = load i64, ptr %l30, !tbaa !24
  %t1370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v5, ptr %t1364, %"compiler/source:Span" %t1365, i64 %t1366)
  store ptr %t1370, ptr %l730
  br label %bb328
bb328:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1371
  %t1372 = getelementptr { i64, [4 x i64] }, ptr %t1371, i32 0, i32 0
  store i64 2, ptr %t1372
  %t1373 = load %"compiler/source:Span", ptr %l725
  %t1374 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1373, 0
  %t1375 = load i32, ptr %l726, !tbaa !23
  %t1376 = insertvalue { %"compiler/source:Span", i32, ptr } %t1374, i32 %t1375, 1
  %t1377 = load ptr, ptr %l730, !tbaa !29
  %t1378 = insertvalue { %"compiler/source:Span", i32, ptr } %t1376, ptr %t1377, 2
  %t1379 = getelementptr { i64, [4 x i64] }, ptr %t1371, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1378, ptr %t1379
  %t1380 = load { i64, [4 x i64] }, ptr %t1371
  %t1382 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store { i64, [4 x i64] } %t1380, ptr %t1382
  %t1384 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1384, ptr %l733
  %t1385 = load i32, ptr %l27, !tbaa !23
  store i32 %t1385, ptr %l734, !tbaa !23
  store ptr %t1382, ptr %l735, !tbaa !29
  %t1387 = load ptr, ptr %l0, !tbaa !29
  %t1388 = load %"compiler/source:Span", ptr %l1
  %t1389 = load i64, ptr %l38, !tbaa !24
  %t1393 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v5, ptr %t1387, %"compiler/source:Span" %t1388, i64 %t1389)
  store ptr %t1393, ptr %l739
  br label %bb329
bb329:
  %t1394 = load ptr, ptr %l735, !tbaa !29
  %t1395 = load ptr, ptr %l739, !tbaa !29
  %t1397 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %t1394, ptr %t1395, i32 0)
  store %"compiler/typed:Elem" %t1397, ptr %l741
  br label %bb330
bb330:
  %t1398 = load %"compiler/typed:Elem", ptr %l741
  %t1399 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 24, i64 8)
  store %"compiler/typed:Elem" %t1398, ptr %t1399
  store { i64, [4 x i64] } zeroinitializer, ptr %t1400
  %t1401 = getelementptr { i64, [4 x i64] }, ptr %t1400, i32 0, i32 0
  store i64 4, ptr %t1401
  %t1402 = load %"compiler/source:Span", ptr %l733
  %t1403 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1402, 0
  %t1404 = load i32, ptr %l734, !tbaa !23
  %t1405 = insertvalue { %"compiler/source:Span", i32, ptr } %t1403, i32 %t1404, 1
  %t1407 = insertvalue { %"compiler/source:Span", i32, ptr } %t1405, ptr %t1399, 2
  %t1408 = getelementptr { i64, [4 x i64] }, ptr %t1400, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1407, ptr %t1408
  %t1409 = load { i64, [4 x i64] }, ptr %t1400
  %t1410 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 40, i64 8)
  store ptr %t1410, ptr %lp44
  %t1412 = load ptr, ptr %lp44
  store { i64, [4 x i64] } %t1409, ptr %t1412
  %t1413 = load ptr, ptr %l0, !tbaa !29
  %t1414 = load ptr, ptr %lp44
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v5, ptr %t1413, ptr %t1414)
  br label %bb331
bb331:
  %t1417 = load ptr, ptr %l0, !tbaa !29
  %t1418 = load %"compiler/source:Span", ptr %l1
  %t1419 = load %"compiler/source:Span", ptr %l1
  %t1420 = load i32, ptr %l27, !tbaa !23
  %t1421 = load ptr, ptr %lp44
  store { i64, [5 x i64] } zeroinitializer, ptr %t1422
  %t1423 = getelementptr { i64, [5 x i64] }, ptr %t1422, i32 0, i32 0
  store i64 4, ptr %t1423
  %t1425 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1419, 0
  %t1427 = insertvalue { %"compiler/source:Span", i32, ptr } %t1425, i32 %t1420, 1
  %t1429 = insertvalue { %"compiler/source:Span", i32, ptr } %t1427, ptr %t1421, 2
  %t1430 = getelementptr { i64, [5 x i64] }, ptr %t1422, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1429, ptr %t1430
  %t1431 = load { i64, [5 x i64] }, ptr %t1422
  %t1433 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1431, ptr %t1433
  store { i64, [3 x i64] } zeroinitializer, ptr %t1434
  %t1435 = getelementptr { i64, [3 x i64] }, ptr %t1434, i32 0, i32 0
  store i64 15, ptr %t1435
  %t1437 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1418, 0
  %t1439 = insertvalue { %"compiler/source:Span", ptr } %t1437, ptr %t1433, 1
  %t1440 = getelementptr { i64, [3 x i64] }, ptr %t1434, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1439, ptr %t1440
  %t1441 = load { i64, [3 x i64] }, ptr %t1434
  %t1443 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1441, ptr %t1443
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t1417, ptr %t1443)
  br label %bb332
bb332:
  %t1446 = load ptr, ptr %l0, !tbaa !29
  %t1447 = load %"compiler/source:Span", ptr %l1
  %t1448 = load i64, ptr %l38, !tbaa !24
  %t1449 = load i64, ptr %l39, !tbaa !24
  %t1450 = load i64, ptr %l40, !tbaa !24
  %t1451 = load i64, ptr %l41, !tbaa !24
  %t1452 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %t1446, %"compiler/source:Span" %t1447, i64 %t1448, i64 %t1449, i64 %t1450, i64 %t1451, i64 %t1452)
  br label %bb333
bb333:
  %t1460 = load ptr, ptr %l0, !tbaa !29
  %t1461 = load i64, ptr %l34, !tbaa !24
  %t1462 = load i64, ptr %l35, !tbaa !24
  %t1463 = load i64, ptr %l36, !tbaa !24
  %t1464 = load i64, ptr %l32, !tbaa !24
  %t1470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v5, ptr %t1460, i64 %t1461, i64 %t1462, i64 %t1463, i64 %t1464)
  store ptr %t1470, ptr %l767
  br label %bb334
bb334:
  %t1471 = load ptr, ptr %l767, !tbaa !29
  store ptr %t1471, ptr %l45, !tbaa !29
  %t1472 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1472, ptr %l768
  %t1473 = load i32, ptr %l28, !tbaa !23
  store i32 %t1473, ptr %l769, !tbaa !23
  %t1474 = load ptr, ptr %l0, !tbaa !29
  %t1475 = load %"compiler/source:Span", ptr %l1
  %t1476 = load i64, ptr %l31, !tbaa !24
  %t1480 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v5, ptr %t1474, %"compiler/source:Span" %t1475, i64 %t1476)
  store ptr %t1480, ptr %l773
  br label %bb335
bb335:
  %t1481 = load ptr, ptr %l773, !tbaa !29
  store ptr %t1481, ptr %l774, !tbaa !29
  %t1482 = load ptr, ptr %l45, !tbaa !29
  store ptr %t1482, ptr %l775, !tbaa !29
  %t1483 = load ptr, ptr %l0, !tbaa !29
  %t1484 = load %"compiler/source:Span", ptr %l1
  %t1488 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1483, i32 3, %"compiler/source:Span" %t1484)
  store i32 %t1488, ptr %l779
  br label %bb336
bb336:
  %t1489 = load ptr, ptr %l774, !tbaa !29
  %t1490 = load ptr, ptr %l775, !tbaa !29
  %t1491 = load i32, ptr %l779, !tbaa !23
  %t1493 = call %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %t1489, ptr %t1490, i32 %t1491, i32 0, i1 true)
  store %"compiler/typed:Collect" %t1493, ptr %l781
  br label %bb337
bb337:
  %t1494 = load %"compiler/typed:Collect", ptr %l781
  %t1495 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Collect" %t1494, ptr %t1495
  store { i64, [5 x i64] } zeroinitializer, ptr %t1496
  %t1497 = getelementptr { i64, [5 x i64] }, ptr %t1496, i32 0, i32 0
  store i64 8, ptr %t1497
  %t1498 = load %"compiler/source:Span", ptr %l768
  %t1499 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1498, 0
  %t1500 = load i32, ptr %l769, !tbaa !23
  %t1501 = insertvalue { %"compiler/source:Span", i32, ptr } %t1499, i32 %t1500, 1
  %t1503 = insertvalue { %"compiler/source:Span", i32, ptr } %t1501, ptr %t1495, 2
  %t1504 = getelementptr { i64, [5 x i64] }, ptr %t1496, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1503, ptr %t1504
  %t1505 = load { i64, [5 x i64] }, ptr %t1496
  %t1506 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store ptr %t1506, ptr %lp46
  %t1508 = load ptr, ptr %lp46
  store { i64, [5 x i64] } %t1505, ptr %t1508
  %t1509 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1509, ptr %l784
  %t1510 = load i32, ptr %l28, !tbaa !23
  store i32 %t1510, ptr %l785, !tbaa !23
  %t1511 = load ptr, ptr %l0, !tbaa !29
  %t1513 = getelementptr %"compiler/check:Checker", ptr %t1511, i32 0, i32 37
  %t1514 = load i64, ptr %l29, !tbaa !24
  %t1517 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1513, i64 %t1514)
  store { i64, ptr } %t1517, ptr %l789
  br label %bb338
bb338:
  %t1518 = load ptr, ptr %lp46
  %t1519 = load { i64, ptr }, ptr %l789, !tbaa !27
  %t1521 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v5, ptr %v5, { i64, ptr } %t1519, ptr %t1518, i1 false)
  store %"compiler/typed:Seq" %t1521, ptr %l791
  br label %bb339
bb339:
  %t1522 = load %"compiler/typed:Seq", ptr %l791
  %t1523 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Seq" %t1522, ptr %t1523
  store { i64, [5 x i64] } zeroinitializer, ptr %t1524
  %t1525 = getelementptr { i64, [5 x i64] }, ptr %t1524, i32 0, i32 0
  store i64 12, ptr %t1525
  %t1526 = load %"compiler/source:Span", ptr %l784
  %t1527 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1526, 0
  %t1528 = load i32, ptr %l785, !tbaa !23
  %t1529 = insertvalue { %"compiler/source:Span", i32, ptr } %t1527, i32 %t1528, 1
  %t1531 = insertvalue { %"compiler/source:Span", i32, ptr } %t1529, ptr %t1523, 2
  %t1532 = getelementptr { i64, [5 x i64] }, ptr %t1524, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1531, ptr %t1532
  %t1533 = load { i64, [5 x i64] }, ptr %t1524
  %t1535 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t1533, ptr %t1535
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1535, ptr %rv
  br label %ret
bb340:
  %t1537 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1539 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1537, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t1539, ptr %l796
  br label %bb341
bb341:
  %t1540 = load i1, ptr %l796, !tbaa !21
  br i1 %t1540, label %bb342, label %bb343
bb342:
  %t1541 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1543 = extractvalue { i64, ptr } %t1541, 0
  %t1545 = icmp eq i64 %t1543, 0
  store i1 %t1545, ptr %l797, !tbaa !21
  br label %bb344
bb343:
  store i1 false, ptr %l797, !tbaa !21
  br label %bb344
bb344:
  %t1547 = load i1, ptr %l797, !tbaa !21
  br i1 %t1547, label %bb345, label %bb346
bb345:
  %t1548 = load ptr, ptr %l0, !tbaa !29
  %t1550 = getelementptr %"compiler/check:Checker", ptr %t1548, i32 0, i32 1
  %t1551 = load ptr, ptr %t1550, !tbaa !29
  store ptr %t1551, ptr %l803, !tbaa !29
  %t1552 = load ptr, ptr %l0, !tbaa !29
  %t1554 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1552)
  store ptr %t1554, ptr %l805
  br label %bb347
bb346:
  store i1 false, ptr %l801, !tbaa !21
  br label %bb349
bb347:
  %t1555 = load ptr, ptr %l805, !tbaa !29
  %t1557 = getelementptr %"compiler/check:frame", ptr %t1555, i32 0, i32 1
  %t1558 = load i64, ptr %t1557, !tbaa !24
  %t1559 = load ptr, ptr %l803, !tbaa !29
  %t1561 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t1559, i64 %t1558)
  store i1 %t1561, ptr %l808
  br label %bb348
bb348:
  %t1562 = load i1, ptr %l808, !tbaa !21
  store i1 %t1562, ptr %l801, !tbaa !21
  br label %bb349
bb349:
  %t1563 = load i1, ptr %l801, !tbaa !21
  br i1 %t1563, label %bb350, label %bb351
bb350:
  %t1564 = load ptr, ptr %l4, !tbaa !29
  %t1566 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t1564)
  store ptr %t1566, ptr %l810
  br label %bb352
bb351:
  br label %bb366
bb352:
  %t1567 = load ptr, ptr %l810, !tbaa !29
  store ptr %t1567, ptr %l47, !tbaa !29
  %t1568 = load ptr, ptr %l47, !tbaa !29
  %t1570 = icmp eq ptr %t1568, null
  br i1 %t1570, label %bb353, label %bb354
bb353:
  store i1 true, ptr %l813, !tbaa !21
  br label %bb356
bb354:
  %t1572 = load ptr, ptr %l0, !tbaa !29
  %t1573 = load ptr, ptr %l47, !tbaa !29
  %t1576 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v5, ptr %t1572, ptr %t1573)
  store i1 %t1576, ptr %l816
  br label %bb355
bb355:
  %t1577 = load i1, ptr %l816, !tbaa !21
  %t1578 = xor i1 %t1577, true
  store i1 %t1578, ptr %l813, !tbaa !21
  br label %bb356
bb356:
  %t1580 = load i1, ptr %l813, !tbaa !21
  br i1 %t1580, label %bb357, label %bb358
bb357:
  %t1581 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1581, ptr %l818, !tbaa !29
  %t1582 = load ptr, ptr %l0, !tbaa !29
  %t1583 = load ptr, ptr %l3, !tbaa !29
  %t1586 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1582, ptr %t1583)
  store %"compiler/source:Span" %t1586, ptr %l821
  br label %bb359
bb358:
  br label %bb363
bb359:
  %t1587 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %v0)
  store %"compiler/diagmsg:Msg" %t1587, ptr %l822
  br label %bb360
bb360:
  %t1588 = load ptr, ptr %l818, !tbaa !29
  %t1589 = load %"compiler/source:Span", ptr %l821
  %t1590 = load %"compiler/diagmsg:Msg", ptr %l822
  %t1591 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1588, %"compiler/source:Span" %t1589, %"compiler/diagmsg:Msg" %t1590)
  store i64 %t1591, ptr %l823
  br label %bb361
bb361:
  %t1592 = load ptr, ptr %l0, !tbaa !29
  %t1593 = load %"compiler/source:Span", ptr %l1
  %t1596 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1592, %"compiler/source:Span" %t1593)
  store ptr %t1596, ptr %l826
  br label %bb362
bb362:
  %t1597 = load ptr, ptr %l826, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1597, ptr %rv
  br label %ret
bb363:
  %t1599 = load ptr, ptr %l0, !tbaa !29
  %t1600 = load ptr, ptr %l47, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v5, ptr %t1599, ptr %t1600)
  br label %bb364
bb364:
  %t1603 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1603, ptr %l830
  %t1604 = load ptr, ptr %l47, !tbaa !29
  %t1606 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v5, ptr %t1604)
  store i32 %t1606, ptr %l832
  br label %bb365
bb365:
  %t1607 = load ptr, ptr %l47, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t1608
  %t1609 = getelementptr { i64, [5 x i64] }, ptr %t1608, i32 0, i32 0
  store i64 4, ptr %t1609
  %t1610 = load %"compiler/source:Span", ptr %l830
  %t1611 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1610, 0
  %t1612 = load i32, ptr %l832, !tbaa !23
  %t1613 = insertvalue { %"compiler/source:Span", i32, ptr } %t1611, i32 %t1612, 1
  %t1615 = insertvalue { %"compiler/source:Span", i32, ptr } %t1613, ptr %t1607, 2
  %t1616 = getelementptr { i64, [5 x i64] }, ptr %t1608, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1615, ptr %t1616
  %t1617 = load { i64, [5 x i64] }, ptr %t1608
  %t1619 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t1617, ptr %t1619
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1619, ptr %rv
  br label %ret
bb366:
  %t1621 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1623 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t1621, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d63, i32 0, i32 1) })
  store i1 %t1623, ptr %l837
  br label %bb367
bb367:
  %t1624 = load i1, ptr %l837, !tbaa !21
  br i1 %t1624, label %bb368, label %bb369
bb368:
  %t1625 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1627 = extractvalue { i64, ptr } %t1625, 0
  %t1629 = icmp eq i64 %t1627, 1
  store i1 %t1629, ptr %l838, !tbaa !21
  br label %bb370
bb369:
  store i1 false, ptr %l838, !tbaa !21
  br label %bb370
bb370:
  %t1631 = load i1, ptr %l838, !tbaa !21
  br i1 %t1631, label %bb371, label %bb372
bb371:
  %t1632 = load ptr, ptr %l0, !tbaa !29
  %t1634 = getelementptr %"compiler/check:Checker", ptr %t1632, i32 0, i32 1
  %t1635 = load ptr, ptr %t1634, !tbaa !29
  store ptr %t1635, ptr %l844, !tbaa !29
  %t1636 = load ptr, ptr %l0, !tbaa !29
  %t1638 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1636)
  store ptr %t1638, ptr %l846
  br label %bb373
bb372:
  store i1 false, ptr %l842, !tbaa !21
  br label %bb375
bb373:
  %t1639 = load ptr, ptr %l846, !tbaa !29
  %t1641 = getelementptr %"compiler/check:frame", ptr %t1639, i32 0, i32 1
  %t1642 = load i64, ptr %t1641, !tbaa !24
  %t1643 = load ptr, ptr %l844, !tbaa !29
  %t1645 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %t1643, i64 %t1642)
  store i1 %t1645, ptr %l849
  br label %bb374
bb374:
  %t1646 = load i1, ptr %l849, !tbaa !21
  store i1 %t1646, ptr %l842, !tbaa !21
  br label %bb375
bb375:
  %t1647 = load i1, ptr %l842, !tbaa !21
  br i1 %t1647, label %bb376, label %bb377
bb376:
  store %olang.scope zeroinitializer, ptr %s28
  %t1648 = load ptr, ptr %l4, !tbaa !29
  %t1650 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t1648)
  store ptr %t1650, ptr %l851
  br label %bb378
bb377:
  br label %bb395
bb378:
  %t1651 = load ptr, ptr %l851, !tbaa !29
  store ptr %t1651, ptr %l48, !tbaa !29
  %t1652 = load ptr, ptr %l48, !tbaa !29
  %t1654 = icmp eq ptr %t1652, null
  br i1 %t1654, label %bb379, label %bb380
bb379:
  store i1 true, ptr %l854, !tbaa !21
  br label %bb382
bb380:
  %t1656 = load ptr, ptr %l0, !tbaa !29
  %t1657 = load ptr, ptr %l48, !tbaa !29
  %t1660 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v5, ptr %t1656, ptr %t1657)
  store i1 %t1660, ptr %l857
  br label %bb381
bb381:
  %t1661 = load i1, ptr %l857, !tbaa !21
  %t1662 = xor i1 %t1661, true
  store i1 %t1662, ptr %l854, !tbaa !21
  br label %bb382
bb382:
  %t1664 = load i1, ptr %l854, !tbaa !21
  br i1 %t1664, label %bb383, label %bb384
bb383:
  %t1665 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1665, ptr %l859, !tbaa !29
  %t1666 = load ptr, ptr %l0, !tbaa !29
  %t1667 = load ptr, ptr %l3, !tbaa !29
  %t1670 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1666, ptr %t1667)
  store %"compiler/source:Span" %t1670, ptr %l862
  br label %bb385
bb384:
  br label %bb389
bb385:
  %t1671 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %v0)
  store %"compiler/diagmsg:Msg" %t1671, ptr %l863
  br label %bb386
bb386:
  %t1672 = load ptr, ptr %l859, !tbaa !29
  %t1673 = load %"compiler/source:Span", ptr %l862
  %t1674 = load %"compiler/diagmsg:Msg", ptr %l863
  %t1675 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1672, %"compiler/source:Span" %t1673, %"compiler/diagmsg:Msg" %t1674)
  store i64 %t1675, ptr %l864
  br label %bb387
bb387:
  %t1676 = load ptr, ptr %l0, !tbaa !29
  %t1677 = load %"compiler/source:Span", ptr %l1
  %t1680 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1676, %"compiler/source:Span" %t1677)
  store ptr %t1680, ptr %l867
  br label %bb388
bb388:
  %t1681 = load ptr, ptr %l867, !tbaa !29
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1681, ptr %rv
  br label %ret
bb389:
  %t1683 = load ptr, ptr %l0, !tbaa !29
  %t1685 = getelementptr %"compiler/check:Checker", ptr %t1683, i32 0, i32 37
  %t1687 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1685)
  store i64 %t1687, ptr %l871
  br label %bb390
bb390:
  %t1688 = load i64, ptr %l871, !tbaa !24
  store i64 %t1688, ptr %l49, !tbaa !24
  %t1689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1689, ptr %l872, !tbaa !29
  %t1690 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1690, ptr %l873
  %t1691 = load ptr, ptr %l48, !tbaa !29
  store ptr %t1691, ptr %l874, !tbaa !29
  %t1692 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1692, ptr %l875, !tbaa !27
  %t1693 = getelementptr { i64, ptr }, ptr %l875, i32 0, i32 1
  %t1694 = load ptr, ptr %t1693, !tbaa !27
  %t1695 = getelementptr ptr, ptr %t1694, i64 0
  %t1696 = load ptr, ptr %t1695, !tbaa !39
  store ptr %t1696, ptr %l876, !tbaa !29
  %t1697 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1697, ptr %l877, !tbaa !27
  %t1698 = getelementptr { i64, ptr }, ptr %l877, i32 0, i32 1
  %t1699 = load ptr, ptr %t1698, !tbaa !27
  %t1700 = getelementptr ptr, ptr %t1699, i64 0
  %t1701 = load ptr, ptr %t1700, !tbaa !39
  %t1703 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v4, ptr %t1701)
  store %"compiler/source:Span" %t1703, ptr %l879
  br label %bb391
bb391:
  %t1704 = load ptr, ptr %l872, !tbaa !29
  %t1705 = load %"compiler/source:Span", ptr %l873
  %t1706 = load ptr, ptr %l874, !tbaa !29
  %t1707 = load ptr, ptr %l876, !tbaa !29
  %t1708 = load %"compiler/source:Span", ptr %l879
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v5, ptr %v4, ptr %s28, ptr %t1704, %"compiler/source:Span" %t1705, ptr %t1706, ptr %t1707, %"compiler/source:Span" %t1708, ptr null, i1 true)
  br label %bb392
bb392:
  %t1709 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1709, ptr %l880
  %t1710 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t1710, ptr %l881, !tbaa !23
  %t1711 = load ptr, ptr %l0, !tbaa !29
  %t1713 = getelementptr %"compiler/check:Checker", ptr %t1711, i32 0, i32 37
  %t1714 = load i64, ptr %l49, !tbaa !24
  %t1717 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t1713, i64 %t1714)
  store { i64, ptr } %t1717, ptr %l885
  br label %bb393
bb393:
  %t1718 = load { i64, ptr }, ptr %l885, !tbaa !27
  %t1719 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v5, ptr %v5, { i64, ptr } %t1718, ptr null, i1 false)
  store %"compiler/typed:Seq" %t1719, ptr %l886
  br label %bb394
bb394:
  %t1720 = load %"compiler/typed:Seq", ptr %l886
  %t1721 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store %"compiler/typed:Seq" %t1720, ptr %t1721
  store { i64, [5 x i64] } zeroinitializer, ptr %t1722
  %t1723 = getelementptr { i64, [5 x i64] }, ptr %t1722, i32 0, i32 0
  store i64 12, ptr %t1723
  %t1724 = load %"compiler/source:Span", ptr %l880
  %t1725 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1724, 0
  %t1726 = load i32, ptr %l881, !tbaa !23
  %t1727 = insertvalue { %"compiler/source:Span", i32, ptr } %t1725, i32 %t1726, 1
  %t1729 = insertvalue { %"compiler/source:Span", i32, ptr } %t1727, ptr %t1721, 2
  %t1730 = getelementptr { i64, [5 x i64] }, ptr %t1722, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1729, ptr %t1730
  %t1731 = load { i64, [5 x i64] }, ptr %t1722
  %t1733 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t1731, ptr %t1733
  call void @__olang_scope_close(ptr %s28)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1733, ptr %rv
  br label %ret
bb395:
  %t1735 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1737 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v3, ptr %s0, { i64, ptr } %t1735, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t1737, ptr %l891
  br label %bb396
bb396:
  %t1738 = load i1, ptr %l891, !tbaa !21
  br i1 %t1738, label %bb397, label %bb398
bb397:
  store %olang.scope zeroinitializer, ptr %s30
  store i32 24, ptr %l50
  store i64 0, ptr %l51, !tbaa !24
  %t1740 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1742 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s30, { i64, ptr } %t1740, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t1742, ptr %l894
  br label %bb399
bb398:
  br label %bb487
bb399:
  %t1743 = load i1, ptr %l894, !tbaa !21
  br i1 %t1743, label %bb400, label %bb401
bb400:
  store i32 25, ptr %l50
  store i64 1, ptr %l51, !tbaa !24
  br label %bb418
bb401:
  store %olang.scope zeroinitializer, ptr %s32
  %t1745 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1747 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s32, { i64, ptr } %t1745, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t1747, ptr %l897
  br label %bb402
bb402:
  %t1748 = load i1, ptr %l897, !tbaa !21
  br i1 %t1748, label %bb403, label %bb404
bb403:
  store i32 26, ptr %l50
  store i64 1, ptr %l51, !tbaa !24
  br label %bb417
bb404:
  store %olang.scope zeroinitializer, ptr %s34
  %t1750 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1752 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s34, { i64, ptr } %t1750, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t1752, ptr %l900
  br label %bb405
bb405:
  %t1753 = load i1, ptr %l900, !tbaa !21
  br i1 %t1753, label %bb406, label %bb407
bb406:
  store i32 27, ptr %l50
  store i64 1, ptr %l51, !tbaa !24
  br label %bb416
bb407:
  store %olang.scope zeroinitializer, ptr %s36
  %t1755 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1757 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s36, { i64, ptr } %t1755, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d68, i32 0, i32 1) })
  store i1 %t1757, ptr %l903
  br label %bb408
bb408:
  %t1758 = load i1, ptr %l903, !tbaa !21
  br i1 %t1758, label %bb409, label %bb410
bb409:
  store i32 28, ptr %l50
  store i64 2, ptr %l51, !tbaa !24
  br label %bb415
bb410:
  store %olang.scope zeroinitializer, ptr %s38
  %t1760 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t1762 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s38, { i64, ptr } %t1760, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t1762, ptr %l906
  br label %bb411
bb411:
  %t1763 = load i1, ptr %l906, !tbaa !21
  %t1764 = xor i1 %t1763, true
  br i1 %t1764, label %bb412, label %bb413
bb412:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb413:
  br label %bb414
bb414:
  call void @__olang_scope_close(ptr %s38)
  br label %bb415
bb415:
  call void @__olang_scope_close(ptr %s36)
  br label %bb416
bb416:
  call void @__olang_scope_close(ptr %s34)
  br label %bb417
bb417:
  call void @__olang_scope_close(ptr %s32)
  br label %bb418
bb418:
  %t1767 = load ptr, ptr %l0, !tbaa !29
  %t1769 = getelementptr %"compiler/check:Checker", ptr %t1767, i32 0, i32 1
  %t1770 = load ptr, ptr %t1769, !tbaa !29
  %t1772 = getelementptr %"compiler/generic:Program", ptr %t1770, i32 0, i32 2
  %t1773 = load i32, ptr %l8, !tbaa !23
  %t1776 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t1772, i32 %t1773)
  store i1 %t1776, ptr %l913
  br label %bb419
bb419:
  %t1777 = load i1, ptr %l913, !tbaa !21
  %t1778 = xor i1 %t1777, true
  br i1 %t1778, label %bb420, label %bb421
bb420:
  %t1780 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1780, ptr %l915, !tbaa !29
  %t1781 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1781, ptr %l916
  %t1782 = load ptr, ptr %l0, !tbaa !29
  %t1783 = load i32, ptr %l7, !tbaa !23
  %t1786 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t1782, i32 %t1783)
  store { i64, ptr } %t1786, ptr %l919
  br label %bb422
bb421:
  br label %bb426
bb422:
  %t1787 = load { i64, ptr }, ptr %l919, !tbaa !27
  %t1788 = extractvalue { i64, ptr } %t1787, 0
  %t1789 = extractvalue { i64, ptr } %t1787, 1
  %t1790 = mul i64 %t1788, 1
  %t1791 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1790)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1791, ptr %t1789, i64 %t1790, i1 false)
  %t1792 = insertvalue { i64, ptr } undef, i64 %t1788, 0
  %t1793 = insertvalue { i64, ptr } %t1792, ptr %t1791, 1
  %t1795 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v0, { i64, ptr } %t1793)
  store %"compiler/diagmsg:Msg" %t1795, ptr %l921
  br label %bb423
bb423:
  %t1796 = load ptr, ptr %l915, !tbaa !29
  %t1797 = load %"compiler/source:Span", ptr %l916
  %t1798 = load %"compiler/diagmsg:Msg", ptr %l921
  %t1799 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1796, %"compiler/source:Span" %t1797, %"compiler/diagmsg:Msg" %t1798)
  store i64 %t1799, ptr %l922
  br label %bb424
bb424:
  %t1800 = load ptr, ptr %l0, !tbaa !29
  %t1801 = load %"compiler/source:Span", ptr %l1
  %t1804 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1800, %"compiler/source:Span" %t1801)
  store ptr %t1804, ptr %l925
  br label %bb425
bb425:
  %t1805 = load ptr, ptr %l925, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1805, ptr %rv
  br label %ret
bb426:
  %t1807 = load i32, ptr %l8, !tbaa !23
  %t1809 = icmp sgt i32 %t1807, 14
  br i1 %t1809, label %bb427, label %bb428
bb427:
  %t1811 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1811, ptr %l929, !tbaa !29
  %t1812 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1812, ptr %l930
  %t1813 = load ptr, ptr %l0, !tbaa !29
  %t1814 = load i32, ptr %l7, !tbaa !23
  %t1817 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t1813, i32 %t1814)
  store { i64, ptr } %t1817, ptr %l933
  br label %bb429
bb428:
  br label %bb433
bb429:
  %t1818 = load { i64, ptr }, ptr %l933, !tbaa !27
  %t1819 = extractvalue { i64, ptr } %t1818, 0
  %t1820 = extractvalue { i64, ptr } %t1818, 1
  %t1821 = mul i64 %t1819, 1
  %t1822 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t1821)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1822, ptr %t1820, i64 %t1821, i1 false)
  %t1823 = insertvalue { i64, ptr } undef, i64 %t1819, 0
  %t1824 = insertvalue { i64, ptr } %t1823, ptr %t1822, 1
  %t1826 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %v0, ptr %v0, { i64, ptr } %t1824)
  store %"compiler/diagmsg:Msg" %t1826, ptr %l935
  br label %bb430
bb430:
  %t1827 = load ptr, ptr %l929, !tbaa !29
  %t1828 = load %"compiler/source:Span", ptr %l930
  %t1829 = load %"compiler/diagmsg:Msg", ptr %l935
  %t1830 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1827, %"compiler/source:Span" %t1828, %"compiler/diagmsg:Msg" %t1829)
  store i64 %t1830, ptr %l936
  br label %bb431
bb431:
  %t1831 = load ptr, ptr %l0, !tbaa !29
  %t1832 = load %"compiler/source:Span", ptr %l1
  %t1835 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1831, %"compiler/source:Span" %t1832)
  store ptr %t1835, ptr %l939
  br label %bb432
bb432:
  %t1836 = load ptr, ptr %l939, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1836, ptr %rv
  br label %ret
bb433:
  %t1838 = load ptr, ptr %l4, !tbaa !29
  %t1840 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v5, ptr %t1838)
  store ptr %t1840, ptr %l942
  br label %bb434
bb434:
  %t1841 = load ptr, ptr %l942, !tbaa !29
  store ptr %t1841, ptr %l52, !tbaa !29
  %t1842 = load ptr, ptr %l52, !tbaa !29
  %t1844 = icmp eq ptr %t1842, null
  br i1 %t1844, label %bb435, label %bb436
bb435:
  %t1846 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1846, ptr %l945, !tbaa !29
  %t1847 = load ptr, ptr %l0, !tbaa !29
  %t1848 = load ptr, ptr %l3, !tbaa !29
  %t1851 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1847, ptr %t1848)
  store %"compiler/source:Span" %t1851, ptr %l948
  br label %bb437
bb436:
  br label %bb441
bb437:
  %t1852 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0)
  store %"compiler/diagmsg:Msg" %t1852, ptr %l949
  br label %bb438
bb438:
  %t1853 = load ptr, ptr %l945, !tbaa !29
  %t1854 = load %"compiler/source:Span", ptr %l948
  %t1855 = load %"compiler/diagmsg:Msg", ptr %l949
  %t1856 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1853, %"compiler/source:Span" %t1854, %"compiler/diagmsg:Msg" %t1855)
  store i64 %t1856, ptr %l950
  br label %bb439
bb439:
  %t1857 = load ptr, ptr %l0, !tbaa !29
  %t1858 = load %"compiler/source:Span", ptr %l1
  %t1861 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1857, %"compiler/source:Span" %t1858)
  store ptr %t1861, ptr %l953
  br label %bb440
bb440:
  %t1862 = load ptr, ptr %l953, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1862, ptr %rv
  br label %ret
bb441:
  %t1864 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1864, ptr %l955, !tbaa !29
  %t1865 = load ptr, ptr %l52, !tbaa !29
  store ptr %t1865, ptr %l956, !tbaa !29
  %t1866 = load ptr, ptr %l0, !tbaa !29
  %t1867 = load ptr, ptr %l3, !tbaa !29
  %t1870 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1866, ptr %t1867)
  store %"compiler/source:Span" %t1870, ptr %l959
  br label %bb442
bb442:
  %t1871 = load ptr, ptr %l955, !tbaa !29
  %t1872 = load ptr, ptr %l956, !tbaa !29
  %t1873 = load %"compiler/source:Span", ptr %l959
  %t1874 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v5, ptr %t1871, ptr %t1872, %"compiler/source:Span" %t1873)
  store i1 %t1874, ptr %l960
  br label %bb443
bb443:
  %t1875 = load i1, ptr %l960, !tbaa !21
  br i1 %t1875, label %bb444, label %bb445
bb444:
  %t1876 = load ptr, ptr %l0, !tbaa !29
  %t1877 = load %"compiler/source:Span", ptr %l1
  %t1880 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1876, %"compiler/source:Span" %t1877)
  store ptr %t1880, ptr %l963
  br label %bb446
bb445:
  br label %bb447
bb446:
  %t1881 = load ptr, ptr %l963, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1881, ptr %rv
  br label %ret
bb447:
  %t1883 = load i32, ptr %l50, !range !{i32 0, i32 52}
  %t1885 = trunc i64 24 to i32
  %t1886 = icmp eq i32 %t1883, %t1885
  %t1888 = xor i1 %t1886, true
  br i1 %t1888, label %bb448, label %bb449
bb448:
  %t1890 = load ptr, ptr %l0, !tbaa !29
  %t1891 = load ptr, ptr %l52, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v5, ptr %t1890, ptr %t1891)
  br label %bb450
bb449:
  br label %bb451
bb450:
  br label %bb451
bb451:
  %t1894 = load i32, ptr %l50, !range !{i32 0, i32 52}
  %t1896 = trunc i64 24 to i32
  %t1897 = icmp eq i32 %t1894, %t1896
  %t1899 = xor i1 %t1897, true
  br i1 %t1899, label %bb452, label %bb453
bb452:
  %t1901 = load ptr, ptr %l0, !tbaa !29
  %t1902 = load ptr, ptr %l52, !tbaa !29
  %t1905 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v5, ptr %t1901, ptr %t1902)
  store i1 %t1905, ptr %l976
  br label %bb454
bb453:
  store i1 false, ptr %l973, !tbaa !21
  br label %bb455
bb454:
  %t1906 = load i1, ptr %l976, !tbaa !21
  %t1907 = xor i1 %t1906, true
  store i1 %t1907, ptr %l973, !tbaa !21
  br label %bb455
bb455:
  %t1909 = load i1, ptr %l973, !tbaa !21
  br i1 %t1909, label %bb456, label %bb457
bb456:
  %t1910 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1910, ptr %l978, !tbaa !29
  %t1911 = load ptr, ptr %l0, !tbaa !29
  %t1912 = load ptr, ptr %l3, !tbaa !29
  %t1915 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %t1911, ptr %t1912)
  store %"compiler/source:Span" %t1915, ptr %l981
  br label %bb458
bb457:
  br label %bb462
bb458:
  %t1916 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0)
  store %"compiler/diagmsg:Msg" %t1916, ptr %l982
  br label %bb459
bb459:
  %t1917 = load ptr, ptr %l978, !tbaa !29
  %t1918 = load %"compiler/source:Span", ptr %l981
  %t1919 = load %"compiler/diagmsg:Msg", ptr %l982
  %t1920 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1917, %"compiler/source:Span" %t1918, %"compiler/diagmsg:Msg" %t1919)
  store i64 %t1920, ptr %l983
  br label %bb460
bb460:
  %t1921 = load ptr, ptr %l0, !tbaa !29
  %t1922 = load %"compiler/source:Span", ptr %l1
  %t1925 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1921, %"compiler/source:Span" %t1922)
  store ptr %t1925, ptr %l986
  br label %bb461
bb461:
  %t1926 = load ptr, ptr %l986, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1926, ptr %rv
  br label %ret
bb462:
  %t1928 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1930 = extractvalue { i64, ptr } %t1928, 0
  %t1931 = load i64, ptr %l51, !tbaa !24
  %t1934 = icmp ne i64 %t1930, %t1931
  br i1 %t1934, label %bb463, label %bb464
bb463:
  %t1936 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1936, ptr %l992, !tbaa !29
  %t1937 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1937, ptr %l993
  %t1938 = load i64, ptr %l51, !tbaa !24
  store i64 %t1938, ptr %l994, !tbaa !24
  %t1939 = load i64, ptr %l51, !tbaa !24
  %t1941 = icmp eq i64 %t1939, 1
  br i1 %t1941, label %bb465, label %bb466
bb464:
  br label %bb471
bb465:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l997, !tbaa !27
  br label %bb467
bb466:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l997, !tbaa !27
  br label %bb467
bb467:
  %t1943 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t1945 = extractvalue { i64, ptr } %t1943, 0
  %t1946 = load i64, ptr %l994, !tbaa !24
  %t1947 = load { i64, ptr }, ptr %l997, !tbaa !27
  %t1949 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v0, i64 %t1946, { i64, ptr } %t1947, i64 %t1945)
  store %"compiler/diagmsg:Msg" %t1949, ptr %l1000
  br label %bb468
bb468:
  %t1950 = load ptr, ptr %l992, !tbaa !29
  %t1951 = load %"compiler/source:Span", ptr %l993
  %t1952 = load %"compiler/diagmsg:Msg", ptr %l1000
  %t1953 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t1950, %"compiler/source:Span" %t1951, %"compiler/diagmsg:Msg" %t1952)
  store i64 %t1953, ptr %l1001
  br label %bb469
bb469:
  %t1954 = load ptr, ptr %l0, !tbaa !29
  %t1955 = load %"compiler/source:Span", ptr %l1
  %t1958 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t1954, %"compiler/source:Span" %t1955)
  store ptr %t1958, ptr %l1004
  br label %bb470
bb470:
  %t1959 = load ptr, ptr %l1004, !tbaa !29
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1959, ptr %rv
  br label %ret
bb471:
  %t1961 = load ptr, ptr %l0, !tbaa !29
  %t1963 = getelementptr %"compiler/check:Checker", ptr %t1961, i32 0, i32 36
  %t1965 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1963)
  store i64 %t1965, ptr %l1008
  br label %bb472
bb472:
  %t1966 = load i64, ptr %l1008, !tbaa !24
  store i64 %t1966, ptr %l53, !tbaa !24
  %t1967 = load ptr, ptr %l0, !tbaa !29
  %t1969 = getelementptr %"compiler/check:Checker", ptr %t1967, i32 0, i32 36
  store ptr %t1969, ptr %l1010, !tbaa !29
  %t1970 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t1970, ptr %l1011
  %t1971 = load ptr, ptr %l0, !tbaa !29
  %t1973 = getelementptr %"compiler/check:Checker", ptr %t1971, i32 0, i32 1
  %t1974 = load ptr, ptr %t1973, !tbaa !29
  %t1976 = getelementptr %"compiler/generic:Program", ptr %t1974, i32 0, i32 2
  %t1977 = load i32, ptr %l7, !tbaa !23
  %t1978 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1982 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1976, i32 %t1977, i64 %t1978)
  store i32 %t1982, ptr %l1017
  br label %bb473
bb473:
  %t1983 = load ptr, ptr %l52, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t1984
  %t1985 = getelementptr { i64, [5 x i64] }, ptr %t1984, i32 0, i32 0
  store i64 3, ptr %t1985
  %t1986 = load %"compiler/source:Span", ptr %l1011
  %t1987 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1986, 0
  %t1988 = load i32, ptr %l1017, !tbaa !23
  %t1989 = insertvalue { %"compiler/source:Span", i32, ptr } %t1987, i32 %t1988, 1
  %t1991 = insertvalue { %"compiler/source:Span", i32, ptr } %t1989, ptr %t1983, 2
  %t1992 = getelementptr { i64, [5 x i64] }, ptr %t1984, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1991, ptr %t1992
  %t1993 = load { i64, [5 x i64] }, ptr %t1984
  %t1995 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1993, ptr %t1995
  %t1996 = load ptr, ptr %l1010, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t1996, ptr %t1995)
  br label %bb474
bb474:
  %t1998 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t1998, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t2000 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t2002 = extractvalue { i64, ptr } %t2000, 0
  store i64 %t2002, ptr %l56, !tbaa !24
  br label %bb475
bb475:
  %t2004 = load i64, ptr %l55, !tbaa !24
  %t2005 = load i64, ptr %l56, !tbaa !24
  %t2008 = icmp slt i64 %t2004, %t2005
  %t2010 = xor i1 %t2008, true
  br i1 %t2010, label %bb476, label %bb477
bb476:
  br label %bb482
bb477:
  br label %bb478
bb478:
  %t2012 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t2012, ptr %l1028, !tbaa !27
  %t2013 = load i64, ptr %l55, !tbaa !24
  %t2015 = getelementptr { i64, ptr }, ptr %l1028, i32 0, i32 1
  %t2016 = load ptr, ptr %t2015, !tbaa !27
  %t2017 = getelementptr ptr, ptr %t2016, i64 %t2013
  %t2018 = load ptr, ptr %t2017, !tbaa !39
  %t2020 = load ptr, ptr %l0, !tbaa !29
  %t2022 = getelementptr %"compiler/check:Checker", ptr %t2020, i32 0, i32 36
  store ptr %t2022, ptr %l1032, !tbaa !29
  %t2023 = load ptr, ptr %l0, !tbaa !29
  %t2025 = load i32, ptr %l7, !tbaa !23
  %t2029 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v4, ptr %v0, ptr %t2023, ptr %t2018, i32 %t2025)
  store ptr %t2029, ptr %l1036
  br label %bb479
bb479:
  %t2030 = load ptr, ptr %l1032, !tbaa !29
  %t2031 = load ptr, ptr %l1036, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t2030, ptr %t2031)
  br label %bb480
bb480:
  br label %bb481
bb481:
  %t2032 = load i64, ptr %l55, !tbaa !24
  %t2034 = add i64 %t2032, 1
  store i64 %t2034, ptr %l55, !tbaa !24
  br label %bb475
bb482:
  %t2036 = load i32, ptr %l50, !range !{i32 0, i32 52}
  %t2038 = trunc i64 25 to i32
  %t2039 = icmp eq i32 %t2036, %t2038
  br i1 %t2039, label %bb483, label %bb484
bb483:
  %t2041 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t2041, ptr %l1041, !tbaa !23
  br label %bb485
bb484:
  %t2043 = load i32, ptr %l7, !tbaa !23
  store i32 %t2043, ptr %l1041, !tbaa !23
  br label %bb485
bb485:
  %t2045 = load i32, ptr %l1041, !tbaa !23
  %t2046 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2046, ptr %l1044
  store i32 %t2045, ptr %l1045, !tbaa !23
  %t2048 = load i32, ptr %l50, !range !{i32 0, i32 52}
  store i32 %t2048, ptr %l1046
  store i32 0, ptr %l1047
  %t2049 = load ptr, ptr %l0, !tbaa !29
  %t2051 = getelementptr %"compiler/check:Checker", ptr %t2049, i32 0, i32 36
  %t2052 = load i64, ptr %l53, !tbaa !24
  %t2055 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v5, ptr %t2051, i64 %t2052)
  store { i64, ptr } %t2055, ptr %l1051
  br label %bb486
bb486:
  store { i64, [5 x i64] } zeroinitializer, ptr %t2056
  %t2057 = getelementptr { i64, [5 x i64] }, ptr %t2056, i32 0, i32 0
  store i64 9, ptr %t2057
  %t2058 = load %"compiler/source:Span", ptr %l1044
  %t2059 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t2058, 0
  %t2060 = load i32, ptr %l1045, !tbaa !23
  %t2061 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2059, i32 %t2060, 1
  %t2062 = load i32, ptr %l1046, !range !{i32 0, i32 52}
  %t2063 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2061, i32 %t2062, 2
  %t2064 = load i32, ptr %l1047, !range !{i32 0, i32 3}
  %t2065 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2063, i32 %t2064, 3
  %t2066 = load { i64, ptr }, ptr %l1051, !tbaa !27
  %t2067 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2065, { i64, ptr } %t2066, 4
  %t2068 = getelementptr { i64, [5 x i64] }, ptr %t2056, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t2067, ptr %t2068
  %t2069 = load { i64, [5 x i64] }, ptr %t2056
  %t2071 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t2069, ptr %t2071
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2071, ptr %rv
  br label %ret
bb487:
  %t2073 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t2075 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t2073, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t2075, ptr %l1055
  br label %bb488
bb488:
  %t2076 = load i1, ptr %l1055, !tbaa !21
  br i1 %t2076, label %bb489, label %bb490
bb489:
  %t2077 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t2079 = extractvalue { i64, ptr } %t2077, 0
  %t2081 = icmp eq i64 %t2079, 0
  store i1 %t2081, ptr %l1056, !tbaa !21
  br label %bb491
bb490:
  store i1 false, ptr %l1056, !tbaa !21
  br label %bb491
bb491:
  %t2083 = load i1, ptr %l1056, !tbaa !21
  br i1 %t2083, label %bb492, label %bb493
bb492:
  %t2084 = load ptr, ptr %l4, !tbaa !29
  %t2087 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2084)
  store i32 %t2087, ptr %l1062
  br label %bb494
bb493:
  br label %bb538
bb494:
  %t2088 = load i32, ptr %l1062, !tbaa !23
  store i32 %t2088, ptr %l59, !tbaa !23
  %t2089 = load ptr, ptr %l0, !tbaa !29
  %t2091 = getelementptr %"compiler/check:Checker", ptr %t2089, i32 0, i32 1
  %t2092 = load ptr, ptr %t2091, !tbaa !29
  store ptr %t2092, ptr %l1064, !tbaa !29
  %t2093 = load ptr, ptr %l0, !tbaa !29
  %t2094 = load i32, ptr %l59, !tbaa !23
  %t2097 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2093, i32 %t2094)
  store i32 %t2097, ptr %l1067
  br label %bb495
bb495:
  %t2098 = load ptr, ptr %l1064, !tbaa !29
  %t2099 = load i32, ptr %l1067, !tbaa !23
  %t2100 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t2098, i32 %t2099)
  store i1 %t2100, ptr %l1068
  br label %bb496
bb496:
  %t2101 = load i1, ptr %l1068, !tbaa !21
  br i1 %t2101, label %bb497, label %bb498
bb497:
  %t2102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2102, ptr %l1069, !tbaa !29
  %t2103 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t2103, ptr %l1070
  %t2104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2104, ptr %l1071, !tbaa !29
  %t2105 = load ptr, ptr %l0, !tbaa !29
  %t2106 = load i32, ptr %l59, !tbaa !23
  %t2109 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2105, i32 %t2106)
  store i32 %t2109, ptr %l1074
  br label %bb499
bb498:
  br label %bb504
bb499:
  %t2110 = load ptr, ptr %l1071, !tbaa !29
  %t2111 = load i32, ptr %l1074, !tbaa !23
  %t2112 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t2110, i32 %t2111)
  store { i64, ptr } %t2112, ptr %l1075
  br label %bb500
bb500:
  %t2113 = load { i64, ptr }, ptr %l1075, !tbaa !27
  %t2114 = extractvalue { i64, ptr } %t2113, 0
  %t2115 = extractvalue { i64, ptr } %t2113, 1
  %t2116 = mul i64 %t2114, 1
  %t2117 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t2116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2117, ptr %t2115, i64 %t2116, i1 false)
  %t2118 = insertvalue { i64, ptr } undef, i64 %t2114, 0
  %t2119 = insertvalue { i64, ptr } %t2118, ptr %t2117, 1
  %t2121 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueCopy(ptr %v0, ptr %v0, { i64, ptr } %t2119)
  store %"compiler/diagmsg:Msg" %t2121, ptr %l1077
  br label %bb501
bb501:
  %t2122 = load ptr, ptr %l1069, !tbaa !29
  %t2123 = load %"compiler/source:Span", ptr %l1070
  %t2124 = load %"compiler/diagmsg:Msg", ptr %l1077
  %t2125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t2122, %"compiler/source:Span" %t2123, %"compiler/diagmsg:Msg" %t2124)
  store i64 %t2125, ptr %l1078
  br label %bb502
bb502:
  %t2126 = load ptr, ptr %l0, !tbaa !29
  %t2127 = load %"compiler/source:Span", ptr %l1
  %t2130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t2126, %"compiler/source:Span" %t2127)
  store ptr %t2130, ptr %l1081
  br label %bb503
bb503:
  %t2131 = load ptr, ptr %l1081, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2131, ptr %rv
  br label %ret
bb504:
  %t2133 = load ptr, ptr %l0, !tbaa !29
  %t2135 = getelementptr %"compiler/check:Checker", ptr %t2133, i32 0, i32 1
  %t2136 = load ptr, ptr %t2135, !tbaa !29
  store ptr %t2136, ptr %l1084, !tbaa !29
  %t2137 = load ptr, ptr %l0, !tbaa !29
  %t2138 = load i32, ptr %l59, !tbaa !23
  %t2141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2137, i32 %t2138)
  store i32 %t2141, ptr %l1087
  br label %bb505
bb505:
  %t2142 = load ptr, ptr %l1084, !tbaa !29
  %t2143 = load i32, ptr %l1087, !tbaa !23
  %t2144 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %t2142, i32 %t2143)
  store i1 %t2144, ptr %l1088
  br label %bb506
bb506:
  %t2145 = load i1, ptr %l1088, !tbaa !21
  br i1 %t2145, label %bb507, label %bb508
bb507:
  %t2146 = load ptr, ptr %l0, !tbaa !29
  %t2147 = load i32, ptr %l59, !tbaa !23
  %t2150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %t2146, i32 %t2147)
  store i1 %t2150, ptr %l1092
  br label %bb509
bb508:
  store i1 false, ptr %l1089, !tbaa !21
  br label %bb510
bb509:
  %t2151 = load i1, ptr %l1092, !tbaa !21
  store i1 %t2151, ptr %l1089, !tbaa !21
  br label %bb510
bb510:
  %t2152 = load i1, ptr %l1089, !tbaa !21
  br i1 %t2152, label %bb511, label %bb512
bb511:
  %t2153 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2153, ptr %l1093, !tbaa !29
  %t2154 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t2154, ptr %l1094
  %t2155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2155, ptr %l1095, !tbaa !29
  %t2156 = load ptr, ptr %l0, !tbaa !29
  %t2157 = load i32, ptr %l59, !tbaa !23
  %t2160 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2156, i32 %t2157)
  store i32 %t2160, ptr %l1098
  br label %bb513
bb512:
  br label %bb518
bb513:
  %t2161 = load ptr, ptr %l1095, !tbaa !29
  %t2162 = load i32, ptr %l1098, !tbaa !23
  %t2163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t2161, i32 %t2162)
  store { i64, ptr } %t2163, ptr %l1099
  br label %bb514
bb514:
  %t2164 = load { i64, ptr }, ptr %l1099, !tbaa !27
  %t2165 = extractvalue { i64, ptr } %t2164, 0
  %t2166 = extractvalue { i64, ptr } %t2164, 1
  %t2167 = mul i64 %t2165, 1
  %t2168 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t2167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2168, ptr %t2166, i64 %t2167, i1 false)
  %t2169 = insertvalue { i64, ptr } undef, i64 %t2165, 0
  %t2170 = insertvalue { i64, ptr } %t2169, ptr %t2168, 1
  %t2172 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenCopyDestruct(ptr %v0, ptr %v0, { i64, ptr } %t2170)
  store %"compiler/diagmsg:Msg" %t2172, ptr %l1101
  br label %bb515
bb515:
  %t2173 = load ptr, ptr %l1093, !tbaa !29
  %t2174 = load %"compiler/source:Span", ptr %l1094
  %t2175 = load %"compiler/diagmsg:Msg", ptr %l1101
  %t2176 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t2173, %"compiler/source:Span" %t2174, %"compiler/diagmsg:Msg" %t2175)
  store i64 %t2176, ptr %l1102
  br label %bb516
bb516:
  %t2177 = load ptr, ptr %l0, !tbaa !29
  %t2178 = load %"compiler/source:Span", ptr %l1
  %t2181 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v5, ptr %t2177, %"compiler/source:Span" %t2178)
  store ptr %t2181, ptr %l1105
  br label %bb517
bb517:
  %t2182 = load ptr, ptr %l1105, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2182, ptr %rv
  br label %ret
bb518:
  %t2184 = load ptr, ptr %l0, !tbaa !29
  %t2185 = load i32, ptr %l59, !tbaa !23
  %t2188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t2184, i32 %t2185)
  store i1 %t2188, ptr %l1109
  br label %bb519
bb519:
  %t2189 = load i1, ptr %l1109, !tbaa !21
  br i1 %t2189, label %bb520, label %bb521
bb520:
  %t2190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2190, ptr %l1111, !tbaa !29
  %t2191 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2191, ptr %l1112
  %t2192 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2192, ptr %l1113
  %t2193 = load ptr, ptr %l0, !tbaa !29
  %t2195 = getelementptr %"compiler/check:Checker", ptr %t2193, i32 0, i32 1
  %t2196 = load ptr, ptr %t2195, !tbaa !29
  %t2198 = getelementptr %"compiler/generic:Program", ptr %t2196, i32 0, i32 2
  %t2199 = load i32, ptr %l59, !tbaa !23
  %t2202 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t2198, i32 %t2199)
  store i32 %t2202, ptr %l1118
  br label %bb522
bb521:
  %t2203 = load ptr, ptr %l4, !tbaa !29
  store ptr %t2203, ptr %l1110, !tbaa !29
  br label %bb524
bb522:
  %t2205 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t2206
  %t2207 = getelementptr { i64, [4 x i64] }, ptr %t2206, i32 0, i32 0
  store i64 2, ptr %t2207
  %t2208 = load %"compiler/source:Span", ptr %l1113
  %t2209 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2208, 0
  %t2210 = load i32, ptr %l1118, !tbaa !23
  %t2211 = insertvalue { %"compiler/source:Span", i32, ptr } %t2209, i32 %t2210, 1
  %t2213 = insertvalue { %"compiler/source:Span", i32, ptr } %t2211, ptr %t2205, 2
  %t2214 = getelementptr { i64, [4 x i64] }, ptr %t2206, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2213, ptr %t2214
  %t2215 = load { i64, [4 x i64] }, ptr %t2206
  %t2217 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t2215, ptr %t2217
  %t2218 = load ptr, ptr %l1111, !tbaa !29
  %t2219 = load %"compiler/source:Span", ptr %l1112
  %t2221 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t2218, %"compiler/source:Span" %t2219, ptr %t2217)
  store ptr %t2221, ptr %l1122
  br label %bb523
bb523:
  %t2222 = load ptr, ptr %l1122, !tbaa !29
  store ptr %t2222, ptr %l1110, !tbaa !29
  br label %bb524
bb524:
  %t2223 = load ptr, ptr %l1110, !tbaa !29
  store ptr %t2223, ptr %l60, !tbaa !29
  %t2224 = load ptr, ptr %l60, !tbaa !29
  %t2226 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v2, ptr %t2224)
  store i1 %t2226, ptr %l1125
  br label %bb525
bb525:
  %t2227 = load i1, ptr %l1125, !tbaa !21
  %t2228 = xor i1 %t2227, true
  br i1 %t2228, label %bb526, label %bb527
bb526:
  %t2230 = load ptr, ptr %l60, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2230, ptr %rv
  br label %ret
bb527:
  br label %bb528
bb528:
  %t2233 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2233, ptr %l1129, !tbaa !29
  %t2234 = load ptr, ptr %l60, !tbaa !29
  %t2237 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2234)
  store i32 %t2237, ptr %l1132
  br label %bb529
bb529:
  %t2238 = load ptr, ptr %l1129, !tbaa !29
  %t2239 = load i32, ptr %l1132, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %t2238, i32 %t2239, i64 0)
  br label %bb530
bb530:
  %t2240 = load ptr, ptr %l60, !tbaa !29
  %t2242 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t2240)
  store %"compiler/source:Span" %t2242, ptr %l1134
  br label %bb531
bb531:
  %t2243 = load %"compiler/source:Span", ptr %l1134
  store %"compiler/source:Span" %t2243, ptr %l61
  %t2244 = load ptr, ptr %l0, !tbaa !29
  %t2246 = getelementptr %"compiler/check:Checker", ptr %t2244, i32 0, i32 36
  %t2248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2246)
  store i64 %t2248, ptr %l1137
  br label %bb532
bb532:
  %t2249 = load i64, ptr %l1137, !tbaa !24
  store i64 %t2249, ptr %l62, !tbaa !24
  %t2250 = load ptr, ptr %l0, !tbaa !29
  %t2252 = getelementptr %"compiler/check:Checker", ptr %t2250, i32 0, i32 36
  %t2253 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t2252, ptr %t2253)
  br label %bb533
bb533:
  %t2256 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t2256, ptr %l1141
  %t2257 = load ptr, ptr %l60, !tbaa !29
  %t2260 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2257)
  store i32 %t2260, ptr %l1144
  br label %bb534
bb534:
  store i32 4, ptr %l1145
  %t2261 = load ptr, ptr %l0, !tbaa !29
  %t2263 = getelementptr %"compiler/check:Checker", ptr %t2261, i32 0, i32 36
  %t2264 = load i64, ptr %l62, !tbaa !24
  %t2267 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t2263, i64 %t2264)
  store { i64, ptr } %t2267, ptr %l1149
  br label %bb535
bb535:
  %t2268 = load ptr, ptr %l0, !tbaa !29
  %t2269 = load %"compiler/source:Span", ptr %l61
  %t2273 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t2268, i32 1, %"compiler/source:Span" %t2269)
  store i32 %t2273, ptr %l1153
  br label %bb536
bb536:
  %t2274 = load i32, ptr %l1145, !range !{i32 0, i32 5}
  %t2275 = load { i64, ptr }, ptr %l1149, !tbaa !27
  %t2276 = load i32, ptr %l1153, !tbaa !23
  %t2278 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v5, ptr %v5, i32 %t2274, i64 0, { i64, ptr } %t2275, ptr null, i32 %t2276, i32 0, i1 false)
  store %"compiler/typed:Make" %t2278, ptr %l1155
  br label %bb537
bb537:
  %t2279 = load %"compiler/typed:Make", ptr %l1155
  %t2280 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 56, i64 8)
  store %"compiler/typed:Make" %t2279, ptr %t2280
  store { i64, [5 x i64] } zeroinitializer, ptr %t2281
  %t2282 = getelementptr { i64, [5 x i64] }, ptr %t2281, i32 0, i32 0
  store i64 7, ptr %t2282
  %t2283 = load %"compiler/source:Span", ptr %l1141
  %t2284 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t2283, 0
  %t2285 = load i32, ptr %l1144, !tbaa !23
  %t2286 = insertvalue { %"compiler/source:Span", i32, ptr } %t2284, i32 %t2285, 1
  %t2288 = insertvalue { %"compiler/source:Span", i32, ptr } %t2286, ptr %t2280, 2
  %t2289 = getelementptr { i64, [5 x i64] }, ptr %t2281, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t2288, ptr %t2289
  %t2290 = load { i64, [5 x i64] }, ptr %t2281
  %t2292 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 48, i64 8)
  store { i64, [5 x i64] } %t2290, ptr %t2292
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2292, ptr %rv
  br label %ret
bb538:
  %t2294 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t2296 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t2294, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) })
  store i1 %t2296, ptr %l1160
  br label %bb539
bb539:
  %t2297 = load i1, ptr %l1160, !tbaa !21
  br i1 %t2297, label %bb540, label %bb541
bb540:
  %t2298 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t2300 = extractvalue { i64, ptr } %t2298, 0
  %t2302 = icmp eq i64 %t2300, 0
  store i1 %t2302, ptr %l1161, !tbaa !21
  br label %bb542
bb541:
  store i1 false, ptr %l1161, !tbaa !21
  br label %bb542
bb542:
  %t2304 = load i1, ptr %l1161, !tbaa !21
  br i1 %t2304, label %bb543, label %bb544
bb543:
  store %olang.scope zeroinitializer, ptr %s54
  %t2305 = load ptr, ptr %l0, !tbaa !29
  %t2306 = load %"compiler/source:Span", ptr %l2
  %t2309 = getelementptr %"compiler/check:Checker", ptr %t2305, i32 0, i32 47
  store %"compiler/source:Span" %t2306, ptr %t2309
  %t2310 = load ptr, ptr %l0, !tbaa !29
  %t2311 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartHashes(ptr %v0, ptr %t2310, i32 %t2311, i64 0)
  br label %bb545
bb544:
  br label %bb551
bb545:
  %t2314 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2314, ptr %l1169, !tbaa !29
  %t2315 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s54, i32 -1, i32 -1)
  store %"compiler/source:Span" %t2315, ptr %l1170
  br label %bb546
bb546:
  %t2316 = load %"compiler/source:Span", ptr %l1170
  %t2317 = load ptr, ptr %l1169, !tbaa !29
  %t2318 = getelementptr %"compiler/check:Checker", ptr %t2317, i32 0, i32 47
  store %"compiler/source:Span" %t2316, ptr %t2318
  %t2319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2319, ptr %l1171, !tbaa !29
  %t2320 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t2320, ptr %l1172
  %t2321 = load ptr, ptr %l0, !tbaa !29
  %t2323 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t2321)
  store i32 %t2323, ptr %l1174
  br label %bb547
bb547:
  %t2324 = load i32, ptr %l7, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t2325
  %t2326 = getelementptr { i64, [3 x i64] }, ptr %t2325, i32 0, i32 0
  store i64 4, ptr %t2326
  %t2328 = insertvalue { i32, i32 } undef, i32 1, 0
  %t2330 = insertvalue { i32, i32 } %t2328, i32 %t2324, 1
  %t2331 = getelementptr { i64, [3 x i64] }, ptr %t2325, i32 0, i32 1
  store { i32, i32 } %t2330, ptr %t2331
  %t2332 = load { i64, [3 x i64] }, ptr %t2325
  %t2334 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store { i64, [3 x i64] } %t2332, ptr %t2334
  store ptr %t2334, ptr %l1178, !tbaa !29
  %t2335 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2335, ptr %l1179, !tbaa !29
  %t2336 = load ptr, ptr %l0, !tbaa !29
  %t2337 = load ptr, ptr %l4, !tbaa !29
  %t2338 = load %"compiler/source:Span", ptr %l1
  %t2342 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v2, ptr %v2, ptr %t2336, ptr %t2337, %"compiler/source:Span" %t2338)
  store ptr %t2342, ptr %l1183
  br label %bb548
bb548:
  %t2343 = load ptr, ptr %l1179, !tbaa !29
  %t2344 = load ptr, ptr %l1183, !tbaa !29
  %t2345 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v2, ptr %v0, ptr %t2343, ptr %t2344)
  store { i64, ptr } %t2345, ptr %l1184
  br label %bb549
bb549:
  %t2346 = load ptr, ptr %l1171, !tbaa !29
  %t2347 = load %"compiler/source:Span", ptr %l1172
  %t2348 = load i32, ptr %l1174, !tbaa !23
  %t2349 = load ptr, ptr %l1178, !tbaa !29
  %t2350 = load { i64, ptr }, ptr %l1184, !tbaa !27
  %t2351 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v5, ptr %v0, ptr %v5, ptr %t2346, %"compiler/source:Span" %t2347, i32 %t2348, ptr %t2349, { i64, ptr } %t2350)
  store ptr %t2351, ptr %l1185
  br label %bb550
bb550:
  %t2352 = load ptr, ptr %l1185, !tbaa !29
  call void @__olang_scope_close(ptr %s54)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t2352, ptr %rv
  br label %ret
bb551:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %rv = alloca { i32, %"compiler/source:Span" }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 114}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 114}
  %t24 = trunc i64 5 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load %"compiler/source:Span", ptr %l2
  %t29 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t27, 1
  store { i32, %"compiler/source:Span" } %t29, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb23
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l16, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 30}
  %t37 = icmp eq i64 %t35, 2
  store i1 %t37, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l17, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t49 = call { i32, %"compiler/source:Span" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %t46)
  %t50 = extractvalue { i32, %"compiler/source:Span" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/source:Span" } %t49, 0
  store i32 %t51, ptr %l26
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb16, label %ok.53, !prof !99
ok.53:
  store %"compiler/source:Span" %t50, ptr %l25
  br label %bb15
bb15:
  %t54 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t54, ptr %l22
  br label %bb17
bb16:
  %t55 = load i32, ptr %l26, !tbaa !23
  %t56 = lshr i32 %t55, 16
  %t57 = and i32 %t55, 65535
  %t58 = icmp eq i32 %t56, 1
  %t59 = select i1 %t58, i32 1, i32 0
  %t60 = icmp eq i32 %t55, 0
  %t61 = shl i32 %t59, 16
  %t62 = or i32 %t61, %t57
  %t63 = select i1 %t60, i32 0, i32 %t62
  %t65 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 %t63, 0
  store { i32, %"compiler/source:Span" } %t65, ptr %rv
  br label %ret
bb17:
  %t66 = load %"compiler/source:Span", ptr %l22
  %t67 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, %"compiler/source:Span" %t66, 1
  store { i32, %"compiler/source:Span" } %t67, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec59a5f60fda0dc9_336029f9ba6be385)
  unreachable
bb23:
  %t69 = insertvalue { i32, %"compiler/source:Span" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/source:Span" } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/source:Span" }, ptr %rv
  ret { i32, %"compiler/source:Span" } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryStore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l38 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"compiler/typed:Seq"
  %l67 = alloca i64
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l97 = alloca ptr
  %l104 = alloca i1
  %l112 = alloca i64
  %l113 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/source:Span"
  %l123 = alloca i32
  %l125 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l130 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t93 = alloca { i64, [5 x i64] }, align 8
  %t237 = alloca { i64, [5 x i64] }, align 8
  %t249 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 28
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i64, ptr %l23, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 37
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l26
  br label %bb3
bb3:
  %t16 = load i64, ptr %l26, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 16
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l7, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 130
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l31
  br label %bb4
bb4:
  %t27 = load i64, ptr %l31, !tbaa !24
  store i64 %t27, ptr %l8, !tbaa !24
  %t28 = load ptr, ptr %l4, !tbaa !29
  store ptr %t28, ptr %l32, !tbaa !29
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t29, i32 0, i32 15
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = add i64 %t31, 1
  %t35 = load ptr, ptr %l32, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 15
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t37, ptr %a2)
  br label %bb5
bb5:
  %t42 = load ptr, ptr %l4, !tbaa !29
  store ptr %t42, ptr %l38, !tbaa !29
  %t43 = load ptr, ptr %l38, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 15
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  %t49 = load ptr, ptr %l38, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 15
  store i64 %t47, ptr %t50, !tbaa !24
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 16
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp ne i64 %t54, %t55
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 16
  store i64 %t61, ptr %t64, !tbaa !24
  %t67 = xor i1 %t58, true
  br i1 %t67, label %bb6, label %bb7
bb6:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t69)
  store i1 %t71, ptr %l51
  br label %bb8
bb7:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb9
bb8:
  %t72 = load i1, ptr %l51, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l49, !tbaa !21
  br label %bb9
bb9:
  %t75 = load i1, ptr %l49, !tbaa !21
  br i1 %t75, label %bb10, label %bb11
bb10:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %t76, %"compiler/source:Span" %t77)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l55
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t81, ptr %l56, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 37
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t84, i64 %t85)
  store { i64, ptr } %t88, ptr %l60
  br label %bb14
bb14:
  %t89 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t90 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t89, ptr null, i1 false)
  store %"compiler/typed:Seq" %t90, ptr %l61
  br label %bb15
bb15:
  %t91 = load %"compiler/typed:Seq", ptr %l61
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Seq" %t91, ptr %t92
  store { i64, [5 x i64] } zeroinitializer, ptr %t93
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 0
  store i64 12, ptr %t94
  %t95 = load %"compiler/source:Span", ptr %l55
  %t96 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t95, 0
  %t97 = load i32, ptr %l56, !tbaa !23
  %t98 = insertvalue { %"compiler/source:Span", i32, ptr } %t96, i32 %t97, 1
  %t100 = insertvalue { %"compiler/source:Span", i32, ptr } %t98, ptr %t92, 2
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t100, ptr %t101
  %t102 = load { i64, [5 x i64] }, ptr %t93
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t102, ptr %t104
  store ptr %t104, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 28
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t108)
  store i64 %t110, ptr %l67
  br label %bb16
bb16:
  %t111 = load i64, ptr %l67, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t112, { i64, ptr } %t113, i64 %t114, i64 %t115)
  br label %bb17
bb17:
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l72
  br label %bb18
bb18:
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %t122
  store ptr %t122, ptr %l12, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s2
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i64, ptr %l5, !tbaa !24
  %t132 = load i64, ptr %l11, !tbaa !24
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %s2, ptr %t130, i64 %t131, i64 %t132)
  store { i64, ptr } %t136, ptr %l80
  br label %bb21
bb20:
  br label %bb30
bb21:
  %t137 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t137, ptr %l13, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t145 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t152 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t152, ptr %l88, !tbaa !27
  %t153 = load i64, ptr %l15, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  %t160 = load ptr, ptr %l12, !tbaa !29
  store ptr %t160, ptr %l91, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t164 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v2, ptr %s2, ptr %v0, ptr %v0, ptr %t161, ptr %t158, i32 %t163, i1 false, { i64, ptr } %t164, ptr %t165)
  store ptr %t171, ptr %l97
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v0, ptr %t172, ptr %t173)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t174 = load i64, ptr %l15, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l15, !tbaa !24
  br label %bb22
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t180 = load ptr, ptr %l12, !tbaa !29
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseRules(ptr %v0, ptr %v2, ptr %v0, ptr %t178, { i64, ptr } %t179, ptr %t180, i1 false, i32 %t181)
  store i1 %t186, ptr %l104
  br label %bb31
bb31:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l8, !tbaa !24
  %t189 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v0, ptr %t187, i64 %t188, ptr %t189)
  br label %bb32
bb32:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i64, ptr %l5, !tbaa !24
  %t195 = load i64, ptr %l11, !tbaa !24
  %t196 = load ptr, ptr %l12, !tbaa !29
  %t201 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t193, i64 %t194, i64 %t195, ptr %t196)
  store i64 %t201, ptr %l112
  br label %bb33
bb33:
  %t202 = load i64, ptr %l112, !tbaa !24
  store i64 %t202, ptr %l18, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l113, !tbaa !29
  %t204 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  %t206 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t207 = load i32, ptr %t206, !tbaa !23
  %t209 = add i32 %t207, 3
  %t212 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t205, i32 %t209)
  store %"compiler/source:Span" %t212, ptr %l117
  br label %bb34
bb34:
  %t213 = load i64, ptr %l5, !tbaa !24
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load ptr, ptr %l113, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l117
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i64 %t213, i64 %t214)
  br label %bb35
bb35:
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l120, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t220, ptr %l121
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l122
  %t222 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t222, ptr %l123, !tbaa !23
  %t223 = load ptr, ptr %l10, !tbaa !29
  store ptr %t223, ptr %l125, !tbaa !29
  %t225 = load ptr, ptr %l12, !tbaa !29
  %t227 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v0, ptr %t225)
  store { i64, ptr } %t227, ptr %l127
  br label %bb36
bb36:
  %t228 = load i64, ptr %l18, !tbaa !24
  %t230 = icmp sgt i64 %t228, 0
  %t231 = load ptr, ptr %l125, !tbaa !29
  %t232 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t234 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t231, { i64, ptr } %t232, i1 false, i1 false, i1 %t230)
  store %"compiler/typed:Try" %t234, ptr %l130
  br label %bb37
bb37:
  %t235 = load %"compiler/typed:Try", ptr %l130
  %t236 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t235, ptr %t236
  store { i64, [5 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 0
  store i64 14, ptr %t238
  %t239 = load %"compiler/source:Span", ptr %l122
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t239, 0
  %t241 = load i32, ptr %l123, !tbaa !23
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t241, 1
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t236, 2
  %t245 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [5 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t246, ptr %t248
  store { i64, [3 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [3 x i64] }, ptr %t249, i32 0, i32 0
  store i64 2, ptr %t250
  %t251 = load %"compiler/source:Span", ptr %l121
  %t252 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t251, 0
  %t254 = insertvalue { %"compiler/source:Span", ptr } %t252, ptr %t248, 1
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t254, ptr %t255
  %t256 = load { i64, [3 x i64] }, ptr %t249
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t256, ptr %t258
  %t259 = load ptr, ptr %l120, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t259, ptr %t258)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l24 = alloca i32
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l12, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 3}
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l18
  br label %bb11
bb11:
  %t36 = load i1, ptr %l18, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l24
  br label %bb14
bb13:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t47)
  store i32 %t49, ptr %l26
  br label %bb15
bb15:
  %t50 = load i32, ptr %l24, !tbaa !23
  %t51 = load i32, ptr %l26, !tbaa !23
  %t52 = icmp eq i32 %t50, %t51
  store i1 %t52, ptr %l19, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l19, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l29, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = mul i64 %t58, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l31, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l30, !tbaa !24
  %t68 = mul i64 %t67, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t64, ptr %t66, i64 %t68, i1 false)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t69, ptr %l29, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l32, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t75 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t72)
  store i32 %t75, ptr %l35
  br label %bb32
bb32:
  %t76 = load ptr, ptr %l32, !tbaa !29
  %t77 = load i32, ptr %l35, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t76, i32 %t77)
  store { i64, ptr } %t78, ptr %l36
  br label %bb33
bb33:
  %t79 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l24 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %t43, ptr %t44)
  store ptr %t48, ptr %l24
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l24, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1dea4fd8b0797e99_ba26b9776858744d)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l16 = alloca i1
  %l20 = alloca i1
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca i32
  %l33 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l34 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l43 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l65 = alloca i32
  %l68 = alloca i1
  %l70 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i32
  %l89 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l95 = alloca i1
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/diagmsg:Msg"
  %l115 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 102
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l20
  br label %bb3
bb3:
  %t14 = load i1, ptr %l20, !tbaa !21
  store i1 %t14, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l16, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l22
  br label %bb8
bb8:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %l3
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t27 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnended(ptr %v0, ptr %s0, ptr %t22, i32 %t23, ptr %l3)
  store i32 %t27, ptr %l27
  br label %bb9
bb9:
  %t28 = load i32, ptr %l27, !tbaa !23
  store i32 %t28, ptr %l4, !tbaa !23
  %t29 = load i32, ptr %l4, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H42e6f1efb33b8691983223fc2608e242(ptr %s0, ptr %s0, ptr %l3)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t37, ptr %l33
  br label %bb13
bb13:
  %t38 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l33
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t38, ptr %l5
  br label %bb14
bb14:
  %t40 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3ccompiler_2ftypes_3aTypeId_2c_20_Hfbcf1a40cd42d1431ad3e24c7e642711(ptr %s0, ptr %l5)
  %t41 = extractvalue { i32, i32 } %t40, 1
  %t42 = extractvalue { i32, i32 } %t40, 0
  store i32 %t42, ptr %l37
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb16, label %ok.44, !prof !99
ok.44:
  store i32 %t41, ptr %l36
  br label %bb15
bb15:
  %t45 = load i32, ptr %l36, !tbaa !23
  store i32 %t45, ptr %l34, !tbaa !23
  br label %bb18
bb16:
  %t46 = load i32, ptr %l37, !tbaa !23
  %t47 = ashr i32 %t46, 16
  %t49 = icmp eq i32 %t47, 1
  store i1 %t49, ptr %l39, !tbaa !21
  br label %bb17
bb17:
  br label %bb21
bb18:
  %t50 = load i32, ptr %l34, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 102
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %t53, i32 %t50, i1 true)
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb14
bb21:
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t57, ptr %l43, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 0
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l7, !tbaa !29
  %t63 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t63, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb23, label %bb24
bb23:
  br label %bb43
bb24:
  br label %bb25
bb25:
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %l52, !tbaa !27
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  store ptr %t83, ptr %l11, !tbaa !29
  %t85 = load ptr, ptr %l11, !tbaa !29
  %t87 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v1, ptr %t85)
  store i1 %t87, ptr %l56
  br label %bb26
bb26:
  %t88 = load i1, ptr %l56, !tbaa !21
  br i1 %t88, label %bb27, label %bb28
bb27:
  br label %bb42
bb28:
  br label %bb29
bb29:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t93)
  store ptr %t95, ptr %l60
  br label %bb30
bb30:
  %t96 = load ptr, ptr %l60, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t96, i32 0, i32 4
  %t99 = load ptr, ptr %l11, !tbaa !29
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t104 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t101, ptr %t98, ptr %t99)
  store i32 %t104, ptr %l65
  br label %bb31
bb31:
  %t105 = load i32, ptr %l65, !tbaa !23
  store i32 %t105, ptr %l12, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l12, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t106, i32 %t107)
  store i1 %t110, ptr %l68
  br label %bb32
bb32:
  %t111 = load i1, ptr %l68, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb33, label %bb34
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l72, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = getelementptr %"compiler/generic:Program", ptr %t121, i32 0, i32 2
  store ptr %t123, ptr %l75, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l12, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t129, i32 %t130, i32 0)
  store i32 %t133, ptr %l80
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb38
bb35:
  %t134 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t135 = load ptr, ptr %l75, !tbaa !29
  %t136 = load i32, ptr %l80, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t135, i32 %t136, i64 %t134)
  store i32 %t138, ptr %l82
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l72, !tbaa !29
  %t140 = load i32, ptr %l82, !tbaa !23
  %t141 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnendedDrop(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t141, ptr %l83
  br label %bb37
bb37:
  %t142 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t143 = load i32, ptr %l83, !tbaa !23
  %t145 = icmp ne i32 %t143, %t142
  store i1 %t145, ptr %l70, !tbaa !21
  br label %bb38
bb38:
  %t147 = load i1, ptr %l70, !tbaa !21
  br i1 %t147, label %bb39, label %bb40
bb39:
  %t148 = load ptr, ptr %l11, !tbaa !29
  store ptr %t148, ptr %l7, !tbaa !29
  br label %bb43
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l9, !tbaa !24
  br label %bb22
bb43:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l89, !tbaa !29
  %t155 = load ptr, ptr %l7, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l91
  br label %bb44
bb44:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i32, ptr %l4, !tbaa !23
  %t165 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t161, i32 %t162)
  store i1 %t165, ptr %l95
  br label %bb45
bb45:
  %t166 = load i1, ptr %l95, !tbaa !21
  br i1 %t166, label %bb46, label %bb47
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l4, !tbaa !23
  %t171 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t171, ptr %l99
  br label %bb48
bb47:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l4, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t176, ptr %l108
  br label %bb51
bb48:
  %t177 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l100, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l2, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l103
  br label %bb49
bb49:
  %t189 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t196 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t198 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructTypeByValue(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t196, { i64, ptr } %t195)
  store %"compiler/diagmsg:Msg" %t198, ptr %l105
  br label %bb50
bb50:
  %t199 = load %"compiler/diagmsg:Msg", ptr %l105
  store %"compiler/diagmsg:Msg" %t199, ptr %l96
  br label %bb54
bb51:
  %t200 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l109, !tbaa !27
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l2, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l112
  br label %bb52
bb52:
  %t212 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t219 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t221 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCopiedHeld(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t219, { i64, ptr } %t218)
  store %"compiler/diagmsg:Msg" %t221, ptr %l114
  br label %bb53
bb53:
  %t222 = load %"compiler/diagmsg:Msg", ptr %l114
  store %"compiler/diagmsg:Msg" %t222, ptr %l96
  br label %bb54
bb54:
  %t223 = load ptr, ptr %l89, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l91
  %t225 = load %"compiler/diagmsg:Msg", ptr %l96
  %t226 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/diagmsg:Msg" %t225)
  store i64 %t226, ptr %l115
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/ast:TypeDecl", ptr %a1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l10, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l8, !tbaa !27
  br label %bb28
bb6:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 5}
  %t24 = icmp eq i64 %t22, 4
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  br label %bb28
bb12:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 5}
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l22, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr, ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t43 = load ptr, ptr %l3, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t47 = load ptr, ptr %l27, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 1
  store i1 %t50, ptr %l28, !tbaa !21
  br label %bb19
bb19:
  %t51 = load i1, ptr %l28, !tbaa !21
  br i1 %t51, label %bb20, label %bb21
bb20:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 0
  %t56 = load %"compiler/source:Span", ptr %t55
  store %"compiler/source:Span" %t56, ptr %l4
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t64, ptr %l31, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t66, ptr %l31, !tbaa !27
  br label %bb22
bb22:
  %t68 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t69, ptr %l8, !tbaa !27
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_1ef5225cc090d9b9_51641959a5947e05)
  unreachable
bb28:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l42, !tbaa !24
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l43, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l42, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t84, ptr %l8, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i1
  %l13 = alloca i64
  %l21 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i1, ptr %l8, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t13, i32 %t14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) }, i64 1)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp slt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i32 %t33, ptr %l21
  br label %bb9
bb9:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load i32, ptr %l30, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l33
  br label %bb14
bb14:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t70, ptr %l40
  br label %bb18
bb18:
  %t71 = load i1, ptr %l40, !tbaa !21
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l49
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb24
bb22:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l50
  br label %bb23
bb23:
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb24
bb24:
  %t97 = load i1, ptr %l41, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l53, !tbaa !24
  br label %bb27
bb26:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %lp15 = alloca ptr
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/typed:Block"
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca %"compiler/typed:If"
  %l75 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l95 = alloca %"compiler/typed:Seq"
  %l101 = alloca i64
  %l107 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca i32
  %l123 = alloca i32
  %l127 = alloca ptr
  %l131 = alloca ptr
  %l133 = alloca ptr
  %l136 = alloca i64
  %l144 = alloca ptr
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"compiler/typed:Block"
  %l155 = alloca ptr
  %l156 = alloca %"compiler/source:Span"
  %l159 = alloca %"compiler/typed:If"
  %l163 = alloca ptr
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca %"compiler/source:Span"
  %l170 = alloca i32
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l182 = alloca i32
  %l186 = alloca { i64, ptr }
  %l189 = alloca %"compiler/typed:Seq"
  %rv = alloca ptr
  %t73 = alloca { i64, [3 x i64] }, align 8
  %t120 = alloca { i64, [3 x i64] }, align 8
  %t163 = alloca { i64, [5 x i64] }, align 8
  %t182 = alloca { i64, [5 x i64] }, align 8
  %t204 = alloca { i64, [1 x i64] }, align 8
  %t229 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t326 = alloca { i64, [3 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t397 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l19
  br label %bb1
bb1:
  %t5 = load i32, ptr %l19, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l20, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l21, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l4
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l5, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t29, i32 0, i32 3
  %t31 = load i32, ptr %t30
  store i32 %t31, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb25
bb6:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = call i1 @compiler_2fcheck_2epurePlace(ptr %v1, ptr %t33)
  store i1 %t35, ptr %l31
  br label %bb7
bb7:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 37
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l34
  br label %bb10
bb9:
  br label %bb24
bb10:
  %t42 = load i64, ptr %l34, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l35, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l36
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t45, ptr %l37, !tbaa !23
  store i32 19, ptr %l38
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l39, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr %l3, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i32 %t49)
  store ptr %t53, ptr %l43
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l43, !tbaa !29
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l36
  %t57 = load i32, ptr %l37, !tbaa !23
  %t58 = load i32, ptr %l38, !range !{i32 0, i32 52}
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t55, %"compiler/source:Span" %t56, i32 %t57, i32 %t58, ptr %t59, ptr %t54)
  store ptr %t61, ptr %l45
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l45, !tbaa !29
  store ptr %t62, ptr %l8, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 37
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t65)
  store i64 %t67, ptr %l48
  br label %bb13
bb13:
  %t68 = load i64, ptr %l48, !tbaa !24
  store i64 %t68, ptr %l9, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 37
  %t72 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 0
  store i64 9, ptr %t74
  %t76 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t72, 0
  %t78 = insertvalue { %"compiler/source:Span", i32, ptr } %t76, i32 1, 1
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t78, ptr null, 2
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t79, ptr %t80
  %t81 = load { i64, [3 x i64] }, ptr %t73
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t81, ptr %t83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t71, ptr %t83)
  br label %bb14
bb14:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t86)
  store ptr %t88, ptr %l56
  br label %bb15
bb15:
  %t89 = load ptr, ptr %l56, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 7
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = trunc i64 %t92 to i32
  store i32 %t94, ptr %l60, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 37
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l64
  br label %bb16
bb16:
  %t103 = load i32, ptr %l60, !tbaa !23
  %t104 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t105 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t103, { i64, ptr } %t104)
  store %"compiler/typed:Block" %t105, ptr %l65
  br label %bb17
bb17:
  %t106 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t106, ptr %lp10
  %t107 = load %"compiler/typed:Block", ptr %l65
  %t108 = load ptr, ptr %lp10
  store %"compiler/typed:Block" %t107, ptr %t108
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 37
  store ptr %t111, ptr %l67, !tbaa !29
  %t112 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t112, ptr %l68
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t114 = load ptr, ptr %lp10
  %t117 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v0, ptr %t113, ptr %t114, ptr null)
  store %"compiler/typed:If" %t117, ptr %l71
  br label %bb18
bb18:
  %t118 = load %"compiler/typed:If", ptr %l71
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t118, ptr %t119
  store { i64, [3 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 0
  store i64 3, ptr %t121
  %t122 = load %"compiler/source:Span", ptr %l68
  %t123 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t122, 0
  %t125 = insertvalue { %"compiler/source:Span", ptr } %t123, ptr %t119, 1
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t125, ptr %t126
  %t127 = load { i64, [3 x i64] }, ptr %t120
  %t129 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t127, ptr %t129
  %t130 = load ptr, ptr %l67, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t130, ptr %t129)
  br label %bb19
bb19:
  %t132 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t132, ptr %l75
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l3, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l80
  br label %bb20
bb20:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 37
  %t146 = load i64, ptr %l7, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l84
  br label %bb21
bb21:
  %t150 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l3, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l90
  br label %bb22
bb22:
  %t161 = load ptr, ptr %l5, !tbaa !29
  %t162 = load i32, ptr %l6, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 0
  store i64 2, ptr %t164
  %t165 = load %"compiler/source:Span", ptr %l85
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t165, 0
  %t167 = load i32, ptr %l90, !tbaa !23
  %t168 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t166, i32 %t167, 1
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t168, ptr %t161, 2
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t170, i32 %t162, 3
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t163, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t172, ptr %t173
  %t174 = load { i64, [5 x i64] }, ptr %t163
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t174, ptr %t176
  %t177 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t179 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t177, ptr %t176, i1 false)
  store %"compiler/typed:Seq" %t179, ptr %l95
  br label %bb23
bb23:
  %t180 = load %"compiler/typed:Seq", ptr %l95
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t180, ptr %t181
  store { i64, [5 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 0
  store i64 12, ptr %t183
  %t184 = load %"compiler/source:Span", ptr %l75
  %t185 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t184, 0
  %t186 = load i32, ptr %l80, !tbaa !23
  %t187 = insertvalue { %"compiler/source:Span", i32, ptr } %t185, i32 %t186, 1
  %t189 = insertvalue { %"compiler/source:Span", i32, ptr } %t187, ptr %t181, 2
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t189, ptr %t190
  %t191 = load { i64, [5 x i64] }, ptr %t182
  %t193 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t191, ptr %t193
  store ptr %t193, ptr %rv
  br label %ret
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_8302d182975d1c39_f0b10209f7a6052d)
  unreachable
bb30:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 37
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t197)
  store i64 %t199, ptr %l101
  br label %bb31
bb31:
  %t200 = load i64, ptr %l101, !tbaa !24
  store i64 %t200, ptr %l11, !tbaa !24
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t203 = load i32, ptr %l3, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [1 x i64] }, ptr %t204, i32 0, i32 0
  store i64 4, ptr %t205
  %t206 = load { i64, [1 x i64] }, ptr %t204
  %t212 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t201, i32 0, %"compiler/source:Span" %t202, i32 %t203, i32 1, { i64, [1 x i64] } %t206)
  store i64 %t212, ptr %l107
  br label %bb32
bb32:
  %t213 = load i64, ptr %l107, !tbaa !24
  store i64 %t213, ptr %l12, !tbaa !24
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load i64, ptr %l12, !tbaa !24
  %t216 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %t214, i64 %t215, ptr %t216)
  br label %bb33
bb33:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 37
  %t223 = load %"compiler/source:Span", ptr %l1
  %t224 = load i64, ptr %l12, !tbaa !24
  %t226 = trunc i64 %t224 to i32
  %t228 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t229
  %t230 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 0
  store i64 0, ptr %t230
  %t232 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t223, 0
  %t234 = insertvalue { %"compiler/source:Span", i32, ptr } %t232, i32 %t226, 1
  %t236 = insertvalue { %"compiler/source:Span", i32, ptr } %t234, ptr %t228, 2
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t229, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t236, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t229
  %t240 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t238, ptr %t240
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t222, ptr %t240)
  br label %bb34
bb34:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l120, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t244, ptr %l121
  %t245 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t245, ptr %l122, !tbaa !23
  store i32 19, ptr %l123
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l1
  %t248 = load i64, ptr %l12, !tbaa !24
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t246, %"compiler/source:Span" %t247, i64 %t248)
  store ptr %t252, ptr %l127
  br label %bb35
bb35:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  %t255 = load i32, ptr %l3, !tbaa !23
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v0, ptr %t253, %"compiler/source:Span" %t254, i32 %t255)
  store ptr %t259, ptr %l131
  br label %bb36
bb36:
  %t260 = load ptr, ptr %l131, !tbaa !29
  %t261 = load ptr, ptr %l120, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l121
  %t263 = load i32, ptr %l122, !tbaa !23
  %t264 = load i32, ptr %l123, !range !{i32 0, i32 52}
  %t265 = load ptr, ptr %l127, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t261, %"compiler/source:Span" %t262, i32 %t263, i32 %t264, ptr %t265, ptr %t260)
  store ptr %t267, ptr %l133
  br label %bb37
bb37:
  %t268 = load ptr, ptr %l133, !tbaa !29
  store ptr %t268, ptr %l13, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/check:Checker", ptr %t269, i32 0, i32 37
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l136
  br label %bb38
bb38:
  %t274 = load i64, ptr %l136, !tbaa !24
  store i64 %t274, ptr %l14, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 37
  %t278 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 9, ptr %t280
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t278, 0
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, i32 1, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t284, ptr null, 2
  %t286 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [3 x i64] }, ptr %t279
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t287, ptr %t289
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t277, ptr %t289)
  br label %bb39
bb39:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t292)
  store ptr %t294, ptr %l144
  br label %bb40
bb40:
  %t295 = load ptr, ptr %l144, !tbaa !29
  %t297 = getelementptr %"compiler/check:frame", ptr %t295, i32 0, i32 7
  %t298 = load i64, ptr %t297, !tbaa !24
  %t300 = trunc i64 %t298 to i32
  store i32 %t300, ptr %l148, !tbaa !23
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 37
  %t305 = load i64, ptr %l14, !tbaa !24
  %t308 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t304, i64 %t305)
  store { i64, ptr } %t308, ptr %l152
  br label %bb41
bb41:
  %t309 = load i32, ptr %l148, !tbaa !23
  %t310 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t311 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t309, { i64, ptr } %t310)
  store %"compiler/typed:Block" %t311, ptr %l153
  br label %bb42
bb42:
  %t312 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t312, ptr %lp15
  %t313 = load %"compiler/typed:Block", ptr %l153
  %t314 = load ptr, ptr %lp15
  store %"compiler/typed:Block" %t313, ptr %t314
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 37
  store ptr %t317, ptr %l155, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t318, ptr %l156
  %t319 = load ptr, ptr %l13, !tbaa !29
  %t320 = load ptr, ptr %lp15
  %t323 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v2, ptr %v2, ptr %v0, ptr %v0, ptr %t319, ptr %t320, ptr null)
  store %"compiler/typed:If" %t323, ptr %l159
  br label %bb43
bb43:
  %t324 = load %"compiler/typed:If", ptr %l159
  %t325 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t324, ptr %t325
  store { i64, [3 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 0
  store i64 3, ptr %t327
  %t328 = load %"compiler/source:Span", ptr %l156
  %t329 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t328, 0
  %t331 = insertvalue { %"compiler/source:Span", ptr } %t329, ptr %t325, 1
  %t332 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t331, ptr %t332
  %t333 = load { i64, [3 x i64] }, ptr %t326
  %t335 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t333, ptr %t335
  %t336 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t336, ptr %t335)
  br label %bb44
bb44:
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l163, !tbaa !29
  %t339 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t339, ptr %l164
  %t340 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t340, ptr %l165
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 2
  %t347 = load i32, ptr %l3, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t346, i32 %t347)
  store i32 %t350, ptr %l170
  br label %bb45
bb45:
  %t351 = load i64, ptr %l12, !tbaa !24
  %t353 = trunc i64 %t351 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 0, ptr %t356
  %t357 = load %"compiler/source:Span", ptr %l165
  %t358 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t357, 0
  %t359 = load i32, ptr %l170, !tbaa !23
  %t360 = insertvalue { %"compiler/source:Span", i32, i32 } %t358, i32 %t359, 1
  %t362 = insertvalue { %"compiler/source:Span", i32, i32 } %t360, i32 %t353, 2
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l163, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l164
  %t370 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t367, %"compiler/source:Span" %t368, ptr %t366)
  store ptr %t370, ptr %l176
  br label %bb46
bb46:
  %t371 = load ptr, ptr %l176, !tbaa !29
  store ptr %t371, ptr %l16, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t372, ptr %l177
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  %t379 = load i32, ptr %l3, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l182
  br label %bb47
bb47:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/check:Checker", ptr %t383, i32 0, i32 37
  %t386 = load i64, ptr %l11, !tbaa !24
  %t389 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t385, i64 %t386)
  store { i64, ptr } %t389, ptr %l186
  br label %bb48
bb48:
  %t390 = load ptr, ptr %l16, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t394 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t392, ptr %t390, i1 false)
  store %"compiler/typed:Seq" %t394, ptr %l189
  br label %bb49
bb49:
  %t395 = load %"compiler/typed:Seq", ptr %l189
  %t396 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t395, ptr %t396
  store { i64, [5 x i64] } zeroinitializer, ptr %t397
  %t398 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 0
  store i64 12, ptr %t398
  %t399 = load %"compiler/source:Span", ptr %l177
  %t400 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t399, 0
  %t401 = load i32, ptr %l182, !tbaa !23
  %t402 = insertvalue { %"compiler/source:Span", i32, ptr } %t400, i32 %t401, 1
  %t404 = insertvalue { %"compiler/source:Span", i32, ptr } %t402, ptr %t396, 2
  %t405 = getelementptr { i64, [5 x i64] }, ptr %t397, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t404, ptr %t405
  %t406 = load { i64, [5 x i64] }, ptr %t397
  %t408 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t406, ptr %t408
  store ptr %t408, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompoundOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t3 = trunc i64 81 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 68, ptr %l1
  br label %bb49
bb4:
  %t7 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t9 = trunc i64 82 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i32 69, ptr %l1
  br label %bb49
bb8:
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t15 = trunc i64 83 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i32 70, ptr %l1
  br label %bb49
bb12:
  %t19 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t21 = trunc i64 84 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i32 71, ptr %l1
  br label %bb49
bb16:
  %t25 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t27 = trunc i64 85 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 72, ptr %l1
  br label %bb49
bb20:
  %t31 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t33 = trunc i64 86 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i32 73, ptr %l1
  br label %bb49
bb24:
  %t37 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t39 = trunc i64 87 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i32 106, ptr %l1
  br label %bb49
bb28:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t45 = trunc i64 88 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i32 107, ptr %l1
  br label %bb49
bb32:
  %t49 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t51 = trunc i64 89 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i32 101, ptr %l1
  br label %bb49
bb36:
  %t55 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t57 = trunc i64 90 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i32 102, ptr %l1
  br label %bb49
bb40:
  %t61 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t63 = trunc i64 91 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i32 103, ptr %l1
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i32 0, ptr %l1
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5)
  unreachable
bb49:
  %t68 = load i32, ptr %l1, !range !{i32 0, i32 114}
  store i32 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2eeffectOp(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t3 = trunc i64 25 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb9
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t8 = trunc i64 26 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t11 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t13 = trunc i64 27 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  %t16 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t18 = trunc i64 28 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb10:
  %t21 = load i32, ptr %l0, !range !{i32 0, i32 52}
  %t23 = trunc i64 29 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d652d3791394a9d9_f08137453595c3ad)
  unreachable
bb19:
  %t26 = load i1, ptr %l1, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb12:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb13, label %bb14
bb13:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 30}
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb14
bb14:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb18:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb19, label %bb20
bb19:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 30}
  %t35 = icmp eq i64 %t33, 13
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb20
bb20:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb24:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb25, label %bb26
bb25:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 30}
  %t44 = icmp eq i64 %t42, 18
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb26
bb26:
  %t45 = load i1, ptr %l19, !tbaa !21
  br i1 %t45, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb30:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb31, label %bb32
bb31:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 30}
  %t53 = icmp eq i64 %t51, 19
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb32
bb32:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb36:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb37, label %bb38
bb37:
  %t59 = load ptr, ptr %l26, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 22
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb38
bb38:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb42:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb43, label %bb44
bb43:
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 30}
  %t71 = icmp eq i64 %t69, 23
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb44
bb44:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb48:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb49, label %bb50
bb49:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 30}
  %t80 = icmp eq i64 %t78, 24
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb50
bb50:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb54:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb55, label %bb56
bb55:
  %t86 = load ptr, ptr %l38, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 30}
  %t89 = icmp eq i64 %t87, 25
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb56
bb56:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb60:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb61, label %bb62
bb61:
  %t95 = load ptr, ptr %l42, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 30}
  %t98 = icmp eq i64 %t96, 15
  store i1 %t98, ptr %l43, !tbaa !21
  br label %bb62
bb62:
  %t99 = load i1, ptr %l43, !tbaa !21
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb66:
  br i1 true, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d149dd778abfbb99_ce32867ac8840ced)
  unreachable
bb71:
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l54 = alloca ptr
  %l60 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb47
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 14
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb19
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Try", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Try", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb14, label %bb15
bb13:
  store ptr null, ptr %l24, !tbaa !29
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e)
  unreachable
bb15:
  br label %bb16
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Try", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t53)
  store ptr %t55, ptr %l30
  br label %bb17
bb17:
  %t56 = load ptr, ptr %l30, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l24, !tbaa !29
  store ptr %t57, ptr %l5, !tbaa !29
  br label %bb47
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 18}
  %t65 = icmp eq i64 %t63, 17
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l3, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t73)
  store ptr %t75, ptr %l38
  br label %bb25
bb25:
  %t76 = load ptr, ptr %l38, !tbaa !29
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb47
bb26:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t78 = load ptr, ptr %l39, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 18}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l40, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l40, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l4, !tbaa !29
  br label %bb31
bb30:
  br label %bb42
bb31:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Seq", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Seq", ptr %t101, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp eq i64 %t106, 0
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l49, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Seq", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb37, label %bb38
bb36:
  store ptr null, ptr %l54, !tbaa !29
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e85625530f05a4e1_e8094ee11349b825)
  unreachable
bb38:
  br label %bb39
bb39:
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Seq", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ehandleCall(ptr %v0, ptr %v1, ptr %t121)
  store ptr %t123, ptr %l60
  br label %bb40
bb40:
  %t124 = load ptr, ptr %l60, !tbaa !29
  store ptr %t124, ptr %l54, !tbaa !29
  br label %bb41
bb41:
  %t125 = load ptr, ptr %l54, !tbaa !29
  store ptr %t125, ptr %l5, !tbaa !29
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17)
  unreachable
bb47:
  %t126 = load ptr, ptr %l5, !tbaa !29
  store ptr %t126, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eisEntry(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 114}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 114}
  %t18 = trunc i64 79 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_264a2a6908485689_7d6fe96b47d57f6d)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2elambdaOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 22
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_94831dcf6c50df99_e0fe015107062615)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2elaneTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t3 = trunc i64 68 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t8 = trunc i64 69 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t14 = trunc i64 70 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t20 = trunc i64 72 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t26 = trunc i64 73 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t32 = trunc i64 101 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t38 = trunc i64 102 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t44 = trunc i64 103 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t50 = trunc i64 106 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t54 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t56 = trunc i64 107 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb30
bb29:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t62 = trunc i64 47 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb30
bb30:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb33
bb32:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t68 = trunc i64 45 to i32
  %t69 = icmp eq i32 %t66, %t68
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb33
bb33:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb36
bb35:
  %t72 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t74 = trunc i64 46 to i32
  %t75 = icmp eq i32 %t72, %t74
  store i1 %t75, ptr %l36, !tbaa !21
  br label %bb36
bb36:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb39
bb38:
  %t78 = load i32, ptr %l0, !range !{i32 0, i32 114}
  %t80 = trunc i64 71 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l39, !tbaa !21
  br label %bb39
bb39:
  %t83 = load i1, ptr %l39, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enestedSets(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb24
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 7
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [8 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2echainSets(ptr %v0, ptr %t45, i32 %a1)
  store i1 %t49, ptr %l29
  br label %bb13
bb13:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f5486e4325103d79_668082c6ca0b25f5)
  unreachable
bb22:
  br label %bb23
bb23:
  %t52 = load i64, ptr %l3, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l3, !tbaa !24
  br label %bb4
bb24:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2epastAway(ptr %v0, ptr %v0, ptr %t16)
  store ptr %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_55e43ab8a3145b19_623cb1abd394c54d)
  unreachable
bb12:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2erebased(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l25 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca ptr
  %t42 = alloca { i64, [4 x i64] }, align 8
  %t81 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 3
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t34 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t34, ptr %l21
  %t35 = load i32, ptr %l3, !tbaa !23
  store i32 %t35, ptr %l22, !tbaa !23
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t40 = call ptr @compiler_2fcheck_2erebased(ptr %v0, ptr %v1, ptr %v0, ptr %t36, ptr %t37)
  store ptr %t40, ptr %l25
  br label %bb6
bb6:
  %t41 = load i64, ptr %l5, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 0
  store i64 3, ptr %t43
  %t44 = load %"compiler/source:Span", ptr %l21
  %t45 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t44, 0
  %t46 = load i32, ptr %l22, !tbaa !23
  %t47 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t45, i32 %t46, 1
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t47, ptr %t48, 2
  %t51 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t49, i64 %t41, 3
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t42, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t51, ptr %t52
  %t53 = load { i64, [4 x i64] }, ptr %t42
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t53, ptr %t55
  store ptr %t55, ptr %l8, !tbaa !29
  br label %bb18
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb8, label %bb9
bb8:
  %t61 = load ptr, ptr %l29, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 8}
  %t64 = icmp eq i64 %t62, 6
  store i1 %t64, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t68, i32 0, i32 0
  %t70 = load %"compiler/source:Span", ptr %t69
  store %"compiler/source:Span" %t70, ptr %l6
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l7, !tbaa !23
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t78 = load %"compiler/source:Span", ptr %l6
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load ptr, ptr %l1, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t81
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 0
  store i64 2, ptr %t82
  %t84 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t78, 0
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } %t84, i32 %t79, 1
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, ptr %t80, 2
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t88, ptr %t89
  %t90 = load { i64, [4 x i64] }, ptr %t81
  %t92 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t90, ptr %t92
  store ptr %t92, ptr %l8, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_241a90e95a4894c9_a3a560eaba438c2d)
  unreachable
bb18:
  %t96 = load ptr, ptr %l8, !tbaa !29
  store ptr %t96, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca i1
  %l97 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca i1
  %l107 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i1
  %l130 = alloca i1
  %l131 = alloca ptr
  %l132 = alloca i1
  %l139 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i1
  %l200 = alloca i1
  %l201 = alloca i1
  %l205 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i1
  %l221 = alloca i1
  %l222 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l235 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l244 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca i1
  %l254 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  %l263 = alloca i1
  %l264 = alloca ptr
  %l265 = alloca i1
  %l275 = alloca i1
  %l276 = alloca i1
  %l279 = alloca i1
  %l280 = alloca ptr
  %l281 = alloca i1
  %l285 = alloca ptr
  %l286 = alloca i1
  %l294 = alloca i1
  %l295 = alloca i1
  %l299 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l311 = alloca i1
  %l325 = alloca { i64, ptr }
  %l330 = alloca i1
  %l331 = alloca i1
  %l335 = alloca i1
  %l342 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t7 = load ptr, ptr %l36, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l36, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 22}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l37, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l37, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb12
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t22 = load ptr, ptr %l42, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l42, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 22}
  %t28 = icmp eq i64 %t26, 21
  store i1 %t28, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t29 = load i1, ptr %l43, !tbaa !21
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr { i64, [4 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", ptr }, ptr %t32, i32 0, i32 1
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t38)
  store i1 %t41, ptr %l51
  br label %bb13
bb13:
  %t42 = load i1, ptr %l51, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t44 = load ptr, ptr %l52, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l52, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 22}
  %t50 = icmp eq i64 %t48, 1
  store i1 %t50, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l53, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:VarDecl", ptr %t58, i32 0, i32 3
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t65, ptr %l61
  br label %bb20
bb20:
  %t66 = load i1, ptr %l61, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t68 = load ptr, ptr %l62, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l62, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 22}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l63, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l63, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l4, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t84, i32 0, i32 3
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb36
bb26:
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t92 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t88, { i64, ptr } %t89)
  store i1 %t92, ptr %l72
  br label %bb27
bb27:
  %t93 = load i1, ptr %l72, !tbaa !21
  br i1 %t93, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t94, { i64, ptr } %t96)
  store i1 %t99, ptr %l77
  br label %bb30
bb30:
  %t100 = load i1, ptr %l77, !tbaa !21
  store i1 %t100, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t101 = load i1, ptr %l73, !tbaa !21
  br i1 %t101, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb35
bb33:
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t102, { i64, ptr } %t104)
  store i1 %t107, ptr %l82
  br label %bb34
bb34:
  %t108 = load i1, ptr %l82, !tbaa !21
  store i1 %t108, ptr %l78, !tbaa !21
  br label %bb35
bb35:
  %t109 = load i1, ptr %l78, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t111 = load ptr, ptr %l83, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l83, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 22}
  %t117 = icmp eq i64 %t115, 2
  store i1 %t117, ptr %l84, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l84, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l6, !tbaa !29
  br label %bb41
bb40:
  br label %bb57
bb41:
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Multi", ptr %t125, i32 0, i32 0
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  store { i64, ptr } %t128, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb42
bb42:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = icmp slt i64 %t134, %t135
  %t140 = xor i1 %t138, true
  br i1 %t140, label %bb43, label %bb44
bb43:
  br label %bb55
bb44:
  br label %bb45
bb45:
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t142, ptr %l97, !tbaa !27
  %t143 = load i64, ptr %l8, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr ptr, ptr %t146, i64 %t143
  %t148 = load ptr, ptr %t147, !tbaa !39
  store ptr %t148, ptr %l10, !tbaa !29
  %t150 = load ptr, ptr %l10, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t154 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t150, { i64, ptr } %t151)
  store i1 %t154, ptr %l102
  br label %bb46
bb46:
  %t155 = load i1, ptr %l102, !tbaa !21
  br i1 %t155, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb50
bb48:
  %t156 = load ptr, ptr %l10, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t161 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t156, { i64, ptr } %t158)
  store i1 %t161, ptr %l107
  br label %bb49
bb49:
  %t162 = load i1, ptr %l107, !tbaa !21
  store i1 %t162, ptr %l103, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l103, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l8, !tbaa !24
  br label %bb42
bb55:
  %t169 = load ptr, ptr %l6, !tbaa !29
  %t171 = getelementptr %"compiler/ast:Multi", ptr %t169, i32 0, i32 2
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t176 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t172, { i64, ptr } %t173)
  store i1 %t176, ptr %l114
  br label %bb56
bb56:
  %t177 = load i1, ptr %l114, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb57:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t179 = load ptr, ptr %l115, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l115, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 22}
  %t185 = icmp eq i64 %t183, 4
  store i1 %t185, ptr %l116, !tbaa !21
  br label %bb59
bb59:
  %t186 = load i1, ptr %l116, !tbaa !21
  br i1 %t186, label %bb60, label %bb61
bb60:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr { i64, [4 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t189, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l11, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr { i64, [4 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t195, i32 0, i32 2
  %t197 = load { i64, ptr }, ptr %t196
  store { i64, ptr } %t197, ptr %l12, !tbaa !27
  br label %bb62
bb61:
  br label %bb68
bb62:
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t204 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t199, { i64, ptr } %t201)
  store i1 %t204, ptr %l126
  br label %bb63
bb63:
  %t205 = load i1, ptr %l126, !tbaa !21
  br i1 %t205, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb67
bb65:
  %t206 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t210 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t206, { i64, ptr } %t207)
  store i1 %t210, ptr %l130
  br label %bb66
bb66:
  %t211 = load i1, ptr %l130, !tbaa !21
  store i1 %t211, ptr %l127, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l127, !tbaa !21
  store i1 %t212, ptr %rv
  br label %ret
bb68:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t214 = load ptr, ptr %l131, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb69, label %bb70
bb69:
  %t217 = load ptr, ptr %l131, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 22}
  %t220 = icmp eq i64 %t218, 5
  store i1 %t220, ptr %l132, !tbaa !21
  br label %bb70
bb70:
  %t221 = load i1, ptr %l132, !tbaa !21
  br i1 %t221, label %bb71, label %bb72
bb71:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", ptr }, ptr %t224, i32 0, i32 1
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l13, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t228 = load ptr, ptr %l13, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t232 = call i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %t228, { i64, ptr } %t229)
  store i1 %t232, ptr %l139
  br label %bb74
bb74:
  %t233 = load i1, ptr %l139, !tbaa !21
  store i1 %t233, ptr %rv
  br label %ret
bb75:
  %t234 = load ptr, ptr %l0, !tbaa !29
  store ptr %t234, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t235 = load ptr, ptr %l140, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t238 = load ptr, ptr %l140, !tbaa !29
  %t239 = load i64, ptr %t238, !range !{i64 0, i64 22}
  %t241 = icmp eq i64 %t239, 6
  store i1 %t241, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t242 = load i1, ptr %l141, !tbaa !21
  br i1 %t242, label %bb78, label %bb79
bb78:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t245, i32 0, i32 1
  %t247 = load { i64, ptr }, ptr %t246
  store { i64, ptr } %t247, ptr %l14, !tbaa !27
  br label %bb84
bb79:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t250 = load ptr, ptr %l146, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb80, label %bb81
bb80:
  %t253 = load ptr, ptr %l146, !tbaa !29
  %t254 = load i64, ptr %t253, !range !{i64 0, i64 22}
  %t256 = icmp eq i64 %t254, 20
  store i1 %t256, ptr %l147, !tbaa !21
  br label %bb81
bb81:
  %t257 = load i1, ptr %l147, !tbaa !21
  br i1 %t257, label %bb82, label %bb83
bb82:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t260, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261
  store { i64, ptr } %t262, ptr %l14, !tbaa !27
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t264 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t268 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t264, { i64, ptr } %t265)
  store i1 %t268, ptr %l154
  br label %bb85
bb85:
  %t269 = load i1, ptr %l154, !tbaa !21
  store i1 %t269, ptr %rv
  br label %ret
bb86:
  %t270 = load ptr, ptr %l0, !tbaa !29
  store ptr %t270, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t271 = load ptr, ptr %l155, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb87, label %bb88
bb87:
  %t274 = load ptr, ptr %l155, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 22}
  %t277 = icmp eq i64 %t275, 7
  store i1 %t277, ptr %l156, !tbaa !21
  br label %bb88
bb88:
  %t278 = load i1, ptr %l156, !tbaa !21
  br i1 %t278, label %bb89, label %bb90
bb89:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l15, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 2
  %t289 = load { i64, ptr }, ptr %t288
  store { i64, ptr } %t289, ptr %l16, !tbaa !27
  br label %bb95
bb90:
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t292 = load ptr, ptr %l163, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb91, label %bb92
bb91:
  %t295 = load ptr, ptr %l163, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 22}
  %t298 = icmp eq i64 %t296, 10
  store i1 %t298, ptr %l164, !tbaa !21
  br label %bb92
bb92:
  %t299 = load i1, ptr %l164, !tbaa !21
  br i1 %t299, label %bb93, label %bb94
bb93:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr { i64, [4 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t302, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303
  store { i64, ptr } %t304, ptr %l16, !tbaa !27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr { i64, [4 x i64] }, ptr %t306, i32 0, i32 1
  %t309 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t308, i32 0, i32 2
  %t310 = load ptr, ptr %t309
  store ptr %t310, ptr %l15, !tbaa !29
  br label %bb95
bb94:
  br label %bb101
bb95:
  %t312 = load ptr, ptr %l15, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t317 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t312, { i64, ptr } %t314)
  store i1 %t317, ptr %l174
  br label %bb96
bb96:
  %t318 = load i1, ptr %l174, !tbaa !21
  br i1 %t318, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l175, !tbaa !21
  br label %bb100
bb98:
  %t319 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t323 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t319, { i64, ptr } %t320)
  store i1 %t323, ptr %l178
  br label %bb99
bb99:
  %t324 = load i1, ptr %l178, !tbaa !21
  store i1 %t324, ptr %l175, !tbaa !21
  br label %bb100
bb100:
  %t325 = load i1, ptr %l175, !tbaa !21
  store i1 %t325, ptr %rv
  br label %ret
bb101:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t327 = load ptr, ptr %l179, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb102, label %bb103
bb102:
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 22}
  %t333 = icmp eq i64 %t331, 8
  store i1 %t333, ptr %l180, !tbaa !21
  br label %bb103
bb103:
  %t334 = load i1, ptr %l180, !tbaa !21
  br i1 %t334, label %bb104, label %bb105
bb104:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l17, !tbaa !29
  br label %bb106
bb105:
  br label %bb120
bb106:
  %t341 = load ptr, ptr %l17, !tbaa !29
  %t343 = getelementptr %"compiler/ast:For3", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t349 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t344, { i64, ptr } %t346)
  store i1 %t349, ptr %l189
  br label %bb107
bb107:
  %t350 = load i1, ptr %l189, !tbaa !21
  br i1 %t350, label %bb108, label %bb109
bb108:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb111
bb109:
  %t351 = load ptr, ptr %l17, !tbaa !29
  %t353 = getelementptr %"compiler/ast:For3", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t358 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t354, { i64, ptr } %t355)
  store i1 %t358, ptr %l194
  br label %bb110
bb110:
  %t359 = load i1, ptr %l194, !tbaa !21
  store i1 %t359, ptr %l190, !tbaa !21
  br label %bb111
bb111:
  %t360 = load i1, ptr %l190, !tbaa !21
  br i1 %t360, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb115
bb113:
  %t361 = load ptr, ptr %l17, !tbaa !29
  %t363 = getelementptr %"compiler/ast:For3", ptr %t361, i32 0, i32 2
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t369 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t364, { i64, ptr } %t366)
  store i1 %t369, ptr %l200
  br label %bb114
bb114:
  %t370 = load i1, ptr %l200, !tbaa !21
  store i1 %t370, ptr %l195, !tbaa !21
  br label %bb115
bb115:
  %t371 = load i1, ptr %l195, !tbaa !21
  br i1 %t371, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb119
bb117:
  %t372 = load ptr, ptr %l17, !tbaa !29
  %t374 = getelementptr %"compiler/ast:For3", ptr %t372, i32 0, i32 3
  %t375 = load { i64, ptr }, ptr %t374, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t379 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t375, { i64, ptr } %t376)
  store i1 %t379, ptr %l205
  br label %bb118
bb118:
  %t380 = load i1, ptr %l205, !tbaa !21
  store i1 %t380, ptr %l201, !tbaa !21
  br label %bb119
bb119:
  %t381 = load i1, ptr %l201, !tbaa !21
  store i1 %t381, ptr %rv
  br label %ret
bb120:
  %t382 = load ptr, ptr %l0, !tbaa !29
  store ptr %t382, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t383 = load ptr, ptr %l206, !tbaa !29
  %t384 = icmp ne ptr %t383, null
  br i1 %t384, label %bb121, label %bb122
bb121:
  %t386 = load ptr, ptr %l206, !tbaa !29
  %t387 = load i64, ptr %t386, !range !{i64 0, i64 22}
  %t389 = icmp eq i64 %t387, 9
  store i1 %t389, ptr %l207, !tbaa !21
  br label %bb122
bb122:
  %t390 = load i1, ptr %l207, !tbaa !21
  br i1 %t390, label %bb123, label %bb124
bb123:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr { i64, [4 x i64] }, ptr %t391, i32 0, i32 1
  %t394 = getelementptr { %"compiler/source:Span", ptr }, ptr %t393, i32 0, i32 1
  %t395 = load ptr, ptr %t394
  store ptr %t395, ptr %l18, !tbaa !29
  br label %bb125
bb124:
  br label %bb135
bb125:
  %t397 = load ptr, ptr %l18, !tbaa !29
  %t399 = getelementptr %"compiler/ast:ForIn", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t405 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t400, { i64, ptr } %t402)
  store i1 %t405, ptr %l216
  br label %bb126
bb126:
  %t406 = load i1, ptr %l216, !tbaa !21
  br i1 %t406, label %bb127, label %bb128
bb127:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb130
bb128:
  %t407 = load ptr, ptr %l18, !tbaa !29
  %t409 = getelementptr %"compiler/ast:ForIn", ptr %t407, i32 0, i32 4
  %t410 = load { i64, ptr }, ptr %t409, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t414 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t410, { i64, ptr } %t411)
  store i1 %t414, ptr %l221
  br label %bb129
bb129:
  %t415 = load i1, ptr %l221, !tbaa !21
  store i1 %t415, ptr %l217, !tbaa !21
  br label %bb130
bb130:
  %t416 = load i1, ptr %l217, !tbaa !21
  br i1 %t416, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb134
bb132:
  %t417 = load ptr, ptr %l18, !tbaa !29
  %t419 = getelementptr %"compiler/ast:ForIn", ptr %t417, i32 0, i32 5
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t424 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t420, { i64, ptr } %t421)
  store i1 %t424, ptr %l226
  br label %bb133
bb133:
  %t425 = load i1, ptr %l226, !tbaa !21
  store i1 %t425, ptr %l222, !tbaa !21
  br label %bb134
bb134:
  %t426 = load i1, ptr %l222, !tbaa !21
  store i1 %t426, ptr %rv
  br label %ret
bb135:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t428 = load ptr, ptr %l227, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb136, label %bb137
bb136:
  %t431 = load ptr, ptr %l227, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 22}
  %t434 = icmp eq i64 %t432, 11
  store i1 %t434, ptr %l228, !tbaa !21
  br label %bb137
bb137:
  %t435 = load i1, ptr %l228, !tbaa !21
  br i1 %t435, label %bb138, label %bb139
bb138:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr }, ptr %t438, i32 0, i32 1
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l19, !tbaa !29
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t442 = load ptr, ptr %l19, !tbaa !29
  %t443 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t446 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t442, { i64, ptr } %t443)
  store i1 %t446, ptr %l235
  br label %bb141
bb141:
  %t447 = load i1, ptr %l235, !tbaa !21
  store i1 %t447, ptr %rv
  br label %ret
bb142:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t449 = load ptr, ptr %l236, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb143, label %bb144
bb143:
  %t452 = load ptr, ptr %l236, !tbaa !29
  %t453 = load i64, ptr %t452, !range !{i64 0, i64 22}
  %t455 = icmp eq i64 %t453, 12
  store i1 %t455, ptr %l237, !tbaa !21
  br label %bb144
bb144:
  %t456 = load i1, ptr %l237, !tbaa !21
  br i1 %t456, label %bb145, label %bb146
bb145:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t459, i32 0, i32 1
  %t461 = load { i64, ptr }, ptr %t460
  store { i64, ptr } %t461, ptr %l20, !tbaa !27
  br label %bb147
bb146:
  br label %bb149
bb147:
  %t463 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t467 = call i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %t463, { i64, ptr } %t464)
  store i1 %t467, ptr %l244
  br label %bb148
bb148:
  %t468 = load i1, ptr %l244, !tbaa !21
  store i1 %t468, ptr %rv
  br label %ret
bb149:
  %t469 = load ptr, ptr %l0, !tbaa !29
  store ptr %t469, ptr %l245, !tbaa !29
  store i1 false, ptr %l246, !tbaa !21
  %t470 = load ptr, ptr %l245, !tbaa !29
  %t471 = icmp ne ptr %t470, null
  br i1 %t471, label %bb150, label %bb151
bb150:
  %t473 = load ptr, ptr %l245, !tbaa !29
  %t474 = load i64, ptr %t473, !range !{i64 0, i64 22}
  %t476 = icmp eq i64 %t474, 15
  store i1 %t476, ptr %l246, !tbaa !21
  br label %bb151
bb151:
  %t477 = load i1, ptr %l246, !tbaa !21
  br i1 %t477, label %bb152, label %bb153
bb152:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr { i64, [4 x i64] }, ptr %t478, i32 0, i32 1
  %t481 = getelementptr { %"compiler/source:Span", ptr }, ptr %t480, i32 0, i32 1
  %t482 = load ptr, ptr %t481
  store ptr %t482, ptr %l21, !tbaa !29
  br label %bb154
bb153:
  br label %bb156
bb154:
  %t484 = load ptr, ptr %l21, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t489 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t484, { i64, ptr } %t486)
  store i1 %t489, ptr %l254
  br label %bb155
bb155:
  %t490 = load i1, ptr %l254, !tbaa !21
  store i1 %t490, ptr %rv
  br label %ret
bb156:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t492 = load ptr, ptr %l255, !tbaa !29
  %t493 = icmp ne ptr %t492, null
  br i1 %t493, label %bb157, label %bb158
bb157:
  %t495 = load ptr, ptr %l255, !tbaa !29
  %t496 = load i64, ptr %t495, !range !{i64 0, i64 22}
  %t498 = icmp eq i64 %t496, 13
  store i1 %t498, ptr %l256, !tbaa !21
  br label %bb158
bb158:
  %t499 = load i1, ptr %l256, !tbaa !21
  br i1 %t499, label %bb159, label %bb160
bb159:
  %t500 = load ptr, ptr %l0, !tbaa !29
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t500, i32 0, i32 1
  %t503 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t502, i32 0, i32 2
  %t504 = load ptr, ptr %t503
  store ptr %t504, ptr %l22, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t506 = load ptr, ptr %l22, !tbaa !29
  %t507 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t510 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t506, { i64, ptr } %t507)
  store i1 %t510, ptr %l263
  br label %bb162
bb162:
  %t511 = load i1, ptr %l263, !tbaa !21
  store i1 %t511, ptr %rv
  br label %ret
bb163:
  %t512 = load ptr, ptr %l0, !tbaa !29
  store ptr %t512, ptr %l264, !tbaa !29
  store i1 false, ptr %l265, !tbaa !21
  %t513 = load ptr, ptr %l264, !tbaa !29
  %t514 = icmp ne ptr %t513, null
  br i1 %t514, label %bb164, label %bb165
bb164:
  %t516 = load ptr, ptr %l264, !tbaa !29
  %t517 = load i64, ptr %t516, !range !{i64 0, i64 22}
  %t519 = icmp eq i64 %t517, 14
  store i1 %t519, ptr %l265, !tbaa !21
  br label %bb165
bb165:
  %t520 = load i1, ptr %l265, !tbaa !21
  br i1 %t520, label %bb166, label %bb167
bb166:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr { i64, [4 x i64] }, ptr %t521, i32 0, i32 1
  %t524 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t523, i32 0, i32 1
  %t525 = load ptr, ptr %t524
  store ptr %t525, ptr %l23, !tbaa !29
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t529 = getelementptr { i64, [4 x i64] }, ptr %t527, i32 0, i32 1
  %t530 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t529, i32 0, i32 2
  %t531 = load ptr, ptr %t530
  store ptr %t531, ptr %l24, !tbaa !29
  br label %bb168
bb167:
  br label %bb174
bb168:
  %t533 = load ptr, ptr %l23, !tbaa !29
  %t535 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t538 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t533, { i64, ptr } %t535)
  store i1 %t538, ptr %l275
  br label %bb169
bb169:
  %t539 = load i1, ptr %l275, !tbaa !21
  br i1 %t539, label %bb170, label %bb171
bb170:
  store i1 true, ptr %l276, !tbaa !21
  br label %bb173
bb171:
  %t540 = load ptr, ptr %l24, !tbaa !29
  %t541 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t544 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t540, { i64, ptr } %t541)
  store i1 %t544, ptr %l279
  br label %bb172
bb172:
  %t545 = load i1, ptr %l279, !tbaa !21
  store i1 %t545, ptr %l276, !tbaa !21
  br label %bb173
bb173:
  %t546 = load i1, ptr %l276, !tbaa !21
  store i1 %t546, ptr %rv
  br label %ret
bb174:
  %t547 = load ptr, ptr %l0, !tbaa !29
  store ptr %t547, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t548 = load ptr, ptr %l280, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb175, label %bb176
bb175:
  %t551 = load ptr, ptr %l280, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 22}
  %t554 = icmp eq i64 %t552, 16
  store i1 %t554, ptr %l281, !tbaa !21
  br label %bb176
bb176:
  %t555 = load i1, ptr %l281, !tbaa !21
  br i1 %t555, label %bb177, label %bb178
bb177:
  br label %bb179
bb178:
  br label %bb180
bb179:
  store i1 false, ptr %rv
  br label %ret
bb180:
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t558 = load ptr, ptr %l285, !tbaa !29
  %t559 = icmp ne ptr %t558, null
  br i1 %t559, label %bb181, label %bb182
bb181:
  %t561 = load ptr, ptr %l285, !tbaa !29
  %t562 = load i64, ptr %t561, !range !{i64 0, i64 22}
  %t564 = icmp eq i64 %t562, 18
  store i1 %t564, ptr %l286, !tbaa !21
  br label %bb182
bb182:
  %t565 = load i1, ptr %l286, !tbaa !21
  br i1 %t565, label %bb183, label %bb184
bb183:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr { i64, [4 x i64] }, ptr %t566, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", ptr }, ptr %t568, i32 0, i32 1
  %t570 = load ptr, ptr %t569
  store ptr %t570, ptr %l25, !tbaa !29
  br label %bb185
bb184:
  br label %bb191
bb185:
  %t572 = load ptr, ptr %l25, !tbaa !29
  %t574 = getelementptr %"compiler/ast:JoinS", ptr %t572, i32 0, i32 1
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t579 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t575, { i64, ptr } %t576)
  store i1 %t579, ptr %l294
  br label %bb186
bb186:
  %t580 = load i1, ptr %l294, !tbaa !21
  br i1 %t580, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb190
bb188:
  %t581 = load ptr, ptr %l25, !tbaa !29
  %t583 = getelementptr %"compiler/ast:JoinS", ptr %t581, i32 0, i32 2
  %t584 = load { i64, ptr }, ptr %t583, !tbaa !27
  %t585 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t588 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t584, { i64, ptr } %t585)
  store i1 %t588, ptr %l299
  br label %bb189
bb189:
  %t589 = load i1, ptr %l299, !tbaa !21
  store i1 %t589, ptr %l295, !tbaa !21
  br label %bb190
bb190:
  %t590 = load i1, ptr %l295, !tbaa !21
  store i1 %t590, ptr %rv
  br label %ret
bb191:
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l300, !tbaa !29
  store i1 false, ptr %l301, !tbaa !21
  %t592 = load ptr, ptr %l300, !tbaa !29
  %t593 = icmp ne ptr %t592, null
  br i1 %t593, label %bb192, label %bb193
bb192:
  %t595 = load ptr, ptr %l300, !tbaa !29
  %t596 = load i64, ptr %t595, !range !{i64 0, i64 22}
  %t598 = icmp eq i64 %t596, 19
  store i1 %t598, ptr %l301, !tbaa !21
  br label %bb193
bb193:
  %t599 = load i1, ptr %l301, !tbaa !21
  br i1 %t599, label %bb194, label %bb195
bb194:
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t602 = getelementptr { i64, [4 x i64] }, ptr %t600, i32 0, i32 1
  %t603 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t602, i32 0, i32 1
  %t604 = load ptr, ptr %t603
  store ptr %t604, ptr %l26, !tbaa !29
  br label %bb196
bb195:
  br label %bb198
bb196:
  %t606 = load ptr, ptr %l26, !tbaa !29
  %t608 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t611 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t606, { i64, ptr } %t608)
  store i1 %t611, ptr %l309
  br label %bb197
bb197:
  %t612 = load i1, ptr %l309, !tbaa !21
  store i1 %t612, ptr %rv
  br label %ret
bb198:
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t614 = load ptr, ptr %l310, !tbaa !29
  %t615 = icmp ne ptr %t614, null
  br i1 %t615, label %bb199, label %bb200
bb199:
  %t617 = load ptr, ptr %l310, !tbaa !29
  %t618 = load i64, ptr %t617, !range !{i64 0, i64 22}
  %t620 = icmp eq i64 %t618, 17
  store i1 %t620, ptr %l311, !tbaa !21
  br label %bb200
bb200:
  %t621 = load i1, ptr %l311, !tbaa !21
  br i1 %t621, label %bb201, label %bb202
bb201:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr { i64, [4 x i64] }, ptr %t622, i32 0, i32 1
  %t625 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t624, i32 0, i32 1
  %t626 = load { i64, ptr }, ptr %t625
  store { i64, ptr } %t626, ptr %l27, !tbaa !27
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr { i64, [4 x i64] }, ptr %t628, i32 0, i32 1
  %t631 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t630, i32 0, i32 2
  %t632 = load ptr, ptr %t631
  store ptr %t632, ptr %l28, !tbaa !29
  br label %bb203
bb202:
  br label %bb219
bb203:
  %t634 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t634, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t636 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t638 = extractvalue { i64, ptr } %t636, 0
  store i64 %t638, ptr %l31, !tbaa !24
  br label %bb204
bb204:
  %t640 = load i64, ptr %l30, !tbaa !24
  %t641 = load i64, ptr %l31, !tbaa !24
  %t644 = icmp slt i64 %t640, %t641
  %t646 = xor i1 %t644, true
  br i1 %t646, label %bb205, label %bb206
bb205:
  br label %bb217
bb206:
  br label %bb207
bb207:
  %t648 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t648, ptr %l325, !tbaa !27
  %t649 = load i64, ptr %l30, !tbaa !24
  %t651 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr ptr, ptr %t652, i64 %t649
  %t654 = load ptr, ptr %t653, !tbaa !39
  store ptr %t654, ptr %l32, !tbaa !29
  %t656 = load ptr, ptr %l32, !tbaa !29
  %t657 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t660 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t656, { i64, ptr } %t657)
  store i1 %t660, ptr %l330
  br label %bb208
bb208:
  %t661 = load i1, ptr %l330, !tbaa !21
  br i1 %t661, label %bb209, label %bb210
bb209:
  store i1 true, ptr %l331, !tbaa !21
  br label %bb212
bb210:
  %t662 = load ptr, ptr %l32, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t667 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t662, { i64, ptr } %t664)
  store i1 %t667, ptr %l335
  br label %bb211
bb211:
  %t668 = load i1, ptr %l335, !tbaa !21
  store i1 %t668, ptr %l331, !tbaa !21
  br label %bb212
bb212:
  %t669 = load i1, ptr %l331, !tbaa !21
  br i1 %t669, label %bb213, label %bb214
bb213:
  store i1 true, ptr %rv
  br label %ret
bb214:
  br label %bb215
bb215:
  br label %bb216
bb216:
  %t671 = load i64, ptr %l30, !tbaa !24
  %t673 = add i64 %t671, 1
  store i64 %t673, ptr %l30, !tbaa !24
  br label %bb204
bb217:
  %t675 = load ptr, ptr %l28, !tbaa !29
  %t677 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t680 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t675, { i64, ptr } %t677)
  store i1 %t680, ptr %l342
  br label %bb218
bb218:
  %t681 = load i1, ptr %l342, !tbaa !21
  store i1 %t681, ptr %rv
  br label %ret
bb219:
  call void @__olang_check_failed(ptr @olang_loc_3f7a94628940c729_cdb98f41ead125dd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2etempUnder(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  br label %bb18
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2etempUnder(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l19
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l19, !tbaa !29
  store ptr %t37, ptr %l3, !tbaa !29
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store ptr null, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_74af738f4d64f689_e986ed633af561bd)
  unreachable
bb18:
  %t38 = load ptr, ptr %l3, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d1 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"an export fn's call" }>, align 8
@.d2 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d3 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a constructor's call" }>, align 8
@.d4 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a lambda's call" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

@.d5 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"it reads a mutable global, whose value is the running program's" }>, align 8
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2fcheck_3afactRead_2e6 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d10 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d11 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"StringBuilder" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"std/set" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"std/deque" }>, align 8
@.d15 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Deque" }>, align 8
@.d16 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"std/heap" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Heap" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d20 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d21 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"has a destructor" }>, align 8
@.d22 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d23 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"is no struct" }>, align 8
@.d24 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/array" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ArrayError" }>, align 8
@.d26 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"OutOfRange" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"extern " }>, align 8
@.d29 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G42 " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.c32 = private unnamed_addr constant [5 x i8] c"true\00"
@.c33 = private unnamed_addr constant [6 x i8] c"false\00"
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", or write '" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d42 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'Bits'" }>, align 8
@.d43 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Value" }>, align 8
@.d48 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d56 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"retire" }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"grown" }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"vacate" }>, align 8
@.d63 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"occupy" }>, align 8
@.d64 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Atomic" }>, align 8
@.d65 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AtomicStore" }>, align 8
@.d66 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"AtomicAdd" }>, align 8
@.d67 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicSwap" }>, align 8
@.d68 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AtomicCompareSwap" }>, align 8
@.d69 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicLoad" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d74 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d75 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"a trait" }>, align 8
@.d76 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"an extern type" }>, align 8
@.d77 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a function type" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Ref" }>, align 8
@.d81 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"an increment as a value (S3a)" }>, align 8
@.d82 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'is' with a type (E32)" }>, align 8
@.d83 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'as' (E32)" }>, align 8
@.d84 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a generic name as a value" }>, align 8
@.d85 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"a nested row (E21)" }>, align 8
@.d86 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a comprehension (E27)" }>, align 8
@.d87 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"a lambda (D16)" }>, align 8
@.d88 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a match value (S12b)" }>, align 8
@.d89 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"a range outside a for (S9b)" }>, align 8
@.d90 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"'default' outside a call (E14a)" }>, align 8
@.d91 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"an index of this kind" }>, align 8
@.d92 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"an expression of this kind" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_Ha3611e7042201d9891a66cc0e2a71916(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_37018c2ebf0da22a_371c8892c4c63a5e = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_357157b7b16ebf19_d0077534c0a9b60d = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7a179da39a9781e9_720543b731edd2ed = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_ea1bc73a77e68519_ca6969815981751d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eAt_3ccompiler_2ftyped_3aClause_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchAfterCatchAll(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchUnreachable(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultInStatement(ptr %v0)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNoValue(ptr %v0)
@olang_loc_20fb2e81a5b7d68a_7759df49ce89a9e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultDead(ptr %v0)
declare i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchMustLeave(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultCount(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereSite(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_aa0d5e524103d919_41af477b1830b7e5 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1e68dbdbde35cba9_f30fa4c89b16ec2d = external constant [0 x i8]
@olang_loc_af264802bedcf8d8_5deeb41ed3d90c7c = external constant [0 x i8]
@olang_loc_8d3e5410ed2a27a9_4efdc57dac874585 = external constant [0 x i8]
@olang_loc_1dfbc037cdd154d8_cf42e6f659c8aed4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eHoldsVarByValue(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i64 %a4)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2eWrittenMut(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDefaultNotComputable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@olang_loc_5535019c26f71449_86439f2d3bbcfbb5 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapeRules(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dd139b797ad07c59_48ae02fb28d54045 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuilderNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fgeneric_2eDescFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3, i64 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factRead" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2eConservative(i32 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/check:reflList" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrolled(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, %"compiler/check:reflList" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInNeedsTry(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForInTryNothing(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaksBetween(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, i1 %a3, { i64, ptr } %a4, ptr %a5)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eToAr_H1af1cf80015c73411d038ac8256aec52(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2ePush_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Gap" %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_369dcc443ccea639_2a432d0faa4fb925 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ab1100555885b989_2cac6a0e3d43e9fd = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyHandle(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_968c62dd2cdb7cc9_e4aa23f03d53ae95 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9c0e2310e04cd1f8_9ba0cca7b5a93fa4 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ddeebe9155436d6a_19ee353760b572b6 = external constant [0 x i8]
@olang_loc_7406e676cee1d8f8_b07044052169e244 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, %"compiler/source:Span" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H7d5384a5030fc995e793b3fe1f57e776(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/diagmsg:Msg" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d8c36506bebb6839_82dbce7e68d1cca5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0)
@olang_loc_2a22705e3675cc6a_15625908cbc104fe = external constant [0 x i8]
@olang_loc_e03e15fa1ad8573f_767a3f28b3ff5a33 = external constant [0 x i8]
@olang_loc_f1d5d3b2155f2ddc_ad13ea37e14bc210 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedArgUnknown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgRequired(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNamedArgAlsoPositional(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePositionalAfterNamed(ptr %v0)
@olang_loc_6a354e0ae5aa0db2_42d5d79e5424950e = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2erecordBody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9d659989a3d8e899_e17dd41770304f7d = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimplSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorInstance(ptr %v0, ptr %a0)
declare %"compiler/generic:Origin" @compiler_2fgeneric_3aOrigin_2ector(ptr %v0, i64 %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eequality(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earraysEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumsEqual(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWordFields(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/check:payloadItem" @compiler_2fcheck_3apayloadItem_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3apayloadItem_3e_2ePu_H56e661e7866ebbaff102f6db3c63f52b(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:payloadItem" %a1)
@olang_loc_99a2219cf20f55d9_bdfeae2ff747ebc5 = external constant [0 x i8]
@olang_loc_aa9d1041871ddc08_900eaa132351bb14 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
@olang_loc_fb06dcd16342dc9_94e70e479081575d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efileIdentity(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eDecide(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare { i32, { i64, ptr } } @compiler_2ffacts_2ecompiler_2ffacts_3aTable_2eRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H9a57a0a969606bc6b56c6db08d26f577(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
@olang_loc_8771b1e868207559_9b4adf6aba3e467d = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTempBase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_62c5ac3e914a4019_8e197c98e172d865 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_57dc1f8c088d198a_6c44e525bc3c6ade = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFix(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyStored(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyDecl(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyReturned(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyGlobal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_658c1f9b991d3291_83ad80e13fec4285 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eLen__H7de3be79b8c6c838ec83b81887d1384a(ptr %v0, ptr %a0)
declare %"compiler/check:unsetCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aunsetCand_3e_2eAt_3ccompiler_2fcheck_3aunsetCand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/definit:Verdict" @compiler_2fdefinit_2eVerdict_2eJudge(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aValueAsk_3e_2eRefMu_H262fdcc49aab606e6e6c369788183545(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsetLowers(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eRefMut_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneverNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldUnassigned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadUnassigned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedDecl(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedNoElse(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedBranch(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedLoop(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedArm(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteUnassignedClause(ptr %v0)
@olang_loc_f865849e169fa2c9_a08c637f3ac5dd5 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritesImmut(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_238986d309dff67a_df3b69a02a086cde = external constant [0 x i8]
@olang_loc_f7f48d742623e788_feac04c086d410bc = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_61cd02582a530769_6431634bdc3c1a5d = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_ddf5999d75afc0ea_2c71428eb0b518ce = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteBack(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, i64 %a6, { i64, ptr } %a7)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estepMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i1 %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStepNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, { i64, ptr } %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
@olang_loc_abac8132a300fc4a_61eef78091b78ca6 = external constant [0 x i8]
@olang_loc_740060cd3c65d53f_5a6edac2e2ccbc3b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewriteAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estoreInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5, i1 %a6)
@olang_loc_2cb8a0e94f65b35c_b9489d26c7426678 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5)
@olang_loc_56b27b3a434e6e4b_829f47044d523297 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowNeedsType(ptr %v0)
declare i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpNotInteger(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eByteSwapWidth(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBitOpCount(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2esatOp(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLibrary(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, i64, i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopOpen(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLoopClose(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6)
declare %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVacateNotPlace(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotInteger(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicWidth(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotPlace(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elendsPacked(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAtomicNotWritable(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenerational(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenCopyDestruct(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewantCopy(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epartHashes(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4)
@olang_loc_ec59a5f60fda0dc9_336029f9ba6be385 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enothingFails(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
@olang_loc_1dea4fd8b0797e99_ba26b9776858744d = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_Hb3133f486435530b533aaf49461c92b5(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnended(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H42e6f1efb33b8691983223fc2608e242(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3ccompiler_2ftypes_3aTypeId_2c_20_Hfbcf1a40cd42d1431ad3e24c7e642711(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_H64d9be73b6c9bed004c541bdf7f0ca0a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnendedDrop(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructTypeByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCopiedHeld(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1ef5225cc090d9b9_51641959a5947e05 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2epurePlace(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8302d182975d1c39_f0b10209f7a6052d = external constant [0 x i8]
@olang_loc_20f9f67d26588f89_c77aed4cf9eaedd5 = external constant [0 x i8]
@olang_loc_d652d3791394a9d9_f08137453595c3ad = external constant [0 x i8]
@olang_loc_d149dd778abfbb99_ce32867ac8840ced = external constant [0 x i8]
@olang_loc_9272b3113db2835a_2a2a8b0a39f9db7e = external constant [0 x i8]
@olang_loc_e85625530f05a4e1_e8094ee11349b825 = external constant [0 x i8]
@olang_loc_fd7989cc94cf1ac3_95016419ffbfbd17 = external constant [0 x i8]
@olang_loc_264a2a6908485689_7d6fe96b47d57f6d = external constant [0 x i8]
@olang_loc_94831dcf6c50df99_e0fe015107062615 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2echainSets(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f5486e4325103d79_668082c6ca0b25f5 = external constant [0 x i8]
@olang_loc_55e43ab8a3145b19_623cb1abd394c54d = external constant [0 x i8]
@olang_loc_241a90e95a4894c9_a3a560eaba438c2d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3f7a94628940c729_cdb98f41ead125dd = external constant [0 x i8]
@olang_loc_74af738f4d64f689_e986ed633af561bd = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
