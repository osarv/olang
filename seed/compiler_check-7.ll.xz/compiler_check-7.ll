; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeParam" = type { %"compiler/source:Span", i32, ptr, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:roArg" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
define dso_local void @compiler_2fcheck_2eRoReturned_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i64 %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca %"compiler/check:litv"
  %l16 = alloca i1
  %l20 = alloca %"compiler/check:litv"
  %l25 = alloca i1
  %l32 = alloca %"compiler/check:litv"
  %l37 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i1 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l0, !tbaa !21
  %t2 = load i1, ptr %l2, !tbaa !21
  %t5 = icmp eq i1 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l3, !tbaa !65
  %t11 = add i64 %t7, %t8
  store i64 %t11, ptr %l4, !tbaa !65
  %t13 = load i64, ptr %l4, !tbaa !65
  %t14 = load i64, ptr %l1, !tbaa !65
  %t17 = icmp ult i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb11
bb3:
  %t19 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t19, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t20, ptr %rv
  br label %ret
bb6:
  %t21 = load i1, ptr %l0, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l4, !tbaa !65
  %t25 = icmp ne i64 %t23, 0
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i64, ptr %l4, !tbaa !65
  %t28 = load i1, ptr %l16, !tbaa !21
  %t30 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t28, i64 %t27)
  store %"compiler/check:litv" %t30, ptr %l20
  br label %bb10
bb10:
  %t31 = load %"compiler/check:litv", ptr %l20
  store %"compiler/check:litv" %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load i64, ptr %l1, !tbaa !65
  %t33 = load i64, ptr %l3, !tbaa !65
  %t36 = icmp uge i64 %t32, %t33
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i1, ptr %l0, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  %t40 = load i64, ptr %l1, !tbaa !65
  %t41 = load i64, ptr %l3, !tbaa !65
  %t44 = icmp ne i64 %t40, %t41
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i64, ptr %l1, !tbaa !65
  %t47 = load i64, ptr %l3, !tbaa !65
  %t50 = sub i64 %t46, %t47
  %t51 = load i1, ptr %l25, !tbaa !21
  %t53 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t51, i64 %t50)
  store %"compiler/check:litv" %t53, ptr %l32
  br label %bb17
bb17:
  %t54 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t54, ptr %rv
  br label %ret
bb18:
  %t55 = load i1, ptr %l2, !tbaa !21
  %t56 = load i64, ptr %l3, !tbaa !65
  %t57 = load i64, ptr %l1, !tbaa !65
  %t60 = sub i64 %t56, %t57
  %t63 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t55, i64 %t60)
  store %"compiler/check:litv" %t63, ptr %l37
  br label %bb19
bb19:
  %t64 = load %"compiler/check:litv", ptr %l37
  store %"compiler/check:litv" %t64, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i32 @compiler_2fcheck_2ebitOp(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 12, ptr @.d0 })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i32 30, ptr %l1
  br label %bb35
bb5:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 13, ptr @.d1 })
  store i1 %t8, ptr %l6
  br label %bb6
bb6:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i32 31, ptr %l1
  br label %bb35
bb10:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t11, { i64, ptr } { i64 8, ptr @.d2 })
  store i1 %t13, ptr %l9
  br label %bb11
bb11:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i32 32, ptr %l1
  br label %bb35
bb15:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t18 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 10, ptr @.d3 })
  store i1 %t18, ptr %l12
  br label %bb16
bb16:
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 33, ptr %l1
  br label %bb35
bb20:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 11, ptr @.d4 })
  store i1 %t23, ptr %l15
  br label %bb21
bb21:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i32 34, ptr %l1
  br label %bb35
bb25:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } { i64 8, ptr @.d5 })
  store i1 %t28, ptr %l18
  br label %bb26
bb26:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i32 35, ptr %l1
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i32 29, ptr %l1
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a3fc486149a2dc5d_17491af4361141b9)
  unreachable
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l1
  store i32 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TypeDecl", ptr %t14, i32 0, i32 3
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l2, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l14, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr { i64, [6 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { { i64, ptr }, ptr }, ptr %t30, i32 0, i32 0
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t40 = icmp slt i64 %t34, %t37
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  store ptr %t48, ptr %l23, !tbaa !29
  br label %bb14
bb13:
  store ptr null, ptr %l23, !tbaa !29
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l23, !tbaa !29
  store ptr %t51, ptr %rv
  br label %ret
bb15:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_980c9dc24d8ab357_bac7a576dce6b97b)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyAs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l17 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca i32
  %l39 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l9
  %t11 = load %"compiler/source:Span", ptr %l11
  %t12 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t9, %"compiler/source:Span" %t10, %"compiler/source:Span" %t11, i64 2)
  store %"compiler/source:Span" %t12, ptr %l12
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t16 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t13)
  store i32 %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l12
  %t20 = load i32, ptr %l15, !tbaa !23
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v2, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, ptr %t17)
  store i32 %t22, ptr %l17
  br label %bb5
bb5:
  %t23 = load i32, ptr %l17, !tbaa !23
  store i32 %t23, ptr %l5, !tbaa !23
  %t24 = load i32, ptr %l5, !tbaa !23
  %t25 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t28 = icmp eq i32 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l1
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t30, %"compiler/source:Span" %t31)
  store ptr %t34, ptr %l23
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load ptr, ptr %l23, !tbaa !29
  store ptr %t35, ptr %rv
  br label %ret
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t37, ptr %l25
  %t38 = load ptr, ptr %l2, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  store i32 %t39, ptr %l27, !tbaa !23
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l30
  br label %bb10
bb10:
  %t44 = mul i64 1, 4
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i32, ptr %l30, !tbaa !23
  %t49 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i32, ptr %t50, i64 0
  store i32 %t48, ptr %t51, !tbaa !33
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l34
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t56)
  store %"compiler/source:Span" %t58, ptr %l36
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l34
  %t61 = load %"compiler/source:Span", ptr %l36
  %t62 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i64 2)
  store %"compiler/source:Span" %t62, ptr %l37
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l28, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t65 = load %"compiler/source:Span", ptr %l37
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t63, { i64, ptr } %t64, %"compiler/source:Span" %t65, i1 true)
  store i32 %t66, ptr %l38
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l24, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l25
  %t69 = load ptr, ptr %l26, !tbaa !29
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = load i32, ptr %l38
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, ptr %t69, i32 %t70, i32 %t71)
  store ptr %t72, ptr %l39
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load ptr, ptr %l39, !tbaa !29
  store ptr %t73, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/generic:Unmet"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca %"compiler/generic:Unmet"
  %l23 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca %"compiler/msgs:Msg"
  %l66 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca i64
  %l85 = alloca i64
  %l88 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca %"compiler/msgs:Msg"
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l102 = alloca %"compiler/msgs:Msg"
  %l103 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr %l2, !tbaa !23
  %t10 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t4, i32 %t5, i32 %t6, i1 true, i64 0)
  store %"compiler/generic:Unmet" %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:Unmet", ptr %l17
  store %"compiler/generic:Unmet" %t11, ptr %l4
  %t12 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l23
  br label %bb5
bb5:
  %t23 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 5
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t29 = load i32, ptr %t28, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %t27, i32 %t29)
  store i1 %t32, ptr %l27
  br label %bb8
bb7:
  %t33 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 3
  %t34 = load i1, ptr %t33, !tbaa !21
  br i1 %t34, label %bb31, label %bb32
bb8:
  %t36 = load i1, ptr %l27, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t40 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t40, ptr %l30
  br label %bb12
bb12:
  %t41 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t41, ptr %l6
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %s4, ptr %t45, i32 %t47)
  store { i64, ptr } %t50, ptr %l34
  br label %bb13
bb13:
  %t51 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 4
  %t55 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  store i64 %t61, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb16:
  br label %bb17
bb17:
  %t71 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  store i32 %t77, ptr %l10, !tbaa !23
  %t80 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l6)
  store i64 %t80, ptr %l46
  br label %bb18
bb18:
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  br i1 %t82, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s6, ptr %l6, { i64, ptr } { i64 2, ptr @.d6 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  store ptr %l6, ptr %l49, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l10, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l52
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l49, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s5, ptr %t97, { i64, ptr } %t96)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb14
bb26:
  call void @__olang_scope_close(ptr %s4)
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l56, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t104, ptr %l57
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l1, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t105, i32 %t106)
  store { i64, ptr } %t109, ptr %l60
  br label %bb27
bb27:
  %t110 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l61, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l62, !tbaa !27
  %t119 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s2, ptr %l6)
  store { i64, ptr } %t119, ptr %l64
  br label %bb28
bb28:
  %t120 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t123 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %s2, ptr %s0, ptr %s2, ptr %s2, { i64, ptr } %t120, { i64, ptr } %t121, { i64, ptr } %t122)
  store %"compiler/msgs:Msg" %t123, ptr %l65
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l56, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l57
  %t126 = load %"compiler/msgs:Msg", ptr %l65
  %t127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t124, %"compiler/source:Span" %t125, %"compiler/msgs:Msg" %t126)
  store i64 %t127, ptr %l66
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l68, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t129, ptr %l69
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t130, i32 %t131)
  store { i64, ptr } %t134, ptr %l72
  br label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s11
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l95, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t136, ptr %l96
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l1, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t137, i32 %t138)
  store { i64, ptr } %t141, ptr %l99
  br label %bb44
bb33:
  %t142 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l73, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t149, ptr %l74, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t150, i32 %t152)
  store { i64, ptr } %t155, ptr %l77
  br label %bb34
bb34:
  %t156 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t166 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %s9, ptr %s0, ptr %s9, ptr %s9, { i64, ptr } %t163, { i64, ptr } %t164, { i64, ptr } %t162)
  store %"compiler/msgs:Msg" %t166, ptr %l79
  br label %bb35
bb35:
  %t167 = load ptr, ptr %l68, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l69
  %t169 = load %"compiler/msgs:Msg", ptr %l79
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t167, %"compiler/source:Span" %t168, %"compiler/msgs:Msg" %t169)
  store i64 %t170, ptr %l80
  br label %bb36
bb36:
  %t171 = load i64, ptr %l80, !tbaa !24
  store i64 %t171, ptr %l11, !tbaa !24
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/check:Checker", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t176 = load i32, ptr %l1, !tbaa !23
  %t177 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t178 = load i32, ptr %t177, !tbaa !23
  %t182 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t175, i32 %t176, i32 %t178)
  store i64 %t182, ptr %l85
  br label %bb37
bb37:
  %t183 = load i64, ptr %l85, !tbaa !24
  store i64 %t183, ptr %l12, !tbaa !24
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = icmp sge i64 %t184, 0
  br i1 %t186, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s10
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l88, !tbaa !29
  %t189 = load i64, ptr %l11, !tbaa !24
  store i64 %t189, ptr %l89, !tbaa !24
  %t190 = load i64, ptr %l12, !tbaa !24
  store i64 %t190, ptr %l90, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Unmet", ptr %l4, i32 0, i32 2
  %t193 = load i32, ptr %t192, !tbaa !23
  %t196 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t191, i32 %t193)
  store { i64, ptr } %t196, ptr %l93
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t197 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t198 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %s10, { i64, ptr } %t197)
  store %"compiler/msgs:Msg" %t198, ptr %l94
  br label %bb41
bb41:
  %t199 = load ptr, ptr %l88, !tbaa !29
  %t200 = load i64, ptr %l89, !tbaa !24
  %t201 = load i64, ptr %l90, !tbaa !24
  %t202 = load %"compiler/msgs:Msg", ptr %l94
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %s10, ptr %t199, i64 %t200, i64 %t201, %"compiler/msgs:Msg" %t202)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb44:
  %t203 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  %t205 = extractvalue { i64, ptr } %t203, 1
  %t206 = mul i64 %t204, 1
  %t207 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t206)
  call void @llvm.memcpy.p0.p0.i64(ptr %t207, ptr %t205, i64 %t206, i1 false)
  %t208 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t207, 1
  %t210 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t213 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %s11, ptr %s0, ptr %s11, { i64, ptr } %t209, { i64, ptr } %t210)
  store %"compiler/msgs:Msg" %t213, ptr %l102
  br label %bb45
bb45:
  %t214 = load ptr, ptr %l95, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l96
  %t216 = load %"compiler/msgs:Msg", ptr %l102
  %t217 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t214, %"compiler/source:Span" %t215, %"compiler/msgs:Msg" %t216)
  store i64 %t217, ptr %l103
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb47:
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l21 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Alt", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t35)
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Alt", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t63, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66, ptr %t70)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Arm", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t83, ptr %t84, ptr %t88)
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Arm", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t97)
  br label %bb19
bb19:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Arm", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i32, ptr %t19, i64 %t16
  %t21 = load i32, ptr %t20, !tbaa !33
  %t27 = add i64 %a2, 1
  %t31 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %t21, i64 %t27)
  store i1 %t31, ptr %l21
  br label %bb5
bb5:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l4, !tbaa !24
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l15 = alloca i32
  %l16 = alloca i1
  %l21 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i1
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sgt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i32, ptr %l15
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 21 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb48
bb11:
  %t29 = load i32, ptr %l3
  %t31 = trunc i64 19 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l21, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %l1, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb15
bb15:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = add i64 %t45, 1
  %t48 = load ptr, ptr %l21, !tbaa !29
  %t49 = load i32, ptr %l26, !tbaa !23
  %t51 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %t48, i32 %t49, i64 %t47)
  store i1 %t51, ptr %l29
  br label %bb16
bb16:
  %t52 = load i1, ptr %l29, !tbaa !21
  store i1 %t52, ptr %l16, !tbaa !21
  br label %bb48
bb17:
  %t53 = load i32, ptr %l3
  %t55 = trunc i64 22 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t58 = load i32, ptr %l3
  %t60 = trunc i64 23 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l34, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l42
  br label %bb23
bb23:
  %t80 = load ptr, ptr %l37, !tbaa !29
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l43
  br label %bb24
bb24:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l45
  br label %bb25
bb25:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l16, !tbaa !21
  br label %bb48
bb26:
  %t89 = load i32, ptr %l3
  %t91 = trunc i64 18 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb43
bb29:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i32, ptr %l1, !tbaa !23
  %t101 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l51
  br label %bb30
bb30:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l53, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l56, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  %t116 = load i32, ptr %l1, !tbaa !23
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t119, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb42
bb33:
  %t120 = load ptr, ptr %l56, !tbaa !29
  %t121 = load i32, ptr %l61, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l62
  br label %bb34
bb34:
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load ptr, ptr %l53, !tbaa !29
  %t125 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t127 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t124, { i64, ptr } %t125, i64 %t123)
  store i1 %t127, ptr %l64
  br label %bb35
bb35:
  %t128 = load i1, ptr %l64, !tbaa !21
  br i1 %t128, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb41
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l66, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/generic:Program", ptr %t133, i32 0, i32 2
  store ptr %t135, ptr %l69, !tbaa !29
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = load i32, ptr %l1, !tbaa !23
  %t145 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t141, i32 %t142)
  store i32 %t145, ptr %l74
  br label %bb38
bb38:
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = load i32, ptr %l74, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t146, i32 %t147)
  store { i64, ptr } %t148, ptr %l75
  br label %bb39
bb39:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l66, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsAny(ptr %v0, ptr %v0, ptr %t150, { i64, ptr } %t151, i64 %t149)
  store i1 %t153, ptr %l77
  br label %bb40
bb40:
  %t154 = load i1, ptr %l77, !tbaa !21
  store i1 %t154, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t155 = load i1, ptr %l65, !tbaa !21
  store i1 %t155, ptr %l52, !tbaa !21
  br label %bb42
bb42:
  %t156 = load i1, ptr %l52, !tbaa !21
  store i1 %t156, ptr %l16, !tbaa !21
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6d92d89bf6179935_a746df8e6ee4ce11)
  unreachable
bb48:
  %t157 = load i1, ptr %l16, !tbaa !21
  store i1 %t157, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l26 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t13 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 %a2, %"compiler/source:Span" %a3)
  store { i64, i64, i64 } %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t14, ptr %l5
  %t15 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 0
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, i64, i64 }, ptr %l5, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %a1)
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t28, i64 %t29, i64 %t30, i64 %t31, i64 %t32)
  store ptr %t38, ptr %l26
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l26, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, [3 x i64] }
  %l29 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, [3 x i64] }
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %lp47 = alloca ptr
  %l48 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca %"compiler/source:Span"
  %l81 = alloca i1
  %l85 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca { i64, ptr }
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca i64
  %l133 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l146 = alloca i64
  %l152 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca %"compiler/source:Span"
  %l174 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i64
  %l181 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca i64
  %l190 = alloca { i64, ptr }
  %l192 = alloca %"compiler/msgs:Msg"
  %l193 = alloca i64
  %l199 = alloca ptr
  %l204 = alloca i64
  %l207 = alloca i64
  %l229 = alloca i1
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"compiler/source:Span"
  %l244 = alloca i1
  %l249 = alloca i1
  %l250 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l264 = alloca { i64, [3 x i64] }
  %l266 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l280 = alloca i1
  %l285 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca i1
  %l301 = alloca { i64, ptr }
  %l304 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l311 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l329 = alloca ptr
  %l331 = alloca i32
  %l332 = alloca i32
  %l335 = alloca i1
  %l339 = alloca { i64, ptr }
  %l342 = alloca i32
  %l346 = alloca ptr
  %l348 = alloca { i64, ptr }
  %l351 = alloca %"compiler/source:Span"
  %l352 = alloca %"compiler/msgs:Msg"
  %l353 = alloca i64
  %l356 = alloca ptr
  %l359 = alloca { i64, ptr }
  %l362 = alloca i1
  %l363 = alloca i1
  %l364 = alloca ptr
  %l368 = alloca i1
  %l369 = alloca ptr
  %l370 = alloca ptr
  %l374 = alloca %"compiler/source:Span"
  %l375 = alloca %"compiler/msgs:Msg"
  %l376 = alloca i64
  %l377 = alloca ptr
  %l378 = alloca ptr
  %l381 = alloca ptr
  %l382 = alloca { i64, ptr }
  %l384 = alloca i32
  %l386 = alloca { i64, ptr }
  %l389 = alloca %"compiler/source:Span"
  %l390 = alloca ptr
  %l393 = alloca ptr
  %l398 = alloca { i64, [3 x i64] }
  %l402 = alloca ptr
  %l405 = alloca ptr
  %l408 = alloca ptr
  %l409 = alloca { i64, ptr }
  %l411 = alloca i32
  %l413 = alloca { i64, ptr }
  %l416 = alloca %"compiler/source:Span"
  %l417 = alloca ptr
  %l424 = alloca i1
  %l425 = alloca i1
  %l429 = alloca { i64, ptr }
  %l432 = alloca i32
  %l435 = alloca ptr
  %l438 = alloca ptr
  %l440 = alloca { i64, ptr }
  %l443 = alloca %"compiler/source:Span"
  %l446 = alloca ptr
  %l448 = alloca ptr
  %l451 = alloca i64
  %l452 = alloca i64
  %l453 = alloca ptr
  %l454 = alloca %"compiler/source:Span"
  %l457 = alloca { i64, ptr }
  %l460 = alloca ptr
  %l474 = alloca ptr
  %l483 = alloca { i64, ptr }
  %l486 = alloca ptr
  %l490 = alloca i32
  %l494 = alloca i32
  %l499 = alloca { i64, ptr }
  %l502 = alloca i1
  %l504 = alloca ptr
  %l510 = alloca ptr
  %l511 = alloca %"compiler/source:Span"
  %l513 = alloca %"compiler/msgs:Msg"
  %l514 = alloca i64
  %l518 = alloca ptr
  %l519 = alloca %"compiler/source:Span"
  %l521 = alloca %"compiler/msgs:Msg"
  %l522 = alloca i64
  %l523 = alloca ptr
  %l524 = alloca %"compiler/source:Span"
  %l525 = alloca %"compiler/msgs:Msg"
  %l526 = alloca i64
  %l531 = alloca { i64, ptr }
  %l535 = alloca ptr
  %l536 = alloca ptr
  %l547 = alloca i32
  %l550 = alloca i1
  %l551 = alloca i1
  %l556 = alloca i64
  %l561 = alloca ptr
  %l566 = alloca i32
  %l571 = alloca i64
  %l574 = alloca i32
  %l579 = alloca i32
  %l584 = alloca ptr
  %l589 = alloca i32
  %l590 = alloca { i64, ptr }
  %l591 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l597 = alloca i64
  %l600 = alloca i64
  %l618 = alloca { i64, ptr }
  %l623 = alloca i1
  %l624 = alloca i1
  %l630 = alloca i64
  %l633 = alloca i1
  %l638 = alloca i64
  %l644 = alloca ptr
  %l649 = alloca i32
  %l654 = alloca i64
  %l657 = alloca i32
  %l665 = alloca ptr
  %l668 = alloca ptr
  %l670 = alloca { i64, ptr }
  %l671 = alloca i32
  %l672 = alloca i32
  %l679 = alloca { i64, ptr }
  %l683 = alloca i32
  %l684 = alloca %"compiler/source:Span"
  %l685 = alloca i32
  %l690 = alloca %"compiler/typed:Call"
  %l695 = alloca i64
  %l700 = alloca i64
  %l703 = alloca i1
  %l705 = alloca ptr
  %l709 = alloca i1
  %l712 = alloca i1
  %l723 = alloca ptr
  %l727 = alloca i64
  %l730 = alloca %"compiler/source:Span"
  %l731 = alloca i32
  %l735 = alloca { i64, ptr }
  %l737 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca ptr
  %t1329 = alloca { i64, [2 x i64] }, align 8
  %t1340 = alloca { i64, [5 x i64] }, align 8
  %t1442 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 43
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 43
  store { i64, ptr } { i64 0, ptr @.d7 }, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 42
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l10
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l54, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t15, ptr %l55
  br label %bb1
bb1:
  %t16 = load %"compiler/source:Span", ptr %l55
  %t17 = load ptr, ptr %l54, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 42
  store %"compiler/source:Span" %t16, ptr %t18
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 37
  %t22 = load i1, ptr %t21, !tbaa !21
  store i1 %t22, ptr %l11, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 37
  store i1 false, ptr %t26, !tbaa !21
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t33, %"compiler/source:Span" %t34)
  store ptr %t37, ptr %l64
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l64, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l67, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l72
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l67, !tbaa !29
  %t56 = load i32, ptr %l72, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l73
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t58, ptr %l12, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 33
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l76
  br label %bb8
bb8:
  %t64 = load i64, ptr %l76, !tbaa !24
  store i64 %t64, ptr %l13, !tbaa !24
  %t65 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t65, ptr %l77
  br label %bb9
bb9:
  %t66 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t66, ptr %l14
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb10, label %bb11
bb10:
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = icmp sgt i64 %t75, 0
  store i1 %t77, ptr %l81, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb12
bb12:
  %t79 = load i1, ptr %l81, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t80 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp eq i64 %t82, 1
  store i1 %t84, ptr %l85, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb15
bb15:
  %t86 = load i1, ptr %l85, !tbaa !21
  br i1 %t86, label %bb16, label %bb17
bb16:
  %t87 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l91, !tbaa !24
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb21
bb18:
  store i64 1, ptr %l95, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l91, !tbaa !24
  %t97 = load i64, ptr %l95, !tbaa !24
  %t98 = sub i64 %t96, %t97
  %t100 = icmp sgt i64 %t98, 1
  store i1 %t100, ptr %l89, !tbaa !21
  br label %bb21
bb21:
  %t102 = load i1, ptr %l89, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t103, ptr %l99, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr ptr, ptr %t105, i64 0
  %t107 = load ptr, ptr %t106, !tbaa !39
  %t109 = call i1 @compiler_2fcheck_2ecallLike(ptr %v1, ptr %t107)
  store i1 %t109, ptr %l101
  br label %bb24
bb23:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb25
bb24:
  %t110 = load i1, ptr %l101, !tbaa !21
  store i1 %t110, ptr %l98, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l98, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t113, ptr %l103, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 0
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espread(ptr %v0, ptr %v1, ptr %t112, ptr %t117)
  store { i64, ptr } %t120, ptr %l105
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t121 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t121, ptr %l8, !tbaa !27
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t123, ptr %l107, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 0
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t130 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t122, ptr %t127)
  store %"compiler/source:Span" %t130, ptr %l109
  br label %bb29
bb29:
  %t131 = load %"compiler/source:Span", ptr %l109
  store %"compiler/source:Span" %t131, ptr %l14
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 32
  %t136 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t134)
  store i64 %t136, ptr %l112
  br label %bb31
bb31:
  %t137 = load i64, ptr %l112, !tbaa !24
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb32, label %bb33
bb32:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l116, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  store ptr %t145, ptr %l117, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb34, label %bb35
bb33:
  br label %bb44
bb34:
  %t152 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t152, ptr %l122, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 0
  %t156 = load i32, ptr %t155, !tbaa !33
  store i32 %t156, ptr %l121, !tbaa !23
  br label %bb36
bb35:
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t158, ptr %l121, !tbaa !23
  br label %bb36
bb36:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l126
  br label %bb37
bb37:
  %t163 = load ptr, ptr %l116, !tbaa !29
  %t164 = load ptr, ptr %l117, !tbaa !29
  %t165 = load i32, ptr %l121, !tbaa !23
  %t166 = load %"compiler/source:Span", ptr %l126
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t163, ptr %t164, i32 %t165, %"compiler/source:Span" %t166)
  store ptr %t167, ptr %l127
  br label %bb38
bb38:
  %t168 = load ptr, ptr %l127, !tbaa !29
  store ptr %t168, ptr %l17, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l128, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t170, ptr %t171)
  store i64 %t174, ptr %l131
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l17, !tbaa !29
  store ptr %t175, ptr %l133, !tbaa !29
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t179 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t177)
  store %"compiler/source:Span" %t179, ptr %l135
  br label %bb40
bb40:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l5, !tbaa !24
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  store { i64, ptr } %t184, ptr %l138
  br label %bb41
bb41:
  %t185 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t192 = load ptr, ptr %l128, !tbaa !29
  %t193 = load i64, ptr %l131, !tbaa !24
  %t194 = load ptr, ptr %l133, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v0, ptr %v0, ptr %t192, i64 %t193, i64 0, ptr %t194, %"compiler/source:Span" %t195, { i64, ptr } %t191)
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 32
  %t200 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t199, ptr %t200)
  br label %bb43
bb43:
  store i64 1, ptr %l16, !tbaa !24
  br label %bb44
bb44:
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb45, label %bb46
bb45:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l146, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb47
bb47:
  %t213 = load i64, ptr %l146, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb48, label %bb49
bb48:
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = load i64, ptr %l18, !tbaa !24
  %t226 = icmp sgt i64 %t222, %t223
  store i1 %t226, ptr %l152, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb50
bb50:
  %t228 = load i1, ptr %l152, !tbaa !21
  br i1 %t228, label %bb51, label %bb52
bb51:
  %t229 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l18, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t233 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = load i64, ptr %l16, !tbaa !24
  %t239 = sub i64 %t235, %t236
  store i64 %t239, ptr %l19, !tbaa !24
  %t241 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = icmp sge i32 %t242, 0
  br i1 %t244, label %bb54, label %bb55
bb54:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t248 = icmp sgt i64 %t246, 1
  store i1 %t248, ptr %l165, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb56
bb56:
  %t250 = load i1, ptr %l165, !tbaa !21
  br i1 %t250, label %bb57, label %bb58
bb57:
  %t251 = load i64, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = icmp ne i64 %t251, %t252
  store i1 %t255, ptr %l168, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb59
bb59:
  %t257 = load i1, ptr %l168, !tbaa !21
  br i1 %t257, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s5
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l172, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t259, ptr %l173
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %s5)
  store %"compiler/msgs:Msg" %t260, ptr %l174
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t261 = load ptr, ptr %l172, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l173
  %t263 = load %"compiler/msgs:Msg", ptr %l174
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l175
  br label %bb63
bb63:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 32
  %t268 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t267, i64 %t268)
  br label %bb64
bb64:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l1
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t271, %"compiler/source:Span" %t272)
  store ptr %t275, ptr %l181
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t276 = load ptr, ptr %l181, !tbaa !29
  store ptr %t276, ptr %rv
  br label %ret
bb66:
  %t277 = load i64, ptr %l18, !tbaa !24
  %t278 = load i64, ptr %l19, !tbaa !24
  %t281 = icmp sgt i64 %t277, %t278
  br i1 %t281, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s6
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l185, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t284, ptr %l186
  %t285 = load i64, ptr %l19, !tbaa !24
  store i64 %t285, ptr %l187, !tbaa !24
  %t286 = load i64, ptr %l19, !tbaa !24
  %t288 = icmp eq i64 %t286, 1
  br i1 %t288, label %bb69, label %bb70
bb68:
  br label %bb76
bb69:
  store { i64, ptr } { i64 0, ptr @.d8 }, ptr %l190, !tbaa !27
  br label %bb71
bb70:
  store { i64, ptr } { i64 1, ptr @.d9 }, ptr %l190, !tbaa !27
  br label %bb71
bb71:
  %t290 = load i64, ptr %l18, !tbaa !24
  %t291 = load i64, ptr %l187, !tbaa !24
  %t292 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s6, ptr %s6, i64 %t291, { i64, ptr } %t292, i64 %t290)
  store %"compiler/msgs:Msg" %t294, ptr %l192
  br label %bb72
bb72:
  %t295 = load ptr, ptr %l185, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l186
  %t297 = load %"compiler/msgs:Msg", ptr %l192
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t295, %"compiler/source:Span" %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l193
  br label %bb73
bb73:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 32
  %t302 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t301, i64 %t302)
  br label %bb74
bb74:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t305, %"compiler/source:Span" %t306)
  store ptr %t309, ptr %l199
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t310 = load ptr, ptr %l199, !tbaa !29
  store ptr %t310, ptr %rv
  br label %ret
bb76:
  store i64 0, ptr %l20, !tbaa !24
  %t311 = load i64, ptr %l18, !tbaa !24
  store i64 %t311, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t313 = load i64, ptr %l21, !tbaa !24
  %t314 = load i64, ptr %l20, !tbaa !24
  %t317 = icmp sgt i64 %t313, %t314
  br i1 %t317, label %bb77, label %bb78
bb77:
  %t319 = load i64, ptr %l22, !tbaa !24
  %t321 = icmp sgt i64 %t319, 0
  br i1 %t321, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb82
bb79:
  %t323 = load i64, ptr %l21, !tbaa !24
  %t324 = load i64, ptr %l20, !tbaa !24
  %t327 = sub i64 %t323, %t324
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t333 = sub i64 %t331, 1
  %t334 = load i64, ptr %l22, !tbaa !24
  %t337 = sdiv i64 %t333, %t334
  store i64 %t337, ptr %l207, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb81
bb81:
  %t339 = load i64, ptr %l207, !tbaa !24
  store i64 %t339, ptr %l204, !tbaa !24
  br label %bb82
bb82:
  %t340 = load i64, ptr %l204, !tbaa !24
  store i64 %t340, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s8
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l23, !tbaa !24
  %t345 = icmp slt i64 %t341, %t342
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s8)
  br label %bb196
bb85:
  br label %bb86
bb86:
  %t349 = load i64, ptr %l20, !tbaa !24
  %t350 = load i64, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l22, !tbaa !24
  %t354 = mul i64 %t350, %t351
  %t357 = add i64 %t349, %t354
  store i64 %t357, ptr %l25, !tbaa !24
  store ptr null, ptr %l26, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t359, ptr %l27
  %t361 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb87, label %bb88
bb87:
  %t367 = load i64, ptr %l25, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t373 = icmp slt i64 %t367, %t370
  store i1 %t373, ptr %l229, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb89
bb89:
  %t375 = load i1, ptr %l229, !tbaa !21
  br i1 %t375, label %bb90, label %bb91
bb90:
  %t376 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t376, ptr %l234, !tbaa !27
  %t377 = load i64, ptr %l25, !tbaa !24
  %t379 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr ptr, ptr %t380, i64 %t377
  %t382 = load ptr, ptr %t381, !tbaa !39
  %t384 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t382)
  store %"compiler/source:Span" %t384, ptr %l237
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t385 = load %"compiler/source:Span", ptr %l237
  store %"compiler/source:Span" %t385, ptr %l27
  br label %bb93
bb93:
  %t386 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t387 = load i32, ptr %t386, !tbaa !23
  %t389 = icmp sge i32 %t387, 0
  br i1 %t389, label %bb94, label %bb95
bb94:
  %t391 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t391, ptr %l27
  br label %bb96
bb95:
  br label %bb96
bb96:
  %t393 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t397 = icmp sgt i64 %t395, 0
  br i1 %t397, label %bb97, label %bb98
bb97:
  %t399 = load i64, ptr %l25, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t405 = icmp slt i64 %t399, %t402
  store i1 %t405, ptr %l244, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb99
bb99:
  %t407 = load i1, ptr %l244, !tbaa !21
  br i1 %t407, label %bb100, label %bb101
bb100:
  %t408 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t408, ptr %l250, !tbaa !27
  %t409 = load i64, ptr %l25, !tbaa !24
  %t411 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr ptr, ptr %t412, i64 %t409
  %t414 = load ptr, ptr %t413, !tbaa !39
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 0
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t421 = icmp eq ptr %t414, %t418
  %t423 = xor i1 %t421, true
  store i1 %t423, ptr %l249, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb102
bb102:
  %t425 = load i1, ptr %l249, !tbaa !21
  br i1 %t425, label %bb103, label %bb104
bb103:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 10
  %t429 = load { i64, [3 x i64] }, ptr %t428
  store { i64, [3 x i64] } %t429, ptr %l28
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l259, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l4, !tbaa !29
  %t434 = load i64, ptr %l5, !tbaa !24
  %t435 = load i64, ptr %l16, !tbaa !24
  %t440 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v0, ptr %t432, ptr %t433, i64 %t434, i64 %t435)
  store { i64, [3 x i64] } %t440, ptr %l264
  br label %bb105
bb104:
  %t441 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t445 = icmp sgt i64 %t443, 0
  br i1 %t445, label %bb107, label %bb108
bb105:
  %t447 = load { i64, [3 x i64] }, ptr %l264
  %t448 = load ptr, ptr %l259, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 10
  store { i64, [3 x i64] } %t447, ptr %t449
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t451, ptr %l266, !tbaa !27
  %t452 = load i64, ptr %l25, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr ptr, ptr %t455, i64 %t452
  %t457 = load ptr, ptr %t456, !tbaa !39
  %t458 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t458, ptr %l269, !tbaa !27
  %t459 = load i64, ptr %l16, !tbaa !24
  %t461 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = getelementptr i32, ptr %t462, i64 %t459
  %t464 = load i32, ptr %t463, !tbaa !33
  %t465 = load %"compiler/source:Span", ptr %l27
  %t470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t450, ptr %t457, i32 %t464, %"compiler/source:Span" %t465)
  store ptr %t470, ptr %l273
  br label %bb106
bb106:
  %t471 = load ptr, ptr %l273, !tbaa !29
  store ptr %t471, ptr %l26, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load { i64, [3 x i64] }, ptr %l28
  %t477 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 10
  store { i64, [3 x i64] } %t474, ptr %t477
  br label %bb187
bb107:
  %t478 = load i64, ptr %l25, !tbaa !24
  %t479 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t484 = icmp slt i64 %t478, %t481
  store i1 %t484, ptr %l280, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb109
bb109:
  %t486 = load i1, ptr %l280, !tbaa !21
  br i1 %t486, label %bb110, label %bb111
bb110:
  store i1 false, ptr %l29, !tbaa !21
  %t487 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t487, ptr %l285, !tbaa !27
  %t488 = load i64, ptr %l25, !tbaa !24
  %t490 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr ptr, ptr %t491, i64 %t488
  %t493 = load ptr, ptr %t492, !tbaa !39
  store ptr %t493, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t496 = load ptr, ptr %l288, !tbaa !29
  %t497 = icmp ne ptr %t496, null
  br i1 %t497, label %bb112, label %bb113
bb111:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l27
  %t503 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t499, %"compiler/source:Span" %t500)
  store ptr %t503, ptr %l446
  br label %bb185
bb112:
  %t504 = load ptr, ptr %l288, !tbaa !29
  %t505 = load i64, ptr %t504
  %t507 = icmp eq i64 %t505, 26
  store i1 %t507, ptr %l289, !tbaa !21
  br label %bb113
bb113:
  %t508 = load i1, ptr %l289, !tbaa !21
  br i1 %t508, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t509 = load i1, ptr %l29, !tbaa !21
  br i1 %t509, label %bb119, label %bb120
bb119:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l1
  %t513 = load ptr, ptr %l4, !tbaa !29
  %t514 = load i64, ptr %l5, !tbaa !24
  %t515 = load i64, ptr %l16, !tbaa !24
  %t516 = load ptr, ptr %l6, !tbaa !29
  %t518 = icmp eq ptr %t516, null
  %t520 = xor i1 %t518, true
  %t521 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t521, ptr %l301, !tbaa !27
  %t522 = load i64, ptr %l16, !tbaa !24
  %t524 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t525 = load ptr, ptr %t524, !tbaa !27
  %t526 = getelementptr i32, ptr %t525, i64 %t522
  %t527 = load i32, ptr %t526, !tbaa !33
  %t535 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %t511, %"compiler/source:Span" %t512, ptr %t513, i64 %t514, i64 %t515, i1 %t520, i32 %t527)
  store ptr %t535, ptr %l304
  br label %bb121
bb120:
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t537, ptr %l307, !tbaa !27
  %t538 = load i64, ptr %l25, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr ptr, ptr %t541, i64 %t538
  %t543 = load ptr, ptr %t542, !tbaa !39
  %t545 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t545, ptr %l311, !tbaa !27
  %t546 = load i64, ptr %l16, !tbaa !24
  %t548 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr i32, ptr %t549, i64 %t546
  %t551 = load i32, ptr %t550, !tbaa !33
  %t555 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t536, ptr %t543, i32 %t551)
  store ptr %t555, ptr %l314
  br label %bb122
bb121:
  %t556 = load ptr, ptr %l304, !tbaa !29
  store ptr %t556, ptr %l26, !tbaa !29
  br label %bb184
bb122:
  %t558 = load ptr, ptr %l314, !tbaa !29
  store ptr %t558, ptr %l26, !tbaa !29
  %t559 = load ptr, ptr %l26, !tbaa !29
  %t561 = icmp eq ptr %t559, null
  br i1 %t561, label %bb123, label %bb124
bb123:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t564, ptr %l318, !tbaa !27
  %t565 = load i64, ptr %l25, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr ptr, ptr %t568, i64 %t565
  %t570 = load ptr, ptr %t569, !tbaa !39
  %t572 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t572, ptr %l322, !tbaa !27
  %t573 = load i64, ptr %l16, !tbaa !24
  %t575 = getelementptr { i64, ptr }, ptr %l322, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr i32, ptr %t576, i64 %t573
  %t578 = load i32, ptr %t577, !tbaa !33
  %t582 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t563, ptr %t570, i32 %t578)
  store ptr %t582, ptr %l325
  br label %bb125
bb124:
  br label %bb126
bb125:
  %t583 = load ptr, ptr %l325, !tbaa !29
  store ptr %t583, ptr %l26, !tbaa !29
  br label %bb126
bb126:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/check:Checker", ptr %t585, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 2
  store ptr %t590, ptr %l329, !tbaa !29
  %t591 = load ptr, ptr %l26, !tbaa !29
  %t593 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t591)
  store i32 %t593, ptr %l331
  br label %bb127
bb127:
  %t594 = load ptr, ptr %l329, !tbaa !29
  %t595 = load i32, ptr %l331, !tbaa !23
  %t596 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t594, i32 %t595)
  store i32 %t596, ptr %l332
  br label %bb128
bb128:
  %t597 = load i32, ptr %l332
  %t599 = trunc i64 22 to i32
  %t600 = icmp eq i32 %t597, %t599
  br i1 %t600, label %bb129, label %bb130
bb129:
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/check:Checker", ptr %t602, i32 0, i32 1
  %t605 = load ptr, ptr %t604, !tbaa !29
  %t607 = getelementptr %"compiler/generic:Program", ptr %t605, i32 0, i32 2
  %t608 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t608, ptr %l339, !tbaa !27
  %t609 = load i64, ptr %l16, !tbaa !24
  %t611 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t612 = load ptr, ptr %t611, !tbaa !27
  %t613 = getelementptr i32, ptr %t612, i64 %t609
  %t614 = load i32, ptr %t613, !tbaa !33
  %t617 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t607, i32 %t614)
  store i32 %t617, ptr %l342
  br label %bb131
bb130:
  store i1 false, ptr %l335, !tbaa !21
  br label %bb132
bb131:
  %t618 = load i32, ptr %l342
  %t620 = trunc i64 22 to i32
  %t621 = icmp eq i32 %t618, %t620
  %t623 = xor i1 %t621, true
  store i1 %t623, ptr %l335, !tbaa !21
  br label %bb132
bb132:
  %t625 = load i1, ptr %l335, !tbaa !21
  br i1 %t625, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s19
  %t626 = load ptr, ptr %l0, !tbaa !29
  store ptr %t626, ptr %l346, !tbaa !29
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t628, ptr %l348, !tbaa !27
  %t629 = load i64, ptr %l25, !tbaa !24
  %t631 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t632 = load ptr, ptr %t631, !tbaa !27
  %t633 = getelementptr ptr, ptr %t632, i64 %t629
  %t634 = load ptr, ptr %t633, !tbaa !39
  %t637 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t627, ptr %t634)
  store %"compiler/source:Span" %t637, ptr %l351
  br label %bb135
bb134:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t639, ptr %l359, !tbaa !27
  %t640 = load i64, ptr %l16, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l359, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr i32, ptr %t643, i64 %t640
  %t645 = load i32, ptr %t644, !tbaa !33
  %t648 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t638, i32 %t645)
  store i1 %t648, ptr %l362
  br label %bb139
bb135:
  %t649 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %s19)
  store %"compiler/msgs:Msg" %t649, ptr %l352
  br label %bb136
bb136:
  %t650 = load ptr, ptr %l346, !tbaa !29
  %t651 = load %"compiler/source:Span", ptr %l351
  %t652 = load %"compiler/msgs:Msg", ptr %l352
  %t653 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t650, %"compiler/source:Span" %t651, %"compiler/msgs:Msg" %t652)
  store i64 %t653, ptr %l353
  br label %bb137
bb137:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load %"compiler/source:Span", ptr %l27
  %t658 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t654, %"compiler/source:Span" %t655)
  store ptr %t658, ptr %l356
  br label %bb138
bb138:
  %t659 = load ptr, ptr %l356, !tbaa !29
  store ptr %t659, ptr %l26, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  br label %bb183
bb139:
  %t661 = load i1, ptr %l362, !tbaa !21
  br i1 %t661, label %bb140, label %bb141
bb140:
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l364, !tbaa !29
  %t663 = load ptr, ptr %l26, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  br i1 %t665, label %bb142, label %bb143
bb141:
  store i1 false, ptr %l363, !tbaa !21
  br label %bb146
bb142:
  call void @__olang_check_failed(ptr @olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4)
  unreachable
bb143:
  br label %bb144
bb144:
  %t667 = load ptr, ptr %l26, !tbaa !29
  %t668 = load ptr, ptr %l364, !tbaa !29
  %t670 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v0, ptr %t668, ptr %t667)
  store i1 %t670, ptr %l368
  br label %bb145
bb145:
  %t671 = load i1, ptr %l368, !tbaa !21
  store i1 %t671, ptr %l363, !tbaa !21
  br label %bb146
bb146:
  %t672 = load i1, ptr %l363, !tbaa !21
  br i1 %t672, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s21
  %t673 = load ptr, ptr %l0, !tbaa !29
  store ptr %t673, ptr %l369, !tbaa !29
  %t674 = load ptr, ptr %l0, !tbaa !29
  store ptr %t674, ptr %l370, !tbaa !29
  %t675 = load ptr, ptr %l26, !tbaa !29
  %t677 = icmp eq ptr %t675, null
  br i1 %t677, label %bb149, label %bb150
bb148:
  br label %bb155
bb149:
  call void @__olang_check_failed(ptr @olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4)
  unreachable
bb150:
  br label %bb151
bb151:
  %t679 = load ptr, ptr %l26, !tbaa !29
  %t680 = load ptr, ptr %l370, !tbaa !29
  %t682 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v0, ptr %t680, ptr %t679)
  store %"compiler/source:Span" %t682, ptr %l374
  br label %bb152
bb152:
  %t683 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %s21)
  store %"compiler/msgs:Msg" %t683, ptr %l375
  br label %bb153
bb153:
  %t684 = load ptr, ptr %l369, !tbaa !29
  %t685 = load %"compiler/source:Span", ptr %l374
  %t686 = load %"compiler/msgs:Msg", ptr %l375
  %t687 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t684, %"compiler/source:Span" %t685, %"compiler/msgs:Msg" %t686)
  store i64 %t687, ptr %l376
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s21)
  br label %bb155
bb155:
  %t688 = load ptr, ptr %l0, !tbaa !29
  store ptr %t688, ptr %l377, !tbaa !29
  %t689 = load ptr, ptr %l4, !tbaa !29
  store ptr %t689, ptr %l378, !tbaa !29
  %t690 = load ptr, ptr %l26, !tbaa !29
  %t692 = icmp eq ptr %t690, null
  br i1 %t692, label %bb156, label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_460d09842f9fec87_8a34dc35fdcd1373)
  unreachable
bb157:
  br label %bb158
bb158:
  %t694 = load ptr, ptr %l26, !tbaa !29
  store ptr %t694, ptr %l381, !tbaa !29
  %t695 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t695, ptr %l382, !tbaa !27
  %t696 = load i64, ptr %l16, !tbaa !24
  %t698 = getelementptr { i64, ptr }, ptr %l382, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr i32, ptr %t699, i64 %t696
  %t701 = load i32, ptr %t700, !tbaa !33
  store i32 %t701, ptr %l384, !tbaa !23
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t703, ptr %l386, !tbaa !27
  %t704 = load i64, ptr %l25, !tbaa !24
  %t706 = getelementptr { i64, ptr }, ptr %l386, i32 0, i32 1
  %t707 = load ptr, ptr %t706, !tbaa !27
  %t708 = getelementptr ptr, ptr %t707, i64 %t704
  %t709 = load ptr, ptr %t708, !tbaa !39
  %t712 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t702, ptr %t709)
  store %"compiler/source:Span" %t712, ptr %l389
  br label %bb159
bb159:
  %t713 = load ptr, ptr %l377, !tbaa !29
  %t714 = load ptr, ptr %l378, !tbaa !29
  %t715 = load ptr, ptr %l381, !tbaa !29
  %t716 = load i32, ptr %l384, !tbaa !23
  %t717 = load %"compiler/source:Span", ptr %l389
  %t718 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v0, ptr %t713, ptr %t714, ptr %t715, i32 %t716, %"compiler/source:Span" %t717)
  store ptr %t718, ptr %l390
  br label %bb160
bb160:
  %t719 = load ptr, ptr %l390, !tbaa !29
  store ptr %t719, ptr %l31, !tbaa !29
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/check:Checker", ptr %t720, i32 0, i32 10
  %t723 = load { i64, [3 x i64] }, ptr %t722
  store { i64, [3 x i64] } %t723, ptr %l32
  %t725 = load ptr, ptr %l0, !tbaa !29
  store ptr %t725, ptr %l393, !tbaa !29
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t727 = load ptr, ptr %l4, !tbaa !29
  %t728 = load i64, ptr %l5, !tbaa !24
  %t729 = load i64, ptr %l16, !tbaa !24
  %t734 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v0, ptr %t726, ptr %t727, i64 %t728, i64 %t729)
  store { i64, [3 x i64] } %t734, ptr %l398
  br label %bb161
bb161:
  %t735 = load { i64, [3 x i64] }, ptr %l398
  %t736 = load ptr, ptr %l393, !tbaa !29
  %t737 = getelementptr %"compiler/check:Checker", ptr %t736, i32 0, i32 10
  store { i64, [3 x i64] } %t735, ptr %t737
  %t738 = load ptr, ptr %l31, !tbaa !29
  %t740 = icmp eq ptr %t738, null
  %t742 = xor i1 %t740, true
  br i1 %t742, label %bb162, label %bb163
bb162:
  %t744 = load ptr, ptr %l31, !tbaa !29
  store ptr %t744, ptr %l402, !tbaa !29
  br label %bb169
bb163:
  %t747 = load ptr, ptr %l0, !tbaa !29
  store ptr %t747, ptr %l405, !tbaa !29
  %t748 = load ptr, ptr %l26, !tbaa !29
  %t750 = icmp eq ptr %t748, null
  br i1 %t750, label %bb164, label %bb165
bb164:
  call void @__olang_check_failed(ptr @olang_loc_1a2fe83b02404856_98942d3dbe0d9432)
  unreachable
bb165:
  br label %bb166
bb166:
  %t752 = load ptr, ptr %l26, !tbaa !29
  store ptr %t752, ptr %l408, !tbaa !29
  %t753 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t753, ptr %l409, !tbaa !27
  %t754 = load i64, ptr %l16, !tbaa !24
  %t756 = getelementptr { i64, ptr }, ptr %l409, i32 0, i32 1
  %t757 = load ptr, ptr %t756, !tbaa !27
  %t758 = getelementptr i32, ptr %t757, i64 %t754
  %t759 = load i32, ptr %t758, !tbaa !33
  store i32 %t759, ptr %l411, !tbaa !23
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t761 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t761, ptr %l413, !tbaa !27
  %t762 = load i64, ptr %l25, !tbaa !24
  %t764 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !27
  %t766 = getelementptr ptr, ptr %t765, i64 %t762
  %t767 = load ptr, ptr %t766, !tbaa !39
  %t770 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t760, ptr %t767)
  store %"compiler/source:Span" %t770, ptr %l416
  br label %bb167
bb167:
  %t771 = load ptr, ptr %l405, !tbaa !29
  %t772 = load ptr, ptr %l408, !tbaa !29
  %t773 = load i32, ptr %l411, !tbaa !23
  %t774 = load %"compiler/source:Span", ptr %l416
  %t775 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t771, ptr %t772, i32 %t773, %"compiler/source:Span" %t774)
  store ptr %t775, ptr %l417
  br label %bb168
bb168:
  %t776 = load ptr, ptr %l417, !tbaa !29
  store ptr %t776, ptr %l402, !tbaa !29
  br label %bb169
bb169:
  %t778 = load ptr, ptr %l402, !tbaa !29
  store ptr %t778, ptr %l26, !tbaa !29
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load { i64, [3 x i64] }, ptr %l32
  %t783 = getelementptr %"compiler/check:Checker", ptr %t779, i32 0, i32 10
  store { i64, [3 x i64] } %t780, ptr %t783
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t785 = load ptr, ptr %l4, !tbaa !29
  %t786 = load i64, ptr %l5, !tbaa !24
  %t790 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecCallback(ptr %v0, ptr %v0, ptr %t784, ptr %t785, i64 %t786)
  store i1 %t790, ptr %l424
  br label %bb170
bb170:
  %t791 = load i1, ptr %l424, !tbaa !21
  br i1 %t791, label %bb171, label %bb172
bb171:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/check:Checker", ptr %t792, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = getelementptr %"compiler/generic:Program", ptr %t795, i32 0, i32 2
  %t798 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t798, ptr %l429, !tbaa !27
  %t799 = load i64, ptr %l16, !tbaa !24
  %t801 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t802 = load ptr, ptr %t801, !tbaa !27
  %t803 = getelementptr i32, ptr %t802, i64 %t799
  %t804 = load i32, ptr %t803, !tbaa !33
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t797, i32 %t804)
  store i32 %t807, ptr %l432
  br label %bb173
bb172:
  store i1 false, ptr %l425, !tbaa !21
  br label %bb174
bb173:
  %t808 = load i32, ptr %l432
  %t810 = trunc i64 21 to i32
  %t811 = icmp eq i32 %t808, %t810
  store i1 %t811, ptr %l425, !tbaa !21
  br label %bb174
bb174:
  %t813 = load i1, ptr %l425, !tbaa !21
  br i1 %t813, label %bb175, label %bb176
bb175:
  %t814 = load ptr, ptr %l0, !tbaa !29
  store ptr %t814, ptr %l435, !tbaa !29
  %t815 = load ptr, ptr %l26, !tbaa !29
  %t817 = icmp eq ptr %t815, null
  br i1 %t817, label %bb177, label %bb178
bb176:
  br label %bb182
bb177:
  call void @__olang_check_failed(ptr @olang_loc_5243f41784a5b43d_9dc8734848aaa559)
  unreachable
bb178:
  br label %bb179
bb179:
  %t819 = load ptr, ptr %l26, !tbaa !29
  store ptr %t819, ptr %l438, !tbaa !29
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t821 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t821, ptr %l440, !tbaa !27
  %t822 = load i64, ptr %l25, !tbaa !24
  %t824 = getelementptr { i64, ptr }, ptr %l440, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = getelementptr ptr, ptr %t825, i64 %t822
  %t827 = load ptr, ptr %t826, !tbaa !39
  %t830 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t820, ptr %t827)
  store %"compiler/source:Span" %t830, ptr %l443
  br label %bb180
bb180:
  %t831 = load ptr, ptr %l435, !tbaa !29
  %t832 = load ptr, ptr %l438, !tbaa !29
  %t833 = load %"compiler/source:Span", ptr %l443
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackArg(ptr %v0, ptr %v0, ptr %t831, ptr %t832, %"compiler/source:Span" %t833)
  br label %bb181
bb181:
  br label %bb182
bb182:
  br label %bb183
bb183:
  br label %bb184
bb184:
  br label %bb186
bb185:
  %t834 = load ptr, ptr %l446, !tbaa !29
  store ptr %t834, ptr %l26, !tbaa !29
  br label %bb186
bb186:
  br label %bb187
bb187:
  %t836 = load ptr, ptr %l0, !tbaa !29
  store ptr %t836, ptr %l448, !tbaa !29
  %t837 = load ptr, ptr %l0, !tbaa !29
  %t838 = load ptr, ptr %l4, !tbaa !29
  %t841 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t837, ptr %t838)
  store i64 %t841, ptr %l451
  br label %bb188
bb188:
  %t842 = load i64, ptr %l16, !tbaa !24
  store i64 %t842, ptr %l452, !tbaa !24
  %t843 = load ptr, ptr %l26, !tbaa !29
  store ptr %t843, ptr %l453, !tbaa !29
  %t844 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t844, ptr %l454
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t846 = load i64, ptr %l5, !tbaa !24
  %t849 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v0, ptr %t845, i64 %t846)
  store { i64, ptr } %t849, ptr %l457
  br label %bb189
bb189:
  %t850 = load { i64, ptr }, ptr %l457, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t850, 0
  %t852 = extractvalue { i64, ptr } %t850, 1
  %t853 = mul i64 %t851, 1
  %t854 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t853)
  call void @llvm.memcpy.p0.p0.i64(ptr %t854, ptr %t852, i64 %t853, i1 false)
  %t855 = insertvalue { i64, ptr } undef, i64 %t851, 0
  %t856 = insertvalue { i64, ptr } %t855, ptr %t854, 1
  %t857 = load ptr, ptr %l448, !tbaa !29
  %t858 = load i64, ptr %l451, !tbaa !24
  %t859 = load i64, ptr %l452, !tbaa !24
  %t860 = load ptr, ptr %l453, !tbaa !29
  %t861 = load %"compiler/source:Span", ptr %l454
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v0, ptr %v0, ptr %t857, i64 %t858, i64 %t859, ptr %t860, %"compiler/source:Span" %t861, { i64, ptr } %t856)
  br label %bb190
bb190:
  %t863 = load ptr, ptr %l0, !tbaa !29
  %t865 = getelementptr %"compiler/check:Checker", ptr %t863, i32 0, i32 32
  store ptr %t865, ptr %l460, !tbaa !29
  %t866 = load ptr, ptr %l26, !tbaa !29
  %t868 = icmp eq ptr %t866, null
  br i1 %t868, label %bb191, label %bb192
bb191:
  call void @__olang_check_failed(ptr @olang_loc_67a1dd87ea5136c_f63c1c37282cd7e0)
  unreachable
bb192:
  br label %bb193
bb193:
  %t870 = load ptr, ptr %l26, !tbaa !29
  %t871 = load ptr, ptr %l460, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t871, ptr %t870)
  br label %bb194
bb194:
  %t873 = load i64, ptr %l16, !tbaa !24
  %t875 = add i64 %t873, 1
  store i64 %t875, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb195
bb195:
  %t877 = load i64, ptr %l24, !tbaa !24
  %t879 = add i64 %t877, 1
  store i64 %t879, ptr %l24, !tbaa !24
  br label %bb83
bb196:
  br label %bb197
bb197:
  store %olang.scope zeroinitializer, ptr %s25
  %t881 = load i64, ptr %l16, !tbaa !24
  %t882 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t884 = extractvalue { i64, ptr } %t882, 0
  %t887 = icmp slt i64 %t881, %t884
  %t889 = xor i1 %t887, true
  br i1 %t889, label %bb198, label %bb199
bb198:
  call void @__olang_scope_close(ptr %s25)
  br label %bb204
bb199:
  br label %bb200
bb200:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/check:Checker", ptr %t891, i32 0, i32 32
  store ptr %t893, ptr %l474, !tbaa !29
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = load %"compiler/source:Span", ptr %l1
  %t896 = load ptr, ptr %l4, !tbaa !29
  %t897 = load i64, ptr %l5, !tbaa !24
  %t898 = load i64, ptr %l16, !tbaa !24
  %t899 = load ptr, ptr %l6, !tbaa !29
  %t901 = icmp eq ptr %t899, null
  %t903 = xor i1 %t901, true
  %t904 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t904, ptr %l483, !tbaa !27
  %t905 = load i64, ptr %l16, !tbaa !24
  %t907 = getelementptr { i64, ptr }, ptr %l483, i32 0, i32 1
  %t908 = load ptr, ptr %t907, !tbaa !27
  %t909 = getelementptr i32, ptr %t908, i64 %t905
  %t910 = load i32, ptr %t909, !tbaa !33
  %t918 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %t894, %"compiler/source:Span" %t895, ptr %t896, i64 %t897, i64 %t898, i1 %t903, i32 %t910)
  store ptr %t918, ptr %l486
  br label %bb201
bb201:
  %t919 = load ptr, ptr %l474, !tbaa !29
  %t920 = load ptr, ptr %l486, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t919, ptr %t920)
  br label %bb202
bb202:
  %t921 = load i64, ptr %l16, !tbaa !24
  %t923 = add i64 %t921, 1
  store i64 %t923, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb203
bb203:
  br label %bb197
bb204:
  %t925 = load i1, ptr %l11, !tbaa !21
  br i1 %t925, label %bb205, label %bb206
bb205:
  store i32 0, ptr %l490, !tbaa !23
  br label %bb208
bb206:
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load ptr, ptr %l4, !tbaa !29
  %t929 = load i32, ptr %l3, !tbaa !23
  %t933 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %t927, ptr %t928, i32 %t929)
  store i32 %t933, ptr %l494
  br label %bb207
bb207:
  %t934 = load i32, ptr %l494, !tbaa !23
  store i32 %t934, ptr %l490, !tbaa !23
  br label %bb208
bb208:
  %t935 = load i32, ptr %l490, !tbaa !23
  store i32 %t935, ptr %l33, !tbaa !23
  %t936 = load ptr, ptr %l0, !tbaa !29
  %t938 = getelementptr %"compiler/check:Checker", ptr %t936, i32 0, i32 1
  %t939 = load ptr, ptr %t938, !tbaa !29
  %t941 = getelementptr %"compiler/generic:Program", ptr %t939, i32 0, i32 2
  %t942 = load i32, ptr %l33, !tbaa !23
  %t945 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t941, i32 %t942)
  store { i64, ptr } %t945, ptr %l499
  br label %bb209
bb209:
  %t946 = load { i64, ptr }, ptr %l499, !tbaa !27
  %t947 = extractvalue { i64, ptr } %t946, 0
  %t949 = icmp sgt i64 %t947, 0
  br i1 %t949, label %bb210, label %bb211
bb210:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t951)
  store ptr %t953, ptr %l504
  br label %bb212
bb211:
  store i1 false, ptr %l502, !tbaa !21
  br label %bb213
bb212:
  %t954 = load ptr, ptr %l504, !tbaa !29
  %t956 = getelementptr %"compiler/check:frame", ptr %t954, i32 0, i32 15
  %t957 = load i64, ptr %t956, !tbaa !24
  %t959 = icmp eq i64 %t957, 0
  store i1 %t959, ptr %l502, !tbaa !21
  br label %bb213
bb213:
  %t961 = load i1, ptr %l502, !tbaa !21
  br i1 %t961, label %bb214, label %bb215
bb214:
  %t962 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t963 = load i32, ptr %t962, !tbaa !23
  %t965 = icmp sge i32 %t963, 0
  br i1 %t965, label %bb216, label %bb217
bb215:
  br label %bb228
bb216:
  store %olang.scope zeroinitializer, ptr %s27
  %t967 = load ptr, ptr %l0, !tbaa !29
  store ptr %t967, ptr %l510, !tbaa !29
  %t968 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t968, ptr %l511
  %t969 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t971 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %s27, { i64, ptr } %t969)
  store %"compiler/msgs:Msg" %t971, ptr %l513
  br label %bb218
bb217:
  %t972 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t974 = extractvalue { i64, ptr } %t972, 0
  %t976 = icmp sgt i64 %t974, 0
  br i1 %t976, label %bb220, label %bb221
bb218:
  %t978 = load ptr, ptr %l510, !tbaa !29
  %t979 = load %"compiler/source:Span", ptr %l511
  %t980 = load %"compiler/msgs:Msg", ptr %l513
  %t981 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t978, %"compiler/source:Span" %t979, %"compiler/msgs:Msg" %t980)
  store i64 %t981, ptr %l514
  br label %bb219
bb219:
  call void @__olang_scope_close(ptr %s27)
  br label %bb227
bb220:
  store %olang.scope zeroinitializer, ptr %s29
  %t982 = load ptr, ptr %l0, !tbaa !29
  store ptr %t982, ptr %l518, !tbaa !29
  %t983 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t983, ptr %l519
  %t984 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t986 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %s29, { i64, ptr } %t984)
  store %"compiler/msgs:Msg" %t986, ptr %l521
  br label %bb222
bb221:
  store %olang.scope zeroinitializer, ptr %s30
  %t987 = load ptr, ptr %l0, !tbaa !29
  store ptr %t987, ptr %l523, !tbaa !29
  %t988 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t988, ptr %l524
  %t989 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s30)
  store %"compiler/msgs:Msg" %t989, ptr %l525
  br label %bb224
bb222:
  %t990 = load ptr, ptr %l518, !tbaa !29
  %t991 = load %"compiler/source:Span", ptr %l519
  %t992 = load %"compiler/msgs:Msg", ptr %l521
  %t993 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t990, %"compiler/source:Span" %t991, %"compiler/msgs:Msg" %t992)
  store i64 %t993, ptr %l522
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s29)
  br label %bb226
bb224:
  %t994 = load ptr, ptr %l523, !tbaa !29
  %t995 = load %"compiler/source:Span", ptr %l524
  %t996 = load %"compiler/msgs:Msg", ptr %l525
  %t997 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s30, ptr %t994, %"compiler/source:Span" %t995, %"compiler/msgs:Msg" %t996)
  store i64 %t997, ptr %l526
  br label %bb225
bb225:
  call void @__olang_scope_close(ptr %s30)
  br label %bb226
bb226:
  br label %bb227
bb227:
  br label %bb228
bb228:
  %t998 = load ptr, ptr %l0, !tbaa !29
  %t1000 = getelementptr %"compiler/check:Checker", ptr %t998, i32 0, i32 1
  %t1001 = load ptr, ptr %t1000, !tbaa !29
  %t1003 = getelementptr %"compiler/generic:Program", ptr %t1001, i32 0, i32 2
  %t1004 = load i32, ptr %l33, !tbaa !23
  %t1007 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1003, i32 %t1004)
  store { i64, ptr } %t1007, ptr %l531
  br label %bb229
bb229:
  %t1008 = load { i64, ptr }, ptr %l531, !tbaa !27
  %t1009 = extractvalue { i64, ptr } %t1008, 0
  %t1011 = icmp sgt i64 %t1009, 0
  br i1 %t1011, label %bb230, label %bb231
bb230:
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1015 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1013)
  store ptr %t1015, ptr %l535
  br label %bb232
bb231:
  br label %bb233
bb232:
  %t1016 = load ptr, ptr %l535, !tbaa !29
  store ptr %t1016, ptr %l536, !tbaa !29
  %t1017 = load ptr, ptr %l536, !tbaa !29
  %t1018 = getelementptr %"compiler/check:frame", ptr %t1017, i32 0, i32 16
  %t1019 = load i64, ptr %t1018, !tbaa !24
  %t1021 = add i64 %t1019, 1
  %t1023 = load ptr, ptr %l536, !tbaa !29
  %t1024 = getelementptr %"compiler/check:frame", ptr %t1023, i32 0, i32 16
  store i64 %t1021, ptr %t1024, !tbaa !24
  br label %bb233
bb233:
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1026 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t1025, i32 %t1026)
  br label %bb234
bb234:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  %t1030 = load i32, ptr %l33, !tbaa !23
  %t1033 = getelementptr %"compiler/check:Checker", ptr %t1029, i32 0, i32 35
  store i32 %t1030, ptr %t1033, !tbaa !23
  %t1034 = load ptr, ptr %l0, !tbaa !29
  %t1036 = getelementptr %"compiler/check:Checker", ptr %t1034, i32 0, i32 1
  %t1037 = load ptr, ptr %t1036, !tbaa !29
  %t1039 = getelementptr %"compiler/generic:Program", ptr %t1037, i32 0, i32 2
  %t1040 = load i32, ptr %l3, !tbaa !23
  %t1043 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1039, i32 %t1040)
  store i32 %t1043, ptr %l547
  br label %bb235
bb235:
  %t1044 = load i32, ptr %l547, !tbaa !23
  store i32 %t1044, ptr %l34, !tbaa !23
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1046 = load i32, ptr %l34, !tbaa !23
  %t1049 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1045, i32 %t1046)
  store i1 %t1049, ptr %l550
  br label %bb236
bb236:
  %t1050 = load i1, ptr %l550, !tbaa !21
  br i1 %t1050, label %bb237, label %bb238
bb237:
  %t1051 = load ptr, ptr %l0, !tbaa !29
  %t1053 = getelementptr %"compiler/check:Checker", ptr %t1051, i32 0, i32 1
  %t1054 = load ptr, ptr %t1053, !tbaa !29
  %t1056 = getelementptr %"compiler/generic:Program", ptr %t1054, i32 0, i32 2
  %t1057 = load i32, ptr %l3, !tbaa !23
  %t1060 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t1056, i32 %t1057, i64 0)
  store i64 %t1060, ptr %l556
  br label %bb239
bb238:
  store i1 false, ptr %l551, !tbaa !21
  br label %bb240
bb239:
  %t1061 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t1062 = load i64, ptr %l556, !tbaa !24
  %t1064 = icmp eq i64 %t1062, %t1061
  store i1 %t1064, ptr %l551, !tbaa !21
  br label %bb240
bb240:
  %t1066 = load i1, ptr %l551, !tbaa !21
  br i1 %t1066, label %bb241, label %bb242
bb241:
  %t1067 = load ptr, ptr %l0, !tbaa !29
  %t1069 = getelementptr %"compiler/check:Checker", ptr %t1067, i32 0, i32 1
  %t1070 = load ptr, ptr %t1069, !tbaa !29
  %t1072 = getelementptr %"compiler/generic:Program", ptr %t1070, i32 0, i32 2
  store ptr %t1072, ptr %l561, !tbaa !29
  %t1073 = load ptr, ptr %l0, !tbaa !29
  %t1075 = getelementptr %"compiler/check:Checker", ptr %t1073, i32 0, i32 1
  %t1076 = load ptr, ptr %t1075, !tbaa !29
  %t1078 = getelementptr %"compiler/generic:Program", ptr %t1076, i32 0, i32 2
  %t1079 = load i32, ptr %l34, !tbaa !23
  %t1082 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1078, i32 %t1079)
  store i32 %t1082, ptr %l566
  br label %bb243
bb242:
  %t1083 = load ptr, ptr %l0, !tbaa !29
  %t1085 = getelementptr %"compiler/check:Checker", ptr %t1083, i32 0, i32 1
  %t1086 = load ptr, ptr %t1085, !tbaa !29
  %t1088 = getelementptr %"compiler/generic:Program", ptr %t1086, i32 0, i32 2
  %t1089 = load i32, ptr %l34, !tbaa !23
  %t1092 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1088, i32 %t1089)
  store i32 %t1092, ptr %l579
  br label %bb246
bb243:
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1095 = getelementptr %"compiler/check:Checker", ptr %t1093, i32 0, i32 1
  %t1096 = load ptr, ptr %t1095, !tbaa !29
  %t1098 = getelementptr %"compiler/generic:Program", ptr %t1096, i32 0, i32 2
  %t1099 = load i32, ptr %l34, !tbaa !23
  %t1102 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1098, i32 %t1099)
  store i64 %t1102, ptr %l571
  br label %bb244
bb244:
  %t1103 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1104 = load i64, ptr %l571, !tbaa !24
  %t1106 = or i64 %t1104, %t1103
  %t1107 = load ptr, ptr %l561, !tbaa !29
  %t1108 = load i32, ptr %l566, !tbaa !23
  %t1110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1107, i32 %t1108, i64 %t1106)
  store i32 %t1110, ptr %l574
  br label %bb245
bb245:
  %t1111 = load i32, ptr %l574, !tbaa !23
  store i32 %t1111, ptr %l34, !tbaa !23
  br label %bb287
bb246:
  %t1112 = load i32, ptr %l579
  %t1114 = trunc i64 22 to i32
  %t1115 = icmp eq i32 %t1112, %t1114
  br i1 %t1115, label %bb247, label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s34
  %t1117 = load ptr, ptr %l0, !tbaa !29
  %t1119 = getelementptr %"compiler/check:Checker", ptr %t1117, i32 0, i32 1
  %t1120 = load ptr, ptr %t1119, !tbaa !29
  %t1122 = getelementptr %"compiler/generic:Program", ptr %t1120, i32 0, i32 2
  store ptr %t1122, ptr %l584, !tbaa !29
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1125 = getelementptr %"compiler/check:Checker", ptr %t1123, i32 0, i32 1
  %t1126 = load ptr, ptr %t1125, !tbaa !29
  %t1128 = getelementptr %"compiler/generic:Program", ptr %t1126, i32 0, i32 2
  %t1129 = load i32, ptr %l34, !tbaa !23
  %t1132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1128, i32 %t1129)
  store i32 %t1132, ptr %l589
  br label %bb249
bb248:
  br label %bb286
bb249:
  %t1133 = load ptr, ptr %l584, !tbaa !29
  %t1134 = load i32, ptr %l589, !tbaa !23
  %t1135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1133, i32 %t1134)
  store { i64, ptr } %t1135, ptr %l590
  br label %bb250
bb250:
  %t1136 = load { i64, ptr }, ptr %l590, !tbaa !27
  store { i64, ptr } %t1136, ptr %l35, !tbaa !27
  %t1137 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s34)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1137, ptr %l591
  br label %bb251
bb251:
  %t1138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l591
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1138, ptr %l36
  store i1 false, ptr %l37, !tbaa !21
  store i64 0, ptr %l38, !tbaa !24
  %t1139 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1141 = extractvalue { i64, ptr } %t1139, 0
  store i64 %t1141, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t1143 = load i64, ptr %l39, !tbaa !24
  %t1144 = load i64, ptr %l38, !tbaa !24
  %t1147 = icmp sgt i64 %t1143, %t1144
  br i1 %t1147, label %bb252, label %bb253
bb252:
  %t1149 = load i64, ptr %l40, !tbaa !24
  %t1151 = icmp sgt i64 %t1149, 0
  br i1 %t1151, label %bb254, label %bb255
bb253:
  store i64 0, ptr %l597, !tbaa !24
  br label %bb257
bb254:
  %t1153 = load i64, ptr %l39, !tbaa !24
  %t1154 = load i64, ptr %l38, !tbaa !24
  %t1157 = sub i64 %t1153, %t1154
  %t1158 = load i64, ptr %l40, !tbaa !24
  %t1161 = add i64 %t1157, %t1158
  %t1163 = sub i64 %t1161, 1
  %t1164 = load i64, ptr %l40, !tbaa !24
  %t1167 = sdiv i64 %t1163, %t1164
  store i64 %t1167, ptr %l600, !tbaa !24
  br label %bb256
bb255:
  store i64 0, ptr %l600, !tbaa !24
  br label %bb256
bb256:
  %t1169 = load i64, ptr %l600, !tbaa !24
  store i64 %t1169, ptr %l597, !tbaa !24
  br label %bb257
bb257:
  %t1170 = load i64, ptr %l597, !tbaa !24
  store i64 %t1170, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb258
bb258:
  store %olang.scope zeroinitializer, ptr %s36
  %t1171 = load i64, ptr %l42, !tbaa !24
  %t1172 = load i64, ptr %l41, !tbaa !24
  %t1175 = icmp slt i64 %t1171, %t1172
  %t1177 = xor i1 %t1175, true
  br i1 %t1177, label %bb259, label %bb260
bb259:
  call void @__olang_scope_close(ptr %s36)
  br label %bb279
bb260:
  br label %bb261
bb261:
  %t1179 = load i64, ptr %l38, !tbaa !24
  %t1180 = load i64, ptr %l42, !tbaa !24
  %t1181 = load i64, ptr %l40, !tbaa !24
  %t1184 = mul i64 %t1180, %t1181
  %t1187 = add i64 %t1179, %t1184
  store i64 %t1187, ptr %l43, !tbaa !24
  %t1189 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1189, ptr %l618, !tbaa !27
  %t1190 = load i64, ptr %l43, !tbaa !24
  %t1192 = getelementptr { i64, ptr }, ptr %l618, i32 0, i32 1
  %t1193 = load ptr, ptr %t1192, !tbaa !27
  %t1194 = getelementptr i32, ptr %t1193, i64 %t1190
  %t1195 = load i32, ptr %t1194, !tbaa !33
  store i32 %t1195, ptr %l44, !tbaa !23
  %t1197 = load ptr, ptr %l0, !tbaa !29
  %t1198 = load i32, ptr %l44, !tbaa !23
  %t1201 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1197, i32 %t1198)
  store i1 %t1201, ptr %l623
  br label %bb262
bb262:
  %t1202 = load i1, ptr %l623, !tbaa !21
  br i1 %t1202, label %bb263, label %bb264
bb263:
  %t1203 = load ptr, ptr %l0, !tbaa !29
  %t1205 = getelementptr %"compiler/check:Checker", ptr %t1203, i32 0, i32 1
  %t1206 = load ptr, ptr %t1205, !tbaa !29
  %t1208 = getelementptr %"compiler/generic:Program", ptr %t1206, i32 0, i32 2
  %t1209 = load i32, ptr %l3, !tbaa !23
  %t1210 = load i64, ptr %l43, !tbaa !24
  %t1214 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t1208, i32 %t1209, i64 %t1210)
  store i64 %t1214, ptr %l630
  br label %bb265
bb264:
  store i1 false, ptr %l624, !tbaa !21
  br label %bb266
bb265:
  %t1215 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t1216 = load i64, ptr %l630, !tbaa !24
  %t1218 = icmp eq i64 %t1216, %t1215
  store i1 %t1218, ptr %l624, !tbaa !21
  br label %bb266
bb266:
  %t1220 = load i1, ptr %l624, !tbaa !21
  br i1 %t1220, label %bb267, label %bb268
bb267:
  %t1221 = load ptr, ptr %l0, !tbaa !29
  %t1223 = getelementptr %"compiler/check:Checker", ptr %t1221, i32 0, i32 1
  %t1224 = load ptr, ptr %t1223, !tbaa !29
  %t1226 = getelementptr %"compiler/generic:Program", ptr %t1224, i32 0, i32 2
  %t1227 = load i32, ptr %l44, !tbaa !23
  %t1230 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1226, i32 %t1227)
  store i64 %t1230, ptr %l638
  br label %bb269
bb268:
  store i1 false, ptr %l633, !tbaa !21
  br label %bb270
bb269:
  %t1231 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1232 = load i64, ptr %l638, !tbaa !24
  %t1234 = and i64 %t1232, %t1231
  %t1236 = icmp eq i64 %t1234, 0
  store i1 %t1236, ptr %l633, !tbaa !21
  br label %bb270
bb270:
  %t1238 = load i1, ptr %l633, !tbaa !21
  br i1 %t1238, label %bb271, label %bb272
bb271:
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1241 = getelementptr %"compiler/check:Checker", ptr %t1239, i32 0, i32 1
  %t1242 = load ptr, ptr %t1241, !tbaa !29
  %t1244 = getelementptr %"compiler/generic:Program", ptr %t1242, i32 0, i32 2
  store ptr %t1244, ptr %l644, !tbaa !29
  %t1245 = load ptr, ptr %l0, !tbaa !29
  %t1247 = getelementptr %"compiler/check:Checker", ptr %t1245, i32 0, i32 1
  %t1248 = load ptr, ptr %t1247, !tbaa !29
  %t1250 = getelementptr %"compiler/generic:Program", ptr %t1248, i32 0, i32 2
  %t1251 = load i32, ptr %l44, !tbaa !23
  %t1254 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1250, i32 %t1251)
  store i32 %t1254, ptr %l649
  br label %bb273
bb272:
  br label %bb276
bb273:
  %t1255 = load ptr, ptr %l0, !tbaa !29
  %t1257 = getelementptr %"compiler/check:Checker", ptr %t1255, i32 0, i32 1
  %t1258 = load ptr, ptr %t1257, !tbaa !29
  %t1260 = getelementptr %"compiler/generic:Program", ptr %t1258, i32 0, i32 2
  %t1261 = load i32, ptr %l44, !tbaa !23
  %t1264 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1260, i32 %t1261)
  store i64 %t1264, ptr %l654
  br label %bb274
bb274:
  %t1265 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1266 = load i64, ptr %l654, !tbaa !24
  %t1268 = or i64 %t1266, %t1265
  %t1269 = load ptr, ptr %l644, !tbaa !29
  %t1270 = load i32, ptr %l649, !tbaa !23
  %t1272 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1269, i32 %t1270, i64 %t1268)
  store i32 %t1272, ptr %l657
  br label %bb275
bb275:
  %t1273 = load i32, ptr %l657, !tbaa !23
  store i32 %t1273, ptr %l44, !tbaa !23
  store i1 true, ptr %l37, !tbaa !21
  br label %bb276
bb276:
  %t1274 = load i32, ptr %l44, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s34, ptr %l36, i32 %t1274)
  br label %bb277
bb277:
  call void @__olang_scope_close(ptr %s36)
  br label %bb278
bb278:
  %t1277 = load i64, ptr %l42, !tbaa !24
  %t1279 = add i64 %t1277, 1
  store i64 %t1279, ptr %l42, !tbaa !24
  br label %bb258
bb279:
  %t1281 = load i1, ptr %l37, !tbaa !21
  br i1 %t1281, label %bb280, label %bb281
bb280:
  store %olang.scope zeroinitializer, ptr %s39
  %t1283 = load ptr, ptr %l0, !tbaa !29
  %t1285 = getelementptr %"compiler/check:Checker", ptr %t1283, i32 0, i32 1
  %t1286 = load ptr, ptr %t1285, !tbaa !29
  %t1288 = getelementptr %"compiler/generic:Program", ptr %t1286, i32 0, i32 2
  store ptr %t1288, ptr %l665, !tbaa !29
  %t1289 = load ptr, ptr %l0, !tbaa !29
  %t1291 = getelementptr %"compiler/check:Checker", ptr %t1289, i32 0, i32 1
  %t1292 = load ptr, ptr %t1291, !tbaa !29
  %t1294 = getelementptr %"compiler/generic:Program", ptr %t1292, i32 0, i32 2
  store ptr %t1294, ptr %l668, !tbaa !29
  %t1296 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s34, ptr %s39, ptr %l36)
  store { i64, ptr } %t1296, ptr %l670
  br label %bb282
bb281:
  br label %bb285
bb282:
  %t1297 = load ptr, ptr %l668, !tbaa !29
  %t1298 = load { i64, ptr }, ptr %l670, !tbaa !27
  %t1299 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s39, ptr %t1297, { i64, ptr } %t1298)
  store i32 %t1299, ptr %l671
  br label %bb283
bb283:
  %t1300 = load ptr, ptr %l665, !tbaa !29
  %t1301 = load i32, ptr %l671, !tbaa !23
  %t1302 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t1300, i32 %t1301)
  store i32 %t1302, ptr %l672
  br label %bb284
bb284:
  %t1303 = load i32, ptr %l672, !tbaa !23
  store i32 %t1303, ptr %l34, !tbaa !23
  call void @__olang_scope_close(ptr %s39)
  br label %bb285
bb285:
  call void @__olang_scope_close(ptr %s34)
  br label %bb286
bb286:
  br label %bb287
bb287:
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load ptr, ptr %l4, !tbaa !29
  %t1306 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v0, ptr %t1304, ptr %t1305, i32 %t1306)
  br label %bb288
bb288:
  %t1310 = load ptr, ptr %l0, !tbaa !29
  %t1312 = getelementptr %"compiler/check:Checker", ptr %t1310, i32 0, i32 32
  %t1313 = load i64, ptr %l15, !tbaa !24
  %t1316 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1312, i64 %t1313)
  store { i64, ptr } %t1316, ptr %l679
  br label %bb289
bb289:
  %t1317 = load { i64, ptr }, ptr %l679, !tbaa !27
  store { i64, ptr } %t1317, ptr %l45, !tbaa !27
  %t1318 = load ptr, ptr %l0, !tbaa !29
  %t1319 = load %"compiler/source:Span", ptr %l1
  %t1323 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1318, i32 0, %"compiler/source:Span" %t1319)
  store i32 %t1323, ptr %l683
  br label %bb290
bb290:
  %t1324 = load i32, ptr %l683, !tbaa !23
  store i32 %t1324, ptr %l46, !tbaa !23
  %t1325 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1325, ptr %l684
  %t1326 = load i32, ptr %l34, !tbaa !23
  store i32 %t1326, ptr %l685, !tbaa !23
  %t1327 = load ptr, ptr %l4, !tbaa !29
  %t1328 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t1329
  %t1330 = getelementptr { i64, [2 x i64] }, ptr %t1329, i32 0, i32 0
  store i64 0, ptr %t1330
  %t1331 = load { i64, [2 x i64] }, ptr %t1329
  %t1332 = load i32, ptr %l46, !tbaa !23
  %t1337 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t1327, { i64, ptr } %t1328, { i64, [2 x i64] } %t1331, i32 %t1332, i1 false)
  store %"compiler/typed:Call" %t1337, ptr %l690
  br label %bb291
bb291:
  %t1338 = load %"compiler/typed:Call", ptr %l690
  %t1339 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t1338, ptr %t1339
  store { i64, [5 x i64] } zeroinitializer, ptr %t1340
  %t1341 = getelementptr { i64, [5 x i64] }, ptr %t1340, i32 0, i32 0
  store i64 6, ptr %t1341
  %t1342 = load %"compiler/source:Span", ptr %l684
  %t1343 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1342, 0
  %t1344 = load i32, ptr %l685, !tbaa !23
  %t1345 = insertvalue { %"compiler/source:Span", i32, ptr } %t1343, i32 %t1344, 1
  %t1347 = insertvalue { %"compiler/source:Span", i32, ptr } %t1345, ptr %t1339, 2
  %t1348 = getelementptr { i64, [5 x i64] }, ptr %t1340, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1347, ptr %t1348
  %t1349 = load { i64, [5 x i64] }, ptr %t1340
  %t1350 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t1350, ptr %lp47
  %t1352 = load ptr, ptr %lp47
  store { i64, [5 x i64] } %t1349, ptr %t1352
  %t1353 = load ptr, ptr %l0, !tbaa !29
  %t1354 = load ptr, ptr %l4, !tbaa !29
  %t1357 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t1353, ptr %t1354)
  store i64 %t1357, ptr %l695
  br label %bb292
bb292:
  %t1358 = load i64, ptr %l695, !tbaa !24
  store i64 %t1358, ptr %l48, !tbaa !24
  %t1359 = load i64, ptr %l48, !tbaa !24
  %t1361 = icmp slt i64 %t1359, 0
  br i1 %t1361, label %bb293, label %bb294
bb293:
  %t1363 = load ptr, ptr %l0, !tbaa !29
  %t1364 = load ptr, ptr %l4, !tbaa !29
  %t1367 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotContract(ptr %v0, ptr %v0, ptr %t1363, ptr %t1364)
  store i64 %t1367, ptr %l700
  br label %bb295
bb294:
  br label %bb296
bb295:
  %t1368 = load i64, ptr %l700, !tbaa !24
  store i64 %t1368, ptr %l48, !tbaa !24
  br label %bb296
bb296:
  %t1369 = load i64, ptr %l48, !tbaa !24
  %t1371 = icmp sge i64 %t1369, 0
  br i1 %t1371, label %bb297, label %bb298
bb297:
  %t1373 = load ptr, ptr %l0, !tbaa !29
  %t1375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1373)
  store ptr %t1375, ptr %l705
  br label %bb299
bb298:
  store i1 false, ptr %l703, !tbaa !21
  br label %bb300
bb299:
  %t1376 = load ptr, ptr %l705, !tbaa !29
  %t1378 = getelementptr %"compiler/check:frame", ptr %t1376, i32 0, i32 47
  %t1379 = load i64, ptr %t1378, !tbaa !24
  %t1381 = icmp eq i64 %t1379, 0
  store i1 %t1381, ptr %l703, !tbaa !21
  br label %bb300
bb300:
  %t1383 = load i1, ptr %l703, !tbaa !21
  br i1 %t1383, label %bb301, label %bb302
bb301:
  %t1384 = load ptr, ptr %l0, !tbaa !29
  %t1385 = load i64, ptr %l48, !tbaa !24
  %t1388 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t1384, i64 %t1385)
  store i1 %t1388, ptr %l712
  br label %bb303
bb302:
  store i1 false, ptr %l709, !tbaa !21
  br label %bb304
bb303:
  %t1389 = load i1, ptr %l712, !tbaa !21
  store i1 %t1389, ptr %l709, !tbaa !21
  br label %bb304
bb304:
  %t1390 = load i1, ptr %l709, !tbaa !21
  br i1 %t1390, label %bb305, label %bb306
bb305:
  %t1391 = load ptr, ptr %l0, !tbaa !29
  %t1392 = load %"compiler/source:Span", ptr %l1
  %t1393 = load %"compiler/source:Span", ptr %l2
  %t1394 = load i32, ptr %l34, !tbaa !23
  %t1395 = load ptr, ptr %lp47
  %t1396 = load { i64, [5 x i64] }, ptr %t1395
  %t1398 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1396, ptr %t1398
  %t1399 = load ptr, ptr %l4, !tbaa !29
  %t1400 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1401 = load i32, ptr %l46, !tbaa !23
  %t1402 = load i64, ptr %l48, !tbaa !24
  %t1412 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractAt(ptr %v0, ptr %t1391, %"compiler/source:Span" %t1392, %"compiler/source:Span" %t1393, i32 %t1394, ptr %t1398, ptr %t1399, { i64, ptr } %t1400, i32 %t1401, i64 %t1402)
  store ptr %t1412, ptr %l723
  br label %bb307
bb306:
  br label %bb308
bb307:
  %t1413 = load ptr, ptr %l723, !tbaa !29
  %t1414 = load { i64, [5 x i64] }, ptr %t1413
  %t1416 = load ptr, ptr %lp47
  store { i64, [5 x i64] } %t1414, ptr %t1416
  br label %bb308
bb308:
  %t1417 = load ptr, ptr %l0, !tbaa !29
  %t1419 = getelementptr %"compiler/check:Checker", ptr %t1417, i32 0, i32 33
  %t1421 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1419)
  store i64 %t1421, ptr %l727
  br label %bb309
bb309:
  %t1422 = load i64, ptr %l13, !tbaa !24
  %t1423 = load i64, ptr %l727, !tbaa !24
  %t1425 = icmp sgt i64 %t1423, %t1422
  br i1 %t1425, label %bb310, label %bb311
bb310:
  %t1427 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1427, ptr %l730
  %t1428 = load i32, ptr %l34, !tbaa !23
  store i32 %t1428, ptr %l731, !tbaa !23
  %t1429 = load ptr, ptr %l0, !tbaa !29
  %t1431 = getelementptr %"compiler/check:Checker", ptr %t1429, i32 0, i32 33
  %t1432 = load i64, ptr %l13, !tbaa !24
  %t1435 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1431, i64 %t1432)
  store { i64, ptr } %t1435, ptr %l735
  br label %bb312
bb311:
  br label %bb314
bb312:
  %t1436 = load ptr, ptr %lp47
  %t1437 = load { i64, ptr }, ptr %l735, !tbaa !27
  %t1439 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1437, ptr %t1436)
  store %"compiler/typed:Seq" %t1439, ptr %l737
  br label %bb313
bb313:
  %t1440 = load %"compiler/typed:Seq", ptr %l737
  %t1441 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t1440, ptr %t1441
  store { i64, [5 x i64] } zeroinitializer, ptr %t1442
  %t1443 = getelementptr { i64, [5 x i64] }, ptr %t1442, i32 0, i32 0
  store i64 12, ptr %t1443
  %t1444 = load %"compiler/source:Span", ptr %l730
  %t1445 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1444, 0
  %t1446 = load i32, ptr %l731, !tbaa !23
  %t1447 = insertvalue { %"compiler/source:Span", i32, ptr } %t1445, i32 %t1446, 1
  %t1449 = insertvalue { %"compiler/source:Span", i32, ptr } %t1447, ptr %t1441, 2
  %t1450 = getelementptr { i64, [5 x i64] }, ptr %t1442, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1449, ptr %t1450
  %t1451 = load { i64, [5 x i64] }, ptr %t1442
  %t1453 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1451, ptr %t1453
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1453, ptr %rv
  br label %ret
bb314:
  %t1455 = load ptr, ptr %lp47
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1455, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t7, %"compiler/source:Span" %t8, { i64, ptr } { i64 25, ptr @.d10 })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t11, %"compiler/source:Span" %t12)
  store ptr %t15, ptr %l15
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load ptr, ptr %l15, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp ne i64 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l20
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 1, { i64, ptr } { i64 0, ptr @.d11 }, i64 %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l20
  %t32 = load %"compiler/msgs:Msg", ptr %l23
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l27
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load ptr, ptr %l27, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t49 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t40, ptr %t45)
  store %"compiler/check:litv" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t50, ptr %l4
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t53 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/check:litv", ptr %l4
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l39
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb18:
  %t65 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t70, ptr %t75)
  store i1 %t78, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb26
bb21:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t80, ptr %t85)
  store i1 %t88, ptr %l52
  br label %bb24
bb24:
  %t89 = load i1, ptr %l52, !tbaa !21
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l48, !tbaa !21
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l40, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = load i32, ptr %l5, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t96, ptr %t101, i32 %t103)
  store ptr %t107, ptr %l60
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l63
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l63
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t115, ptr %t116, %"compiler/source:Span" %t117)
  store ptr %t118, ptr %l64
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l64, !tbaa !29
  store ptr %t119, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb34
bb34:
  %t124 = load i32, ptr %l67, !tbaa !23
  store i32 %t124, ptr %l7, !tbaa !23
  %t125 = load i32, ptr %l7, !tbaa !23
  %t126 = load i32, ptr %l2, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb37
bb36:
  %t131 = load i32, ptr %l7, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  store i1 %t135, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l78
  br label %bb41
bb41:
  %t145 = load i1, ptr %l78, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l82
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l82, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l79, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l85, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 0
  %t160 = load ptr, ptr %t159, !tbaa !39
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l87
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l90
  br label %bb49
bb49:
  %t168 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l91, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l7, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l94
  br label %bb50
bb50:
  %t180 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t187, { i64, ptr } %t186)
  store %"compiler/msgs:Msg" %t189, ptr %l96
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l84, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l87
  %t192 = load %"compiler/msgs:Msg", ptr %l96
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l97
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store ptr %t198, ptr %l100
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load ptr, ptr %l100, !tbaa !29
  store ptr %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l7, !tbaa !23
  %t202 = load i32, ptr %l2, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t200, i32 %t201, i32 %t202)
  store { i64, ptr } %t206, ptr %l104
  br label %bb55
bb55:
  %t207 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb56, label %bb57
bb56:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l107, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l108
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t214, ptr %l109, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 0
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l111
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l2, !tbaa !23
  %t223 = load ptr, ptr %l107, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l108
  %t225 = load %"compiler/source:Span", ptr %l111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/source:Span" %t225, ptr %t221, i32 %t222)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l6, !tbaa !29
  %t231 = load i32, ptr %l2, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t228, %"compiler/source:Span" %t229, ptr %t230, i32 %t231)
  store ptr %t236, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t237 = load ptr, ptr %l118, !tbaa !29
  store ptr %t237, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorVarRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l38 = alloca i32
  %l40 = alloca i32
  %l44 = alloca { i64, ptr }
  %l48 = alloca %"compiler/source:Span"
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca %"compiler/msgs:Msg"
  %l62 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l85 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i64
  %l123 = alloca i1
  %l128 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l132 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l142 = alloca i64
  %l147 = alloca i1
  %l152 = alloca i1
  %l165 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l194 = alloca %"compiler/source:Span"
  %l198 = alloca { i64, ptr }
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l206 = alloca %"compiler/source:Span"
  %l209 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:StructBody", ptr %t1, i32 0, i32 5
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/ast:TypeDecl", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:StructBody", ptr %t19, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l34, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 0
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l36, !tbaa !29
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t31 = getelementptr %"compiler/ast:TypeParam", ptr %t29, i32 0, i32 0
  %t32 = getelementptr %"compiler/source:Span", ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32, !tbaa !23
  store i32 %t33, ptr %l38, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/ast:TypeParam", ptr %t34, i32 0, i32 0
  %t37 = getelementptr %"compiler/source:Span", ptr %t36, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  store i32 %t38, ptr %l40, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TypeParam", ptr %t40, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l44
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t47 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t50 = trunc i64 %t48 to i32
  %t51 = load i32, ptr %l40, !tbaa !23
  %t53 = add i32 %t51, %t50
  %t54 = load i32, ptr %l38, !tbaa !23
  %t56 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t54, i32 %t53)
  store %"compiler/source:Span" %t56, ptr %l48
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TypeParam", ptr %t58, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t57, i32 %t61)
  store { i64, ptr } %t64, ptr %l52
  br label %bb8
bb8:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/ast:TypeDecl", ptr %t66, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t65, i32 %t69)
  store { i64, ptr } %t72, ptr %l56
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/ast:TypeParam", ptr %t74, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t73, i32 %t77)
  store { i64, ptr } %t80, ptr %l60
  br label %bb10
bb10:
  %t81 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t84 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } %t82, { i64, ptr } %t83)
  store %"compiler/msgs:Msg" %t84, ptr %l61
  br label %bb11
bb11:
  %t85 = load ptr, ptr %l36, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l48
  %t87 = load %"compiler/msgs:Msg", ptr %l61
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t85, %"compiler/source:Span" %t86, %"compiler/msgs:Msg" %t87)
  store i64 %t88, ptr %l62
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t92 = getelementptr %"compiler/ast:StructBody", ptr %t90, i32 0, i32 5
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l65, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr ptr, ptr %t95, i64 0
  %t97 = load ptr, ptr %t96, !tbaa !39
  %t99 = getelementptr %"compiler/ast:TypeParam", ptr %t97, i32 0, i32 1
  %t100 = load i32, ptr %t99, !tbaa !23
  %t103 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t89, i32 %t100)
  store { i64, ptr } %t103, ptr %l68
  br label %bb14
bb14:
  %t104 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:StructBody", ptr %t105, i32 0, i32 2
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:StructBody", ptr %t114, i32 0, i32 2
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  store i64 %t121, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l7, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb93
bb20:
  br label %bb21
bb21:
  %t131 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t131, ptr %l81, !tbaa !27
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 %t132
  %t137 = load ptr, ptr %t136, !tbaa !39
  store ptr %t137, ptr %l8, !tbaa !29
  %t139 = load ptr, ptr %l8, !tbaa !29
  store ptr %t139, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t140 = load ptr, ptr %l84, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb22, label %bb23
bb22:
  %t143 = load ptr, ptr %l84, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 1
  store i1 %t146, ptr %l85, !tbaa !21
  br label %bb23
bb23:
  %t147 = load i1, ptr %l85, !tbaa !21
  br i1 %t147, label %bb24, label %bb25
bb24:
  %t148 = load ptr, ptr %l8, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l9, !tbaa !29
  br label %bb26
bb25:
  br label %bb90
bb26:
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t156 = getelementptr %"compiler/ast:VarDecl", ptr %t154, i32 0, i32 5
  %t157 = load i1, ptr %t156, !tbaa !21
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb28:
  br label %bb29
bb29:
  store i64 0, ptr %l10, !tbaa !24
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = getelementptr %"compiler/ast:VarDecl", ptr %t161, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t164, 0
  store i64 %t166, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l11, !tbaa !24
  %t169 = load i64, ptr %l10, !tbaa !24
  %t172 = icmp sgt i64 %t168, %t169
  br i1 %t172, label %bb30, label %bb31
bb30:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t176 = icmp sgt i64 %t174, 0
  br i1 %t176, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb35
bb32:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l10, !tbaa !24
  %t182 = sub i64 %t178, %t179
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t182, %t183
  %t188 = sub i64 %t186, 1
  %t189 = load i64, ptr %l12, !tbaa !24
  %t192 = sdiv i64 %t188, %t189
  store i64 %t192, ptr %l102, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb34
bb34:
  %t194 = load i64, ptr %l102, !tbaa !24
  store i64 %t194, ptr %l99, !tbaa !24
  br label %bb35
bb35:
  %t195 = load i64, ptr %l99, !tbaa !24
  store i64 %t195, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s9
  %t196 = load i64, ptr %l14, !tbaa !24
  %t197 = load i64, ptr %l13, !tbaa !24
  %t200 = icmp slt i64 %t196, %t197
  %t202 = xor i1 %t200, true
  br i1 %t202, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb38:
  br label %bb39
bb39:
  %t204 = load i64, ptr %l10, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  %t206 = load i64, ptr %l12, !tbaa !24
  %t209 = mul i64 %t205, %t206
  %t212 = add i64 %t204, %t209
  store i64 %t212, ptr %l15, !tbaa !24
  %t214 = load ptr, ptr %l9, !tbaa !29
  %t216 = getelementptr %"compiler/ast:VarDecl", ptr %t214, i32 0, i32 2
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb40, label %bb41
bb40:
  %t221 = load ptr, ptr %l9, !tbaa !29
  %t223 = getelementptr %"compiler/ast:VarDecl", ptr %t221, i32 0, i32 3
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t228 = icmp sgt i64 %t226, 0
  store i1 %t228, ptr %l123, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb42
bb42:
  %t230 = load i1, ptr %l123, !tbaa !21
  br i1 %t230, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s10
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l128, !tbaa !29
  %t232 = load ptr, ptr %l9, !tbaa !29
  %t234 = getelementptr %"compiler/ast:VarDecl", ptr %t232, i32 0, i32 1
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l130, !tbaa !27
  %t236 = load i64, ptr %l15, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr %"compiler/source:Span", ptr %t239, i64 %t236
  %t241 = load %"compiler/source:Span", ptr %t240
  store %"compiler/source:Span" %t241, ptr %l132
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l9, !tbaa !29
  %t245 = getelementptr %"compiler/ast:VarDecl", ptr %t243, i32 0, i32 0
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l135, !tbaa !27
  %t247 = load i64, ptr %l15, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i32, ptr %t250, i64 %t247
  %t252 = load i32, ptr %t251, !tbaa !33
  %t255 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t242, i32 %t252)
  store { i64, ptr } %t255, ptr %l138
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t256 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t258 = extractvalue { i64, ptr } %t256, 1
  %t259 = mul i64 %t257, 1
  %t260 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t259)
  call void @llvm.memcpy.p0.p0.i64(ptr %t260, ptr %t258, i64 %t259, i1 false)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t263 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t266 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %s10, ptr %v0, ptr %s10, { i64, ptr } %t262, { i64, ptr } %t263)
  store %"compiler/msgs:Msg" %t266, ptr %l141
  br label %bb46
bb46:
  %t267 = load ptr, ptr %l128, !tbaa !29
  %t268 = load %"compiler/source:Span", ptr %l132
  %t269 = load %"compiler/msgs:Msg", ptr %l141
  %t270 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t267, %"compiler/source:Span" %t268, %"compiler/msgs:Msg" %t269)
  store i64 %t270, ptr %l142
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb48:
  %t271 = load ptr, ptr %l9, !tbaa !29
  %t273 = getelementptr %"compiler/ast:VarDecl", ptr %t271, i32 0, i32 2
  %t274 = load ptr, ptr %t273, !tbaa !29
  store ptr %t274, ptr %l16, !tbaa !29
  %t276 = load ptr, ptr %l16, !tbaa !29
  %t278 = icmp eq ptr %t276, null
  br i1 %t278, label %bb49, label %bb50
bb49:
  %t280 = load ptr, ptr %l9, !tbaa !29
  %t282 = getelementptr %"compiler/ast:VarDecl", ptr %t280, i32 0, i32 3
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t287 = icmp eq i64 %t285, 0
  store i1 %t287, ptr %l147, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb51
bb51:
  %t289 = load i1, ptr %l147, !tbaa !21
  br i1 %t289, label %bb52, label %bb53
bb52:
  %t290 = load ptr, ptr %l2, !tbaa !29
  %t292 = getelementptr %"compiler/ast:StructBody", ptr %t290, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t297 = icmp sgt i64 %t295, 0
  store i1 %t297, ptr %l152, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb54
bb54:
  %t299 = load i1, ptr %l152, !tbaa !21
  br i1 %t299, label %bb55, label %bb56
bb55:
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t302 = getelementptr %"compiler/ast:StructBody", ptr %t300, i32 0, i32 0
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  store { i64, ptr } %t303, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l19, !tbaa !24
  br label %bb57
bb56:
  br label %bb66
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t309 = load i64, ptr %l18, !tbaa !24
  %t310 = load i64, ptr %l19, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb65
bb59:
  br label %bb60
bb60:
  %t317 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t317, ptr %l165, !tbaa !27
  %t318 = load i64, ptr %l18, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  store ptr %t323, ptr %l20, !tbaa !29
  %t325 = load ptr, ptr %l20, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Param", ptr %t325, i32 0, i32 1
  %t328 = load i32, ptr %t327, !tbaa !23
  %t329 = load ptr, ptr %l9, !tbaa !29
  %t331 = getelementptr %"compiler/ast:VarDecl", ptr %t329, i32 0, i32 0
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l171, !tbaa !27
  %t333 = load i64, ptr %l15, !tbaa !24
  %t335 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr i32, ptr %t336, i64 %t333
  %t338 = load i32, ptr %t337, !tbaa !33
  %t341 = icmp eq i32 %t328, %t338
  br i1 %t341, label %bb61, label %bb62
bb61:
  %t343 = load ptr, ptr %l20, !tbaa !29
  %t345 = getelementptr %"compiler/ast:Param", ptr %t343, i32 0, i32 2
  %t346 = load ptr, ptr %t345, !tbaa !29
  store ptr %t346, ptr %l16, !tbaa !29
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb64
bb64:
  %t348 = load i64, ptr %l18, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l18, !tbaa !24
  br label %bb57
bb65:
  br label %bb66
bb66:
  %t352 = load ptr, ptr %l16, !tbaa !29
  %t354 = icmp eq ptr %t352, null
  br i1 %t354, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s9)
  br label %bb88
bb68:
  br label %bb69
bb69:
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t358 = getelementptr %"compiler/ast:StructBody", ptr %t356, i32 0, i32 5
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  store { i64, ptr } %t359, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l23, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s18
  %t365 = load i64, ptr %l22, !tbaa !24
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s18)
  br label %bb87
bb72:
  br label %bb73
bb73:
  %t373 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t373, ptr %l189, !tbaa !27
  %t374 = load i64, ptr %l22, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr ptr, ptr %t377, i64 %t374
  %t379 = load ptr, ptr %t378, !tbaa !39
  store ptr %t379, ptr %l24, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l192, !tbaa !29
  %t382 = load ptr, ptr %l16, !tbaa !29
  %t384 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t382)
  store %"compiler/source:Span" %t384, ptr %l194
  br label %bb74
bb74:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l24, !tbaa !29
  %t388 = getelementptr %"compiler/ast:TypeParam", ptr %t386, i32 0, i32 1
  %t389 = load i32, ptr %t388, !tbaa !23
  %t392 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t385, i32 %t389)
  store { i64, ptr } %t392, ptr %l198
  br label %bb75
bb75:
  %t393 = load ptr, ptr %l192, !tbaa !29
  %t394 = load %"compiler/source:Span", ptr %l194
  %t395 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t396 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v0, ptr %t393, %"compiler/source:Span" %t394, { i64, ptr } %t395)
  store %"compiler/source:Span" %t396, ptr %l199
  br label %bb76
bb76:
  %t397 = getelementptr %"compiler/source:Span", ptr %l199, i32 0, i32 0
  %t398 = load i32, ptr %t397, !tbaa !23
  %t400 = icmp sge i32 %t398, 0
  br i1 %t400, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s19
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l202, !tbaa !29
  %t403 = load ptr, ptr %l9, !tbaa !29
  %t405 = getelementptr %"compiler/ast:VarDecl", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l204, !tbaa !27
  %t407 = load i64, ptr %l15, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr %"compiler/source:Span", ptr %t410, i64 %t407
  %t412 = load %"compiler/source:Span", ptr %t411
  store %"compiler/source:Span" %t412, ptr %l206
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load ptr, ptr %l9, !tbaa !29
  %t416 = getelementptr %"compiler/ast:VarDecl", ptr %t414, i32 0, i32 0
  %t417 = load { i64, ptr }, ptr %t416, !tbaa !27
  store { i64, ptr } %t417, ptr %l209, !tbaa !27
  %t418 = load i64, ptr %l15, !tbaa !24
  %t420 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = getelementptr i32, ptr %t421, i64 %t418
  %t423 = load i32, ptr %t422, !tbaa !33
  %t426 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t413, i32 %t423)
  store { i64, ptr } %t426, ptr %l212
  br label %bb79
bb78:
  br label %bb85
bb79:
  %t427 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  %t429 = extractvalue { i64, ptr } %t427, 1
  %t430 = mul i64 %t428, 1
  %t431 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t430)
  call void @llvm.memcpy.p0.p0.i64(ptr %t431, ptr %t429, i64 %t430, i1 false)
  %t432 = insertvalue { i64, ptr } undef, i64 %t428, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l213, !tbaa !27
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l24, !tbaa !29
  %t437 = getelementptr %"compiler/ast:TypeParam", ptr %t435, i32 0, i32 1
  %t438 = load i32, ptr %t437, !tbaa !23
  %t441 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t434, i32 %t438)
  store { i64, ptr } %t441, ptr %l217
  br label %bb80
bb80:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l1, !tbaa !29
  %t445 = getelementptr %"compiler/ast:TypeDecl", ptr %t443, i32 0, i32 0
  %t446 = load i32, ptr %t445, !tbaa !23
  %t449 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t442, i32 %t446)
  store { i64, ptr } %t449, ptr %l221
  br label %bb81
bb81:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l24, !tbaa !29
  %t453 = getelementptr %"compiler/ast:TypeParam", ptr %t451, i32 0, i32 1
  %t454 = load i32, ptr %t453, !tbaa !23
  %t457 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t450, i32 %t454)
  store { i64, ptr } %t457, ptr %l225
  br label %bb82
bb82:
  %t458 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t459 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t460 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t461 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t462 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %s19, ptr %v0, ptr %v0, ptr %v0, ptr %s19, { i64, ptr } %t458, { i64, ptr } %t459, { i64, ptr } %t460, { i64, ptr } %t461)
  store %"compiler/msgs:Msg" %t462, ptr %l226
  br label %bb83
bb83:
  %t463 = load ptr, ptr %l202, !tbaa !29
  %t464 = load %"compiler/source:Span", ptr %l206
  %t465 = load %"compiler/msgs:Msg", ptr %l226
  %t466 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t463, %"compiler/source:Span" %t464, %"compiler/msgs:Msg" %t465)
  store i64 %t466, ptr %l227
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb86
bb86:
  %t467 = load i64, ptr %l22, !tbaa !24
  %t469 = add i64 %t467, 1
  store i64 %t469, ptr %l22, !tbaa !24
  br label %bb70
bb87:
  call void @__olang_scope_close(ptr %s9)
  br label %bb88
bb88:
  %t471 = load i64, ptr %l14, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l14, !tbaa !24
  br label %bb36
bb89:
  br label %bb91
bb90:
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb92:
  %t475 = load i64, ptr %l6, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l6, !tbaa !24
  br label %bb18
bb93:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecurInst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t9)
  store ptr %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l7, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t21)
  store ptr %t23, ptr %l15
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l1
  %t29 = load { i64, [2 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l18, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1b2b22cc85627f3f_81f3e65f4e45ba6b)
  unreachable
bb18:
  %t40 = load i64, ptr %l18, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 3
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { { i64, ptr } }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { %"compiler/cond:Value", i1 }
  %l5 = alloca %"compiler/cond:Value"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { %"compiler/cond:Value", i1 }
  %l12 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { %"compiler/cond:Value", i1 }
  %l17 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca i64
  %l36 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca i1
  %l50 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l63 = alloca i32
  %l66 = alloca %"compiler/check:litv"
  %l67 = alloca i64
  %l68 = alloca ptr
  %l72 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l83 = alloca i64
  %l84 = alloca ptr
  %l88 = alloca i1
  %l89 = alloca i32
  %l91 = alloca i32
  %l96 = alloca ptr
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t11, i32 %t12)
  store { i64, ptr } %t15, ptr %l15
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l12, !tbaa !29
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t18 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t16, { i64, ptr } %t17)
  %t19 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t18, 1
  %t20 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb3, label %ok.22
ok.22:
  store { %"compiler/cond:Value", i1 } %t19, ptr %l16
  br label %bb2
bb2:
  %t23 = load { %"compiler/cond:Value", i1 }, ptr %l16
  store { %"compiler/cond:Value", i1 } %t23, ptr %l8
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store ptr null, ptr %rv
  br label %ret
bb5:
  %t25 = load { %"compiler/cond:Value", i1 }, ptr %l8
  store { %"compiler/cond:Value", i1 } %t25, ptr %l4
  %t26 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l4, i32 0, i32 0
  %t27 = load %"compiler/cond:Value", ptr %t26
  store %"compiler/cond:Value" %t27, ptr %l5
  %t29 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l4, i32 0, i32 1
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l6, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb6
bb6:
  %t37 = load i32, ptr %l23, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t39 = load i32, ptr %t38
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i32, ptr %l7, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t48 = icmp eq i32 %t44, %t45
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l26, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t52, ptr %l31
  %t53 = load i32, ptr %l3, !tbaa !23
  store i32 %t53, ptr %l32, !tbaa !23
  %t54 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp ne i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l35, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l30, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l31
  %t61 = load i32, ptr %l32, !tbaa !23
  %t62 = load i64, ptr %l35, !tbaa !24
  %t63 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, i32 %t61, i64 %t62)
  store ptr %t63, ptr %l36
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l36, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  %t66 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t67 = load i32, ptr %t66
  %t69 = trunc i64 2 to i32
  %t70 = icmp eq i32 %t67, %t69
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l7, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l45
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t82 = load i1, ptr %l45, !tbaa !21
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load %"compiler/source:Span", ptr %l1
  %t86 = load i32, ptr %l3, !tbaa !23
  %t87 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t84, %"compiler/source:Span" %t85, i32 %t86, i64 %t88)
  store ptr %t93, ptr %l50
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t94 = load ptr, ptr %l50, !tbaa !29
  store ptr %t94, ptr %rv
  br label %ret
bb24:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t97 = load i32, ptr %t96
  %t99 = trunc i64 2 to i32
  %t100 = icmp eq i32 %t97, %t99
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l7, !tbaa !23
  %t111 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb28
bb27:
  %t112 = load i1, ptr %l59, !tbaa !21
  store i1 %t112, ptr %l54, !tbaa !21
  br label %bb28
bb28:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l60, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l61
  %t116 = load i32, ptr %l3, !tbaa !23
  store i32 %t116, ptr %l62, !tbaa !23
  %t117 = load i32, ptr %l7, !tbaa !23
  store i32 %t117, ptr %l63, !tbaa !23
  %t118 = load i1, ptr %l6, !tbaa !21
  %t119 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 1
  %t120 = load i64, ptr %t119, !tbaa !24
  %t123 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s4, i1 true, i1 false, i1 %t118, i64 %t120, double 0x0000000000000000)
  store %"compiler/check:litv" %t123, ptr %l66
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = load %"compiler/check:litv", ptr %l66
  %t126 = call i64 @compiler_2fcheck_2eintFloatBits(i32 %t124, %"compiler/check:litv" %t125)
  store i64 %t126, ptr %l67
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l61
  %t129 = load i32, ptr %l62, !tbaa !23
  %t130 = load i64, ptr %l67, !tbaa !24
  %t131 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129, i64 %t130)
  store ptr %t131, ptr %l68
  br label %bb33
bb33:
  %t132 = load ptr, ptr %l68, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  store ptr %t132, ptr %rv
  br label %ret
bb34:
  %t134 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t135 = load i32, ptr %t134
  %t137 = trunc i64 3 to i32
  %t138 = icmp eq i32 %t135, %t137
  br i1 %t138, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = load i32, ptr %l7, !tbaa !23
  %t149 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t145, i32 %t146)
  store i1 %t149, ptr %l77
  br label %bb37
bb36:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb38
bb37:
  %t150 = load i1, ptr %l77, !tbaa !21
  store i1 %t150, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l72, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l78, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l79
  %t154 = load i32, ptr %l3, !tbaa !23
  store i32 %t154, ptr %l80, !tbaa !23
  %t155 = load i32, ptr %l7, !tbaa !23
  %t156 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 2
  %t157 = load double, ptr %t156, !tbaa !26
  %t160 = call i64 @compiler_2fcheck_2efloatBits(i32 %t155, double %t157)
  store i64 %t160, ptr %l83
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t161 = load ptr, ptr %l78, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l79
  %t163 = load i32, ptr %l80, !tbaa !23
  %t164 = load i64, ptr %l83, !tbaa !24
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t161, %"compiler/source:Span" %t162, i32 %t163, i64 %t164)
  store ptr %t165, ptr %l84
  br label %bb42
bb42:
  %t166 = load ptr, ptr %l84, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb43:
  %t168 = getelementptr %"compiler/cond:Value", ptr %l5, i32 0, i32 0
  %t169 = load i32, ptr %t168
  %t171 = trunc i64 4 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb44, label %bb45
bb44:
  %t174 = load i32, ptr %l3, !tbaa !23
  store i32 %t174, ptr %l89, !tbaa !23
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t175)
  store i32 %t177, ptr %l91
  br label %bb46
bb45:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb47
bb46:
  %t178 = load i32, ptr %l89, !tbaa !23
  %t179 = load i32, ptr %l91, !tbaa !23
  %t180 = icmp eq i32 %t178, %t179
  store i1 %t180, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l88, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l1
  %t185 = load i32, ptr %l2, !tbaa !23
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %t183, %"compiler/source:Span" %t184, i32 %t185)
  store ptr %t189, ptr %l96
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t190 = load ptr, ptr %l96, !tbaa !29
  store ptr %t190, ptr %rv
  br label %ret
bb51:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb4
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  %t19 = load i32, ptr %l10, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l5, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %s3 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr ptr, ptr %t25, i64 %t22
  %t27 = load ptr, ptr %t26, !tbaa !39
  store ptr %t27, ptr %l5, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 23
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t45 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t39, i32 %t41)
  store ptr %t45, ptr %l27
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb4
bb17:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca %"compiler/check:litv"
  %l20 = alloca i64
  %l23 = alloca i32
  %l27 = alloca i64
  %l30 = alloca i64
  %l50 = alloca i1
  %l54 = alloca %"compiler/source:Span"
  %l59 = alloca i32
  %l63 = alloca ptr
  %l70 = alloca i32
  %l75 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca i32
  %l86 = alloca i64
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l97 = alloca i32
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l120 = alloca i32
  %l127 = alloca i32
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l138 = alloca %"compiler/check:atRec"
  %l139 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l153 = alloca %"compiler/source:Span"
  %l156 = alloca { i64, ptr }
  %l158 = alloca %"compiler/msgs:Msg"
  %l159 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l167 = alloca { i64, ptr }
  %l169 = alloca i1
  %l170 = alloca i32
  %l172 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca ptr
  %l179 = alloca ptr
  %l182 = alloca i32
  %l183 = alloca i1
  %l185 = alloca i1
  %l188 = alloca i32
  %l191 = alloca ptr
  %l192 = alloca { i64, ptr }
  %l194 = alloca %"compiler/source:Span"
  %l195 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l201 = alloca %"compiler/msgs:Msg"
  %l202 = alloca i64
  %l207 = alloca i32
  %l210 = alloca i1
  %l213 = alloca i1
  %l218 = alloca i32
  %l222 = alloca { i64, ptr }
  %l225 = alloca %"compiler/check:litv"
  %l230 = alloca i64
  %l232 = alloca i1
  %l235 = alloca i1
  %l238 = alloca i1
  %l241 = alloca i1
  %l245 = alloca ptr
  %l246 = alloca { i64, ptr }
  %l248 = alloca %"compiler/source:Span"
  %l251 = alloca %"compiler/msgs:Msg"
  %l252 = alloca i64
  %l253 = alloca %"compiler/source:Span"
  %l258 = alloca i32
  %l262 = alloca %"compiler/typed:Elem"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t83 = alloca { i64, [4 x i64] }, align 8
  %t250 = alloca { i64, [4 x i64] }, align 8
  %t514 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  %t3 = load ptr, ptr %l5, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load i32, ptr %l23, !tbaa !23
  store i32 %t6, ptr %l6, !tbaa !23
  store i64 0, ptr %l7, !tbaa !24
  store i64 4, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l9, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l9, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l9, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l30, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l30, !tbaa !24
  store i64 %t33, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l27, !tbaa !24
  store i64 %t34, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l11, !tbaa !24
  %t45 = load i64, ptr %l9, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l12, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l6, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l50
  br label %bb12
bb12:
  %t58 = load i1, ptr %l50, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t61, ptr %t62)
  br label %bb16
bb16:
  %t65 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t65, ptr %l54
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l6, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l59
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/source:Span", ptr %l1
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t76, %"compiler/source:Span" %t77, ptr %t78)
  store ptr %t82, ptr %l63
  br label %bb18
bb18:
  store { i64, [4 x i64] } zeroinitializer, ptr %t83
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 0
  store i64 2, ptr %t84
  %t85 = load %"compiler/source:Span", ptr %l54
  %t86 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t85, 0
  %t87 = load i32, ptr %l59, !tbaa !23
  %t88 = insertvalue { %"compiler/source:Span", i32, ptr } %t86, i32 %t87, 1
  %t89 = load ptr, ptr %l63, !tbaa !29
  %t90 = insertvalue { %"compiler/source:Span", i32, ptr } %t88, ptr %t89, 2
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t83, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t90, ptr %t91
  %t92 = load { i64, [4 x i64] }, ptr %t83
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t92, ptr %t94
  store ptr %t94, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l6, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l70
  br label %bb19
bb19:
  %t106 = load i32, ptr %l70, !tbaa !23
  store i32 %t106, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l11, !tbaa !24
  br label %bb8
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l75
  br label %bb22
bb22:
  %t116 = load i32, ptr %l75, !tbaa !23
  store i32 %t116, ptr %l13, !tbaa !23
  %t117 = load i32, ptr %l13, !tbaa !23
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t121 = icmp eq i32 %t117, %t118
  br i1 %t121, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t123 = load i32, ptr %l6, !tbaa !23
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t127 = icmp eq i32 %t123, %t124
  br i1 %t127, label %bb25, label %bb26
bb24:
  br label %bb54
bb25:
  call void @__olang_scope_close(ptr %s5)
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l83, !tbaa !29
  %t131 = load i32, ptr %l6, !tbaa !23
  store i32 %t131, ptr %l84, !tbaa !23
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l86, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l1
  %t139 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t135, %"compiler/source:Span" %t136)
  store %"compiler/source:Span" %t139, ptr %l89
  br label %bb28
bb28:
  %t140 = load ptr, ptr %l83, !tbaa !29
  %t141 = load i32, ptr %l84, !tbaa !23
  %t142 = load i64, ptr %l86, !tbaa !24
  %t143 = load %"compiler/source:Span", ptr %l89
  %t144 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s5, ptr %s5, ptr %t140, i32 %t141, { i64, ptr } { i64 2, ptr @.d12 }, i64 %t142, %"compiler/source:Span" %t143, { i64, ptr } { i64 3, ptr @.d13 })
  store i64 %t144, ptr %l90
  br label %bb29
bb29:
  %t145 = load i64, ptr %l90, !tbaa !24
  store i64 %t145, ptr %l14, !tbaa !24
  %t146 = load i64, ptr %l14, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb30, label %bb31
bb30:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l93, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t151, ptr %l94
  %t152 = load i32, ptr %l6, !tbaa !23
  store i32 %t152, ptr %l95, !tbaa !23
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t153)
  store i32 %t155, ptr %l97
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = load ptr, ptr %l93, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l94
  %t161 = load i32, ptr %l95, !tbaa !23
  %t162 = load i32, ptr %l97, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i32 %t162, i64 %t158)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  store ptr null, ptr %rv
  br label %ret
bb34:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l101, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t166, ptr %l102
  %t167 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t167, ptr %l103
  %t168 = load i64, ptr %l14, !tbaa !24
  store i64 %t168, ptr %l104, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l1
  %t171 = load ptr, ptr %l5, !tbaa !29
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t169, %"compiler/source:Span" %t170, ptr %t171)
  store ptr %t175, ptr %l108
  br label %bb35
bb35:
  %t176 = load ptr, ptr %l108, !tbaa !29
  store ptr %t176, ptr %l109, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t177, ptr %l110, !tbaa !27
  %t178 = icmp sge i64 0, 0
  br i1 %t178, label %bb36, label %bb37
bb36:
  %t180 = icmp sle i64 0, 1152921504606846975
  br i1 %t180, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_c4d3d83bf1f8452c_ec6a6fd400497ee8)
  unreachable
bb38:
  %t182 = mul i64 0, 8
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 0, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l113, !tbaa !27
  %t186 = icmp sge i64 0, 0
  br i1 %t186, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c4d3d83bf1f8452c_ec6a6fd400497ee8)
  unreachable
bb40:
  %t188 = icmp sle i64 0, 2305843009213693951
  br i1 %t188, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_c74df4524a4bbeb9_4f077fe640f42ed5)
  unreachable
bb42:
  %t190 = mul i64 0, 4
  %t191 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 0, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load ptr, ptr %l101, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l102
  %t196 = load %"compiler/source:Span", ptr %l103
  %t197 = load i64, ptr %l104, !tbaa !24
  %t198 = load ptr, ptr %l109, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t202 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %s5, ptr %t194, %"compiler/source:Span" %t195, %"compiler/source:Span" %t196, i64 %t197, ptr %t198, { i64, ptr } %t199, { i64, ptr } %t200, { i64, ptr } %t193)
  store ptr %t202, ptr %l117
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c74df4524a4bbeb9_4f077fe640f42ed5)
  unreachable
bb44:
  %t203 = load ptr, ptr %l117, !tbaa !29
  store ptr %t203, ptr %l15, !tbaa !29
  %t204 = load ptr, ptr %l15, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t204)
  store i32 %t207, ptr %l120
  br label %bb45
bb45:
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t209 = load i32, ptr %l120, !tbaa !23
  %t211 = icmp eq i32 %t209, %t208
  br i1 %t211, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s5)
  store ptr null, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l1
  %t219 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t214, i32 8, %"compiler/source:Span" %t215)
  store i32 %t219, ptr %l127
  br label %bb49
bb49:
  %t220 = load i32, ptr %l127, !tbaa !23
  store i32 %t220, ptr %l16, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 34
  store ptr %t223, ptr %l129, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t224)
  store ptr %t226, ptr %l131
  br label %bb50
bb50:
  %t227 = load ptr, ptr %l131, !tbaa !29
  %t229 = getelementptr %"compiler/check:frame", ptr %t227, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load i32, ptr %l16, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t234 = load ptr, ptr %l5, !tbaa !29
  %t235 = load i32, ptr %l6, !tbaa !23
  %t240 = call %"compiler/check:atRec" @compiler_2fcheck_3aatRec_2ector(ptr %v0, ptr %v0, i64 %t230, i64 %t233, ptr %t234, i32 %t235)
  store %"compiler/check:atRec" %t240, ptr %l138
  br label %bb51
bb51:
  %t241 = load ptr, ptr %l129, !tbaa !29
  %t242 = load %"compiler/check:atRec", ptr %l138
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ePush_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v0, ptr %t241, %"compiler/check:atRec" %t242)
  br label %bb52
bb52:
  %t243 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t243, ptr %l139
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t247 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t244)
  store i32 %t247, ptr %l142
  br label %bb53
bb53:
  %t248 = load ptr, ptr %l15, !tbaa !29
  %t249 = load i32, ptr %l16, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t250
  %t251 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 0
  store i64 6, ptr %t251
  %t252 = load %"compiler/source:Span", ptr %l139
  %t253 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t252, 0
  %t254 = load i32, ptr %l142, !tbaa !23
  %t255 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t253, i32 %t254, 1
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t255, ptr %t248, 2
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t257, i32 %t249, 3
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t250, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t259, ptr %t260
  %t261 = load { i64, [4 x i64] }, ptr %t250
  %t263 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t261, ptr %t263
  call void @__olang_scope_close(ptr %s5)
  store ptr %t263, ptr %rv
  br label %ret
bb54:
  %t265 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t269 = icmp ne i64 %t267, 1
  br i1 %t269, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l150, !tbaa !29
  %t272 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t272, ptr %l151, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr ptr, ptr %t274, i64 1
  %t276 = load ptr, ptr %t275, !tbaa !39
  %t278 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t276)
  store %"compiler/source:Span" %t278, ptr %l153
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i32, ptr %l6, !tbaa !23
  %t283 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t279, i32 %t280)
  store { i64, ptr } %t283, ptr %l156
  br label %bb58
bb58:
  %t284 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  %t292 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOneIndex(ptr %s9, ptr %s9, { i64, ptr } %t290)
  store %"compiler/msgs:Msg" %t292, ptr %l158
  br label %bb59
bb59:
  %t293 = load ptr, ptr %l150, !tbaa !29
  %t294 = load %"compiler/source:Span", ptr %l153
  %t295 = load %"compiler/msgs:Msg", ptr %l158
  %t296 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t293, %"compiler/source:Span" %t294, %"compiler/msgs:Msg" %t295)
  store i64 %t296, ptr %l159
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s9)
  store ptr null, ptr %rv
  br label %ret
bb61:
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l161, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  store ptr %t299, ptr %l162, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t300, ptr %l163, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr ptr, ptr %t302, i64 0
  %t304 = load ptr, ptr %t303, !tbaa !39
  store ptr %t304, ptr %l165, !tbaa !29
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t307, ptr %l167, !tbaa !27
  %t308 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr ptr, ptr %t309, i64 0
  %t311 = load ptr, ptr %t310, !tbaa !39
  %t314 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t306, ptr %t311)
  store i1 %t314, ptr %l169
  br label %bb62
bb62:
  %t315 = load i1, ptr %l169, !tbaa !21
  br i1 %t315, label %bb63, label %bb64
bb63:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t318 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t316)
  store i32 %t318, ptr %l172
  br label %bb65
bb64:
  %t319 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t319, ptr %l170, !tbaa !23
  br label %bb66
bb65:
  %t321 = load i32, ptr %l172, !tbaa !23
  store i32 %t321, ptr %l170, !tbaa !23
  br label %bb66
bb66:
  %t322 = load ptr, ptr %l162, !tbaa !29
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load i32, ptr %l170, !tbaa !23
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t322, ptr %t323, i32 %t324)
  store ptr %t325, ptr %l174
  br label %bb67
bb67:
  %t326 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t326, ptr %l175, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr ptr, ptr %t328, i64 0
  %t330 = load ptr, ptr %t329, !tbaa !39
  %t332 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t330)
  store %"compiler/source:Span" %t332, ptr %l177
  br label %bb68
bb68:
  %t333 = load ptr, ptr %l161, !tbaa !29
  %t334 = load ptr, ptr %l174, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l177
  %t336 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t333, ptr %t334, %"compiler/source:Span" %t335)
  store ptr %t336, ptr %l178
  br label %bb69
bb69:
  %t337 = load ptr, ptr %l178, !tbaa !29
  store ptr %t337, ptr %l17, !tbaa !29
  %t338 = load ptr, ptr %l0, !tbaa !29
  store ptr %t338, ptr %l179, !tbaa !29
  %t339 = load ptr, ptr %l17, !tbaa !29
  %t342 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t339)
  store i32 %t342, ptr %l182
  br label %bb70
bb70:
  %t343 = load ptr, ptr %l179, !tbaa !29
  %t344 = load i32, ptr %l182, !tbaa !23
  %t345 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t345, ptr %l183
  br label %bb71
bb71:
  %t346 = load i1, ptr %l183, !tbaa !21
  %t347 = xor i1 %t346, true
  br i1 %t347, label %bb72, label %bb73
bb72:
  %t349 = load ptr, ptr %l17, !tbaa !29
  %t352 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t349)
  store i32 %t352, ptr %l188
  br label %bb74
bb73:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb75
bb74:
  %t353 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t354 = load i32, ptr %l188, !tbaa !23
  %t356 = icmp ne i32 %t354, %t353
  store i1 %t356, ptr %l185, !tbaa !21
  br label %bb75
bb75:
  %t358 = load i1, ptr %l185, !tbaa !21
  br i1 %t358, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l191, !tbaa !29
  %t360 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t360, ptr %l192, !tbaa !27
  %t361 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr ptr, ptr %t362, i64 0
  %t364 = load ptr, ptr %t363, !tbaa !39
  %t366 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t364)
  store %"compiler/source:Span" %t366, ptr %l194
  br label %bb78
bb77:
  br label %bb83
bb78:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l195, !tbaa !29
  %t368 = load ptr, ptr %l17, !tbaa !29
  %t371 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t368)
  store i32 %t371, ptr %l198
  br label %bb79
bb79:
  %t372 = load ptr, ptr %l195, !tbaa !29
  %t373 = load i32, ptr %l198, !tbaa !23
  %t374 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t372, i32 %t373)
  store { i64, ptr } %t374, ptr %l199
  br label %bb80
bb80:
  %t375 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t377 = extractvalue { i64, ptr } %t375, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t383 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexNotInt(ptr %s10, ptr %s10, { i64, ptr } %t381)
  store %"compiler/msgs:Msg" %t383, ptr %l201
  br label %bb81
bb81:
  %t384 = load ptr, ptr %l191, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l194
  %t386 = load %"compiler/msgs:Msg", ptr %l201
  %t387 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t384, %"compiler/source:Span" %t385, %"compiler/msgs:Msg" %t386)
  store i64 %t387, ptr %l202
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/check:Checker", ptr %t388, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !29
  %t393 = getelementptr %"compiler/generic:Program", ptr %t391, i32 0, i32 2
  %t394 = load i32, ptr %l13, !tbaa !23
  %t397 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t393, i32 %t394)
  store i32 %t397, ptr %l207
  br label %bb84
bb84:
  %t398 = load i32, ptr %l207, !tbaa !23
  store i32 %t398, ptr %l18, !tbaa !23
  %t399 = load i32, ptr %l4
  %t401 = trunc i64 0 to i32
  %t402 = icmp eq i32 %t399, %t401
  br i1 %t402, label %bb85, label %bb86
bb85:
  %t404 = load i32, ptr %l18, !tbaa !23
  %t406 = icmp ne i32 %t404, 0
  store i1 %t406, ptr %l210, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb87
bb87:
  %t408 = load i1, ptr %l210, !tbaa !21
  br i1 %t408, label %bb88, label %bb89
bb88:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/check:Checker", ptr %t409, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = getelementptr %"compiler/generic:Program", ptr %t412, i32 0, i32 2
  %t415 = load i32, ptr %l18, !tbaa !23
  %t418 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t414, i32 %t415)
  store i32 %t418, ptr %l218
  br label %bb90
bb89:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb91
bb90:
  %t419 = load i32, ptr %l218
  %t421 = trunc i64 26 to i32
  %t422 = icmp eq i32 %t419, %t421
  store i1 %t422, ptr %l213, !tbaa !21
  br label %bb91
bb91:
  %t424 = load i1, ptr %l213, !tbaa !21
  br i1 %t424, label %bb92, label %bb93
bb92:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t426, ptr %l222, !tbaa !27
  %t427 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr ptr, ptr %t428, i64 0
  %t430 = load ptr, ptr %t429, !tbaa !39
  %t434 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t425, ptr %t430)
  store %"compiler/check:litv" %t434, ptr %l225
  br label %bb94
bb93:
  br label %bb114
bb94:
  %t435 = load %"compiler/check:litv", ptr %l225
  store %"compiler/check:litv" %t435, ptr %l19
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/check:Checker", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = getelementptr %"compiler/generic:Program", ptr %t439, i32 0, i32 2
  %t442 = load i32, ptr %l18, !tbaa !23
  %t445 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t441, i32 %t442)
  store i64 %t445, ptr %l230
  br label %bb95
bb95:
  %t446 = load i64, ptr %l230, !tbaa !24
  store i64 %t446, ptr %l20, !tbaa !24
  %t447 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 0
  %t448 = load i1, ptr %t447, !tbaa !21
  br i1 %t448, label %bb96, label %bb97
bb96:
  %t450 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 1
  %t451 = load i1, ptr %t450, !tbaa !21
  %t453 = xor i1 %t451, true
  store i1 %t453, ptr %l232, !tbaa !21
  br label %bb98
bb97:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb98
bb98:
  %t455 = load i1, ptr %l232, !tbaa !21
  br i1 %t455, label %bb99, label %bb100
bb99:
  %t456 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 2
  %t457 = load i1, ptr %t456, !tbaa !21
  %t459 = xor i1 %t457, true
  store i1 %t459, ptr %l235, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb101
bb101:
  %t461 = load i1, ptr %l235, !tbaa !21
  br i1 %t461, label %bb102, label %bb103
bb102:
  %t462 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 3
  %t463 = load i64, ptr %t462, !tbaa !24
  %t465 = icmp slt i64 %t463, 0
  br i1 %t465, label %bb104, label %bb105
bb103:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb107
bb104:
  store i1 true, ptr %l241, !tbaa !21
  br label %bb106
bb105:
  %t467 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 3
  %t468 = load i64, ptr %t467, !tbaa !24
  %t469 = load i64, ptr %l20, !tbaa !24
  %t472 = icmp sge i64 %t468, %t469
  store i1 %t472, ptr %l241, !tbaa !21
  br label %bb106
bb106:
  %t474 = load i1, ptr %l241, !tbaa !21
  store i1 %t474, ptr %l238, !tbaa !21
  br label %bb107
bb107:
  %t475 = load i1, ptr %l238, !tbaa !21
  br i1 %t475, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s12
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l245, !tbaa !29
  %t477 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t477, ptr %l246, !tbaa !27
  %t478 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr ptr, ptr %t479, i64 0
  %t481 = load ptr, ptr %t480, !tbaa !39
  %t483 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t481)
  store %"compiler/source:Span" %t483, ptr %l248
  br label %bb110
bb109:
  br label %bb113
bb110:
  %t484 = getelementptr %"compiler/check:litv", ptr %l19, i32 0, i32 3
  %t485 = load i64, ptr %t484, !tbaa !24
  %t486 = load i64, ptr %l20, !tbaa !24
  %t489 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexOutOfRange(ptr %s12, i64 %t485, i64 %t486)
  store %"compiler/msgs:Msg" %t489, ptr %l251
  br label %bb111
bb111:
  %t490 = load ptr, ptr %l245, !tbaa !29
  %t491 = load %"compiler/source:Span", ptr %l248
  %t492 = load %"compiler/msgs:Msg", ptr %l251
  %t493 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t490, %"compiler/source:Span" %t491, %"compiler/msgs:Msg" %t492)
  store i64 %t493, ptr %l252
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t494 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t494, ptr %l253
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/generic:Program", ptr %t498, i32 0, i32 2
  %t501 = load i32, ptr %l13, !tbaa !23
  %t504 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t500, i32 %t501)
  store i32 %t504, ptr %l258
  br label %bb115
bb115:
  %t505 = load ptr, ptr %l5, !tbaa !29
  %t506 = load ptr, ptr %l17, !tbaa !29
  %t507 = load i32, ptr %l4
  %t511 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t505, ptr %t506, i32 %t507)
  store %"compiler/typed:Elem" %t511, ptr %l262
  br label %bb116
bb116:
  %t512 = load %"compiler/typed:Elem", ptr %l262
  %t513 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t512, ptr %t513
  store { i64, [4 x i64] } zeroinitializer, ptr %t514
  %t515 = getelementptr { i64, [4 x i64] }, ptr %t514, i32 0, i32 0
  store i64 4, ptr %t515
  %t516 = load %"compiler/source:Span", ptr %l253
  %t517 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t516, 0
  %t518 = load i32, ptr %l258, !tbaa !23
  %t519 = insertvalue { %"compiler/source:Span", i32, ptr } %t517, i32 %t518, 1
  %t521 = insertvalue { %"compiler/source:Span", i32, ptr } %t519, ptr %t513, 2
  %t522 = getelementptr { i64, [4 x i64] }, ptr %t514, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t521, ptr %t522
  %t523 = load { i64, [4 x i64] }, ptr %t514
  %t525 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t523, ptr %t525
  store ptr %t525, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l26 = alloca i32
  %l30 = alloca %"compiler/typed:Block"
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t60 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l3
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t22, %"compiler/source:Span" %t23, ptr %t24)
  store ptr %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l16, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t31)
  store %"compiler/source:Span" %t33, ptr %l19
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l17, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l19
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s2, ptr %t34, %"compiler/source:Span" %t35, { i64, ptr } { i64 20, ptr @.d14 })
  br label %bb9
bb9:
  store %"compiler/source:Span" %a1, ptr %l20
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l22
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/check:frame", ptr %t40, i32 0, i32 7
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = trunc i64 %t43 to i32
  store i32 %t45, ptr %l26, !tbaa !23
  %t47 = icmp sge i64 0, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = icmp sle i64 0, 1152921504606846975
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_823a266be2210958_13324b84b1c75d64)
  unreachable
bb13:
  %t51 = mul i64 0, 8
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 0, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t55 = load i32, ptr %l26, !tbaa !23
  %t57 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t55, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t57, ptr %l30
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_823a266be2210958_13324b84b1c75d64)
  unreachable
bb15:
  %t58 = load %"compiler/typed:Block", ptr %l30
  %t59 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t58, ptr %t59
  store { i64, [3 x i64] } zeroinitializer, ptr %t60
  %t61 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 0
  store i64 11, ptr %t61
  %t62 = load %"compiler/source:Span", ptr %l20
  %t63 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t62, 0
  %t65 = insertvalue { %"compiler/source:Span", ptr } %t63, ptr %t59, 1
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t60, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t65, ptr %t66
  %t67 = load { i64, [3 x i64] }, ptr %t60
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t67, ptr %t69
  call void @__olang_scope_close(ptr %s2)
  store ptr %t69, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l17 = alloca i64
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca { i64, [2 x i64] }
  %l25 = alloca i32
  %l29 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l43 = alloca i1
  %rv = alloca i64
  %t40 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 17
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11
ok.11:
  store i64 %t8, ptr %l9
  br label %bb1
bb1:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l5, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l17
  br label %bb8
bb8:
  %t28 = load i64, ptr %l17, !tbaa !24
  store i64 %t28, ptr %l3, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t32, i64 %t33)
  store i32 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 0
  store i64 0, ptr %t41
  %t43 = insertvalue { i64 } undef, i64 %t39, 0
  %t44 = getelementptr { i64, [2 x i64] }, ptr %t40, i32 0, i32 1
  store { i64 } %t43, ptr %t44
  %t45 = load { i64, [2 x i64] }, ptr %t40
  store { i64, [2 x i64] } %t45, ptr %l24
  %t46 = load i32, ptr %l4, !tbaa !23
  store i32 %t46, ptr %l25, !tbaa !23
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l29
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t58, i64 %t59)
  store ptr %t62, ptr %l33
  br label %bb11
bb11:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Func", ptr %t63, i32 0, i32 0
  %t66 = load %"compiler/source:Span", ptr %t65
  %t67 = load ptr, ptr %l22, !tbaa !29
  %t68 = load { i64, [2 x i64] }, ptr %l24
  %t69 = load i32, ptr %l25, !tbaa !23
  %t70 = load i64, ptr %l29, !tbaa !24
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t67, { i64, [2 x i64] } %t68, i32 %t69, i64 %t70, %"compiler/source:Span" %t66)
  store i64 %t72, ptr %l36
  br label %bb12
bb12:
  %t73 = load i64, ptr %l36, !tbaa !24
  store i64 %t73, ptr %l2, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 17
  %t77 = load i64, ptr %l1, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  br label %bb13
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 47
  %t91 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t90, i64 %t91, i1 true)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca ptr
  %l49 = alloca i32
  %l51 = alloca i32
  %l55 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l65 = alloca %"compiler/msgs:Msg"
  %l66 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca i1
  %l83 = alloca ptr
  %l89 = alloca ptr
  %l93 = alloca %"compiler/names:Ref"
  %l98 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i64
  %l112 = alloca i1
  %l114 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %l129 = alloca %"compiler/msgs:Msg"
  %l130 = alloca i64
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca { i64, ptr }
  %l154 = alloca %"compiler/msgs:Msg"
  %l155 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l18
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l18, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l22
  br label %bb2
bb2:
  %t18 = load i64, ptr %l22, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t19, i64 -1, i64 %t20, i32 %t21, i32 0)
  store ptr %t25, ptr %l26
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 5
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Func", ptr %t35, i32 0, i32 5
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  store i64 %t42, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  br label %bb73
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb8:
  br label %bb9
bb9:
  %t52 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t52, ptr %l39, !tbaa !27
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 %t53
  %t58 = load ptr, ptr %t57, !tbaa !39
  store ptr %t58, ptr %l7, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load ptr, ptr %l7, !tbaa !29
  %t64 = getelementptr %"compiler/ast:TypeParam", ptr %t62, i32 0, i32 1
  %t65 = load i32, ptr %t64, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %t60, i64 %t61, i32 %t65)
  store i1 %t69, ptr %l46
  br label %bb10
bb10:
  %t70 = load i1, ptr %l46, !tbaa !21
  br i1 %t70, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l47, !tbaa !29
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t74 = getelementptr %"compiler/ast:TypeParam", ptr %t72, i32 0, i32 0
  %t75 = getelementptr %"compiler/source:Span", ptr %t74, i32 0, i32 0
  %t76 = load i32, ptr %t75, !tbaa !23
  store i32 %t76, ptr %l49, !tbaa !23
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TypeParam", ptr %t77, i32 0, i32 0
  %t80 = getelementptr %"compiler/source:Span", ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  store i32 %t81, ptr %l51, !tbaa !23
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l7, !tbaa !29
  %t85 = getelementptr %"compiler/ast:TypeParam", ptr %t83, i32 0, i32 1
  %t86 = load i32, ptr %t85, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t82, i32 %t86)
  store { i64, ptr } %t89, ptr %l55
  br label %bb13
bb12:
  br label %bb18
bb13:
  %t90 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t93 = trunc i64 %t91 to i32
  %t94 = load i32, ptr %l51, !tbaa !23
  %t96 = add i32 %t94, %t93
  %t97 = load i32, ptr %l49, !tbaa !23
  %t99 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t97, i32 %t96)
  store %"compiler/source:Span" %t99, ptr %l59
  br label %bb14
bb14:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = getelementptr %"compiler/ast:TypeParam", ptr %t101, i32 0, i32 1
  %t104 = load i32, ptr %t103, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t100, i32 %t104)
  store { i64, ptr } %t107, ptr %l63
  br label %bb15
bb15:
  %t108 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %s4, ptr %s4, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l65
  br label %bb16
bb16:
  %t117 = load ptr, ptr %l47, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l59
  %t119 = load %"compiler/msgs:Msg", ptr %l65
  %t120 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t117, %"compiler/source:Span" %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l66
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t123 = getelementptr %"compiler/ast:TypeParam", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  store ptr %t124, ptr %l8, !tbaa !29
  %t126 = load ptr, ptr %l8, !tbaa !29
  store ptr %t126, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t127 = load ptr, ptr %l69, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb19, label %bb20
bb19:
  %t130 = load ptr, ptr %l69, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 0
  store i1 %t133, ptr %l70, !tbaa !21
  br label %bb20
bb20:
  %t134 = load i1, ptr %l70, !tbaa !21
  br i1 %t134, label %bb21, label %bb22
bb21:
  %t135 = load ptr, ptr %l8, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t137, i32 0, i32 0
  %t139 = load %"compiler/source:Span", ptr %t138
  store %"compiler/source:Span" %t139, ptr %l9
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t143, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144
  store { i64, ptr } %t145, ptr %l10, !tbaa !27
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t147 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t151 = icmp eq i64 %t149, 1
  br i1 %t151, label %bb24, label %bb25
bb24:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/generic:Program", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l83, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 0
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/load:Loader", ptr %t166, i32 0, i32 5
  %t169 = load i64, ptr %l3, !tbaa !24
  %t172 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t168, i64 %t169)
  store ptr %t172, ptr %l89
  br label %bb26
bb25:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb28
bb26:
  %t173 = load ptr, ptr %l89, !tbaa !29
  %t175 = getelementptr %"compiler/load:Module", ptr %t173, i32 0, i32 4
  %t176 = load i64, ptr %t175, !tbaa !24
  %t177 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t178 = load i32, ptr %t177, !tbaa !23
  %t179 = load ptr, ptr %l83, !tbaa !29
  %t182 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t179, i64 %t176, i32 %t178)
  store %"compiler/names:Ref" %t182, ptr %l93
  br label %bb27
bb27:
  %t183 = getelementptr %"compiler/names:Ref", ptr %l93, i32 0, i32 0
  %t184 = load i32, ptr %t183
  %t186 = trunc i64 0 to i32
  %t187 = icmp eq i32 %t184, %t186
  store i1 %t187, ptr %l80, !tbaa !21
  br label %bb28
bb28:
  %t189 = load i1, ptr %l80, !tbaa !21
  br i1 %t189, label %bb29, label %bb30
bb29:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l9
  %t192 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t192, ptr %l98, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr i32, ptr %t194, i64 0
  %t196 = load i32, ptr %t195, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i32 %t196)
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t200 = load ptr, ptr %l7, !tbaa !29
  %t202 = getelementptr %"compiler/ast:TypeParam", ptr %t200, i32 0, i32 2
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb35, label %bb36
bb35:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l105, !tbaa !29
  %t210 = load i64, ptr %l3, !tbaa !24
  store i64 %t210, ptr %l106, !tbaa !24
  %t211 = load ptr, ptr %l7, !tbaa !29
  %t213 = getelementptr %"compiler/ast:TypeParam", ptr %t211, i32 0, i32 2
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb41
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5ec57267b0627cae_caaef3a5d88fe622)
  unreachable
bb38:
  br label %bb39
bb39:
  %t218 = load ptr, ptr %l7, !tbaa !29
  %t220 = getelementptr %"compiler/ast:TypeParam", ptr %t218, i32 0, i32 2
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load ptr, ptr %l105, !tbaa !29
  %t223 = load i64, ptr %l106, !tbaa !24
  %t225 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v0, ptr %t222, i64 %t223, ptr %t221)
  store i1 %t225, ptr %l112
  br label %bb40
bb40:
  %t226 = load i1, ptr %l112, !tbaa !21
  %t227 = xor i1 %t226, true
  store i1 %t227, ptr %l104, !tbaa !21
  br label %bb41
bb41:
  %t229 = load i1, ptr %l104, !tbaa !21
  br i1 %t229, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s8
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l114, !tbaa !29
  %t231 = load ptr, ptr %l7, !tbaa !29
  %t233 = getelementptr %"compiler/ast:TypeParam", ptr %t231, i32 0, i32 2
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  br i1 %t236, label %bb44, label %bb45
bb43:
  br label %bb55
bb44:
  call void @__olang_check_failed(ptr @olang_loc_5ec57267b0627cae_caaef3a5d88fe622)
  unreachable
bb45:
  br label %bb46
bb46:
  %t238 = load ptr, ptr %l7, !tbaa !29
  %t240 = getelementptr %"compiler/ast:TypeParam", ptr %t238, i32 0, i32 2
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t241)
  store %"compiler/source:Span" %t243, ptr %l120
  br label %bb47
bb47:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l121, !tbaa !29
  %t245 = load ptr, ptr %l7, !tbaa !29
  %t247 = getelementptr %"compiler/ast:TypeParam", ptr %t245, i32 0, i32 2
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = icmp eq ptr %t248, null
  br i1 %t250, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5ec57267b0627cae_caaef3a5d88fe622)
  unreachable
bb49:
  br label %bb50
bb50:
  %t252 = load ptr, ptr %l7, !tbaa !29
  %t254 = getelementptr %"compiler/ast:TypeParam", ptr %t252, i32 0, i32 2
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t255)
  store %"compiler/source:Span" %t257, ptr %l127
  br label %bb51
bb51:
  %t258 = load ptr, ptr %l121, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l127
  %t260 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t258, %"compiler/source:Span" %t259)
  store { i64, ptr } %t260, ptr %l128
  br label %bb52
bb52:
  %t261 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t262 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %s8, { i64, ptr } %t261)
  store %"compiler/msgs:Msg" %t262, ptr %l129
  br label %bb53
bb53:
  %t263 = load ptr, ptr %l114, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l120
  %t265 = load %"compiler/msgs:Msg", ptr %l129
  %t266 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t263, %"compiler/source:Span" %t264, %"compiler/msgs:Msg" %t265)
  store i64 %t266, ptr %l130
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb55:
  %t267 = load ptr, ptr %l7, !tbaa !29
  %t269 = getelementptr %"compiler/ast:TypeParam", ptr %t267, i32 0, i32 3
  %t270 = load { i64, ptr }, ptr %t269, !tbaa !27
  store { i64, ptr } %t270, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t272, 0
  store i64 %t274, ptr %l13, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t276 = load i64, ptr %l12, !tbaa !24
  %t277 = load i64, ptr %l13, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb70
bb58:
  br label %bb59
bb59:
  %t284 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t284, ptr %l139, !tbaa !27
  %t285 = load i64, ptr %l12, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr ptr, ptr %t288, i64 %t285
  %t290 = load ptr, ptr %t289, !tbaa !39
  store ptr %t290, ptr %l14, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load i64, ptr %l3, !tbaa !24
  %t294 = load ptr, ptr %l14, !tbaa !29
  %t298 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v0, ptr %t292, i64 %t293, ptr %t294)
  store i1 %t298, ptr %l145
  br label %bb60
bb60:
  %t299 = load i1, ptr %l145, !tbaa !21
  %t300 = xor i1 %t299, true
  br i1 %t300, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s11
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l147, !tbaa !29
  %t303 = load ptr, ptr %l14, !tbaa !29
  %t305 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t303)
  store %"compiler/source:Span" %t305, ptr %l149
  br label %bb63
bb62:
  br label %bb68
bb63:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l150, !tbaa !29
  %t307 = load ptr, ptr %l14, !tbaa !29
  %t309 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t307)
  store %"compiler/source:Span" %t309, ptr %l152
  br label %bb64
bb64:
  %t310 = load ptr, ptr %l150, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l152
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t310, %"compiler/source:Span" %t311)
  store { i64, ptr } %t312, ptr %l153
  br label %bb65
bb65:
  %t313 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t314 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %s11, { i64, ptr } %t313)
  store %"compiler/msgs:Msg" %t314, ptr %l154
  br label %bb66
bb66:
  %t315 = load ptr, ptr %l147, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l149
  %t317 = load %"compiler/msgs:Msg", ptr %l154
  %t318 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t315, %"compiler/source:Span" %t316, %"compiler/msgs:Msg" %t317)
  store i64 %t318, ptr %l155
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb69:
  %t319 = load i64, ptr %l12, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l12, !tbaa !24
  br label %bb56
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  %t323 = load i64, ptr %l5, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l5, !tbaa !24
  br label %bb6
bb72:
  br label %bb73
bb73:
  %t327 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t327)
  br label %bb74
bb74:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load i32, ptr %l3
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i64 %t31, ptr %l16
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t32)
  store %"compiler/check:litv" %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t34, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2bda502508e1b1d_a3083ba563ab0481)
  unreachable
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/check:litv" %t40, ptr %l21
  br label %bb17
bb17:
  %t41 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efor3(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca { i64, i64, i64 }
  %l37 = alloca ptr
  %t66 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 1, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l15
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l15
  store { i64, i64, i64 } %t13, ptr %l4
  %t14 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:For3", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb3
bb3:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr %"compiler/ast:For3", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/ast:For3", ptr %t37, i32 0, i32 3
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t43 = getelementptr %"compiler/ast:For3", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t31, %"compiler/source:Span" %t32, ptr %t36, { i64, ptr } %t40, ptr %t44)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t51, i64 %t52, i64 %t53, i64 %t54, i64 %t55)
  store ptr %t61, ptr %l37
  br label %bb5
bb5:
  %t62 = load ptr, ptr %l37, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t66
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 0
  store i64 11, ptr %t67
  %t69 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t64, 0
  %t71 = insertvalue { %"compiler/source:Span", ptr } %t69, ptr %t62, 1
  %t72 = getelementptr { i64, [3 x i64] }, ptr %t66, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t71, ptr %t72
  %t73 = load { i64, [3 x i64] }, ptr %t66
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t73, ptr %t75
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t63, ptr %t75)
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, i64 }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca { i64, i64 }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l41 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i32
  %l79 = alloca ptr
  %l90 = alloca %"compiler/source:Span"
  %l91 = alloca ptr
  %l97 = alloca ptr
  %l108 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca ptr
  %l125 = alloca i32
  %l129 = alloca %"compiler/typed:Block"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca i1
  %l153 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i1
  %l179 = alloca i1
  %l185 = alloca i1
  %l194 = alloca i1
  %l195 = alloca ptr
  %l203 = alloca i1
  %l204 = alloca ptr
  %l206 = alloca ptr
  %l208 = alloca i64
  %l214 = alloca i64
  %l218 = alloca ptr
  %l219 = alloca i64
  %l221 = alloca ptr
  %l223 = alloca i64
  %l229 = alloca %"compiler/source:Span"
  %l230 = alloca i32
  %l231 = alloca ptr
  %l233 = alloca ptr
  %l235 = alloca i64
  %l238 = alloca { i64, ptr }
  %l239 = alloca %"compiler/check:Ask"
  %l243 = alloca i1
  %l255 = alloca i1
  %l256 = alloca ptr
  %l264 = alloca i1
  %l268 = alloca %"compiler/source:Span"
  %l270 = alloca ptr
  %l274 = alloca i32
  %l278 = alloca %"compiler/typed:Block"
  %l282 = alloca ptr
  %l283 = alloca %"compiler/source:Span"
  %l289 = alloca ptr
  %l298 = alloca i1
  %l303 = alloca i1
  %l304 = alloca ptr
  %l310 = alloca i1
  %l311 = alloca %"compiler/source:Span"
  %l312 = alloca ptr
  %l318 = alloca ptr
  %l329 = alloca i1
  %l330 = alloca ptr
  %l338 = alloca i1
  %l339 = alloca i1
  %l340 = alloca ptr
  %l348 = alloca i1
  %l349 = alloca i1
  %l353 = alloca i1
  %l356 = alloca %"compiler/source:Span"
  %l358 = alloca ptr
  %l362 = alloca i32
  %l366 = alloca %"compiler/typed:Block"
  %l370 = alloca ptr
  %l376 = alloca i64
  %l379 = alloca %"compiler/source:Span"
  %l380 = alloca ptr
  %l386 = alloca ptr
  %l394 = alloca %"compiler/source:Span"
  %l396 = alloca ptr
  %l400 = alloca i32
  %l404 = alloca %"compiler/typed:Block"
  %l410 = alloca ptr
  %l411 = alloca i1
  %l421 = alloca %"compiler/source:Span"
  %l422 = alloca ptr
  %l428 = alloca ptr
  %l434 = alloca ptr
  %l435 = alloca ptr
  %l436 = alloca %"compiler/source:Span"
  %l442 = alloca ptr
  %l447 = alloca ptr
  %l453 = alloca ptr
  %l455 = alloca i1
  %l458 = alloca i32
  %l461 = alloca ptr
  %l462 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l469 = alloca %"compiler/msgs:Msg"
  %l470 = alloca i64
  %l471 = alloca ptr
  %l478 = alloca { i64, i64 }
  %l481 = alloca ptr
  %l491 = alloca ptr
  %l498 = alloca ptr
  %l499 = alloca i1
  %l509 = alloca ptr
  %l516 = alloca { i64, i64 }
  %l519 = alloca ptr
  %l529 = alloca ptr
  %l533 = alloca i64
  %l537 = alloca { i64, i64, i64 }
  %l541 = alloca ptr
  %l548 = alloca ptr
  %l555 = alloca ptr
  %l559 = alloca ptr
  %l565 = alloca ptr
  %l567 = alloca ptr
  %l573 = alloca %"compiler/source:Span"
  %l574 = alloca %"compiler/source:Span"
  %l578 = alloca %"compiler/typed:If"
  %s0 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca ptr
  %t24 = alloca { i64, [3 x i64] }, align 8
  %t154 = alloca { i64, [3 x i64] }, align 8
  %t232 = alloca { i64, [3 x i64] }, align 8
  %t559 = alloca { i64, [3 x i64] }, align 8
  %t649 = alloca { i64, [3 x i64] }, align 8
  %t758 = alloca { i64, [3 x i64] }, align 8
  %t805 = alloca { i64, [3 x i64] }, align 8
  %t851 = alloca { i64, [3 x i64] }, align 8
  %t911 = alloca { i64, [3 x i64] }, align 8
  %t1247 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t8, ptr %l34
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l35, !tbaa !29
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_a622476533ee0612_1aeb16e8ac1e1db6)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t21 = load ptr, ptr %l35, !tbaa !29
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t21, ptr %t20)
  store ptr %t23, ptr %l41
  br label %bb6
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t24
  %t25 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 0
  store i64 11, ptr %t25
  %t26 = load %"compiler/source:Span", ptr %l34
  %t27 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t26, 0
  %t28 = load ptr, ptr %l41, !tbaa !29
  %t29 = insertvalue { %"compiler/source:Span", ptr } %t27, ptr %t28, 1
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t24
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @__olang_scope_close(ptr %s0)
  store ptr %t33, ptr %rv
  br label %ret
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/load:Loader", ptr %t41, i32 0, i32 4
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l3, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t46)
  store ptr %t48, ptr %l49
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t49, i32 0, i32 2
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l51, !tbaa !24
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:If", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = icmp eq ptr %t56, null
  br i1 %t58, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_319f2f7a6670a39_e028e643a90bcd1d)
  unreachable
bb10:
  br label %bb11
bb11:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:If", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l57
  br label %bb12
bb12:
  %t66 = getelementptr %"compiler/source:Span", ptr %l57, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t70 = load i64, ptr %l51, !tbaa !24
  %t72 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t70, i64 %t69)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, ptr %l60
  br label %bb13
bb13:
  %t73 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l60
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t73, ptr %l4
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 73
  %t77 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t80 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t76, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t77)
  store i1 %t80, ptr %l64
  br label %bb14
bb14:
  %t81 = load i1, ptr %l64, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 73
  %t85 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t88 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %t84, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t85)
  %t89 = extractvalue { i32, i1 } %t88, 1
  %t90 = extractvalue { i32, i1 } %t88, 0
  store i32 %t90, ptr %l70
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb18, label %ok.92
ok.92:
  store i1 %t89, ptr %l69
  br label %bb17
bb16:
  br label %bb82
bb17:
  %t93 = load i1, ptr %l69, !tbaa !21
  store i1 %t93, ptr %l65, !tbaa !21
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l65, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l65, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:If", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb22:
  br label %bb38
bb23:
  call void @__olang_check_failed(ptr @olang_loc_856dc584101bc984_5c32a185ff63a848)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/ast:If", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t108 = getelementptr %"compiler/ast:Branch", ptr %t105, i32 0, i32 2
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = icmp sge i64 %t109, 0
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = load ptr, ptr %l3, !tbaa !29
  store ptr %t113, ptr %l79, !tbaa !29
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:If", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb28, label %bb29
bb27:
  br label %bb32
bb28:
  call void @__olang_check_failed(ptr @olang_loc_856dc584101bc984_5c32a185ff63a848)
  unreachable
bb29:
  br label %bb30
bb30:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr %"compiler/ast:If", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t127 = getelementptr %"compiler/ast:Branch", ptr %t124, i32 0, i32 2
  %t128 = load i64, ptr %t127, !tbaa !24
  %t129 = load ptr, ptr %l79, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t129, i64 %t128)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t134 = getelementptr %"compiler/ast:If", ptr %t132, i32 0, i32 2
  %t135 = load ptr, ptr %t134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %t131, ptr %t135)
  br label %bb33
bb33:
  %t138 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t138, ptr %l90
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l91, !tbaa !29
  %t140 = load ptr, ptr %l2, !tbaa !29
  %t142 = getelementptr %"compiler/ast:If", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = icmp eq ptr %t143, null
  br i1 %t145, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_6de95c363ba43753_b985f35754c3cc67)
  unreachable
bb35:
  br label %bb36
bb36:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/ast:If", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l91, !tbaa !29
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t151, ptr %t150)
  store ptr %t153, ptr %l97
  br label %bb37
bb37:
  store { i64, [3 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 0
  store i64 11, ptr %t155
  %t156 = load %"compiler/source:Span", ptr %l90
  %t157 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t156, 0
  %t158 = load ptr, ptr %l97, !tbaa !29
  %t159 = insertvalue { %"compiler/source:Span", ptr } %t157, ptr %t158, 1
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t159, ptr %t160
  %t161 = load { i64, [3 x i64] }, ptr %t154
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t161, ptr %t163
  call void @__olang_scope_close(ptr %s0)
  store ptr %t163, ptr %rv
  br label %ret
bb38:
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = getelementptr %"compiler/ast:If", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = icmp eq ptr %t168, null
  br i1 %t170, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_62c8ad0b34d7b82e_8c827e0bb8ee6f7a)
  unreachable
bb40:
  br label %bb41
bb41:
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = getelementptr %"compiler/ast:If", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = getelementptr %"compiler/ast:Branch", ptr %t175, i32 0, i32 2
  %t179 = load i64, ptr %t178, !tbaa !24
  %t181 = icmp sge i64 %t179, 0
  br i1 %t181, label %bb42, label %bb43
bb42:
  %t183 = load ptr, ptr %l3, !tbaa !29
  store ptr %t183, ptr %l108, !tbaa !29
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = getelementptr %"compiler/ast:If", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb44, label %bb45
bb43:
  br label %bb48
bb44:
  call void @__olang_check_failed(ptr @olang_loc_62c8ad0b34d7b82e_8c827e0bb8ee6f7a)
  unreachable
bb45:
  br label %bb46
bb46:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr %"compiler/ast:If", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Branch", ptr %t194, i32 0, i32 2
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = load ptr, ptr %l108, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %t199, i64 %t198)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr %"compiler/ast:If", ptr %t201, i32 0, i32 2
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t206 = icmp eq ptr %t204, null
  br i1 %t206, label %bb49, label %bb50
bb49:
  %t208 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t208, ptr %l119
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t209)
  store ptr %t211, ptr %l121
  br label %bb51
bb50:
  br label %bb57
bb51:
  %t212 = load ptr, ptr %l121, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t212, i32 0, i32 7
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = trunc i64 %t215 to i32
  store i32 %t217, ptr %l125, !tbaa !23
  %t219 = icmp sge i64 0, 0
  br i1 %t219, label %bb52, label %bb53
bb52:
  %t221 = icmp sle i64 0, 1152921504606846975
  br i1 %t221, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_3219af0a7bb6371b_608971ab22223c2f)
  unreachable
bb54:
  %t223 = mul i64 0, 8
  %t224 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t223)
  %t225 = insertvalue { i64, ptr } undef, i64 0, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t227 = load i32, ptr %l125, !tbaa !23
  %t229 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t227, { i64, ptr } %t226)
  store %"compiler/typed:Block" %t229, ptr %l129
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_3219af0a7bb6371b_608971ab22223c2f)
  unreachable
bb56:
  %t230 = load %"compiler/typed:Block", ptr %l129
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t230, ptr %t231
  store { i64, [3 x i64] } zeroinitializer, ptr %t232
  %t233 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 0
  store i64 11, ptr %t233
  %t234 = load %"compiler/source:Span", ptr %l119
  %t235 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t234, 0
  %t237 = insertvalue { %"compiler/source:Span", ptr } %t235, ptr %t231, 1
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t232, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t237, ptr %t238
  %t239 = load { i64, [3 x i64] }, ptr %t232
  %t241 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t239, ptr %t241
  call void @__olang_scope_close(ptr %s0)
  store ptr %t241, ptr %rv
  br label %ret
bb57:
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t245 = getelementptr %"compiler/ast:If", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  store ptr %t246, ptr %l5, !tbaa !29
  %t248 = load ptr, ptr %l5, !tbaa !29
  store ptr %t248, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t249 = load ptr, ptr %l135, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb58, label %bb59
bb58:
  %t252 = load ptr, ptr %l135, !tbaa !29
  %t253 = load i64, ptr %t252
  %t255 = icmp eq i64 %t253, 5
  store i1 %t255, ptr %l136, !tbaa !21
  br label %bb59
bb59:
  %t256 = load i1, ptr %l136, !tbaa !21
  br i1 %t256, label %bb60, label %bb61
bb60:
  %t257 = load ptr, ptr %l5, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr }, ptr %t259, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l6, !tbaa !29
  br label %bb62
bb61:
  br label %bb76
bb62:
  %t263 = load ptr, ptr %l6, !tbaa !29
  %t265 = getelementptr %"compiler/ast:If", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t268 = icmp eq ptr %t266, null
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t270 = load ptr, ptr %l6, !tbaa !29
  %t272 = getelementptr %"compiler/ast:If", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t275 = icmp eq ptr %t273, null
  br i1 %t275, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb68
bb65:
  call void @__olang_check_failed(ptr @olang_loc_9bced391e891fdc0_daecba1c3e9b04cc)
  unreachable
bb66:
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l6, !tbaa !29
  %t279 = getelementptr %"compiler/ast:If", ptr %t277, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t283 = getelementptr %"compiler/ast:Branch", ptr %t280, i32 0, i32 2
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = icmp sge i64 %t284, 0
  store i1 %t286, ptr %l144, !tbaa !21
  br label %bb68
bb68:
  %t288 = load i1, ptr %l144, !tbaa !21
  br i1 %t288, label %bb69, label %bb70
bb69:
  %t289 = load ptr, ptr %l3, !tbaa !29
  store ptr %t289, ptr %l153, !tbaa !29
  %t290 = load ptr, ptr %l6, !tbaa !29
  %t292 = getelementptr %"compiler/ast:If", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = icmp eq ptr %t293, null
  br i1 %t295, label %bb71, label %bb72
bb70:
  br label %bb75
bb71:
  call void @__olang_check_failed(ptr @olang_loc_9bced391e891fdc0_daecba1c3e9b04cc)
  unreachable
bb72:
  br label %bb73
bb73:
  %t297 = load ptr, ptr %l6, !tbaa !29
  %t299 = getelementptr %"compiler/ast:If", ptr %t297, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t303 = getelementptr %"compiler/ast:Branch", ptr %t300, i32 0, i32 2
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = load ptr, ptr %l153, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t305, i64 %t304)
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  %t307 = load ptr, ptr %l0, !tbaa !29
  store ptr %t307, ptr %l161, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t308, ptr %l162
  %t309 = load ptr, ptr %l2, !tbaa !29
  %t311 = getelementptr %"compiler/ast:If", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t314 = icmp eq ptr %t312, null
  br i1 %t314, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_8beb387543c1195f_db09fb2ec562613b)
  unreachable
bb79:
  br label %bb80
bb80:
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = getelementptr %"compiler/ast:If", ptr %t316, i32 0, i32 2
  %t319 = load ptr, ptr %t318, !tbaa !29
  %t320 = load ptr, ptr %l161, !tbaa !29
  %t321 = load %"compiler/source:Span", ptr %l162
  %t323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t320, %"compiler/source:Span" %t321, ptr %t319)
  store ptr %t323, ptr %l168
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  %t324 = load ptr, ptr %l168, !tbaa !29
  store ptr %t324, ptr %rv
  br label %ret
bb82:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t325, i32 0, i32 89
  %t328 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t331 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t327, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t328)
  store i1 %t331, ptr %l172
  br label %bb83
bb83:
  %t332 = load i1, ptr %l172, !tbaa !21
  br i1 %t332, label %bb84, label %bb85
bb84:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb87
bb85:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/names:Resolver", ptr %t339, i32 0, i32 16
  %t342 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t345 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t341, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t342)
  store i1 %t345, ptr %l179
  br label %bb86
bb86:
  %t346 = load i1, ptr %l179, !tbaa !21
  store i1 %t346, ptr %l173, !tbaa !21
  br label %bb87
bb87:
  %t347 = load i1, ptr %l173, !tbaa !21
  store i1 %t347, ptr %l7, !tbaa !21
  %t348 = load i1, ptr %l7, !tbaa !21
  br i1 %t348, label %bb88, label %bb89
bb88:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t350, ptr %t351)
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb91
bb91:
  store i1 false, ptr %l8, !tbaa !21
  %t354 = load i1, ptr %l7, !tbaa !21
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb92, label %bb93
bb92:
  %t358 = load ptr, ptr %l2, !tbaa !29
  %t360 = getelementptr %"compiler/ast:If", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t363 = icmp eq ptr %t361, null
  br i1 %t363, label %bb94, label %bb95
bb93:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb97
bb94:
  call void @__olang_check_failed(ptr @olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be)
  unreachable
bb95:
  br label %bb96
bb96:
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = getelementptr %"compiler/ast:If", ptr %t365, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Branch", ptr %t368, i32 0, i32 2
  %t372 = load i64, ptr %t371, !tbaa !24
  %t374 = icmp sge i64 %t372, 0
  store i1 %t374, ptr %l185, !tbaa !21
  br label %bb97
bb97:
  %t376 = load i1, ptr %l185, !tbaa !21
  br i1 %t376, label %bb98, label %bb99
bb98:
  %t377 = load ptr, ptr %l3, !tbaa !29
  store ptr %t377, ptr %l195, !tbaa !29
  %t378 = load ptr, ptr %l2, !tbaa !29
  %t380 = getelementptr %"compiler/ast:If", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  br i1 %t383, label %bb100, label %bb101
bb99:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb104
bb100:
  call void @__olang_check_failed(ptr @olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be)
  unreachable
bb101:
  br label %bb102
bb102:
  %t385 = load ptr, ptr %l2, !tbaa !29
  %t387 = getelementptr %"compiler/ast:If", ptr %t385, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t391 = getelementptr %"compiler/ast:Branch", ptr %t388, i32 0, i32 2
  %t392 = load i64, ptr %t391, !tbaa !24
  %t393 = load ptr, ptr %l195, !tbaa !29
  %t395 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t393, i64 %t392)
  store i1 %t395, ptr %l203
  br label %bb103
bb103:
  %t396 = load i1, ptr %l203, !tbaa !21
  store i1 %t396, ptr %l194, !tbaa !21
  br label %bb104
bb104:
  %t397 = load i1, ptr %l194, !tbaa !21
  br i1 %t397, label %bb105, label %bb106
bb105:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l204, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t401 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t399)
  store ptr %t401, ptr %l206
  br label %bb107
bb106:
  br label %bb129
bb107:
  %t402 = load ptr, ptr %l206, !tbaa !29
  %t404 = getelementptr %"compiler/check:frame", ptr %t402, i32 0, i32 1
  %t405 = load i64, ptr %t404, !tbaa !24
  store i64 %t405, ptr %l208, !tbaa !24
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t408 = getelementptr %"compiler/ast:If", ptr %t406, i32 0, i32 0
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t411 = icmp eq ptr %t409, null
  br i1 %t411, label %bb108, label %bb109
bb108:
  call void @__olang_check_failed(ptr @olang_loc_c2ac910391966871_92a7715ab8ef6a65)
  unreachable
bb109:
  br label %bb110
bb110:
  %t413 = load ptr, ptr %l2, !tbaa !29
  %t415 = getelementptr %"compiler/ast:If", ptr %t413, i32 0, i32 0
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t417 = load ptr, ptr %l204, !tbaa !29
  %t418 = load i64, ptr %l208, !tbaa !24
  %t420 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %t417, i64 %t418, ptr %t416)
  store i64 %t420, ptr %l214
  br label %bb111
bb111:
  %t421 = load i64, ptr %l214, !tbaa !24
  store i64 %t421, ptr %l9, !tbaa !24
  %t422 = load i64, ptr %l9, !tbaa !24
  %t424 = icmp sge i64 %t422, 0
  br i1 %t424, label %bb112, label %bb113
bb112:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 74
  store ptr %t428, ptr %l218, !tbaa !29
  %t429 = load i64, ptr %l9, !tbaa !24
  store i64 %t429, ptr %l219, !tbaa !24
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t430)
  store ptr %t432, ptr %l221
  br label %bb114
bb113:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %l2, !tbaa !29
  %t436 = getelementptr %"compiler/ast:If", ptr %t434, i32 0, i32 0
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t440 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t433, ptr %t437)
  store i1 %t440, ptr %l243
  br label %bb123
bb114:
  %t441 = load ptr, ptr %l221, !tbaa !29
  %t443 = getelementptr %"compiler/check:frame", ptr %t441, i32 0, i32 2
  %t444 = load i64, ptr %t443, !tbaa !24
  store i64 %t444, ptr %l223, !tbaa !24
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t447 = getelementptr %"compiler/ast:If", ptr %t445, i32 0, i32 0
  %t448 = load ptr, ptr %t447, !tbaa !29
  %t450 = icmp eq ptr %t448, null
  br i1 %t450, label %bb115, label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_ccb3ed4617d06259_8e58603f3b63faf5)
  unreachable
bb116:
  br label %bb117
bb117:
  %t452 = load ptr, ptr %l2, !tbaa !29
  %t454 = getelementptr %"compiler/ast:If", ptr %t452, i32 0, i32 0
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t455)
  store %"compiler/source:Span" %t457, ptr %l229
  br label %bb118
bb118:
  %t458 = getelementptr %"compiler/source:Span", ptr %l229, i32 0, i32 0
  %t459 = load i32, ptr %t458, !tbaa !23
  store i32 %t459, ptr %l230, !tbaa !23
  %t460 = load ptr, ptr %l2, !tbaa !29
  store ptr %t460, ptr %l231, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t461)
  store ptr %t463, ptr %l233
  br label %bb119
bb119:
  %t464 = load ptr, ptr %l233, !tbaa !29
  %t466 = getelementptr %"compiler/check:frame", ptr %t464, i32 0, i32 0
  %t467 = load i64, ptr %t466, !tbaa !24
  store i64 %t467, ptr %l235, !tbaa !24
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/check:Checker", ptr %t468, i32 0, i32 87
  %t472 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v0, ptr %t470)
  store { i64, ptr } %t472, ptr %l238
  br label %bb120
bb120:
  %t473 = load i64, ptr %l219, !tbaa !24
  %t474 = load i64, ptr %l223, !tbaa !24
  %t475 = load i32, ptr %l230, !tbaa !23
  %t476 = load ptr, ptr %l231, !tbaa !29
  %t477 = load i64, ptr %l235, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t479 = call %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t473, i64 %t474, i32 %t475, ptr %t476, i64 %t477, { i64, ptr } %t478)
  store %"compiler/check:Ask" %t479, ptr %l239
  br label %bb121
bb121:
  %t480 = load ptr, ptr %l218, !tbaa !29
  %t481 = load %"compiler/check:Ask", ptr %l239
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ePush_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t480, %"compiler/check:Ask" %t481)
  br label %bb122
bb122:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb128
bb123:
  %t482 = load i1, ptr %l243, !tbaa !21
  %t483 = xor i1 %t482, true
  br i1 %t483, label %bb124, label %bb125
bb124:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t485, ptr %t486)
  br label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  br label %bb129
bb129:
  %t489 = load ptr, ptr %l2, !tbaa !29
  %t491 = getelementptr %"compiler/ast:If", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  br i1 %t494, label %bb130, label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_c77fa73b8d335132_2d868ec26eb5ab4e)
  unreachable
bb131:
  br label %bb132
bb132:
  %t496 = load ptr, ptr %l2, !tbaa !29
  %t498 = getelementptr %"compiler/ast:If", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t502 = getelementptr %"compiler/ast:Branch", ptr %t499, i32 0, i32 2
  %t503 = load i64, ptr %t502, !tbaa !24
  %t505 = icmp sge i64 %t503, 0
  br i1 %t505, label %bb133, label %bb134
bb133:
  %t507 = load ptr, ptr %l3, !tbaa !29
  store ptr %t507, ptr %l256, !tbaa !29
  %t508 = load ptr, ptr %l2, !tbaa !29
  %t510 = getelementptr %"compiler/ast:If", ptr %t508, i32 0, i32 1
  %t511 = load ptr, ptr %t510, !tbaa !29
  %t513 = icmp eq ptr %t511, null
  br i1 %t513, label %bb135, label %bb136
bb134:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb139
bb135:
  call void @__olang_check_failed(ptr @olang_loc_c77fa73b8d335132_2d868ec26eb5ab4e)
  unreachable
bb136:
  br label %bb137
bb137:
  %t515 = load ptr, ptr %l2, !tbaa !29
  %t517 = getelementptr %"compiler/ast:If", ptr %t515, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t521 = getelementptr %"compiler/ast:Branch", ptr %t518, i32 0, i32 2
  %t522 = load i64, ptr %t521, !tbaa !24
  %t523 = load ptr, ptr %l256, !tbaa !29
  %t525 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t523, i64 %t522)
  store i1 %t525, ptr %l264
  br label %bb138
bb138:
  %t526 = load i1, ptr %l264, !tbaa !21
  store i1 %t526, ptr %l255, !tbaa !21
  br label %bb139
bb139:
  %t527 = load i1, ptr %l255, !tbaa !21
  br i1 %t527, label %bb140, label %bb141
bb140:
  %t528 = load ptr, ptr %l2, !tbaa !29
  %t530 = getelementptr %"compiler/ast:If", ptr %t528, i32 0, i32 2
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = icmp eq ptr %t531, null
  br i1 %t533, label %bb142, label %bb143
bb141:
  br label %bb155
bb142:
  %t535 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t535, ptr %l268
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t536)
  store ptr %t538, ptr %l270
  br label %bb144
bb143:
  br label %bb150
bb144:
  %t539 = load ptr, ptr %l270, !tbaa !29
  %t541 = getelementptr %"compiler/check:frame", ptr %t539, i32 0, i32 7
  %t542 = load i64, ptr %t541, !tbaa !24
  %t544 = trunc i64 %t542 to i32
  store i32 %t544, ptr %l274, !tbaa !23
  %t546 = icmp sge i64 0, 0
  br i1 %t546, label %bb145, label %bb146
bb145:
  %t548 = icmp sle i64 0, 1152921504606846975
  br i1 %t548, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_f018e3200f0cebf1_cf14bb53b7e0d845)
  unreachable
bb147:
  %t550 = mul i64 0, 8
  %t551 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t550)
  %t552 = insertvalue { i64, ptr } undef, i64 0, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t551, 1
  %t554 = load i32, ptr %l274, !tbaa !23
  %t556 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t554, { i64, ptr } %t553)
  store %"compiler/typed:Block" %t556, ptr %l278
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_f018e3200f0cebf1_cf14bb53b7e0d845)
  unreachable
bb149:
  %t557 = load %"compiler/typed:Block", ptr %l278
  %t558 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t557, ptr %t558
  store { i64, [3 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [3 x i64] }, ptr %t559, i32 0, i32 0
  store i64 11, ptr %t560
  %t561 = load %"compiler/source:Span", ptr %l268
  %t562 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t561, 0
  %t564 = insertvalue { %"compiler/source:Span", ptr } %t562, ptr %t558, 1
  %t565 = getelementptr { i64, [3 x i64] }, ptr %t559, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t564, ptr %t565
  %t566 = load { i64, [3 x i64] }, ptr %t559
  %t568 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t566, ptr %t568
  call void @__olang_scope_close(ptr %s0)
  store ptr %t568, ptr %rv
  br label %ret
bb150:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l282, !tbaa !29
  %t571 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t571, ptr %l283
  %t572 = load ptr, ptr %l2, !tbaa !29
  %t574 = getelementptr %"compiler/ast:If", ptr %t572, i32 0, i32 2
  %t575 = load ptr, ptr %t574, !tbaa !29
  %t577 = icmp eq ptr %t575, null
  br i1 %t577, label %bb151, label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_63e876f984926a4_8a5a5385d13272e0)
  unreachable
bb152:
  br label %bb153
bb153:
  %t579 = load ptr, ptr %l2, !tbaa !29
  %t581 = getelementptr %"compiler/ast:If", ptr %t579, i32 0, i32 2
  %t582 = load ptr, ptr %t581, !tbaa !29
  %t583 = load ptr, ptr %l282, !tbaa !29
  %t584 = load %"compiler/source:Span", ptr %l283
  %t586 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t583, %"compiler/source:Span" %t584, ptr %t582)
  store ptr %t586, ptr %l289
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s0)
  %t587 = load ptr, ptr %l289, !tbaa !29
  store ptr %t587, ptr %rv
  br label %ret
bb155:
  %t588 = load ptr, ptr %l2, !tbaa !29
  %t590 = getelementptr %"compiler/ast:If", ptr %t588, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t593 = icmp eq ptr %t591, null
  br i1 %t593, label %bb156, label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_2925a2ee61841cf5_31e6aa96f1b04059)
  unreachable
bb157:
  br label %bb158
bb158:
  %t595 = load ptr, ptr %l2, !tbaa !29
  %t597 = getelementptr %"compiler/ast:If", ptr %t595, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !29
  %t601 = getelementptr %"compiler/ast:Branch", ptr %t598, i32 0, i32 2
  %t602 = load i64, ptr %t601, !tbaa !24
  %t604 = icmp sge i64 %t602, 0
  br i1 %t604, label %bb159, label %bb160
bb159:
  %t606 = load ptr, ptr %l2, !tbaa !29
  %t608 = getelementptr %"compiler/ast:If", ptr %t606, i32 0, i32 2
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = icmp eq ptr %t609, null
  %t613 = xor i1 %t611, true
  store i1 %t613, ptr %l298, !tbaa !21
  br label %bb161
bb160:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb161
bb161:
  %t615 = load i1, ptr %l298, !tbaa !21
  br i1 %t615, label %bb162, label %bb163
bb162:
  %t616 = load ptr, ptr %l0, !tbaa !29
  store ptr %t616, ptr %l304, !tbaa !29
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t619 = getelementptr %"compiler/ast:If", ptr %t617, i32 0, i32 2
  %t620 = load ptr, ptr %t619, !tbaa !29
  %t622 = icmp eq ptr %t620, null
  br i1 %t622, label %bb164, label %bb165
bb163:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb168
bb164:
  call void @__olang_check_failed(ptr @olang_loc_2925a2ee61841cf5_31e6aa96f1b04059)
  unreachable
bb165:
  br label %bb166
bb166:
  %t624 = load ptr, ptr %l2, !tbaa !29
  %t626 = getelementptr %"compiler/ast:If", ptr %t624, i32 0, i32 2
  %t627 = load ptr, ptr %t626, !tbaa !29
  %t628 = load ptr, ptr %l304, !tbaa !29
  %t630 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %t628, ptr %t627)
  store i1 %t630, ptr %l310
  br label %bb167
bb167:
  %t631 = load i1, ptr %l310, !tbaa !21
  store i1 %t631, ptr %l303, !tbaa !21
  br label %bb168
bb168:
  %t632 = load i1, ptr %l303, !tbaa !21
  br i1 %t632, label %bb169, label %bb170
bb169:
  %t633 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t633, ptr %l311
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l312, !tbaa !29
  %t635 = load ptr, ptr %l2, !tbaa !29
  %t637 = getelementptr %"compiler/ast:If", ptr %t635, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !29
  %t640 = icmp eq ptr %t638, null
  br i1 %t640, label %bb171, label %bb172
bb170:
  br label %bb175
bb171:
  call void @__olang_check_failed(ptr @olang_loc_c853d17194d5cd4e_2cb2648c67132f32)
  unreachable
bb172:
  br label %bb173
bb173:
  %t642 = load ptr, ptr %l2, !tbaa !29
  %t644 = getelementptr %"compiler/ast:If", ptr %t642, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !29
  %t646 = load ptr, ptr %l312, !tbaa !29
  %t648 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t646, ptr %t645)
  store ptr %t648, ptr %l318
  br label %bb174
bb174:
  store { i64, [3 x i64] } zeroinitializer, ptr %t649
  %t650 = getelementptr { i64, [3 x i64] }, ptr %t649, i32 0, i32 0
  store i64 11, ptr %t650
  %t651 = load %"compiler/source:Span", ptr %l311
  %t652 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t651, 0
  %t653 = load ptr, ptr %l318, !tbaa !29
  %t654 = insertvalue { %"compiler/source:Span", ptr } %t652, ptr %t653, 1
  %t655 = getelementptr { i64, [3 x i64] }, ptr %t649, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t654, ptr %t655
  %t656 = load { i64, [3 x i64] }, ptr %t649
  %t658 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t656, ptr %t658
  call void @__olang_scope_close(ptr %s0)
  store ptr %t658, ptr %rv
  br label %ret
bb175:
  %t660 = load ptr, ptr %l2, !tbaa !29
  %t662 = getelementptr %"compiler/ast:If", ptr %t660, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  br i1 %t665, label %bb176, label %bb177
bb176:
  call void @__olang_check_failed(ptr @olang_loc_c46a74b5b6ac91ff_1e531384a6d2ae73)
  unreachable
bb177:
  br label %bb178
bb178:
  %t667 = load ptr, ptr %l2, !tbaa !29
  %t669 = getelementptr %"compiler/ast:If", ptr %t667, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !29
  %t673 = getelementptr %"compiler/ast:Branch", ptr %t670, i32 0, i32 2
  %t674 = load i64, ptr %t673, !tbaa !24
  %t676 = icmp sge i64 %t674, 0
  br i1 %t676, label %bb179, label %bb180
bb179:
  %t678 = load ptr, ptr %l3, !tbaa !29
  store ptr %t678, ptr %l330, !tbaa !29
  %t679 = load ptr, ptr %l2, !tbaa !29
  %t681 = getelementptr %"compiler/ast:If", ptr %t679, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !29
  %t684 = icmp eq ptr %t682, null
  br i1 %t684, label %bb181, label %bb182
bb180:
  store i1 false, ptr %l329, !tbaa !21
  br label %bb185
bb181:
  call void @__olang_check_failed(ptr @olang_loc_c46a74b5b6ac91ff_1e531384a6d2ae73)
  unreachable
bb182:
  br label %bb183
bb183:
  %t686 = load ptr, ptr %l2, !tbaa !29
  %t688 = getelementptr %"compiler/ast:If", ptr %t686, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t692 = getelementptr %"compiler/ast:Branch", ptr %t689, i32 0, i32 2
  %t693 = load i64, ptr %t692, !tbaa !24
  %t694 = load ptr, ptr %l330, !tbaa !29
  %t696 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t694, i64 %t693)
  store i1 %t696, ptr %l338
  br label %bb184
bb184:
  %t697 = load i1, ptr %l338, !tbaa !21
  store i1 %t697, ptr %l329, !tbaa !21
  br label %bb185
bb185:
  %t698 = load i1, ptr %l329, !tbaa !21
  br i1 %t698, label %bb186, label %bb187
bb186:
  %t699 = load ptr, ptr %l3, !tbaa !29
  store ptr %t699, ptr %l340, !tbaa !29
  %t700 = load ptr, ptr %l2, !tbaa !29
  %t702 = getelementptr %"compiler/ast:If", ptr %t700, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !29
  %t705 = icmp eq ptr %t703, null
  br i1 %t705, label %bb188, label %bb189
bb187:
  store i1 false, ptr %l339, !tbaa !21
  br label %bb196
bb188:
  call void @__olang_check_failed(ptr @olang_loc_c46a74b5b6ac91ff_1e531384a6d2ae73)
  unreachable
bb189:
  br label %bb190
bb190:
  %t707 = load ptr, ptr %l2, !tbaa !29
  %t709 = getelementptr %"compiler/ast:If", ptr %t707, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !29
  %t713 = getelementptr %"compiler/ast:Branch", ptr %t710, i32 0, i32 2
  %t714 = load i64, ptr %t713, !tbaa !24
  %t715 = load ptr, ptr %l340, !tbaa !29
  %t717 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %t715, i64 %t714)
  store i1 %t717, ptr %l348
  br label %bb191
bb191:
  %t718 = load i1, ptr %l348, !tbaa !21
  br i1 %t718, label %bb192, label %bb193
bb192:
  store i1 true, ptr %l349, !tbaa !21
  br label %bb195
bb193:
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load ptr, ptr %l2, !tbaa !29
  %t722 = getelementptr %"compiler/ast:If", ptr %t720, i32 0, i32 2
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t726 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %t719, ptr %t723)
  store i1 %t726, ptr %l353
  br label %bb194
bb194:
  %t727 = load i1, ptr %l353, !tbaa !21
  store i1 %t727, ptr %l349, !tbaa !21
  br label %bb195
bb195:
  %t728 = load i1, ptr %l349, !tbaa !21
  store i1 %t728, ptr %l339, !tbaa !21
  br label %bb196
bb196:
  %t729 = load i1, ptr %l339, !tbaa !21
  br i1 %t729, label %bb197, label %bb198
bb197:
  store %olang.scope zeroinitializer, ptr %s18
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s18, ptr %t730, %"compiler/source:Span" %t731, { i64, ptr } { i64 51, ptr @.d15 })
  br label %bb199
bb198:
  br label %bb206
bb199:
  %t734 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t734, ptr %l356
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t737 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t735)
  store ptr %t737, ptr %l358
  br label %bb200
bb200:
  %t738 = load ptr, ptr %l358, !tbaa !29
  %t740 = getelementptr %"compiler/check:frame", ptr %t738, i32 0, i32 7
  %t741 = load i64, ptr %t740, !tbaa !24
  %t743 = trunc i64 %t741 to i32
  store i32 %t743, ptr %l362, !tbaa !23
  %t745 = icmp sge i64 0, 0
  br i1 %t745, label %bb201, label %bb202
bb201:
  %t747 = icmp sle i64 0, 1152921504606846975
  br i1 %t747, label %bb203, label %bb204
bb202:
  call void @__olang_check_failed(ptr @olang_loc_b5b4909ab910ecd8_969bb6e75e2c8ae4)
  unreachable
bb203:
  %t749 = mul i64 0, 8
  %t750 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t749)
  %t751 = insertvalue { i64, ptr } undef, i64 0, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t750, 1
  %t753 = load i32, ptr %l362, !tbaa !23
  %t755 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t753, { i64, ptr } %t752)
  store %"compiler/typed:Block" %t755, ptr %l366
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_b5b4909ab910ecd8_969bb6e75e2c8ae4)
  unreachable
bb205:
  %t756 = load %"compiler/typed:Block", ptr %l366
  %t757 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t756, ptr %t757
  store { i64, [3 x i64] } zeroinitializer, ptr %t758
  %t759 = getelementptr { i64, [3 x i64] }, ptr %t758, i32 0, i32 0
  store i64 11, ptr %t759
  %t760 = load %"compiler/source:Span", ptr %l356
  %t761 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t760, 0
  %t763 = insertvalue { %"compiler/source:Span", ptr } %t761, ptr %t757, 1
  %t764 = getelementptr { i64, [3 x i64] }, ptr %t758, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t763, ptr %t764
  %t765 = load { i64, [3 x i64] }, ptr %t758
  %t767 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t765, ptr %t767
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t767, ptr %rv
  br label %ret
bb206:
  %t769 = load ptr, ptr %l0, !tbaa !29
  store ptr %t769, ptr %l370, !tbaa !29
  %t770 = load ptr, ptr %l2, !tbaa !29
  %t772 = getelementptr %"compiler/ast:If", ptr %t770, i32 0, i32 0
  %t773 = load ptr, ptr %t772, !tbaa !29
  %t775 = icmp eq ptr %t773, null
  br i1 %t775, label %bb207, label %bb208
bb207:
  call void @__olang_check_failed(ptr @olang_loc_204174f82b625491_c4a24154dc66de6d)
  unreachable
bb208:
  br label %bb209
bb209:
  %t777 = load ptr, ptr %l2, !tbaa !29
  %t779 = getelementptr %"compiler/ast:If", ptr %t777, i32 0, i32 0
  %t780 = load ptr, ptr %t779, !tbaa !29
  %t781 = load ptr, ptr %l370, !tbaa !29
  %t783 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %t781, ptr %t780)
  store i64 %t783, ptr %l376
  br label %bb210
bb210:
  %t784 = load i64, ptr %l376, !tbaa !24
  store i64 %t784, ptr %l10, !tbaa !24
  %t785 = load i64, ptr %l10, !tbaa !24
  %t787 = icmp eq i64 %t785, 1
  br i1 %t787, label %bb211, label %bb212
bb211:
  %t789 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t789, ptr %l379
  %t790 = load ptr, ptr %l0, !tbaa !29
  store ptr %t790, ptr %l380, !tbaa !29
  %t791 = load ptr, ptr %l2, !tbaa !29
  %t793 = getelementptr %"compiler/ast:If", ptr %t791, i32 0, i32 1
  %t794 = load ptr, ptr %t793, !tbaa !29
  %t796 = icmp eq ptr %t794, null
  br i1 %t796, label %bb213, label %bb214
bb212:
  br label %bb217
bb213:
  call void @__olang_check_failed(ptr @olang_loc_129174e89ad23b8a_c281ac2402d9bb86)
  unreachable
bb214:
  br label %bb215
bb215:
  %t798 = load ptr, ptr %l2, !tbaa !29
  %t800 = getelementptr %"compiler/ast:If", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t802 = load ptr, ptr %l380, !tbaa !29
  %t804 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t802, ptr %t801)
  store ptr %t804, ptr %l386
  br label %bb216
bb216:
  store { i64, [3 x i64] } zeroinitializer, ptr %t805
  %t806 = getelementptr { i64, [3 x i64] }, ptr %t805, i32 0, i32 0
  store i64 11, ptr %t806
  %t807 = load %"compiler/source:Span", ptr %l379
  %t808 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t807, 0
  %t809 = load ptr, ptr %l386, !tbaa !29
  %t810 = insertvalue { %"compiler/source:Span", ptr } %t808, ptr %t809, 1
  %t811 = getelementptr { i64, [3 x i64] }, ptr %t805, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t810, ptr %t811
  %t812 = load { i64, [3 x i64] }, ptr %t805
  %t814 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t812, ptr %t814
  call void @__olang_scope_close(ptr %s0)
  store ptr %t814, ptr %rv
  br label %ret
bb217:
  %t816 = load i64, ptr %l10, !tbaa !24
  %t818 = icmp eq i64 %t816, 0
  br i1 %t818, label %bb218, label %bb219
bb218:
  %t820 = load ptr, ptr %l2, !tbaa !29
  %t822 = getelementptr %"compiler/ast:If", ptr %t820, i32 0, i32 2
  %t823 = load ptr, ptr %t822, !tbaa !29
  %t825 = icmp eq ptr %t823, null
  br i1 %t825, label %bb220, label %bb221
bb219:
  br label %bb247
bb220:
  %t827 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t827, ptr %l394
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t828)
  store ptr %t830, ptr %l396
  br label %bb222
bb221:
  br label %bb228
bb222:
  %t831 = load ptr, ptr %l396, !tbaa !29
  %t833 = getelementptr %"compiler/check:frame", ptr %t831, i32 0, i32 7
  %t834 = load i64, ptr %t833, !tbaa !24
  %t836 = trunc i64 %t834 to i32
  store i32 %t836, ptr %l400, !tbaa !23
  %t838 = icmp sge i64 0, 0
  br i1 %t838, label %bb223, label %bb224
bb223:
  %t840 = icmp sle i64 0, 1152921504606846975
  br i1 %t840, label %bb225, label %bb226
bb224:
  call void @__olang_check_failed(ptr @olang_loc_e450882c0be92eca_22c03d797ed0de)
  unreachable
bb225:
  %t842 = mul i64 0, 8
  %t843 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t842)
  %t844 = insertvalue { i64, ptr } undef, i64 0, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t843, 1
  %t846 = load i32, ptr %l400, !tbaa !23
  %t848 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 %t846, { i64, ptr } %t845)
  store %"compiler/typed:Block" %t848, ptr %l404
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_e450882c0be92eca_22c03d797ed0de)
  unreachable
bb227:
  %t849 = load %"compiler/typed:Block", ptr %l404
  %t850 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t849, ptr %t850
  store { i64, [3 x i64] } zeroinitializer, ptr %t851
  %t852 = getelementptr { i64, [3 x i64] }, ptr %t851, i32 0, i32 0
  store i64 11, ptr %t852
  %t853 = load %"compiler/source:Span", ptr %l394
  %t854 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t853, 0
  %t856 = insertvalue { %"compiler/source:Span", ptr } %t854, ptr %t850, 1
  %t857 = getelementptr { i64, [3 x i64] }, ptr %t851, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t856, ptr %t857
  %t858 = load { i64, [3 x i64] }, ptr %t851
  %t860 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t858, ptr %t860
  call void @__olang_scope_close(ptr %s0)
  store ptr %t860, ptr %rv
  br label %ret
bb228:
  %t862 = load ptr, ptr %l2, !tbaa !29
  %t864 = getelementptr %"compiler/ast:If", ptr %t862, i32 0, i32 2
  %t865 = load ptr, ptr %t864, !tbaa !29
  store ptr %t865, ptr %l11, !tbaa !29
  %t867 = load ptr, ptr %l11, !tbaa !29
  store ptr %t867, ptr %l410, !tbaa !29
  store i1 false, ptr %l411, !tbaa !21
  %t868 = load ptr, ptr %l410, !tbaa !29
  %t869 = icmp ne ptr %t868, null
  br i1 %t869, label %bb229, label %bb230
bb229:
  %t871 = load ptr, ptr %l410, !tbaa !29
  %t872 = load i64, ptr %t871
  %t874 = icmp eq i64 %t872, 5
  store i1 %t874, ptr %l411, !tbaa !21
  br label %bb230
bb230:
  %t875 = load i1, ptr %l411, !tbaa !21
  br i1 %t875, label %bb231, label %bb232
bb231:
  %t876 = load ptr, ptr %l11, !tbaa !29
  %t878 = getelementptr { i64, [4 x i64] }, ptr %t876, i32 0, i32 1
  %t879 = getelementptr { %"compiler/source:Span", ptr }, ptr %t878, i32 0, i32 0
  %t880 = load %"compiler/source:Span", ptr %t879
  store %"compiler/source:Span" %t880, ptr %l12
  %t882 = load ptr, ptr %l11, !tbaa !29
  %t884 = getelementptr { i64, [4 x i64] }, ptr %t882, i32 0, i32 1
  %t885 = getelementptr { %"compiler/source:Span", ptr }, ptr %t884, i32 0, i32 1
  %t886 = load ptr, ptr %t885
  store ptr %t886, ptr %l13, !tbaa !29
  br label %bb233
bb232:
  br label %bb242
bb233:
  %t888 = load ptr, ptr %l13, !tbaa !29
  %t890 = getelementptr %"compiler/ast:If", ptr %t888, i32 0, i32 0
  %t891 = load ptr, ptr %t890, !tbaa !29
  %t893 = icmp eq ptr %t891, null
  br i1 %t893, label %bb234, label %bb235
bb234:
  %t895 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t895, ptr %l421
  %t896 = load ptr, ptr %l0, !tbaa !29
  store ptr %t896, ptr %l422, !tbaa !29
  %t897 = load ptr, ptr %l13, !tbaa !29
  %t899 = getelementptr %"compiler/ast:If", ptr %t897, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !29
  %t902 = icmp eq ptr %t900, null
  br i1 %t902, label %bb236, label %bb237
bb235:
  br label %bb240
bb236:
  call void @__olang_check_failed(ptr @olang_loc_14ce9ceb5dce4271_aff89a24b099384d)
  unreachable
bb237:
  br label %bb238
bb238:
  %t904 = load ptr, ptr %l13, !tbaa !29
  %t906 = getelementptr %"compiler/ast:If", ptr %t904, i32 0, i32 1
  %t907 = load ptr, ptr %t906, !tbaa !29
  %t908 = load ptr, ptr %l422, !tbaa !29
  %t910 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t908, ptr %t907)
  store ptr %t910, ptr %l428
  br label %bb239
bb239:
  store { i64, [3 x i64] } zeroinitializer, ptr %t911
  %t912 = getelementptr { i64, [3 x i64] }, ptr %t911, i32 0, i32 0
  store i64 11, ptr %t912
  %t913 = load %"compiler/source:Span", ptr %l421
  %t914 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t913, 0
  %t915 = load ptr, ptr %l428, !tbaa !29
  %t916 = insertvalue { %"compiler/source:Span", ptr } %t914, ptr %t915, 1
  %t917 = getelementptr { i64, [3 x i64] }, ptr %t911, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t916, ptr %t917
  %t918 = load { i64, [3 x i64] }, ptr %t911
  %t920 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t918, ptr %t920
  call void @__olang_scope_close(ptr %s0)
  store ptr %t920, ptr %rv
  br label %ret
bb240:
  %t922 = load ptr, ptr %l0, !tbaa !29
  %t923 = load %"compiler/source:Span", ptr %l12
  %t924 = load ptr, ptr %l13, !tbaa !29
  %t928 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t922, %"compiler/source:Span" %t923, ptr %t924)
  store ptr %t928, ptr %l434
  br label %bb241
bb241:
  call void @__olang_scope_close(ptr %s0)
  %t929 = load ptr, ptr %l434, !tbaa !29
  store ptr %t929, ptr %rv
  br label %ret
bb242:
  %t930 = load ptr, ptr %l0, !tbaa !29
  store ptr %t930, ptr %l435, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t931, ptr %l436
  %t932 = load ptr, ptr %l2, !tbaa !29
  %t934 = getelementptr %"compiler/ast:If", ptr %t932, i32 0, i32 2
  %t935 = load ptr, ptr %t934, !tbaa !29
  %t937 = icmp eq ptr %t935, null
  br i1 %t937, label %bb243, label %bb244
bb243:
  call void @__olang_check_failed(ptr @olang_loc_6f3b4b685ddeb67c_7b5ce21143ef4c38)
  unreachable
bb244:
  br label %bb245
bb245:
  %t939 = load ptr, ptr %l2, !tbaa !29
  %t941 = getelementptr %"compiler/ast:If", ptr %t939, i32 0, i32 2
  %t942 = load ptr, ptr %t941, !tbaa !29
  %t943 = load ptr, ptr %l435, !tbaa !29
  %t944 = load %"compiler/source:Span", ptr %l436
  %t946 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseOf(ptr %v0, ptr %v1, ptr %t943, %"compiler/source:Span" %t944, ptr %t942)
  store ptr %t946, ptr %l442
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s0)
  %t947 = load ptr, ptr %l442, !tbaa !29
  store ptr %t947, ptr %rv
  br label %ret
bb247:
  %t948 = load i1, ptr %l8, !tbaa !21
  %t950 = xor i1 %t948, true
  br i1 %t950, label %bb248, label %bb249
bb248:
  %t952 = load ptr, ptr %l0, !tbaa !29
  %t953 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %t952, ptr %t953)
  br label %bb250
bb249:
  br label %bb251
bb250:
  br label %bb251
bb251:
  %t956 = load ptr, ptr %l0, !tbaa !29
  store ptr %t956, ptr %l447, !tbaa !29
  %t957 = load ptr, ptr %l2, !tbaa !29
  %t959 = getelementptr %"compiler/ast:If", ptr %t957, i32 0, i32 0
  %t960 = load ptr, ptr %t959, !tbaa !29
  %t962 = icmp eq ptr %t960, null
  br i1 %t962, label %bb252, label %bb253
bb252:
  call void @__olang_check_failed(ptr @olang_loc_e7da762e638de5eb_7df0529e92f5f857)
  unreachable
bb253:
  br label %bb254
bb254:
  %t964 = load ptr, ptr %l2, !tbaa !29
  %t966 = getelementptr %"compiler/ast:If", ptr %t964, i32 0, i32 0
  %t967 = load ptr, ptr %t966, !tbaa !29
  %t968 = load ptr, ptr %l447, !tbaa !29
  %t970 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t968, ptr %t967)
  store ptr %t970, ptr %l453
  br label %bb255
bb255:
  %t971 = load ptr, ptr %l453, !tbaa !29
  store ptr %t971, ptr %l14, !tbaa !29
  %t972 = load i1, ptr %l7, !tbaa !21
  br i1 %t972, label %bb256, label %bb257
bb256:
  %t974 = load ptr, ptr %l14, !tbaa !29
  %t977 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t974)
  store i32 %t977, ptr %l458
  br label %bb258
bb257:
  store i1 false, ptr %l455, !tbaa !21
  br label %bb259
bb258:
  %t978 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t979 = load i32, ptr %l458, !tbaa !23
  %t981 = icmp eq i32 %t979, %t978
  store i1 %t981, ptr %l455, !tbaa !21
  br label %bb259
bb259:
  %t983 = load i1, ptr %l455, !tbaa !21
  br i1 %t983, label %bb260, label %bb261
bb260:
  store %olang.scope zeroinitializer, ptr %s26
  %t984 = load ptr, ptr %l0, !tbaa !29
  store ptr %t984, ptr %l461, !tbaa !29
  %t985 = load ptr, ptr %l0, !tbaa !29
  store ptr %t985, ptr %l462, !tbaa !29
  %t986 = load ptr, ptr %l2, !tbaa !29
  %t988 = getelementptr %"compiler/ast:If", ptr %t986, i32 0, i32 0
  %t989 = load ptr, ptr %t988, !tbaa !29
  %t991 = icmp eq ptr %t989, null
  br i1 %t991, label %bb262, label %bb263
bb261:
  br label %bb268
bb262:
  call void @__olang_check_failed(ptr @olang_loc_8ed32cf5e7258066_ffd10e9c2d5e46a)
  unreachable
bb263:
  br label %bb264
bb264:
  %t993 = load ptr, ptr %l2, !tbaa !29
  %t995 = getelementptr %"compiler/ast:If", ptr %t993, i32 0, i32 0
  %t996 = load ptr, ptr %t995, !tbaa !29
  %t997 = load ptr, ptr %l462, !tbaa !29
  %t999 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %t997, ptr %t996)
  store %"compiler/source:Span" %t999, ptr %l468
  br label %bb265
bb265:
  %t1000 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %s26)
  store %"compiler/msgs:Msg" %t1000, ptr %l469
  br label %bb266
bb266:
  %t1001 = load ptr, ptr %l461, !tbaa !29
  %t1002 = load %"compiler/source:Span", ptr %l468
  %t1003 = load %"compiler/msgs:Msg", ptr %l469
  %t1004 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t1001, %"compiler/source:Span" %t1002, %"compiler/msgs:Msg" %t1003)
  store i64 %t1004, ptr %l470
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s26)
  br label %bb268
bb268:
  %t1005 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1005, ptr %l471, !tbaa !29
  %t1006 = load ptr, ptr %l2, !tbaa !29
  %t1008 = getelementptr %"compiler/ast:If", ptr %t1006, i32 0, i32 0
  %t1009 = load ptr, ptr %t1008, !tbaa !29
  %t1011 = icmp eq ptr %t1009, null
  br i1 %t1011, label %bb269, label %bb270
bb269:
  call void @__olang_check_failed(ptr @olang_loc_4ac5dcd3d6b95a4d_7a015a3c37ae2071)
  unreachable
bb270:
  br label %bb271
bb271:
  %t1013 = load ptr, ptr %l2, !tbaa !29
  %t1015 = getelementptr %"compiler/ast:If", ptr %t1013, i32 0, i32 0
  %t1016 = load ptr, ptr %t1015, !tbaa !29
  %t1017 = load ptr, ptr %l471, !tbaa !29
  %t1020 = call { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %t1017, ptr %t1016, i32 72)
  store { i64, i64 } %t1020, ptr %l478
  br label %bb272
bb272:
  %t1021 = load { i64, i64 }, ptr %l478
  store { i64, i64 } %t1021, ptr %l15
  %t1022 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t1023 = load i64, ptr %t1022, !tbaa !24
  store i64 %t1023, ptr %l16, !tbaa !24
  %t1025 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t1026 = load i64, ptr %t1025, !tbaa !24
  store i64 %t1026, ptr %l17, !tbaa !24
  %t1028 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1028, ptr %l481, !tbaa !29
  %t1029 = load ptr, ptr %l2, !tbaa !29
  %t1031 = getelementptr %"compiler/ast:If", ptr %t1029, i32 0, i32 1
  %t1032 = load ptr, ptr %t1031, !tbaa !29
  %t1034 = icmp eq ptr %t1032, null
  br i1 %t1034, label %bb273, label %bb274
bb273:
  call void @__olang_check_failed(ptr @olang_loc_162a24c06a0f6e38_d46e08b937be947c)
  unreachable
bb274:
  br label %bb275
bb275:
  %t1036 = load ptr, ptr %l2, !tbaa !29
  %t1038 = getelementptr %"compiler/ast:If", ptr %t1036, i32 0, i32 1
  %t1039 = load ptr, ptr %t1038, !tbaa !29
  %t1040 = load i64, ptr %l16, !tbaa !24
  %t1041 = load i64, ptr %l17, !tbaa !24
  %t1042 = load ptr, ptr %l2, !tbaa !29
  %t1044 = getelementptr %"compiler/ast:If", ptr %t1042, i32 0, i32 0
  %t1045 = load ptr, ptr %t1044, !tbaa !29
  %t1046 = load ptr, ptr %l481, !tbaa !29
  %t1051 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v1, ptr %t1046, ptr %t1039, i64 %t1040, i64 %t1041, ptr %t1045, i1 true)
  store ptr %t1051, ptr %l491
  br label %bb276
bb276:
  %t1052 = load ptr, ptr %l491, !tbaa !29
  store ptr %t1052, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t1053 = load ptr, ptr %l2, !tbaa !29
  %t1055 = getelementptr %"compiler/ast:If", ptr %t1053, i32 0, i32 2
  %t1056 = load ptr, ptr %t1055, !tbaa !29
  %t1058 = icmp eq ptr %t1056, null
  %t1060 = xor i1 %t1058, true
  br i1 %t1060, label %bb277, label %bb278
bb277:
  %t1062 = load ptr, ptr %l2, !tbaa !29
  %t1064 = getelementptr %"compiler/ast:If", ptr %t1062, i32 0, i32 2
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  store ptr %t1065, ptr %l20, !tbaa !29
  %t1067 = load ptr, ptr %l20, !tbaa !29
  store ptr %t1067, ptr %l498, !tbaa !29
  store i1 false, ptr %l499, !tbaa !21
  %t1068 = load ptr, ptr %l498, !tbaa !29
  %t1069 = icmp ne ptr %t1068, null
  br i1 %t1069, label %bb279, label %bb280
bb278:
  br label %bb315
bb279:
  %t1071 = load ptr, ptr %l498, !tbaa !29
  %t1072 = load i64, ptr %t1071
  %t1074 = icmp eq i64 %t1072, 5
  store i1 %t1074, ptr %l499, !tbaa !21
  br label %bb280
bb280:
  %t1075 = load i1, ptr %l499, !tbaa !21
  br i1 %t1075, label %bb281, label %bb282
bb281:
  %t1076 = load ptr, ptr %l20, !tbaa !29
  %t1078 = getelementptr { i64, [4 x i64] }, ptr %t1076, i32 0, i32 1
  %t1079 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1078, i32 0, i32 0
  %t1080 = load %"compiler/source:Span", ptr %t1079
  store %"compiler/source:Span" %t1080, ptr %l21
  %t1082 = load ptr, ptr %l20, !tbaa !29
  %t1084 = getelementptr { i64, [4 x i64] }, ptr %t1082, i32 0, i32 1
  %t1085 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1084, i32 0, i32 1
  %t1086 = load ptr, ptr %t1085
  store ptr %t1086, ptr %l22, !tbaa !29
  br label %bb283
bb282:
  br label %bb308
bb283:
  %t1088 = load ptr, ptr %l22, !tbaa !29
  %t1090 = getelementptr %"compiler/ast:If", ptr %t1088, i32 0, i32 0
  %t1091 = load ptr, ptr %t1090, !tbaa !29
  %t1093 = icmp eq ptr %t1091, null
  br i1 %t1093, label %bb284, label %bb285
bb284:
  %t1095 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1095, ptr %l509, !tbaa !29
  %t1096 = load ptr, ptr %l2, !tbaa !29
  %t1098 = getelementptr %"compiler/ast:If", ptr %t1096, i32 0, i32 0
  %t1099 = load ptr, ptr %t1098, !tbaa !29
  %t1101 = icmp eq ptr %t1099, null
  br i1 %t1101, label %bb286, label %bb287
bb285:
  %t1103 = load ptr, ptr %l0, !tbaa !29
  %t1105 = getelementptr %"compiler/check:Checker", ptr %t1103, i32 0, i32 33
  %t1107 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1105)
  store i64 %t1107, ptr %l533
  br label %bb294
bb286:
  call void @__olang_check_failed(ptr @olang_loc_18bd954db9161a57_4d0d337f3d6dc3eb)
  unreachable
bb287:
  br label %bb288
bb288:
  %t1108 = load ptr, ptr %l2, !tbaa !29
  %t1110 = getelementptr %"compiler/ast:If", ptr %t1108, i32 0, i32 0
  %t1111 = load ptr, ptr %t1110, !tbaa !29
  %t1112 = load ptr, ptr %l509, !tbaa !29
  %t1115 = call { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %t1112, ptr %t1111, i32 74)
  store { i64, i64 } %t1115, ptr %l516
  br label %bb289
bb289:
  %t1116 = load { i64, i64 }, ptr %l516
  store { i64, i64 } %t1116, ptr %l23
  %t1117 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 0
  %t1118 = load i64, ptr %t1117, !tbaa !24
  store i64 %t1118, ptr %l24, !tbaa !24
  %t1120 = getelementptr { i64, i64 }, ptr %l23, i32 0, i32 1
  %t1121 = load i64, ptr %t1120, !tbaa !24
  store i64 %t1121, ptr %l25, !tbaa !24
  %t1123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1123, ptr %l519, !tbaa !29
  %t1124 = load ptr, ptr %l22, !tbaa !29
  %t1126 = getelementptr %"compiler/ast:If", ptr %t1124, i32 0, i32 1
  %t1127 = load ptr, ptr %t1126, !tbaa !29
  %t1129 = icmp eq ptr %t1127, null
  br i1 %t1129, label %bb290, label %bb291
bb290:
  call void @__olang_check_failed(ptr @olang_loc_f844534d0025e012_1a1d7643daef702e)
  unreachable
bb291:
  br label %bb292
bb292:
  %t1131 = load ptr, ptr %l22, !tbaa !29
  %t1133 = getelementptr %"compiler/ast:If", ptr %t1131, i32 0, i32 1
  %t1134 = load ptr, ptr %t1133, !tbaa !29
  %t1135 = load i64, ptr %l24, !tbaa !24
  %t1136 = load i64, ptr %l25, !tbaa !24
  %t1137 = load ptr, ptr %l2, !tbaa !29
  %t1139 = getelementptr %"compiler/ast:If", ptr %t1137, i32 0, i32 0
  %t1140 = load ptr, ptr %t1139, !tbaa !29
  %t1141 = load ptr, ptr %l519, !tbaa !29
  %t1146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v1, ptr %t1141, ptr %t1134, i64 %t1135, i64 %t1136, ptr %t1140, i1 false)
  store ptr %t1146, ptr %l529
  br label %bb293
bb293:
  %t1147 = load ptr, ptr %l529, !tbaa !29
  store ptr %t1147, ptr %l19, !tbaa !29
  br label %bb307
bb294:
  %t1149 = load i64, ptr %l533, !tbaa !24
  store i64 %t1149, ptr %l26, !tbaa !24
  %t1150 = load ptr, ptr %l0, !tbaa !29
  %t1151 = load %"compiler/source:Span", ptr %l21
  %t1155 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t1150, i32 1, %"compiler/source:Span" %t1151)
  store { i64, i64, i64 } %t1155, ptr %l537
  br label %bb295
bb295:
  %t1156 = load { i64, i64, i64 }, ptr %l537
  store { i64, i64, i64 } %t1156, ptr %l27
  %t1157 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 0
  %t1158 = load i64, ptr %t1157, !tbaa !24
  store i64 %t1158, ptr %l28, !tbaa !24
  %t1160 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 1
  %t1161 = load i64, ptr %t1160, !tbaa !24
  store i64 %t1161, ptr %l29, !tbaa !24
  %t1163 = getelementptr { i64, i64, i64 }, ptr %l27, i32 0, i32 2
  %t1164 = load i64, ptr %t1163, !tbaa !24
  store i64 %t1164, ptr %l30, !tbaa !24
  %t1166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1166, ptr %l541, !tbaa !29
  %t1167 = load ptr, ptr %l2, !tbaa !29
  %t1169 = getelementptr %"compiler/ast:If", ptr %t1167, i32 0, i32 0
  %t1170 = load ptr, ptr %t1169, !tbaa !29
  %t1172 = icmp eq ptr %t1170, null
  br i1 %t1172, label %bb296, label %bb297
bb296:
  call void @__olang_check_failed(ptr @olang_loc_553bfedf729ee439_b54fafc31e964fd5)
  unreachable
bb297:
  br label %bb298
bb298:
  %t1174 = load ptr, ptr %l2, !tbaa !29
  %t1176 = getelementptr %"compiler/ast:If", ptr %t1174, i32 0, i32 0
  %t1177 = load ptr, ptr %t1176, !tbaa !29
  %t1178 = load i64, ptr %l28, !tbaa !24
  %t1179 = load ptr, ptr %l541, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t1179, ptr %t1177, i1 false, i64 %t1178)
  br label %bb299
bb299:
  %t1182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1182, ptr %l548, !tbaa !29
  %t1183 = load ptr, ptr %l2, !tbaa !29
  %t1185 = getelementptr %"compiler/ast:If", ptr %t1183, i32 0, i32 0
  %t1186 = load ptr, ptr %t1185, !tbaa !29
  %t1188 = icmp eq ptr %t1186, null
  br i1 %t1188, label %bb300, label %bb301
bb300:
  call void @__olang_check_failed(ptr @olang_loc_2032043ec708821f_9b3365a6aba1b47b)
  unreachable
bb301:
  br label %bb302
bb302:
  %t1190 = load ptr, ptr %l2, !tbaa !29
  %t1192 = getelementptr %"compiler/ast:If", ptr %t1190, i32 0, i32 0
  %t1193 = load ptr, ptr %t1192, !tbaa !29
  %t1194 = load i64, ptr %l28, !tbaa !24
  %t1195 = load ptr, ptr %l548, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %t1195, ptr %t1193, i1 false, i64 %t1194)
  br label %bb303
bb303:
  %t1198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1198, ptr %l555, !tbaa !29
  %t1199 = load ptr, ptr %l0, !tbaa !29
  %t1200 = load %"compiler/source:Span", ptr %l21
  %t1201 = load ptr, ptr %l22, !tbaa !29
  %t1205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %t1199, %"compiler/source:Span" %t1200, ptr %t1201)
  store ptr %t1205, ptr %l559
  br label %bb304
bb304:
  %t1206 = load ptr, ptr %l555, !tbaa !29
  %t1207 = load ptr, ptr %l559, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t1206, ptr %t1207)
  br label %bb305
bb305:
  %t1208 = load ptr, ptr %l0, !tbaa !29
  %t1209 = load i64, ptr %l28, !tbaa !24
  %t1210 = load i64, ptr %l29, !tbaa !24
  %t1211 = load i64, ptr %l30, !tbaa !24
  %t1212 = load i64, ptr %l26, !tbaa !24
  %t1218 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t1208, i64 %t1209, i64 %t1210, i64 %t1211, i64 %t1212)
  store ptr %t1218, ptr %l565
  br label %bb306
bb306:
  %t1219 = load ptr, ptr %l565, !tbaa !29
  store ptr %t1219, ptr %l19, !tbaa !29
  br label %bb307
bb307:
  br label %bb314
bb308:
  store %olang.scope zeroinitializer, ptr %s31
  %t1221 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1221, ptr %l567, !tbaa !29
  %t1222 = load ptr, ptr %l2, !tbaa !29
  %t1224 = getelementptr %"compiler/ast:If", ptr %t1222, i32 0, i32 2
  %t1225 = load ptr, ptr %t1224, !tbaa !29
  %t1227 = icmp eq ptr %t1225, null
  br i1 %t1227, label %bb309, label %bb310
bb309:
  call void @__olang_check_failed(ptr @olang_loc_7e262e55150b6580_229faafeaed7320c)
  unreachable
bb310:
  br label %bb311
bb311:
  %t1229 = load ptr, ptr %l2, !tbaa !29
  %t1231 = getelementptr %"compiler/ast:If", ptr %t1229, i32 0, i32 2
  %t1232 = load ptr, ptr %t1231, !tbaa !29
  %t1234 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t1232)
  store %"compiler/source:Span" %t1234, ptr %l573
  br label %bb312
bb312:
  %t1235 = load ptr, ptr %l567, !tbaa !29
  %t1236 = load %"compiler/source:Span", ptr %l573
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s31, ptr %t1235, %"compiler/source:Span" %t1236, { i64, ptr } { i64 20, ptr @.d16 })
  br label %bb313
bb313:
  call void @__olang_scope_close(ptr %s31)
  br label %bb314
bb314:
  br label %bb315
bb315:
  %t1237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1237, ptr %l574
  %t1238 = load ptr, ptr %l14, !tbaa !29
  %t1239 = load ptr, ptr %l18, !tbaa !29
  %t1240 = load ptr, ptr %l19, !tbaa !29
  %t1244 = call %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t1238, ptr %t1239, ptr %t1240)
  store %"compiler/typed:If" %t1244, ptr %l578
  br label %bb316
bb316:
  %t1245 = load %"compiler/typed:If", ptr %l578
  %t1246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:If" %t1245, ptr %t1246
  store { i64, [3 x i64] } zeroinitializer, ptr %t1247
  %t1248 = getelementptr { i64, [3 x i64] }, ptr %t1247, i32 0, i32 0
  store i64 3, ptr %t1248
  %t1249 = load %"compiler/source:Span", ptr %l574
  %t1250 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t1249, 0
  %t1252 = insertvalue { %"compiler/source:Span", ptr } %t1250, ptr %t1246, 1
  %t1253 = getelementptr { i64, [3 x i64] }, ptr %t1247, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t1252, ptr %t1253
  %t1254 = load { i64, [3 x i64] }, ptr %t1247
  %t1256 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t1254, ptr %t1256
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1256, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l17 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/msgs:Msg"
  %l91 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca i32
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l127 = alloca i32
  %l129 = alloca i32
  %l131 = alloca i1
  %l132 = alloca ptr
  %l135 = alloca i32
  %l136 = alloca i1
  %l144 = alloca ptr
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i32
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l163 = alloca %"compiler/source:Span"
  %l165 = alloca i32
  %l169 = alloca %"compiler/typed:Make"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t21 = alloca { i64, [3 x i64] }, align 8
  %t277 = alloca { i64, [4 x i64] }, align 8
  %t298 = alloca { i64, [3 x i64] }, align 8
  %t347 = alloca { i64, [5 x i64] }, align 8
  %t359 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 20
  store i1 false, ptr %t7, !tbaa !21
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp eq i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t18 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 5
  store i32 %t15, ptr %t18, !tbaa !23
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t24 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t20, 0
  %t25 = insertvalue { %"compiler/source:Span", ptr } %t24, ptr null, 1
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t25, ptr %t26
  %t27 = load { i64, [3 x i64] }, ptr %t21
  %t29 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t27, ptr %t29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t19, ptr %t29)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 32
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l30
  br label %bb6
bb6:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l32, !tbaa !24
  %t42 = icmp sge i64 %t41, 0
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t44, 2305843009213693951
  br i1 %t45, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb9:
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  store i64 %t55, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8)
  unreachable
bb11:
  %t63 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb16
bb13:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l44, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb15
bb15:
  %t83 = load i64, ptr %l44, !tbaa !24
  store i64 %t83, ptr %l41, !tbaa !24
  br label %bb16
bb16:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load i64, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb19:
  br label %bb20
bb20:
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l11, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l62, !tbaa !29
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l64, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr ptr, ptr %t109, i64 %t106
  %t111 = load ptr, ptr %t110, !tbaa !39
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t104, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb21
bb21:
  %t118 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t118, ptr %l70, !tbaa !27
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l73
  br label %bb22
bb22:
  %t127 = load ptr, ptr %l62, !tbaa !29
  %t128 = load ptr, ptr %l69, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l73
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t127, ptr %t128, %"compiler/source:Span" %t129)
  store ptr %t130, ptr %l74
  br label %bb23
bb23:
  %t131 = load ptr, ptr %l74, !tbaa !29
  store ptr %t131, ptr %l12, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t135 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t132)
  store i32 %t135, ptr %l77
  br label %bb24
bb24:
  %t136 = load i32, ptr %l77, !tbaa !23
  store i32 %t136, ptr %l13, !tbaa !23
  %t137 = load i32, ptr %l13, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t141 = icmp eq i32 %t137, %t138
  br i1 %t141, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  %t143 = load i32, ptr %l13, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t147 = icmp eq i32 %t143, %t144
  store i1 %t147, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t149 = load i1, ptr %l81, !tbaa !21
  br i1 %t149, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l85, !tbaa !29
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t151, ptr %l86, !tbaa !27
  %t152 = load i64, ptr %l11, !tbaa !24
  %t154 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr ptr, ptr %t155, i64 %t152
  %t157 = load ptr, ptr %t156, !tbaa !39
  %t159 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t157)
  store %"compiler/source:Span" %t159, ptr %l89
  br label %bb30
bb29:
  %t160 = load i32, ptr %l13, !tbaa !23
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t164 = icmp ne i32 %t160, %t161
  br i1 %t164, label %bb33, label %bb34
bb30:
  %t166 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %s4)
  store %"compiler/msgs:Msg" %t166, ptr %l90
  br label %bb31
bb31:
  %t167 = load ptr, ptr %l85, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l89
  %t169 = load %"compiler/msgs:Msg", ptr %l90
  %t170 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t167, %"compiler/source:Span" %t168, %"compiler/msgs:Msg" %t169)
  store i64 %t170, ptr %l91
  br label %bb32
bb32:
  %t171 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t171, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb33:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t174, ptr %l97, !tbaa !27
  %t175 = load i64, ptr %l11, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t181 = load ptr, ptr %l12, !tbaa !29
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v0, ptr %t173, ptr %t180, ptr %t181, i1 false)
  store i32 %t185, ptr %l101
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t186 = load i32, ptr %l101, !tbaa !23
  store i32 %t186, ptr %l13, !tbaa !23
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t187 = load i64, ptr %l11, !tbaa !24
  %t188 = load i32, ptr %l13, !tbaa !23
  %t191 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t187
  store i32 %t188, ptr %t193, !tbaa !33
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 32
  store ptr %t196, ptr %l105, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l106, !tbaa !29
  %t198 = load ptr, ptr %l12, !tbaa !29
  store ptr %t198, ptr %l107, !tbaa !29
  %t199 = load i32, ptr %l13, !tbaa !23
  store i32 %t199, ptr %l108, !tbaa !23
  %t200 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t200, ptr %l109, !tbaa !27
  %t201 = load i64, ptr %l11, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr ptr, ptr %t204, i64 %t201
  %t206 = load ptr, ptr %t205, !tbaa !39
  %t208 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t206)
  store %"compiler/source:Span" %t208, ptr %l112
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l106, !tbaa !29
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i32, ptr %l108, !tbaa !23
  %t212 = load %"compiler/source:Span", ptr %l112
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t209, ptr %t210, i32 %t211, %"compiler/source:Span" %t212)
  store ptr %t213, ptr %l113
  br label %bb39
bb39:
  %t214 = load ptr, ptr %l105, !tbaa !29
  %t215 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t214, ptr %t215)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t216 = load i64, ptr %l10, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l10, !tbaa !24
  br label %bb17
bb42:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 32
  %t223 = load i64, ptr %l4, !tbaa !24
  %t226 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t222, i64 %t223)
  store { i64, ptr } %t226, ptr %l119
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t227, ptr %l14, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t232 = icmp eq i64 %t230, 1
  br i1 %t232, label %bb44, label %bb45
bb44:
  %t234 = load ptr, ptr %l3, !tbaa !29
  %t235 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i32, ptr %t236, i64 0
  %t238 = load i32, ptr %t237, !tbaa !33
  %t241 = getelementptr %"compiler/check:frame", ptr %t234, i32 0, i32 5
  store i32 %t238, ptr %t241, !tbaa !23
  %t242 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t242, ptr %l125, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 0
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l15, !tbaa !29
  %t248 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = getelementptr i32, ptr %t249, i64 0
  %t251 = load i32, ptr %t250, !tbaa !33
  store i32 %t251, ptr %l127, !tbaa !23
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t252)
  store i32 %t254, ptr %l129
  br label %bb46
bb45:
  br label %bb57
bb46:
  %t255 = load i32, ptr %l127, !tbaa !23
  %t256 = load i32, ptr %l129, !tbaa !23
  %t257 = icmp eq i32 %t255, %t256
  br i1 %t257, label %bb47, label %bb48
bb47:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l132, !tbaa !29
  %t260 = load ptr, ptr %l15, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t260)
  store i32 %t263, ptr %l135
  br label %bb49
bb48:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb51
bb49:
  %t264 = load ptr, ptr %l132, !tbaa !29
  %t265 = load i32, ptr %l135, !tbaa !23
  %t266 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t264, i32 %t265)
  store i1 %t266, ptr %l136
  br label %bb50
bb50:
  %t267 = load i1, ptr %l136, !tbaa !21
  store i1 %t267, ptr %l131, !tbaa !21
  br label %bb51
bb51:
  %t268 = load i1, ptr %l131, !tbaa !21
  br i1 %t268, label %bb52, label %bb53
bb52:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 0
  %t275 = load i32, ptr %t274, !tbaa !33
  %t276 = load ptr, ptr %l15, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 0
  store i64 2, ptr %t278
  %t280 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t271, 0
  %t282 = insertvalue { %"compiler/source:Span", i32, ptr } %t280, i32 %t275, 1
  %t284 = insertvalue { %"compiler/source:Span", i32, ptr } %t282, ptr %t276, 2
  %t285 = getelementptr { i64, [4 x i64] }, ptr %t277, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t284, ptr %t285
  %t286 = load { i64, [4 x i64] }, ptr %t277
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t286, ptr %t288
  %t292 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t269, %"compiler/source:Span" %t270, ptr %t288)
  store ptr %t292, ptr %l144
  br label %bb54
bb53:
  br label %bb55
bb54:
  %t293 = load ptr, ptr %l144, !tbaa !29
  store ptr %t293, ptr %l15, !tbaa !29
  br label %bb55
bb55:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load %"compiler/source:Span", ptr %l1
  %t296 = load ptr, ptr %l15, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t298
  %t299 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 0
  store i64 6, ptr %t299
  %t301 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t295, 0
  %t303 = insertvalue { %"compiler/source:Span", ptr } %t301, ptr %t296, 1
  %t304 = getelementptr { i64, [3 x i64] }, ptr %t298, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t303, ptr %t304
  %t305 = load { i64, [3 x i64] }, ptr %t298
  %t307 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t305, ptr %t307
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t294, ptr %t307)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb57:
  %t310 = load ptr, ptr %l3, !tbaa !29
  store ptr %t310, ptr %l151, !tbaa !29
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/check:Checker", ptr %t311, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/generic:Program", ptr %t314, i32 0, i32 2
  store ptr %t316, ptr %l154, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  %t323 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t326 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t322, { i64, ptr } %t323)
  store i32 %t326, ptr %l159
  br label %bb58
bb58:
  %t327 = load ptr, ptr %l154, !tbaa !29
  %t328 = load i32, ptr %l159, !tbaa !23
  %t329 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t327, i32 %t328)
  store i32 %t329, ptr %l160
  br label %bb59
bb59:
  %t330 = load i32, ptr %l160, !tbaa !23
  %t331 = load ptr, ptr %l151, !tbaa !29
  %t332 = getelementptr %"compiler/check:frame", ptr %t331, i32 0, i32 5
  store i32 %t330, ptr %t332, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l161, !tbaa !29
  %t334 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t334, ptr %l162
  %t335 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t335, ptr %l163
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/check:frame", ptr %t336, i32 0, i32 5
  %t339 = load i32, ptr %t338, !tbaa !23
  store i32 %t339, ptr %l165, !tbaa !23
  %t340 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t344 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t340, ptr null, i32 -1, i32 0)
  store %"compiler/typed:Make" %t344, ptr %l169
  br label %bb60
bb60:
  %t345 = load %"compiler/typed:Make", ptr %l169
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t345, ptr %t346
  store { i64, [5 x i64] } zeroinitializer, ptr %t347
  %t348 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 0
  store i64 7, ptr %t348
  %t349 = load %"compiler/source:Span", ptr %l163
  %t350 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t349, 0
  %t351 = load i32, ptr %l165, !tbaa !23
  %t352 = insertvalue { %"compiler/source:Span", i32, ptr } %t350, i32 %t351, 1
  %t354 = insertvalue { %"compiler/source:Span", i32, ptr } %t352, ptr %t346, 2
  %t355 = getelementptr { i64, [5 x i64] }, ptr %t347, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t354, ptr %t355
  %t356 = load { i64, [5 x i64] }, ptr %t347
  %t358 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t356, ptr %t358
  store { i64, [3 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 0
  store i64 6, ptr %t360
  %t361 = load %"compiler/source:Span", ptr %l162
  %t362 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t361, 0
  %t364 = insertvalue { %"compiler/source:Span", ptr } %t362, ptr %t358, 1
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t359, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t364, ptr %t365
  %t366 = load { i64, [3 x i64] }, ptr %t359
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t366, ptr %t368
  %t369 = load ptr, ptr %l161, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t369, ptr %t368)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t17, i32 %a2)
  store i32 %t21, ptr %l14
  br label %bb2
bb2:
  %t22 = load i32, ptr %l14, !tbaa !23
  store i32 %t22, ptr %l4, !tbaa !23
  %t23 = load i32, ptr %l3, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = icmp eq i32 %t23, %t24
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb6
bb6:
  %t40 = load i32, ptr %l23
  %t42 = trunc i64 27 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb10
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l4, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l31
  br label %bb9
bb9:
  %t55 = load i32, ptr %l31
  %t57 = trunc i64 27 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l26, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l27 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t24, ptr %l19, !tbaa !27
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t37 = add i64 %a3, 1
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %t32, i32 %t30, %"compiler/source:Span" %a2, i64 %t37)
  store i1 %t42, ptr %l27
  br label %bb6
bb6:
  %t43 = load i1, ptr %l27, !tbaa !21
  %t44 = xor i1 %t43, true
  br i1 %t44, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb2
bb11:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t38 = alloca i64
  %t70 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb5:
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l19
  br label %bb6
bb6:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l19, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l20, !tbaa !23
  %t31 = icmp sge i64 1, 0
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = icmp sle i64 1, 2305843009213693951
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9c04d5f47d2250f6_3417b2e0d095e072)
  unreachable
bb9:
  %t35 = mul i64 1, 4
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = load i32, ptr %l20, !tbaa !23
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, 1
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i32, ptr %t36, i64 %t42
  store i32 %t37, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t36, 1
  %t48 = load ptr, ptr %l13, !tbaa !29
  %t50 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s0, ptr %t48, { i64, ptr } %t47)
  store i1 %t50, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9c04d5f47d2250f6_3417b2e0d095e072)
  unreachable
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  store i1 %t51, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l12, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l29
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t63 = load i32, ptr %l29, !tbaa !23
  store i32 %t63, ptr %l3, !tbaa !23
  br label %bb16
bb16:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = trunc i64 %t66 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 0
  store i64 0, ptr %t71
  %t73 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %a1, 0
  %t75 = insertvalue { %"compiler/source:Span", i32, i32 } %t73, i32 %t65, 1
  %t77 = insertvalue { %"compiler/source:Span", i32, i32 } %t75, i32 %t68, 2
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t77, ptr %t78
  %t79 = load { i64, [4 x i64] }, ptr %t70
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t79, ptr %t81
  call void @__olang_scope_close(ptr %s0)
  store ptr %t81, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 16, ptr @.d17 }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 11, ptr @.d18 }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t3, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l11, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l3, !tbaa !23
  br label %bb9
bb8:
  br label %bb29
bb9:
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t27, ptr %l22
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t30 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 42
  store ptr %t30, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t32, i64 %t33)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l29
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb13, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l28
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  br label %bb17
bb13:
  %t42 = load i32, ptr %l29, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d)
  unreachable
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb17:
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t61
  %t66 = load i64, ptr %t65, !tbaa !34
  %t69 = load i32, ptr %l3, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t74 = icmp eq i64 %t66, %t71
  br i1 %t74, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t77 = load i64, ptr %l8, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l8, !tbaa !24
  br label %bb18
bb26:
  %t81 = load i64, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l7, !tbaa !24
  %t85 = add i64 %t81, %t82
  store i64 %t85, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  br label %bb11
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/check:nullNarrow"
  %l13 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l37 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 44
  store ptr %t13, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H7b40d2e2dc0a1b98abd717d3c6137546(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, { i64, ptr } } %t19, 1
  %t21 = extractvalue { i32, { i64, ptr } } %t19, 0
  store i32 %t21, ptr %l20
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb7, label %ok.23
ok.23:
  store { i64, ptr } %t20, ptr %l19
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  br label %bb11
bb7:
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = ashr i32 %t25, 16
  %t28 = icmp eq i32 %t26, 1
  br i1 %t28, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_9c106c9f4aa088c5_d9578fd6b61bf4a9)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb11:
  %t30 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr %"compiler/check:nullNarrow", ptr %t47, i64 %t44
  %t49 = load %"compiler/check:nullNarrow", ptr %t48
  store %"compiler/check:nullNarrow" %t49, ptr %l7
  %t51 = getelementptr %"compiler/check:nullNarrow", ptr %l7, i32 0, i32 2
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = getelementptr %"compiler/check:nullNarrow", ptr %l7, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t61 = call i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %t57, { i64, ptr } %t58)
  store i1 %t61, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i1, ptr %l37, !tbaa !21
  store i1 %t62, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l6, !tbaa !24
  br label %bb12
bb24:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = add i64 %t69, %t70
  store i64 %t73, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  br label %bb5
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l90 = alloca { i64, ptr }
  %l96 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i32
  %l104 = alloca i1
  %l108 = alloca ptr
  %l112 = alloca i1
  %l115 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i64
  %l119 = alloca i64
  %l129 = alloca i64
  %l133 = alloca i64
  %l136 = alloca i64
  %l157 = alloca ptr
  %l166 = alloca i1
  %l170 = alloca ptr
  %l175 = alloca i1
  %l178 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca i64
  %l183 = alloca i64
  %l189 = alloca i64
  %l190 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l191 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l197 = alloca i32
  %l206 = alloca { i64, ptr }
  %l209 = alloca ptr
  %l211 = alloca i64
  %l215 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l217 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca i32
  %l230 = alloca { i64, ptr }
  %l233 = alloca ptr
  %l234 = alloca i64
  %l237 = alloca i64
  %l238 = alloca i32
  %l249 = alloca ptr
  %l251 = alloca i64
  %l252 = alloca i64
  %l263 = alloca i64
  %l266 = alloca i64
  %l288 = alloca i64
  %l292 = alloca i64
  %l296 = alloca i64
  %l299 = alloca i64
  %l319 = alloca i64
  %l321 = alloca i1
  %l324 = alloca i64
  %l336 = alloca ptr
  %l339 = alloca i64
  %l347 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l348 = alloca i64
  %l351 = alloca i64
  %l352 = alloca i32
  %l361 = alloca i64
  %l365 = alloca i64
  %l368 = alloca i64
  %l388 = alloca i64
  %l389 = alloca ptr
  %l390 = alloca ptr
  %l393 = alloca i64
  %l394 = alloca i64
  %l403 = alloca i64
  %l407 = alloca i64
  %l411 = alloca i64
  %l414 = alloca i64
  %l434 = alloca i1
  %l437 = alloca i64
  %l439 = alloca i1
  %l442 = alloca i64
  %l447 = alloca i64
  %l456 = alloca i64
  %l459 = alloca i64
  %l481 = alloca ptr
  %l484 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s44 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l73
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t4)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l74
  br label %bb2
bb2:
  %t6 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 25
  store ptr %t9, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Ha95900cb572ddce4e68e0f318299e6b4(ptr %v0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l81
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l80
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t20, ptr %l77, !tbaa !27
  br label %bb9
bb5:
  %t21 = load i32, ptr %l81, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_eb65b3680edb0345_685145072e457a11)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb38
bb9:
  %t26 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t39, ptr %l90, !tbaa !27
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t43, i64 %t40
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %t44
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45, ptr %l10
  %t47 = getelementptr %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = icmp ne i64 %t48, %t49
  br i1 %t52, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb15:
  br label %bb16
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 23
  %t57 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  %t60 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t56, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t57)
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l101
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb18, label %ok.64
ok.64:
  store i64 %t61, ptr %l100
  br label %bb17
bb17:
  %t65 = load i64, ptr %l100, !tbaa !24
  store i64 %t65, ptr %l96, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l96, !tbaa !24
  br label %bb20
bb20:
  %t66 = load i64, ptr %l96, !tbaa !24
  store i64 %t66, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l11, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb24
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 11
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store ptr %t77, ptr %l108
  br label %bb23
bb23:
  %t78 = load ptr, ptr %l108, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Body", ptr %t78, i32 0, i32 11
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  store i1 %t83, ptr %l104, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l104, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l112, !tbaa !21
  br label %bb28
bb26:
  %t86 = load i64, ptr %l11, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t86)
  store i1 %t89, ptr %l115
  br label %bb27
bb27:
  %t90 = load i1, ptr %l115, !tbaa !21
  store i1 %t90, ptr %l112, !tbaa !21
  br label %bb28
bb28:
  %t91 = load i1, ptr %l112, !tbaa !21
  br i1 %t91, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb30:
  br label %bb31
bb31:
  store ptr %l4, ptr %l116, !tbaa !29
  %t92 = load i64, ptr %l11, !tbaa !24
  store i64 %t92, ptr %l117, !tbaa !24
  %t94 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t94, ptr %l119
  br label %bb32
bb32:
  %t95 = load ptr, ptr %l116, !tbaa !29
  %t96 = load i64, ptr %l117, !tbaa !24
  %t97 = load i64, ptr %l119, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t95, i64 %t96, i64 %t97)
  br label %bb33
bb33:
  %t98 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t98)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t103 = add i64 %t101, 1
  store i64 %t103, ptr %l9, !tbaa !24
  br label %bb10
bb36:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t105, %t106
  store i64 %t109, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb37:
  br label %bb3
bb38:
  store i64 0, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 11
  %t115 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t113)
  store i64 %t115, ptr %l129
  br label %bb39
bb39:
  %t116 = load i64, ptr %l129, !tbaa !24
  store i64 %t116, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb40, label %bb41
bb40:
  %t123 = load i64, ptr %l14, !tbaa !24
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l133, !tbaa !24
  br label %bb45
bb42:
  %t127 = load i64, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t132 = load i64, ptr %l14, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = sub i64 %t135, 1
  %t138 = load i64, ptr %l14, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l136, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l136, !tbaa !24
  br label %bb44
bb44:
  %t143 = load i64, ptr %l136, !tbaa !24
  store i64 %t143, ptr %l133, !tbaa !24
  br label %bb45
bb45:
  %t144 = load i64, ptr %l133, !tbaa !24
  store i64 %t144, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s8
  %t145 = load i64, ptr %l16, !tbaa !24
  %t146 = load i64, ptr %l15, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb75
bb48:
  br label %bb49
bb49:
  %t153 = load i64, ptr %l12, !tbaa !24
  %t154 = load i64, ptr %l16, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  store i64 %t161, ptr %l17, !tbaa !24
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 11
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t165, i64 %t166)
  store ptr %t169, ptr %l157
  br label %bb50
bb50:
  %t170 = load ptr, ptr %l157, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 1
  %t173 = load { i64, [2 x i64] }, ptr %t172
  store { i64, [2 x i64] } %t173, ptr %l18
  %t175 = load { i64, [2 x i64] }, ptr %l18
  %t177 = extractvalue { i64, [2 x i64] } %t175, 0
  %t178 = icmp eq i64 %t177, 6
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t180 = getelementptr { i64, [2 x i64] }, ptr %l18, i32 0, i32 1
  %t181 = getelementptr { i64, i32 }, ptr %t180, i32 0, i32 0
  %t182 = load i64, ptr %t181
  store i64 %t182, ptr %l19, !tbaa !24
  br label %bb53
bb52:
  br label %bb68
bb53:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l1, !tbaa !24
  %t188 = icmp eq i64 %t184, %t185
  br i1 %t188, label %bb54, label %bb55
bb54:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/check:Checker", ptr %t190, i32 0, i32 11
  %t193 = load i64, ptr %l17, !tbaa !24
  %t196 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t192, i64 %t193)
  store ptr %t196, ptr %l170
  br label %bb56
bb55:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb57
bb56:
  %t197 = load ptr, ptr %l170, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Body", ptr %t197, i32 0, i32 11
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  %t204 = xor i1 %t202, true
  store i1 %t204, ptr %l166, !tbaa !21
  br label %bb57
bb57:
  %t206 = load i1, ptr %l166, !tbaa !21
  br i1 %t206, label %bb58, label %bb59
bb58:
  %t207 = load i64, ptr %l17, !tbaa !24
  %t210 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t207)
  store i1 %t210, ptr %l178
  br label %bb60
bb59:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb61
bb60:
  %t211 = load i1, ptr %l178, !tbaa !21
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l175, !tbaa !21
  br label %bb61
bb61:
  %t214 = load i1, ptr %l175, !tbaa !21
  br i1 %t214, label %bb62, label %bb63
bb62:
  store ptr %l4, ptr %l180, !tbaa !29
  %t215 = load i64, ptr %l17, !tbaa !24
  store i64 %t215, ptr %l181, !tbaa !24
  %t217 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t217, ptr %l183
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t218 = load ptr, ptr %l180, !tbaa !29
  %t219 = load i64, ptr %l181, !tbaa !24
  %t220 = load i64, ptr %l183, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %s0, ptr %t218, i64 %t219, i64 %t220)
  br label %bb65
bb65:
  %t221 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t221)
  br label %bb66
bb66:
  br label %bb67
bb67:
  br label %bb73
bb68:
  br i1 true, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_bd75af4b3ae4d294_e659e9e595aa9980)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb74
bb74:
  %t224 = load i64, ptr %l16, !tbaa !24
  %t226 = add i64 %t224, 1
  store i64 %t226, ptr %l16, !tbaa !24
  br label %bb46
bb75:
  %t229 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t229, ptr %l189
  br label %bb76
bb76:
  %t230 = load i64, ptr %l189, !tbaa !24
  store i64 %t230, ptr %l20, !tbaa !24
  %t231 = load ptr, ptr @__olang_prog_scope
  %t232 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t231)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l190
  br label %bb77
bb77:
  %t233 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l190
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l21
  %t234 = load ptr, ptr @__olang_prog_scope
  %t235 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t234)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t235, ptr %l191
  br label %bb78
bb78:
  %t236 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l191
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %l22
  store ptr %l3, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t238 = load ptr, ptr %l23, !tbaa !29
  %t239 = load i64, ptr %l24, !tbaa !24
  %t242 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t238, i64 %t239)
  %t243 = extractvalue { i32, { i64, ptr } } %t242, 1
  %t244 = extractvalue { i32, { i64, ptr } } %t242, 0
  store i32 %t244, ptr %l197
  %t245 = icmp ne i32 %t244, 0
  br i1 %t245, label %bb81, label %ok.246
ok.246:
  store { i64, ptr } %t243, ptr %l196
  br label %bb80
bb80:
  %t247 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t247, ptr %l193, !tbaa !27
  br label %bb85
bb81:
  %t248 = load i32, ptr %l197, !tbaa !23
  %t249 = ashr i32 %t248, 16
  %t251 = icmp eq i32 %t249, 1
  br i1 %t251, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_check_failed(ptr @olang_loc_bbebe2756c1f74cf_e5643b8f6a3fbcfb)
  unreachable
bb84:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb85:
  %t253 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t253, ptr %l25, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 0
  store i64 %t256, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s15
  %t258 = load i64, ptr %l27, !tbaa !24
  %t259 = load i64, ptr %l26, !tbaa !24
  %t262 = icmp slt i64 %t258, %t259
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s15)
  br label %bb114
bb88:
  br label %bb89
bb89:
  %t266 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t266, ptr %l206, !tbaa !27
  %t267 = load i64, ptr %l27, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i64, ptr %t270, i64 %t267
  %t272 = load i64, ptr %t271, !tbaa !34
  store i64 %t272, ptr %l28, !tbaa !24
  store ptr %l21, ptr %l209, !tbaa !29
  %t275 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l22)
  store i64 %t275, ptr %l211
  br label %bb90
bb90:
  %t276 = load ptr, ptr %l209, !tbaa !29
  %t277 = load i64, ptr %l211, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t276, i64 %t277)
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s16
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l1, !tbaa !24
  %t280 = load i64, ptr %l28, !tbaa !24
  %t284 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %s16, ptr %t278, i64 %t279, i64 %t280)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t284, ptr %l215
  br label %bb92
bb92:
  %t285 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l215
  %t286 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t285, ptr %t286
  store ptr %t286, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s17
  %t288 = load ptr, ptr %l29, !tbaa !29
  %t289 = load i64, ptr %l30, !tbaa !24
  %t292 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s16, ptr %t288, i64 %t289)
  %t293 = extractvalue { i32, { i64, ptr } } %t292, 1
  %t294 = extractvalue { i32, { i64, ptr } } %t292, 0
  store i32 %t294, ptr %l221
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb95, label %ok.296
ok.296:
  store { i64, ptr } %t293, ptr %l220
  br label %bb94
bb94:
  %t297 = load { i64, ptr }, ptr %l220, !tbaa !27
  store { i64, ptr } %t297, ptr %l217, !tbaa !27
  br label %bb99
bb95:
  %t298 = load i32, ptr %l221, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  br i1 %t301, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_8acdd28853e9448e_36c5d2b255a9987a)
  unreachable
bb98:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb112
bb99:
  %t303 = load { i64, ptr }, ptr %l217, !tbaa !27
  store { i64, ptr } %t303, ptr %l31, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  store i64 %t306, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t308 = load i64, ptr %l33, !tbaa !24
  %t309 = load i64, ptr %l32, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb110
bb102:
  br label %bb103
bb103:
  %t316 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t316, ptr %l230, !tbaa !27
  %t317 = load i64, ptr %l33, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr i64, ptr %t320, i64 %t317
  %t322 = load i64, ptr %t321, !tbaa !34
  store ptr %l22, ptr %l233, !tbaa !29
  %t327 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %l4, i64 %t322)
  %t328 = extractvalue { i32, i64 } %t327, 1
  %t329 = extractvalue { i32, i64 } %t327, 0
  store i32 %t329, ptr %l238
  %t330 = icmp ne i32 %t329, 0
  br i1 %t330, label %bb105, label %ok.331
ok.331:
  store i64 %t328, ptr %l237
  br label %bb104
bb104:
  %t332 = load i64, ptr %l237, !tbaa !24
  store i64 %t332, ptr %l234, !tbaa !24
  br label %bb107
bb105:
  br label %bb106
bb106:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l234, !tbaa !24
  br label %bb107
bb107:
  %t333 = load ptr, ptr %l233, !tbaa !29
  %t334 = load i64, ptr %l234, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t333, i64 %t334)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb109:
  %t335 = load i64, ptr %l33, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l33, !tbaa !24
  br label %bb100
bb110:
  %t339 = load i64, ptr %l30, !tbaa !24
  %t340 = load i64, ptr %l32, !tbaa !24
  %t343 = add i64 %t339, %t340
  store i64 %t343, ptr %l30, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  br label %bb93
bb112:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  br label %bb113
bb113:
  %t345 = load i64, ptr %l27, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l27, !tbaa !24
  br label %bb86
bb114:
  %t349 = load i64, ptr %l24, !tbaa !24
  %t350 = load i64, ptr %l26, !tbaa !24
  %t353 = add i64 %t349, %t350
  store i64 %t353, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb115
bb115:
  br label %bb79
bb116:
  store ptr %l21, ptr %l249, !tbaa !29
  %t356 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l22)
  store i64 %t356, ptr %l251
  br label %bb117
bb117:
  %t357 = load ptr, ptr %l249, !tbaa !29
  %t358 = load i64, ptr %l251, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t357, i64 %t358)
  br label %bb118
bb118:
  %t359 = load i64, ptr %l20, !tbaa !24
  store i64 %t359, ptr %l252, !tbaa !24
  %t360 = load i64, ptr %l252, !tbaa !24
  %t361 = icmp sge i64 %t360, 0
  br i1 %t361, label %bb119, label %bb120
bb119:
  %t363 = load i64, ptr %l252, !tbaa !24
  %t364 = mul i64 %t363, 1
  %t365 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t364)
  %t366 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t365, 1
  store { i64, ptr } %t367, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_5a7b482711619cea_7bdfef37448fa616)
  unreachable
bb121:
  store %olang.scope zeroinitializer, ptr %s21
  %t369 = load i64, ptr %l36, !tbaa !24
  %t370 = load i64, ptr %l20, !tbaa !24
  %t373 = icmp slt i64 %t369, %t370
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s21)
  br label %bb253
bb123:
  br label %bb124
bb124:
  store i64 -1, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  %t377 = load i64, ptr %l20, !tbaa !24
  store i64 %t377, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t379 = load i64, ptr %l39, !tbaa !24
  %t380 = load i64, ptr %l38, !tbaa !24
  %t383 = icmp sgt i64 %t379, %t380
  br i1 %t383, label %bb125, label %bb126
bb125:
  %t385 = load i64, ptr %l40, !tbaa !24
  %t387 = icmp sgt i64 %t385, 0
  br i1 %t387, label %bb127, label %bb128
bb126:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb130
bb127:
  %t389 = load i64, ptr %l39, !tbaa !24
  %t390 = load i64, ptr %l38, !tbaa !24
  %t393 = sub i64 %t389, %t390
  %t394 = load i64, ptr %l40, !tbaa !24
  %t397 = add i64 %t393, %t394
  %t399 = sub i64 %t397, 1
  %t400 = load i64, ptr %l40, !tbaa !24
  %t403 = sdiv i64 %t399, %t400
  store i64 %t403, ptr %l266, !tbaa !24
  br label %bb129
bb128:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb129
bb129:
  %t405 = load i64, ptr %l266, !tbaa !24
  store i64 %t405, ptr %l263, !tbaa !24
  br label %bb130
bb130:
  %t406 = load i64, ptr %l263, !tbaa !24
  store i64 %t406, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb131
bb131:
  store %olang.scope zeroinitializer, ptr %s23
  %t407 = load i64, ptr %l42, !tbaa !24
  %t408 = load i64, ptr %l41, !tbaa !24
  %t411 = icmp slt i64 %t407, %t408
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb132, label %bb133
bb132:
  call void @__olang_scope_close(ptr %s23)
  br label %bb164
bb133:
  br label %bb134
bb134:
  %t415 = load i64, ptr %l38, !tbaa !24
  %t416 = load i64, ptr %l42, !tbaa !24
  %t417 = load i64, ptr %l40, !tbaa !24
  %t420 = mul i64 %t416, %t417
  %t423 = add i64 %t415, %t420
  store i64 %t423, ptr %l43, !tbaa !24
  %t425 = load i64, ptr %l43, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr i1, ptr %t428, i64 %t425
  %t430 = load i1, ptr %t429, !tbaa !31
  br i1 %t430, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s23)
  br label %bb163
bb136:
  br label %bb137
bb137:
  store i1 true, ptr %l44, !tbaa !21
  %t432 = load i64, ptr %l43, !tbaa !24
  %t435 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t432)
  store i64 %t435, ptr %l288
  br label %bb138
bb138:
  %t436 = load i64, ptr %l288, !tbaa !24
  store i64 %t436, ptr %l45, !tbaa !24
  %t437 = load i64, ptr %l43, !tbaa !24
  %t439 = add i64 %t437, 1
  %t442 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t439)
  store i64 %t442, ptr %l292
  br label %bb139
bb139:
  %t443 = load i64, ptr %l292, !tbaa !24
  store i64 %t443, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t444 = load i64, ptr %l46, !tbaa !24
  %t445 = load i64, ptr %l45, !tbaa !24
  %t448 = icmp sgt i64 %t444, %t445
  br i1 %t448, label %bb140, label %bb141
bb140:
  %t450 = load i64, ptr %l47, !tbaa !24
  %t452 = icmp sgt i64 %t450, 0
  br i1 %t452, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l296, !tbaa !24
  br label %bb145
bb142:
  %t454 = load i64, ptr %l46, !tbaa !24
  %t455 = load i64, ptr %l45, !tbaa !24
  %t458 = sub i64 %t454, %t455
  %t459 = load i64, ptr %l47, !tbaa !24
  %t462 = add i64 %t458, %t459
  %t464 = sub i64 %t462, 1
  %t465 = load i64, ptr %l47, !tbaa !24
  %t468 = sdiv i64 %t464, %t465
  store i64 %t468, ptr %l299, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l299, !tbaa !24
  br label %bb144
bb144:
  %t470 = load i64, ptr %l299, !tbaa !24
  store i64 %t470, ptr %l296, !tbaa !24
  br label %bb145
bb145:
  %t471 = load i64, ptr %l296, !tbaa !24
  store i64 %t471, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s26
  %t472 = load i64, ptr %l49, !tbaa !24
  %t473 = load i64, ptr %l48, !tbaa !24
  %t476 = icmp slt i64 %t472, %t473
  %t478 = xor i1 %t476, true
  br i1 %t478, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s26)
  br label %bb159
bb148:
  br label %bb149
bb149:
  %t480 = load i64, ptr %l45, !tbaa !24
  %t481 = load i64, ptr %l49, !tbaa !24
  %t482 = load i64, ptr %l47, !tbaa !24
  %t485 = mul i64 %t481, %t482
  %t488 = add i64 %t480, %t485
  store i64 %t488, ptr %l50, !tbaa !24
  %t490 = load i64, ptr %l50, !tbaa !24
  %t493 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t490)
  store i64 %t493, ptr %l319
  br label %bb150
bb150:
  %t494 = load i64, ptr %l319, !tbaa !24
  %t495 = icmp sge i64 %t494, 0
  br i1 %t495, label %bb151, label %bb152
bb151:
  %t497 = load i64, ptr %l50, !tbaa !24
  %t500 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t497)
  store i64 %t500, ptr %l324
  br label %bb153
bb152:
  store i1 false, ptr %l321, !tbaa !21
  br label %bb154
bb153:
  %t501 = load i64, ptr %l324, !tbaa !24
  %t502 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr i1, ptr %t503, i64 %t501
  %t505 = load i1, ptr %t504, !tbaa !31
  %t507 = xor i1 %t505, true
  store i1 %t507, ptr %l321, !tbaa !21
  br label %bb154
bb154:
  %t509 = load i1, ptr %l321, !tbaa !21
  br i1 %t509, label %bb155, label %bb156
bb155:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb157
bb156:
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s26)
  br label %bb158
bb158:
  %t510 = load i64, ptr %l49, !tbaa !24
  %t512 = add i64 %t510, 1
  store i64 %t512, ptr %l49, !tbaa !24
  br label %bb146
bb159:
  %t514 = load i1, ptr %l44, !tbaa !21
  br i1 %t514, label %bb160, label %bb161
bb160:
  %t516 = load i64, ptr %l43, !tbaa !24
  store i64 %t516, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb164
bb161:
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s23)
  br label %bb163
bb163:
  %t518 = load i64, ptr %l42, !tbaa !24
  %t520 = add i64 %t518, 1
  store i64 %t520, ptr %l42, !tbaa !24
  br label %bb131
bb164:
  %t522 = load i64, ptr %l37, !tbaa !24
  %t524 = icmp sge i64 %t522, 0
  br i1 %t524, label %bb165, label %bb166
bb165:
  %t526 = load i64, ptr %l37, !tbaa !24
  %t528 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr i1, ptr %t529, i64 %t526
  store i1 true, ptr %t530, !tbaa !31
  %t531 = load ptr, ptr %l2, !tbaa !29
  store ptr %t531, ptr %l336, !tbaa !29
  %t532 = load i64, ptr %l37, !tbaa !24
  %t535 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t532)
  store i64 %t535, ptr %l339
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t536 = load ptr, ptr %l336, !tbaa !29
  %t537 = load i64, ptr %l339, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t536, i64 %t537)
  br label %bb168
bb168:
  %t538 = load i64, ptr %l36, !tbaa !24
  %t540 = add i64 %t538, 1
  store i64 %t540, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb252
bb169:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb170
bb170:
  store %olang.scope zeroinitializer, ptr %s32
  %t542 = load i64, ptr %l51, !tbaa !24
  %t544 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr i1, ptr %t545, i64 %t542
  %t547 = load i1, ptr %t546, !tbaa !31
  %t549 = xor i1 %t547, true
  br i1 %t549, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s32)
  br label %bb175
bb172:
  br label %bb173
bb173:
  %t551 = load i64, ptr %l51, !tbaa !24
  %t553 = add i64 %t551, 1
  store i64 %t553, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s32)
  br label %bb174
bb174:
  br label %bb170
bb175:
  %t555 = load ptr, ptr @__olang_prog_scope
  %t556 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t555)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t556, ptr %l347
  br label %bb176
bb176:
  %t557 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l347
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t557, ptr %l52
  br label %bb177
bb177:
  store %olang.scope zeroinitializer, ptr %s33
  %t558 = load i64, ptr %l51, !tbaa !24
  %t561 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eIndexOf_3cI64_3e(ptr %s21, ptr %l52, i64 %t558)
  %t562 = extractvalue { i32, i64 } %t561, 1
  %t563 = extractvalue { i32, i64 } %t561, 0
  store i32 %t563, ptr %l352
  %t564 = icmp ne i32 %t563, 0
  br i1 %t564, label %bb179, label %ok.565
ok.565:
  store i64 %t562, ptr %l351
  br label %bb178
bb178:
  %t566 = load i64, ptr %l351, !tbaa !24
  store i64 %t566, ptr %l348, !tbaa !24
  br label %bb181
bb179:
  br label %bb180
bb180:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l348, !tbaa !24
  br label %bb181
bb181:
  %t567 = load i64, ptr %l348, !tbaa !24
  store i64 %t567, ptr %l53, !tbaa !24
  %t568 = load i64, ptr %l53, !tbaa !24
  %t570 = icmp sge i64 %t568, 0
  br i1 %t570, label %bb182, label %bb183
bb182:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t573 = load i64, ptr %l53, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %s0, ptr %s21, ptr %t572, ptr %l3, ptr %l52, i64 %t573)
  br label %bb184
bb183:
  br label %bb202
bb184:
  %t578 = load i64, ptr %l53, !tbaa !24
  store i64 %t578, ptr %l54, !tbaa !24
  %t581 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s21, ptr %l52)
  store i64 %t581, ptr %l361
  br label %bb185
bb185:
  %t582 = load i64, ptr %l361, !tbaa !24
  store i64 %t582, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t583 = load i64, ptr %l55, !tbaa !24
  %t584 = load i64, ptr %l54, !tbaa !24
  %t587 = icmp sgt i64 %t583, %t584
  br i1 %t587, label %bb186, label %bb187
bb186:
  %t589 = load i64, ptr %l56, !tbaa !24
  %t591 = icmp sgt i64 %t589, 0
  br i1 %t591, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l365, !tbaa !24
  br label %bb191
bb188:
  %t593 = load i64, ptr %l55, !tbaa !24
  %t594 = load i64, ptr %l54, !tbaa !24
  %t597 = sub i64 %t593, %t594
  %t598 = load i64, ptr %l56, !tbaa !24
  %t601 = add i64 %t597, %t598
  %t603 = sub i64 %t601, 1
  %t604 = load i64, ptr %l56, !tbaa !24
  %t607 = sdiv i64 %t603, %t604
  store i64 %t607, ptr %l368, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l368, !tbaa !24
  br label %bb190
bb190:
  %t609 = load i64, ptr %l368, !tbaa !24
  store i64 %t609, ptr %l365, !tbaa !24
  br label %bb191
bb191:
  %t610 = load i64, ptr %l365, !tbaa !24
  store i64 %t610, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s36
  %t611 = load i64, ptr %l58, !tbaa !24
  %t612 = load i64, ptr %l57, !tbaa !24
  %t615 = icmp slt i64 %t611, %t612
  %t617 = xor i1 %t615, true
  br i1 %t617, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s36)
  br label %bb201
bb194:
  br label %bb195
bb195:
  %t619 = load i64, ptr %l54, !tbaa !24
  %t620 = load i64, ptr %l58, !tbaa !24
  %t621 = load i64, ptr %l56, !tbaa !24
  %t624 = mul i64 %t620, %t621
  %t627 = add i64 %t619, %t624
  store i64 %t627, ptr %l59, !tbaa !24
  %t629 = load i64, ptr %l59, !tbaa !24
  %t632 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s21, ptr %l52, i64 %t629)
  store i64 %t632, ptr %l388
  br label %bb196
bb196:
  %t633 = load i64, ptr %l388, !tbaa !24
  %t634 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !27
  %t636 = getelementptr i1, ptr %t635, i64 %t633
  store i1 true, ptr %t636, !tbaa !31
  %t637 = load ptr, ptr %l2, !tbaa !29
  store ptr %t637, ptr %l389, !tbaa !29
  store ptr %l3, ptr %l390, !tbaa !29
  %t638 = load i64, ptr %l59, !tbaa !24
  %t641 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s21, ptr %l52, i64 %t638)
  store i64 %t641, ptr %l393
  br label %bb197
bb197:
  %t642 = load ptr, ptr %l390, !tbaa !29
  %t643 = load i64, ptr %l393, !tbaa !24
  %t644 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t642, i64 %t643)
  store i64 %t644, ptr %l394
  br label %bb198
bb198:
  %t645 = load ptr, ptr %l389, !tbaa !29
  %t646 = load i64, ptr %l394, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t645, i64 %t646)
  br label %bb199
bb199:
  %t647 = load i64, ptr %l36, !tbaa !24
  %t649 = add i64 %t647, 1
  store i64 %t649, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s36)
  br label %bb200
bb200:
  %t651 = load i64, ptr %l58, !tbaa !24
  %t653 = add i64 %t651, 1
  store i64 %t653, ptr %l58, !tbaa !24
  br label %bb192
bb201:
  call void @__olang_scope_close(ptr %s33)
  br label %bb251
bb202:
  %t655 = load i64, ptr %l51, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s21, ptr %l52, i64 %t655)
  br label %bb203
bb203:
  store i64 -1, ptr %l60, !tbaa !24
  %t658 = load i64, ptr %l51, !tbaa !24
  %t661 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t658)
  store i64 %t661, ptr %l403
  br label %bb204
bb204:
  %t662 = load i64, ptr %l403, !tbaa !24
  store i64 %t662, ptr %l61, !tbaa !24
  %t663 = load i64, ptr %l51, !tbaa !24
  %t665 = add i64 %t663, 1
  %t668 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l21, i64 %t665)
  store i64 %t668, ptr %l407
  br label %bb205
bb205:
  %t669 = load i64, ptr %l407, !tbaa !24
  store i64 %t669, ptr %l62, !tbaa !24
  store i64 1, ptr %l63, !tbaa !24
  %t670 = load i64, ptr %l62, !tbaa !24
  %t671 = load i64, ptr %l61, !tbaa !24
  %t674 = icmp sgt i64 %t670, %t671
  br i1 %t674, label %bb206, label %bb207
bb206:
  %t676 = load i64, ptr %l63, !tbaa !24
  %t678 = icmp sgt i64 %t676, 0
  br i1 %t678, label %bb208, label %bb209
bb207:
  store i64 0, ptr %l411, !tbaa !24
  br label %bb211
bb208:
  %t680 = load i64, ptr %l62, !tbaa !24
  %t681 = load i64, ptr %l61, !tbaa !24
  %t684 = sub i64 %t680, %t681
  %t685 = load i64, ptr %l63, !tbaa !24
  %t688 = add i64 %t684, %t685
  %t690 = sub i64 %t688, 1
  %t691 = load i64, ptr %l63, !tbaa !24
  %t694 = sdiv i64 %t690, %t691
  store i64 %t694, ptr %l414, !tbaa !24
  br label %bb210
bb209:
  store i64 0, ptr %l414, !tbaa !24
  br label %bb210
bb210:
  %t696 = load i64, ptr %l414, !tbaa !24
  store i64 %t696, ptr %l411, !tbaa !24
  br label %bb211
bb211:
  %t697 = load i64, ptr %l411, !tbaa !24
  store i64 %t697, ptr %l64, !tbaa !24
  store i64 0, ptr %l65, !tbaa !24
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s39
  %t698 = load i64, ptr %l65, !tbaa !24
  %t699 = load i64, ptr %l64, !tbaa !24
  %t702 = icmp slt i64 %t698, %t699
  %t704 = xor i1 %t702, true
  br i1 %t704, label %bb213, label %bb214
bb213:
  call void @__olang_scope_close(ptr %s39)
  br label %bb229
bb214:
  br label %bb215
bb215:
  %t706 = load i64, ptr %l61, !tbaa !24
  %t707 = load i64, ptr %l65, !tbaa !24
  %t708 = load i64, ptr %l63, !tbaa !24
  %t711 = mul i64 %t707, %t708
  %t714 = add i64 %t706, %t711
  store i64 %t714, ptr %l66, !tbaa !24
  %t716 = load i64, ptr %l60, !tbaa !24
  %t718 = icmp slt i64 %t716, 0
  br i1 %t718, label %bb216, label %bb217
bb216:
  %t720 = load i64, ptr %l66, !tbaa !24
  %t723 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t720)
  store i64 %t723, ptr %l437
  br label %bb218
bb217:
  store i1 false, ptr %l434, !tbaa !21
  br label %bb219
bb218:
  %t724 = load i64, ptr %l437, !tbaa !24
  %t725 = icmp sge i64 %t724, 0
  store i1 %t725, ptr %l434, !tbaa !21
  br label %bb219
bb219:
  %t727 = load i1, ptr %l434, !tbaa !21
  br i1 %t727, label %bb220, label %bb221
bb220:
  %t728 = load i64, ptr %l66, !tbaa !24
  %t731 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t728)
  store i64 %t731, ptr %l442
  br label %bb222
bb221:
  store i1 false, ptr %l439, !tbaa !21
  br label %bb223
bb222:
  %t732 = load i64, ptr %l442, !tbaa !24
  %t733 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t734 = load ptr, ptr %t733, !tbaa !27
  %t735 = getelementptr i1, ptr %t734, i64 %t732
  %t736 = load i1, ptr %t735, !tbaa !31
  %t738 = xor i1 %t736, true
  store i1 %t738, ptr %l439, !tbaa !21
  br label %bb223
bb223:
  %t740 = load i1, ptr %l439, !tbaa !21
  br i1 %t740, label %bb224, label %bb225
bb224:
  %t741 = load i64, ptr %l66, !tbaa !24
  %t744 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l22, i64 %t741)
  store i64 %t744, ptr %l447
  br label %bb226
bb225:
  br label %bb227
bb226:
  %t745 = load i64, ptr %l447, !tbaa !24
  store i64 %t745, ptr %l60, !tbaa !24
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s39)
  br label %bb228
bb228:
  %t746 = load i64, ptr %l65, !tbaa !24
  %t748 = add i64 %t746, 1
  store i64 %t748, ptr %l65, !tbaa !24
  br label %bb212
bb229:
  %t750 = load i64, ptr %l60, !tbaa !24
  %t752 = icmp slt i64 %t750, 0
  br i1 %t752, label %bb230, label %bb231
bb230:
  store i64 0, ptr %l67, !tbaa !24
  %t754 = load i64, ptr %l20, !tbaa !24
  store i64 %t754, ptr %l68, !tbaa !24
  store i64 1, ptr %l69, !tbaa !24
  %t756 = load i64, ptr %l68, !tbaa !24
  %t757 = load i64, ptr %l67, !tbaa !24
  %t760 = icmp sgt i64 %t756, %t757
  br i1 %t760, label %bb232, label %bb233
bb231:
  br label %bb249
bb232:
  %t762 = load i64, ptr %l69, !tbaa !24
  %t764 = icmp sgt i64 %t762, 0
  br i1 %t764, label %bb234, label %bb235
bb233:
  store i64 0, ptr %l456, !tbaa !24
  br label %bb237
bb234:
  %t766 = load i64, ptr %l68, !tbaa !24
  %t767 = load i64, ptr %l67, !tbaa !24
  %t770 = sub i64 %t766, %t767
  %t771 = load i64, ptr %l69, !tbaa !24
  %t774 = add i64 %t770, %t771
  %t776 = sub i64 %t774, 1
  %t777 = load i64, ptr %l69, !tbaa !24
  %t780 = sdiv i64 %t776, %t777
  store i64 %t780, ptr %l459, !tbaa !24
  br label %bb236
bb235:
  store i64 0, ptr %l459, !tbaa !24
  br label %bb236
bb236:
  %t782 = load i64, ptr %l459, !tbaa !24
  store i64 %t782, ptr %l456, !tbaa !24
  br label %bb237
bb237:
  %t783 = load i64, ptr %l456, !tbaa !24
  store i64 %t783, ptr %l70, !tbaa !24
  store i64 0, ptr %l71, !tbaa !24
  br label %bb238
bb238:
  store %olang.scope zeroinitializer, ptr %s44
  %t784 = load i64, ptr %l71, !tbaa !24
  %t785 = load i64, ptr %l70, !tbaa !24
  %t788 = icmp slt i64 %t784, %t785
  %t790 = xor i1 %t788, true
  br i1 %t790, label %bb239, label %bb240
bb239:
  call void @__olang_scope_close(ptr %s44)
  br label %bb248
bb240:
  br label %bb241
bb241:
  %t792 = load i64, ptr %l67, !tbaa !24
  %t793 = load i64, ptr %l71, !tbaa !24
  %t794 = load i64, ptr %l69, !tbaa !24
  %t797 = mul i64 %t793, %t794
  %t800 = add i64 %t792, %t797
  store i64 %t800, ptr %l72, !tbaa !24
  %t802 = load i64, ptr %l72, !tbaa !24
  %t804 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t805 = load ptr, ptr %t804, !tbaa !27
  %t806 = getelementptr i1, ptr %t805, i64 %t802
  %t807 = load i1, ptr %t806, !tbaa !31
  %t809 = xor i1 %t807, true
  br i1 %t809, label %bb242, label %bb243
bb242:
  %t811 = load i64, ptr %l72, !tbaa !24
  %t813 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t814 = load ptr, ptr %t813, !tbaa !27
  %t815 = getelementptr i1, ptr %t814, i64 %t811
  store i1 true, ptr %t815, !tbaa !31
  %t816 = load ptr, ptr %l2, !tbaa !29
  store ptr %t816, ptr %l481, !tbaa !29
  %t817 = load i64, ptr %l72, !tbaa !24
  %t820 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t817)
  store i64 %t820, ptr %l484
  br label %bb244
bb243:
  br label %bb246
bb244:
  %t821 = load ptr, ptr %l481, !tbaa !29
  %t822 = load i64, ptr %l484, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t821, i64 %t822)
  br label %bb245
bb245:
  %t823 = load i64, ptr %l36, !tbaa !24
  %t825 = add i64 %t823, 1
  store i64 %t825, ptr %l36, !tbaa !24
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s44)
  br label %bb247
bb247:
  %t827 = load i64, ptr %l71, !tbaa !24
  %t829 = add i64 %t827, 1
  store i64 %t829, ptr %l71, !tbaa !24
  br label %bb238
bb248:
  call void @__olang_scope_close(ptr %s33)
  br label %bb251
bb249:
  %t831 = load i64, ptr %l60, !tbaa !24
  store i64 %t831, ptr %l51, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb250
bb250:
  br label %bb177
bb251:
  call void @__olang_scope_close(ptr %s21)
  br label %bb252
bb252:
  br label %bb121
bb253:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoutOfRange(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 17, ptr @.d19 }, { i64, ptr } { i64 10, ptr @.d20 }, { i64, ptr } { i64 12, ptr @.d21 })
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l80 = alloca i32
  %l82 = alloca i32
  %l86 = alloca { i64, ptr }
  %l90 = alloca %"compiler/source:Span"
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l100 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_70239da7d97117f8_be3796eb66d568d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %t14, ptr %t12, i32 %t13)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Param", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Param", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i1 %t33, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t34 = load i1, ptr %l21, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 %a3, ptr %l28, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb18:
  %t60 = load i32, ptr %l35
  %t62 = trunc i64 19 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i32 %t68)
  store i1 %t72, ptr %l41
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t73 = load i1, ptr %l41, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %l4, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l46
  br label %bb24
bb24:
  %t84 = load i32, ptr %l46
  %t86 = trunc i64 19 to i32
  %t87 = icmp eq i32 %t84, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i32 %t93)
  store i1 %t97, ptr %l53
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t98 = load i1, ptr %l53, !tbaa !21
  store i1 %t98, ptr %l4, !tbaa !21
  br label %bb28
bb28:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Param", ptr %t99, i32 0, i32 2
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb29, label %bb30
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Param", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t108, ptr %t112)
  store i1 %t115, ptr %l62
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  %t116 = load i1, ptr %l62, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l58, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l67
  br label %bb35
bb34:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb36
bb35:
  %t125 = load i1, ptr %l67, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l64, !tbaa !21
  br label %bb36
bb36:
  %t128 = load i1, ptr %l64, !tbaa !21
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  store ptr %t134, ptr %l72, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l75
  br label %bb39
bb38:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb41
bb39:
  %t140 = load ptr, ptr %l72, !tbaa !29
  %t141 = load i32, ptr %l75, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t142, ptr %l76
  br label %bb40
bb40:
  %t143 = load i32, ptr %l76
  %t145 = trunc i64 19 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l69, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Param", ptr %t149, i32 0, i32 0
  %t152 = getelementptr %"compiler/source:Span", ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152, !tbaa !23
  store i32 %t153, ptr %l80, !tbaa !23
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Param", ptr %t154, i32 0, i32 0
  %t157 = getelementptr %"compiler/source:Span", ptr %t156, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  store i32 %t158, ptr %l82, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Param", ptr %t160, i32 0, i32 1
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t159, i32 %t163)
  store { i64, ptr } %t166, ptr %l86
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t167 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = trunc i64 %t168 to i32
  %t171 = load i32, ptr %l82, !tbaa !23
  %t173 = add i32 %t171, %t170
  %t174 = load i32, ptr %l80, !tbaa !23
  %t176 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t174, i32 %t173)
  store %"compiler/source:Span" %t176, ptr %l90
  br label %bb45
bb45:
  %t177 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t177, ptr %l5
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 19
  store ptr %t180, ptr %l92, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t181)
  store ptr %t183, ptr %l94
  br label %bb46
bb46:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t186 = getelementptr %"compiler/check:frame", ptr %t184, i32 0, i32 2
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr %"compiler/ast:Param", ptr %t188, i32 0, i32 0
  %t191 = getelementptr %"compiler/source:Span", ptr %t190, i32 0, i32 0
  %t192 = load i32, ptr %t191, !tbaa !23
  %t194 = sext i32 %t192 to i64
  %t197 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t187, i64 %t194)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t197, ptr %l100
  br label %bb47
bb47:
  %t198 = load ptr, ptr %l92, !tbaa !29
  %t199 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l100
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t198, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t199, i1 true)
  br label %bb48
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l101, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t201, ptr %l102
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 1
  %t206 = load i32, ptr %t205, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t202, i32 %t206)
  store { i64, ptr } %t209, ptr %l106
  br label %bb49
bb49:
  %t210 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l107, !tbaa !27
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l108, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Param", ptr %t218, i32 0, i32 2
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_397a47855f80e417_31e96358085bf9e3)
  unreachable
bb51:
  br label %bb52
bb52:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Param", ptr %t225, i32 0, i32 2
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t228)
  store %"compiler/source:Span" %t230, ptr %l114
  br label %bb53
bb53:
  %t231 = load ptr, ptr %l108, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l114
  %t233 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store { i64, ptr } %t233, ptr %l115
  br label %bb54
bb54:
  %t234 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t236 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t234, { i64, ptr } %t235)
  store %"compiler/msgs:Msg" %t236, ptr %l116
  br label %bb55
bb55:
  %t237 = load ptr, ptr %l101, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l102
  %t239 = load %"compiler/msgs:Msg", ptr %l116
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t237, %"compiler/source:Span" %t238, %"compiler/msgs:Msg" %t239)
  store i64 %t240, ptr %l117
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb57:
  %t241 = load i1, ptr %l4, !tbaa !21
  store i1 %t241, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t35 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 32
  %t22 = load ptr, ptr %l5, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t21, ptr %t22)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  store %"compiler/source:Span" %a1, ptr %l19
  store i32 %a2, ptr %l20, !tbaa !23
  store i32 %a3, ptr %l21
  store i32 0, ptr %l22
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 32
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l26
  br label %bb7
bb7:
  store { i64, [5 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 0
  store i64 9, ptr %t36
  %t37 = load %"compiler/source:Span", ptr %l19
  %t38 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t37, 0
  %t39 = load i32, ptr %l20, !tbaa !23
  %t40 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t38, i32 %t39, 1
  %t41 = load i32, ptr %l21
  %t42 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t40, i32 %t41, 2
  %t43 = load i32, ptr %l22
  %t44 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t42, i32 %t43, 3
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t46 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t44, { i64, ptr } %t45, 4
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t46, ptr %t47
  %t48 = load { i64, [5 x i64] }, ptr %t35
  %t50 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t48, ptr %t50
  store ptr %t50, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l34 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l53 = alloca { i64, ptr }
  %l56 = alloca i32
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca %"compiler/check:nullNarrow"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  call void @compiler_2fcheck_2enullTests(ptr %v1, ptr %s0, ptr %a1, i1 %a2, ptr %l4)
  br label %bb2
bb2:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load i64, ptr %l6, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H0499d14ae95d265a50e407376635c44d(ptr %s0, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l25
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l24
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  br label %bb9
bb5:
  %t21 = load i32, ptr %l25, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_813406258c5e392b_5a078ade2d158267)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  %t26 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t26, ptr %l7, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t39, ptr %l34, !tbaa !27
  %t40 = load i64, ptr %l9, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t51 = icmp eq i64 %t49, 1
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t55, ptr %l41
  br label %bb16
bb15:
  br label %bb27
bb16:
  %t56 = load ptr, ptr %l41, !tbaa !29
  %t58 = getelementptr %"compiler/check:frame", ptr %t56, i32 0, i32 44
  store ptr %t58, ptr %l43, !tbaa !29
  %t59 = mul i64 100, 4
  %t60 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 100, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t77 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t77, ptr %l53, !tbaa !27
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t78
  %t83 = load i32, ptr %t82, !tbaa !33
  store i32 %t83, ptr %l56, !tbaa !23
  %t86 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = load i64, ptr %l45, !tbaa !24
  %t90 = icmp eq i64 %t88, %t87
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = load i64, ptr %l45, !tbaa !24
  %t93 = mul i64 %t92, 2
  %t95 = add i64 %t93, 1
  %t97 = mul i64 %t95, 4
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l61, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l45, !tbaa !24
  %t106 = mul i64 %t105, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t107, ptr %l44, !tbaa !27
  br label %bb22
bb22:
  %t108 = load i32, ptr %l56, !tbaa !23
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 %t109
  store i32 %t108, ptr %t112, !tbaa !33
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  %t115 = load i64, ptr %l12, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l12, !tbaa !24
  br label %bb17
bb24:
  %t119 = load i64, ptr %l45, !tbaa !24
  %t120 = mul i64 %t119, 4
  %t121 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l64, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l45, !tbaa !24
  %t129 = mul i64 %t128, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = mul i64 %t131, 4
  %t134 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t133)
  call void @llvm.memcpy.p0.p0.i64(ptr %t134, ptr %t132, i64 %t133, i1 false)
  %t135 = insertvalue { i64, ptr } undef, i64 %t131, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  %t140 = call %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v0, { i64, ptr } %t136, i64 %a3, i1 false)
  store %"compiler/check:nullNarrow" %t140, ptr %l67
  br label %bb25
bb25:
  %t141 = load ptr, ptr %l43, !tbaa !29
  %t142 = load %"compiler/check:nullNarrow", ptr %l67
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_Heed5ce4b924794f19a38fda2afa7ddeb(ptr %v0, ptr %v0, ptr %t141, %"compiler/check:nullNarrow" %t142)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l9, !tbaa !24
  br label %bb10
bb29:
  %t147 = load i64, ptr %l6, !tbaa !24
  %t148 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t147, %t148
  store i64 %t151, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  br label %bb3
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eputTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i32
  %l57 = alloca i1
  %l63 = alloca ptr
  %l70 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca ptr
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t116 = alloca { i64, [2 x i64] }, align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t4, ptr %l5
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t8 = load ptr, ptr %l13, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb3:
  br label %bb41
bb4:
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 0
  store i1 %t14, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l14, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l6
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l7, !tbaa !23
  br label %bb8
bb7:
  br label %bb37
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l7, !tbaa !23
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t32, ptr %l23
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr @.d22 })
  store i1 %t34, ptr %l24
  br label %bb10
bb10:
  %t35 = load i1, ptr %l24, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t36)
  store ptr %t38, ptr %l26
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 38
  %t42 = load i32, ptr %l7, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i32, ptr %l4, !tbaa !23
  %t51 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l34
  br label %bb18
bb17:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load i32, ptr %l34, !tbaa !23
  %t55 = icmp ne i32 %t53, %t52
  store i1 %t55, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l39
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t63 = load i32, ptr %l39, !tbaa !23
  store i32 %t63, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l42, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l4, !tbaa !23
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l45
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = load i32, ptr %l45, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l46
  br label %bb25
bb25:
  %t78 = load i32, ptr %l46
  %t80 = trunc i64 19 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l52, !tbaa !29
  %t89 = load i32, ptr %l4, !tbaa !23
  store i32 %t89, ptr %l53, !tbaa !23
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t90)
  store i32 %t93, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb30
bb28:
  %t94 = load ptr, ptr %l52, !tbaa !29
  %t95 = load i32, ptr %l53, !tbaa !23
  %t96 = load i32, ptr %l56, !tbaa !23
  %t97 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t94, i32 %t95, i32 %t96)
  store i1 %t97, ptr %l57
  br label %bb29
bb29:
  %t98 = load i1, ptr %l57, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t104 = load i32, ptr %l4, !tbaa !23
  %t105 = load %"compiler/source:Span", ptr %l6
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t102, ptr %t103, i32 %t104, %"compiler/source:Span" %t105)
  store ptr %t110, ptr %l63
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t111 = load ptr, ptr %l63, !tbaa !29
  store ptr %t111, ptr %l3, !tbaa !29
  br label %bb34
bb34:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l7, !tbaa !23
  %t114 = load %"compiler/source:Span", ptr %l6
  %t115 = load i32, ptr %l4, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t116
  %t117 = getelementptr { i64, [2 x i64] }, ptr %t116, i32 0, i32 0
  store i64 5, ptr %t117
  %t118 = load { i64, [2 x i64] }, ptr %t116
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t112, i32 %t113, %"compiler/source:Span" %t114, i32 %t115, i32 1, { i64, [2 x i64] } %t118)
  store i64 %t125, ptr %l70
  br label %bb35
bb35:
  %t126 = load i64, ptr %l70, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l6
  %t131 = trunc i64 %t126 to i32
  %t133 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t128, 0
  %t139 = insertvalue { %"compiler/source:Span", i32, ptr } %t137, i32 %t131, 1
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } %t139, ptr %t133, 2
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t141, ptr %t142
  %t143 = load { i64, [3 x i64] }, ptr %t134
  %t145 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t143, ptr %t145
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t127, ptr %t145)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l79, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t149, ptr %l80
  %t150 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %s6)
  store %"compiler/msgs:Msg" %t150, ptr %l81
  br label %bb38
bb38:
  %t151 = load ptr, ptr %l79, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l80
  %t153 = load %"compiler/msgs:Msg", ptr %l81
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t151, %"compiler/source:Span" %t152, %"compiler/msgs:Msg" %t153)
  store i64 %t154, ptr %l82
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb40:
  br label %ret
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %t155, ptr %t156)
  store ptr %t159, ptr %l85
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l85, !tbaa !29
  store ptr %t160, ptr %l9, !tbaa !29
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb43, label %bb44
bb43:
  br label %ret
bb44:
  br label %bb45
bb45:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t166, ptr %l89
  %t167 = load ptr, ptr %l9, !tbaa !29
  store ptr %t167, ptr %l90, !tbaa !29
  %t168 = load ptr, ptr %l0, !tbaa !29
  store ptr %t168, ptr %l91, !tbaa !29
  %t169 = load ptr, ptr %l3, !tbaa !29
  store ptr %t169, ptr %l92, !tbaa !29
  %t170 = load ptr, ptr %l9, !tbaa !29
  %t172 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l94
  br label %bb46
bb46:
  %t173 = load %"compiler/source:Span", ptr %l5
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l92, !tbaa !29
  %t176 = load i32, ptr %l94, !tbaa !23
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t174, ptr %t175, i32 %t176, %"compiler/source:Span" %t173)
  store ptr %t178, ptr %l96
  br label %bb47
bb47:
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 1, ptr %t180
  %t181 = load %"compiler/source:Span", ptr %l89
  %t182 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t181, 0
  %t183 = load ptr, ptr %l90, !tbaa !29
  %t184 = insertvalue { %"compiler/source:Span", ptr, ptr } %t182, ptr %t183, 1
  %t185 = load ptr, ptr %l96, !tbaa !29
  %t186 = insertvalue { %"compiler/source:Span", ptr, ptr } %t184, ptr %t185, 2
  %t187 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t186, ptr %t187
  %t188 = load { i64, [3 x i64] }, ptr %t179
  %t190 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t188, ptr %t190
  %t191 = load ptr, ptr %l88, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t191, ptr %t190)
  br label %bb48
bb48:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 86
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t20 = icmp slt i64 %t11, %t17
  store i1 %t20, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t22 = load i1, ptr %l8, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t23, ptr %t33)
  store i1 %t37, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l21, !tbaa !21
  store i1 %t38, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t39 = load i1, ptr %l14, !tbaa !21
  store i1 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca ptr
  %l14 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 0
  store i1 %t24, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t28, i32 0, i32 1
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i32, ptr %l3, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t43 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t38, i64 %t39, i64 %t42, ptr %t43)
  br label %bb11
bb11:
  br label %bb27
bb12:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 1
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb26
bb17:
  %t70 = load ptr, ptr %l5, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb18, label %bb19
bb18:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 0
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  %t87 = load i32, ptr %l7, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t90 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %t85, i64 %t86, i64 %t89, ptr %t90)
  br label %bb23
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  %t11 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %a1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t11, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"compiler/check:roOrigin"
  %l29 = alloca ptr
  %l30 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca %"compiler/check:roOrigin"
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca %"compiler/check:roOrigin"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l12
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l13
  br label %bb4
bb4:
  %t13 = load i1, ptr %l13, !tbaa !21
  %t14 = xor i1 %t13, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb11, label %bb12
bb11:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 57
  store ptr %t34, ptr %l22, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t35, i64 %t36)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39, ptr %l25
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t40, i1 false)
  store %"compiler/check:roOrigin" %t43, ptr %l28
  br label %bb15
bb15:
  %t44 = load ptr, ptr %l22, !tbaa !29
  %t45 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t46 = load %"compiler/check:roOrigin", ptr %l28
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t44, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t45, %"compiler/check:roOrigin" %t46)
  br label %bb16
bb16:
  br label %bb36
bb17:
  %t47 = load ptr, ptr %l2, !tbaa !29
  store ptr %t47, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l30, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 57
  store ptr %t64, ptr %l36, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t65, i64 %t66)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t69, ptr %l39
  br label %bb23
bb23:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t73 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t70, i1 true)
  store %"compiler/check:roOrigin" %t73, ptr %l42
  br label %bb24
bb24:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l39
  %t76 = load %"compiler/check:roOrigin", ptr %l42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t74, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t75, %"compiler/check:roOrigin" %t76)
  br label %bb25
bb25:
  br label %bb36
bb26:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 10
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l44, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb35
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 57
  store ptr %t94, ptr %l50, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l1, !tbaa !24
  %t99 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t95, i64 %t96)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t99, ptr %l53
  br label %bb32
bb32:
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Slice", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t106 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v1, ptr %v0, ptr %t103, i1 true)
  store %"compiler/check:roOrigin" %t106, ptr %l57
  br label %bb33
bb33:
  %t107 = load ptr, ptr %l50, !tbaa !29
  %t108 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l53
  %t109 = load %"compiler/check:roOrigin", ptr %l57
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v0, ptr %t107, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, %"compiler/check:roOrigin" %t109)
  br label %bb34
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l17 = alloca ptr
  %l27 = alloca i32
  %l34 = alloca i64
  %l41 = alloca i32
  %l44 = alloca i1
  %l49 = alloca i32
  %l58 = alloca i64
  %l63 = alloca i32
  %l66 = alloca ptr
  %l68 = alloca i32
  %l70 = alloca i32
  %l74 = alloca i32
  %l81 = alloca i64
  %l86 = alloca i32
  %l89 = alloca ptr
  %l91 = alloca i32
  %l93 = alloca i32
  %l97 = alloca ptr
  %l98 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i32
  %l117 = alloca i1
  %l120 = alloca i32
  %l123 = alloca i1
  %l128 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca i32
  %l139 = alloca i64
  %l140 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = load %"compiler/generic:Context", ptr %t6
  store %"compiler/generic:Context" %t7, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  store i1 %t11, ptr %l6, !tbaa !21
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t23 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %t19, ptr %t20)
  store i32 %t23, ptr %l27
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t24 = load i32, ptr %l27, !tbaa !23
  store i32 %t24, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l7, !tbaa !23
  %t27 = icmp sge i32 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l7, !tbaa !23
  %t38 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t34, i32 %t35)
  store i64 %t38, ptr %l34
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t39 = load i64, ptr %l34, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t49, i32 %a1)
  store i32 %t53, ptr %l41
  br label %bb12
bb11:
  br label %bb26
bb12:
  %t54 = load i32, ptr %l41, !tbaa !23
  store i32 %t54, ptr %l8, !tbaa !23
  %t55 = load i1, ptr %l6, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb16
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l8, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l49
  br label %bb15
bb15:
  %t69 = load i32, ptr %l49
  %t71 = trunc i64 26 to i32
  %t72 = icmp eq i32 %t69, %t71
  %t74 = xor i1 %t72, true
  store i1 %t74, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  %t76 = load i1, ptr %l44, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  store i32 0, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l8, !tbaa !23
  %t87 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l58
  br label %bb20
bb20:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l58, !tbaa !24
  %t91 = sub i64 %t89, %t88
  store i64 %t91, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l66, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t103)
  store i32 %t105, ptr %l68
  br label %bb23
bb22:
  store i32 0, ptr %l63, !tbaa !23
  br label %bb25
bb23:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t107 = load ptr, ptr %l66, !tbaa !29
  %t108 = load i32, ptr %l68, !tbaa !23
  %t110 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t107, i32 %t108, i64 %t106)
  store i32 %t110, ptr %l70
  br label %bb24
bb24:
  %t111 = load i32, ptr %l70, !tbaa !23
  store i32 %t111, ptr %l63, !tbaa !23
  br label %bb25
bb25:
  %t112 = load i32, ptr %l63, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
bb26:
  %t113 = load i1, ptr %l6, !tbaa !21
  br i1 %t113, label %bb27, label %bb28
bb27:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t119 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v2, ptr %t115, ptr %t116)
  store i32 %t119, ptr %l74
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t120 = load i32, ptr %l74, !tbaa !23
  store i32 %t120, ptr %l10, !tbaa !23
  %t121 = load i32, ptr %l10, !tbaa !23
  %t123 = icmp sge i32 %t121, 0
  br i1 %t123, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l10, !tbaa !23
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t130, i32 %t131)
  store i64 %t134, ptr %l81
  br label %bb32
bb31:
  br label %bb38
bb32:
  %t135 = load i64, ptr %l5, !tbaa !24
  %t136 = load i64, ptr %l81, !tbaa !24
  %t138 = sub i64 %t136, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb33, label %bb34
bb33:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  store ptr %t149, ptr %l89, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t150)
  store i32 %t152, ptr %l91
  br label %bb35
bb34:
  store i32 0, ptr %l86, !tbaa !23
  br label %bb37
bb35:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t154 = load ptr, ptr %l89, !tbaa !29
  %t155 = load i32, ptr %l91, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t154, i32 %t155, i64 %t153)
  store i32 %t157, ptr %l93
  br label %bb36
bb36:
  %t158 = load i32, ptr %l93, !tbaa !23
  store i32 %t158, ptr %l86, !tbaa !23
  br label %bb37
bb37:
  %t159 = load i32, ptr %l86, !tbaa !23
  store i32 %t159, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t160 = load ptr, ptr %l2, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = load ptr, ptr %l3, !tbaa !29
  store ptr %t166, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t167 = load ptr, ptr %l97, !tbaa !29
  %t168 = icmp ne ptr %t167, null
  br i1 %t168, label %bb42, label %bb43
bb41:
  br label %bb72
bb42:
  %t170 = load ptr, ptr %l97, !tbaa !29
  %t171 = load i64, ptr %t170
  %t173 = icmp eq i64 %t171, 5
  store i1 %t173, ptr %l98, !tbaa !21
  br label %bb43
bb43:
  %t174 = load i1, ptr %l98, !tbaa !21
  br i1 %t174, label %bb44, label %bb45
bb44:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = getelementptr { i64, [5 x i64] }, ptr %t175, i32 0, i32 1
  %t178 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t177, i32 0, i32 1
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l12
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t183 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  %t184 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t183, i32 0, i32 2
  %t185 = load ptr, ptr %t184
  store ptr %t185, ptr %l13, !tbaa !29
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t189, i32 0, i32 3
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l14, !tbaa !29
  br label %bb46
bb45:
  br label %bb70
bb46:
  %t193 = load i32, ptr %l12
  %t195 = trunc i64 48 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb47, label %bb48
bb47:
  store i32 -1, ptr %l15, !tbaa !23
  %t198 = load ptr, ptr %l13, !tbaa !29
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t202 = call i1 @compiler_2fcheck_2esameRead(ptr %v2, ptr %v1, ptr %t198, ptr %t199)
  store i1 %t202, ptr %l111
  br label %bb49
bb48:
  br label %bb69
bb49:
  %t203 = load i1, ptr %l111, !tbaa !21
  br i1 %t203, label %bb50, label %bb51
bb50:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l14, !tbaa !29
  %t208 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v2, ptr %t204, ptr %t205)
  store i32 %t208, ptr %l114
  br label %bb52
bb51:
  %t209 = load ptr, ptr %l14, !tbaa !29
  %t210 = load ptr, ptr %l2, !tbaa !29
  %t213 = call i1 @compiler_2fcheck_2esameRead(ptr %v2, ptr %v1, ptr %t209, ptr %t210)
  store i1 %t213, ptr %l117
  br label %bb53
bb52:
  %t214 = load i32, ptr %l114, !tbaa !23
  store i32 %t214, ptr %l15, !tbaa !23
  br label %bb58
bb53:
  %t215 = load i1, ptr %l117, !tbaa !21
  br i1 %t215, label %bb54, label %bb55
bb54:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l13, !tbaa !29
  %t220 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v2, ptr %t216, ptr %t217)
  store i32 %t220, ptr %l120
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t221 = load i32, ptr %l120, !tbaa !23
  store i32 %t221, ptr %l15, !tbaa !23
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t222 = load i32, ptr %l15, !tbaa !23
  %t224 = icmp sge i32 %t222, 0
  br i1 %t224, label %bb59, label %bb60
bb59:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/generic:Program", ptr %t229, i32 0, i32 2
  %t232 = load i32, ptr %l15, !tbaa !23
  %t235 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t231, i32 %t232)
  store i64 %t235, ptr %l128
  br label %bb61
bb60:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb62
bb61:
  %t236 = load i64, ptr %l128, !tbaa !24
  %t237 = icmp sge i64 %t236, 0
  store i1 %t237, ptr %l123, !tbaa !21
  br label %bb62
bb62:
  %t239 = load i1, ptr %l123, !tbaa !21
  br i1 %t239, label %bb63, label %bb64
bb63:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/check:Checker", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/generic:Program", ptr %t243, i32 0, i32 2
  store ptr %t245, ptr %l132, !tbaa !29
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t246)
  store i32 %t248, ptr %l134
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/generic:Program", ptr %t252, i32 0, i32 2
  %t255 = load i32, ptr %l15, !tbaa !23
  %t258 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t254, i32 %t255)
  store i64 %t258, ptr %l139
  br label %bb66
bb66:
  %t259 = load ptr, ptr %l132, !tbaa !29
  %t260 = load i32, ptr %l134, !tbaa !23
  %t261 = load i64, ptr %l139, !tbaa !24
  %t262 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t259, i32 %t260, i64 %t261)
  store i32 %t262, ptr %l140
  br label %bb67
bb67:
  %t263 = load i32, ptr %l140, !tbaa !23
  store i32 %t263, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/source:Span", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca { %"compiler/source:Span", i1 }
  %l26 = alloca %"compiler/source:Span"
  %s3 = alloca %olang.scope
  %rv = alloca { %"compiler/source:Span", i1 }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load %"compiler/source:Span", ptr %l2
  %t23 = load i32, ptr %l3
  %t25 = trunc i64 5 to i32
  %t26 = icmp eq i32 %t23, %t25
  %t28 = insertvalue { %"compiler/source:Span", i1 } undef, %"compiler/source:Span" %t22, 0
  %t30 = insertvalue { %"compiler/source:Span", i1 } %t28, i1 %t26, 1
  store { %"compiler/source:Span", i1 } %t30, ptr %rv
  br label %ret
bb6:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l17, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t51 = call { %"compiler/source:Span", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextValue(ptr %v0, ptr %v1, ptr %a0, ptr %t48)
  store { %"compiler/source:Span", i1 } %t51, ptr %l25
  br label %bb12
bb12:
  %t52 = load { %"compiler/source:Span", i1 }, ptr %l25
  store { %"compiler/source:Span", i1 } %t52, ptr %rv
  br label %ret
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t53, ptr %l26
  br label %bb14
bb14:
  %t54 = load %"compiler/source:Span", ptr %l26
  %t55 = insertvalue { %"compiler/source:Span", i1 } undef, %"compiler/source:Span" %t54, 0
  %t56 = insertvalue { %"compiler/source:Span", i1 } %t55, i1 false, 1
  call void @__olang_scope_close(ptr %s3)
  store { %"compiler/source:Span", i1 } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/source:Span", i1 }, ptr %rv
  ret { %"compiler/source:Span", i1 } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l49 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 5
  %t23 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l19
  br label %bb2
bb2:
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb5:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t52 = load i64, ptr %l23, !tbaa !24
  store i64 %t52, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l8, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/load:Loader", ptr %t77, i32 0, i32 5
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store ptr %t83, ptr %l49
  br label %bb13
bb13:
  %t84 = load ptr, ptr %l49, !tbaa !29
  %t86 = getelementptr %"compiler/load:Module", ptr %t84, i32 0, i32 4
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb14, label %bb15
bb14:
  %t93 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t93, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb9
bb18:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t18, i32 0, i32 3
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb26
bb5:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 1
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr { i64, [2 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { { i64, ptr } }, ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l21, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l2, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l27
  br label %bb14
bb13:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb16
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t53)
  store i32 %t55, ptr %l29
  br label %bb15
bb15:
  %t56 = load i32, ptr %l27, !tbaa !23
  %t57 = load i32, ptr %l29, !tbaa !23
  %t58 = icmp eq i32 %t56, %t57
  store i1 %t58, ptr %l22, !tbaa !21
  br label %bb16
bb16:
  %t60 = load i1, ptr %l22, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 6, ptr @.d23 }, ptr %l31, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l33, !tbaa !24
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l34, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e722c21055ee6b49_58bcebf0b772fb7d)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_eca48244095fc078_aacf4c954a6e214c)
  unreachable
bb31:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l35, !tbaa !29
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t78)
  store i32 %t81, ptr %l38
  br label %bb32
bb32:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i32, ptr %l38, !tbaa !23
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v2, ptr %t82, i32 %t83)
  store { i64, ptr } %t84, ptr %l39
  br label %bb33
bb33:
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeInstNote(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca i32
  %l18 = alloca i64
  %l21 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l64 = alloca %"compiler/generic:varRow"
  %l66 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l2, { i64, ptr } { i64 17, ptr @.d24 })
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l17
  br label %bb3
bb3:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = call i64 @compiler_2fgeneric_2eDeclOwner(i32 %t14)
  store i64 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i64, ptr %l18, !tbaa !24
  store i64 %t16, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  store ptr %t22, ptr %l21, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l26
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i32, ptr %l26, !tbaa !23
  %t35 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t33, i32 %t34)
  store { i64, ptr } %t35, ptr %l27
  br label %bb6
bb6:
  %t36 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t36, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb12
bb9:
  %t51 = load i64, ptr %l6, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l36, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l36, !tbaa !24
  store i64 %t67, ptr %l33, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l10, !tbaa !24
  store ptr %l2, ptr %l54, !tbaa !29
  %t87 = load i64, ptr %l10, !tbaa !24
  %t89 = icmp eq i64 %t87, 0
  br i1 %t89, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 7, ptr @.d25 }, ptr %l57, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 2, ptr @.d26 }, ptr %l57, !tbaa !27
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l54, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t91, { i64, ptr } %t92)
  br label %bb20
bb20:
  store ptr %l2, ptr %l58, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l59, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t103 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t97, i64 %t98, i64 %t99)
  store %"compiler/generic:varRow" %t103, ptr %l64
  br label %bb21
bb21:
  %t104 = getelementptr %"compiler/generic:varRow", ptr %l64, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t106, i32 %t105)
  store { i64, ptr } %t108, ptr %l66
  br label %bb22
bb22:
  %t109 = load ptr, ptr %l58, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l66, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t109, { i64, ptr } %t110)
  br label %bb23
bb23:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } { i64 3, ptr @.d27 })
  br label %bb24
bb24:
  store ptr %l2, ptr %l68, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t113, ptr %l70, !tbaa !27
  %t114 = load i64, ptr %l10, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t112, i32 %t119)
  store { i64, ptr } %t122, ptr %l73
  br label %bb25
bb25:
  %t123 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load ptr, ptr %l68, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t130, { i64, ptr } %t129)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb13
bb28:
  %t137 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t137, ptr %l78
  br label %bb29
bb29:
  %t138 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t138, ptr %l79, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  store i64 %t140, ptr %l80, !tbaa !24
  %t141 = load i64, ptr %l80, !tbaa !24
  %t142 = mul i64 %t141, 1
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l81, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = load i64, ptr %l80, !tbaa !24
  %t151 = mul i64 %t150, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %t149, i64 %t151, i1 false)
  %t152 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t152, ptr %l79, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunadapted(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l24 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 3
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t32, i32 0, i32 0
  %t34 = load %"compiler/source:Span", ptr %t33
  store %"compiler/source:Span" %t34, ptr %l3
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t43 = load %"compiler/source:Span", ptr %l3
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %t43, ptr %t44)
  store ptr %t48, ptr %l24
  br label %bb12
bb12:
  %t49 = load ptr, ptr %l24, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
bb13:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca { i64, i64, i64 }
  %l56 = alloca ptr
  %l61 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l94 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l96 = alloca i32
  %l97 = alloca i32
  %l101 = alloca ptr
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca i64
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l133 = alloca ptr
  %l145 = alloca i64
  %l147 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca i32
  %l152 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca i32
  %l164 = alloca ptr
  %l167 = alloca i64
  %l171 = alloca { i64, i64, i64 }
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca i32
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l188 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l197 = alloca i32
  %l198 = alloca ptr
  %l200 = alloca ptr
  %l208 = alloca ptr
  %s0 = alloca %olang.scope
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [4 x i64] }, align 8
  %t376 = alloca { i64, [3 x i64] }, align 8
  %t407 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t7 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %t1, %"compiler/source:Span" %t2, ptr %a3)
  store i64 %t7, ptr %l27
  br label %bb1
bb1:
  %t8 = load i64, ptr %l27, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l28, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t11)
  store i32 %t13, ptr %l31
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l29
  %t16 = load i32, ptr %l31, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t14, %"compiler/source:Span" %t15, i32 %t16)
  store i64 %t17, ptr %l32
  br label %bb3
bb3:
  %t18 = load i64, ptr %l32, !tbaa !24
  store i64 %t18, ptr %l9, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l33, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t20, ptr %l34
  %t21 = load i64, ptr %l9, !tbaa !24
  %t23 = trunc i64 %t21 to i32
  store i32 %t23, ptr %l37, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l38, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l39
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l41
  br label %bb4
bb4:
  %t30 = load ptr, ptr %l38, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l39
  %t32 = load i32, ptr %l41, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t30, %"compiler/source:Span" %t31, i32 %t32, i64 0)
  store ptr %t33, ptr %l42
  br label %bb5
bb5:
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 0, ptr %t35
  %t36 = load %"compiler/source:Span", ptr %l34
  %t37 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t36, 0
  %t38 = load i32, ptr %l37, !tbaa !23
  %t39 = insertvalue { %"compiler/source:Span", i32, ptr } %t37, i32 %t38, 1
  %t40 = load ptr, ptr %l42, !tbaa !29
  %t41 = insertvalue { %"compiler/source:Span", i32, ptr } %t39, ptr %t40, 2
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t41, ptr %t42
  %t43 = load { i64, [3 x i64] }, ptr %t34
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t43, ptr %t45
  %t46 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t46, ptr %t45)
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 33
  %t52 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l47
  br label %bb7
bb7:
  %t53 = load i64, ptr %l47, !tbaa !24
  store i64 %t53, ptr %l10, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t59 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t54, i32 2, %"compiler/source:Span" %t55)
  store { i64, i64, i64 } %t59, ptr %l51
  br label %bb8
bb8:
  %t60 = load { i64, i64, i64 }, ptr %l51
  store { i64, i64, i64 } %t60, ptr %l11
  %t61 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  store i64 %t62, ptr %l12, !tbaa !24
  %t64 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l13, !tbaa !24
  %t67 = getelementptr { i64, i64, i64 }, ptr %l11, i32 0, i32 2
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l14, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t70)
  store ptr %t72, ptr %l56
  br label %bb9
bb9:
  %t73 = load ptr, ptr %l56, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 10
  %t76 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  br label %bb10
bb10:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t79)
  store ptr %t81, ptr %l61
  br label %bb11
bb11:
  %t82 = load ptr, ptr %l61, !tbaa !29
  %t84 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 11
  %t85 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  br label %bb12
bb12:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t90 = getelementptr %"compiler/ast:ForIn", ptr %t88, i32 0, i32 3
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t93)
  store ptr %t95, ptr %l68
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t96 = load ptr, ptr %l68, !tbaa !29
  store ptr %t96, ptr %l69, !tbaa !29
  %t97 = load ptr, ptr %l69, !tbaa !29
  %t98 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 15
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = add i64 %t99, 1
  %t103 = load ptr, ptr %l69, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 15
  store i64 %t101, ptr %t104, !tbaa !24
  br label %bb16
bb16:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l72, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t106, ptr %l73
  %t107 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t107, ptr %l74
  store i64 %a5, ptr %l75, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load %"compiler/source:Span", ptr %l1
  %t111 = load i64, ptr %l8, !tbaa !24
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t109, %"compiler/source:Span" %t110, i64 %t111)
  store ptr %t115, ptr %l79
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l79, !tbaa !29
  store ptr %t116, ptr %l80, !tbaa !29
  %t117 = icmp sge i64 0, 0
  br i1 %t117, label %bb18, label %bb19
bb18:
  %t119 = icmp sle i64 0, 1152921504606846975
  br i1 %t119, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb20:
  %t121 = mul i64 0, 8
  %t122 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 0, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l83, !tbaa !27
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb22:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb24:
  %t129 = mul i64 0, 8
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 0, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l86, !tbaa !27
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8)
  unreachable
bb26:
  %t135 = icmp sle i64 0, 2305843009213693951
  br i1 %t135, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb28:
  %t137 = mul i64 0, 4
  %t138 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t137)
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t141 = load ptr, ptr %l72, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l73
  %t143 = load %"compiler/source:Span", ptr %l74
  %t144 = load i64, ptr %l75, !tbaa !24
  %t145 = load ptr, ptr %l80, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t149 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t141, %"compiler/source:Span" %t142, %"compiler/source:Span" %t143, i64 %t144, ptr %t145, { i64, ptr } %t146, { i64, ptr } %t147, { i64, ptr } %t140)
  store ptr %t149, ptr %l90
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb30:
  %t150 = load ptr, ptr %l90, !tbaa !29
  store ptr %t150, ptr %l15, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l91, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l92, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l93
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l94, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l95
  %t156 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t156, ptr %l96, !tbaa !23
  store i32 15, ptr %l97
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l1
  %t159 = load i64, ptr %l9, !tbaa !24
  %t163 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t157, %"compiler/source:Span" %t158, i64 %t159)
  store ptr %t163, ptr %l101
  br label %bb31
bb31:
  %t164 = load ptr, ptr %l15, !tbaa !29
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l95
  %t168 = load i32, ptr %l96, !tbaa !23
  %t169 = load i32, ptr %l97
  %t170 = load ptr, ptr %l101, !tbaa !29
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i32 %t168, i32 %t169, ptr %t170, ptr %t164)
  store ptr %t172, ptr %l104
  br label %bb32
bb32:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load ptr, ptr %l92, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l93
  %t176 = load ptr, ptr %l104, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t174, %"compiler/source:Span" %t175, ptr %t176, i64 %t173)
  store ptr %t178, ptr %l106
  br label %bb33
bb33:
  %t179 = load ptr, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l106, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t179, ptr %t180)
  br label %bb34
bb34:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l107, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l108
  %t183 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t183, ptr %l109
  store i64 %a4, ptr %l110, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  %t187 = load i64, ptr %l8, !tbaa !24
  %t191 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, i64 %t187)
  store ptr %t191, ptr %l114
  br label %bb35
bb35:
  %t192 = load ptr, ptr %l114, !tbaa !29
  store ptr %t192, ptr %l115, !tbaa !29
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb36, label %bb37
bb36:
  %t195 = icmp sle i64 0, 1152921504606846975
  br i1 %t195, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb38:
  %t197 = mul i64 0, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 0, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l118, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l119, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l1
  %t204 = load i64, ptr %l9, !tbaa !24
  %t208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t202, %"compiler/source:Span" %t203, i64 %t204)
  store ptr %t208, ptr %l123
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_130b25e968db6b32_47c65c95f253846)
  unreachable
bb40:
  %t209 = load ptr, ptr %l119, !tbaa !29
  %t210 = load ptr, ptr %l123, !tbaa !29
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t209, ptr %t210)
  store { i64, ptr } %t211, ptr %l124
  br label %bb41
bb41:
  %t212 = icmp sge i64 0, 0
  br i1 %t212, label %bb42, label %bb43
bb42:
  %t214 = icmp sle i64 0, 2305843009213693951
  br i1 %t214, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb44:
  %t216 = mul i64 0, 4
  %t217 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t216)
  %t218 = insertvalue { i64, ptr } undef, i64 0, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t217, 1
  %t220 = load ptr, ptr %l107, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l108
  %t222 = load %"compiler/source:Span", ptr %l109
  %t223 = load i64, ptr %l110, !tbaa !24
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t220, %"compiler/source:Span" %t221, %"compiler/source:Span" %t222, i64 %t223, ptr %t224, { i64, ptr } %t225, { i64, ptr } %t226, { i64, ptr } %t219)
  store ptr %t228, ptr %l128
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_19568a04807ed851_528b5bfe222c3865)
  unreachable
bb46:
  %t229 = load ptr, ptr %l128, !tbaa !29
  store ptr %t229, ptr %l16, !tbaa !29
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t232 = getelementptr %"compiler/ast:ForIn", ptr %t230, i32 0, i32 3
  %t233 = load i1, ptr %t232, !tbaa !21
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t235)
  store ptr %t237, ptr %l132
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t238 = load ptr, ptr %l132, !tbaa !29
  store ptr %t238, ptr %l133, !tbaa !29
  %t239 = load ptr, ptr %l133, !tbaa !29
  %t240 = getelementptr %"compiler/check:frame", ptr %t239, i32 0, i32 15
  %t241 = load i64, ptr %t240, !tbaa !24
  %t243 = sub i64 %t241, 1
  %t245 = load ptr, ptr %l133, !tbaa !29
  %t246 = getelementptr %"compiler/check:frame", ptr %t245, i32 0, i32 15
  store i64 %t243, ptr %t246, !tbaa !24
  br label %bb50
bb50:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t250 = load i64, ptr %l9, !tbaa !24
  %t251 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %t247, %"compiler/source:Span" %t248, ptr %t249, i64 %t250, ptr %t251)
  br label %bb51
bb51:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t258, ptr %a6, i32 %a7)
  br label %bb52
bb52:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t265)
  store ptr %t267, ptr %l147
  br label %bb53
bb53:
  %t268 = load ptr, ptr %l147, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 10
  %t272 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t270)
  %t273 = extractvalue { i32, i64 } %t272, 1
  %t274 = extractvalue { i32, i64 } %t272, 0
  store i32 %t274, ptr %l151
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb55, label %ok.276
ok.276:
  store i64 %t273, ptr %l150
  br label %bb54
bb54:
  %t277 = load i64, ptr %l150, !tbaa !24
  store i64 %t277, ptr %l145, !tbaa !24
  br label %bb57
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  br label %bb57
bb57:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t278)
  store ptr %t280, ptr %l154
  br label %bb58
bb58:
  %t281 = load ptr, ptr %l154, !tbaa !29
  %t283 = getelementptr %"compiler/check:frame", ptr %t281, i32 0, i32 11
  %t285 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t283)
  %t286 = extractvalue { i32, i64 } %t285, 1
  %t287 = extractvalue { i32, i64 } %t285, 0
  store i32 %t287, ptr %l158
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb60, label %ok.289
ok.289:
  store i64 %t286, ptr %l157
  br label %bb59
bb59:
  %t290 = load i64, ptr %l157, !tbaa !24
  store i64 %t290, ptr %l152, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  call void @__olang_ert_req_clear()
  br label %bb62
bb62:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i64, ptr %l12, !tbaa !24
  %t293 = load i64, ptr %l13, !tbaa !24
  %t294 = load i64, ptr %l14, !tbaa !24
  %t295 = load i64, ptr %l10, !tbaa !24
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t291, i64 %t292, i64 %t293, i64 %t294, i64 %t295)
  store ptr %t301, ptr %l164
  br label %bb63
bb63:
  %t302 = load ptr, ptr %l164, !tbaa !29
  store ptr %t302, ptr %l17, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 33
  %t307 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t305)
  store i64 %t307, ptr %l167
  br label %bb64
bb64:
  %t308 = load i64, ptr %l167, !tbaa !24
  store i64 %t308, ptr %l18, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t314 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t309, i32 3, %"compiler/source:Span" %t310)
  store { i64, i64, i64 } %t314, ptr %l171
  br label %bb65
bb65:
  %t315 = load { i64, i64, i64 }, ptr %l171
  store { i64, i64, i64 } %t315, ptr %l19
  %t316 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 0
  %t317 = load i64, ptr %t316, !tbaa !24
  store i64 %t317, ptr %l20, !tbaa !24
  %t319 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 1
  %t320 = load i64, ptr %t319, !tbaa !24
  store i64 %t320, ptr %l21, !tbaa !24
  %t322 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 2
  %t323 = load i64, ptr %t322, !tbaa !24
  store i64 %t323, ptr %l22, !tbaa !24
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l175, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t326, ptr %l176
  %t327 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t327, ptr %l177
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t328)
  store i32 %t330, ptr %l179
  br label %bb66
bb66:
  %t331 = load i64, ptr %l9, !tbaa !24
  %t333 = trunc i64 %t331 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 0
  store i64 0, ptr %t336
  %t337 = load %"compiler/source:Span", ptr %l177
  %t338 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t337, 0
  %t339 = load i32, ptr %l179, !tbaa !23
  %t340 = insertvalue { %"compiler/source:Span", i32, i32 } %t338, i32 %t339, 1
  %t342 = insertvalue { %"compiler/source:Span", i32, i32 } %t340, i32 %t333, 2
  %t343 = getelementptr { i64, [4 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t342, ptr %t343
  %t344 = load { i64, [4 x i64] }, ptr %t335
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t344, ptr %t346
  store ptr %t346, ptr %l184, !tbaa !29
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l185, !tbaa !29
  %t348 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t348, ptr %l186
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t349)
  store i32 %t351, ptr %l188
  br label %bb67
bb67:
  store i32 3, ptr %l189
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l1
  %t354 = load i64, ptr %l9, !tbaa !24
  %t358 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t352, %"compiler/source:Span" %t353, i64 %t354)
  store ptr %t358, ptr %l193
  br label %bb68
bb68:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l194, !tbaa !29
  %t360 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t360, ptr %l195
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t361)
  store i32 %t363, ptr %l197
  br label %bb69
bb69:
  %t364 = load ptr, ptr %l194, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l195
  %t366 = load i32, ptr %l197, !tbaa !23
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366, i64 1)
  store ptr %t367, ptr %l198
  br label %bb70
bb70:
  %t368 = load ptr, ptr %l198, !tbaa !29
  %t369 = load ptr, ptr %l185, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l186
  %t371 = load i32, ptr %l188, !tbaa !23
  %t372 = load i32, ptr %l189
  %t373 = load ptr, ptr %l193, !tbaa !29
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t369, %"compiler/source:Span" %t370, i32 %t371, i32 %t372, ptr %t373, ptr %t368)
  store ptr %t375, ptr %l200
  br label %bb71
bb71:
  store { i64, [3 x i64] } zeroinitializer, ptr %t376
  %t377 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 0
  store i64 1, ptr %t377
  %t378 = load %"compiler/source:Span", ptr %l176
  %t379 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t378, 0
  %t380 = load ptr, ptr %l184, !tbaa !29
  %t381 = insertvalue { %"compiler/source:Span", ptr, ptr } %t379, ptr %t380, 1
  %t382 = load ptr, ptr %l200, !tbaa !29
  %t383 = insertvalue { %"compiler/source:Span", ptr, ptr } %t381, ptr %t382, 2
  %t384 = getelementptr { i64, [3 x i64] }, ptr %t376, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t383, ptr %t384
  %t385 = load { i64, [3 x i64] }, ptr %t376
  %t387 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t385, ptr %t387
  %t388 = load ptr, ptr %l175, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t388, ptr %t387)
  br label %bb72
bb72:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i64, ptr %l20, !tbaa !24
  %t392 = load i64, ptr %l21, !tbaa !24
  %t393 = load i64, ptr %l22, !tbaa !24
  %t394 = load i64, ptr %l18, !tbaa !24
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t390, i64 %t391, i64 %t392, i64 %t393, i64 %t394)
  store ptr %t400, ptr %l208
  br label %bb73
bb73:
  %t401 = load ptr, ptr %l208, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l1
  %t404 = load ptr, ptr %l17, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t407
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 0
  store i64 4, ptr %t408
  %t410 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t403, 0
  %t412 = insertvalue { %"compiler/source:Span", ptr, ptr } %t410, ptr %t404, 1
  %t414 = insertvalue { %"compiler/source:Span", ptr, ptr } %t412, ptr %t401, 2
  %t415 = getelementptr { i64, [3 x i64] }, ptr %t407, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t414, ptr %t415
  %t416 = load { i64, [3 x i64] }, ptr %t407
  %t418 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t416, ptr %t418
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t402, ptr %t418)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store { i64, ptr } { i64 29, ptr @.d28 }, ptr %l1, !tbaa !27
  br label %bb77
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 9
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 22, ptr @.d29 }, ptr %l1, !tbaa !27
  br label %bb77
bb12:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb13, label %bb14
bb13:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb14
bb14:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store { i64, ptr } { i64 10, ptr @.d30 }, ptr %l1, !tbaa !27
  br label %bb77
bb18:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t29 = load ptr, ptr %l14, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb19, label %bb20
bb19:
  %t32 = load ptr, ptr %l14, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 13
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb20
bb20:
  %t36 = load i1, ptr %l15, !tbaa !21
  br i1 %t36, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 22, ptr @.d31 }, ptr %l1, !tbaa !27
  br label %bb77
bb24:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb25, label %bb26
bb25:
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 14
  store i1 %t44, ptr %l19, !tbaa !21
  br label %bb26
bb26:
  %t45 = load i1, ptr %l19, !tbaa !21
  br i1 %t45, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store { i64, ptr } { i64 25, ptr @.d32 }, ptr %l1, !tbaa !27
  br label %bb77
bb30:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb31, label %bb32
bb31:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 19
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb32
bb32:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 18, ptr @.d33 }, ptr %l1, !tbaa !27
  br label %bb77
bb36:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb37, label %bb38
bb37:
  %t59 = load ptr, ptr %l26, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 20
  store i1 %t62, ptr %l27, !tbaa !21
  br label %bb38
bb38:
  %t63 = load i1, ptr %l27, !tbaa !21
  br i1 %t63, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 21, ptr @.d34 }, ptr %l1, !tbaa !27
  br label %bb77
bb42:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t65 = load ptr, ptr %l30, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb43, label %bb44
bb43:
  %t68 = load ptr, ptr %l30, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 23
  store i1 %t71, ptr %l31, !tbaa !21
  br label %bb44
bb44:
  %t72 = load i1, ptr %l31, !tbaa !21
  br i1 %t72, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 14, ptr @.d35 }, ptr %l1, !tbaa !27
  br label %bb77
bb48:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb49, label %bb50
bb49:
  %t77 = load ptr, ptr %l34, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 24
  store i1 %t80, ptr %l35, !tbaa !21
  br label %bb50
bb50:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 20, ptr @.d36 }, ptr %l1, !tbaa !27
  br label %bb77
bb54:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t83 = load ptr, ptr %l38, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb55, label %bb56
bb55:
  %t86 = load ptr, ptr %l38, !tbaa !29
  %t87 = load i64, ptr %t86
  %t89 = icmp eq i64 %t87, 25
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb56
bb56:
  %t90 = load i1, ptr %l39, !tbaa !21
  br i1 %t90, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  store { i64, ptr } { i64 27, ptr @.d37 }, ptr %l1, !tbaa !27
  br label %bb77
bb60:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb61, label %bb62
bb61:
  %t95 = load ptr, ptr %l42, !tbaa !29
  %t96 = load i64, ptr %t95
  %t98 = icmp eq i64 %t96, 26
  store i1 %t98, ptr %l43, !tbaa !21
  br label %bb62
bb62:
  %t99 = load i1, ptr %l43, !tbaa !21
  br i1 %t99, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb66
bb65:
  store { i64, ptr } { i64 31, ptr @.d38 }, ptr %l1, !tbaa !27
  br label %bb77
bb66:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb67, label %bb68
bb67:
  %t104 = load ptr, ptr %l46, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 16
  store i1 %t107, ptr %l47, !tbaa !21
  br label %bb68
bb68:
  %t108 = load i1, ptr %l47, !tbaa !21
  br i1 %t108, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb72
bb71:
  store { i64, ptr } { i64 21, ptr @.d39 }, ptr %l1, !tbaa !27
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 26, ptr @.d40 }, ptr %l1, !tbaa !27
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_d149dd778abfbb99_ce32867ac8840ced)
  unreachable
bb77:
  %t109 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t109, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 97
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 102
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 65
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 70
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisTrue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
bb9:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2enoLit() #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 false, i1 false, i1 false, i64 0, double 0x0000000000000000)
  store %"compiler/check:litv" %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load %"compiler/check:litv", ptr %l0
  store %"compiler/check:litv" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i1
  %l57 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l75 = alloca i1
  %l77 = alloca i1
  %l80 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t6 = load ptr, ptr %l15, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = load i1, ptr %l1, !tbaa !21
  %t23 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t20, i1 %t22, ptr %t23)
  br label %bb9
bb9:
  br label %bb59
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l25, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l26, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l4
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t44, i32 0, i32 2
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t48 = load i32, ptr %l4
  %t50 = trunc i64 47 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = load i1, ptr %l1, !tbaa !21
  %t57 = xor i1 %t55, true
  %t58 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t53, i1 %t57, ptr %t58)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb59
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t63 = load ptr, ptr %l40, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t67 = load i64, ptr %t66
  %t69 = icmp eq i64 %t67, 10
  store i1 %t69, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t73, i32 0, i32 1
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l6, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr { i64, [5 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l7, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t85, i32 0, i32 3
  %t87 = load i1, ptr %t86
  store i1 %t87, ptr %l8, !tbaa !21
  br label %bb25
bb24:
  br label %bb38
bb25:
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t89)
  store i1 %t91, ptr %l51
  br label %bb26
bb26:
  %t92 = load i1, ptr %l51, !tbaa !21
  br i1 %t92, label %bb27, label %bb28
bb27:
  %t93 = load i1, ptr %l8, !tbaa !21
  %t94 = load i1, ptr %l1, !tbaa !21
  %t97 = icmp eq i1 %t93, %t94
  store i1 %t97, ptr %l52, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb29
bb29:
  %t99 = load i1, ptr %l52, !tbaa !21
  br i1 %t99, label %bb30, label %bb31
bb30:
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %t100)
  store { i64, ptr } %t102, ptr %l57
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t103 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t103, ptr %l9, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v1, ptr %v0, ptr %t110, { i64, ptr } %t111)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb59
bb38:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t115 = load ptr, ptr %l63, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb39, label %bb40
bb39:
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = load i64, ptr %t118
  %t121 = icmp eq i64 %t119, 5
  store i1 %t121, ptr %l64, !tbaa !21
  br label %bb40
bb40:
  %t122 = load i1, ptr %l64, !tbaa !21
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l10
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr { i64, [5 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l11, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t137, i32 0, i32 3
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l12, !tbaa !29
  br label %bb43
bb42:
  br label %bb58
bb43:
  %t141 = load i32, ptr %l10
  %t143 = trunc i64 44 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb44, label %bb45
bb44:
  %t146 = load i1, ptr %l1, !tbaa !21
  store i1 %t146, ptr %l75, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb46
bb46:
  %t148 = load i1, ptr %l75, !tbaa !21
  br i1 %t148, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb52
bb48:
  %t149 = load i32, ptr %l10
  %t151 = trunc i64 45 to i32
  %t152 = icmp eq i32 %t149, %t151
  br i1 %t152, label %bb49, label %bb50
bb49:
  %t154 = load i1, ptr %l1, !tbaa !21
  %t156 = xor i1 %t154, true
  store i1 %t156, ptr %l80, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb51
bb51:
  %t158 = load i1, ptr %l80, !tbaa !21
  store i1 %t158, ptr %l77, !tbaa !21
  br label %bb52
bb52:
  %t159 = load i1, ptr %l77, !tbaa !21
  br i1 %t159, label %bb53, label %bb54
bb53:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load i1, ptr %l1, !tbaa !21
  %t163 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t160, i1 %t162, ptr %t163)
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t167 = load ptr, ptr %l12, !tbaa !29
  %t169 = load i1, ptr %l1, !tbaa !21
  %t170 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2enullTests(ptr %v0, ptr %v1, ptr %t167, i1 %t169, ptr %t170)
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 15
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l5, !tbaa !23
  br label %bb17
bb16:
  br label %bb28
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 15
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load i32, ptr %l7, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l47
  br label %bb25
bb24:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb25:
  %t91 = load i1, ptr %l47, !tbaa !21
  store i1 %t91, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t92 = load i1, ptr %l44, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb27:
  store i1 false, ptr %rv
  br label %ret
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t95 = load ptr, ptr %l49, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l50, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t109 = load ptr, ptr %l8, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t113 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i1 %t113, ptr %l57
  br label %bb34
bb34:
  %t114 = load i1, ptr %l57, !tbaa !21
  store i1 %t114, ptr %rv
  br label %ret
bb35:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l69 = alloca { i64, ptr }
  %l74 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i1
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l215 = alloca { i64, ptr }
  %l220 = alloca i1
  %s6 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t7 = load ptr, ptr %l29, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l29, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l30, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t21, { i64, ptr } %t23)
  store i1 %t26, ptr %l38
  br label %bb9
bb9:
  %t27 = load i1, ptr %l38, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l40, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb21
bb15:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t50)
  store i1 %t53, ptr %l49
  br label %bb16
bb16:
  %t54 = load i1, ptr %l49, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb20
bb18:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t55, { i64, ptr } %t57)
  store i1 %t60, ptr %l54
  br label %bb19
bb19:
  %t61 = load i1, ptr %l54, !tbaa !21
  store i1 %t61, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t62 = load i1, ptr %l50, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t64 = load ptr, ptr %l55, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l55, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 2
  store i1 %t70, ptr %l56, !tbaa !21
  br label %bb23
bb23:
  %t71 = load i1, ptr %l56, !tbaa !21
  br i1 %t71, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb37
bb26:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Multi", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l69, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t104)
  store i1 %t107, ptr %l74
  br label %bb31
bb31:
  %t108 = load i1, ptr %l74, !tbaa !21
  br i1 %t108, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb27
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t116 = load ptr, ptr %l79, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t119 = load ptr, ptr %l79, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 4
  store i1 %t122, ptr %l80, !tbaa !21
  br label %bb39
bb39:
  %t123 = load i1, ptr %l80, !tbaa !21
  br i1 %t123, label %bb40, label %bb41
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t132, i32 0, i32 2
  %t134 = load { i64, ptr }, ptr %t133
  store { i64, ptr } %t134, ptr %l11, !tbaa !27
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t141 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t138)
  store i1 %t141, ptr %l90
  br label %bb43
bb43:
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb47
bb45:
  %t143 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t147 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t143, { i64, ptr } %t144)
  store i1 %t147, ptr %l94
  br label %bb46
bb46:
  %t148 = load i1, ptr %l94, !tbaa !21
  store i1 %t148, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t149 = load i1, ptr %l91, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
bb48:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t151 = load ptr, ptr %l95, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb49, label %bb50
bb49:
  %t154 = load ptr, ptr %l95, !tbaa !29
  %t155 = load i64, ptr %t154
  %t157 = icmp eq i64 %t155, 5
  store i1 %t157, ptr %l96, !tbaa !21
  br label %bb50
bb50:
  %t158 = load i1, ptr %l96, !tbaa !21
  br i1 %t158, label %bb51, label %bb52
bb51:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", ptr }, ptr %t161, i32 0, i32 1
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l12, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t169 = call i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %t165, { i64, ptr } %t166)
  store i1 %t169, ptr %l103
  br label %bb54
bb54:
  %t170 = load i1, ptr %l103, !tbaa !21
  store i1 %t170, ptr %rv
  br label %ret
bb55:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb56, label %bb57
bb56:
  %t175 = load ptr, ptr %l104, !tbaa !29
  %t176 = load i64, ptr %t175
  %t178 = icmp eq i64 %t176, 6
  store i1 %t178, ptr %l105, !tbaa !21
  br label %bb57
bb57:
  %t179 = load i1, ptr %l105, !tbaa !21
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183
  store { i64, ptr } %t184, ptr %l13, !tbaa !27
  br label %bb64
bb59:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t187 = load ptr, ptr %l110, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t190 = load ptr, ptr %l110, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 19
  store i1 %t193, ptr %l111, !tbaa !21
  br label %bb61
bb61:
  %t194 = load i1, ptr %l111, !tbaa !21
  br i1 %t194, label %bb62, label %bb63
bb62:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr { i64, [4 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t197, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198
  store { i64, ptr } %t199, ptr %l13, !tbaa !27
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t205 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t201, { i64, ptr } %t202)
  store i1 %t205, ptr %l118
  br label %bb65
bb65:
  %t206 = load i1, ptr %l118, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb66:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t208 = load ptr, ptr %l119, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb67, label %bb68
bb67:
  %t211 = load ptr, ptr %l119, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 7
  store i1 %t214, ptr %l120, !tbaa !21
  br label %bb68
bb68:
  %t215 = load i1, ptr %l120, !tbaa !21
  br i1 %t215, label %bb69, label %bb70
bb69:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr { i64, [4 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l14, !tbaa !27
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t222 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t226 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t222, { i64, ptr } %t223)
  store i1 %t226, ptr %l127
  br label %bb72
bb72:
  %t227 = load i1, ptr %l127, !tbaa !21
  store i1 %t227, ptr %rv
  br label %ret
bb73:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t229 = load ptr, ptr %l128, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb74, label %bb75
bb74:
  %t232 = load ptr, ptr %l128, !tbaa !29
  %t233 = load i64, ptr %t232
  %t235 = icmp eq i64 %t233, 10
  store i1 %t235, ptr %l129, !tbaa !21
  br label %bb75
bb75:
  %t236 = load i1, ptr %l129, !tbaa !21
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t239, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l15, !tbaa !27
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t243 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t247 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t243, { i64, ptr } %t244)
  store i1 %t247, ptr %l136
  br label %bb79
bb79:
  %t248 = load i1, ptr %l136, !tbaa !21
  store i1 %t248, ptr %rv
  br label %ret
bb80:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t250 = load ptr, ptr %l137, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb81, label %bb82
bb81:
  %t253 = load ptr, ptr %l137, !tbaa !29
  %t254 = load i64, ptr %t253
  %t256 = icmp eq i64 %t254, 8
  store i1 %t256, ptr %l138, !tbaa !21
  br label %bb82
bb82:
  %t257 = load i1, ptr %l138, !tbaa !21
  br i1 %t257, label %bb83, label %bb84
bb83:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 1
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l16, !tbaa !29
  br label %bb85
bb84:
  br label %bb91
bb85:
  %t264 = load ptr, ptr %l16, !tbaa !29
  %t266 = getelementptr %"compiler/ast:For3", ptr %t264, i32 0, i32 2
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t272 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t267, { i64, ptr } %t269)
  store i1 %t272, ptr %l147
  br label %bb86
bb86:
  %t273 = load i1, ptr %l147, !tbaa !21
  br i1 %t273, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb90
bb88:
  %t274 = load ptr, ptr %l16, !tbaa !29
  %t276 = getelementptr %"compiler/ast:For3", ptr %t274, i32 0, i32 3
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t281 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t277, { i64, ptr } %t278)
  store i1 %t281, ptr %l152
  br label %bb89
bb89:
  %t282 = load i1, ptr %l152, !tbaa !21
  store i1 %t282, ptr %l148, !tbaa !21
  br label %bb90
bb90:
  %t283 = load i1, ptr %l148, !tbaa !21
  store i1 %t283, ptr %rv
  br label %ret
bb91:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t285 = load ptr, ptr %l153, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb92, label %bb93
bb92:
  %t288 = load ptr, ptr %l153, !tbaa !29
  %t289 = load i64, ptr %t288
  %t291 = icmp eq i64 %t289, 9
  store i1 %t291, ptr %l154, !tbaa !21
  br label %bb93
bb93:
  %t292 = load i1, ptr %l154, !tbaa !21
  br i1 %t292, label %bb94, label %bb95
bb94:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb102
bb96:
  %t299 = load ptr, ptr %l17, !tbaa !29
  %t301 = getelementptr %"compiler/ast:ForIn", ptr %t299, i32 0, i32 4
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t306 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t302, { i64, ptr } %t303)
  store i1 %t306, ptr %l162
  br label %bb97
bb97:
  %t307 = load i1, ptr %l162, !tbaa !21
  br i1 %t307, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb101
bb99:
  %t308 = load ptr, ptr %l17, !tbaa !29
  %t310 = getelementptr %"compiler/ast:ForIn", ptr %t308, i32 0, i32 5
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t315 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t311, { i64, ptr } %t312)
  store i1 %t315, ptr %l167
  br label %bb100
bb100:
  %t316 = load i1, ptr %l167, !tbaa !21
  store i1 %t316, ptr %l163, !tbaa !21
  br label %bb101
bb101:
  %t317 = load i1, ptr %l163, !tbaa !21
  store i1 %t317, ptr %rv
  br label %ret
bb102:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t319 = load ptr, ptr %l168, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb103, label %bb104
bb103:
  %t322 = load ptr, ptr %l168, !tbaa !29
  %t323 = load i64, ptr %t322
  %t325 = icmp eq i64 %t323, 11
  store i1 %t325, ptr %l169, !tbaa !21
  br label %bb104
bb104:
  %t326 = load i1, ptr %l169, !tbaa !21
  br i1 %t326, label %bb105, label %bb106
bb105:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t337 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t333, { i64, ptr } %t334)
  store i1 %t337, ptr %l176
  br label %bb108
bb108:
  %t338 = load i1, ptr %l176, !tbaa !21
  store i1 %t338, ptr %rv
  br label %ret
bb109:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t340 = load ptr, ptr %l177, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb110, label %bb111
bb110:
  %t343 = load ptr, ptr %l177, !tbaa !29
  %t344 = load i64, ptr %t343
  %t346 = icmp eq i64 %t344, 17
  store i1 %t346, ptr %l178, !tbaa !21
  br label %bb111
bb111:
  %t347 = load i1, ptr %l178, !tbaa !21
  br i1 %t347, label %bb112, label %bb113
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr { i64, [4 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb120
bb114:
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t356 = getelementptr %"compiler/ast:JoinS", ptr %t354, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t361 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t357, { i64, ptr } %t358)
  store i1 %t361, ptr %l186
  br label %bb115
bb115:
  %t362 = load i1, ptr %l186, !tbaa !21
  br i1 %t362, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb119
bb117:
  %t363 = load ptr, ptr %l19, !tbaa !29
  %t365 = getelementptr %"compiler/ast:JoinS", ptr %t363, i32 0, i32 2
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t370 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t366, { i64, ptr } %t367)
  store i1 %t370, ptr %l191
  br label %bb118
bb118:
  %t371 = load i1, ptr %l191, !tbaa !21
  store i1 %t371, ptr %l187, !tbaa !21
  br label %bb119
bb119:
  %t372 = load i1, ptr %l187, !tbaa !21
  store i1 %t372, ptr %rv
  br label %ret
bb120:
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t374 = load ptr, ptr %l192, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb121, label %bb122
bb121:
  %t377 = load ptr, ptr %l192, !tbaa !29
  %t378 = load i64, ptr %t377
  %t380 = icmp eq i64 %t378, 18
  store i1 %t380, ptr %l193, !tbaa !21
  br label %bb122
bb122:
  %t381 = load i1, ptr %l193, !tbaa !21
  br i1 %t381, label %bb123, label %bb124
bb123:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr { i64, [4 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", ptr }, ptr %t384, i32 0, i32 1
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l20, !tbaa !29
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t388 = load ptr, ptr %l20, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t393 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t388, { i64, ptr } %t390)
  store i1 %t393, ptr %l201
  br label %bb126
bb126:
  %t394 = load i1, ptr %l201, !tbaa !21
  store i1 %t394, ptr %rv
  br label %ret
bb127:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t396 = load ptr, ptr %l202, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb128, label %bb129
bb128:
  %t399 = load ptr, ptr %l202, !tbaa !29
  %t400 = load i64, ptr %t399
  %t402 = icmp eq i64 %t400, 16
  store i1 %t402, ptr %l203, !tbaa !21
  br label %bb129
bb129:
  %t403 = load i1, ptr %l203, !tbaa !21
  br i1 %t403, label %bb130, label %bb131
bb130:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t406, i32 0, i32 1
  %t408 = load { i64, ptr }, ptr %t407
  store { i64, ptr } %t408, ptr %l21, !tbaa !27
  br label %bb132
bb131:
  br label %bb143
bb132:
  %t410 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t410, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t412 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t412, 0
  store i64 %t414, ptr %l24, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load i64, ptr %l23, !tbaa !24
  %t417 = load i64, ptr %l24, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s21)
  br label %bb142
bb135:
  br label %bb136
bb136:
  %t424 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t424, ptr %l215, !tbaa !27
  %t425 = load i64, ptr %l23, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr ptr, ptr %t428, i64 %t425
  %t430 = load ptr, ptr %t429, !tbaa !39
  %t433 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t436 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t430, { i64, ptr } %t433)
  store i1 %t436, ptr %l220
  br label %bb137
bb137:
  %t437 = load i1, ptr %l220, !tbaa !21
  br i1 %t437, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s21)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s21)
  br label %bb141
bb141:
  %t439 = load i64, ptr %l23, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l23, !tbaa !24
  br label %bb133
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  br i1 true, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  store i1 false, ptr %rv
  br label %ret
bb147:
  call void @__olang_check_failed(ptr @olang_loc_3f7a94628940c729_cdb98f41ead125dd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t12, ptr %lp1
  %t14 = load ptr, ptr %lp1
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7873eed4a01e5678_b9c164dc568d47a4)
  unreachable
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t43 = load ptr, ptr %lp1
  %t45 = getelementptr { i64, ptr }, ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  store i8 %t37, ptr %t47, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb3
bb8:
  %t52 = load ptr, ptr %lp1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l12 = alloca i1
  %l18 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb19
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Seq", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %t35)
  store i1 %t37, ptr %l18
  br label %bb11
bb11:
  %t38 = load i1, ptr %l18, !tbaa !21
  store i1 %t38, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Seq", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  call void @__olang_check_failed(ptr @olang_loc_db336c98c3d140f2_e2aca3dd623cb216)
  unreachable
bb16:
  br label %bb17
bb17:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Seq", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:AssertAsk" @compiler_2fcheck_3aAssertAsk_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8) #0 {
entry:
  %rv = alloca %"compiler/check:AssertAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/check:AssertAsk" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/check:AssertAsk" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/check:AssertAsk" %t22, %"compiler/source:Span" %a2, 2
  %t26 = insertvalue %"compiler/check:AssertAsk" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/check:AssertAsk" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/check:AssertAsk" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/check:AssertAsk" %t30, { i64, ptr } %a6, 6
  %t34 = insertvalue %"compiler/check:AssertAsk" %t32, { i64, [3 x i64] } %a7, 7
  %t36 = insertvalue %"compiler/check:AssertAsk" %t34, { i64, ptr } %a8, 8
  store %"compiler/check:AssertAsk" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:AssertAsk", ptr %rv
  ret %"compiler/check:AssertAsk" %rr
}

define dso_local %"compiler/check:roArg" @compiler_2fcheck_3aroArg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %rv = alloca %"compiler/check:roArg"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/check:roArg" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/check:roArg" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/check:roArg" %t16, { i64, [3 x i64] } %a2, 2
  %t20 = insertvalue %"compiler/check:roArg" %t18, { i64, ptr } %a3, 3
  %t22 = insertvalue %"compiler/check:roArg" %t20, { i64, ptr } %a4, 4
  %t24 = insertvalue %"compiler/check:roArg" %t22, { i64, ptr } %a5, 5
  store %"compiler/check:roArg" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roArg", ptr %rv
  ret %"compiler/check:roArg" %rr
}

@.d0 = private constant [12 x i8] c"LeadingZeros"
@.d1 = private constant [13 x i8] c"TrailingZeros"
@.d2 = private constant [8 x i8] c"PopCount"
@.d3 = private constant [10 x i8] c"RotateLeft"
@.d4 = private constant [11 x i8] c"RotateRight"
@.d5 = private constant [8 x i8] c"ByteSwap"
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant [2 x i8] c", "
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [1 x i8] c"s"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d10 = private constant [25 x i8] c"a conversion of this kind"
@.d11 = private constant [0 x i8] c""
declare void @__olang_ert_req_clear()
@.d12 = private constant [2 x i8] c"At"
@.d13 = private constant [3 x i8] c"'['"
@.d14 = private constant [20 x i8] c"an else of this kind"
@.d15 = private constant [51 x i8] c"an if the build decides, still undecided (S8b, B9c)"
@.d16 = private constant [20 x i8] c"an else of this kind"
@.d17 = private constant [16 x i8] c"an unreachable's"
@.d18 = private constant [11 x i8] c"an assert's"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d19 = private constant [17 x i8] c"std/prelude/array"
@.d20 = private constant [10 x i8] c"ArrayError"
@.d21 = private constant [12 x i8] c"OUT_OF_RANGE"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d22 = private constant [1 x i8] c"_"
@.d23 = private constant [6 x i8] c"String"
@.d24 = private constant [17 x i8] c"instantiated here"
@.d25 = private constant [7 x i8] c", with "
@.d26 = private constant [2 x i8] c", "
@.d27 = private constant [3 x i8] c" = "
@.d28 = private constant [29 x i8] c"an increment as a value (S3a)"
@.d29 = private constant [22 x i8] c"'is' with a type (E32)"
@.d30 = private constant [10 x i8] c"'as' (E32)"
@.d31 = private constant [22 x i8] c"a scope argument (E25)"
@.d32 = private constant [25 x i8] c"a generic name as a value"
@.d33 = private constant [18 x i8] c"a nested row (E21)"
@.d34 = private constant [21 x i8] c"a comprehension (E27)"
@.d35 = private constant [14 x i8] c"a lambda (D16)"
@.d36 = private constant [20 x i8] c"a match value (S12b)"
@.d37 = private constant [27 x i8] c"a range outside a for (S9b)"
@.d38 = private constant [31 x i8] c"'default' outside a call (E14a)"
@.d39 = private constant [21 x i8] c"an index of this kind"
@.d40 = private constant [26 x i8] c"an expression of this kind"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a3fc486149a2dc5d_17491af4361141b9 = external constant [0 x i8]
@olang_loc_980c9dc24d8ab357_bac7a576dce6b97b = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrongCase(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyInstance(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteOtherSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyUnmet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6d92d89bf6179935_a746df8e6ee4ce11 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espread(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5, i32 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %v0)
@olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0)
@olang_loc_460d09842f9fec87_8a34dc35fdcd1373 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
@olang_loc_1a2fe83b02404856_98942d3dbe0d9432 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecCallback(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_5243f41784a5b43d_9dc8734848aaa559 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_67a1dd87ea5136c_f63c1c37282cd7e0 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslotContract(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, { i64, ptr } %a6, i32 %a7, i64 %a8)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorGenericInferredField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
@olang_loc_1b2b22cc85627f3f_81f3e65f4e45ba6b = external constant [0 x i8]
declare { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1)
declare i64 @compiler_2fcheck_2efloatBits(i32 %a0, double %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4)
@olang_loc_c4d3d83bf1f8452c_ec6a6fd400497ee8 = external constant [0 x i8]
@olang_loc_c74df4524a4bbeb9_4f077fe640f42ed5 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/check:atRec" @compiler_2fcheck_3aatRec_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, ptr %a2, i32 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2ePush_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:atRec" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayOneIndex(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexNotInt(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIndexOutOfRange(ptr %v0, i64 %a0, i64 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_823a266be2210958_13324b84b1c75d64 = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarNamesType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_5ec57267b0627cae_caaef3a5d88fe622 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConstraintNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
@olang_loc_2bda502508e1b1d_a3083ba563ab0481 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
@olang_loc_a622476533ee0612_1aeb16e8ac1e1db6 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_319f2f7a6670a39_e028e643a90bcd1d = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H190b78e3c1eec037529224679e114a85(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_856dc584101bc984_5c32a185ff63a848 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_6de95c363ba43753_b985f35754c3cc67 = external constant [0 x i8]
@olang_loc_62c8ad0b34d7b82e_8c827e0bb8ee6f7a = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3219af0a7bb6371b_608971ab22223c2f = external constant [0 x i8]
@olang_loc_9bced391e891fdc0_daecba1c3e9b04cc = external constant [0 x i8]
@olang_loc_8beb387543c1195f_db09fb2ec562613b = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_58a847b11cbe2c6a_cfe1571b02fdc8be = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c2ac910391966871_92a7715ab8ef6a65 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eCondBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ccb3ed4617d06259_8e58603f3b63faf5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:Ask" @compiler_2fcheck_3aAsk_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i32 %a2, ptr %a3, i64 %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2ePush_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:Ask" %a1)
@olang_loc_c77fa73b8d335132_2d868ec26eb5ab4e = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f018e3200f0cebf1_cf14bb53b7e0d845 = external constant [0 x i8]
@olang_loc_63e876f984926a4_8a5a5385d13272e0 = external constant [0 x i8]
@olang_loc_2925a2ee61841cf5_31e6aa96f1b04059 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_c853d17194d5cd4e_2cb2648c67132f32 = external constant [0 x i8]
@olang_loc_c46a74b5b6ac91ff_1e531384a6d2ae73 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseHolds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b5b4909ab910ecd8_969bb6e75e2c8ae4 = external constant [0 x i8]
@olang_loc_204174f82b625491_c4a24154dc66de6d = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_129174e89ad23b8a_c281ac2402d9bb86 = external constant [0 x i8]
@olang_loc_e450882c0be92eca_22c03d797ed0de = external constant [0 x i8]
@olang_loc_14ce9ceb5dce4271_aff89a24b099384d = external constant [0 x i8]
@olang_loc_6f3b4b685ddeb67c_7b5ce21143ef4c38 = external constant [0 x i8]
@olang_loc_e7da762e638de5eb_7df0529e92f5f857 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8ed32cf5e7258066_ffd10e9c2d5e46a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eConditionConstant(ptr %v0)
@olang_loc_4ac5dcd3d6b95a4d_7a015a3c37ae2071 = external constant [0 x i8]
declare { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_162a24c06a0f6e38_d46e08b937be947c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, i1 %a5)
@olang_loc_18bd954db9161a57_4d0d337f3d6dc3eb = external constant [0 x i8]
@olang_loc_f844534d0025e012_1a1d7643daef702e = external constant [0 x i8]
@olang_loc_553bfedf729ee439_b54fafc31e964fd5 = external constant [0 x i8]
@olang_loc_2032043ec708821f_9b3365a6aba1b47b = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
@olang_loc_7e262e55150b6580_229faafeaed7320c = external constant [0 x i8]
declare %"compiler/typed:If" @compiler_2ftyped_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_a6a18c8586cf83c4_fafef84db4cc6ad8 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaResultUninferable(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesIn(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c04d5f47d2250f6_3417b2e0d095e072 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cd94e6a5e488a5b1_e9066543c2d4a76d = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H7b40d2e2dc0a1b98abd717d3c6137546(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9c106c9f4aa088c5_d9578fd6b61bf4a9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Ha95900cb572ddce4e68e0f318299e6b4(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_eb65b3680edb0345_685145072e457a11 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
@olang_loc_bd75af4b3ae4d294_e659e9e595aa9980 = external constant [0 x i8]
@olang_loc_bbebe2756c1f74cf_e5643b8f6a3fbcfb = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_8acdd28853e9448e_36c5d2b255a9987a = external constant [0 x i8]
@olang_loc_5a7b482711619cea_7bdfef37448fa616 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eIndexOf_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aCycle(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_70239da7d97117f8_be3796eb66d568d4 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_397a47855f80e417_31e96358085bf9e3 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__H0499d14ae95d265a50e407376635c44d(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_813406258c5e392b_5a078ade2d158267 = external constant [0 x i8]
declare %"compiler/check:nullNarrow" @compiler_2fcheck_3anullNarrow_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_Heed5ce4b924794f19a38fda2afa7ddeb(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:nullNarrow" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H8da9376267bda3f76393292be0e507b2(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructNotName(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd862b35741eab3a632965773dd6b12ba(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/check:roOrigin" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eknownInt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e722c21055ee6b49_58bcebf0b772fb7d = external constant [0 x i8]
@olang_loc_eca48244095fc078_aacf4c954a6e214c = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eDeclOwner(i32 %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
@olang_loc_5c35d65bf515aa44_9edccba99dd9b7f8 = external constant [0 x i8]
@olang_loc_19568a04807ed851_528b5bfe222c3865 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@olang_loc_130b25e968db6b32_47c65c95f253846 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelementLocals(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_d149dd778abfbb99_ce32867ac8840ced = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId__Hf9046546eeaba1d92e03d463169230dc(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3f7a94628940c729_cdb98f41ead125dd = external constant [0 x i8]
@olang_loc_7873eed4a01e5678_b9c164dc568d47a4 = external constant [0 x i8]
@olang_loc_db336c98c3d140f2_e2aca3dd623cb216 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2epureRead(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3ccompiler_2fsource_3aNameId_3e_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
