; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" = type { ptr, i64, ptr, ptr }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Names" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/interp:Exec" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/lower:Lowerer" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i32 }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/session:symWriter" = type { ptr, i64 }
%"compiler/session:Found" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:FieldInfo" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:finder" = type { i64, i64, { i64, ptr }, ptr, i64, { i64, [6 x i64] }, i64 }
%"compiler/session:typeFinder" = type { i64, i32, i64 }
%"compiler/session:Items" = type { %"std/prelude/text:StringBuilder", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
@G_2ecompiler_2fsession_2eCompConstant = constant <{ [8 x i8] }> <{ [8 x i8] c"\15\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompField = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompFunction = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompKeyword = constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompMethod = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompModule = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompStruct = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompVariable = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKeywords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k1, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k2, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k6, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k9, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k10, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k12, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k13, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k15, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k16, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k17, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k18, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k19, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k20, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k21, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k22, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k23, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k24, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k25, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k26, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k27, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k28, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k29, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k30, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k31, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k32, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k33, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k34, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k35, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k36, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k37, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k38, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k39, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k40, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k41 }>, align 64
@G_2ecompiler_2fsession_2eKeywords.k1 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\66\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k2 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\79\70\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k3 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\6E\75\6D" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\61\69\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\74\65\6E\64\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k7 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\69\6D\70\6F\72\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\65\78\74\65\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k10 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\66" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k11 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\6C\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k13 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\61\6E\67\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6D\61\74\63\68" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k16 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\61\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k17 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\6E\6F\6D\61\74\63\68" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k18 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\72\65\74\75\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k19 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\72\65\61\6B" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k20 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\6E\74\69\6E\75\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k21 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k22 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\72\79" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k23 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\61\74\63\68" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k24 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\64\65\66\61\75\6C\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k25 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6A\6F\69\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k26 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\73\70\61\77\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k27 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\64\65\66\65\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k28 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\61\73\73\65\72\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k29 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\75\6E\72\65\61\63\68\61\62\6C\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k30 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6E\6F\72\65\74\75\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k31 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\75\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k32 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\61\6E\64" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k33 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k34 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6E\6F\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k35 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\78\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k36 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k37 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\61\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k38 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6E\75\6C\6C" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k39 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\72\75\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k40 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\61\6C\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k41 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\64\65\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2fsession_2eKindClass = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindEnum = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindEnumMember = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindField = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindFunction = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindInterface = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindMethod = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindStruct = constant <{ [8 x i8] }> <{ [8 x i8] c"\17\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindVariable = constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
define dso_local ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l9 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca %"compiler/fetch:Fetcher"
  %l26 = alloca %"compiler/source:Names"
  %l28 = alloca { i64, ptr }
  %l35 = alloca %"compiler/load:Loader"
  %l38 = alloca %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce"
  %l39 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l41 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l42 = alloca i32
  %l53 = alloca i64
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca i64
  %l67 = alloca %"compiler/session:Analysis"
  %l72 = alloca i1
  %l74 = alloca i1
  %l77 = alloca %"compiler/check:Checker"
  %l82 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l95 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  %t198 = alloca %"compiler/check:Checker", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l17, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v1)
  store { i64, ptr } %t11, ptr %l18
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v1)
  store { i64, ptr } %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 9
  %t30 = load i1, ptr %t29, !tbaa !21
  %t31 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t35 = call %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t31, { i64, ptr } %t32, { i64, ptr } %t26, i1 %t30, i1 true)
  store %"compiler/fetch:Fetcher" %t35, ptr %l24
  br label %bb4
bb4:
  %t36 = load %"compiler/fetch:Fetcher", ptr %l24
  %t37 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/fetch:Fetcher" %t36, ptr %t37
  store ptr %t37, ptr %l5, !tbaa !29
  %t39 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v1)
  store %"compiler/source:Names" %t39, ptr %l26
  br label %bb5
bb5:
  %t40 = load %"compiler/source:Names", ptr %l26
  %t41 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store %"compiler/source:Names" %t40, ptr %t41
  store ptr %t41, ptr %l6, !tbaa !29
  %t43 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v1)
  store { i64, ptr } %t43, ptr %l28
  br label %bb6
bb6:
  %t44 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  %t46 = extractvalue { i64, ptr } %t44, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %l5, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t62 = call %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t50, ptr %t53, ptr %t54, ptr %t55, ptr %t56)
  store %"compiler/load:Loader" %t62, ptr %l35
  br label %bb7
bb7:
  %t63 = load %"compiler/load:Loader", ptr %l35
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store %"compiler/load:Loader" %t63, ptr %t64
  store ptr %t64, ptr %l7, !tbaa !29
  %t68 = call %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v2, ptr %v2, ptr %a3)
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t68, ptr %l38
  br label %bb8
bb8:
  %t69 = load %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce", ptr %l38
  store %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" %t69, ptr %l8
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t71 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v2, ptr %v2, ptr %l8)
  %t72 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t71, 1
  %t73 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t71, 0
  store i32 %t73, ptr %l42
  %t74 = icmp ne i32 %t73, 0
  br i1 %t74, label %bb11, label %ok.75
ok.75:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t72, ptr %l41
  br label %bb10
bb10:
  %t76 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l41
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t76, ptr %l39
  br label %bb15
bb11:
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  br i1 %t80, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_9597a45ffcf3bed9_58043f2be0cce7d)
  unreachable
bb14:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb15:
  %t82 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l39
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t82, ptr %l9
  %t83 = load ptr, ptr %l7, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 8
  %t86 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l9, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = extractvalue { i64, ptr } %t87, 0
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t89, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t101 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l9, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = extractvalue { i64, ptr } %t102, 0
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t104, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v1, ptr %v1, ptr %v1, ptr %t85, { i64, ptr } %t100, { i64, ptr } %t115)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb9
bb18:
  %t119 = call i64 @std_2ftime_2eNow()
  store i64 %t119, ptr %l53
  br label %bb19
bb19:
  %t120 = load i64, ptr %l53, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t125 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v1, ptr %v0, ptr %t121, { i64, ptr } %t122)
  store i64 %t125, ptr %l56
  br label %bb20
bb20:
  %t126 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t126, ptr %l57, !tbaa !27
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = getelementptr %"compiler/load:Loader", ptr %t127, i32 0, i32 5
  %t131 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v1, ptr %t129)
  store i64 %t131, ptr %l60
  br label %bb21
bb21:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = call i64 @std_2ftime_2eSince(i64 %t132)
  store i64 %t134, ptr %l62
  br label %bb22
bb22:
  %t135 = load i64, ptr %l62, !tbaa !24
  %t136 = sdiv i64 %t135, 1000000
  %t137 = extractvalue { i64, ptr } { i64 7, ptr @.d0 }, 1
  %t138 = extractvalue { i64, ptr } { i64 7, ptr @.d0 }, 0
  %t139 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 2, ptr @.d1 }, 1
  %t144 = extractvalue { i64, ptr } { i64 2, ptr @.d1 }, 0
  %t145 = add i64 %t142, %t144
  %t146 = load i64, ptr %l60, !tbaa !24
  %t147 = call i64 @__olang_fmt_i64(ptr null, i64 %t146)
  %t148 = add i64 %t145, %t147
  %t149 = extractvalue { i64, ptr } { i64 13, ptr @.d2 }, 1
  %t150 = extractvalue { i64, ptr } { i64 13, ptr @.d2 }, 0
  %t151 = add i64 %t148, %t150
  %t153 = call i64 @__olang_fmt_i64(ptr null, i64 %t136)
  %t154 = add i64 %t151, %t153
  %t155 = extractvalue { i64, ptr } { i64 3, ptr @.d3 }, 1
  %t156 = extractvalue { i64, ptr } { i64 3, ptr @.d3 }, 0
  %t157 = add i64 %t154, %t156
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t137, i64 %t138)
  %t159 = getelementptr i8, ptr %t158, i64 %t138
  call void @olang_textcopy(ptr %t159, ptr %t140, i64 %t141)
  %t160 = getelementptr i8, ptr %t159, i64 %t141
  call void @olang_textcopy(ptr %t160, ptr %t143, i64 %t144)
  %t161 = getelementptr i8, ptr %t160, i64 %t144
  %t162 = call i64 @__olang_fmt_i64(ptr %t161, i64 %t146)
  %t163 = getelementptr i8, ptr %t161, i64 %t147
  call void @olang_textcopy(ptr %t163, ptr %t149, i64 %t150)
  %t164 = getelementptr i8, ptr %t163, i64 %t150
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t136)
  %t166 = getelementptr i8, ptr %t164, i64 %t153
  call void @olang_textcopy(ptr %t166, ptr %t155, i64 %t156)
  %t167 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t158, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t175)
  br label %bb23
bb23:
  %t177 = load ptr, ptr %l7, !tbaa !29
  %t179 = call %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v1, ptr %v1, ptr %t177)
  store %"compiler/session:Analysis" %t179, ptr %l67
  br label %bb24
bb24:
  %t180 = load %"compiler/session:Analysis", ptr %l67
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/session:Analysis" %t180, ptr %t181
  store ptr %t181, ptr %l11, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t185 = getelementptr %"compiler/load:Loader", ptr %t183, i32 0, i32 7
  %t186 = load i64, ptr %t185, !tbaa !24
  %t188 = icmp slt i64 %t186, 0
  br i1 %t188, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb28
bb26:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v1, ptr %t190)
  store i1 %t192, ptr %l74
  br label %bb27
bb27:
  %t193 = load i1, ptr %l74, !tbaa !21
  store i1 %t193, ptr %l72, !tbaa !21
  br label %bb28
bb28:
  %t194 = load i1, ptr %l72, !tbaa !21
  br i1 %t194, label %bb29, label %bb30
bb29:
  %t195 = load ptr, ptr %l11, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t195, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t197 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t198, ptr %v1, ptr %v1, ptr %t197, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l77, ptr %t198, i64 720, i1 false)
  br label %bb32
bb32:
  %t200 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 720, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t200, ptr %l77, i64 720, i1 false)
  store ptr %t200, ptr %l12, !tbaa !29
  %t202 = load ptr, ptr %l11, !tbaa !29
  %t203 = load ptr, ptr %l12, !tbaa !29
  %t207 = getelementptr %"compiler/session:Analysis", ptr %t202, i32 0, i32 1
  store ptr %t203, ptr %t207, !tbaa !29
  %t208 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %l82
  br label %bb33
bb33:
  %t209 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  %t210 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t209, ptr %t210
  store ptr %t210, ptr %l13, !tbaa !29
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t214 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t212)
  store i64 %t214, ptr %l85
  br label %bb34
bb34:
  %t215 = load i64, ptr %l85, !tbaa !24
  %t216 = icmp eq i64 %t215, 0
  store i1 %t216, ptr %l14, !tbaa !21
  %t218 = load i1, ptr %l14, !tbaa !21
  br i1 %t218, label %bb35, label %bb36
bb35:
  %t220 = load ptr, ptr %l12, !tbaa !29
  %t222 = call i64 @compiler_2finterp_2eDecideValues(ptr %v1, ptr %t220)
  store i64 %t222, ptr %l89
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t223 = load ptr, ptr %l12, !tbaa !29
  %t224 = load ptr, ptr %l13, !tbaa !29
  %t227 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v1, ptr %v1, ptr %t223, ptr %t224)
  store i64 %t227, ptr %l92
  br label %bb39
bb39:
  %t228 = load i1, ptr %l14, !tbaa !21
  br i1 %t228, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t230 = load ptr, ptr %l12, !tbaa !29
  %t232 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v1, ptr %s8, ptr %t230)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l95
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t233 = load i64, ptr %l10, !tbaa !24
  %t235 = call i64 @std_2ftime_2eSince(i64 %t233)
  store i64 %t235, ptr %l97
  br label %bb44
bb44:
  %t236 = load i64, ptr %l97, !tbaa !24
  %t237 = sdiv i64 %t236, 1000000
  %t238 = extractvalue { i64, ptr } { i64 11, ptr @.d4 }, 1
  %t239 = extractvalue { i64, ptr } { i64 11, ptr @.d4 }, 0
  %t241 = call i64 @__olang_fmt_i64(ptr null, i64 %t237)
  %t242 = add i64 %t239, %t241
  %t243 = extractvalue { i64, ptr } { i64 3, ptr @.d5 }, 1
  %t244 = extractvalue { i64, ptr } { i64 3, ptr @.d5 }, 0
  %t245 = add i64 %t242, %t244
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t238, i64 %t239)
  %t247 = getelementptr i8, ptr %t246, i64 %t239
  %t248 = call i64 @__olang_fmt_i64(ptr %t247, i64 %t237)
  %t249 = getelementptr i8, ptr %t247, i64 %t241
  call void @olang_textcopy(ptr %t249, ptr %t243, i64 %t244)
  %t250 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t246, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t258)
  br label %bb45
bb45:
  br i1 %a4, label %bb46, label %bb47
bb46:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2eHold(ptr %v1, ptr %v1, ptr %t262, ptr %t263)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t266 = load ptr, ptr %l11, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t266, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca { i32, i32 }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/session:Reader"
  %l6 = alloca i32
  %l7 = alloca { i32, i32 }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i32
  %l21 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca i32
  %l36 = alloca %"compiler/session:Reader"
  %l38 = alloca i1
  %l42 = alloca i32
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load { i32, i32 }, ptr %l7
  store { i32, i32 } %t2, ptr %l1
  %t3 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t6 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t11 = icmp slt i32 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { ptr, ptr }, ptr %l0
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  %t17 = call { i64, ptr } %t15(ptr %t16, ptr %v1)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t19 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t18, 0
  %t20 = insertvalue { { i64, ptr }, i32 } %t19, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t20, ptr %rv
  br label %ret
bb5:
  %t22 = call i32 @fork()
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t28)
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t30 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t30)
  br label %bb10
bb10:
  %t32 = load { ptr, ptr }, ptr %l0
  %t34 = extractvalue { ptr, ptr } %t32, 0
  %t35 = extractvalue { ptr, ptr } %t32, 1
  %t36 = call { i64, ptr } %t34(ptr %t35, ptr %v1)
  store { i64, ptr } %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t38 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t37, 0
  %t39 = insertvalue { { i64, ptr }, i32 } %t38, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t39, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp eq i32 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t45)
  br label %bb15
bb14:
  br label %bb25
bb15:
  call void @compiler_2fsession_2eDup2(i32 2, i32 1)
  br label %bb16
bb16:
  %t47 = load i32, ptr %l3, !tbaa !23
  store i32 %t47, ptr %l26, !tbaa !23
  %t48 = load { ptr, ptr }, ptr %l0
  %t50 = extractvalue { ptr, ptr } %t48, 0
  %t51 = extractvalue { ptr, ptr } %t48, 1
  %t52 = call { i64, ptr } %t50(ptr %t51, ptr %s3)
  store { i64, ptr } %t52, ptr %l28
  br label %bb17
bb17:
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load i32, ptr %l26, !tbaa !23
  %t63 = call i32 @std_2fio_2eWrite(ptr %s3, i32 %t61, { i64, ptr } %t60)
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65
ok.65:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t66 = load i32, ptr %l31, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  br i1 %t69, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_35fd852a81194674_cc9a5a6794b34358)
  unreachable
bb22:
  call void @__olang_ert_req_clear()
  br label %bb23
bb23:
  call void @_exit(i32 0)
  unreachable
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2e5a67dd47f860a5_3bdcee40b40c1629)
  unreachable
bb25:
  %t71 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t71)
  br label %bb26
bb26:
  %t73 = load i32, ptr %l2, !tbaa !23
  %t75 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 %t73)
  store %"compiler/session:Reader" %t75, ptr %l36
  br label %bb27
bb27:
  %t76 = load %"compiler/session:Reader", ptr %l36
  store %"compiler/session:Reader" %t76, ptr %l5
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %l5)
  store i1 %t78, ptr %l38
  br label %bb29
bb29:
  %t79 = load i1, ptr %l38, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb28
bb34:
  %t82 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t82)
  br label %bb35
bb35:
  %t84 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2fsession_2eReap(i32 %t84)
  store i32 %t86, ptr %l42
  br label %bb36
bb36:
  %t87 = load i32, ptr %l42, !tbaa !23
  store i32 %t87, ptr %l6, !tbaa !23
  %t88 = getelementptr %"compiler/session:Reader", ptr %l5, i32 0, i32 1
  %t90 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %s0, ptr %t88)
  store { i64, ptr } %t90, ptr %l44
  br label %bb37
bb37:
  %t91 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = extractvalue { i64, ptr } %t91, 0
  %t95 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t93, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t98 = load i32, ptr %l6, !tbaa !23
  %t100 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t97, 0
  %t102 = insertvalue { { i64, ptr }, i32 } %t100, i32 %t98, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local void @compiler_2fsession_2eCloseFd(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l4 = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp sge i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l0, !tbaa !23
  %t7 = call i32 @close(i32 %t5)
  store i32 %t7, ptr %l4
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompConstant_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 21, ptr @G_2ecompiler_2fsession_2eCompConstant, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompField_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2fsession_2eCompField, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompFunction_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fsession_2eCompFunction, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompKeyword_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 14, ptr @G_2ecompiler_2fsession_2eCompKeyword, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompMethod_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompModule_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 9, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompStruct_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 22, ptr @G_2ecompiler_2fsession_2eCompStruct, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eCompVariable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca %"compiler/diag:Diagnostics"
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i1
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l65 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca { i64, [3 x i64] }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/msgs:Msg"
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l110 = alloca %"compiler/doc:Module"
  %l112 = alloca { i64, ptr }
  %l115 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l123 = alloca { i64, ptr }
  %l133 = alloca i64
  %l137 = alloca i32
  %l144 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca i32
  %l159 = alloca { i64, ptr }
  %l166 = alloca i32
  %l168 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i32
  %l174 = alloca ptr
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l184 = alloca %"compiler/doc:Module"
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l204 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t6 = alloca %"compiler/diag:Diagnostics", align 8
  %t135 = alloca { i64, [3 x i64] }, align 8
  %t355 = alloca { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr @.d6 })
  store i1 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i1, ptr %l23, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t5, ptr %l24
  br label %bb4
bb3:
  br label %bb58
bb4:
  %t7 = load i1, ptr %l24, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t6, ptr %v3, i1 %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t6, i64 200, i1 false)
  br label %bb5
bb5:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t8, ptr %l25, i64 200, i1 false)
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l27, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %t12, i64 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !37
  store { i64, ptr } %t14, ptr %l28, !tbaa !27
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l29, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l30, !tbaa !29
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l31
  br label %bb6
bb6:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  %t19 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %t19
  %t20 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t22 = load ptr, ptr %l30, !tbaa !29
  %t24 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v3, ptr %s1, { i64, ptr } %t20, ptr %t21, ptr %t22, ptr %t19, i1 true)
  store ptr %t24, ptr %l33
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l33, !tbaa !29
  store ptr %t25, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t26)
  store i64 %t28, ptr %l35
  br label %bb8
bb8:
  %t29 = load i64, ptr %l35, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/session:Analysis", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  store i1 %t37, ptr %l37, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l37, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb14
bb13:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/session:Analysis", ptr %t40, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  store i1 %t45, ptr %l41, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l41, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s2, ptr %t48)
  store { i64, ptr } %t50, ptr %l46
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t51 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t57)
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v3, ptr %s2, ptr %t59)
  store { i64, ptr } %t61, ptr %l49
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t68)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb21:
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr @.d7 })
  store i1 %t73, ptr %l53
  br label %bb22
bb22:
  %t74 = load i1, ptr %l53, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/session:Analysis", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb25, label %bb26
bb24:
  br label %bb45
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb26:
  br label %bb27
bb27:
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr %"compiler/session:Analysis", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l60, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/session:Analysis", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t97 = getelementptr %"compiler/session:Analysis", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l65, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t101 = getelementptr %"compiler/session:Analysis", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t108 = getelementptr %"compiler/session:Analysis", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = getelementptr %"compiler/session:Analysis", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 7
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t118 = load ptr, ptr %l60, !tbaa !29
  %t119 = load ptr, ptr %l65, !tbaa !29
  %t123 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v3, ptr %v3, ptr %v3, ptr %v1, ptr %s3, ptr %t118, ptr %t119, ptr %t109, i64 %t116, { i64, ptr } %t117)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l76
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb35, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l75
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t128, ptr %l55, !tbaa !27
  br label %bb43
bb35:
  %t129 = load i32, ptr %l76, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1ea25794a8230c9f_eba27a85472598cb)
  unreachable
bb38:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t134 = load ptr, ptr %l4, !tbaa !29
  store ptr %t134, ptr %l79, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 0
  store i64 0, ptr %t136
  %t137 = load { i64, [3 x i64] }, ptr %t135
  store { i64, [3 x i64] } %t137, ptr %l80
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t139, ptr %l82, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %t141, i64 0
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !37
  %t146 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v1, ptr %v0, ptr %s4, { i64, ptr } %t138, { i64, ptr } %t143)
  store %"compiler/msgs:Msg" %t146, ptr %l84
  br label %bb39
bb39:
  %t147 = load ptr, ptr %l79, !tbaa !29
  %t148 = load { i64, [3 x i64] }, ptr %l80
  %t149 = load %"compiler/msgs:Msg", ptr %l84
  %t150 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s4, ptr %t147, { i64, [3 x i64] } %t148, %"compiler/msgs:Msg" %t149)
  store i64 %t150, ptr %l85
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s4, ptr %t151)
  store { i64, ptr } %t153, ptr %l87
  br label %bb41
bb41:
  %t154 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  call void @compiler_2fsession_2esay(ptr %s4, { i64, ptr } %t160)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb43:
  %t163 = load { i64, ptr }, ptr %l55, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s3, { i64, ptr } %t163)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb45:
  %t167 = load ptr, ptr %l5, !tbaa !29
  %t169 = getelementptr %"compiler/session:Analysis", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = icmp eq ptr %t170, null
  br i1 %t172, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_3d3ecb4e4c1abd3d_61c17d26e89329d9)
  unreachable
bb47:
  br label %bb48
bb48:
  %t174 = load ptr, ptr %l5, !tbaa !29
  %t176 = getelementptr %"compiler/session:Analysis", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  store ptr %t177, ptr %l96, !tbaa !29
  %t178 = load ptr, ptr %l5, !tbaa !29
  %t180 = getelementptr %"compiler/session:Analysis", ptr %t178, i32 0, i32 2
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = icmp eq ptr %t181, null
  br i1 %t183, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3d3ecb4e4c1abd3d_61c17d26e89329d9)
  unreachable
bb50:
  br label %bb51
bb51:
  %t185 = load ptr, ptr %l5, !tbaa !29
  %t187 = getelementptr %"compiler/session:Analysis", ptr %t185, i32 0, i32 2
  %t188 = load ptr, ptr %t187, !tbaa !29
  store ptr %t188, ptr %l101, !tbaa !29
  %t189 = load ptr, ptr %l5, !tbaa !29
  %t191 = getelementptr %"compiler/session:Analysis", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3d3ecb4e4c1abd3d_61c17d26e89329d9)
  unreachable
bb53:
  br label %bb54
bb54:
  %t196 = load ptr, ptr %l5, !tbaa !29
  %t198 = getelementptr %"compiler/session:Analysis", ptr %t196, i32 0, i32 3
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  %t202 = getelementptr %"compiler/session:Analysis", ptr %t200, i32 0, i32 0
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/load:Loader", ptr %t203, i32 0, i32 7
  %t206 = load i64, ptr %t205, !tbaa !24
  %t207 = load ptr, ptr %l96, !tbaa !29
  %t208 = load ptr, ptr %l101, !tbaa !29
  %t211 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v3, ptr %v3, ptr %v3, ptr %s1, ptr %t207, ptr %t208, ptr %t199, i64 %t206, i1 false)
  store %"compiler/doc:Module" %t211, ptr %l110
  br label %bb55
bb55:
  %t212 = load %"compiler/doc:Module", ptr %l110
  %t213 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 56, i64 8)
  store %"compiler/doc:Module" %t212, ptr %t213
  %t215 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %s1, ptr %s1, ptr %t213)
  store { i64, ptr } %t215, ptr %l112
  br label %bb56
bb56:
  %t216 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t222)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb58:
  %t225 = load ptr, ptr @__olang_prog_scope
  %t226 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t225)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %l115
  br label %bb59
bb59:
  %t227 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l7
  %t228 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t228, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t234 = load i64, ptr %l9, !tbaa !24
  %t235 = load i64, ptr %l10, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t242 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t242, ptr %l123, !tbaa !27
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %t246, i64 %t243
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !37
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t252, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = mul i64 %t258, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t261, ptr %t259, i64 %t260, i1 false)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t263)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s6)
  br label %bb65
bb65:
  %t266 = load i64, ptr %l9, !tbaa !24
  %t268 = add i64 %t266, 1
  store i64 %t268, ptr %l9, !tbaa !24
  br label %bb60
bb66:
  %t271 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %s0, ptr %l7)
  store i64 %t271, ptr %l133
  br label %bb67
bb67:
  %t272 = load i64, ptr %l133, !tbaa !24
  %t273 = icmp eq i64 %t272, 0
  br i1 %t273, label %bb68, label %bb69
bb68:
  call void @compiler_2fsession_2estdModules(ptr %s0, ptr %l7)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t276 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t278 = call i32 @std_2fos_2eMkDirAll(ptr %v2, { i64, ptr } %t276)
  store i32 %t278, ptr %l137
  %t279 = icmp ne i32 %t278, 0
  br i1 %t279, label %bb73, label %ok.280
ok.280:
  br label %bb72
bb72:
  br label %bb78
bb73:
  %t281 = load i32, ptr %l137, !tbaa !23
  %t282 = ashr i32 %t281, 16
  %t284 = icmp eq i32 %t282, 1
  br i1 %t284, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_849d325a162e3455_c407129f4a4a7021)
  unreachable
bb76:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t286 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t287 = extractvalue { i64, ptr } { i64 7, ptr @.d8 }, 1
  %t288 = extractvalue { i64, ptr } { i64 7, ptr @.d8 }, 0
  %t290 = extractvalue { i64, ptr } %t286, 1
  %t291 = extractvalue { i64, ptr } %t286, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 17, ptr @.d9 }, 1
  %t294 = extractvalue { i64, ptr } { i64 17, ptr @.d9 }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t287, i64 %t288)
  %t297 = getelementptr i8, ptr %t296, i64 %t288
  call void @olang_textcopy(ptr %t297, ptr %t290, i64 %t291)
  %t298 = getelementptr i8, ptr %t297, i64 %t291
  call void @olang_textcopy(ptr %t298, ptr %t293, i64 %t294)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t296, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  call void @compiler_2fsession_2esay(ptr %s10, { i64, ptr } %t307)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb78:
  store i32 0, ptr %l12, !tbaa !23
  %t310 = load ptr, ptr @__olang_prog_scope
  %t311 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e(ptr %t310)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t311, ptr %l144
  br label %bb79
bb79:
  %t312 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l144
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t312, ptr %l13
  store ptr %l7, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s13
  %t314 = load ptr, ptr %l14, !tbaa !29
  %t315 = load i64, ptr %l15, !tbaa !24
  %t318 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t314, i64 %t315)
  %t319 = extractvalue { i32, { i64, ptr } } %t318, 1
  %t320 = extractvalue { i32, { i64, ptr } } %t318, 0
  store i32 %t320, ptr %l150
  %t321 = icmp ne i32 %t320, 0
  br i1 %t321, label %bb82, label %ok.322
ok.322:
  store { i64, ptr } %t319, ptr %l149
  br label %bb81
bb81:
  %t323 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t323, ptr %l146, !tbaa !27
  br label %bb86
bb82:
  %t324 = load i32, ptr %l150, !tbaa !23
  %t325 = ashr i32 %t324, 16
  %t327 = icmp eq i32 %t325, 1
  br i1 %t327, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_955ee6d2dd4da682_b67b6619c21949c6)
  unreachable
bb85:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb108
bb86:
  %t329 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t329, ptr %l16, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  store i64 %t332, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s14
  %t334 = load i64, ptr %l18, !tbaa !24
  %t335 = load i64, ptr %l17, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb89:
  br label %bb90
bb90:
  %t342 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t342, ptr %l159, !tbaa !27
  %t343 = load i64, ptr %l18, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %t346, i64 %t343
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !37
  store { i64, ptr } %t348, ptr %l19, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t351 = load ptr, ptr %l3, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t353 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr null, i32 1
  %t354 = ptrtoint ptr %t353 to i64
  %t356 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 0
  store { i64, ptr } %t350, ptr %t356, !tbaa !28
  %t358 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 1
  store ptr %t351, ptr %t358, !tbaa !28
  %t360 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 2
  store { i64, ptr } %t352, ptr %t360, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t362 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 3
  store ptr %s0, ptr %t362, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t363 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 4
  store ptr %v3, ptr %t363, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t364 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t355, i32 0, i32 5
  store ptr %v2, ptr %t364, !tbaa !28
  %t365 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_10, 0
  %t366 = insertvalue { ptr, ptr } %t365, ptr %t355, 1
  %t368 = extractvalue { ptr, ptr } %t366, 0
  %t369 = extractvalue { ptr, ptr } %t366, 1
  %t370 = call i32 @compiler_2fsession_2eInChild(ptr %s14, ptr %t368, ptr %t369)
  store i32 %t370, ptr %l166
  br label %bb91
bb91:
  %t371 = load i32, ptr %l166, !tbaa !23
  %t372 = icmp ne i32 %t371, 0
  br i1 %t372, label %bb92, label %bb93
bb92:
  store i32 1, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  br label %bb105
bb93:
  br label %bb94
bb94:
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t376 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s14, { i64, ptr } %t374)
  %t377 = extractvalue { i32, { i64, ptr } } %t376, 1
  %t378 = extractvalue { i32, { i64, ptr } } %t376, 0
  store i32 %t378, ptr %l171
  %t379 = icmp ne i32 %t378, 0
  br i1 %t379, label %bb96, label %ok.380
ok.380:
  store { i64, ptr } %t377, ptr %l170
  br label %bb95
bb95:
  %t381 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t381, ptr %l168, !tbaa !27
  br label %bb100
bb96:
  %t382 = load i32, ptr %l171, !tbaa !23
  %t383 = ashr i32 %t382, 16
  %t385 = icmp eq i32 %t383, 1
  br i1 %t385, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_59b0d3c23afb5803_7d478ed24d90bfa7)
  unreachable
bb99:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb105
bb100:
  %t387 = load { i64, ptr }, ptr %l168, !tbaa !27
  store { i64, ptr } %t387, ptr %l20, !tbaa !27
  store ptr %l13, ptr %l174, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t390 = call { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %s0, ptr %s0, { i64, ptr } %t388)
  store { i64, ptr } %t390, ptr %l176
  br label %bb101
bb101:
  %t391 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 0
  %t393 = extractvalue { i64, ptr } %t391, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  store { i64, ptr } %t397, ptr %l177, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t398, 1
  %t401 = extractvalue { i64, ptr } %t398, 0
  %t402 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t401)
  call void @olang_textcopy(ptr %t402, ptr %t400, i64 %t401)
  %t403 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = extractvalue { i64, ptr } %t404, 1
  %t408 = mul i64 %t406, 1
  %t409 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t408)
  call void @llvm.memcpy.p0.p0.i64(ptr %t409, ptr %t407, i64 %t408, i1 false)
  %t410 = insertvalue { i64, ptr } undef, i64 %t406, 0
  %t411 = insertvalue { i64, ptr } %t410, ptr %t409, 1
  store { i64, ptr } %t411, ptr %l180, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t414 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %s14, ptr %s0, { i64, ptr } %t412)
  store { i64, ptr } %t414, ptr %l182
  br label %bb102
bb102:
  %t415 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  %t417 = extractvalue { i64, ptr } %t415, 1
  %t418 = mul i64 %t416, 1
  %t419 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t418)
  call void @llvm.memcpy.p0.p0.i64(ptr %t419, ptr %t417, i64 %t418, i1 false)
  %t420 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t419, 1
  %t422 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t425 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t422, { i64, ptr } %t423, { i64, ptr } %t421)
  store %"compiler/doc:Module" %t425, ptr %l184
  br label %bb103
bb103:
  %t426 = load ptr, ptr %l174, !tbaa !29
  %t427 = load %"compiler/doc:Module", ptr %l184
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %t426, %"compiler/doc:Module" %t427)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s14)
  br label %bb105
bb105:
  %t428 = load i64, ptr %l18, !tbaa !24
  %t430 = add i64 %t428, 1
  store i64 %t430, ptr %l18, !tbaa !24
  br label %bb87
bb106:
  %t432 = load i64, ptr %l15, !tbaa !24
  %t433 = load i64, ptr %l17, !tbaa !24
  %t436 = add i64 %t432, %t433
  store i64 %t436, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb107
bb107:
  br label %bb80
bb108:
  %t438 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t439 = insertvalue { ptr, ptr } %t438, ptr null, 1
  %t442 = extractvalue { ptr, ptr } %t439, 0
  %t443 = extractvalue { ptr, ptr } %t439, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2eSort_3_H1ab8198b77e0f018190e9fba053e1380(ptr %s0, ptr %s0, ptr %l13, ptr %t442, ptr %t443)
  br label %bb109
bb109:
  %t444 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t446 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t444, { i64, ptr } { i64 10, ptr @.d12 }, { i64, ptr } { i64 0, ptr @.d13 }, { i64, ptr } { i64 0, ptr @.d14 }, { i64, ptr } { i64 0, ptr @.d15 }, { i64, ptr } { i64 0, ptr @.d16 })
  store { i64, ptr } %t446, ptr %l193
  br label %bb110
bb110:
  %t447 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t447, ptr %l21, !tbaa !27
  %t448 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t448, ptr %l194, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t449, 0
  %t453 = icmp eq i64 %t451, 0
  br i1 %t453, label %bb111, label %bb112
bb111:
  store { i64, ptr } { i64 22, ptr @.d17 }, ptr %l198, !tbaa !27
  br label %bb113
bb112:
  store { i64, ptr } { i64 5, ptr @.d18 }, ptr %l198, !tbaa !27
  br label %bb113
bb113:
  %t456 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t456, ptr %l200
  br label %bb114
bb114:
  %t457 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t459 = call { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t457, { i64, ptr } %t458)
  store { i64, ptr } %t459, ptr %l201
  br label %bb115
bb115:
  %t460 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = extractvalue { i64, ptr } %t460, 1
  %t464 = mul i64 %t462, 1
  %t465 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t465, ptr %t463, i64 %t464, i1 false)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t468 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t470 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t468, { i64, ptr } %t467)
  store i32 %t470, ptr %l204
  %t471 = icmp ne i32 %t470, 0
  br i1 %t471, label %bb117, label %ok.472
ok.472:
  br label %bb116
bb116:
  br label %bb122
bb117:
  %t473 = load i32, ptr %l204, !tbaa !23
  %t474 = ashr i32 %t473, 16
  %t476 = icmp eq i32 %t474, 1
  br i1 %t476, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_1a1e266cc778f828_672b31d7f6f9b22c)
  unreachable
bb120:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s19
  %t478 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t479 = extractvalue { i64, ptr } { i64 7, ptr @.d19 }, 1
  %t480 = extractvalue { i64, ptr } { i64 7, ptr @.d19 }, 0
  %t482 = extractvalue { i64, ptr } %t478, 1
  %t483 = extractvalue { i64, ptr } %t478, 0
  %t484 = add i64 %t480, %t483
  %t485 = extractvalue { i64, ptr } { i64 20, ptr @.d20 }, 1
  %t486 = extractvalue { i64, ptr } { i64 20, ptr @.d20 }, 0
  %t487 = add i64 %t484, %t486
  %t488 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t487)
  call void @olang_textcopy(ptr %t488, ptr %t479, i64 %t480)
  %t489 = getelementptr i8, ptr %t488, i64 %t480
  call void @olang_textcopy(ptr %t489, ptr %t482, i64 %t483)
  %t490 = getelementptr i8, ptr %t489, i64 %t483
  call void @olang_textcopy(ptr %t490, ptr %t485, i64 %t486)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t488, 1
  %t494 = extractvalue { i64, ptr } %t492, 0
  %t495 = extractvalue { i64, ptr } %t492, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  call void @compiler_2fsession_2esay(ptr %s19, { i64, ptr } %t499)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb122:
  %t502 = load i32, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t502, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2eDup2(i32 %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @dup2(i32 %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eExit(i32 %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_exit(i32 %a0)
  unreachable
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb449e3906b36447_37ec3fcb8d3ba1cb)
  unreachable
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eExitStatus(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l6 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = and i32 %t1, 127
  store i32 %t3, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp eq i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i32, ptr %l0, !tbaa !23
  %t11 = ashr i32 %t9, 8
  %t13 = and i32 %t11, 255
  store i32 %t13, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = add i32 128, %t15
  store i32 %t17, ptr %l6, !tbaa !23
  br label %bb3
bb3:
  %t19 = load i32, ptr %l6, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fsession_2eFork() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @fork()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Source"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t3, ptr %l5
  br label %bb2
bb2:
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t22 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v2, ptr %v1, ptr %v2, { i64, ptr } %t18, { i64, ptr } %a1)
  store %"compiler/source:Source" %t22, ptr %l11
  br label %bb3
bb3:
  %t23 = load %"compiler/source:Source", ptr %l11
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store %"compiler/source:Source" %t23, ptr %t24
  store ptr %t24, ptr %l12, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %l13, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t28 = call { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %s0, ptr %v2, { i64, ptr } %t26)
  store { i64, ptr } %t28, ptr %l15
  br label %bb4
bb4:
  %t29 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  %t36 = load ptr, ptr %l12, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t40 = call { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v2, ptr %s0, ptr %v2, ptr %s0, ptr %v2, ptr %t36, { i64, ptr } %t37, { i64, ptr } %t35, i1 false, ptr %l2)
  %t41 = extractvalue { i32, { i64, ptr } } %t40, 1
  %t42 = extractvalue { i32, { i64, ptr } } %t40, 0
  store i32 %t42, ptr %l19
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb6, label %ok.44
ok.44:
  store { i64, ptr } %t41, ptr %l18
  br label %bb5
bb5:
  %t45 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  br label %bb7
bb6:
  %t46 = load i32, ptr %l19, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t46, 0
  %t52 = shl i32 %t50, 16
  %t53 = or i32 %t52, %t48
  %t54 = select i1 %t51, i32 0, i32 %t53
  call void @__olang_scope_close(ptr %s0)
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t54, 0
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t57, 1
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fsession_2eHold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l26 = alloca ptr
  %l32 = alloca %"compiler/scope:Scoper"
  %l42 = alloca i64
  %l53 = alloca ptr
  %l60 = alloca %"compiler/interp:Exec"
  %l62 = alloca ptr
  %s0 = alloca %olang.scope
  %t54 = alloca %"compiler/scope:Scoper", align 8
  %t138 = alloca %"compiler/interp:Exec", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/session:Analysis", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %t24)
  store i1 %t26, ptr %l18
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call i64 @std_2ftime_2eNow()
  store i64 %t29, ptr %l19
  br label %bb11
bb11:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_35f6bc648a66c5f9_fb290a2b6e993705)
  unreachable
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_35f6bc648a66c5f9_fb290a2b6e993705)
  unreachable
bb16:
  br label %bb17
bb17:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 11
  %t53 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t52
  %t55 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fscope_3aScoper_2ector(ptr %t54, ptr %v0, ptr %v0, ptr %v1, ptr %t55, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t54, i64 1024, i1 false)
  br label %bb18
bb18:
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 1024, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %l32, i64 1024, i1 false)
  store ptr %t57, ptr %l4, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t62 = ptrtoint ptr %t61 to i64
  %t63 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t62, i64 8)
  %t64 = getelementptr { ptr, ptr }, ptr %t63, i32 0, i32 0
  store ptr %t60, ptr %t64, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t66 = getelementptr { ptr, ptr }, ptr %t63, i32 0, i32 1
  store ptr %v0, ptr %t66, !tbaa !28
  %t67 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_21, 0
  %t68 = insertvalue { ptr, ptr } %t67, ptr %t63, 1
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %t59, i32 0, i32 4
  store { ptr, ptr } %t68, ptr %t71
  %t72 = load ptr, ptr %l4, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t75 = ptrtoint ptr %t74 to i64
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t75, i64 8)
  %t77 = getelementptr { ptr, ptr }, ptr %t76, i32 0, i32 0
  store ptr %t73, ptr %t77, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t79 = getelementptr { ptr, ptr }, ptr %t76, i32 0, i32 1
  store ptr %v0, ptr %t79, !tbaa !28
  %t80 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_22, 0
  %t81 = insertvalue { ptr, ptr } %t80, ptr %t76, 1
  %t84 = getelementptr %"compiler/scope:Scoper", ptr %t72, i32 0, i32 5
  store { ptr, ptr } %t81, ptr %t84
  %t85 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v1, ptr %t85)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = call i64 @std_2ftime_2eSince(i64 %t87)
  store i64 %t89, ptr %l42
  br label %bb20
bb20:
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = sdiv i64 %t90, 1000000
  %t92 = extractvalue { i64, ptr } { i64 21, ptr @.d23 }, 1
  %t93 = extractvalue { i64, ptr } { i64 21, ptr @.d23 }, 0
  %t95 = call i64 @__olang_fmt_i64(ptr null, i64 %t91)
  %t96 = add i64 %t93, %t95
  %t97 = extractvalue { i64, ptr } { i64 3, ptr @.d24 }, 1
  %t98 = extractvalue { i64, ptr } { i64 3, ptr @.d24 }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t92, i64 %t93)
  %t101 = getelementptr i8, ptr %t100, i64 %t93
  %t102 = call i64 @__olang_fmt_i64(ptr %t101, i64 %t91)
  %t103 = getelementptr i8, ptr %t101, i64 %t95
  call void @olang_textcopy(ptr %t103, ptr %t97, i64 %t98)
  %t104 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t100, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = extractvalue { i64, ptr } %t105, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t112)
  br label %bb21
bb21:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t119 = getelementptr %"compiler/session:Analysis", ptr %t114, i32 0, i32 2
  store ptr %t115, ptr %t119, !tbaa !29
  %t120 = load ptr, ptr %l3, !tbaa !29
  %t122 = icmp eq ptr %t120, null
  br i1 %t122, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e)
  unreachable
bb23:
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  store ptr %t128, ptr %l53, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e)
  unreachable
bb26:
  br label %bb27
bb27:
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 11
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t136
  %t139 = load ptr, ptr %l53, !tbaa !29
  call void @compiler_2finterp_3aExec_2ector(ptr %t138, ptr %v0, ptr %v0, ptr %v1, ptr %t139, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t138, i64 936, i1 false)
  br label %bb28
bb28:
  %t142 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 936, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t142, ptr %l60, i64 936, i1 false)
  store ptr %t142, ptr %l5, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  store ptr %t144, ptr %l62, !tbaa !29
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  br i1 %t147, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_6f935d255f99d513_bebfb26ca618488f)
  unreachable
bb30:
  br label %bb31
bb31:
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 84
  %t153 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t152
  %t155 = load ptr, ptr %l62, !tbaa !29
  %t156 = getelementptr %"compiler/interp:Exec", ptr %t155, i32 0, i32 10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %t156
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t162 = getelementptr %"compiler/session:Analysis", ptr %t157, i32 0, i32 3
  store ptr %t158, ptr %t162, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l41 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l48 = alloca i64
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i1
  %l74 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t5, ptr %l9
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %s0, ptr %s0, { i64, ptr } %t12)
  store { i64, ptr } %t14, ptr %l11
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  %t16 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr @.d25 }, ptr %l15, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l12, !tbaa !27
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t31, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d26 }, ptr %l18, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l21, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t46, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l22, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t47, ptr %l23, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l24, !tbaa !24
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l25, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l24, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 1
  %t68 = extractvalue { i64, ptr } { i64 1, ptr @.d28 }, 0
  %t69 = add i64 %t66, %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t69)
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = getelementptr i8, ptr %t70, i64 %t66
  call void @olang_textcopy(ptr %t71, ptr %t67, i64 %t68)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t70, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t62, { i64, ptr } %t80)
  store i1 %t83, ptr %l30
  br label %bb8
bb8:
  %t84 = load i1, ptr %l30, !tbaa !21
  br i1 %t84, label %bb9, label %bb10
bb9:
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l33, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l35, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  store i64 %t94, ptr %l36, !tbaa !24
  %t95 = load i64, ptr %l33, !tbaa !24
  %t96 = icmp sge i64 %t95, 0
  br i1 %t96, label %bb11, label %bb12
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = extractvalue { i64, ptr } %t99, 0
  %t103 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 1
  %t104 = extractvalue { i64, ptr } { i64 1, ptr @.d29 }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = getelementptr i8, ptr %t106, i64 %t102
  call void @olang_textcopy(ptr %t107, ptr %t103, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = extractvalue { i64, ptr } %t109, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t98, { i64, ptr } %t116)
  store i1 %t119, ptr %l56
  br label %bb23
bb11:
  %t120 = load i64, ptr %l33, !tbaa !24
  %t121 = load i64, ptr %l35, !tbaa !24
  %t122 = icmp sle i64 %t120, %t121
  br i1 %t122, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb13:
  %t124 = load i64, ptr %l35, !tbaa !24
  %t125 = load i64, ptr %l36, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  br i1 %t126, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb15:
  %t128 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l33, !tbaa !24
  %t131 = load i64, ptr %l35, !tbaa !24
  %t132 = getelementptr i8, ptr %t129, i64 %t130
  %t133 = sub i64 %t131, %t130
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l41, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l43, !tbaa !24
  %t147 = load i64, ptr %l43, !tbaa !24
  %t148 = icmp eq i64 %t143, %t147
  br i1 %t148, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb17:
  %t150 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l43, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  br label %bb19
bb18:
  %t156 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t156, ptr %l4, !tbaa !27
  br label %bb19
bb19:
  store { i64, ptr } { i64 4, ptr @.d30 }, ptr %l45, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t157, ptr %l46, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l48, !tbaa !24
  %t163 = load i64, ptr %l48, !tbaa !24
  %t164 = icmp eq i64 %t159, %t163
  br i1 %t164, label %bb20, label %bb21
bb20:
  %t166 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l48, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  br label %bb22
bb21:
  %t172 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 0
  store i64 %t173, ptr %l50, !tbaa !24
  %t174 = load i64, ptr %l50, !tbaa !24
  %t175 = mul i64 %t174, 1
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l51, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = load i64, ptr %l50, !tbaa !24
  %t184 = mul i64 %t183, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t180, ptr %t182, i64 %t184, i1 false)
  %t185 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t185, ptr %l5, !tbaa !27
  br label %bb22
bb22:
  br label %bb36
bb23:
  %t186 = load i1, ptr %l56, !tbaa !21
  br i1 %t186, label %bb24, label %bb25
bb24:
  %t187 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l59, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l61, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l62, !tbaa !24
  %t197 = load i64, ptr %l59, !tbaa !24
  %t198 = icmp sge i64 %t197, 0
  br i1 %t198, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  %t200 = load i64, ptr %l59, !tbaa !24
  %t201 = load i64, ptr %l61, !tbaa !24
  %t202 = icmp sle i64 %t200, %t201
  br i1 %t202, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb28:
  %t204 = load i64, ptr %l61, !tbaa !24
  %t205 = load i64, ptr %l62, !tbaa !24
  %t206 = icmp sle i64 %t204, %t205
  br i1 %t206, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb30:
  %t208 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = load i64, ptr %l59, !tbaa !24
  %t211 = load i64, ptr %l61, !tbaa !24
  %t212 = getelementptr i8, ptr %t209, i64 %t210
  %t213 = sub i64 %t211, %t210
  %t214 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t212, 1
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = extractvalue { i64, ptr } %t215, 0
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t217, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l67, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  %t224 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l69, !tbaa !24
  %t227 = load i64, ptr %l69, !tbaa !24
  %t228 = icmp eq i64 %t223, %t227
  br i1 %t228, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb32:
  %t230 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = load i64, ptr %l69, !tbaa !24
  %t235 = mul i64 %t234, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t231, ptr %t233, i64 %t235, i1 false)
  br label %bb34
bb33:
  %t236 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t236, ptr %l4, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t237 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr @.d31 })
  store i1 %t239, ptr %l72
  br label %bb37
bb37:
  %t240 = load i1, ptr %l72, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb38, label %bb39
bb38:
  %t243 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = extractvalue { i64, ptr } %t243, 0
  %t249 = extractvalue { i64, ptr } %t244, 1
  %t250 = extractvalue { i64, ptr } %t244, 0
  %t251 = add i64 %t247, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t246, i64 %t247)
  %t253 = getelementptr i8, ptr %t252, i64 %t247
  call void @olang_textcopy(ptr %t253, ptr %t249, i64 %t250)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  store { i64, ptr } %t255, ptr %l74, !tbaa !27
  br label %bb41
bb39:
  %t257 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t259 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, { i64, ptr } %t257)
  store { i64, ptr } %t259, ptr %l79
  br label %bb40
bb40:
  %t260 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t262)
  call void @olang_textcopy(ptr %t263, ptr %t261, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l74, !tbaa !27
  br label %bb41
bb41:
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t267, ptr %lp6
  %t268 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t269 = load ptr, ptr %lp6
  store { i64, ptr } %t268, ptr %t269, !tbaa !27
  %t270 = load ptr, ptr %lp6
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t273 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t271, { i64, ptr } { i64 6, ptr @.d32 })
  store i1 %t273, ptr %l82
  br label %bb42
bb42:
  %t274 = load i1, ptr %l82, !tbaa !21
  br i1 %t274, label %bb43, label %bb44
bb43:
  %t275 = load ptr, ptr %lp6
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t280 = sub i64 %t278, 6
  store i64 %t280, ptr %l86, !tbaa !24
  %t281 = load ptr, ptr %lp6
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  store i64 %t283, ptr %l87, !tbaa !24
  %t284 = icmp sge i64 0, 0
  br i1 %t284, label %bb45, label %bb46
bb44:
  %t286 = load ptr, ptr %lp6
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  store { i64, ptr } %t287, ptr %l83, !tbaa !27
  br label %bb51
bb45:
  %t289 = load i64, ptr %l86, !tbaa !24
  %t290 = icmp sle i64 0, %t289
  br i1 %t290, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb47:
  %t292 = load i64, ptr %l86, !tbaa !24
  %t293 = load i64, ptr %l87, !tbaa !24
  %t294 = icmp sle i64 %t292, %t293
  br i1 %t294, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb49:
  %t296 = load ptr, ptr %lp6
  %t297 = getelementptr { i64, ptr }, ptr %t296, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = load i64, ptr %l86, !tbaa !24
  %t300 = getelementptr i8, ptr %t298, i64 0
  %t301 = sub i64 %t299, 0
  %t302 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t300, 1
  %t305 = extractvalue { i64, ptr } %t303, 1
  %t306 = extractvalue { i64, ptr } %t303, 0
  %t307 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t305, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l83, !tbaa !27
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t311 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t311, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fsession_2eIgnoreBrokenPipes() #0 {
entry:
  %l0 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @signal(i32 13, i64 1)
  store i64 %t1, ptr %l0
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eInChild(ptr %v0, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca i32
  %l2 = alloca [1 x i32]
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @fork()
  store i32 %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load i32, ptr %l3, !tbaa !23
  store i32 %t2, ptr %l1, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  %t5 = icmp slt i32 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { ptr, ptr }, ptr %l0
  %t9 = extractvalue { ptr, ptr } %t7, 0
  %t10 = extractvalue { ptr, ptr } %t7, 1
  %t11 = call i32 %t9(ptr %t10)
  store i32 %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = icmp eq i32 %t13, 0
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t17 = load { ptr, ptr }, ptr %l0
  %t19 = extractvalue { ptr, ptr } %t17, 0
  %t20 = extractvalue { ptr, ptr } %t17, 1
  %t21 = call i32 %t19(ptr %t20)
  store i32 %t21, ptr %l11
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t22 = load i32, ptr %l11, !tbaa !23
  call void @_exit(i32 %t22)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ff40fb5988b00df4_fbbcb1c788c8bd28)
  unreachable
bb10:
  %t23 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t23, ptr %l2
  %t25 = load i32, ptr %l1, !tbaa !23
  %t27 = insertvalue { i64, ptr } undef, i64 1, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %l2, 1
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = extractvalue { i64, ptr } %t28, 0
  %t34 = call i32 @waitpid(i32 %t25, ptr %t32, i32 0)
  store i32 %t34, ptr %l17
  br label %bb11
bb11:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = icmp slt i32 %t35, 0
  br i1 %t36, label %bb12, label %bb13
bb12:
  store i32 1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t39 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t40 = load i32, ptr %t39, !tbaa !33
  %t42 = call i32 @compiler_2fsession_2eExitStatus(i32 %t40)
  store i32 %t42, ptr %l21
  br label %bb15
bb15:
  %t43 = load i32, ptr %l21, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l14 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t1, i8 34)
  br label %bb1
bb1:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 34
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr @.d33 })
  br label %bb8
bb7:
  %t31 = load i8, ptr %l5, !tbaa !22
  %t33 = icmp eq i8 %t31, 92
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t35, { i64, ptr } { i64 2, ptr @.d34 })
  br label %bb11
bb10:
  %t37 = load i8, ptr %l5, !tbaa !22
  %t39 = icmp eq i8 %t37, 10
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t41, { i64, ptr } { i64 2, ptr @.d35 })
  br label %bb14
bb13:
  %t43 = load i8, ptr %l5, !tbaa !22
  %t45 = icmp eq i8 %t43, 13
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t47, { i64, ptr } { i64 2, ptr @.d36 })
  br label %bb17
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 9
  br i1 %t51, label %bb18, label %bb19
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb29
bb18:
  store %olang.scope zeroinitializer, ptr %s11
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t53, { i64, ptr } { i64 2, ptr @.d37 })
  br label %bb20
bb19:
  %t55 = load i8, ptr %l5, !tbaa !22
  %t58 = icmp ult i8 %t55, 32
  br i1 %t58, label %bb21, label %bb22
bb20:
  call void @__olang_scope_close(ptr %s11)
  br label %bb28
bb21:
  store %olang.scope zeroinitializer, ptr %s13
  %t60 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t60, { i64, ptr } { i64 4, ptr @.d38 })
  br label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t62, i8 %t63)
  br label %bb26
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } { i64 16, ptr @.d39 }, ptr %l37, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t67, ptr %l38, !tbaa !27
  %t68 = load i8, ptr %l5, !tbaa !22
  %t71 = lshr i8 %t68, 4
  %t73 = zext i8 %t71 to i64
  %t75 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t66, i8 %t78)
  br label %bb24
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } { i64 16, ptr @.d40 }, ptr %l45, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t82, ptr %l46, !tbaa !27
  %t83 = load i8, ptr %l5, !tbaa !22
  %t86 = and i8 %t83, 15
  %t88 = zext i8 %t86 to i64
  %t90 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t81, i8 %t93)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s13)
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l3, !tbaa !24
  br label %bb2
bb34:
  %t100 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t100, i8 34)
  br label %bb35
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKeywords_2einit() #0 {
entry:
  %l0 = alloca [41 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr @.d41 }, ptr %t1
  %t2 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 4, ptr @.d42 }, ptr %t2
  %t3 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 6, ptr @.d43 }, ptr %t3
  %t4 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 4, ptr @.d44 }, ptr %t4
  %t5 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 5, ptr @.d45 }, ptr %t5
  %t6 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 7, ptr @.d46 }, ptr %t6
  %t7 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 6, ptr @.d47 }, ptr %t7
  %t8 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr @.d48 }, ptr %t8
  %t9 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 6, ptr @.d49 }, ptr %t9
  %t10 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 2, ptr @.d50 }, ptr %t10
  %t11 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 4, ptr @.d51 }, ptr %t11
  %t12 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 3, ptr @.d52 }, ptr %t12
  %t13 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 12
  store { i64, ptr } { i64 2, ptr @.d53 }, ptr %t13
  %t14 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 13
  store { i64, ptr } { i64 5, ptr @.d54 }, ptr %t14
  %t15 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 14
  store { i64, ptr } { i64 5, ptr @.d55 }, ptr %t15
  %t16 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 15
  store { i64, ptr } { i64 4, ptr @.d56 }, ptr %t16
  %t17 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 16
  store { i64, ptr } { i64 7, ptr @.d57 }, ptr %t17
  %t18 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 17
  store { i64, ptr } { i64 6, ptr @.d58 }, ptr %t18
  %t19 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 18
  store { i64, ptr } { i64 5, ptr @.d59 }, ptr %t19
  %t20 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 19
  store { i64, ptr } { i64 8, ptr @.d60 }, ptr %t20
  %t21 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 20
  store { i64, ptr } { i64 5, ptr @.d61 }, ptr %t21
  %t22 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 21
  store { i64, ptr } { i64 3, ptr @.d62 }, ptr %t22
  %t23 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 22
  store { i64, ptr } { i64 5, ptr @.d63 }, ptr %t23
  %t24 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 23
  store { i64, ptr } { i64 7, ptr @.d64 }, ptr %t24
  %t25 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 24
  store { i64, ptr } { i64 4, ptr @.d65 }, ptr %t25
  %t26 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 25
  store { i64, ptr } { i64 5, ptr @.d66 }, ptr %t26
  %t27 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 26
  store { i64, ptr } { i64 5, ptr @.d67 }, ptr %t27
  %t28 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 27
  store { i64, ptr } { i64 6, ptr @.d68 }, ptr %t28
  %t29 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 28
  store { i64, ptr } { i64 11, ptr @.d69 }, ptr %t29
  %t30 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 29
  store { i64, ptr } { i64 8, ptr @.d70 }, ptr %t30
  %t31 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 30
  store { i64, ptr } { i64 3, ptr @.d71 }, ptr %t31
  %t32 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 31
  store { i64, ptr } { i64 3, ptr @.d72 }, ptr %t32
  %t33 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 32
  store { i64, ptr } { i64 2, ptr @.d73 }, ptr %t33
  %t34 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 33
  store { i64, ptr } { i64 3, ptr @.d74 }, ptr %t34
  %t35 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 34
  store { i64, ptr } { i64 3, ptr @.d75 }, ptr %t35
  %t36 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 35
  store { i64, ptr } { i64 2, ptr @.d76 }, ptr %t36
  %t37 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 36
  store { i64, ptr } { i64 2, ptr @.d77 }, ptr %t37
  %t38 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 37
  store { i64, ptr } { i64 4, ptr @.d78 }, ptr %t38
  %t39 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 38
  store { i64, ptr } { i64 4, ptr @.d79 }, ptr %t39
  %t40 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 39
  store { i64, ptr } { i64 5, ptr @.d80 }, ptr %t40
  %t41 = getelementptr [41 x { i64, ptr }], ptr %l0, i64 0, i64 40
  store { i64, ptr } { i64 8, ptr @.d81 }, ptr %t41
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fsession_2eKeywords, ptr %l0, i64 656, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKillAndReap(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp sle i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i32, ptr %l0, !tbaa !23
  %t7 = call i32 @kill(i32 %t5, i32 9)
  store i32 %t7, ptr %l4
  br label %bb4
bb4:
  %t8 = load i32, ptr %l0, !tbaa !23
  %t10 = call i32 @compiler_2fsession_2eReap(i32 %t8)
  store i32 %t10, ptr %l6
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindClass_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindEnumMember_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 22, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindEnum_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 10, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindField_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8, ptr @G_2ecompiler_2fsession_2eKindField, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindFunction_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 12, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindInterface_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 11, ptr @G_2ecompiler_2fsession_2eKindInterface, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindMethod_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindStruct_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 23, ptr @G_2ecompiler_2fsession_2eKindStruct, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKindVariable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 13, ptr @G_2ecompiler_2fsession_2eKindVariable, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eLog(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d82 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d83 }, ptr %l4, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t16, { i64, ptr } { i64 0, ptr @.d84 })
  store i1 %t17, ptr %l7
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 1
  %t21 = extractvalue { i64, ptr } { i64 7, ptr @.d85 }, 0
  %t23 = extractvalue { i64, ptr } %a0, 1
  %t24 = extractvalue { i64, ptr } %a0, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d86 }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t40)
  store i32 %t42, ptr %l11
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb10, label %ok.44
ok.44:
  br label %bb9
bb9:
  br label %bb14
bb10:
  %t45 = load i32, ptr %l11, !tbaa !23
  %t46 = ashr i32 %t45, 16
  %t48 = icmp eq i32 %t46, 1
  br i1 %t48, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1cc1f1f203352feb_9705d5bb59619eef)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @compiler_2fsession_2ePipe() #0 {
entry:
  %l0 = alloca [2 x i32]
  %l5 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i32] undef, i32 0, 0
  %t2 = insertvalue [2 x i32] %t1, i32 0, 1
  store [2 x i32] %t2, ptr %l0
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l0, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pipe(ptr %t9)
  store i32 %t11, ptr %l5
  br label %bb1
bb1:
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = insertvalue { i32, i32 } undef, i32 -1, 0
  %t16 = insertvalue { i32, i32 } %t15, i32 -1, 1
  store { i32, i32 } %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = getelementptr [2 x i32], ptr %l0, i64 0, i64 0
  %t19 = load i32, ptr %t18, !tbaa !33
  %t20 = getelementptr [2 x i32], ptr %l0, i64 0, i64 1
  %t21 = load i32, ptr %t20, !tbaa !33
  %t23 = insertvalue { i32, i32 } undef, i32 %t19, 0
  %t25 = insertvalue { i32, i32 } %t23, i32 %t21, 1
  store { i32, i32 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca { i64, ptr }
  %l59 = alloca i64
  %l66 = alloca i32
  %l73 = alloca i64
  %l76 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = mul i64 2, %t5
  store i64 %t7, ptr %l20, !tbaa !24
  %t8 = load i64, ptr %l20, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l20, !tbaa !24
  %t12 = icmp sle i64 %t11, 2305843009213693951
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb3:
  %t14 = load i64, ptr %l20, !tbaa !24
  %t15 = mul i64 %t14, 4
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb5:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l31, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l28, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = mul i64 2, %t68
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t71, ptr %l51, !tbaa !27
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i32, ptr %t75, i64 %t72
  %t77 = load i32, ptr %t76, !tbaa !33
  %t80 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i32, ptr %t81, i64 %t70
  store i32 %t77, ptr %t82, !tbaa !33
  %t83 = load i64, ptr %l9, !tbaa !24
  %t85 = mul i64 2, %t83
  %t87 = add i64 %t85, 1
  %t89 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t87
  store i32 1, ptr %t91, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = add i64 %t92, 1
  store i64 %t94, ptr %l8, !tbaa !24
  br label %bb11
bb16:
  %t96 = load i64, ptr %l2, !tbaa !24
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load i64, ptr %l59, !tbaa !24
  %t98 = icmp sge i64 %t97, 0
  br i1 %t98, label %bb17, label %bb18
bb17:
  %t100 = load i64, ptr %l59, !tbaa !24
  %t101 = mul i64 %t100, 1
  %t102 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t105, ptr %lp10
  %t107 = load ptr, ptr %lp10
  store { i64, ptr } %t104, ptr %t107, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t109 = load i64, ptr %l2, !tbaa !24
  %t113 = extractvalue { i64, ptr } %t108, 1
  %t114 = extractvalue { i64, ptr } %t108, 0
  %t117 = call i32 @poll(ptr %t113, i64 %t109, i32 %a1)
  store i32 %t117, ptr %l66
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01)
  unreachable
bb19:
  %t118 = load i32, ptr %l66, !tbaa !23
  %t119 = icmp sle i32 %t118, 0
  br i1 %t119, label %bb20, label %bb21
bb20:
  %t121 = load ptr, ptr %lp10
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t122, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l11, !tbaa !24
  %t124 = load i64, ptr %l2, !tbaa !24
  store i64 %t124, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb23, label %bb24
bb23:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb28
bb25:
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l13, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l76, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb27
bb27:
  %t152 = load i64, ptr %l76, !tbaa !24
  store i64 %t152, ptr %l73, !tbaa !24
  br label %bb28
bb28:
  %t153 = load i64, ptr %l73, !tbaa !24
  store i64 %t153, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t154 = load i64, ptr %l15, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t162 = load i64, ptr %l11, !tbaa !24
  %t163 = load i64, ptr %l15, !tbaa !24
  %t164 = load i64, ptr %l13, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l16, !tbaa !24
  %t172 = load i64, ptr %l16, !tbaa !24
  %t173 = load i64, ptr %l16, !tbaa !24
  %t175 = mul i64 2, %t173
  %t177 = add i64 %t175, 1
  %t179 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i32, ptr %t180, i64 %t177
  %t182 = load i32, ptr %t181, !tbaa !33
  %t184 = ashr i32 %t182, 16
  %t186 = and i32 %t184, 25
  %t188 = icmp ne i32 %t186, 0
  %t190 = load ptr, ptr %lp10
  %t192 = getelementptr { i64, ptr }, ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i1, ptr %t193, i64 %t172
  store i1 %t188, ptr %t194, !tbaa !31
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  %t195 = load i64, ptr %l15, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l15, !tbaa !24
  br label %bb29
bb34:
  %t199 = load ptr, ptr %lp10
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t200, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr @.d87 }, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t12 = extractvalue { i64, ptr } %t9, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr @.d88 })
  store i1 %t21, ptr %l10
  br label %bb5
bb5:
  %t22 = load i1, ptr %l10, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = extractvalue { i64, ptr } %t25, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l12, !tbaa !27
  br label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fsession_2eReap(i32 %a0) #0 {
entry:
  %l1 = alloca [1 x i32]
  %l7 = alloca i32
  %l11 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t1, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 1, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t10 = extractvalue { i64, ptr } %t6, 1
  %t11 = extractvalue { i64, ptr } %t6, 0
  %t12 = call i32 @waitpid(i32 %a0, ptr %t10, i32 0)
  store i32 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = icmp slt i32 %t13, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  store i32 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = getelementptr [1 x i32], ptr %l1, i64 0, i64 0
  %t18 = load i32, ptr %t17, !tbaa !33
  %t20 = call i32 @compiler_2fsession_2eExitStatus(i32 %t18)
  store i32 %t20, ptr %l11
  br label %bb5
bb5:
  %t21 = load i32, ptr %l11, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr @.d89 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s1)
  store { i64, ptr } %t5, ptr %l3
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l4, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t14, 0
  store i64 %t17, ptr %l8, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l9, !tbaa !24
  %t20 = icmp sge i64 4, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sle i64 4, %t22
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb7:
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb9:
  %t29 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l8, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 4
  %t33 = sub i64 %t31, 4
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t36, { i64, ptr } %t35, { i64, ptr } { i64 0, ptr @.d90 }, { i64, ptr } { i64 0, ptr @.d91 }, { i64, ptr } { i64 0, ptr @.d92 }, { i64, ptr } { i64 0, ptr @.d93 })
  store { i64, ptr } %t38, ptr %l14
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb11:
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } { i64 6, ptr @.d94 }, 1
  %t43 = extractvalue { i64, ptr } { i64 6, ptr @.d94 }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t40, i64 %t41)
  %t46 = getelementptr i8, ptr %t45, i64 %t41
  call void @olang_textcopy(ptr %t46, ptr %t42, i64 %t43)
  %t47 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb12:
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = extractvalue { i64, ptr } %t50, 0
  %t54 = extractvalue { i64, ptr } { i64 6, ptr @.d95 }, 1
  %t55 = extractvalue { i64, ptr } { i64 6, ptr @.d95 }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t52, i64 %t53)
  %t58 = getelementptr i8, ptr %t57, i64 %t53
  call void @olang_textcopy(ptr %t58, ptr %t54, i64 %t55)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fsession_2eSymbols(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"compiler/session:symWriter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/session:symWriter"
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t1, i8 91)
  br label %bb1
bb1:
  %t5 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v1, ptr %s0, ptr %a1)
  store %"compiler/session:symWriter" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"compiler/session:symWriter", ptr %l11
  store %"compiler/session:symWriter" %t6, ptr %l4
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb5
bb4:
  br label %bb12
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %s0, ptr %v0, ptr %v2, ptr %v3, ptr %l4, ptr %t35, ptr %t33, ptr %a3)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t46, i8 93)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l51 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp sgt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t20, 1
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = call i1 @compiler_2fsession_2eWordChar(i8 %t27)
  store i1 %t29, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %bb4
bb13:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load i64, ptr %l2, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l32, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = call i1 @compiler_2fsession_2eWordChar(i8 %t62)
  store i1 %t64, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb25:
  br label %bb17
bb26:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  br i1 %t77, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb30
bb28:
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l46
  br label %bb29
bb29:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %l42, !tbaa !21
  br label %bb30
bb30:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = trunc i64 %t90 to i32
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t92, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l51
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t99, ptr %rv
  br label %ret
bb34:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = trunc i64 %t103 to i32
  %t108 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t102, i32 %t105)
  store %"compiler/source:Span" %t108, ptr %l56
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load %"compiler/source:Span", ptr %l56
  store %"compiler/source:Span" %t109, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fsession_2eWordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t18 = icmp uge i8 %t15, -128
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t20 = load i1, ptr %l9, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fsession_2eWriteFramed(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 16, ptr @.d96 }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr @.d96 }, 0
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 4, ptr @.d97 }, 1
  %t12 = extractvalue { i64, ptr } { i64 4, ptr @.d97 }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %t5, 1
  %t16 = extractvalue { i64, ptr } %t5, 0
  %t17 = add i64 %t13, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t6, i64 %t7)
  %t19 = getelementptr i8, ptr %t18, i64 %t7
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t4)
  %t21 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t21, ptr %t11, i64 %t12)
  %t22 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t22, ptr %t15, i64 %t16)
  %t23 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t18, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } %t24, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %a0, { i64, ptr } %t32)
  store i32 %t35, ptr %l9
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb2, label %ok.37
ok.37:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t38 = load i32, ptr %l9, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3e799710a156d065_c0388e63a7e7a1d9)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l12 = alloca i1
  %l19 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [6 x i64] }
  %l31 = alloca %"compiler/session:Found"
  %l34 = alloca %"compiler/session:Found"
  %l35 = alloca i32
  %rv = alloca { i32, %"compiler/session:Found" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t21, i64 %t22)
  store { i64, ptr } %t25, ptr %l19
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t26, i64 %a2)
  store %"compiler/source:Span" %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t32, ptr %l5
  %t33 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t35 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = icmp eq i32 %t34, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t42 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load %"compiler/source:Span", ptr %l5
  %t49 = call { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %v0, ptr %t43, i64 %t44, %"compiler/source:Span" %t45)
  store { i64, [6 x i64] } %t49, ptr %l30
  br label %bb13
bb13:
  %t50 = load { i64, [6 x i64] }, ptr %l30
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edescribe(ptr %v0, ptr %v0, ptr %v2, ptr %t51, { i64, [6 x i64] } %t50)
  %t56 = extractvalue { i32, %"compiler/session:Found" } %t55, 1
  %t57 = extractvalue { i32, %"compiler/session:Found" } %t55, 0
  store i32 %t57, ptr %l35
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb15, label %ok.59
ok.59:
  store %"compiler/session:Found" %t56, ptr %l34
  br label %bb14
bb14:
  %t60 = load %"compiler/session:Found", ptr %l34
  store %"compiler/session:Found" %t60, ptr %l31
  br label %bb16
bb15:
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  %t71 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t69, 0
  store { i32, %"compiler/session:Found" } %t71, ptr %rv
  br label %ret
bb16:
  %t72 = load %"compiler/session:Found", ptr %l31
  %t73 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t72, 1
  store { i32, %"compiler/session:Found" } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/session:Found" }, ptr %rv
  ret { i32, %"compiler/session:Found" } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l38 = alloca i1
  %l51 = alloca %"compiler/names:Ref"
  %l62 = alloca %"compiler/names:Ref"
  %l71 = alloca i32
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l24
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/session:Analysis", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 5
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l29
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t42 = getelementptr %"compiler/load:Module", ptr %t40, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t45, i64 %t46)
  store %"compiler/source:Span" %t49, ptr %l34
  br label %bb10
bb10:
  %t50 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t50, ptr %l8
  %t51 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t57 = icmp slt i32 %t52, %t54
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  store i1 %t66, ptr %l38, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l38, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb16, label %bb17
bb15:
  br label %bb31
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3178b68d0296f164_92041ef9c14564d0)
  unreachable
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t80, i64 %t81, i32 %t83)
  store %"compiler/names:Ref" %t87, ptr %l51
  br label %bb19
bb19:
  %t88 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t88, ptr %l9
  %t89 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t90 = load i32, ptr %t89
  %t92 = trunc i64 0 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  br i1 %t97, label %bb22, label %bb23
bb21:
  br label %bb26
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d917d39333aa2133_631bc7dad212aa2f)
  unreachable
bb23:
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load i64, ptr %l7, !tbaa !24
  %t108 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t113 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t106, i64 %t107, i32 %t109)
  store %"compiler/names:Ref" %t113, ptr %l62
  br label %bb25
bb25:
  %t114 = load %"compiler/names:Ref", ptr %l62
  store %"compiler/names:Ref" %t114, ptr %l9
  br label %bb26
bb26:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t116 = load i32, ptr %t115
  %t118 = trunc i64 5 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t121, ptr %t122, i64 %t124, i1 false)
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t134 = call i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %t128, i64 %t129, i64 %t130)
  store i32 %t134, ptr %l71
  br label %bb32
bb32:
  %t135 = load i32, ptr %l71, !tbaa !23
  store i32 %t135, ptr %l10, !tbaa !23
  %t136 = load i64, ptr %l3, !tbaa !24
  store i64 %t136, ptr %l72, !tbaa !24
  %t137 = load i32, ptr %l10, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t141 = icmp ne i32 %t137, %t138
  br i1 %t141, label %bb33, label %bb34
bb33:
  %t143 = load ptr, ptr %l5, !tbaa !29
  %t145 = icmp eq ptr %t143, null
  br i1 %t145, label %bb35, label %bb36
bb34:
  store { i64, ptr } { i64 7, ptr @.d98 }, ptr %l76, !tbaa !27
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8be86b180d8510f2_8625cf113e27a67e)
  unreachable
bb36:
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l5, !tbaa !29
  %t148 = load i32, ptr %l10, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t147, i32 %t148)
  store { i64, ptr } %t151, ptr %l81
  br label %bb38
bb38:
  %t152 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l76, !tbaa !27
  br label %bb39
bb39:
  %t160 = extractvalue { i64, ptr } { i64 26, ptr @.d99 }, 1
  %t161 = extractvalue { i64, ptr } { i64 26, ptr @.d99 }, 0
  %t162 = load i64, ptr %l72, !tbaa !24
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t162)
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 2, ptr @.d100 }, 1
  %t166 = extractvalue { i64, ptr } { i64 2, ptr @.d100 }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t160, i64 %t161)
  %t173 = getelementptr i8, ptr %t172, i64 %t161
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t162)
  %t175 = getelementptr i8, ptr %t173, i64 %t163
  call void @olang_textcopy(ptr %t175, ptr %t165, i64 %t166)
  %t176 = getelementptr i8, ptr %t175, i64 %t166
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t172, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t185)
  br label %bb40
bb40:
  %t187 = load i32, ptr %l10, !tbaa !23
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t191 = icmp eq i32 %t187, %t188
  br i1 %t191, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  br label %bb43
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t195 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %t193, ptr %t194, i32 %t195)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/session:Analysis", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l40
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t69, { i64, ptr } %a1)
  store i1 %t73, ptr %l44
  br label %bb13
bb13:
  %t74 = load i1, ptr %l44, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t75, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/typed:Local"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/load:Import"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i1
  %l47 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l70 = alloca { i64, ptr }
  %l77 = alloca i1
  %l83 = alloca i1
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l104 = alloca { i64, ptr }
  %l109 = alloca i1
  %l116 = alloca i1
  %l119 = alloca i1
  %l122 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l141 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i32
  %l176 = alloca { i64, ptr }
  %l191 = alloca i64
  %l195 = alloca i64
  %l198 = alloca i64
  %l220 = alloca ptr
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l36
  br label %bb1
bb1:
  %t6 = load i64, ptr %l36, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l39, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l39, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 5
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l47
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l47, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/session:Analysis", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_804f8b0fb45e435f_c5484f8454187243)
  unreachable
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/session:Analysis", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 11
  store ptr %t47, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t49, i64 %t50)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l61
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb14, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l60
  br label %bb13
bb13:
  %t58 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t58, ptr %l57, !tbaa !27
  br label %bb18
bb14:
  %t59 = load i32, ptr %l61, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_ca0f10400b3a3f07_954154708ee424db)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb74
bb18:
  %t64 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb72
bb21:
  br label %bb22
bb22:
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %l70, !tbaa !27
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  store ptr %t83, ptr %l11, !tbaa !29
  %t85 = load ptr, ptr %l11, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 3
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l5, !tbaa !24
  %t92 = icmp ne i64 %t88, %t89
  br i1 %t92, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb25
bb24:
  %t94 = load ptr, ptr %l11, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 4
  %t97 = getelementptr %"compiler/source:Span", ptr %t96, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  store i1 %t104, ptr %l77, !tbaa !21
  br label %bb25
bb25:
  %t106 = load i1, ptr %l77, !tbaa !21
  br i1 %t106, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb28
bb27:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 4
  %t111 = getelementptr %"compiler/source:Span", ptr %t110, i32 0, i32 1
  %t112 = load i32, ptr %t111, !tbaa !23
  %t114 = sext i32 %t112 to i64
  %t117 = icmp sgt i64 %t107, %t114
  store i1 %t117, ptr %l83, !tbaa !21
  br label %bb28
bb28:
  %t119 = load i1, ptr %l83, !tbaa !21
  br i1 %t119, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb30:
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l11, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Body", ptr %t120, i32 0, i32 7
  store ptr %t122, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t124 = load ptr, ptr %l12, !tbaa !29
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t124, i64 %t125)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l95
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb34, label %ok.132
ok.132:
  store { i64, ptr } %t129, ptr %l94
  br label %bb33
bb33:
  %t133 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t133, ptr %l91, !tbaa !27
  br label %bb38
bb34:
  %t134 = load i32, ptr %l95, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  br i1 %t137, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_9b218acf13b4620c_e8906e55efde0fe0)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb38:
  %t139 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t139, ptr %l14, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l15, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t152 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t152, ptr %l104, !tbaa !27
  %t153 = load i64, ptr %l16, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr %"compiler/typed:Local", ptr %t156, i64 %t153
  %t158 = load %"compiler/typed:Local", ptr %t157
  store %"compiler/typed:Local" %t158, ptr %l17
  %t160 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 0
  %t161 = load i32, ptr %t160, !tbaa !23
  %t163 = icmp eq i32 %t161, 0
  br i1 %t163, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb45
bb44:
  %t165 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 1
  %t166 = getelementptr %"compiler/source:Span", ptr %t165, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t170 = load i64, ptr %l3, !tbaa !24
  %t173 = icmp sge i64 %t169, %t170
  store i1 %t173, ptr %l109, !tbaa !21
  br label %bb45
bb45:
  %t175 = load i1, ptr %l109, !tbaa !21
  br i1 %t175, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb47:
  br label %bb48
bb48:
  %t176 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 4
  %t177 = load i32, ptr %t176
  %t179 = trunc i64 0 to i32
  %t180 = icmp eq i32 %t177, %t179
  br i1 %t180, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb51
bb50:
  %t182 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 4
  %t183 = load i32, ptr %t182
  %t185 = trunc i64 1 to i32
  %t186 = icmp eq i32 %t183, %t185
  store i1 %t186, ptr %l116, !tbaa !21
  br label %bb51
bb51:
  %t188 = load i1, ptr %l116, !tbaa !21
  br i1 %t188, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb54
bb53:
  %t189 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 4
  %t190 = load i32, ptr %t189
  %t192 = trunc i64 4 to i32
  %t193 = icmp eq i32 %t190, %t192
  store i1 %t193, ptr %l119, !tbaa !21
  br label %bb54
bb54:
  %t195 = load i1, ptr %l119, !tbaa !21
  br i1 %t195, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l122, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/session:Analysis", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  br i1 %t202, label %bb57, label %bb58
bb56:
  br label %bb66
bb57:
  call void @__olang_check_failed(ptr @olang_loc_572cffa5a574e22e_260a164ad5cf82c2)
  unreachable
bb58:
  br label %bb59
bb59:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/session:Analysis", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 3
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  %t222 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t217, i32 %t219)
  store { i64, ptr } %t222, ptr %l133
  br label %bb60
bb60:
  %t223 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t223, ptr %l134, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/session:Analysis", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb61, label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_572cffa5a574e22e_260a164ad5cf82c2)
  unreachable
bb62:
  br label %bb63
bb63:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/session:Analysis", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Local", ptr %l17, i32 0, i32 2
  %t236 = load i32, ptr %t235, !tbaa !23
  %t239 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s10, ptr %t234, i32 %t236)
  store { i64, ptr } %t239, ptr %l141
  br label %bb64
bb64:
  %t240 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  %t242 = extractvalue { i64, ptr } %t240, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load ptr, ptr %l122, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t249 = load i64, ptr %l134, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s10, ptr %t247, { i64, ptr } %t248, i64 %t249, { i64, ptr } %t246)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb67:
  %t251 = load i64, ptr %l16, !tbaa !24
  %t253 = add i64 %t251, 1
  store i64 %t253, ptr %l16, !tbaa !24
  br label %bb39
bb68:
  %t255 = load i64, ptr %l13, !tbaa !24
  %t256 = load i64, ptr %l15, !tbaa !24
  %t259 = add i64 %t255, %t256
  store i64 %t259, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb69:
  br label %bb32
bb70:
  call void @__olang_scope_close(ptr %s4)
  br label %bb71
bb71:
  %t261 = load i64, ptr %l10, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l10, !tbaa !24
  br label %bb19
bb72:
  %t265 = load i64, ptr %l7, !tbaa !24
  %t266 = load i64, ptr %l9, !tbaa !24
  %t269 = add i64 %t265, %t266
  store i64 %t269, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb73
bb73:
  br label %bb12
bb74:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t273 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t271, ptr %t272, i64 %t273, i1 true)
  br label %bb75
bb75:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/session:Analysis", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 5
  %t283 = load i64, ptr %l4, !tbaa !24
  %t286 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t282, i64 %t283)
  store ptr %t286, ptr %l160
  br label %bb76
bb76:
  %t287 = load ptr, ptr %l160, !tbaa !29
  %t289 = getelementptr %"compiler/load:Module", ptr %t287, i32 0, i32 11
  store ptr %t289, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t291 = load ptr, ptr %l18, !tbaa !29
  %t292 = load i64, ptr %l19, !tbaa !24
  %t295 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t291, i64 %t292)
  %t296 = extractvalue { i32, { i64, ptr } } %t295, 1
  %t297 = extractvalue { i32, { i64, ptr } } %t295, 0
  store i32 %t297, ptr %l167
  %t298 = icmp ne i32 %t297, 0
  br i1 %t298, label %bb79, label %ok.299
ok.299:
  store { i64, ptr } %t296, ptr %l166
  br label %bb78
bb78:
  %t300 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t300, ptr %l163, !tbaa !27
  br label %bb83
bb79:
  %t301 = load i32, ptr %l167, !tbaa !23
  %t302 = ashr i32 %t301, 16
  %t304 = icmp eq i32 %t302, 1
  br i1 %t304, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_854b1337ed7621ea_eafb751d49f74e56)
  unreachable
bb82:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb92
bb83:
  %t306 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t306, ptr %l20, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t307, 0
  store i64 %t309, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s15
  %t311 = load i64, ptr %l22, !tbaa !24
  %t312 = load i64, ptr %l21, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s15)
  br label %bb90
bb86:
  br label %bb87
bb87:
  %t319 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t319, ptr %l176, !tbaa !27
  %t320 = load i64, ptr %l22, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr %"compiler/load:Import", ptr %t323, i64 %t320
  %t325 = load %"compiler/load:Import", ptr %t324
  store %"compiler/load:Import" %t325, ptr %l23
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t328 = getelementptr %"compiler/load:Import", ptr %l23, i32 0, i32 2
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  %t330 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  %t331 = getelementptr %"compiler/load:Import", ptr %l23, i32 0, i32 3
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %v0, ptr %t327, { i64, ptr } %t329, i64 %t330, { i64, ptr } %t332)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb89:
  %t337 = load i64, ptr %l22, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l22, !tbaa !24
  br label %bb84
bb90:
  %t341 = load i64, ptr %l19, !tbaa !24
  %t342 = load i64, ptr %l21, !tbaa !24
  %t345 = add i64 %t341, %t342
  store i64 %t345, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb91:
  br label %bb77
bb92:
  store i64 0, ptr %l24, !tbaa !24
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/session:Analysis", ptr %t347, i32 0, i32 0
  %t350 = load ptr, ptr %t349, !tbaa !29
  %t352 = getelementptr %"compiler/load:Loader", ptr %t350, i32 0, i32 5
  %t354 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t352)
  store i64 %t354, ptr %l191
  br label %bb93
bb93:
  %t355 = load i64, ptr %l191, !tbaa !24
  store i64 %t355, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t356 = load i64, ptr %l25, !tbaa !24
  %t357 = load i64, ptr %l24, !tbaa !24
  %t360 = icmp sgt i64 %t356, %t357
  br i1 %t360, label %bb94, label %bb95
bb94:
  %t362 = load i64, ptr %l26, !tbaa !24
  %t364 = icmp sgt i64 %t362, 0
  br i1 %t364, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l195, !tbaa !24
  br label %bb99
bb96:
  %t366 = load i64, ptr %l25, !tbaa !24
  %t367 = load i64, ptr %l24, !tbaa !24
  %t370 = sub i64 %t366, %t367
  %t371 = load i64, ptr %l26, !tbaa !24
  %t374 = add i64 %t370, %t371
  %t376 = sub i64 %t374, 1
  %t377 = load i64, ptr %l26, !tbaa !24
  %t380 = sdiv i64 %t376, %t377
  store i64 %t380, ptr %l198, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb98
bb98:
  %t382 = load i64, ptr %l198, !tbaa !24
  store i64 %t382, ptr %l195, !tbaa !24
  br label %bb99
bb99:
  %t383 = load i64, ptr %l195, !tbaa !24
  store i64 %t383, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s18
  %t384 = load i64, ptr %l28, !tbaa !24
  %t385 = load i64, ptr %l27, !tbaa !24
  %t388 = icmp slt i64 %t384, %t385
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s18)
  br label %bb110
bb102:
  br label %bb103
bb103:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l28, !tbaa !24
  %t394 = load i64, ptr %l26, !tbaa !24
  %t397 = mul i64 %t393, %t394
  %t400 = add i64 %t392, %t397
  store i64 %t400, ptr %l29, !tbaa !24
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr %"compiler/session:Analysis", ptr %t402, i32 0, i32 0
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t407 = getelementptr %"compiler/load:Loader", ptr %t405, i32 0, i32 5
  %t408 = load i64, ptr %l29, !tbaa !24
  %t411 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t407, i64 %t408)
  store ptr %t411, ptr %l220
  br label %bb104
bb104:
  %t412 = load ptr, ptr %l220, !tbaa !29
  %t414 = getelementptr %"compiler/load:Module", ptr %t412, i32 0, i32 3
  %t415 = load i1, ptr %t414, !tbaa !21
  br i1 %t415, label %bb105, label %bb106
bb105:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t419 = load i64, ptr %l29, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t417, ptr %t418, i64 %t419, i1 false)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb109:
  %t423 = load i64, ptr %l28, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l28, !tbaa !24
  br label %bb100
bb110:
  store ptr @G_2ecompiler_2fsession_2eKeywords, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  %t428 = load ptr, ptr %l30
  store i64 41, ptr %l32, !tbaa !24
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s22
  %t431 = load i64, ptr %l31, !tbaa !24
  %t432 = load i64, ptr %l32, !tbaa !24
  %t435 = icmp slt i64 %t431, %t432
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s22)
  br label %bb117
bb113:
  br label %bb114
bb114:
  %t439 = load ptr, ptr %l30
  %t440 = load i64, ptr %l31, !tbaa !24
  %t443 = getelementptr [41 x { i64, ptr }], ptr %t439, i64 0, i64 %t440
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !37
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t448 = load i64, ptr @G_2ecompiler_2fsession_2eCompKeyword, !tbaa !24
  %t449 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %t449, ptr %s22, ptr %t446, { i64, ptr } %t444, i64 %t448, { i64, ptr } { i64 0, ptr @.d101 })
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s22)
  br label %bb116
bb116:
  %t453 = load i64, ptr %l31, !tbaa !24
  %t455 = add i64 %t453, 1
  store i64 %t455, ptr %l31, !tbaa !24
  br label %bb111
bb117:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l24 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l15
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l14
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f733ad54130e916b_d05149f8d1e95327)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t23 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t23, ptr %l4, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l24, !tbaa !27
  %t37 = load i64, ptr %l6, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr ptr, ptr %t40, i64 %t37
  %t42 = load ptr, ptr %t41, !tbaa !39
  store ptr %t42, ptr %l7, !tbaa !29
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = getelementptr %"compiler/load:Module", ptr %t44, i32 0, i32 4
  %t47 = load i64, ptr %t46, !tbaa !24
  %t51 = icmp eq i64 %t47, %a1
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l7, !tbaa !29
  %t55 = getelementptr %"compiler/load:Module", ptr %t53, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = extractvalue { i64, ptr } %t56, 0
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t58, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t62, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = add i64 %t68, %t69
  store i64 %t72, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store { i64, ptr } { i64 0, ptr @.d102 }, ptr %l39, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t74, ptr %l40, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = mul i64 %t77, 1
  %t79 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l42, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l41, !tbaa !24
  %t87 = mul i64 %t86, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %t85, i64 %t87, i1 false)
  %t88 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t88, ptr %l40, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t89, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t10 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 6
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_657f7671e8d24039_dcdf7cbf2572e335)
  unreachable
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/source:Source", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [6 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [6 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %lp12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca %"compiler/typed:Local"
  %l17 = alloca i64
  %lp19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l82 = alloca %"compiler/session:Found"
  %l92 = alloca i64
  %l99 = alloca ptr
  %l105 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l132 = alloca %"compiler/session:Found"
  %l137 = alloca %"compiler/session:FieldInfo"
  %l141 = alloca %"compiler/session:FieldInfo"
  %l142 = alloca i32
  %l144 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l157 = alloca %"compiler/session:Found"
  %l168 = alloca ptr
  %l173 = alloca %"compiler/typed:Local"
  %l177 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l207 = alloca ptr
  %l214 = alloca %"compiler/session:Found"
  %l223 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l235 = alloca %"compiler/session:Found"
  %l243 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l263 = alloca %"compiler/session:Found"
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:Found" }
  store ptr %a0, ptr %l0
  store { i64, [6 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [6 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [6 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, { i64, ptr } }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  %t15 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, { i64, ptr } }, ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  br label %bb31
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l35, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  br i1 %t29, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l40, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/session:Analysis", ptr %t35, i32 0, i32 3
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/session:Analysis", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = load ptr, ptr %l35, !tbaa !29
  %t49 = load ptr, ptr %l40, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %s1, ptr %t48, ptr %t49, ptr %t45, i64 %t46, { i64, ptr } %t47)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l49
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb14, label %ok.57
ok.57:
  store { i64, ptr } %t54, ptr %l48
  br label %bb13
bb13:
  %t58 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t58, ptr %l32, !tbaa !27
  br label %bb18
bb14:
  %t59 = load i32, ptr %l49, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  br i1 %t62, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  %t64 = load i32, ptr %l49, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 0, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  call void @__olang_scope_close(ptr %s1)
  %t74 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t72, 0
  store { i32, %"compiler/session:Found" } %t74, ptr %rv
  br label %ret
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  %t76 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t76, ptr %rv
  br label %ret
bb18:
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t77, ptr %l5, !tbaa !27
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9)
  unreachable
bb20:
  br label %bb21
bb21:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t83 = load i64, ptr %l3, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t88 = call i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %t82, i64 %t83, { i64, ptr } %t84)
  store i64 %t88, ptr %l59
  br label %bb22
bb22:
  %t89 = load i64, ptr %l59, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l60, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = icmp sge i64 %t91, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l3, !tbaa !24
  %t99 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t95, i64 %t96)
  store { i64, ptr } %t99, ptr %l66
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr @.d103 }, ptr %l63, !tbaa !27
  br label %bb27
bb25:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v2, { i64, ptr } %t101, i64 %t100, i1 true)
  store { i64, ptr } %t103, ptr %l68
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l63, !tbaa !27
  br label %bb27
bb27:
  %t112 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t114 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s1, ptr %v2, ptr %v2, { i64, ptr } %t112, { i64, ptr } %t113)
  store { i64, ptr } %t114, ptr %l70
  br label %bb28
bb28:
  %t115 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t117 = extractvalue { i64, ptr } %t115, 1
  %t118 = mul i64 %t116, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t118)
  call void @llvm.memcpy.p0.p0.i64(ptr %t119, ptr %t117, i64 %t118, i1 false)
  %t120 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l71, !tbaa !27
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/session:Analysis", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/load:Loader", ptr %t125, i32 0, i32 5
  %t128 = load i64, ptr %l3, !tbaa !24
  %t131 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t127, i64 %t128)
  store ptr %t131, ptr %l76
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l76, !tbaa !29
  %t134 = getelementptr %"compiler/load:Module", ptr %t132, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t153 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t150, { i64, ptr } %t148, i64 %t149)
  store %"compiler/session:Found" %t153, ptr %l82
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  %t154 = load %"compiler/session:Found", ptr %l82
  %t155 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t154, 1
  store { i32, %"compiler/session:Found" } %t155, ptr %rv
  br label %ret
bb31:
  %t156 = load { i64, [6 x i64] }, ptr %l1
  %t158 = extractvalue { i64, [6 x i64] } %t156, 0
  %t159 = icmp eq i64 %t158, 2
  br i1 %t159, label %bb32, label %bb33
bb32:
  %t161 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t162 = getelementptr { i64 }, ptr %t161, i32 0, i32 0
  %t163 = load i64, ptr %t162
  store i64 %t163, ptr %l7, !tbaa !24
  br label %bb34
bb33:
  br label %bb55
bb34:
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  br i1 %t167, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_913972385efaf6d8_94fc87626a418744)
  unreachable
bb36:
  br label %bb37
bb37:
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load i64, ptr %l7, !tbaa !24
  %t177 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l92
  br label %bb38
bb38:
  %t178 = load i64, ptr %l92, !tbaa !24
  store i64 %t178, ptr %l8, !tbaa !24
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  br i1 %t181, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_50b486dff56c46f7_6641abdfc6e3fb13)
  unreachable
bb40:
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t188 = load i64, ptr %l7, !tbaa !24
  %t191 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t187, i64 %t188)
  store ptr %t191, ptr %l99
  br label %bb42
bb42:
  %t192 = load ptr, ptr %l99, !tbaa !29
  %t194 = getelementptr %"compiler/ast:Func", ptr %t192, i32 0, i32 0
  %t195 = getelementptr %"compiler/source:Span", ptr %t194, i32 0, i32 0
  %t196 = load i32, ptr %t195, !tbaa !23
  %t198 = sext i32 %t196 to i64
  store i64 %t198, ptr %l9, !tbaa !24
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  br i1 %t202, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee)
  unreachable
bb44:
  br label %bb45
bb45:
  %t204 = load ptr, ptr %l2, !tbaa !29
  store ptr %t204, ptr %l105, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/session:Analysis", ptr %t205, i32 0, i32 2
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee)
  unreachable
bb47:
  br label %bb48
bb48:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/session:Analysis", ptr %t212, i32 0, i32 2
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t216 = load i64, ptr %l7, !tbaa !24
  %t217 = load ptr, ptr %l105, !tbaa !29
  %t220 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %v2, ptr %t217, ptr %t215, i64 %t216)
  store { i64, ptr } %t220, ptr %l112
  br label %bb49
bb49:
  %t221 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  %t223 = extractvalue { i64, ptr } %t221, 1
  %t224 = mul i64 %t222, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t224)
  call void @llvm.memcpy.p0.p0.i64(ptr %t225, ptr %t223, i64 %t224, i1 false)
  %t226 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l113, !tbaa !27
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l8, !tbaa !24
  %t232 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t228, i64 %t229)
  store { i64, ptr } %t232, ptr %l116
  br label %bb50
bb50:
  %t233 = load i64, ptr %l9, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t236 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v2, { i64, ptr } %t234, i64 %t233)
  store { i64, ptr } %t236, ptr %l118
  br label %bb51
bb51:
  %t237 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  %t244 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t244, { i64, ptr } %t243)
  store { i64, ptr } %t246, ptr %l120
  br label %bb52
bb52:
  %t247 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  %t249 = extractvalue { i64, ptr } %t247, 1
  %t250 = mul i64 %t248, 1
  %t251 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t250)
  call void @llvm.memcpy.p0.p0.i64(ptr %t251, ptr %t249, i64 %t250, i1 false)
  %t252 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  store { i64, ptr } %t253, ptr %l121, !tbaa !27
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/session:Analysis", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/load:Loader", ptr %t257, i32 0, i32 5
  %t260 = load i64, ptr %l8, !tbaa !24
  %t263 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t259, i64 %t260)
  store ptr %t263, ptr %l126
  br label %bb53
bb53:
  %t264 = load ptr, ptr %l126, !tbaa !29
  %t266 = getelementptr %"compiler/load:Module", ptr %t264, i32 0, i32 1
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 1
  %t270 = extractvalue { i64, ptr } %t267, 0
  %t271 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t269, i64 %t270)
  %t272 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = extractvalue { i64, ptr } %t273, 1
  %t277 = mul i64 %t275, 1
  %t278 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t277)
  call void @llvm.memcpy.p0.p0.i64(ptr %t278, ptr %t276, i64 %t277, i1 false)
  %t279 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t278, 1
  %t281 = load i64, ptr %l9, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t285 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t282, { i64, ptr } %t280, i64 %t281)
  store %"compiler/session:Found" %t285, ptr %l132
  br label %bb54
bb54:
  %t286 = load %"compiler/session:Found", ptr %l132
  %t287 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t286, 1
  store { i32, %"compiler/session:Found" } %t287, ptr %rv
  br label %ret
bb55:
  %t288 = load { i64, [6 x i64] }, ptr %l1
  %t290 = extractvalue { i64, [6 x i64] } %t288, 0
  %t291 = icmp eq i64 %t290, 3
  br i1 %t291, label %bb56, label %bb57
bb56:
  %t293 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t294 = getelementptr { i32, i64 }, ptr %t293, i32 0, i32 0
  %t295 = load i32, ptr %t294
  store i32 %t295, ptr %l10, !tbaa !23
  %t297 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t298 = getelementptr { i32, i64 }, ptr %t297, i32 0, i32 1
  %t299 = load i64, ptr %t298
  store i64 %t299, ptr %l11, !tbaa !24
  br label %bb58
bb57:
  br label %bb68
bb58:
  store %olang.scope zeroinitializer, ptr %s6
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = load i32, ptr %l10, !tbaa !23
  %t303 = load i64, ptr %l11, !tbaa !24
  %t307 = call { i32, %"compiler/session:FieldInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v2, ptr %t301, i32 %t302, i64 %t303)
  %t308 = extractvalue { i32, %"compiler/session:FieldInfo" } %t307, 1
  %t309 = extractvalue { i32, %"compiler/session:FieldInfo" } %t307, 0
  store i32 %t309, ptr %l142
  %t310 = icmp ne i32 %t309, 0
  br i1 %t310, label %bb60, label %ok.311
ok.311:
  store %"compiler/session:FieldInfo" %t308, ptr %l141
  br label %bb59
bb59:
  %t312 = load %"compiler/session:FieldInfo", ptr %l141
  store %"compiler/session:FieldInfo" %t312, ptr %l137
  br label %bb61
bb60:
  %t313 = load i32, ptr %l142, !tbaa !23
  %t314 = lshr i32 %t313, 16
  %t315 = and i32 %t313, 65535
  %t316 = icmp eq i32 %t314, 1
  %t317 = select i1 %t316, i32 1, i32 0
  %t318 = icmp eq i32 %t313, 0
  %t319 = shl i32 %t317, 16
  %t320 = or i32 %t319, %t315
  %t321 = select i1 %t318, i32 0, i32 %t320
  call void @__olang_scope_close(ptr %s6)
  %t323 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t321, 0
  store { i32, %"compiler/session:Found" } %t323, ptr %rv
  br label %ret
bb61:
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store ptr %t324, ptr %lp12
  %t325 = load %"compiler/session:FieldInfo", ptr %l137
  %t326 = load ptr, ptr %lp12
  store %"compiler/session:FieldInfo" %t325, ptr %t326
  %t327 = load ptr, ptr %lp12
  %t328 = getelementptr %"compiler/session:FieldInfo", ptr %t327, i32 0, i32 0
  %t329 = load { i64, ptr }, ptr %t328, !tbaa !27
  store { i64, ptr } %t329, ptr %l144, !tbaa !27
  %t330 = load ptr, ptr %l2, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  br i1 %t332, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb63:
  br label %bb64
bb64:
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t335 = load ptr, ptr %lp12
  %t336 = getelementptr %"compiler/session:FieldInfo", ptr %t335, i32 0, i32 1
  %t337 = load i32, ptr %t336, !tbaa !23
  %t340 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s6, ptr %t334, i32 %t337)
  store { i64, ptr } %t340, ptr %l149
  br label %bb65
bb65:
  %t341 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 1
  %t345 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 0
  %t346 = add i64 %t343, %t345
  %t347 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 1
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t350 = add i64 %t346, %t349
  %t351 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t342, i64 %t343)
  %t352 = getelementptr i8, ptr %t351, i64 %t343
  call void @olang_textcopy(ptr %t352, ptr %t344, i64 %t345)
  %t353 = getelementptr i8, ptr %t352, i64 %t345
  call void @olang_textcopy(ptr %t353, ptr %t348, i64 %t349)
  %t354 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t351, 1
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t358 = extractvalue { i64, ptr } %t355, 1
  %t359 = mul i64 %t357, 1
  %t360 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t359)
  call void @llvm.memcpy.p0.p0.i64(ptr %t360, ptr %t358, i64 %t359, i1 false)
  %t361 = insertvalue { i64, ptr } undef, i64 %t357, 0
  %t362 = insertvalue { i64, ptr } %t361, ptr %t360, 1
  %t363 = load ptr, ptr %lp12
  %t364 = getelementptr %"compiler/session:FieldInfo", ptr %t363, i32 0, i32 2
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !27
  %t368 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t362, { i64, ptr } %t365)
  store { i64, ptr } %t368, ptr %l153
  br label %bb66
bb66:
  %t369 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t369, 0
  %t371 = extractvalue { i64, ptr } %t369, 1
  %t372 = mul i64 %t370, 1
  %t373 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t372)
  call void @llvm.memcpy.p0.p0.i64(ptr %t373, ptr %t371, i64 %t372, i1 false)
  %t374 = insertvalue { i64, ptr } undef, i64 %t370, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  %t376 = load ptr, ptr %lp12
  %t377 = getelementptr %"compiler/session:FieldInfo", ptr %t376, i32 0, i32 3
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !27
  %t379 = load ptr, ptr %lp12
  %t380 = getelementptr %"compiler/session:FieldInfo", ptr %t379, i32 0, i32 4
  %t381 = load i64, ptr %t380, !tbaa !24
  %t385 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t375, { i64, ptr } %t378, i64 %t381)
  store %"compiler/session:Found" %t385, ptr %l157
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s6)
  %t386 = load %"compiler/session:Found", ptr %l157
  %t387 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t386, 1
  store { i32, %"compiler/session:Found" } %t387, ptr %rv
  br label %ret
bb68:
  %t388 = load { i64, [6 x i64] }, ptr %l1
  %t390 = extractvalue { i64, [6 x i64] } %t388, 0
  %t391 = icmp eq i64 %t390, 4
  br i1 %t391, label %bb69, label %bb70
bb69:
  %t393 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t394 = getelementptr { i64, i32 }, ptr %t393, i32 0, i32 0
  %t395 = load i64, ptr %t394
  store i64 %t395, ptr %l13, !tbaa !24
  %t397 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t398 = getelementptr { i64, i32 }, ptr %t397, i32 0, i32 1
  %t399 = load i32, ptr %t398
  store i32 %t399, ptr %l14, !tbaa !23
  br label %bb71
bb70:
  br label %bb95
bb71:
  store %olang.scope zeroinitializer, ptr %s8
  %t401 = load ptr, ptr %l2, !tbaa !29
  %t403 = icmp eq ptr %t401, null
  br i1 %t403, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb73:
  br label %bb74
bb74:
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t405, i32 0, i32 11
  %t409 = load i64, ptr %l13, !tbaa !24
  %t412 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t408, i64 %t409)
  store ptr %t412, ptr %l168
  br label %bb75
bb75:
  %t413 = load ptr, ptr %l168, !tbaa !29
  store ptr %t413, ptr %l15, !tbaa !29
  %t414 = load ptr, ptr %l15, !tbaa !29
  %t416 = getelementptr %"compiler/typed:Body", ptr %t414, i32 0, i32 7
  %t417 = load i32, ptr %l14, !tbaa !23
  %t419 = sext i32 %t417 to i64
  %t422 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t416, i64 %t419)
  store %"compiler/typed:Local" %t422, ptr %l173
  br label %bb76
bb76:
  %t423 = load %"compiler/typed:Local", ptr %l173
  store %"compiler/typed:Local" %t423, ptr %l16
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l15, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Body", ptr %t425, i32 0, i32 3
  %t428 = load i64, ptr %t427, !tbaa !24
  %t431 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t424, i64 %t428)
  store i64 %t431, ptr %l177
  br label %bb77
bb77:
  %t432 = load i64, ptr %l177, !tbaa !24
  store i64 %t432, ptr %l17, !tbaa !24
  %t433 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 4
  %t434 = load i32, ptr %t433
  %t436 = trunc i64 0 to i32
  %t437 = icmp eq i32 %t434, %t436
  br i1 %t437, label %bb78, label %bb79
bb78:
  store { i64, ptr } { i64 10, ptr @.d105 }, ptr %l180, !tbaa !27
  br label %bb80
bb79:
  store { i64, ptr } { i64 0, ptr @.d106 }, ptr %l180, !tbaa !27
  br label %bb80
bb80:
  %t439 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t439, ptr %l181, !tbaa !27
  %t441 = load ptr, ptr %l2, !tbaa !29
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_9453126c7f8f920b_6892400c5eb9861f)
  unreachable
bb82:
  br label %bb83
bb83:
  %t445 = load ptr, ptr %l2, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t445, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t449, i32 0, i32 0
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/load:Loader", ptr %t452, i32 0, i32 3
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t456 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 0
  %t457 = load i32, ptr %t456, !tbaa !23
  %t460 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t455, i32 %t457)
  store { i64, ptr } %t460, ptr %l190
  br label %bb84
bb84:
  %t461 = load ptr, ptr %l2, !tbaa !29
  %t463 = icmp eq ptr %t461, null
  br i1 %t463, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_9453126c7f8f920b_6892400c5eb9861f)
  unreachable
bb86:
  br label %bb87
bb87:
  %t465 = load ptr, ptr %l2, !tbaa !29
  %t466 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 2
  %t467 = load i32, ptr %t466, !tbaa !23
  %t470 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t465, i32 %t467)
  store { i64, ptr } %t470, ptr %l195
  br label %bb88
bb88:
  %t471 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 1
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t474 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = extractvalue { i64, ptr } %t474, 0
  %t477 = add i64 %t473, %t476
  %t478 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 1
  %t479 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 0
  %t480 = add i64 %t477, %t479
  %t481 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 1
  %t483 = extractvalue { i64, ptr } %t481, 0
  %t484 = add i64 %t480, %t483
  %t485 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t484)
  call void @olang_textcopy(ptr %t485, ptr %t472, i64 %t473)
  %t486 = getelementptr i8, ptr %t485, i64 %t473
  call void @olang_textcopy(ptr %t486, ptr %t475, i64 %t476)
  %t487 = getelementptr i8, ptr %t486, i64 %t476
  call void @olang_textcopy(ptr %t487, ptr %t478, i64 %t479)
  %t488 = getelementptr i8, ptr %t487, i64 %t479
  call void @olang_textcopy(ptr %t488, ptr %t482, i64 %t483)
  %t489 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t485, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } %t490, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t499 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t497, { i64, ptr } { i64 0, ptr @.d108 })
  store { i64, ptr } %t499, ptr %l198
  br label %bb89
bb89:
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t500, ptr %lp19
  %t501 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t502 = load ptr, ptr %lp19
  store { i64, ptr } %t501, ptr %t502, !tbaa !27
  %t503 = load ptr, ptr %lp19
  %t504 = load { i64, ptr }, ptr %t503, !tbaa !27
  store { i64, ptr } %t504, ptr %l199, !tbaa !27
  %t505 = load i64, ptr %l17, !tbaa !24
  %t507 = icmp sge i64 %t505, 0
  br i1 %t507, label %bb90, label %bb91
bb90:
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/session:Analysis", ptr %t509, i32 0, i32 0
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t514 = getelementptr %"compiler/load:Loader", ptr %t512, i32 0, i32 5
  %t515 = load i64, ptr %l17, !tbaa !24
  %t518 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t514, i64 %t515)
  store ptr %t518, ptr %l207
  br label %bb92
bb91:
  store { i64, ptr } { i64 0, ptr @.d109 }, ptr %l202, !tbaa !27
  br label %bb93
bb92:
  %t519 = load ptr, ptr %l207, !tbaa !29
  %t521 = getelementptr %"compiler/load:Module", ptr %t519, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t522, 1
  %t525 = extractvalue { i64, ptr } %t522, 0
  %t526 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t525)
  call void @olang_textcopy(ptr %t526, ptr %t524, i64 %t525)
  %t527 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t528 = insertvalue { i64, ptr } %t527, ptr %t526, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = extractvalue { i64, ptr } %t528, 1
  %t532 = mul i64 %t530, 1
  %t533 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t532)
  call void @llvm.memcpy.p0.p0.i64(ptr %t533, ptr %t531, i64 %t532, i1 false)
  %t534 = insertvalue { i64, ptr } undef, i64 %t530, 0
  %t535 = insertvalue { i64, ptr } %t534, ptr %t533, 1
  store { i64, ptr } %t535, ptr %l202, !tbaa !27
  br label %bb93
bb93:
  %t537 = getelementptr %"compiler/typed:Local", ptr %l16, i32 0, i32 1
  %t538 = getelementptr %"compiler/source:Span", ptr %t537, i32 0, i32 0
  %t539 = load i32, ptr %t538, !tbaa !23
  %t541 = sext i32 %t539 to i64
  %t542 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t543 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t545 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t542, { i64, ptr } %t543, i64 %t541)
  store %"compiler/session:Found" %t545, ptr %l214
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s8)
  %t546 = load %"compiler/session:Found", ptr %l214
  %t547 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t546, 1
  store { i32, %"compiler/session:Found" } %t547, ptr %rv
  br label %ret
bb95:
  %t548 = load { i64, [6 x i64] }, ptr %l1
  %t550 = extractvalue { i64, [6 x i64] } %t548, 0
  %t551 = icmp eq i64 %t550, 5
  br i1 %t551, label %bb96, label %bb97
bb96:
  %t553 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t554 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t553, i32 0, i32 0
  %t555 = load i64, ptr %t554
  store i64 %t555, ptr %l20, !tbaa !24
  %t557 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t558 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t557, i32 0, i32 1
  %t559 = load i64, ptr %t558
  store i64 %t559, ptr %l21, !tbaa !24
  %t561 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t562 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t561, i32 0, i32 2
  %t563 = load { i64, ptr }, ptr %t562
  store { i64, ptr } %t563, ptr %l22, !tbaa !27
  %t565 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t566 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t565, i32 0, i32 3
  %t567 = load { i64, ptr }, ptr %t566
  store { i64, ptr } %t567, ptr %l23, !tbaa !27
  br label %bb98
bb97:
  br label %bb102
bb98:
  %t569 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t570 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t573 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t569, { i64, ptr } %t570)
  store { i64, ptr } %t573, ptr %l223
  br label %bb99
bb99:
  %t574 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t574, 0
  %t576 = extractvalue { i64, ptr } %t574, 1
  %t577 = mul i64 %t575, 1
  %t578 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t577)
  call void @llvm.memcpy.p0.p0.i64(ptr %t578, ptr %t576, i64 %t577, i1 false)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t578, 1
  store { i64, ptr } %t580, ptr %l224, !tbaa !27
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/session:Analysis", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t586 = getelementptr %"compiler/load:Loader", ptr %t584, i32 0, i32 5
  %t587 = load i64, ptr %l20, !tbaa !24
  %t590 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t586, i64 %t587)
  store ptr %t590, ptr %l229
  br label %bb100
bb100:
  %t591 = load ptr, ptr %l229, !tbaa !29
  %t593 = getelementptr %"compiler/load:Module", ptr %t591, i32 0, i32 1
  %t594 = load { i64, ptr }, ptr %t593, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t594, 1
  %t597 = extractvalue { i64, ptr } %t594, 0
  %t598 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t597)
  call void @olang_textcopy(ptr %t598, ptr %t596, i64 %t597)
  %t599 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  %t608 = load i64, ptr %l21, !tbaa !24
  %t609 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t612 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t609, { i64, ptr } %t607, i64 %t608)
  store %"compiler/session:Found" %t612, ptr %l235
  br label %bb101
bb101:
  %t613 = load %"compiler/session:Found", ptr %l235
  %t614 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t613, 1
  store { i32, %"compiler/session:Found" } %t614, ptr %rv
  br label %ret
bb102:
  %t615 = load { i64, [6 x i64] }, ptr %l1
  %t617 = extractvalue { i64, [6 x i64] } %t615, 0
  %t618 = icmp eq i64 %t617, 6
  br i1 %t618, label %bb103, label %bb104
bb103:
  %t620 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t621 = getelementptr { i64 }, ptr %t620, i32 0, i32 0
  %t622 = load i64, ptr %t621
  store i64 %t622, ptr %l24, !tbaa !24
  br label %bb105
bb104:
  br label %bb113
bb105:
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/session:Analysis", ptr %t624, i32 0, i32 0
  %t627 = load ptr, ptr %t626, !tbaa !29
  %t629 = getelementptr %"compiler/load:Loader", ptr %t627, i32 0, i32 5
  %t630 = load i64, ptr %l24, !tbaa !24
  %t633 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t629, i64 %t630)
  store ptr %t633, ptr %l243
  br label %bb106
bb106:
  %t634 = load ptr, ptr %l243, !tbaa !29
  store ptr %t634, ptr %l25, !tbaa !29
  %t635 = load ptr, ptr %l25, !tbaa !29
  %t637 = getelementptr %"compiler/load:Module", ptr %t635, i32 0, i32 2
  %t638 = load { i64, ptr }, ptr %t637, !tbaa !27
  %t639 = extractvalue { i64, ptr } { i64 8, ptr @.d110 }, 1
  %t640 = extractvalue { i64, ptr } { i64 8, ptr @.d110 }, 0
  %t642 = extractvalue { i64, ptr } %t638, 1
  %t643 = extractvalue { i64, ptr } %t638, 0
  %t644 = add i64 %t640, %t643
  %t645 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 1
  %t646 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 0
  %t647 = add i64 %t644, %t646
  %t648 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t647)
  call void @olang_textcopy(ptr %t648, ptr %t639, i64 %t640)
  %t649 = getelementptr i8, ptr %t648, i64 %t640
  call void @olang_textcopy(ptr %t649, ptr %t642, i64 %t643)
  %t650 = getelementptr i8, ptr %t649, i64 %t643
  call void @olang_textcopy(ptr %t650, ptr %t645, i64 %t646)
  %t651 = insertvalue { i64, ptr } undef, i64 %t647, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t648, 1
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t655 = extractvalue { i64, ptr } %t652, 1
  %t656 = mul i64 %t654, 1
  %t657 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t656)
  call void @llvm.memcpy.p0.p0.i64(ptr %t657, ptr %t655, i64 %t656, i1 false)
  %t658 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t659 = insertvalue { i64, ptr } %t658, ptr %t657, 1
  store { i64, ptr } %t659, ptr %l247, !tbaa !27
  %t660 = load ptr, ptr %l25, !tbaa !29
  %t662 = getelementptr %"compiler/load:Module", ptr %t660, i32 0, i32 6
  %t663 = load ptr, ptr %t662, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  br i1 %t665, label %bb107, label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a)
  unreachable
bb108:
  br label %bb109
bb109:
  %t667 = load ptr, ptr %l25, !tbaa !29
  %t669 = getelementptr %"compiler/load:Module", ptr %t667, i32 0, i32 6
  %t670 = load ptr, ptr %t669, !tbaa !29
  %t673 = getelementptr %"compiler/source:Source", ptr %t670, i32 0, i32 1
  %t674 = load { i64, ptr }, ptr %t673, !tbaa !27
  %t676 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v2, { i64, ptr } %t674)
  store { i64, ptr } %t676, ptr %l255
  br label %bb110
bb110:
  %t677 = load { i64, ptr }, ptr %l255, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t677, 0
  %t679 = extractvalue { i64, ptr } %t677, 1
  %t680 = mul i64 %t678, 1
  %t681 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t680)
  call void @llvm.memcpy.p0.p0.i64(ptr %t681, ptr %t679, i64 %t680, i1 false)
  %t682 = insertvalue { i64, ptr } undef, i64 %t678, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t681, 1
  %t684 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t686 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t684, { i64, ptr } %t683)
  store { i64, ptr } %t686, ptr %l257
  br label %bb111
bb111:
  %t687 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t688 = extractvalue { i64, ptr } %t687, 0
  %t689 = extractvalue { i64, ptr } %t687, 1
  %t690 = mul i64 %t688, 1
  %t691 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t690)
  call void @llvm.memcpy.p0.p0.i64(ptr %t691, ptr %t689, i64 %t690, i1 false)
  %t692 = insertvalue { i64, ptr } undef, i64 %t688, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr %t691, 1
  %t694 = load ptr, ptr %l25, !tbaa !29
  %t696 = getelementptr %"compiler/load:Module", ptr %t694, i32 0, i32 1
  %t697 = load { i64, ptr }, ptr %t696, !tbaa !27
  %t699 = extractvalue { i64, ptr } %t697, 1
  %t700 = extractvalue { i64, ptr } %t697, 0
  %t701 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t700)
  call void @olang_textcopy(ptr %t701, ptr %t699, i64 %t700)
  %t702 = insertvalue { i64, ptr } undef, i64 %t700, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  %t705 = extractvalue { i64, ptr } %t703, 0
  %t706 = extractvalue { i64, ptr } %t703, 1
  %t707 = mul i64 %t705, 1
  %t708 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t707)
  call void @llvm.memcpy.p0.p0.i64(ptr %t708, ptr %t706, i64 %t707, i1 false)
  %t709 = insertvalue { i64, ptr } undef, i64 %t705, 0
  %t710 = insertvalue { i64, ptr } %t709, ptr %t708, 1
  %t713 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t693, { i64, ptr } %t710, i64 0)
  store %"compiler/session:Found" %t713, ptr %l263
  br label %bb112
bb112:
  %t714 = load %"compiler/session:Found", ptr %l263
  %t715 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t714, 1
  store { i32, %"compiler/session:Found" } %t715, ptr %rv
  br label %ret
bb113:
  %t716 = load { i64, [6 x i64] }, ptr %l1
  %t718 = extractvalue { i64, [6 x i64] } %t716, 0
  %t719 = icmp eq i64 %t718, 0
  br i1 %t719, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  %t722 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t722, ptr %rv
  br label %ret
bb117:
  call void @__olang_check_failed(ptr @olang_loc_20929c6a5a73c2c_efaf2a5e5b22d0b8)
  unreachable
ret:
  %rr = load { i32, %"compiler/session:Found" }, ptr %rv
  ret { i32, %"compiler/session:Found" } %rr
}

define dso_local { i32, %"compiler/session:FieldInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i32
  %l14 = alloca %"compiler/typed:Local"
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %lp17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i32
  %l40 = alloca i32
  %l49 = alloca i32
  %l61 = alloca i32
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l81 = alloca { i64, ptr }
  %l96 = alloca i32
  %l100 = alloca i1
  %l108 = alloca i32
  %l111 = alloca i1
  %l112 = alloca i64
  %l115 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca %"compiler/typed:Local"
  %l128 = alloca i64
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l157 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca { i64, ptr }
  %l178 = alloca i32
  %l179 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l184 = alloca i32
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l194 = alloca ptr
  %l201 = alloca %"compiler/session:FieldInfo"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:FieldInfo" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l29
  br label %bb4
bb4:
  %t21 = load i32, ptr %l29
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l32, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l40
  br label %bb10
bb10:
  %t43 = load i32, ptr %l40, !tbaa !23
  store i32 %t43, ptr %l32, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l32, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e81878307a0930f8_ac6e376276a113b4)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l49
  br label %bb15
bb15:
  %t60 = load i32, ptr %l49
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t68 = insertvalue { i32, %"compiler/session:FieldInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:FieldInfo" } %t68, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cf719ce72396210d_6e539aa1951515a9)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l61
  br label %bb22
bb22:
  %t84 = load i32, ptr %l61, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_90bed28a447e5726_404cd49f4fb329c2)
  unreachable
bb24:
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 11
  store ptr %t92, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t94, i64 %t95)
  %t99 = extractvalue { i32, { i64, ptr } } %t98, 1
  %t100 = extractvalue { i32, { i64, ptr } } %t98, 0
  store i32 %t100, ptr %l71
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb28, label %ok.102
ok.102:
  store { i64, ptr } %t99, ptr %l70
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t103, ptr %l67, !tbaa !27
  br label %bb32
bb28:
  %t104 = load i32, ptr %l71, !tbaa !23
  %t105 = ashr i32 %t104, 16
  %t107 = icmp eq i32 %t105, 1
  br i1 %t107, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  %t109 = load i32, ptr %l71, !tbaa !23
  %t110 = lshr i32 %t109, 16
  %t111 = and i32 %t109, 65535
  %t112 = icmp eq i32 %t110, 1
  %t113 = select i1 %t112, i32 0, i32 0
  %t114 = icmp eq i32 %t109, 0
  %t115 = shl i32 %t113, 16
  %t116 = or i32 %t115, %t111
  %t117 = select i1 %t114, i32 0, i32 %t116
  call void @__olang_scope_close(ptr %s3)
  %t119 = insertvalue { i32, %"compiler/session:FieldInfo" } zeroinitializer, i32 %t117, 0
  store { i32, %"compiler/session:FieldInfo" } %t119, ptr %rv
  br label %ret
bb31:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb101
bb32:
  %t120 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t120, ptr %l8, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  store i64 %t123, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb99
bb35:
  br label %bb36
bb36:
  %t133 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t133, ptr %l81, !tbaa !27
  %t134 = load i64, ptr %l10, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 %t134
  %t139 = load ptr, ptr %t138, !tbaa !39
  store ptr %t139, ptr %l11, !tbaa !29
  %t141 = load ptr, ptr %l11, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Body", ptr %t141, i32 0, i32 1
  %t144 = load { i64, [2 x i64] }, ptr %t143
  store { i64, [2 x i64] } %t144, ptr %l12
  %t146 = load { i64, [2 x i64] }, ptr %l12
  %t148 = extractvalue { i64, [2 x i64] } %t146, 0
  %t149 = icmp eq i64 %t148, 1
  br i1 %t149, label %bb37, label %bb38
bb37:
  %t151 = getelementptr { i64, [2 x i64] }, ptr %l12, i32 0, i32 1
  %t152 = getelementptr { i32, i32 }, ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152
  store i32 %t153, ptr %l13, !tbaa !23
  br label %bb39
bb38:
  br label %bb92
bb39:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t157 = icmp eq ptr %t155, null
  br i1 %t157, label %bb40, label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb41:
  br label %bb42
bb42:
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l13, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l96
  br label %bb43
bb43:
  %t170 = load i32, ptr %l96
  %t172 = trunc i64 18 to i32
  %t173 = icmp eq i32 %t170, %t172
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb50
bb45:
  %t177 = load ptr, ptr %l3, !tbaa !29
  %t179 = icmp eq ptr %t177, null
  br i1 %t179, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb47:
  br label %bb48
bb48:
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t181, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 2
  %t188 = load i32, ptr %l13, !tbaa !23
  %t191 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t187, i32 %t188)
  store i32 %t191, ptr %l108
  br label %bb49
bb49:
  %t192 = load i32, ptr %l5, !tbaa !23
  %t193 = load i32, ptr %l108, !tbaa !23
  %t195 = icmp ne i32 %t193, %t192
  store i1 %t195, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t197 = load i1, ptr %l100, !tbaa !21
  br i1 %t197, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb54
bb52:
  %t198 = load i64, ptr %l2, !tbaa !24
  store i64 %t198, ptr %l112, !tbaa !24
  %t199 = load ptr, ptr %l11, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Body", ptr %t199, i32 0, i32 10
  %t203 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t201)
  store i64 %t203, ptr %l115
  br label %bb53
bb53:
  %t204 = load i64, ptr %l112, !tbaa !24
  %t205 = load i64, ptr %l115, !tbaa !24
  %t206 = icmp sge i64 %t204, %t205
  store i1 %t206, ptr %l111, !tbaa !21
  br label %bb54
bb54:
  %t208 = load i1, ptr %l111, !tbaa !21
  br i1 %t208, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb98
bb56:
  br label %bb57
bb57:
  %t209 = load ptr, ptr %l11, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 7
  store ptr %t211, ptr %l118, !tbaa !29
  %t212 = load ptr, ptr %l11, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Body", ptr %t212, i32 0, i32 10
  %t215 = load i64, ptr %l2, !tbaa !24
  %t218 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l122
  br label %bb58
bb58:
  %t219 = load i32, ptr %l122, !tbaa !23
  %t220 = sext i32 %t219 to i64
  %t221 = load ptr, ptr %l118, !tbaa !29
  %t223 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t221, i64 %t220)
  store %"compiler/typed:Local" %t223, ptr %l124
  br label %bb59
bb59:
  %t224 = load %"compiler/typed:Local", ptr %l124
  store %"compiler/typed:Local" %t224, ptr %l14
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l11, !tbaa !29
  %t228 = getelementptr %"compiler/typed:Body", ptr %t226, i32 0, i32 3
  %t229 = load i64, ptr %t228, !tbaa !24
  %t232 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t225, i64 %t229)
  store i64 %t232, ptr %l128
  br label %bb60
bb60:
  %t233 = load i64, ptr %l128, !tbaa !24
  store i64 %t233, ptr %l15, !tbaa !24
  %t234 = load i64, ptr %l15, !tbaa !24
  %t236 = icmp slt i64 %t234, 0
  br i1 %t236, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t239 = insertvalue { i32, %"compiler/session:FieldInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:FieldInfo" } %t239, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i64, ptr %l15, !tbaa !24
  %t244 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t240, i64 %t241)
  store { i64, ptr } %t244, ptr %l134
  br label %bb64
bb64:
  %t245 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t245, ptr %l16, !tbaa !27
  %t246 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t247 = load i32, ptr %t246, !tbaa !23
  %t249 = icmp eq i32 %t247, 0
  br i1 %t249, label %bb65, label %bb66
bb65:
  %t251 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t251, ptr %l138, !tbaa !27
  %t252 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 1
  %t253 = getelementptr %"compiler/source:Span", ptr %t252, i32 0, i32 0
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = sext i32 %t254 to i64
  store i64 %t256, ptr %l140, !tbaa !24
  %t257 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 1
  %t258 = getelementptr %"compiler/source:Span", ptr %t257, i32 0, i32 1
  %t259 = load i32, ptr %t258, !tbaa !23
  %t261 = sext i32 %t259 to i64
  store i64 %t261, ptr %l142, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l143, !tbaa !24
  %t264 = load i64, ptr %l140, !tbaa !24
  %t265 = icmp sge i64 %t264, 0
  br i1 %t265, label %bb67, label %bb68
bb66:
  %t267 = load ptr, ptr %l3, !tbaa !29
  %t269 = icmp eq ptr %t267, null
  br i1 %t269, label %bb73, label %bb74
bb67:
  %t271 = load i64, ptr %l140, !tbaa !24
  %t272 = load i64, ptr %l142, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb69:
  %t275 = load i64, ptr %l142, !tbaa !24
  %t276 = load i64, ptr %l143, !tbaa !24
  %t277 = icmp sle i64 %t275, %t276
  br i1 %t277, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb71:
  %t279 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l140, !tbaa !24
  %t282 = load i64, ptr %l142, !tbaa !24
  %t283 = getelementptr i8, ptr %t280, i64 %t281
  %t284 = sub i64 %t282, %t281
  %t285 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t283, 1
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = extractvalue { i64, ptr } %t286, 0
  %t290 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t288, i64 %t289)
  %t291 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l137, !tbaa !27
  br label %bb77
bb72:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4c52bbc768601131_90801d9bf2a41585)
  unreachable
bb74:
  br label %bb75
bb75:
  %t294 = load ptr, ptr %l3, !tbaa !29
  %t297 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = getelementptr %"compiler/generic:Program", ptr %t298, i32 0, i32 0
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/load:Loader", ptr %t301, i32 0, i32 3
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 0
  %t306 = load i32, ptr %t305, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t304, i32 %t306)
  store { i64, ptr } %t309, ptr %l157
  br label %bb76
bb76:
  %t310 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t311, i64 %t312)
  %t314 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  store { i64, ptr } %t315, ptr %l137, !tbaa !27
  br label %bb77
bb77:
  %t317 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t317, ptr %lp17
  %t318 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t319 = load ptr, ptr %lp17
  store { i64, ptr } %t318, ptr %t319, !tbaa !27
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  br i1 %t322, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb79:
  br label %bb80
bb80:
  %t324 = load ptr, ptr %l3, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = getelementptr %"compiler/generic:Program", ptr %t328, i32 0, i32 2
  store ptr %t330, ptr %l164, !tbaa !29
  %t331 = load ptr, ptr %l3, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb81, label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb82:
  br label %bb83
bb83:
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/generic:Program", ptr %t339, i32 0, i32 2
  %t342 = load i32, ptr %l4, !tbaa !23
  %t345 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t341, i32 %t342)
  store i32 %t345, ptr %l172
  br label %bb84
bb84:
  %t346 = load ptr, ptr %l164, !tbaa !29
  %t347 = load i32, ptr %l172, !tbaa !23
  %t348 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t346, i32 %t347)
  store { i64, ptr } %t348, ptr %l173
  br label %bb85
bb85:
  %t349 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t349, ptr %l18, !tbaa !27
  %t350 = load i64, ptr %l2, !tbaa !24
  %t351 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t356 = icmp slt i64 %t350, %t353
  br i1 %t356, label %bb86, label %bb87
bb86:
  %t358 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t358, ptr %l179, !tbaa !27
  %t359 = load i64, ptr %l2, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr i32, ptr %t362, i64 %t359
  %t364 = load i32, ptr %t363, !tbaa !33
  store i32 %t364, ptr %l178, !tbaa !23
  br label %bb88
bb87:
  %t366 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 2
  %t367 = load i32, ptr %t366, !tbaa !23
  store i32 %t367, ptr %l178, !tbaa !23
  br label %bb88
bb88:
  %t369 = load i32, ptr %l178, !tbaa !23
  %t370 = load ptr, ptr %lp17
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  store { i64, ptr } %t371, ptr %l183, !tbaa !27
  store i32 %t369, ptr %l184, !tbaa !23
  %t373 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t374 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 1
  %t375 = getelementptr %"compiler/source:Span", ptr %t374, i32 0, i32 0
  %t376 = load i32, ptr %t375, !tbaa !23
  %t378 = sext i32 %t376 to i64
  %t381 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %t373, i64 %t378, i1 true)
  store { i64, ptr } %t381, ptr %l188
  br label %bb89
bb89:
  %t382 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 0
  %t384 = extractvalue { i64, ptr } %t382, 1
  %t385 = mul i64 %t383, 1
  %t386 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t385)
  call void @llvm.memcpy.p0.p0.i64(ptr %t386, ptr %t384, i64 %t385, i1 false)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t386, 1
  store { i64, ptr } %t388, ptr %l189, !tbaa !27
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t391 = getelementptr %"compiler/session:Analysis", ptr %t389, i32 0, i32 0
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t394 = getelementptr %"compiler/load:Loader", ptr %t392, i32 0, i32 5
  %t395 = load i64, ptr %l15, !tbaa !24
  %t398 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t394, i64 %t395)
  store ptr %t398, ptr %l194
  br label %bb90
bb90:
  %t399 = load ptr, ptr %l194, !tbaa !29
  %t401 = getelementptr %"compiler/load:Module", ptr %t399, i32 0, i32 1
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t402, 1
  %t405 = extractvalue { i64, ptr } %t402, 0
  %t406 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t404, i64 %t405)
  %t407 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = getelementptr %"compiler/typed:Local", ptr %l14, i32 0, i32 1
  %t417 = getelementptr %"compiler/source:Span", ptr %t416, i32 0, i32 0
  %t418 = load i32, ptr %t417, !tbaa !23
  %t420 = sext i32 %t418 to i64
  %t421 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t422 = load i32, ptr %l184, !tbaa !23
  %t423 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t426 = call %"compiler/session:FieldInfo" @compiler_2fsession_3aFieldInfo_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t421, i32 %t422, { i64, ptr } %t423, { i64, ptr } %t415, i64 %t420)
  store %"compiler/session:FieldInfo" %t426, ptr %l201
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t427 = load %"compiler/session:FieldInfo", ptr %l201
  %t428 = insertvalue { i32, %"compiler/session:FieldInfo" } zeroinitializer, %"compiler/session:FieldInfo" %t427, 1
  store { i32, %"compiler/session:FieldInfo" } %t428, ptr %rv
  br label %ret
bb92:
  br i1 true, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_dff094d230471566_615c91b3ab3b0902)
  unreachable
bb97:
  call void @__olang_scope_close(ptr %s4)
  br label %bb98
bb98:
  %t429 = load i64, ptr %l10, !tbaa !24
  %t431 = add i64 %t429, 1
  store i64 %t431, ptr %l10, !tbaa !24
  br label %bb33
bb99:
  %t433 = load i64, ptr %l7, !tbaa !24
  %t434 = load i64, ptr %l9, !tbaa !24
  %t437 = add i64 %t433, %t434
  store i64 %t437, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb100
bb100:
  br label %bb26
bb101:
  %t440 = insertvalue { i32, %"compiler/session:FieldInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:FieldInfo" } %t440, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/session:FieldInfo" }, ptr %rv
  ret { i32, %"compiler/session:FieldInfo" } %rr
}

define dso_local %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/typed:Local"
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l36 = alloca { i64, ptr }
  %l45 = alloca i64
  %l49 = alloca i64
  %l52 = alloca i64
  %l73 = alloca %"compiler/typed:Local"
  %l76 = alloca i1
  %l87 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l95 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_878a1a37f76dded1_df06407b9e0240ed)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 11
  store ptr %t14, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l4, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l27
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb6, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l26
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t25, ptr %l23, !tbaa !27
  br label %bb10
bb6:
  %t26 = load i32, ptr %l27, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_571c555105558829_b21161f963665c45)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb10:
  %t31 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb13:
  br label %bb14
bb14:
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t44, ptr %l36, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l8, !tbaa !29
  %t52 = load ptr, ptr %l8, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  %t59 = icmp ne i64 %t55, %a1
  br i1 %t59, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l9, !tbaa !24
  %t61 = load ptr, ptr %l8, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 7
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l45
  br label %bb18
bb18:
  %t66 = load i64, ptr %l45, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t73 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb24
bb21:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l11, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l11, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l52, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb23
bb23:
  %t93 = load i64, ptr %l52, !tbaa !24
  store i64 %t93, ptr %l49, !tbaa !24
  br label %bb24
bb24:
  %t94 = load i64, ptr %l49, !tbaa !24
  store i64 %t94, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t95 = load i64, ptr %l13, !tbaa !24
  %t96 = load i64, ptr %l12, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb27:
  br label %bb28
bb28:
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i64, ptr %l13, !tbaa !24
  %t105 = load i64, ptr %l11, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l14, !tbaa !24
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 7
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t115, i64 %t116)
  store %"compiler/typed:Local" %t119, ptr %l73
  br label %bb29
bb29:
  %t120 = load %"compiler/typed:Local", ptr %l73
  store %"compiler/typed:Local" %t120, ptr %l15
  %t121 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 0
  %t122 = load i32, ptr %t121, !tbaa !23
  %t124 = icmp ne i32 %t122, 0
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t126 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 1
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t134 = icmp eq i64 %t130, %a2
  store i1 %t134, ptr %l76, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb32
bb32:
  %t136 = load i1, ptr %l76, !tbaa !21
  br i1 %t136, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t137 = load ptr, ptr %l8, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Body", ptr %t137, i32 0, i32 0
  %t140 = load i32, ptr %t139, !tbaa !23
  %t142 = sext i32 %t140 to i64
  %t143 = load i64, ptr %l14, !tbaa !24
  %t145 = trunc i64 %t143 to i32
  %t149 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s7, i64 %t142, i32 %t145)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t149, ptr %l87
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t150 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l87
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t150, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l13, !tbaa !24
  br label %bb25
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l7, !tbaa !24
  br label %bb11
bb40:
  %t159 = load i64, ptr %l4, !tbaa !24
  %t160 = load i64, ptr %l6, !tbaa !24
  %t163 = add i64 %t159, %t160
  store i64 %t163, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  br label %bb4
bb42:
  %t165 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s0, i64 -1, i32 0)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t165, ptr %l95
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t166 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l95
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t166, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %rv
  ret %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/names:Entry"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l47 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l88 = alloca ptr
  %l95 = alloca i32
  %l96 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_ad4014c285adba33_5f0a50bbd6dd5777)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 3
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758)
  unreachable
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l31
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l31, !tbaa !29
  %t42 = getelementptr %"compiler/names:Table", ptr %t40, i32 0, i32 0
  store ptr %t42, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load ptr, ptr %l6, !tbaa !29
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t44, i64 %t45)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l38
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb10, label %ok.52
ok.52:
  store { i64, ptr } %t49, ptr %l37
  br label %bb9
bb9:
  %t53 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t53, ptr %l34, !tbaa !27
  br label %bb14
bb10:
  %t54 = load i32, ptr %l38, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  br i1 %t57, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_50adcb75aa4e31d0_b7ad99d78ce5014)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb14:
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t59, ptr %l8, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i64, ptr %l10, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb17:
  br label %bb18
bb18:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr %"compiler/names:Entry", ptr %t76, i64 %t73
  %t78 = load %"compiler/names:Entry", ptr %t77
  store %"compiler/names:Entry" %t78, ptr %l11
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t80, i32 %t82)
  store { i64, ptr } %t85, ptr %l52
  br label %bb19
bb19:
  %t86 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t86, ptr %l12, !tbaa !27
  %t89 = xor i1 %a3, true
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t91 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t93 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t91)
  store i1 %t93, ptr %l57
  br label %bb22
bb21:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb23
bb22:
  %t94 = load i1, ptr %l57, !tbaa !21
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l55, !tbaa !21
  br label %bb23
bb23:
  %t97 = load i1, ptr %l55, !tbaa !21
  br i1 %t97, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb25:
  br label %bb26
bb26:
  %t98 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t99 = load i32, ptr %t98
  %t101 = trunc i64 3 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb29, label %bb30
bb28:
  %t108 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t109 = load i32, ptr %t108
  %t111 = trunc i64 4 to i32
  %t112 = icmp eq i32 %t109, %t111
  br i1 %t112, label %bb52, label %bb53
bb29:
  call void @__olang_check_failed(ptr @olang_loc_6010ac475f88a9f2_430aff1aa96b7386)
  unreachable
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t125 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t118, i64 %t119, i32 %t121)
  store i64 %t125, ptr %l68
  br label %bb32
bb32:
  %t126 = load i64, ptr %l68, !tbaa !24
  store i64 %t126, ptr %l13, !tbaa !24
  %t127 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t127, 0
  br i1 %t129, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb39
bb34:
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  br i1 %t133, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_64c89934b5f1bf_a2a8dc486100a28b)
  unreachable
bb36:
  br label %bb37
bb37:
  %t135 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load i64, ptr %l13, !tbaa !24
  %t143 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t139, i64 %t140)
  store ptr %t143, ptr %l78
  br label %bb38
bb38:
  %t144 = load ptr, ptr %l78, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Func", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  %t151 = xor i1 %t149, true
  store i1 %t151, ptr %l71, !tbaa !21
  br label %bb39
bb39:
  %t153 = load i1, ptr %l71, !tbaa !21
  br i1 %t153, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t154, ptr %l83, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t155, ptr %l84, !tbaa !27
  %t156 = load i64, ptr @G_2ecompiler_2fsession_2eCompFunction, !tbaa !24
  store i64 %t156, ptr %l85, !tbaa !24
  %t157 = load ptr, ptr %l4, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  br i1 %t159, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_4a3b8d5757fbfa0_7b802f1ecd3d6b9c)
  unreachable
bb44:
  br label %bb45
bb45:
  %t161 = load ptr, ptr %l4, !tbaa !29
  store ptr %t161, ptr %l88, !tbaa !29
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_4a3b8d5757fbfa0_7b802f1ecd3d6b9c)
  unreachable
bb47:
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l13, !tbaa !24
  %t174 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t170, i64 %t171)
  store i32 %t174, ptr %l95
  br label %bb49
bb49:
  %t175 = load ptr, ptr %l88, !tbaa !29
  %t176 = load i32, ptr %l95, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t175, i32 %t176)
  store { i64, ptr } %t177, ptr %l96
  br label %bb50
bb50:
  %t178 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l83, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t187 = load i64, ptr %l85, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s5, ptr %t185, { i64, ptr } %t186, i64 %t187, { i64, ptr } %t184)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb67
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t191 = load i64, ptr @G_2ecompiler_2fsession_2eCompStruct, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s8, ptr %t189, { i64, ptr } %t190, i64 %t191, { i64, ptr } { i64 0, ptr @.d112 })
  br label %bb54
bb53:
  %t195 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t196 = load i32, ptr %t195
  %t198 = trunc i64 2 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb55, label %bb56
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb66
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l105, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t202, ptr %l106, !tbaa !27
  %t203 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 3
  %t204 = load i1, ptr %t203, !tbaa !21
  br i1 %t204, label %bb57, label %bb58
bb56:
  %t206 = getelementptr %"compiler/names:Entry", ptr %l11, i32 0, i32 2
  %t207 = load i32, ptr %t206
  %t209 = trunc i64 5 to i32
  %t210 = icmp eq i32 %t207, %t209
  br i1 %t210, label %bb61, label %bb62
bb57:
  %t212 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t212, ptr %l108, !tbaa !24
  br label %bb59
bb58:
  %t214 = load i64, ptr @G_2ecompiler_2fsession_2eCompConstant, !tbaa !24
  store i64 %t214, ptr %l108, !tbaa !24
  br label %bb59
bb59:
  %t216 = load ptr, ptr %l105, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t218 = load i64, ptr %l108, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s10, ptr %t216, { i64, ptr } %t217, i64 %t218, { i64, ptr } { i64 0, ptr @.d113 })
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t221 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s12, ptr %t219, { i64, ptr } %t220, i64 %t221, { i64, ptr } { i64 0, ptr @.d114 })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb68:
  %t225 = load i64, ptr %l10, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l10, !tbaa !24
  br label %bb15
bb69:
  %t229 = load i64, ptr %l7, !tbaa !24
  %t230 = load i64, ptr %l9, !tbaa !24
  %t233 = add i64 %t229, %t230
  store i64 %t233, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  br label %bb8
bb71:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l40 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/session:Analysis", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 5
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l40
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 4
  %t69 = load i64, ptr %t68, !tbaa !24
  %t73 = icmp eq i64 %t69, %a1
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t75, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/names:Entry"
  %l17 = alloca i64
  %l18 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %lp26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l45 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l65 = alloca %"compiler/names:Ref"
  %l71 = alloca %"compiler/names:Ref"
  %l79 = alloca i64
  %l86 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca %"compiler/names:Entry"
  %l96 = alloca { i64, ptr }
  %l110 = alloca %"compiler/source:Span"
  %l115 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l147 = alloca { i64, ptr }
  %l153 = alloca i1
  %l164 = alloca i64
  %l167 = alloca i1
  %l170 = alloca i1
  %l177 = alloca ptr
  %l196 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l212 = alloca i64
  %l216 = alloca i64
  %l219 = alloca i64
  %l243 = alloca i64
  %l252 = alloca ptr
  %l256 = alloca i1
  %l266 = alloca { i64, ptr }
  %l268 = alloca i1
  %l276 = alloca i1
  %l283 = alloca i1
  %l288 = alloca i1
  %l290 = alloca i64
  %l292 = alloca { i64, ptr }
  %l294 = alloca %"compiler/source:Span"
  %l303 = alloca i64
  %l305 = alloca i64
  %l306 = alloca { i64, ptr }
  %l310 = alloca %"compiler/session:finder"
  %l316 = alloca { i64, ptr }
  %l319 = alloca { i64, ptr }
  %l320 = alloca i32
  %l329 = alloca { i64, ptr }
  %l336 = alloca i1
  %l346 = alloca i1
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca { i64, [6 x i64] }
  %t171 = alloca { i64, [6 x i64] }, align 8
  %t187 = alloca { i64, [6 x i64] }, align 8
  %t231 = alloca { i64, [6 x i64] }, align 8
  %t260 = alloca { i64, [6 x i64] }, align 8
  %t404 = alloca { i64, [6 x i64] }, align 8
  %t443 = alloca { i64, [6 x i64] }, align 8
  %t655 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 5
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l45
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l45, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %t34, i64 %t35)
  store { i64, ptr } %t38, ptr %l50
  br label %bb5
bb5:
  %t39 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t39, ptr %l51, !tbaa !27
  %t40 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l53, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l55, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l56, !tbaa !24
  %t50 = load i64, ptr %l53, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = load i64, ptr %l53, !tbaa !24
  %t54 = load i64, ptr %l55, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb8:
  %t57 = load i64, ptr %l55, !tbaa !24
  %t58 = load i64, ptr %l56, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb10:
  %t61 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l53, !tbaa !24
  %t64 = load i64, ptr %l55, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t75, ptr %lp6
  %t77 = load ptr, ptr %lp6
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t85 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t78, i64 %t79, i32 %t81)
  store %"compiler/names:Ref" %t85, ptr %l65
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb12:
  %t86 = load %"compiler/names:Ref", ptr %l65
  store %"compiler/names:Ref" %t86, ptr %l7
  %t87 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87
  %t90 = trunc i64 0 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t100 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t93, i64 %t94, i32 %t96)
  store %"compiler/names:Ref" %t100, ptr %l71
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t101 = load %"compiler/names:Ref", ptr %l71
  store %"compiler/names:Ref" %t101, ptr %l7
  br label %bb16
bb16:
  %t102 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l8
  %t105 = load i32, ptr %l8
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t110 = load i32, ptr %l8
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t115 = load i32, ptr %l8
  %t117 = trunc i64 4 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb30
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l79, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f729b95fcb28e588_e9118b2581b5934c)
  unreachable
bb25:
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 3
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l86, !tbaa !29
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/names:Resolver", ptr %t137, i32 0, i32 1
  %t140 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t139, i64 %t141)
  store ptr %t144, ptr %l90
  br label %bb27
bb27:
  %t145 = load ptr, ptr %l90, !tbaa !29
  %t147 = getelementptr %"compiler/names:Table", ptr %t145, i32 0, i32 0
  %t148 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = call %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s3, ptr %t147, i64 %t149)
  store %"compiler/names:Entry" %t152, ptr %l94
  br label %bb28
bb28:
  %t153 = getelementptr %"compiler/names:Entry", ptr %l94, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t155 = load ptr, ptr %l86, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t155, i32 %t154)
  store { i64, ptr } %t157, ptr %l96
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t159, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 0
  store i64 1, ptr %t172
  %t173 = load i64, ptr %l79, !tbaa !24
  %t174 = insertvalue { i64, { i64, ptr } } undef, i64 %t173, 0
  %t176 = insertvalue { i64, { i64, ptr } } %t174, { i64, ptr } %t170, 1
  %t177 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 1
  store { i64, { i64, ptr } } %t176, ptr %t177
  %t178 = load { i64, [6 x i64] }, ptr %t171
  call void @__olang_scope_close(ptr %s3)
  store { i64, [6 x i64] } %t178, ptr %rv
  br label %ret
bb30:
  %t180 = load i32, ptr %l8
  %t182 = trunc i64 5 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t185 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [6 x i64] }, ptr %t187, i32 0, i32 0
  store i64 6, ptr %t188
  %t190 = insertvalue { i64 } undef, i64 %t186, 0
  %t191 = getelementptr { i64, [6 x i64] }, ptr %t187, i32 0, i32 1
  store { i64 } %t190, ptr %t191
  %t192 = load { i64, [6 x i64] }, ptr %t187
  store { i64, [6 x i64] } %t192, ptr %rv
  br label %ret
bb34:
  %t194 = load i32, ptr %l8
  %t196 = trunc i64 1 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  %t199 = load i32, ptr %l8
  %t201 = trunc i64 8 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t205 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t206 = load i64, ptr %t205, !tbaa !24
  %t209 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %t204, i64 %t206)
  store %"compiler/source:Span" %t209, ptr %l110
  br label %bb40
bb40:
  %t210 = load %"compiler/source:Span", ptr %l110
  store %"compiler/source:Span" %t210, ptr %l9
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l5, !tbaa !24
  %t213 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  %t216 = sext i32 %t214 to i64
  %t220 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t211, i64 %t212, i64 %t216)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t220, ptr %l115
  br label %bb41
bb41:
  %t221 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l115
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t221, ptr %l10
  %t222 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = icmp sge i64 %t223, 0
  br i1 %t225, label %bb42, label %bb43
bb42:
  %t227 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 1
  %t230 = load i32, ptr %t229, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [6 x i64] }, ptr %t231, i32 0, i32 0
  store i64 4, ptr %t232
  %t234 = insertvalue { i64, i32 } undef, i64 %t228, 0
  %t236 = insertvalue { i64, i32 } %t234, i32 %t230, 1
  %t237 = getelementptr { i64, [6 x i64] }, ptr %t231, i32 0, i32 1
  store { i64, i32 } %t236, ptr %t237
  %t238 = load { i64, [6 x i64] }, ptr %t231
  store { i64, [6 x i64] } %t238, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t240 = load i64, ptr %l1, !tbaa !24
  %t241 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = sext i32 %t242 to i64
  %t245 = load ptr, ptr %lp6
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 1
  %t249 = extractvalue { i64, ptr } %t246, 0
  %t250 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t248, i64 %t249)
  %t251 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [6 x i64] }, ptr %t260, i32 0, i32 0
  store i64 5, ptr %t261
  %t263 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } undef, i64 %t240, 0
  %t265 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t263, i64 %t244, 1
  %t266 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t265, { i64, ptr } { i64 0, ptr @.d115 }, 2
  %t268 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t266, { i64, ptr } %t259, 3
  %t269 = getelementptr { i64, [6 x i64] }, ptr %t260, i32 0, i32 1
  store { i64, i64, { i64, ptr }, { i64, ptr } } %t268, ptr %t269
  %t270 = load { i64, [6 x i64] }, ptr %t260
  store { i64, [6 x i64] } %t270, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2)
  unreachable
bb50:
  %t272 = load ptr, ptr %l4, !tbaa !29
  %t274 = getelementptr %"compiler/names:Resolver", ptr %t272, i32 0, i32 1
  %t275 = load i64, ptr %l1, !tbaa !24
  %t278 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t274, i64 %t275)
  store ptr %t278, ptr %l131
  br label %bb51
bb51:
  %t279 = load ptr, ptr %l131, !tbaa !29
  %t281 = getelementptr %"compiler/names:Table", ptr %t279, i32 0, i32 0
  store ptr %t281, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t283 = load ptr, ptr %l11, !tbaa !29
  %t284 = load i64, ptr %l12, !tbaa !24
  %t287 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t283, i64 %t284)
  %t288 = extractvalue { i32, { i64, ptr } } %t287, 1
  %t289 = extractvalue { i32, { i64, ptr } } %t287, 0
  store i32 %t289, ptr %l138
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb54, label %ok.291
ok.291:
  store { i64, ptr } %t288, ptr %l137
  br label %bb53
bb53:
  %t292 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t292, ptr %l134, !tbaa !27
  br label %bb58
bb54:
  %t293 = load i32, ptr %l138, !tbaa !23
  %t294 = ashr i32 %t293, 16
  %t296 = icmp eq i32 %t294, 1
  br i1 %t296, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_82a1ed1229cd6d99_a8840ba8d5b2a1b5)
  unreachable
bb57:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb58:
  %t298 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t298, ptr %l13, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t303 = load i64, ptr %l15, !tbaa !24
  %t304 = load i64, ptr %l14, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %bb87
bb61:
  br label %bb62
bb62:
  %t311 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t311, ptr %l147, !tbaa !27
  %t312 = load i64, ptr %l15, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr %"compiler/names:Entry", ptr %t315, i64 %t312
  %t317 = load %"compiler/names:Entry", ptr %t316
  store %"compiler/names:Entry" %t317, ptr %l16
  %t319 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 1
  %t320 = getelementptr %"compiler/source:Span", ptr %t319, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  %t322 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t323 = load i32, ptr %t322, !tbaa !23
  %t326 = icmp eq i32 %t321, %t323
  br i1 %t326, label %bb63, label %bb64
bb63:
  %t328 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t329 = load i32, ptr %t328
  %t331 = trunc i64 5 to i32
  %t332 = icmp eq i32 %t329, %t331
  %t334 = xor i1 %t332, true
  store i1 %t334, ptr %l153, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb65
bb65:
  %t336 = load i1, ptr %l153, !tbaa !21
  br i1 %t336, label %bb66, label %bb67
bb66:
  %t337 = load ptr, ptr %l3, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  br i1 %t339, label %bb68, label %bb69
bb67:
  br label %bb85
bb68:
  call void @__olang_check_failed(ptr @olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d)
  unreachable
bb69:
  br label %bb70
bb70:
  %t341 = load ptr, ptr %l3, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  %t346 = load i64, ptr %l1, !tbaa !24
  %t347 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 0
  %t348 = load i32, ptr %t347, !tbaa !23
  %t352 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t345, i64 %t346, i32 %t348)
  store i64 %t352, ptr %l164
  br label %bb71
bb71:
  %t353 = load i64, ptr %l164, !tbaa !24
  store i64 %t353, ptr %l17, !tbaa !24
  %t354 = getelementptr %"compiler/names:Entry", ptr %l16, i32 0, i32 2
  %t355 = load i32, ptr %t354
  %t357 = trunc i64 3 to i32
  %t358 = icmp eq i32 %t355, %t357
  br i1 %t358, label %bb72, label %bb73
bb72:
  %t360 = load i64, ptr %l17, !tbaa !24
  %t362 = icmp sge i64 %t360, 0
  store i1 %t362, ptr %l167, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t364 = load i1, ptr %l167, !tbaa !21
  br i1 %t364, label %bb75, label %bb76
bb75:
  %t365 = load ptr, ptr %l3, !tbaa !29
  %t367 = icmp eq ptr %t365, null
  br i1 %t367, label %bb77, label %bb78
bb76:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb81
bb77:
  call void @__olang_check_failed(ptr @olang_loc_f548539da9e2e40c_6a57728f427e36c8)
  unreachable
bb78:
  br label %bb79
bb79:
  %t369 = load ptr, ptr %l3, !tbaa !29
  %t372 = getelementptr %"compiler/check:Checker", ptr %t369, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t374 = load i64, ptr %l17, !tbaa !24
  %t377 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t373, i64 %t374)
  store ptr %t377, ptr %l177
  br label %bb80
bb80:
  %t378 = load ptr, ptr %l177, !tbaa !29
  %t380 = getelementptr %"compiler/ast:Func", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  %t385 = xor i1 %t383, true
  store i1 %t385, ptr %l170, !tbaa !21
  br label %bb81
bb81:
  %t387 = load i1, ptr %l170, !tbaa !21
  br i1 %t387, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  br label %bb89
bb83:
  br label %bb84
bb84:
  %t388 = load i64, ptr %l1, !tbaa !24
  %t389 = load ptr, ptr %lp6
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = extractvalue { i64, ptr } %t390, 0
  %t394 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t392, i64 %t393)
  %t395 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [6 x i64] }, ptr %t404, i32 0, i32 0
  store i64 1, ptr %t405
  %t407 = insertvalue { i64, { i64, ptr } } undef, i64 %t388, 0
  %t409 = insertvalue { i64, { i64, ptr } } %t407, { i64, ptr } %t403, 1
  %t410 = getelementptr { i64, [6 x i64] }, ptr %t404, i32 0, i32 1
  store { i64, { i64, ptr } } %t409, ptr %t410
  %t411 = load { i64, [6 x i64] }, ptr %t404
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  store { i64, [6 x i64] } %t411, ptr %rv
  br label %ret
bb85:
  call void @__olang_scope_close(ptr %s12)
  br label %bb86
bb86:
  %t413 = load i64, ptr %l15, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l15, !tbaa !24
  br label %bb59
bb87:
  %t417 = load i64, ptr %l12, !tbaa !24
  %t418 = load i64, ptr %l14, !tbaa !24
  %t421 = add i64 %t417, %t418
  store i64 %t421, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb88
bb88:
  br label %bb52
bb89:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i64, ptr %l5, !tbaa !24
  %t425 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t426 = load i32, ptr %t425, !tbaa !23
  %t428 = sext i32 %t426 to i64
  %t432 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t423, i64 %t424, i64 %t428)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t432, ptr %l196
  br label %bb90
bb90:
  %t433 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l196
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t433, ptr %l18
  %t434 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l18, i32 0, i32 0
  %t435 = load i64, ptr %t434, !tbaa !24
  %t437 = icmp sge i64 %t435, 0
  br i1 %t437, label %bb91, label %bb92
bb91:
  %t439 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l18, i32 0, i32 0
  %t440 = load i64, ptr %t439, !tbaa !24
  %t441 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l18, i32 0, i32 1
  %t442 = load i32, ptr %t441, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t443
  %t444 = getelementptr { i64, [6 x i64] }, ptr %t443, i32 0, i32 0
  store i64 4, ptr %t444
  %t446 = insertvalue { i64, i32 } undef, i64 %t440, 0
  %t448 = insertvalue { i64, i32 } %t446, i32 %t442, 1
  %t449 = getelementptr { i64, [6 x i64] }, ptr %t443, i32 0, i32 1
  store { i64, i32 } %t448, ptr %t449
  %t450 = load { i64, [6 x i64] }, ptr %t443
  store { i64, [6 x i64] } %t450, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t452 = load ptr, ptr %l3, !tbaa !29
  %t454 = icmp eq ptr %t452, null
  br i1 %t454, label %bb94, label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7)
  unreachable
bb95:
  br label %bb96
bb96:
  %t456 = load ptr, ptr %l3, !tbaa !29
  %t459 = getelementptr %"compiler/check:Checker", ptr %t456, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t460)
  br label %bb97
bb97:
  store i64 0, ptr %l19, !tbaa !24
  %t462 = load ptr, ptr %l3, !tbaa !29
  %t464 = icmp eq ptr %t462, null
  br i1 %t464, label %bb98, label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_be0af37330f35afe_68a0a057b8d4cca2)
  unreachable
bb99:
  br label %bb100
bb100:
  %t466 = load ptr, ptr %l3, !tbaa !29
  %t469 = getelementptr %"compiler/check:Checker", ptr %t466, i32 0, i32 1
  %t470 = load ptr, ptr %t469, !tbaa !29
  %t472 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t470)
  store i64 %t472, ptr %l212
  br label %bb101
bb101:
  %t473 = load i64, ptr %l212, !tbaa !24
  store i64 %t473, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t474 = load i64, ptr %l20, !tbaa !24
  %t475 = load i64, ptr %l19, !tbaa !24
  %t478 = icmp sgt i64 %t474, %t475
  br i1 %t478, label %bb102, label %bb103
bb102:
  %t480 = load i64, ptr %l21, !tbaa !24
  %t482 = icmp sgt i64 %t480, 0
  br i1 %t482, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb107
bb104:
  %t484 = load i64, ptr %l20, !tbaa !24
  %t485 = load i64, ptr %l19, !tbaa !24
  %t488 = sub i64 %t484, %t485
  %t489 = load i64, ptr %l21, !tbaa !24
  %t492 = add i64 %t488, %t489
  %t494 = sub i64 %t492, 1
  %t495 = load i64, ptr %l21, !tbaa !24
  %t498 = sdiv i64 %t494, %t495
  store i64 %t498, ptr %l219, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb106
bb106:
  %t500 = load i64, ptr %l219, !tbaa !24
  store i64 %t500, ptr %l216, !tbaa !24
  br label %bb107
bb107:
  %t501 = load i64, ptr %l216, !tbaa !24
  store i64 %t501, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb108
bb108:
  store %olang.scope zeroinitializer, ptr %s19
  %t502 = load i64, ptr %l23, !tbaa !24
  %t503 = load i64, ptr %l22, !tbaa !24
  %t506 = icmp slt i64 %t502, %t503
  %t508 = xor i1 %t506, true
  br i1 %t508, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s19)
  br label %bb148
bb110:
  br label %bb111
bb111:
  %t510 = load i64, ptr %l19, !tbaa !24
  %t511 = load i64, ptr %l23, !tbaa !24
  %t512 = load i64, ptr %l21, !tbaa !24
  %t515 = mul i64 %t511, %t512
  %t518 = add i64 %t510, %t515
  store i64 %t518, ptr %l24, !tbaa !24
  %t520 = load ptr, ptr %l3, !tbaa !29
  %t522 = icmp eq ptr %t520, null
  br i1 %t522, label %bb112, label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_7be9b74a0a4337a5_af051c2067e0d709)
  unreachable
bb113:
  br label %bb114
bb114:
  %t524 = load ptr, ptr %l3, !tbaa !29
  %t527 = getelementptr %"compiler/check:Checker", ptr %t524, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = load i64, ptr %l24, !tbaa !24
  %t532 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t528, i64 %t529)
  store i64 %t532, ptr %l243
  br label %bb115
bb115:
  %t533 = load i64, ptr %l1, !tbaa !24
  %t534 = load i64, ptr %l243, !tbaa !24
  %t536 = icmp ne i64 %t534, %t533
  br i1 %t536, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s19)
  br label %bb147
bb117:
  br label %bb118
bb118:
  %t538 = load ptr, ptr %l3, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  br i1 %t540, label %bb119, label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_a0e32d5552598bb5_d1b40570995ef0d1)
  unreachable
bb120:
  br label %bb121
bb121:
  %t542 = load ptr, ptr %l3, !tbaa !29
  %t545 = getelementptr %"compiler/check:Checker", ptr %t542, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t547 = load i64, ptr %l24, !tbaa !24
  %t550 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t546, i64 %t547)
  store ptr %t550, ptr %l252
  br label %bb122
bb122:
  %t551 = load ptr, ptr %l252, !tbaa !29
  store ptr %t551, ptr %l25, !tbaa !29
  %t552 = load ptr, ptr %l25, !tbaa !29
  %t554 = getelementptr %"compiler/ast:Func", ptr %t552, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !29
  %t557 = icmp eq ptr %t555, null
  br i1 %t557, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb130
bb124:
  %t559 = load ptr, ptr %l3, !tbaa !29
  %t561 = icmp eq ptr %t559, null
  br i1 %t561, label %bb125, label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_90517919cad2500e_b5e04c9858b7f7ca)
  unreachable
bb126:
  br label %bb127
bb127:
  %t563 = load ptr, ptr %l3, !tbaa !29
  %t566 = getelementptr %"compiler/check:Checker", ptr %t563, i32 0, i32 1
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t569 = getelementptr %"compiler/generic:Program", ptr %t567, i32 0, i32 0
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t572 = getelementptr %"compiler/load:Loader", ptr %t570, i32 0, i32 3
  %t573 = load ptr, ptr %t572, !tbaa !29
  %t574 = load ptr, ptr %l25, !tbaa !29
  %t576 = getelementptr %"compiler/ast:Func", ptr %t574, i32 0, i32 2
  %t577 = load i32, ptr %t576, !tbaa !23
  %t580 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t573, i32 %t577)
  store { i64, ptr } %t580, ptr %l266
  br label %bb128
bb128:
  %t581 = load ptr, ptr %lp6
  %t582 = load { i64, ptr }, ptr %t581, !tbaa !27
  %t583 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t585 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t583, { i64, ptr } %t582)
  store i1 %t585, ptr %l268
  br label %bb129
bb129:
  %t586 = load i1, ptr %l268, !tbaa !21
  %t587 = xor i1 %t586, true
  store i1 %t587, ptr %l256, !tbaa !21
  br label %bb130
bb130:
  %t589 = load i1, ptr %l256, !tbaa !21
  br i1 %t589, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s19)
  br label %bb147
bb132:
  br label %bb133
bb133:
  %t590 = load ptr, ptr %l25, !tbaa !29
  %t592 = getelementptr %"compiler/ast:Func", ptr %t590, i32 0, i32 0
  %t593 = getelementptr %"compiler/source:Span", ptr %t592, i32 0, i32 0
  %t594 = load i32, ptr %t593, !tbaa !23
  %t596 = sext i32 %t594 to i64
  %t597 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t598 = load i32, ptr %t597, !tbaa !23
  %t600 = sext i32 %t598 to i64
  %t603 = icmp sle i64 %t596, %t600
  br i1 %t603, label %bb134, label %bb135
bb134:
  %t605 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t606 = load i32, ptr %t605, !tbaa !23
  %t608 = sext i32 %t606 to i64
  %t609 = load ptr, ptr %l25, !tbaa !29
  %t611 = getelementptr %"compiler/ast:Func", ptr %t609, i32 0, i32 0
  %t612 = getelementptr %"compiler/source:Span", ptr %t611, i32 0, i32 1
  %t613 = load i32, ptr %t612, !tbaa !23
  %t615 = sext i32 %t613 to i64
  %t618 = icmp slt i64 %t608, %t615
  store i1 %t618, ptr %l276, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb136
bb136:
  %t620 = load i1, ptr %l276, !tbaa !21
  br i1 %t620, label %bb137, label %bb138
bb137:
  %t621 = load ptr, ptr %l25, !tbaa !29
  %t623 = getelementptr %"compiler/ast:Func", ptr %t621, i32 0, i32 4
  %t624 = load { i64, ptr }, ptr %t623, !tbaa !27
  %t626 = extractvalue { i64, ptr } %t624, 0
  %t628 = icmp eq i64 %t626, 0
  br i1 %t628, label %bb139, label %bb140
bb138:
  store i1 false, ptr %l283, !tbaa !21
  br label %bb143
bb139:
  store i1 true, ptr %l288, !tbaa !21
  br label %bb142
bb140:
  %t630 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t631 = load i32, ptr %t630, !tbaa !23
  %t633 = sext i32 %t631 to i64
  store i64 %t633, ptr %l290, !tbaa !24
  %t634 = load ptr, ptr %l25, !tbaa !29
  %t636 = getelementptr %"compiler/ast:Func", ptr %t634, i32 0, i32 4
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  store { i64, ptr } %t637, ptr %l292, !tbaa !27
  %t638 = getelementptr { i64, ptr }, ptr %l292, i32 0, i32 1
  %t639 = load ptr, ptr %t638, !tbaa !27
  %t640 = getelementptr ptr, ptr %t639, i64 0
  %t641 = load ptr, ptr %t640, !tbaa !39
  %t643 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %t641)
  store %"compiler/source:Span" %t643, ptr %l294
  br label %bb141
bb141:
  %t644 = getelementptr %"compiler/source:Span", ptr %l294, i32 0, i32 0
  %t645 = load i32, ptr %t644, !tbaa !23
  %t647 = sext i32 %t645 to i64
  %t648 = load i64, ptr %l290, !tbaa !24
  %t650 = icmp slt i64 %t648, %t647
  store i1 %t650, ptr %l288, !tbaa !21
  br label %bb142
bb142:
  %t652 = load i1, ptr %l288, !tbaa !21
  store i1 %t652, ptr %l283, !tbaa !21
  br label %bb143
bb143:
  %t653 = load i1, ptr %l283, !tbaa !21
  br i1 %t653, label %bb144, label %bb145
bb144:
  %t654 = load i64, ptr %l24, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t655
  %t656 = getelementptr { i64, [6 x i64] }, ptr %t655, i32 0, i32 0
  store i64 2, ptr %t656
  %t658 = insertvalue { i64 } undef, i64 %t654, 0
  %t659 = getelementptr { i64, [6 x i64] }, ptr %t655, i32 0, i32 1
  store { i64 } %t658, ptr %t659
  %t660 = load { i64, [6 x i64] }, ptr %t655
  call void @__olang_scope_close(ptr %s19)
  store { i64, [6 x i64] } %t660, ptr %rv
  br label %ret
bb145:
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s19)
  br label %bb147
bb147:
  %t662 = load i64, ptr %l23, !tbaa !24
  %t664 = add i64 %t662, 1
  store i64 %t664, ptr %l23, !tbaa !24
  br label %bb108
bb148:
  %t666 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t667 = load i32, ptr %t666, !tbaa !23
  %t669 = sext i32 %t667 to i64
  store i64 %t669, ptr %l303, !tbaa !24
  %t670 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t671 = load i32, ptr %t670, !tbaa !23
  %t673 = sext i32 %t671 to i64
  store i64 %t673, ptr %l305, !tbaa !24
  %t674 = load ptr, ptr %lp6
  %t675 = load { i64, ptr }, ptr %t674, !tbaa !27
  store { i64, ptr } %t675, ptr %l306, !tbaa !27
  %t676 = load ptr, ptr %l3, !tbaa !29
  %t678 = icmp eq ptr %t676, null
  br i1 %t678, label %bb149, label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_ce3fd8c720c212bf_60e6469ff90569cb)
  unreachable
bb150:
  br label %bb151
bb151:
  %t680 = load ptr, ptr %l3, !tbaa !29
  %t681 = load i64, ptr %l303, !tbaa !24
  %t682 = load i64, ptr %l305, !tbaa !24
  %t683 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t685 = call %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v1, ptr %v0, ptr %v1, i64 %t681, i64 %t682, { i64, ptr } %t683, ptr %t680)
  store %"compiler/session:finder" %t685, ptr %l310
  br label %bb152
bb152:
  %t686 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store ptr %t686, ptr %lp26
  %t687 = load %"compiler/session:finder", ptr %l310
  %t688 = load ptr, ptr %lp26
  store %"compiler/session:finder" %t687, ptr %t688
  %t689 = load ptr, ptr %l3, !tbaa !29
  %t691 = icmp eq ptr %t689, null
  br i1 %t691, label %bb153, label %bb154
bb153:
  call void @__olang_check_failed(ptr @olang_loc_d27ec903618be0a0_36ec6c4f051caedc)
  unreachable
bb154:
  br label %bb155
bb155:
  %t693 = load ptr, ptr %l3, !tbaa !29
  %t696 = getelementptr %"compiler/check:Checker", ptr %t693, i32 0, i32 11
  store ptr %t696, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb156
bb156:
  store %olang.scope zeroinitializer, ptr %s25
  %t698 = load ptr, ptr %l27, !tbaa !29
  %t699 = load i64, ptr %l28, !tbaa !24
  %t702 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t698, i64 %t699)
  %t703 = extractvalue { i32, { i64, ptr } } %t702, 1
  %t704 = extractvalue { i32, { i64, ptr } } %t702, 0
  store i32 %t704, ptr %l320
  %t705 = icmp ne i32 %t704, 0
  br i1 %t705, label %bb158, label %ok.706
ok.706:
  store { i64, ptr } %t703, ptr %l319
  br label %bb157
bb157:
  %t707 = load { i64, ptr }, ptr %l319, !tbaa !27
  store { i64, ptr } %t707, ptr %l316, !tbaa !27
  br label %bb162
bb158:
  %t708 = load i32, ptr %l320, !tbaa !23
  %t709 = ashr i32 %t708, 16
  %t711 = icmp eq i32 %t709, 1
  br i1 %t711, label %bb159, label %bb160
bb159:
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_a0487cd0bec06cd0_843576141ef24254)
  unreachable
bb161:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s25)
  br label %bb183
bb162:
  %t713 = load { i64, ptr }, ptr %l316, !tbaa !27
  store { i64, ptr } %t713, ptr %l29, !tbaa !27
  %t714 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t714, 0
  store i64 %t716, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s26
  %t718 = load i64, ptr %l31, !tbaa !24
  %t719 = load i64, ptr %l30, !tbaa !24
  %t722 = icmp slt i64 %t718, %t719
  %t724 = xor i1 %t722, true
  br i1 %t724, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s26)
  br label %bb181
bb165:
  br label %bb166
bb166:
  %t726 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t726, ptr %l329, !tbaa !27
  %t727 = load i64, ptr %l31, !tbaa !24
  %t729 = getelementptr { i64, ptr }, ptr %l329, i32 0, i32 1
  %t730 = load ptr, ptr %t729, !tbaa !27
  %t731 = getelementptr ptr, ptr %t730, i64 %t727
  %t732 = load ptr, ptr %t731, !tbaa !39
  store ptr %t732, ptr %l32, !tbaa !29
  %t734 = load ptr, ptr %l32, !tbaa !29
  %t736 = getelementptr %"compiler/typed:Body", ptr %t734, i32 0, i32 3
  %t737 = load i64, ptr %t736, !tbaa !24
  %t738 = load i64, ptr %l5, !tbaa !24
  %t741 = icmp ne i64 %t737, %t738
  br i1 %t741, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb169
bb168:
  %t743 = load ptr, ptr %l32, !tbaa !29
  %t745 = getelementptr %"compiler/typed:Body", ptr %t743, i32 0, i32 11
  %t746 = load ptr, ptr %t745, !tbaa !29
  %t748 = icmp eq ptr %t746, null
  store i1 %t748, ptr %l336, !tbaa !21
  br label %bb169
bb169:
  %t750 = load i1, ptr %l336, !tbaa !21
  br i1 %t750, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s26)
  br label %bb180
bb171:
  br label %bb172
bb172:
  %t751 = load ptr, ptr %l32, !tbaa !29
  %t753 = getelementptr %"compiler/typed:Body", ptr %t751, i32 0, i32 4
  %t754 = getelementptr %"compiler/source:Span", ptr %t753, i32 0, i32 1
  %t755 = load i32, ptr %t754, !tbaa !23
  %t757 = sext i32 %t755 to i64
  %t758 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t759 = load i32, ptr %t758, !tbaa !23
  %t761 = sext i32 %t759 to i64
  %t764 = icmp slt i64 %t757, %t761
  br i1 %t764, label %bb173, label %bb174
bb173:
  store i1 true, ptr %l346, !tbaa !21
  br label %bb175
bb174:
  %t766 = load ptr, ptr %l32, !tbaa !29
  %t768 = getelementptr %"compiler/typed:Body", ptr %t766, i32 0, i32 4
  %t769 = getelementptr %"compiler/source:Span", ptr %t768, i32 0, i32 0
  %t770 = load i32, ptr %t769, !tbaa !23
  %t772 = sext i32 %t770 to i64
  %t773 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t774 = load i32, ptr %t773, !tbaa !23
  %t776 = sext i32 %t774 to i64
  %t779 = icmp sgt i64 %t772, %t776
  store i1 %t779, ptr %l346, !tbaa !21
  br label %bb175
bb175:
  %t781 = load i1, ptr %l346, !tbaa !21
  br i1 %t781, label %bb176, label %bb177
bb176:
  call void @__olang_scope_close(ptr %s26)
  br label %bb180
bb177:
  br label %bb178
bb178:
  %t782 = load ptr, ptr %l32, !tbaa !29
  %t784 = getelementptr %"compiler/typed:Body", ptr %t782, i32 0, i32 0
  %t785 = load i32, ptr %t784, !tbaa !23
  %t787 = sext i32 %t785 to i64
  %t789 = load ptr, ptr %lp26
  %t790 = getelementptr %"compiler/session:finder", ptr %t789, i32 0, i32 4
  store i64 %t787, ptr %t790, !tbaa !24
  %t791 = load ptr, ptr %lp26
  %t792 = load ptr, ptr %l32, !tbaa !29
  %t794 = getelementptr %"compiler/typed:Body", ptr %t792, i32 0, i32 11
  %t795 = load ptr, ptr %t794, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v1, ptr %v0, ptr %t791, ptr %t795)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s26)
  br label %bb180
bb180:
  %t798 = load i64, ptr %l31, !tbaa !24
  %t800 = add i64 %t798, 1
  store i64 %t800, ptr %l31, !tbaa !24
  br label %bb163
bb181:
  %t802 = load i64, ptr %l28, !tbaa !24
  %t803 = load i64, ptr %l30, !tbaa !24
  %t806 = add i64 %t802, %t803
  store i64 %t806, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb182
bb182:
  br label %bb156
bb183:
  %t808 = load ptr, ptr %lp26
  %t809 = getelementptr %"compiler/session:finder", ptr %t808, i32 0, i32 5
  %t810 = load { i64, [6 x i64] }, ptr %t809
  store { i64, [6 x i64] } %t810, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [6 x i64] }, ptr %rv
  ret { i64, [6 x i64] } %rr
}

define dso_local i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/session:typeFinder"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Local"
  %l26 = alloca %"compiler/session:typeFinder"
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l47 = alloca { i64, ptr }
  %l54 = alloca i1
  %l74 = alloca { i64, ptr }
  %l77 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l112 = alloca { i64, ptr }
  %l119 = alloca i1
  %l125 = alloca i1
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i32
  %l146 = alloca { i64, ptr }
  %l151 = alloca i1
  %l162 = alloca { i64, ptr }
  %l164 = alloca i1
  %l165 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = call %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %s0, i64 %t1)
  store %"compiler/session:typeFinder" %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load %"compiler/session:typeFinder", ptr %l26
  store %"compiler/session:typeFinder" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:Analysis", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cf04846f3952f731_2a54d968229bc665)
  unreachable
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/session:Analysis", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 11
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t20, i64 %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l38
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb7, label %ok.28
ok.28:
  store { i64, ptr } %t25, ptr %l37
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t29, ptr %l34, !tbaa !27
  br label %bb11
bb7:
  %t30 = load i32, ptr %l38, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_5cb89564a64a7b89_ef4d611fae5a664d)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb11:
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t35, ptr %l6, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb14:
  br label %bb15
bb15:
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t48, ptr %l47, !tbaa !27
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr ptr, ptr %t52, i64 %t49
  %t54 = load ptr, ptr %t53, !tbaa !39
  store ptr %t54, ptr %l9, !tbaa !29
  %t56 = load ptr, ptr %l9, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 3
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr %l1, !tbaa !24
  %t63 = icmp ne i64 %t59, %t60
  br i1 %t63, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb18
bb17:
  %t65 = load ptr, ptr %l9, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 11
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  store i1 %t70, ptr %l54, !tbaa !21
  br label %bb18
bb18:
  %t72 = load i1, ptr %l54, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l9, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 11
  %t76 = load ptr, ptr %t75, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %s0, ptr %v0, ptr %l3, ptr %t76)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l8, !tbaa !24
  br label %bb12
bb24:
  %t83 = load i64, ptr %l5, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t83, %t84
  store i64 %t87, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  br label %bb5
bb26:
  %t89 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp ne i32 %t90, %t91
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t96 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t97, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/session:Analysis", ptr %t99, i32 0, i32 0
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = getelementptr %"compiler/load:Loader", ptr %t102, i32 0, i32 4
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %t105, i64 %t106)
  store { i64, ptr } %t109, ptr %l74
  br label %bb30
bb30:
  %t110 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t110, ptr %l10, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t112 = load i64, ptr %l2, !tbaa !24
  %t115 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t111, i64 %t112)
  store %"compiler/source:Span" %t115, ptr %l77
  br label %bb31
bb31:
  %t116 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t116, ptr %l11
  %t117 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = icmp eq i32 %t118, %t120
  br i1 %t123, label %bb32, label %bb33
bb32:
  %t125 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t125, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t127 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t127, ptr %l82, !tbaa !27
  %t128 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t129 = load i32, ptr %t128, !tbaa !23
  %t131 = sext i32 %t129 to i64
  store i64 %t131, ptr %l84, !tbaa !24
  %t132 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t133 = load i32, ptr %t132, !tbaa !23
  %t135 = sext i32 %t133 to i64
  store i64 %t135, ptr %l86, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l87, !tbaa !24
  %t138 = load i64, ptr %l84, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t141 = load i64, ptr %l84, !tbaa !24
  %t142 = load i64, ptr %l86, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ad9e8a7a2a8b2da1_3a700b1f4bcc2495)
  unreachable
bb37:
  %t145 = load i64, ptr %l86, !tbaa !24
  %t146 = load i64, ptr %l87, !tbaa !24
  %t147 = icmp sle i64 %t145, %t146
  br i1 %t147, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_ad9e8a7a2a8b2da1_3a700b1f4bcc2495)
  unreachable
bb39:
  %t149 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = load i64, ptr %l84, !tbaa !24
  %t152 = load i64, ptr %l86, !tbaa !24
  %t153 = getelementptr i8, ptr %t150, i64 %t151
  %t154 = sub i64 %t152, %t151
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  store { i64, ptr } %t156, ptr %l12, !tbaa !27
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/session:Analysis", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_ad9e8a7a2a8b2da1_3a700b1f4bcc2495)
  unreachable
bb41:
  call void @__olang_check_failed(ptr @olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10)
  unreachable
bb42:
  br label %bb43
bb43:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/session:Analysis", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 11
  store ptr %t171, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t173 = load ptr, ptr %l13, !tbaa !29
  %t174 = load i64, ptr %l14, !tbaa !24
  %t177 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t173, i64 %t174)
  %t178 = extractvalue { i32, { i64, ptr } } %t177, 1
  %t179 = extractvalue { i32, { i64, ptr } } %t177, 0
  store i32 %t179, ptr %l103
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb46, label %ok.181
ok.181:
  store { i64, ptr } %t178, ptr %l102
  br label %bb45
bb45:
  %t182 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t182, ptr %l99, !tbaa !27
  br label %bb50
bb46:
  %t183 = load i32, ptr %l103, !tbaa !23
  %t184 = ashr i32 %t183, 16
  %t186 = icmp eq i32 %t184, 1
  br i1 %t186, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_12a97d69ea90e0b4_1cefa701b7ed5940)
  unreachable
bb49:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb96
bb50:
  %t188 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t188, ptr %l15, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t193 = load i64, ptr %l17, !tbaa !24
  %t194 = load i64, ptr %l16, !tbaa !24
  %t197 = icmp slt i64 %t193, %t194
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb94
bb53:
  br label %bb54
bb54:
  %t201 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t201, ptr %l112, !tbaa !27
  %t202 = load i64, ptr %l17, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr ptr, ptr %t205, i64 %t202
  %t207 = load ptr, ptr %t206, !tbaa !39
  store ptr %t207, ptr %l18, !tbaa !29
  %t209 = load ptr, ptr %l18, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 3
  %t212 = load i64, ptr %t211, !tbaa !24
  %t213 = load i64, ptr %l1, !tbaa !24
  %t216 = icmp ne i64 %t212, %t213
  br i1 %t216, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb57
bb56:
  %t218 = load ptr, ptr %l18, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Body", ptr %t218, i32 0, i32 4
  %t221 = getelementptr %"compiler/source:Span", ptr %t220, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t224 = sext i32 %t222 to i64
  %t225 = load i64, ptr %l2, !tbaa !24
  %t228 = icmp sgt i64 %t224, %t225
  store i1 %t228, ptr %l119, !tbaa !21
  br label %bb57
bb57:
  %t230 = load i1, ptr %l119, !tbaa !21
  br i1 %t230, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb60
bb59:
  %t231 = load i64, ptr %l2, !tbaa !24
  %t232 = load ptr, ptr %l18, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Body", ptr %t232, i32 0, i32 4
  %t235 = getelementptr %"compiler/source:Span", ptr %t234, i32 0, i32 1
  %t236 = load i32, ptr %t235, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t241 = icmp sgt i64 %t231, %t238
  store i1 %t241, ptr %l125, !tbaa !21
  br label %bb60
bb60:
  %t243 = load i1, ptr %l125, !tbaa !21
  br i1 %t243, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb62:
  br label %bb63
bb63:
  %t244 = load ptr, ptr %l18, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Body", ptr %t244, i32 0, i32 7
  store ptr %t246, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t248 = load ptr, ptr %l19, !tbaa !29
  %t249 = load i64, ptr %l20, !tbaa !24
  %t252 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t248, i64 %t249)
  %t253 = extractvalue { i32, { i64, ptr } } %t252, 1
  %t254 = extractvalue { i32, { i64, ptr } } %t252, 0
  store i32 %t254, ptr %l137
  %t255 = icmp ne i32 %t254, 0
  br i1 %t255, label %bb66, label %ok.256
ok.256:
  store { i64, ptr } %t253, ptr %l136
  br label %bb65
bb65:
  %t257 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t257, ptr %l133, !tbaa !27
  br label %bb70
bb66:
  %t258 = load i32, ptr %l137, !tbaa !23
  %t259 = ashr i32 %t258, 16
  %t261 = icmp eq i32 %t259, 1
  br i1 %t261, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_67abeedc6dc3e7e5_22c54dafd155c1d1)
  unreachable
bb69:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb92
bb70:
  %t263 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t263, ptr %l21, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s14
  %t268 = load i64, ptr %l23, !tbaa !24
  %t269 = load i64, ptr %l22, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s14)
  br label %bb90
bb73:
  br label %bb74
bb74:
  %t276 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t276, ptr %l146, !tbaa !27
  %t277 = load i64, ptr %l23, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr %"compiler/typed:Local", ptr %t280, i64 %t277
  %t282 = load %"compiler/typed:Local", ptr %t281
  store %"compiler/typed:Local" %t282, ptr %l24
  %t284 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 0
  %t285 = load i32, ptr %t284, !tbaa !23
  %t287 = icmp ne i32 %t285, 0
  br i1 %t287, label %bb75, label %bb76
bb75:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/session:Analysis", ptr %t289, i32 0, i32 1
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = icmp eq ptr %t292, null
  br i1 %t294, label %bb77, label %bb78
bb76:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb82
bb77:
  call void @__olang_check_failed(ptr @olang_loc_3420eab5d10be317_b620dca566d2bea3)
  unreachable
bb78:
  br label %bb79
bb79:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/session:Analysis", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t302 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t305 = getelementptr %"compiler/generic:Program", ptr %t303, i32 0, i32 0
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/load:Loader", ptr %t306, i32 0, i32 3
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 0
  %t311 = load i32, ptr %t310, !tbaa !23
  %t314 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t309, i32 %t311)
  store { i64, ptr } %t314, ptr %l162
  br label %bb80
bb80:
  %t315 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t316 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t316, { i64, ptr } %t315)
  store i1 %t318, ptr %l164
  br label %bb81
bb81:
  %t319 = load i1, ptr %l164, !tbaa !21
  store i1 %t319, ptr %l151, !tbaa !21
  br label %bb82
bb82:
  %t320 = load i1, ptr %l151, !tbaa !21
  br i1 %t320, label %bb83, label %bb84
bb83:
  %t321 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 1
  %t322 = getelementptr %"compiler/source:Span", ptr %t321, i32 0, i32 0
  %t323 = load i32, ptr %t322, !tbaa !23
  %t325 = sext i32 %t323 to i64
  %t326 = load i64, ptr %l2, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  store i1 %t329, ptr %l165, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb85
bb85:
  %t331 = load i1, ptr %l165, !tbaa !21
  br i1 %t331, label %bb86, label %bb87
bb86:
  %t332 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 2
  %t333 = load i32, ptr %t332, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t333, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb89:
  %t335 = load i64, ptr %l23, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l23, !tbaa !24
  br label %bb71
bb90:
  %t339 = load i64, ptr %l20, !tbaa !24
  %t340 = load i64, ptr %l22, !tbaa !24
  %t343 = add i64 %t339, %t340
  store i64 %t343, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb91
bb91:
  br label %bb64
bb92:
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb93:
  %t345 = load i64, ptr %l17, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l17, !tbaa !24
  br label %bb51
bb94:
  %t349 = load i64, ptr %l14, !tbaa !24
  %t350 = load i64, ptr %l16, !tbaa !24
  %t353 = add i64 %t349, %t350
  store i64 %t353, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb95
bb95:
  br label %bb44
bb96:
  %t355 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t355, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, [2 x i64] }
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %l41 = alloca i32
  %l44 = alloca i32
  %l52 = alloca i32
  %l61 = alloca i32
  %l71 = alloca i32
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l90 = alloca { i64, ptr }
  %l105 = alloca i32
  %l109 = alloca i1
  %l117 = alloca i32
  %l125 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca { i64, ptr }
  %l137 = alloca i64
  %l141 = alloca i64
  %l144 = alloca i64
  %l163 = alloca ptr
  %l167 = alloca i32
  %l169 = alloca %"compiler/typed:Local"
  %l172 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca ptr
  %l199 = alloca { i64, ptr }
  %l200 = alloca i64
  %l203 = alloca ptr
  %l208 = alloca i32
  %l209 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l232 = alloca i64
  %l236 = alloca i64
  %l239 = alloca i64
  %l263 = alloca ptr
  %l272 = alloca ptr
  %l278 = alloca ptr
  %l285 = alloca i32
  %l286 = alloca i32
  %l287 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l297 = alloca i32
  %l307 = alloca i32
  %l313 = alloca i1
  %l324 = alloca { i64, ptr }
  %l326 = alloca i1
  %l328 = alloca i1
  %l335 = alloca i64
  %l340 = alloca ptr
  %l341 = alloca { i64, ptr }
  %l342 = alloca i64
  %l345 = alloca ptr
  %l352 = alloca { i64, ptr }
  %l354 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l41
  br label %bb4
bb4:
  %t21 = load i32, ptr %l41
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l2, !tbaa !23
  store i32 %t30, ptr %l44, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l52
  br label %bb10
bb10:
  %t43 = load i32, ptr %l52, !tbaa !23
  store i32 %t43, ptr %l44, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l44, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_183418cbaaa3b5f3_579c8efa30db605f)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l61
  br label %bb15
bb15:
  %t60 = load i32, ptr %l61
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = icmp eq ptr %t65, null
  br i1 %t67, label %bb18, label %bb19
bb17:
  br label %bb108
bb18:
  call void @__olang_check_failed(ptr @olang_loc_269369d36ae436b2_2e7a039021f1ff2e)
  unreachable
bb19:
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l4, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l71
  br label %bb21
bb21:
  %t80 = load i32, ptr %l71, !tbaa !23
  store i32 %t80, ptr %l5, !tbaa !23
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5)
  unreachable
bb23:
  br label %bb24
bb24:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 11
  store ptr %t88, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t91 = load i64, ptr %l7, !tbaa !24
  %t94 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %t90, i64 %t91)
  %t95 = extractvalue { i32, { i64, ptr } } %t94, 1
  %t96 = extractvalue { i32, { i64, ptr } } %t94, 0
  store i32 %t96, ptr %l81
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb27, label %ok.98
ok.98:
  store { i64, ptr } %t95, ptr %l80
  br label %bb26
bb26:
  %t99 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t99, ptr %l77, !tbaa !27
  br label %bb31
bb27:
  %t100 = load i32, ptr %l81, !tbaa !23
  %t101 = ashr i32 %t100, 16
  %t103 = icmp eq i32 %t101, 1
  br i1 %t103, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_1aec45c66be069a7_7812cf21d0956dab)
  unreachable
bb30:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb107
bb31:
  %t105 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb105
bb34:
  br label %bb35
bb35:
  %t118 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t118, ptr %l90, !tbaa !27
  %t119 = load i64, ptr %l10, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  store ptr %t124, ptr %l11, !tbaa !29
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/typed:Body", ptr %t126, i32 0, i32 1
  %t129 = load { i64, [2 x i64] }, ptr %t128
  store { i64, [2 x i64] } %t129, ptr %l12
  %t131 = load { i64, [2 x i64] }, ptr %l12
  %t133 = extractvalue { i64, [2 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 1
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t136 = getelementptr { i64, [2 x i64] }, ptr %l12, i32 0, i32 1
  %t137 = getelementptr { i32, i32 }, ptr %t136, i32 0, i32 0
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l13, !tbaa !23
  br label %bb38
bb37:
  br label %bb98
bb38:
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb40:
  br label %bb41
bb41:
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l13, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l105
  br label %bb42
bb42:
  %t155 = load i32, ptr %l105
  %t157 = trunc i64 18 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb49
bb44:
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb46:
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 2
  %t173 = load i32, ptr %l13, !tbaa !23
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t172, i32 %t173)
  store i32 %t176, ptr %l117
  br label %bb48
bb48:
  %t177 = load i32, ptr %l5, !tbaa !23
  %t178 = load i32, ptr %l117, !tbaa !23
  %t180 = icmp ne i32 %t178, %t177
  store i1 %t180, ptr %l109, !tbaa !21
  br label %bb49
bb49:
  %t182 = load i1, ptr %l109, !tbaa !21
  br i1 %t182, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %bb104
bb51:
  br label %bb52
bb52:
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb53, label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_276794097286b2ce_71d39dea21084d12)
  unreachable
bb54:
  br label %bb55
bb55:
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/generic:Program", ptr %t191, i32 0, i32 2
  store ptr %t193, ptr %l125, !tbaa !29
  %t194 = load ptr, ptr %l3, !tbaa !29
  %t196 = icmp eq ptr %t194, null
  br i1 %t196, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_276794097286b2ce_71d39dea21084d12)
  unreachable
bb57:
  br label %bb58
bb58:
  %t198 = load ptr, ptr %l3, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l4, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t208, ptr %l133
  br label %bb59
bb59:
  %t209 = load ptr, ptr %l125, !tbaa !29
  %t210 = load i32, ptr %l133, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t209, i32 %t210)
  store { i64, ptr } %t211, ptr %l134
  br label %bb60
bb60:
  %t212 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t212, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t213 = load ptr, ptr %l11, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Body", ptr %t213, i32 0, i32 10
  %t217 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t215)
  store i64 %t217, ptr %l137
  br label %bb61
bb61:
  %t218 = load i64, ptr %l137, !tbaa !24
  store i64 %t218, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t219 = load i64, ptr %l16, !tbaa !24
  %t220 = load i64, ptr %l15, !tbaa !24
  %t223 = icmp sgt i64 %t219, %t220
  br i1 %t223, label %bb62, label %bb63
bb62:
  %t225 = load i64, ptr %l17, !tbaa !24
  %t227 = icmp sgt i64 %t225, 0
  br i1 %t227, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb67
bb64:
  %t229 = load i64, ptr %l16, !tbaa !24
  %t230 = load i64, ptr %l15, !tbaa !24
  %t233 = sub i64 %t229, %t230
  %t234 = load i64, ptr %l17, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t239 = sub i64 %t237, 1
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = sdiv i64 %t239, %t240
  store i64 %t243, ptr %l144, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb66
bb66:
  %t245 = load i64, ptr %l144, !tbaa !24
  store i64 %t245, ptr %l141, !tbaa !24
  br label %bb67
bb67:
  %t246 = load i64, ptr %l141, !tbaa !24
  store i64 %t246, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s8
  %t247 = load i64, ptr %l19, !tbaa !24
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s8)
  br label %bb97
bb70:
  br label %bb71
bb71:
  %t255 = load i64, ptr %l15, !tbaa !24
  %t256 = load i64, ptr %l19, !tbaa !24
  %t257 = load i64, ptr %l17, !tbaa !24
  %t260 = mul i64 %t256, %t257
  %t263 = add i64 %t255, %t260
  store i64 %t263, ptr %l20, !tbaa !24
  %t265 = load ptr, ptr %l11, !tbaa !29
  %t267 = getelementptr %"compiler/typed:Body", ptr %t265, i32 0, i32 7
  store ptr %t267, ptr %l163, !tbaa !29
  %t268 = load ptr, ptr %l11, !tbaa !29
  %t270 = getelementptr %"compiler/typed:Body", ptr %t268, i32 0, i32 10
  %t271 = load i64, ptr %l20, !tbaa !24
  %t274 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t270, i64 %t271)
  store i32 %t274, ptr %l167
  br label %bb72
bb72:
  %t275 = load i32, ptr %l167, !tbaa !23
  %t276 = sext i32 %t275 to i64
  %t277 = load ptr, ptr %l163, !tbaa !29
  %t279 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t277, i64 %t276)
  store %"compiler/typed:Local" %t279, ptr %l169
  br label %bb73
bb73:
  %t280 = load %"compiler/typed:Local", ptr %l169
  store %"compiler/typed:Local" %t280, ptr %l21
  %t281 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t282 = load i32, ptr %t281, !tbaa !23
  %t284 = icmp eq i32 %t282, 0
  br i1 %t284, label %bb74, label %bb75
bb74:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/session:Analysis", ptr %t286, i32 0, i32 0
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/load:Loader", ptr %t289, i32 0, i32 4
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t293 = load ptr, ptr %l11, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Body", ptr %t293, i32 0, i32 3
  %t296 = load i64, ptr %t295, !tbaa !24
  %t299 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %t292, i64 %t296)
  store { i64, ptr } %t299, ptr %l178
  br label %bb76
bb75:
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  br i1 %t302, label %bb83, label %bb84
bb76:
  %t304 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t304, ptr %l179, !tbaa !27
  %t305 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t306 = getelementptr %"compiler/source:Span", ptr %t305, i32 0, i32 0
  %t307 = load i32, ptr %t306, !tbaa !23
  %t309 = sext i32 %t307 to i64
  store i64 %t309, ptr %l181, !tbaa !24
  %t310 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t311 = getelementptr %"compiler/source:Span", ptr %t310, i32 0, i32 1
  %t312 = load i32, ptr %t311, !tbaa !23
  %t314 = sext i32 %t312 to i64
  store i64 %t314, ptr %l183, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 0
  store i64 %t316, ptr %l184, !tbaa !24
  %t317 = load i64, ptr %l181, !tbaa !24
  %t318 = icmp sge i64 %t317, 0
  br i1 %t318, label %bb77, label %bb78
bb77:
  %t320 = load i64, ptr %l181, !tbaa !24
  %t321 = load i64, ptr %l183, !tbaa !24
  %t322 = icmp sle i64 %t320, %t321
  br i1 %t322, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_82218eacf4543783_985f2bd8de40d207)
  unreachable
bb79:
  %t324 = load i64, ptr %l183, !tbaa !24
  %t325 = load i64, ptr %l184, !tbaa !24
  %t326 = icmp sle i64 %t324, %t325
  br i1 %t326, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @olang_loc_82218eacf4543783_985f2bd8de40d207)
  unreachable
bb81:
  %t328 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = load i64, ptr %l181, !tbaa !24
  %t331 = load i64, ptr %l183, !tbaa !24
  %t332 = getelementptr i8, ptr %t329, i64 %t330
  %t333 = sub i64 %t331, %t330
  %t334 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t332, 1
  store { i64, ptr } %t335, ptr %l172, !tbaa !27
  br label %bb87
bb82:
  call void @__olang_check_failed(ptr @olang_loc_82218eacf4543783_985f2bd8de40d207)
  unreachable
bb83:
  call void @__olang_check_failed(ptr @olang_loc_f4d7e16f2a7cbb1c_8fb96f5d8af1db38)
  unreachable
bb84:
  br label %bb85
bb85:
  %t337 = load ptr, ptr %l3, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/generic:Program", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/load:Loader", ptr %t344, i32 0, i32 3
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t349 = load i32, ptr %t348, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t347, i32 %t349)
  store { i64, ptr } %t352, ptr %l197
  br label %bb86
bb86:
  %t353 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t353, ptr %l172, !tbaa !27
  br label %bb87
bb87:
  %t354 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t355 = load ptr, ptr %l1, !tbaa !29
  store ptr %t355, ptr %l198, !tbaa !29
  store { i64, ptr } %t354, ptr %l199, !tbaa !27
  %t357 = load i64, ptr @G_2ecompiler_2fsession_2eCompField, !tbaa !24
  store i64 %t357, ptr %l200, !tbaa !24
  %t358 = load ptr, ptr %l3, !tbaa !29
  %t360 = icmp eq ptr %t358, null
  br i1 %t360, label %bb88, label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_1c008e98be3ff20b_924cdfead9f88757)
  unreachable
bb89:
  br label %bb90
bb90:
  %t362 = load ptr, ptr %l3, !tbaa !29
  store ptr %t362, ptr %l203, !tbaa !29
  %t363 = load i64, ptr %l20, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t369 = icmp slt i64 %t363, %t366
  br i1 %t369, label %bb91, label %bb92
bb91:
  %t371 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t371, ptr %l209, !tbaa !27
  %t372 = load i64, ptr %l20, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr i32, ptr %t375, i64 %t372
  %t377 = load i32, ptr %t376, !tbaa !33
  store i32 %t377, ptr %l208, !tbaa !23
  br label %bb93
bb92:
  %t379 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t380 = load i32, ptr %t379, !tbaa !23
  store i32 %t380, ptr %l208, !tbaa !23
  br label %bb93
bb93:
  %t382 = load ptr, ptr %l203, !tbaa !29
  %t383 = load i32, ptr %l208, !tbaa !23
  %t384 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t382, i32 %t383)
  store { i64, ptr } %t384, ptr %l213
  br label %bb94
bb94:
  %t385 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 0
  %t387 = extractvalue { i64, ptr } %t385, 1
  %t388 = mul i64 %t386, 1
  %t389 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t389, ptr %t387, i64 %t388, i1 false)
  %t390 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t392 = load ptr, ptr %l198, !tbaa !29
  %t393 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t394 = load i64, ptr %l200, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s8, ptr %t392, { i64, ptr } %t393, i64 %t394, { i64, ptr } %t391)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s8)
  br label %bb96
bb96:
  %t396 = load i64, ptr %l19, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l19, !tbaa !24
  br label %bb68
bb97:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb107
bb98:
  br i1 true, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_check_failed(ptr @olang_loc_b565a54699261f06_cef80cb59d129ba)
  unreachable
bb103:
  call void @__olang_scope_close(ptr %s4)
  br label %bb104
bb104:
  %t400 = load i64, ptr %l10, !tbaa !24
  %t402 = add i64 %t400, 1
  store i64 %t402, ptr %l10, !tbaa !24
  br label %bb32
bb105:
  %t404 = load i64, ptr %l7, !tbaa !24
  %t405 = load i64, ptr %l9, !tbaa !24
  %t408 = add i64 %t404, %t405
  store i64 %t408, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb106
bb106:
  br label %bb25
bb107:
  br label %bb108
bb108:
  %t410 = load ptr, ptr %l3, !tbaa !29
  %t412 = icmp eq ptr %t410, null
  br i1 %t412, label %bb109, label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_b99b77fc0d6b96a0_446559ab5289c314)
  unreachable
bb110:
  br label %bb111
bb111:
  %t414 = load ptr, ptr %l3, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t418)
  br label %bb112
bb112:
  store i64 0, ptr %l23, !tbaa !24
  %t420 = load ptr, ptr %l3, !tbaa !29
  %t422 = icmp eq ptr %t420, null
  br i1 %t422, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_87ffdc4dfe3941b5_82c807225dd1f409)
  unreachable
bb114:
  br label %bb115
bb115:
  %t424 = load ptr, ptr %l3, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t424, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t430 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t428)
  store i64 %t430, ptr %l232
  br label %bb116
bb116:
  %t431 = load i64, ptr %l232, !tbaa !24
  store i64 %t431, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t432 = load i64, ptr %l24, !tbaa !24
  %t433 = load i64, ptr %l23, !tbaa !24
  %t436 = icmp sgt i64 %t432, %t433
  br i1 %t436, label %bb117, label %bb118
bb117:
  %t438 = load i64, ptr %l25, !tbaa !24
  %t440 = icmp sgt i64 %t438, 0
  br i1 %t440, label %bb119, label %bb120
bb118:
  store i64 0, ptr %l236, !tbaa !24
  br label %bb122
bb119:
  %t442 = load i64, ptr %l24, !tbaa !24
  %t443 = load i64, ptr %l23, !tbaa !24
  %t446 = sub i64 %t442, %t443
  %t447 = load i64, ptr %l25, !tbaa !24
  %t450 = add i64 %t446, %t447
  %t452 = sub i64 %t450, 1
  %t453 = load i64, ptr %l25, !tbaa !24
  %t456 = sdiv i64 %t452, %t453
  store i64 %t456, ptr %l239, !tbaa !24
  br label %bb121
bb120:
  store i64 0, ptr %l239, !tbaa !24
  br label %bb121
bb121:
  %t458 = load i64, ptr %l239, !tbaa !24
  store i64 %t458, ptr %l236, !tbaa !24
  br label %bb122
bb122:
  %t459 = load i64, ptr %l236, !tbaa !24
  store i64 %t459, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s13
  %t460 = load i64, ptr %l27, !tbaa !24
  %t461 = load i64, ptr %l26, !tbaa !24
  %t464 = icmp slt i64 %t460, %t461
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s13)
  br label %bb189
bb125:
  br label %bb126
bb126:
  %t468 = load i64, ptr %l23, !tbaa !24
  %t469 = load i64, ptr %l27, !tbaa !24
  %t470 = load i64, ptr %l25, !tbaa !24
  %t473 = mul i64 %t469, %t470
  %t476 = add i64 %t468, %t473
  store i64 %t476, ptr %l28, !tbaa !24
  %t478 = load ptr, ptr %l3, !tbaa !29
  %t480 = icmp eq ptr %t478, null
  br i1 %t480, label %bb127, label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_776e281276b2060e_3c638b59aec5e9a2)
  unreachable
bb128:
  br label %bb129
bb129:
  %t482 = load ptr, ptr %l3, !tbaa !29
  %t485 = getelementptr %"compiler/check:Checker", ptr %t482, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !29
  %t487 = load i64, ptr %l28, !tbaa !24
  %t490 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t486, i64 %t487)
  store ptr %t490, ptr %l263
  br label %bb130
bb130:
  %t491 = load ptr, ptr %l263, !tbaa !29
  store ptr %t491, ptr %l29, !tbaa !29
  %t492 = load ptr, ptr %l29, !tbaa !29
  %t494 = getelementptr %"compiler/ast:Func", ptr %t492, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !29
  %t497 = icmp eq ptr %t495, null
  br i1 %t497, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s13)
  br label %bb188
bb132:
  br label %bb133
bb133:
  %t499 = load ptr, ptr %l3, !tbaa !29
  %t501 = icmp eq ptr %t499, null
  br i1 %t501, label %bb134, label %bb135
bb134:
  call void @__olang_check_failed(ptr @olang_loc_6237d3e91d999133_c33b7259109e18ef)
  unreachable
bb135:
  br label %bb136
bb136:
  %t503 = load ptr, ptr %l3, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t509 = getelementptr %"compiler/generic:Program", ptr %t507, i32 0, i32 2
  store ptr %t509, ptr %l272, !tbaa !29
  %t510 = load ptr, ptr %l3, !tbaa !29
  %t512 = icmp eq ptr %t510, null
  br i1 %t512, label %bb137, label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_6237d3e91d999133_c33b7259109e18ef)
  unreachable
bb138:
  br label %bb139
bb139:
  %t514 = load ptr, ptr %l3, !tbaa !29
  %t517 = getelementptr %"compiler/check:Checker", ptr %t514, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !29
  %t520 = getelementptr %"compiler/generic:Program", ptr %t518, i32 0, i32 2
  store ptr %t520, ptr %l278, !tbaa !29
  %t521 = load ptr, ptr %l3, !tbaa !29
  %t523 = icmp eq ptr %t521, null
  br i1 %t523, label %bb140, label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_6237d3e91d999133_c33b7259109e18ef)
  unreachable
bb141:
  br label %bb142
bb142:
  %t525 = load ptr, ptr %l3, !tbaa !29
  %t528 = getelementptr %"compiler/check:Checker", ptr %t525, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t530 = load i64, ptr %l28, !tbaa !24
  %t533 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t529, i64 %t530)
  store i32 %t533, ptr %l285
  br label %bb143
bb143:
  %t534 = load ptr, ptr %l278, !tbaa !29
  %t535 = load i32, ptr %l285, !tbaa !23
  %t536 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t534, i32 %t535)
  store i32 %t536, ptr %l286
  br label %bb144
bb144:
  %t537 = load ptr, ptr %l272, !tbaa !29
  %t538 = load i32, ptr %l286, !tbaa !23
  %t539 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t537, i32 %t538)
  store { i64, ptr } %t539, ptr %l287
  br label %bb145
bb145:
  %t540 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t540, ptr %l288, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr i32, ptr %t542, i64 0
  %t544 = load i32, ptr %t543, !tbaa !33
  store i32 %t544, ptr %l30, !tbaa !23
  %t546 = load ptr, ptr %l3, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  br i1 %t548, label %bb146, label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_ba98b6e2ec866164_4230a8105a2f5a90)
  unreachable
bb147:
  br label %bb148
bb148:
  %t550 = load ptr, ptr %l3, !tbaa !29
  %t553 = getelementptr %"compiler/check:Checker", ptr %t550, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !29
  %t556 = getelementptr %"compiler/generic:Program", ptr %t554, i32 0, i32 2
  %t557 = load i32, ptr %l30, !tbaa !23
  %t560 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t556, i32 %t557)
  store i32 %t560, ptr %l297
  br label %bb149
bb149:
  %t561 = load i32, ptr %l297
  %t563 = trunc i64 20 to i32
  %t564 = icmp eq i32 %t561, %t563
  br i1 %t564, label %bb150, label %bb151
bb150:
  %t566 = load ptr, ptr %l3, !tbaa !29
  %t568 = icmp eq ptr %t566, null
  br i1 %t568, label %bb152, label %bb153
bb151:
  br label %bb156
bb152:
  call void @__olang_check_failed(ptr @olang_loc_ba98b6e2ec866164_4230a8105a2f5a90)
  unreachable
bb153:
  br label %bb154
bb154:
  %t570 = load ptr, ptr %l3, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t570, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = getelementptr %"compiler/generic:Program", ptr %t574, i32 0, i32 2
  %t577 = load i32, ptr %l30, !tbaa !23
  %t580 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t576, i32 %t577)
  store i32 %t580, ptr %l307
  br label %bb155
bb155:
  %t581 = load i32, ptr %l307, !tbaa !23
  store i32 %t581, ptr %l30, !tbaa !23
  br label %bb156
bb156:
  %t582 = load ptr, ptr %l3, !tbaa !29
  %t584 = icmp eq ptr %t582, null
  br i1 %t584, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_7656df89f7661819_748f2d65f1fb15e5)
  unreachable
bb158:
  br label %bb159
bb159:
  %t586 = load ptr, ptr %l3, !tbaa !29
  %t587 = load i32, ptr %l30, !tbaa !23
  %t588 = load i32, ptr %l4, !tbaa !23
  %t592 = call i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %t586, i32 %t587, i32 %t588)
  store i1 %t592, ptr %l313
  br label %bb160
bb160:
  %t593 = load i1, ptr %l313, !tbaa !21
  %t594 = xor i1 %t593, true
  br i1 %t594, label %bb161, label %bb162
bb161:
  call void @__olang_scope_close(ptr %s13)
  br label %bb188
bb162:
  br label %bb163
bb163:
  %t596 = load ptr, ptr %l3, !tbaa !29
  %t598 = icmp eq ptr %t596, null
  br i1 %t598, label %bb164, label %bb165
bb164:
  call void @__olang_check_failed(ptr @olang_loc_15086b6df77480f2_b1c913263c09743e)
  unreachable
bb165:
  br label %bb166
bb166:
  %t600 = load ptr, ptr %l3, !tbaa !29
  %t603 = getelementptr %"compiler/check:Checker", ptr %t600, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = getelementptr %"compiler/generic:Program", ptr %t604, i32 0, i32 0
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/load:Loader", ptr %t607, i32 0, i32 3
  %t610 = load ptr, ptr %t609, !tbaa !29
  %t611 = load ptr, ptr %l29, !tbaa !29
  %t613 = getelementptr %"compiler/ast:Func", ptr %t611, i32 0, i32 2
  %t614 = load i32, ptr %t613, !tbaa !23
  %t617 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t610, i32 %t614)
  store { i64, ptr } %t617, ptr %l324
  br label %bb167
bb167:
  %t618 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t618, ptr %l31, !tbaa !27
  %t619 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t621 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t619)
  store i1 %t621, ptr %l326
  br label %bb168
bb168:
  %t622 = load i1, ptr %l326, !tbaa !21
  %t623 = xor i1 %t622, true
  br i1 %t623, label %bb169, label %bb170
bb169:
  %t625 = load ptr, ptr %l3, !tbaa !29
  %t627 = icmp eq ptr %t625, null
  br i1 %t627, label %bb171, label %bb172
bb170:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb175
bb171:
  call void @__olang_check_failed(ptr @olang_loc_e46064093ccb7737_bcf1b739fe6e0cbb)
  unreachable
bb172:
  br label %bb173
bb173:
  %t629 = load ptr, ptr %l3, !tbaa !29
  %t632 = getelementptr %"compiler/check:Checker", ptr %t629, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !29
  %t634 = load i64, ptr %l28, !tbaa !24
  %t637 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t633, i64 %t634)
  store i64 %t637, ptr %l335
  br label %bb174
bb174:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/session:Analysis", ptr %t638, i32 0, i32 0
  %t641 = load ptr, ptr %t640, !tbaa !29
  %t643 = getelementptr %"compiler/load:Loader", ptr %t641, i32 0, i32 7
  %t644 = load i64, ptr %t643, !tbaa !24
  %t645 = load i64, ptr %l335, !tbaa !24
  %t647 = icmp ne i64 %t645, %t644
  store i1 %t647, ptr %l328, !tbaa !21
  br label %bb175
bb175:
  %t649 = load i1, ptr %l328, !tbaa !21
  br i1 %t649, label %bb176, label %bb177
bb176:
  call void @__olang_scope_close(ptr %s13)
  br label %bb188
bb177:
  br label %bb178
bb178:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l340, !tbaa !29
  %t651 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t651, ptr %l341, !tbaa !27
  %t652 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  store i64 %t652, ptr %l342, !tbaa !24
  %t653 = load ptr, ptr %l3, !tbaa !29
  %t655 = icmp eq ptr %t653, null
  br i1 %t655, label %bb179, label %bb180
bb179:
  call void @__olang_check_failed(ptr @olang_loc_c9113caf811d0518_bcd4762777a6b04c)
  unreachable
bb180:
  br label %bb181
bb181:
  %t657 = load ptr, ptr %l3, !tbaa !29
  store ptr %t657, ptr %l345, !tbaa !29
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t660 = getelementptr %"compiler/session:Analysis", ptr %t658, i32 0, i32 2
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t663 = icmp eq ptr %t661, null
  br i1 %t663, label %bb182, label %bb183
bb182:
  call void @__olang_check_failed(ptr @olang_loc_c9113caf811d0518_bcd4762777a6b04c)
  unreachable
bb183:
  br label %bb184
bb184:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/session:Analysis", ptr %t665, i32 0, i32 2
  %t668 = load ptr, ptr %t667, !tbaa !29
  %t669 = load i64, ptr %l28, !tbaa !24
  %t670 = load ptr, ptr %l345, !tbaa !29
  %t673 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s13, ptr %t670, ptr %t668, i64 %t669)
  store { i64, ptr } %t673, ptr %l352
  br label %bb185
bb185:
  %t674 = load { i64, ptr }, ptr %l352, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t674, 0
  %t676 = extractvalue { i64, ptr } %t674, 1
  %t677 = mul i64 %t675, 1
  %t678 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t677)
  call void @llvm.memcpy.p0.p0.i64(ptr %t678, ptr %t676, i64 %t677, i1 false)
  %t679 = insertvalue { i64, ptr } undef, i64 %t675, 0
  %t680 = insertvalue { i64, ptr } %t679, ptr %t678, 1
  %t682 = call { i64, ptr } @compiler_2fsession_2efirstLine(ptr %s13, ptr %s13, { i64, ptr } %t680)
  store { i64, ptr } %t682, ptr %l354
  br label %bb186
bb186:
  %t683 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t684 = extractvalue { i64, ptr } %t683, 0
  %t685 = extractvalue { i64, ptr } %t683, 1
  %t686 = mul i64 %t684, 1
  %t687 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t686)
  call void @llvm.memcpy.p0.p0.i64(ptr %t687, ptr %t685, i64 %t686, i1 false)
  %t688 = insertvalue { i64, ptr } undef, i64 %t684, 0
  %t689 = insertvalue { i64, ptr } %t688, ptr %t687, 1
  %t690 = load ptr, ptr %l340, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t692 = load i64, ptr %l342, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s13, ptr %t690, { i64, ptr } %t691, i64 %t692, { i64, ptr } %t689)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s13)
  br label %bb188
bb188:
  %t694 = load i64, ptr %l27, !tbaa !24
  %t696 = add i64 %t694, 1
  store i64 %t696, ptr %l27, !tbaa !24
  br label %bb123
bb189:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i1
  %l46 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Items", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l16
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l15
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t14, ptr %l12, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ec94e30d90cfb58d_d203b7196ae8f109)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb7:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t39, { i64, ptr } %t42)
  store i1 %t45, ptr %l30
  br label %bb12
bb12:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l8, !tbaa !24
  br label %bb8
bb17:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  store i64 %t55, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb1
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:Items", ptr %t57, i32 0, i32 2
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = extractvalue { i64, ptr } %t60, 0
  %t64 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t62, i64 %t63)
  %t65 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  %t69 = extractvalue { i64, ptr } %t66, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t59, { i64, ptr } %t73)
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/session:Items", ptr %t76, i32 0, i32 1
  %t79 = load i64, ptr %t78, !tbaa !24
  %t81 = icmp sgt i64 %t79, 0
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/session:Items", ptr %t83, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t85, i8 44)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l46, !tbaa !29
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = getelementptr %"compiler/session:Items", ptr %t88, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = add i64 %t90, 1
  %t94 = load ptr, ptr %l46, !tbaa !29
  %t95 = getelementptr %"compiler/session:Items", ptr %t94, i32 0, i32 1
  store i64 %t92, ptr %t95, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/session:Items", ptr %t96, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t98, { i64, ptr } { i64 9, ptr @.d116 })
  br label %bb25
bb25:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/session:Items", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %t102, { i64, ptr } %t103)
  br label %bb26
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/session:Items", ptr %t106, i32 0, i32 0
  %t110 = extractvalue { i64, ptr } { i64 8, ptr @.d117 }, 1
  %t111 = extractvalue { i64, ptr } { i64 8, ptr @.d117 }, 0
  %t113 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t110, i64 %t111)
  %t116 = getelementptr i8, ptr %t115, i64 %t111
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %a2)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t115, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t108, { i64, ptr } %t126)
  br label %bb27
bb27:
  %t129 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 0, ptr @.d118 })
  store i1 %t131, ptr %l60
  br label %bb28
bb28:
  %t132 = load i1, ptr %l60, !tbaa !21
  %t133 = xor i1 %t132, true
  br i1 %t133, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s9
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/session:Items", ptr %t135, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t137, { i64, ptr } { i64 10, ptr @.d119 })
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/session:Items", ptr %t139, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v2, ptr %t141, { i64, ptr } %t142)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/session:Items", ptr %t145, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t147, i8 125)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l21 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l49 = alloca i64
  %l58 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l88 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/session:Positions", ptr %t7, i32 0, i32 2
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp sge i64 %t6, %t12
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/session:Positions", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Positions", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  %t35 = sext i32 %t33 to i64
  store i64 %t35, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = add i64 %t37, 1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/session:Positions", ptr %t40, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp slt i64 %t39, %t45
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/session:Positions", ptr %t50, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = add i64 %t54, 1
  %t58 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t63 = sext i32 %t61 to i64
  %t65 = sub i64 %t63, 1
  store i64 %t65, ptr %l31, !tbaa !24
  br label %bb9
bb8:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/session:Positions", ptr %t67, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l31, !tbaa !24
  br label %bb9
bb9:
  %t74 = load i64, ptr %l31, !tbaa !24
  store i64 %t74, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/session:Positions", ptr %t75, i32 0, i32 1
  %t78 = load i1, ptr %t77, !tbaa !21
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp sle i64 %t84, %t85
  br i1 %t88, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = load i64, ptr %l2, !tbaa !24
  %t94 = add i64 %t90, %t91
  store i64 %t94, ptr %l49, !tbaa !24
  br label %bb14
bb13:
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %l49, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l49, !tbaa !24
  store i64 %t98, ptr %rv
  br label %ret
bb15:
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  br i1 %t105, label %bb17, label %bb18
bb17:
  %t107 = load i64, ptr %l6, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  store i1 %t111, ptr %l58, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l58, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb21:
  br label %bb22
bb22:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/session:Positions", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  store i8 %t125, ptr %l7, !tbaa !22
  %t128 = load i8, ptr %l7, !tbaa !22
  %t130 = icmp ult i8 %t128, -64
  br i1 %t130, label %bb23, label %bb24
bb23:
  store i64 1, ptr %l70, !tbaa !24
  br label %bb31
bb24:
  %t132 = load i8, ptr %l7, !tbaa !22
  %t134 = icmp ult i8 %t132, -32
  br i1 %t134, label %bb25, label %bb26
bb25:
  store i64 2, ptr %l73, !tbaa !24
  br label %bb30
bb26:
  %t136 = load i8, ptr %l7, !tbaa !22
  %t138 = icmp ult i8 %t136, -16
  br i1 %t138, label %bb27, label %bb28
bb27:
  store i64 3, ptr %l76, !tbaa !24
  br label %bb29
bb28:
  store i64 4, ptr %l76, !tbaa !24
  br label %bb29
bb29:
  %t140 = load i64, ptr %l76, !tbaa !24
  store i64 %t140, ptr %l73, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l73, !tbaa !24
  store i64 %t141, ptr %l70, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l70, !tbaa !24
  store i64 %t142, ptr %l8, !tbaa !24
  %t143 = load i64, ptr %l6, !tbaa !24
  store i64 %t143, ptr %l77, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp eq i64 %t144, 4
  br i1 %t146, label %bb32, label %bb33
bb32:
  store i64 2, ptr %l80, !tbaa !24
  br label %bb34
bb33:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb34
bb34:
  %t148 = load i64, ptr %l77, !tbaa !24
  %t149 = load i64, ptr %l80, !tbaa !24
  %t150 = add i64 %t148, %t149
  store i64 %t150, ptr %l6, !tbaa !24
  %t152 = load i64, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = add i64 %t152, %t153
  store i64 %t156, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  br label %bb16
bb36:
  %t158 = load i64, ptr %l5, !tbaa !24
  %t159 = load i64, ptr %l4, !tbaa !24
  %t162 = icmp sle i64 %t158, %t159
  br i1 %t162, label %bb37, label %bb38
bb37:
  %t164 = load i64, ptr %l5, !tbaa !24
  store i64 %t164, ptr %l88, !tbaa !24
  br label %bb39
bb38:
  %t166 = load i64, ptr %l4, !tbaa !24
  store i64 %t166, ptr %l88, !tbaa !24
  br label %bb39
bb39:
  %t168 = load i64, ptr %l88, !tbaa !24
  store i64 %t168, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l32 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l53 = alloca i64
  %l58 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t12 = icmp sgt i64 %t3, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/session:Positions", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/session:Positions", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = add i64 %t46, 1
  %t50 = sdiv i64 %t48, 2
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/session:Positions", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l32, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t63 = sext i32 %t61 to i64
  %t64 = load i64, ptr %l2, !tbaa !24
  %t67 = icmp sle i64 %t63, %t64
  br i1 %t67, label %bb11, label %bb12
bb11:
  %t69 = load i64, ptr %l5, !tbaa !24
  store i64 %t69, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  br label %bb7
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/session:Positions", ptr %t75, i32 0, i32 2
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l42, !tbaa !27
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l6, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/session:Positions", ptr %t88, i32 0, i32 1
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  %t93 = load i64, ptr %l3, !tbaa !24
  %t94 = load i64, ptr %l2, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t100 = insertvalue { i64, i64 } undef, i64 %t93, 0
  %t102 = insertvalue { i64, i64 } %t100, i64 %t98, 1
  store { i64, i64 } %t102, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t104 = load i64, ptr %l3, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/session:Positions", ptr %t105, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l2, !tbaa !24
  %t114 = call i64 @compiler_2fsession_2eutf16Units(ptr %v0, { i64, ptr } %t108, i64 %t109, i64 %t110)
  store i64 %t114, ptr %l58
  br label %bb19
bb19:
  %t115 = load i64, ptr %l53, !tbaa !24
  %t116 = insertvalue { i64, i64 } undef, i64 %t115, 0
  %t117 = load i64, ptr %l58, !tbaa !24
  %t118 = insertvalue { i64, i64 } %t116, i64 %t117, 1
  store { i64, i64 } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64 }
  %l12 = alloca { i64, i64 }
  %l17 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %t1, i64 %a2)
  store { i64, i64 } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l12
  store { i64, i64 } %t6, ptr %l4
  %t7 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t10 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %t13, i64 %a3)
  store { i64, i64 } %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load { i64, i64 }, ptr %l17
  store { i64, i64 } %t18, ptr %l7
  %t19 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = extractvalue { i64, ptr } { i64 17, ptr @.d120 }, 1
  %t31 = extractvalue { i64, ptr } { i64 17, ptr @.d120 }, 0
  %t33 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t34 = add i64 %t31, %t33
  %t35 = extractvalue { i64, ptr } { i64 13, ptr @.d121 }, 1
  %t36 = extractvalue { i64, ptr } { i64 13, ptr @.d121 }, 0
  %t37 = add i64 %t34, %t36
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t27)
  %t40 = add i64 %t37, %t39
  %t41 = extractvalue { i64, ptr } { i64 16, ptr @.d122 }, 1
  %t42 = extractvalue { i64, ptr } { i64 16, ptr @.d122 }, 0
  %t43 = add i64 %t40, %t42
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 13, ptr @.d123 }, 1
  %t48 = extractvalue { i64, ptr } { i64 13, ptr @.d123 }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 2, ptr @.d124 }, 1
  %t54 = extractvalue { i64, ptr } { i64 2, ptr @.d124 }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t30, i64 %t31)
  %t57 = getelementptr i8, ptr %t56, i64 %t31
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t26)
  %t59 = getelementptr i8, ptr %t57, i64 %t33
  call void @olang_textcopy(ptr %t59, ptr %t35, i64 %t36)
  %t60 = getelementptr i8, ptr %t59, i64 %t36
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t27)
  %t62 = getelementptr i8, ptr %t60, i64 %t39
  call void @olang_textcopy(ptr %t62, ptr %t41, i64 %t42)
  %t63 = getelementptr i8, ptr %t62, i64 %t42
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t20)
  %t65 = getelementptr i8, ptr %t63, i64 %t45
  call void @olang_textcopy(ptr %t65, ptr %t47, i64 %t48)
  %t66 = getelementptr i8, ptr %t65, i64 %t48
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t23)
  %t68 = getelementptr i8, ptr %t66, i64 %t51
  call void @olang_textcopy(ptr %t68, ptr %t53, i64 %t54)
  %t69 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t56, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %a1, { i64, ptr } %t77)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [65536 x i8]
  %l2 = alloca i64
  %l3 = alloca [65536 x i8]
  %l9 = alloca [65536 x i8]
  %l11 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 65536
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [65536 x i8], ptr %l3, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %l3, i64 65536, i1 false)
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/session:Reader", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  %t14 = insertvalue { i64, ptr } undef, i64 65536, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %l1, 1
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l1, i64 65536, i1 false)
  %t17 = load [65536 x i8], ptr %l9
  %t20 = extractvalue { i64, ptr } %t15, 1
  %t21 = extractvalue { i64, ptr } %t15, 0
  %t23 = call i64 @read(i32 %t12, ptr %t20, i64 65536)
  store i64 %t23, ptr %l11
  br label %bb1
bb1:
  %t24 = load i64, ptr %l11, !tbaa !24
  store i64 %t24, ptr %l2, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = icmp sle i64 %t25, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/session:Reader", ptr %t29, i32 0, i32 2
  store i1 true, ptr %t31, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/session:Reader", ptr %t33, i32 0, i32 1
  store ptr %t35, ptr %l17, !tbaa !29
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l18, !tbaa !24
  %t37 = load [65536 x i8], ptr %l1
  store i64 65536, ptr %l19, !tbaa !24
  %t38 = icmp sge i64 0, 0
  br i1 %t38, label %bb5, label %bb6
bb5:
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sle i64 0, %t40
  br i1 %t41, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb7:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l19, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb9:
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = getelementptr i8, ptr %l1, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t52 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %s0, ptr %t52, { i64, ptr } %t51)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l61 = alloca %"std/prelude/text:LineIter"
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l70 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i32
  %l88 = alloca i64
  %l89 = alloca i32
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = add i64 %t11, 3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l21, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 13
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb5:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l26, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 10
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l25, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 2
  %t47 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t52 = icmp eq i8 %t50, 13
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 3
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp eq i8 %t63, 10
  store i1 %t65, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l37, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l20, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = add i64 %t77, 3
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp sge i64 %t79, %t80
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t86 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t86, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l52, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  store i64 %t88, ptr %l53, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l54, !tbaa !24
  %t91 = icmp sge i64 0, 0
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = load i64, ptr %l53, !tbaa !24
  %t94 = icmp sle i64 0, %t93
  br i1 %t94, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb25:
  %t96 = load i64, ptr %l53, !tbaa !24
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb27:
  %t100 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l53, !tbaa !24
  %t103 = getelementptr i8, ptr %t101, i64 0
  %t104 = sub i64 %t102, 0
  %t105 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  store i64 -1, ptr %l5, !tbaa !24
  %t111 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t106)
  store %"std/prelude/text:LineIter" %t111, ptr %l61
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb29:
  %t112 = load %"std/prelude/text:LineIter", ptr %l61
  store %"std/prelude/text:LineIter" %t112, ptr %l6
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l6)
  %t115 = extractvalue { i32, { i64, ptr } } %t114, 1
  %t116 = extractvalue { i32, { i64, ptr } } %t114, 0
  store i32 %t116, ptr %l65
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb32, label %ok.118
ok.118:
  store { i64, ptr } %t115, ptr %l64
  br label %bb31
bb31:
  %t119 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t119, ptr %l62, !tbaa !27
  br label %bb36
bb32:
  %t120 = load i32, ptr %l65, !tbaa !23
  %t121 = ashr i32 %t120, 16
  %t123 = icmp eq i32 %t121, 1
  br i1 %t123, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  %t125 = load i32, ptr %l65, !tbaa !23
  %t126 = lshr i32 %t125, 16
  %t127 = and i32 %t125, 65535
  %t128 = icmp eq i32 %t126, 1
  %t129 = select i1 %t128, i32 0, i32 0
  %t130 = icmp eq i32 %t125, 0
  %t131 = shl i32 %t129, 16
  %t132 = or i32 %t131, %t127
  %t133 = select i1 %t130, i32 0, i32 %t132
  call void @__olang_scope_close(ptr %s4)
  %t135 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t133, 0
  store { i32, { i64, ptr } } %t135, ptr %rv
  br label %ret
bb35:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb36:
  %t136 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t139 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t136)
  store { i64, ptr } %t139, ptr %l70
  br label %bb37
bb37:
  %t140 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t140, ptr %l8, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t143 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %s4, { i64, ptr } %t141)
  store { i64, ptr } %t143, ptr %l72
  br label %bb38
bb38:
  %t144 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  %t146 = extractvalue { i64, ptr } %t144, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t150, { i64, ptr } { i64 15, ptr @.d125 })
  store i1 %t152, ptr %l74
  br label %bb39
bb39:
  %t153 = load i1, ptr %l74, !tbaa !21
  br i1 %t153, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t154 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t154, ptr %l76, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t155, 0
  store i64 %t158, ptr %l79, !tbaa !24
  %t159 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l80, !tbaa !24
  %t161 = icmp sge i64 15, 0
  br i1 %t161, label %bb42, label %bb43
bb41:
  br label %bb55
bb42:
  %t163 = load i64, ptr %l79, !tbaa !24
  %t164 = icmp sle i64 15, %t163
  br i1 %t164, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb44:
  %t166 = load i64, ptr %l79, !tbaa !24
  %t167 = load i64, ptr %l80, !tbaa !24
  %t168 = icmp sle i64 %t166, %t167
  br i1 %t168, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb46:
  %t170 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = load i64, ptr %l79, !tbaa !24
  %t173 = getelementptr i8, ptr %t171, i64 15
  %t174 = sub i64 %t172, 15
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t173, 1
  %t178 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %t176)
  store { i64, ptr } %t178, ptr %l85
  br label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb48:
  %t179 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 10)
  %t180 = extractvalue { i32, i64 } %t179, 1
  %t181 = extractvalue { i32, i64 } %t179, 0
  store i32 %t181, ptr %l87
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb50, label %ok.183
ok.183:
  store i64 %t180, ptr %l86
  br label %bb49
bb49:
  %t184 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t185 = load i64, ptr %l86, !tbaa !24
  %t186 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t184, i64 %t185)
  %t187 = extractvalue { i32, i64 } %t186, 1
  %t188 = extractvalue { i32, i64 } %t186, 0
  store i32 %t188, ptr %l89
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb53, label %ok.190
ok.190:
  store i64 %t187, ptr %l88
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb54
bb52:
  %t191 = load i64, ptr %l88, !tbaa !24
  store i64 %t191, ptr %l75, !tbaa !24
  br label %bb54
bb53:
  br label %bb51
bb54:
  %t192 = load i64, ptr %l75, !tbaa !24
  store i64 %t192, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s4)
  br label %bb56
bb56:
  br label %bb30
bb57:
  %t193 = load i64, ptr %l3, !tbaa !24
  %t195 = add i64 %t193, 4
  store i64 %t195, ptr %l9, !tbaa !24
  %t197 = load i64, ptr %l5, !tbaa !24
  %t199 = icmp slt i64 %t197, 0
  br i1 %t199, label %bb58, label %bb59
bb58:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t201, i64 %t202)
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t206 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t206, ptr %rv
  br label %ret
bb61:
  %t207 = load i64, ptr %l2, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load i64, ptr %l5, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t215 = icmp slt i64 %t207, %t212
  br i1 %t215, label %bb62, label %bb63
bb62:
  %t218 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t218, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  %t219 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t219, ptr %l103, !tbaa !27
  %t220 = load i64, ptr %l9, !tbaa !24
  store i64 %t220, ptr %l104, !tbaa !24
  %t221 = load i64, ptr %l9, !tbaa !24
  %t222 = load i64, ptr %l5, !tbaa !24
  %t225 = add i64 %t221, %t222
  store i64 %t225, ptr %l107, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l108, !tbaa !24
  %t228 = load i64, ptr %l104, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  br i1 %t229, label %bb65, label %bb66
bb65:
  %t231 = load i64, ptr %l104, !tbaa !24
  %t232 = load i64, ptr %l107, !tbaa !24
  %t233 = icmp sle i64 %t231, %t232
  br i1 %t233, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb67:
  %t235 = load i64, ptr %l107, !tbaa !24
  %t236 = load i64, ptr %l108, !tbaa !24
  %t237 = icmp sle i64 %t235, %t236
  br i1 %t237, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb69:
  %t239 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = load i64, ptr %l104, !tbaa !24
  %t242 = load i64, ptr %l107, !tbaa !24
  %t243 = getelementptr i8, ptr %t240, i64 %t241
  %t244 = sub i64 %t242, %t241
  %t245 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  %t249 = extractvalue { i64, ptr } %t246, 1
  %t250 = extractvalue { i64, ptr } %t246, 0
  %t251 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t250)
  call void @olang_textcopy(ptr %t251, ptr %t249, i64 %t250)
  %t252 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t254, ptr %lp10
  %t256 = load ptr, ptr %lp10
  store { i64, ptr } %t253, ptr %t256, !tbaa !27
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l9, !tbaa !24
  %t259 = load i64, ptr %l5, !tbaa !24
  %t262 = add i64 %t258, %t259
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t257, i64 %t262)
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb71:
  %t265 = load ptr, ptr %lp10
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  %t268 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t266, 1
  store { i32, { i64, ptr } } %t268, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp ne i8 %t23, 10
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l14, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb2
bb10:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = icmp sge i64 %t34, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = sub i64 %t47, 1
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 13
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l28, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = sub i64 %t59, 1
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb19
bb18:
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l34, !tbaa !24
  br label %bb19
bb19:
  %t65 = load i64, ptr %l34, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  store i64 %t65, ptr %l39, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l40, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l39, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb22:
  %t75 = load i64, ptr %l39, !tbaa !24
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l39, !tbaa !24
  %t82 = getelementptr i8, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = extractvalue { i64, ptr } %t85, 0
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @olang_textcopy(ptr %t90, ptr %t88, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t93, ptr %lp5
  %t95 = load ptr, ptr %lp5
  store { i64, ptr } %t92, ptr %t95, !tbaa !27
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load i64, ptr %l3, !tbaa !24
  %t99 = add i64 %t97, 1
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t96, i64 %t99)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb26:
  %t102 = load ptr, ptr %lp5
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t103, 1
  store { i32, { i64, ptr } } %t105, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca i8
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:Reader", ptr %t57, i32 0, i32 1
  store ptr %t59, ptr %l39, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = sub i64 %t60, %t61
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/session:Reader", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t67, i64 %t68)
  store i8 %t71, ptr %l46
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i8, ptr %l46, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t72, i64 %t73, i8 %t74)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l7, !tbaa !24
  br label %bb8
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/session:Reader", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l2, !tbaa !24
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = sub i64 %t82, %t83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %t81, i64 %t86)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l34 = alloca ptr
  %l44 = alloca i64
  %l49 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca i1
  %l65 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l80 = alloca i64
  %l95 = alloca i32
  %l103 = alloca i32
  %l108 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca %"compiler/source:Span"
  %l125 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i1
  %t142 = alloca { i64, [6 x i64] }, align 8
  %t181 = alloca { i64, [6 x i64] }, align 8
  %t302 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:finder", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sgt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/session:finder", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = icmp sgt i64 %t16, %t20
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t25 = load i1, ptr %l17, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l23, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l24, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { i32 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb53
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/session:finder", ptr %t41, i32 0, i32 3
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 11
  %t47 = load i32, ptr %l3, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t52 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t46, i64 %t49)
  store ptr %t52, ptr %l34
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l34, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  store { i64, [2 x i64] } %t57, ptr %l5
  %t59 = load { i64, [2 x i64] }, ptr %l5
  %t61 = extractvalue { i64, [2 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t65 = getelementptr { i64 }, ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65
  store i64 %t66, ptr %l6, !tbaa !24
  br label %bb15
bb14:
  br label %bb30
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/session:finder", ptr %t68, i32 0, i32 3
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l44
  br label %bb16
bb16:
  %t79 = load i64, ptr %l44, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/session:finder", ptr %t80, i32 0, i32 3
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l49, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/session:finder", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t99, i64 %t100)
  store ptr %t103, ptr %l54
  br label %bb17
bb17:
  %t104 = load ptr, ptr %l54, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Func", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t108 = load ptr, ptr %l49, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t108, i32 %t107)
  store { i64, ptr } %t110, ptr %l57
  br label %bb18
bb18:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/session:finder", ptr %t111, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t117 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t115, { i64, ptr } %t114)
  store i1 %t117, ptr %l60
  br label %bb19
bb19:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb20, label %bb21
bb20:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/session:finder", ptr %t119, i32 0, i32 3
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t126 = load i64, ptr %l7, !tbaa !24
  %t129 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l65
  br label %bb22
bb21:
  br label %bb29
bb22:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Func", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb23, label %bb24
bb23:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t141 = load i64, ptr %l7, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [6 x i64] }, ptr %t142, i32 0, i32 0
  store i64 2, ptr %t143
  %t145 = insertvalue { i64 } undef, i64 %t141, 0
  %t146 = getelementptr { i64, [6 x i64] }, ptr %t142, i32 0, i32 1
  store { i64 } %t145, ptr %t146
  %t147 = load { i64, [6 x i64] }, ptr %t142
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, { i64, [6 x i64] } %t147)
  br label %bb25
bb24:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l74, !tbaa !29
  %t152 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t152, ptr %l75
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/session:finder", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l7, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l80
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/session:finder", ptr %t164, i32 0, i32 2
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t169, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [6 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load i64, ptr %l80, !tbaa !24
  %t184 = insertvalue { i64, { i64, ptr } } undef, i64 %t183, 0
  %t186 = insertvalue { i64, { i64, ptr } } %t184, { i64, ptr } %t180, 1
  %t187 = getelementptr { i64, [6 x i64] }, ptr %t181, i32 0, i32 1
  store { i64, { i64, ptr } } %t186, ptr %t187
  %t188 = load { i64, [6 x i64] }, ptr %t181
  %t189 = load ptr, ptr %l74, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l75
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t189, %"compiler/source:Span" %t190, { i64, [6 x i64] } %t188)
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb52
bb30:
  %t192 = load { i64, [2 x i64] }, ptr %l5
  %t194 = extractvalue { i64, [2 x i64] } %t192, 0
  %t195 = icmp eq i64 %t194, 1
  br i1 %t195, label %bb31, label %bb32
bb31:
  %t197 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t198 = getelementptr { i32, i32 }, ptr %t197, i32 0, i32 0
  %t199 = load i32, ptr %t198
  store i32 %t199, ptr %l8, !tbaa !23
  br label %bb33
bb32:
  br label %bb47
bb33:
  %t201 = load i32, ptr %l8, !tbaa !23
  store i32 %t201, ptr %l9, !tbaa !23
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/session:finder", ptr %t203, i32 0, i32 3
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l9, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l95
  br label %bb34
bb34:
  %t216 = load i32, ptr %l95
  %t218 = trunc i64 18 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb35, label %bb36
bb35:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/session:finder", ptr %t221, i32 0, i32 3
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = load i32, ptr %l9, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l103
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t234 = load i32, ptr %l103, !tbaa !23
  store i32 %t234, ptr %l10, !tbaa !23
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/session:finder", ptr %t235, i32 0, i32 3
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 0
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/load:Loader", ptr %t244, i32 0, i32 3
  %t247 = load ptr, ptr %t246, !tbaa !29
  store ptr %t247, ptr %l108, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/session:finder", ptr %t248, i32 0, i32 3
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = getelementptr %"compiler/check:Checker", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t256 = getelementptr %"compiler/generic:Program", ptr %t254, i32 0, i32 2
  %t257 = load i32, ptr %l10, !tbaa !23
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t256, i32 %t257)
  store i32 %t260, ptr %l114
  br label %bb38
bb38:
  %t261 = load ptr, ptr %l108, !tbaa !29
  %t262 = load i32, ptr %l114, !tbaa !23
  %t263 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t261, i32 %t262)
  store { i64, ptr } %t263, ptr %l115
  br label %bb39
bb39:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/session:finder", ptr %t264, i32 0, i32 2
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t270 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t268, { i64, ptr } %t267)
  store i1 %t270, ptr %l118
  br label %bb40
bb40:
  %t271 = load i1, ptr %l118, !tbaa !21
  br i1 %t271, label %bb41, label %bb42
bb41:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l119, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t273, ptr %l120
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/session:finder", ptr %t274, i32 0, i32 3
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/check:Checker", ptr %t277, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t281 = load i32, ptr %l10, !tbaa !23
  %t284 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t280, i32 %t281)
  store i64 %t284, ptr %l125
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/session:finder", ptr %t285, i32 0, i32 2
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 1
  %t291 = extractvalue { i64, ptr } %t288, 0
  %t292 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t290, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t302
  %t303 = getelementptr { i64, [6 x i64] }, ptr %t302, i32 0, i32 0
  store i64 1, ptr %t303
  %t304 = load i64, ptr %l125, !tbaa !24
  %t305 = insertvalue { i64, { i64, ptr } } undef, i64 %t304, 0
  %t307 = insertvalue { i64, { i64, ptr } } %t305, { i64, ptr } %t301, 1
  %t308 = getelementptr { i64, [6 x i64] }, ptr %t302, i32 0, i32 1
  store { i64, { i64, ptr } } %t307, ptr %t308
  %t309 = load { i64, [6 x i64] }, ptr %t302
  %t310 = load ptr, ptr %l119, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l120
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t310, %"compiler/source:Span" %t311, { i64, [6 x i64] } %t309)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_a3421b14f56bfb72_e21214c32a246516)
  unreachable
bb52:
  br label %bb65
bb53:
  %t313 = load ptr, ptr %l2, !tbaa !29
  store ptr %t313, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t314 = load ptr, ptr %l131, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb54, label %bb55
bb54:
  %t317 = load ptr, ptr %l131, !tbaa !29
  %t318 = load i64, ptr %t317
  %t320 = icmp eq i64 %t318, 2
  store i1 %t320, ptr %l132, !tbaa !21
  br label %bb55
bb55:
  %t321 = load i1, ptr %l132, !tbaa !21
  br i1 %t321, label %bb56, label %bb57
bb56:
  %t322 = load ptr, ptr %l2, !tbaa !29
  %t324 = getelementptr { i64, [3 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { ptr }, ptr %t324, i32 0, i32 0
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l11, !tbaa !29
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t328, ptr %t329)
  br label %bb59
bb59:
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3aa7b4b0f3deff3_f1c3bb5d68daf437)
  unreachable
bb65:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l121 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca i1
  %l143 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l180 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca i1
  %l206 = alloca ptr
  %l207 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i1
  %l237 = alloca { i64, ptr }
  %l248 = alloca ptr
  %l249 = alloca i1
  %l262 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l289 = alloca { i64, ptr }
  %l313 = alloca ptr
  %l321 = alloca ptr
  %l329 = alloca ptr
  %l330 = alloca i1
  %l346 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %l370 = alloca ptr
  %l371 = alloca i1
  %l378 = alloca ptr
  %l379 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca i1
  %l404 = alloca { i64, ptr }
  %l418 = alloca ptr
  %l426 = alloca ptr
  %l427 = alloca i1
  %l435 = alloca ptr
  %l436 = alloca i1
  %l449 = alloca { i64, ptr }
  %l452 = alloca ptr
  %l453 = alloca i1
  %l463 = alloca ptr
  %l464 = alloca i1
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %t719 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t6 = load ptr, ptr %l70, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l70, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l71, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l71, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t21 = load ptr, ptr %l76, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l76, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l77, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l77, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t36 = load ptr, ptr %l82, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l82, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l83, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l83, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  br label %bb17
bb17:
  br label %bb241
bb18:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t56 = load ptr, ptr %l91, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l91, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l92, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l92, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Promote", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  br label %bb24
bb24:
  br label %bb241
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t79 = load ptr, ptr %l101, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l101, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l102, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l102, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l4
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l4
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %t99, %"compiler/source:Span" %t100, ptr %t104)
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Call", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l121, !tbaa !27
  %t126 = load i64, ptr %l7, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr ptr, ptr %t129, i64 %t126
  %t131 = load ptr, ptr %t130, !tbaa !39
  %t133 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t133, ptr %t131)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l7, !tbaa !24
  br label %bb32
bb38:
  br label %bb241
bb39:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t143 = load ptr, ptr %l129, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t146 = load ptr, ptr %l129, !tbaa !29
  %t147 = load i64, ptr %t146
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l130, !tbaa !21
  br label %bb41
bb41:
  %t150 = load i1, ptr %l130, !tbaa !21
  br i1 %t150, label %bb42, label %bb43
bb42:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t157 = load ptr, ptr %l10, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Make", ptr %t157, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  store i64 %t164, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  %t166 = load i64, ptr %l12, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t174 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t174, ptr %l143, !tbaa !27
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t182 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t182, ptr %t180)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb50:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l12, !tbaa !24
  br label %bb45
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Make", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t191, ptr %t195)
  br label %bb52
bb52:
  br label %bb241
bb53:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t199 = load ptr, ptr %l154, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb54, label %bb55
bb54:
  %t202 = load ptr, ptr %l154, !tbaa !29
  %t203 = load i64, ptr %t202
  %t205 = icmp eq i64 %t203, 8
  store i1 %t205, ptr %l155, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l155, !tbaa !21
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t209, i32 0, i32 2
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l15, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l15, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Collect", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t213, ptr %t217)
  br label %bb59
bb59:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Collect", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t220, ptr %t224)
  br label %bb60
bb60:
  br label %bb241
bb61:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t229 = load ptr, ptr %l167, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t232 = load ptr, ptr %l167, !tbaa !29
  %t233 = load i64, ptr %t232
  %t235 = icmp eq i64 %t233, 9
  store i1 %t235, ptr %l168, !tbaa !21
  br label %bb63
bb63:
  %t236 = load i1, ptr %l168, !tbaa !21
  br i1 %t236, label %bb64, label %bb65
bb64:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t239, i32 0, i32 4
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t243 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t243, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s15
  %t249 = load i64, ptr %l18, !tbaa !24
  %t250 = load i64, ptr %l19, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s15)
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t257 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t257, ptr %l180, !tbaa !27
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  %t265 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t265, ptr %t263)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s15)
  br label %bb72
bb72:
  %t270 = load i64, ptr %l18, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l18, !tbaa !24
  br label %bb67
bb73:
  br label %bb241
bb74:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t275 = load ptr, ptr %l188, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb75, label %bb76
bb75:
  %t278 = load ptr, ptr %l188, !tbaa !29
  %t279 = load i64, ptr %t278
  %t281 = icmp eq i64 %t279, 10
  store i1 %t281, ptr %l189, !tbaa !21
  br label %bb76
bb76:
  %t282 = load i1, ptr %l189, !tbaa !21
  br i1 %t282, label %bb77, label %bb78
bb77:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l21, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l21, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Slice", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t289, ptr %t293)
  br label %bb80
bb80:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l21, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Slice", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t297, ptr %t301)
  br label %bb81
bb81:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l21, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Slice", ptr %t306, i32 0, i32 2
  %t309 = load ptr, ptr %t308, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t305, ptr %t309)
  br label %bb82
bb82:
  br label %bb241
bb83:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t314 = load ptr, ptr %l206, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb84, label %bb85
bb84:
  %t317 = load ptr, ptr %l206, !tbaa !29
  %t318 = load i64, ptr %t317
  %t320 = icmp eq i64 %t318, 11
  store i1 %t320, ptr %l207, !tbaa !21
  br label %bb85
bb85:
  %t321 = load i1, ptr %l207, !tbaa !21
  br i1 %t321, label %bb86, label %bb87
bb86:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t324, i32 0, i32 2
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l22, !tbaa !29
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l22, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Cond", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t328, ptr %t332)
  br label %bb89
bb89:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l22, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Cond", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t336, ptr %t340)
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l22, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Cond", ptr %t344, i32 0, i32 2
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t343, ptr %t347)
  br label %bb91
bb91:
  br label %bb241
bb92:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t352 = load ptr, ptr %l223, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb93, label %bb94
bb93:
  %t355 = load ptr, ptr %l223, !tbaa !29
  %t356 = load i64, ptr %t355
  %t358 = icmp eq i64 %t356, 12
  store i1 %t358, ptr %l224, !tbaa !21
  br label %bb94
bb94:
  %t359 = load i1, ptr %l224, !tbaa !21
  br i1 %t359, label %bb95, label %bb96
bb95:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t362, i32 0, i32 2
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb106
bb97:
  %t366 = load ptr, ptr %l23, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Seq", ptr %t366, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  store { i64, ptr } %t369, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  store i64 %t373, ptr %l26, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s21
  %t375 = load i64, ptr %l25, !tbaa !24
  %t376 = load i64, ptr %l26, !tbaa !24
  %t379 = icmp slt i64 %t375, %t376
  %t381 = xor i1 %t379, true
  br i1 %t381, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s21)
  br label %bb104
bb100:
  br label %bb101
bb101:
  %t383 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t383, ptr %l237, !tbaa !27
  %t384 = load i64, ptr %l25, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr ptr, ptr %t387, i64 %t384
  %t389 = load ptr, ptr %t388, !tbaa !39
  %t391 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %t391, ptr %t389)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s21)
  br label %bb103
bb103:
  %t396 = load i64, ptr %l25, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l25, !tbaa !24
  br label %bb98
bb104:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l23, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Seq", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t400, ptr %t404)
  br label %bb105
bb105:
  br label %bb241
bb106:
  %t407 = load ptr, ptr %l1, !tbaa !29
  store ptr %t407, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t408 = load ptr, ptr %l248, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb107, label %bb108
bb107:
  %t411 = load ptr, ptr %l248, !tbaa !29
  %t412 = load i64, ptr %t411
  %t414 = icmp eq i64 %t412, 13
  store i1 %t414, ptr %l249, !tbaa !21
  br label %bb108
bb108:
  %t415 = load i1, ptr %l249, !tbaa !21
  br i1 %t415, label %bb109, label %bb110
bb109:
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t418, i32 0, i32 2
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l28, !tbaa !29
  br label %bb111
bb110:
  br label %bb146
bb111:
  %t422 = load ptr, ptr %l28, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Match", ptr %t422, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  store { i64, ptr } %t425, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t427 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t427, 0
  store i64 %t429, ptr %l31, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s25
  %t431 = load i64, ptr %l30, !tbaa !24
  %t432 = load i64, ptr %l31, !tbaa !24
  %t435 = icmp slt i64 %t431, %t432
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s25)
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t439 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t439, ptr %l262, !tbaa !27
  %t440 = load i64, ptr %l30, !tbaa !24
  %t442 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr ptr, ptr %t443, i64 %t440
  %t445 = load ptr, ptr %t444, !tbaa !39
  %t447 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %t447, ptr %t445)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s25)
  br label %bb117
bb117:
  %t452 = load i64, ptr %l30, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l30, !tbaa !24
  br label %bb112
bb118:
  %t456 = load ptr, ptr %l28, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Match", ptr %t456, i32 0, i32 1
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  store { i64, ptr } %t459, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t461 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t461, 0
  store i64 %t463, ptr %l35, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s28
  %t465 = load i64, ptr %l34, !tbaa !24
  %t466 = load i64, ptr %l35, !tbaa !24
  %t469 = icmp slt i64 %t465, %t466
  %t471 = xor i1 %t469, true
  br i1 %t471, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s28)
  br label %bb134
bb121:
  br label %bb122
bb122:
  %t473 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t473, ptr %l278, !tbaa !27
  %t474 = load i64, ptr %l34, !tbaa !24
  %t476 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = getelementptr ptr, ptr %t477, i64 %t474
  %t479 = load ptr, ptr %t478, !tbaa !39
  store ptr %t479, ptr %l36, !tbaa !29
  %t481 = load ptr, ptr %l36, !tbaa !29
  %t483 = getelementptr %"compiler/typed:Arm", ptr %t481, i32 0, i32 1
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  store i64 %t488, ptr %l39, !tbaa !24
  br label %bb123
bb123:
  store %olang.scope zeroinitializer, ptr %s30
  %t490 = load i64, ptr %l38, !tbaa !24
  %t491 = load i64, ptr %l39, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s30)
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t498 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t498, ptr %l289, !tbaa !27
  %t499 = load i64, ptr %l38, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t499
  %t504 = load ptr, ptr %t503, !tbaa !39
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/typed:Alt", ptr %t504, i32 0, i32 0
  %t510 = load ptr, ptr %t509, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t510)
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s30)
  br label %bb128
bb128:
  %t514 = load i64, ptr %l38, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l38, !tbaa !24
  br label %bb123
bb129:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l36, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Arm", ptr %t519, i32 0, i32 2
  %t522 = load ptr, ptr %t521, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t518, ptr %t522)
  br label %bb130
bb130:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l36, !tbaa !29
  %t528 = getelementptr %"compiler/typed:Arm", ptr %t526, i32 0, i32 3
  %t529 = load ptr, ptr %t528, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t525, ptr %t529)
  br label %bb131
bb131:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load ptr, ptr %l36, !tbaa !29
  %t535 = getelementptr %"compiler/typed:Arm", ptr %t533, i32 0, i32 4
  %t536 = load ptr, ptr %t535, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t532, ptr %t536)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s28)
  br label %bb133
bb133:
  %t539 = load i64, ptr %l34, !tbaa !24
  %t541 = add i64 %t539, 1
  store i64 %t541, ptr %l34, !tbaa !24
  br label %bb119
bb134:
  %t543 = load ptr, ptr %l28, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Match", ptr %t543, i32 0, i32 2
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb135, label %bb136
bb135:
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l313, !tbaa !29
  %t553 = load ptr, ptr %l28, !tbaa !29
  %t555 = getelementptr %"compiler/typed:Match", ptr %t553, i32 0, i32 2
  %t556 = load ptr, ptr %t555, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb137, label %bb138
bb136:
  br label %bb145
bb137:
  call void @__olang_check_failed(ptr @olang_loc_6c2d06947719abd6_25c6135ab70ee42)
  unreachable
bb138:
  br label %bb139
bb139:
  %t560 = load ptr, ptr %l28, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Match", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Arm", ptr %t563, i32 0, i32 3
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t568 = load ptr, ptr %l313, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t568, ptr %t567)
  br label %bb140
bb140:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l321, !tbaa !29
  %t571 = load ptr, ptr %l28, !tbaa !29
  %t573 = getelementptr %"compiler/typed:Match", ptr %t571, i32 0, i32 2
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = icmp eq ptr %t574, null
  br i1 %t576, label %bb141, label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_a4411270f97f17bd_30632737f0d2da29)
  unreachable
bb142:
  br label %bb143
bb143:
  %t578 = load ptr, ptr %l28, !tbaa !29
  %t580 = getelementptr %"compiler/typed:Match", ptr %t578, i32 0, i32 2
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Arm", ptr %t581, i32 0, i32 4
  %t585 = load ptr, ptr %t584, !tbaa !29
  %t586 = load ptr, ptr %l321, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t585)
  br label %bb144
bb144:
  br label %bb145
bb145:
  br label %bb241
bb146:
  %t588 = load ptr, ptr %l1, !tbaa !29
  store ptr %t588, ptr %l329, !tbaa !29
  store i1 false, ptr %l330, !tbaa !21
  %t589 = load ptr, ptr %l329, !tbaa !29
  %t590 = icmp ne ptr %t589, null
  br i1 %t590, label %bb147, label %bb148
bb147:
  %t592 = load ptr, ptr %l329, !tbaa !29
  %t593 = load i64, ptr %t592
  %t595 = icmp eq i64 %t593, 14
  store i1 %t595, ptr %l330, !tbaa !21
  br label %bb148
bb148:
  %t596 = load i1, ptr %l330, !tbaa !21
  br i1 %t596, label %bb149, label %bb150
bb149:
  %t597 = load ptr, ptr %l1, !tbaa !29
  %t599 = getelementptr { i64, [5 x i64] }, ptr %t597, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t599, i32 0, i32 2
  %t601 = load ptr, ptr %t600
  store ptr %t601, ptr %l41, !tbaa !29
  br label %bb151
bb150:
  br label %bb167
bb151:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l41, !tbaa !29
  %t606 = getelementptr %"compiler/typed:Try", ptr %t604, i32 0, i32 0
  %t607 = load ptr, ptr %t606, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t603, ptr %t607)
  br label %bb152
bb152:
  %t610 = load ptr, ptr %l41, !tbaa !29
  %t612 = getelementptr %"compiler/typed:Try", ptr %t610, i32 0, i32 1
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  store { i64, ptr } %t613, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t615 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  store i64 %t617, ptr %l44, !tbaa !24
  br label %bb153
bb153:
  store %olang.scope zeroinitializer, ptr %s36
  %t619 = load i64, ptr %l43, !tbaa !24
  %t620 = load i64, ptr %l44, !tbaa !24
  %t623 = icmp slt i64 %t619, %t620
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s36)
  br label %bb166
bb155:
  br label %bb156
bb156:
  %t627 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t627, ptr %l346, !tbaa !27
  %t628 = load i64, ptr %l43, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr ptr, ptr %t631, i64 %t628
  %t633 = load ptr, ptr %t632, !tbaa !39
  store ptr %t633, ptr %l45, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load ptr, ptr %l45, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Clause", ptr %t636, i32 0, i32 3
  %t639 = load ptr, ptr %t638, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t635, ptr %t639)
  br label %bb157
bb157:
  %t642 = load ptr, ptr %l45, !tbaa !29
  %t644 = getelementptr %"compiler/typed:Clause", ptr %t642, i32 0, i32 4
  %t645 = load { i64, ptr }, ptr %t644, !tbaa !27
  store { i64, ptr } %t645, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t647 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t647, 0
  store i64 %t649, ptr %l48, !tbaa !24
  br label %bb158
bb158:
  store %olang.scope zeroinitializer, ptr %s38
  %t651 = load i64, ptr %l47, !tbaa !24
  %t652 = load i64, ptr %l48, !tbaa !24
  %t655 = icmp slt i64 %t651, %t652
  %t657 = xor i1 %t655, true
  br i1 %t657, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s38)
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t659 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t659, ptr %l360, !tbaa !27
  %t660 = load i64, ptr %l47, !tbaa !24
  %t662 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = getelementptr ptr, ptr %t663, i64 %t660
  %t665 = load ptr, ptr %t664, !tbaa !39
  %t667 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t667, ptr %t665)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s38)
  br label %bb163
bb163:
  %t672 = load i64, ptr %l47, !tbaa !24
  %t674 = add i64 %t672, 1
  store i64 %t674, ptr %l47, !tbaa !24
  br label %bb158
bb164:
  call void @__olang_scope_close(ptr %s36)
  br label %bb165
bb165:
  %t676 = load i64, ptr %l43, !tbaa !24
  %t678 = add i64 %t676, 1
  store i64 %t678, ptr %l43, !tbaa !24
  br label %bb153
bb166:
  br label %bb241
bb167:
  %t680 = load ptr, ptr %l1, !tbaa !29
  store ptr %t680, ptr %l370, !tbaa !29
  store i1 false, ptr %l371, !tbaa !21
  %t681 = load ptr, ptr %l370, !tbaa !29
  %t682 = icmp ne ptr %t681, null
  br i1 %t682, label %bb168, label %bb169
bb168:
  %t684 = load ptr, ptr %l370, !tbaa !29
  %t685 = load i64, ptr %t684
  %t687 = icmp eq i64 %t685, 15
  store i1 %t687, ptr %l371, !tbaa !21
  br label %bb169
bb169:
  %t688 = load i1, ptr %l371, !tbaa !21
  br i1 %t688, label %bb170, label %bb171
bb170:
  %t689 = load ptr, ptr %l1, !tbaa !29
  %t691 = getelementptr { i64, [5 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t691, i32 0, i32 0
  %t693 = load %"compiler/source:Span", ptr %t692
  store %"compiler/source:Span" %t693, ptr %l50
  %t695 = load ptr, ptr %l1, !tbaa !29
  %t697 = getelementptr { i64, [5 x i64] }, ptr %t695, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t697, i32 0, i32 2
  %t699 = load ptr, ptr %t698
  store ptr %t699, ptr %l51, !tbaa !29
  br label %bb172
bb171:
  br label %bb206
bb172:
  %t701 = load ptr, ptr %l51, !tbaa !29
  store ptr %t701, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t702 = load ptr, ptr %l378, !tbaa !29
  %t703 = icmp ne ptr %t702, null
  br i1 %t703, label %bb173, label %bb174
bb173:
  %t705 = load ptr, ptr %l378, !tbaa !29
  %t706 = load i64, ptr %t705
  %t708 = icmp eq i64 %t706, 0
  store i1 %t708, ptr %l379, !tbaa !21
  br label %bb174
bb174:
  %t709 = load i1, ptr %l379, !tbaa !21
  br i1 %t709, label %bb175, label %bb176
bb175:
  %t710 = load ptr, ptr %l51, !tbaa !29
  %t712 = getelementptr { i64, [4 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { i32 }, ptr %t712, i32 0, i32 0
  %t714 = load i32, ptr %t713
  store i32 %t714, ptr %l52, !tbaa !23
  br label %bb177
bb176:
  br label %bb179
bb177:
  store %olang.scope zeroinitializer, ptr %s42
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load %"compiler/source:Span", ptr %l50
  %t718 = load i32, ptr %l52, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t719
  %t720 = getelementptr { i64, [3 x i64] }, ptr %t719, i32 0, i32 0
  store i64 0, ptr %t720
  %t722 = insertvalue { i32 } undef, i32 %t718, 0
  %t723 = getelementptr { i64, [3 x i64] }, ptr %t719, i32 0, i32 1
  store { i32 } %t722, ptr %t723
  %t724 = load { i64, [3 x i64] }, ptr %t719
  %t726 = call ptr @__olang_scope_alloc_a(ptr %s42, i64 32, i64 8)
  store { i64, [3 x i64] } %t724, ptr %t726
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %s42, ptr %t716, %"compiler/source:Span" %t717, ptr %t726)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s42)
  br label %bb205
bb179:
  %t730 = load ptr, ptr %l51, !tbaa !29
  store ptr %t730, ptr %l389, !tbaa !29
  store i1 false, ptr %l390, !tbaa !21
  %t731 = load ptr, ptr %l389, !tbaa !29
  %t732 = icmp ne ptr %t731, null
  br i1 %t732, label %bb180, label %bb181
bb180:
  %t734 = load ptr, ptr %l389, !tbaa !29
  %t735 = load i64, ptr %t734
  %t737 = icmp eq i64 %t735, 1
  store i1 %t737, ptr %l390, !tbaa !21
  br label %bb181
bb181:
  %t738 = load i1, ptr %l390, !tbaa !21
  br i1 %t738, label %bb182, label %bb183
bb182:
  %t739 = load ptr, ptr %l51, !tbaa !29
  %t741 = getelementptr { i64, [4 x i64] }, ptr %t739, i32 0, i32 1
  %t742 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t741, i32 0, i32 0
  %t743 = load i32, ptr %t742
  store i32 %t743, ptr %l53, !tbaa !23
  %t745 = load ptr, ptr %l51, !tbaa !29
  %t747 = getelementptr { i64, [4 x i64] }, ptr %t745, i32 0, i32 1
  %t748 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t747, i32 0, i32 1
  %t749 = load { i64, ptr }, ptr %t748
  store { i64, ptr } %t749, ptr %l54, !tbaa !27
  br label %bb184
bb183:
  br label %bb197
bb184:
  %t751 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t751, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t753 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t755 = extractvalue { i64, ptr } %t753, 0
  store i64 %t755, ptr %l57, !tbaa !24
  br label %bb185
bb185:
  store %olang.scope zeroinitializer, ptr %s45
  %t757 = load i64, ptr %l56, !tbaa !24
  %t758 = load i64, ptr %l57, !tbaa !24
  %t761 = icmp slt i64 %t757, %t758
  %t763 = xor i1 %t761, true
  br i1 %t763, label %bb186, label %bb187
bb186:
  call void @__olang_scope_close(ptr %s45)
  br label %bb191
bb187:
  br label %bb188
bb188:
  %t765 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t765, ptr %l404, !tbaa !27
  %t766 = load i64, ptr %l56, !tbaa !24
  %t768 = getelementptr { i64, ptr }, ptr %l404, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = getelementptr ptr, ptr %t769, i64 %t766
  %t771 = load ptr, ptr %t770, !tbaa !39
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/typed:Capture", ptr %t771, i32 0, i32 1
  %t777 = load ptr, ptr %t776, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t773, ptr %t777)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s45)
  br label %bb190
bb190:
  %t781 = load i64, ptr %l56, !tbaa !24
  %t783 = add i64 %t781, 1
  store i64 %t783, ptr %l56, !tbaa !24
  br label %bb185
bb191:
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t787 = getelementptr %"compiler/session:finder", ptr %t785, i32 0, i32 3
  %t788 = load ptr, ptr %t787, !tbaa !29
  %t790 = getelementptr %"compiler/check:Checker", ptr %t788, i32 0, i32 11
  %t791 = load i32, ptr %l53, !tbaa !23
  %t793 = sext i32 %t791 to i64
  %t796 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t790, i64 %t793)
  store ptr %t796, ptr %l418
  br label %bb192
bb192:
  %t797 = load ptr, ptr %l418, !tbaa !29
  store ptr %t797, ptr %l59, !tbaa !29
  %t798 = load ptr, ptr %l59, !tbaa !29
  %t800 = getelementptr %"compiler/typed:Body", ptr %t798, i32 0, i32 11
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = icmp eq ptr %t801, null
  %t805 = xor i1 %t803, true
  br i1 %t805, label %bb193, label %bb194
bb193:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load ptr, ptr %l59, !tbaa !29
  %t810 = getelementptr %"compiler/typed:Body", ptr %t808, i32 0, i32 11
  %t811 = load ptr, ptr %t810, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v0, ptr %t807, ptr %t811)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb205
bb197:
  %t814 = load ptr, ptr %l51, !tbaa !29
  store ptr %t814, ptr %l426, !tbaa !29
  store i1 false, ptr %l427, !tbaa !21
  %t815 = load ptr, ptr %l426, !tbaa !29
  %t816 = icmp ne ptr %t815, null
  br i1 %t816, label %bb198, label %bb199
bb198:
  %t818 = load ptr, ptr %l426, !tbaa !29
  %t819 = load i64, ptr %t818
  %t821 = icmp eq i64 %t819, 2
  store i1 %t821, ptr %l427, !tbaa !21
  br label %bb199
bb199:
  %t822 = load i1, ptr %l427, !tbaa !21
  br i1 %t822, label %bb200, label %bb201
bb200:
  %t823 = load ptr, ptr %l51, !tbaa !29
  %t825 = getelementptr { i64, [4 x i64] }, ptr %t823, i32 0, i32 1
  %t826 = getelementptr { i32, ptr, i32 }, ptr %t825, i32 0, i32 1
  %t827 = load ptr, ptr %t826
  store ptr %t827, ptr %l60, !tbaa !29
  br label %bb202
bb201:
  br label %bb204
bb202:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t829, ptr %t830)
  br label %bb203
bb203:
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b)
  unreachable
bb205:
  br label %bb241
bb206:
  %t834 = load ptr, ptr %l1, !tbaa !29
  store ptr %t834, ptr %l435, !tbaa !29
  store i1 false, ptr %l436, !tbaa !21
  %t835 = load ptr, ptr %l435, !tbaa !29
  %t836 = icmp ne ptr %t835, null
  br i1 %t836, label %bb207, label %bb208
bb207:
  %t838 = load ptr, ptr %l435, !tbaa !29
  %t839 = load i64, ptr %t838
  %t841 = icmp eq i64 %t839, 16
  store i1 %t841, ptr %l436, !tbaa !21
  br label %bb208
bb208:
  %t842 = load i1, ptr %l436, !tbaa !21
  br i1 %t842, label %bb209, label %bb210
bb209:
  %t843 = load ptr, ptr %l1, !tbaa !29
  %t845 = getelementptr { i64, [5 x i64] }, ptr %t843, i32 0, i32 1
  %t846 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t845, i32 0, i32 2
  %t847 = load ptr, ptr %t846
  store ptr %t847, ptr %l61, !tbaa !29
  br label %bb211
bb210:
  br label %bb230
bb211:
  %t849 = load ptr, ptr %l61, !tbaa !29
  %t851 = getelementptr %"compiler/typed:Text", ptr %t849, i32 0, i32 0
  %t852 = load { i64, ptr }, ptr %t851, !tbaa !27
  store { i64, ptr } %t852, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t854 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t856 = extractvalue { i64, ptr } %t854, 0
  store i64 %t856, ptr %l64, !tbaa !24
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s51
  %t858 = load i64, ptr %l63, !tbaa !24
  %t859 = load i64, ptr %l64, !tbaa !24
  %t862 = icmp slt i64 %t858, %t859
  %t864 = xor i1 %t862, true
  br i1 %t864, label %bb213, label %bb214
bb213:
  call void @__olang_scope_close(ptr %s51)
  br label %bb229
bb214:
  br label %bb215
bb215:
  %t866 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t866, ptr %l449, !tbaa !27
  %t867 = load i64, ptr %l63, !tbaa !24
  %t869 = getelementptr { i64, ptr }, ptr %l449, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !27
  %t871 = getelementptr ptr, ptr %t870, i64 %t867
  %t872 = load ptr, ptr %t871, !tbaa !39
  store ptr %t872, ptr %l65, !tbaa !29
  %t874 = load ptr, ptr %l65, !tbaa !29
  store ptr %t874, ptr %l452, !tbaa !29
  store i1 false, ptr %l453, !tbaa !21
  %t875 = load ptr, ptr %l452, !tbaa !29
  %t876 = icmp ne ptr %t875, null
  br i1 %t876, label %bb216, label %bb217
bb216:
  %t878 = load ptr, ptr %l452, !tbaa !29
  %t879 = load i64, ptr %t878
  %t881 = icmp eq i64 %t879, 1
  store i1 %t881, ptr %l453, !tbaa !21
  br label %bb217
bb217:
  %t882 = load i1, ptr %l453, !tbaa !21
  br i1 %t882, label %bb218, label %bb219
bb218:
  %t883 = load ptr, ptr %l65, !tbaa !29
  %t885 = getelementptr { i64, [2 x i64] }, ptr %t883, i32 0, i32 1
  %t886 = getelementptr { ptr }, ptr %t885, i32 0, i32 0
  %t887 = load ptr, ptr %t886
  store ptr %t887, ptr %l66, !tbaa !29
  br label %bb220
bb219:
  br label %bb222
bb220:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t889, ptr %t890)
  br label %bb221
bb221:
  br label %bb227
bb222:
  br i1 true, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_7a96973d190d0d9e_4b6d703943f97c5a)
  unreachable
bb227:
  call void @__olang_scope_close(ptr %s51)
  br label %bb228
bb228:
  %t894 = load i64, ptr %l63, !tbaa !24
  %t896 = add i64 %t894, 1
  store i64 %t896, ptr %l63, !tbaa !24
  br label %bb212
bb229:
  br label %bb241
bb230:
  %t898 = load ptr, ptr %l1, !tbaa !29
  store ptr %t898, ptr %l463, !tbaa !29
  store i1 false, ptr %l464, !tbaa !21
  %t899 = load ptr, ptr %l463, !tbaa !29
  %t900 = icmp ne ptr %t899, null
  br i1 %t900, label %bb231, label %bb232
bb231:
  %t902 = load ptr, ptr %l463, !tbaa !29
  %t903 = load i64, ptr %t902
  %t905 = icmp eq i64 %t903, 17
  store i1 %t905, ptr %l464, !tbaa !21
  br label %bb232
bb232:
  %t906 = load i1, ptr %l464, !tbaa !21
  br i1 %t906, label %bb233, label %bb234
bb233:
  %t907 = load ptr, ptr %l1, !tbaa !29
  %t909 = getelementptr { i64, [5 x i64] }, ptr %t907, i32 0, i32 1
  %t910 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t909, i32 0, i32 2
  %t911 = load ptr, ptr %t910
  store ptr %t911, ptr %l67, !tbaa !29
  br label %bb235
bb234:
  br label %bb236
bb235:
  br label %bb241
bb236:
  br i1 true, label %bb237, label %bb238
bb237:
  br label %bb239
bb238:
  br label %bb240
bb239:
  br label %bb241
bb240:
  call void @__olang_check_failed(ptr @olang_loc_d73c626185112279_563eb35624dc00ed)
  unreachable
bb241:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l29 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %t90 = alloca { i64, [6 x i64] }, align 8
  %t166 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t6 = load ptr, ptr %l14, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/session:finder", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t35, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/session:finder", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i32, ptr %l4, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l36
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/session:finder", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t65, { i64, ptr } %t64)
  store i1 %t67, ptr %l39
  br label %bb12
bb12:
  %t68 = load i1, ptr %l39, !tbaa !21
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l29, !tbaa !21
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l2
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/session:finder", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [6 x i64] }, ptr %t90, i32 0, i32 0
  store i64 1, ptr %t91
  %t93 = insertvalue { i64, { i64, ptr } } undef, i64 %t72, 0
  %t95 = insertvalue { i64, { i64, ptr } } %t93, { i64, ptr } %t89, 1
  %t96 = getelementptr { i64, [6 x i64] }, ptr %t90, i32 0, i32 1
  store { i64, { i64, ptr } } %t95, ptr %t96
  %t97 = load { i64, [6 x i64] }, ptr %t90
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, { i64, [6 x i64] } %t97)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb64
bb18:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t102 = load ptr, ptr %l48, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load ptr, ptr %l48, !tbaa !29
  %t106 = load i64, ptr %t105
  %t108 = icmp eq i64 %t106, 2
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i1, ptr %l49, !tbaa !21
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  br label %bb24
bb24:
  br label %bb64
bb25:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t129 = load i1, ptr %l58, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 0
  %t134 = load %"compiler/source:Span", ptr %t133
  store %"compiler/source:Span" %t134, ptr %l6
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l7, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 3
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t148 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t149 = load i32, ptr %t148, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/session:finder", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  %t158 = icmp eq i64 %t151, %t155
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l72, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t161, ptr %l73
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t162)
  store i32 %t164, ptr %l75
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load i64, ptr %l8, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [6 x i64] }, ptr %t166, i32 0, i32 0
  store i64 3, ptr %t167
  %t168 = load i32, ptr %l75, !tbaa !23
  %t169 = insertvalue { i32, i64 } undef, i32 %t168, 0
  %t171 = insertvalue { i32, i64 } %t169, i64 %t165, 1
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t166, i32 0, i32 1
  store { i32, i64 } %t171, ptr %t172
  %t173 = load { i64, [6 x i64] }, ptr %t166
  %t174 = load ptr, ptr %l72, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l73
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, { i64, [6 x i64] } %t173)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb36
bb36:
  br label %bb64
bb37:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t183 = load ptr, ptr %l81, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb38, label %bb39
bb38:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 4
  store i1 %t189, ptr %l82, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l82, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l9, !tbaa !29
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t197, ptr %t201)
  br label %bb43
bb43:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l9, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Elem", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t205, ptr %t209)
  br label %bb44
bb44:
  br label %bb64
bb45:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t214 = load ptr, ptr %l95, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb46, label %bb47
bb46:
  %t217 = load ptr, ptr %l95, !tbaa !29
  %t218 = load i64, ptr %t217
  %t220 = icmp eq i64 %t218, 5
  store i1 %t220, ptr %l96, !tbaa !21
  br label %bb47
bb47:
  %t221 = load i1, ptr %l96, !tbaa !21
  br i1 %t221, label %bb48, label %bb49
bb48:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l10, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Payload", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t228, ptr %t232)
  br label %bb51
bb51:
  br label %bb64
bb52:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t237 = load ptr, ptr %l105, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb53, label %bb54
bb53:
  %t240 = load ptr, ptr %l105, !tbaa !29
  %t241 = load i64, ptr %t240
  %t243 = icmp eq i64 %t241, 6
  store i1 %t243, ptr %l106, !tbaa !21
  br label %bb54
bb54:
  %t244 = load i1, ptr %l106, !tbaa !21
  br i1 %t244, label %bb55, label %bb56
bb55:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l11, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t251, ptr %t252)
  br label %bb58
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5)
  unreachable
bb64:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l153 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i1
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb108
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  br label %bb108
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t57 = load ptr, ptr %l46, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l46, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  br label %bb24
bb24:
  br label %bb108
bb25:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l55, !tbaa !29
  %t81 = load i64, ptr %t80
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l56, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/typed:If", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr %"compiler/typed:If", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/typed:If", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t107, ptr %t111)
  br label %bb33
bb33:
  br label %bb108
bb34:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t115 = load ptr, ptr %l72, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb35, label %bb36
bb35:
  %t118 = load ptr, ptr %l72, !tbaa !29
  %t119 = load i64, ptr %t118
  %t121 = icmp eq i64 %t119, 4
  store i1 %t121, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t122 = load i1, ptr %l73, !tbaa !21
  br i1 %t122, label %bb37, label %bb38
bb37:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l7, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  br label %bb41
bb41:
  br label %bb108
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l85, !tbaa !29
  %t149 = load i64, ptr %t148
  %t151 = icmp eq i64 %t149, 6
  store i1 %t151, ptr %l86, !tbaa !21
  br label %bb44
bb44:
  %t152 = load i1, ptr %l86, !tbaa !21
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", ptr }, ptr %t155, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l9, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  br label %bb48
bb48:
  br label %bb108
bb49:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t164 = load ptr, ptr %l93, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb50, label %bb51
bb50:
  %t167 = load ptr, ptr %l93, !tbaa !29
  %t168 = load i64, ptr %t167
  %t170 = icmp eq i64 %t168, 9
  store i1 %t170, ptr %l94, !tbaa !21
  br label %bb51
bb51:
  %t171 = load i1, ptr %l94, !tbaa !21
  br i1 %t171, label %bb52, label %bb53
bb52:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [3 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l10, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t178, ptr %t179)
  br label %bb55
bb55:
  br label %bb108
bb56:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t183 = load ptr, ptr %l101, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb57, label %bb58
bb57:
  %t186 = load ptr, ptr %l101, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 10
  store i1 %t189, ptr %l102, !tbaa !21
  br label %bb58
bb58:
  %t190 = load i1, ptr %l102, !tbaa !21
  br i1 %t190, label %bb59, label %bb60
bb59:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [3 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t193, i32 0, i32 1
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l11, !tbaa !29
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t199, i32 0, i32 2
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l12, !tbaa !29
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  br label %bb62
bb62:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t208, ptr %t209)
  br label %bb63
bb63:
  br label %bb108
bb64:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t213 = load ptr, ptr %l114, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb65, label %bb66
bb65:
  %t216 = load ptr, ptr %l114, !tbaa !29
  %t217 = load i64, ptr %t216
  %t219 = icmp eq i64 %t217, 11
  store i1 %t219, ptr %l115, !tbaa !21
  br label %bb66
bb66:
  %t220 = load i1, ptr %l115, !tbaa !21
  br i1 %t220, label %bb67, label %bb68
bb67:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [3 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr }, ptr %t223, i32 0, i32 1
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l13, !tbaa !29
  br label %bb73
bb68:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l120, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 12
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l121, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l13, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t242, ptr %t243)
  br label %bb74
bb74:
  br label %bb108
bb75:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t248 = load ptr, ptr %l129, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb76, label %bb77
bb76:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 13
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb77
bb77:
  %t255 = load i1, ptr %l130, !tbaa !21
  br i1 %t255, label %bb78, label %bb79
bb78:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l14, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l14, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Join", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t262, ptr %t266)
  br label %bb81
bb81:
  br label %bb108
bb82:
  %t270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t270, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t271 = load ptr, ptr %l139, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb83, label %bb84
bb83:
  %t274 = load ptr, ptr %l139, !tbaa !29
  %t275 = load i64, ptr %t274
  %t277 = icmp eq i64 %t275, 14
  store i1 %t277, ptr %l140, !tbaa !21
  br label %bb84
bb84:
  %t278 = load i1, ptr %l140, !tbaa !21
  br i1 %t278, label %bb85, label %bb86
bb85:
  %t279 = load ptr, ptr %l1, !tbaa !29
  %t281 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l15, !tbaa !29
  br label %bb87
bb86:
  br label %bb96
bb87:
  %t285 = load ptr, ptr %l15, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Spawn", ptr %t285, i32 0, i32 0
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  store i64 %t292, ptr %l18, !tbaa !24
  br label %bb88
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t294 = load i64, ptr %l17, !tbaa !24
  %t295 = load i64, ptr %l18, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb90:
  br label %bb91
bb91:
  %t302 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t302, ptr %l153, !tbaa !27
  %t303 = load i64, ptr %l17, !tbaa !24
  %t305 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !27
  %t307 = getelementptr ptr, ptr %t306, i64 %t303
  %t308 = load ptr, ptr %t307, !tbaa !39
  %t310 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t310, ptr %t308)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  br label %bb93
bb93:
  %t314 = load i64, ptr %l17, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l17, !tbaa !24
  br label %bb88
bb94:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t319 = load ptr, ptr %l15, !tbaa !29
  %t321 = getelementptr %"compiler/typed:Spawn", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t318, ptr %t322)
  br label %bb95
bb95:
  br label %bb108
bb96:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t327 = load ptr, ptr %l164, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb97, label %bb98
bb97:
  %t330 = load ptr, ptr %l164, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 15
  store i1 %t333, ptr %l165, !tbaa !21
  br label %bb98
bb98:
  %t334 = load i1, ptr %l165, !tbaa !21
  br i1 %t334, label %bb99, label %bb100
bb99:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l20, !tbaa !29
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t341, ptr %t342)
  br label %bb102
bb102:
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_9a3dbb58dbc7a31a_5629726f6c293dd6)
  unreachable
bb108:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, [6 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l14 = alloca i1
  %l20 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t11 = sub i64 %t4, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/session:finder", ptr %t17, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = icmp sle i64 %t16, %t20
  br i1 %t23, label %bb1, label %bb2
bb1:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/session:finder", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = icmp sle i64 %t28, %t32
  store i1 %t35, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t37 = load i1, ptr %l14, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/session:finder", ptr %t39, i32 0, i32 6
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp slt i64 %t38, %t42
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = getelementptr %"compiler/session:finder", ptr %t48, i32 0, i32 6
  store i64 %t49, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/session:finder", ptr %t53, i32 0, i32 5
  store { i64, [6 x i64] } %a2, ptr %t57
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca %"compiler/session:symWriter"
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca %"compiler/session:symWriter"
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l60 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l75 = alloca i1
  %l85 = alloca { i64, ptr }
  %l96 = alloca %"compiler/source:Span"
  %l98 = alloca i64
  %l109 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l112 = alloca i64
  %l117 = alloca { i64, ptr }
  %l119 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l128 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca i1
  %l154 = alloca { i64, ptr }
  %l159 = alloca i64
  %l167 = alloca i64
  %l168 = alloca ptr
  %l169 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l199 = alloca %"compiler/session:symWriter"
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l213 = alloca ptr
  %l214 = alloca i1
  %l227 = alloca i64
  %l230 = alloca i64
  %l249 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca ptr
  %l256 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l271 = alloca ptr
  %l272 = alloca i1
  %l283 = alloca { i64, ptr }
  %l288 = alloca i64
  %l304 = alloca %"compiler/session:symWriter"
  %l312 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l324 = alloca i64
  %l344 = alloca ptr
  %l345 = alloca i1
  %l352 = alloca ptr
  %l353 = alloca ptr
  %l354 = alloca { i64, ptr }
  %l356 = alloca i64
  %l358 = alloca i64
  %l359 = alloca i64
  %l375 = alloca ptr
  %l376 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t10 = load ptr, ptr %l45, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l45, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l46, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l46, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [6 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb9
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t25 = load ptr, ptr %l51, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l51, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l52, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l52, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { ptr }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb48
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l60
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 0
  %t52 = getelementptr %"compiler/source:Span", ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t48, i64 %t55, { i64, ptr } %t56)
  store i64 %t60, ptr %l66
  br label %bb11
bb11:
  %t61 = load i64, ptr %l66, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 0, ptr @.d126 }, ptr %l67, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t62, ptr %l68, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l69, !tbaa !24
  %t65 = load i64, ptr %l69, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l70, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l69, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Func", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb17
bb14:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Param", ptr %t96, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  %t104 = xor i1 %t102, true
  store i1 %t104, ptr %l75, !tbaa !21
  br label %bb17
bb17:
  %t106 = load i1, ptr %l75, !tbaa !21
  br i1 %t106, label %bb18, label %bb19
bb18:
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l85, !tbaa !27
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Func", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb20, label %bb21
bb19:
  br label %bb43
bb20:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb21:
  br label %bb22
bb22:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Func", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Param", ptr %t118, i32 0, i32 2
  %t122 = load ptr, ptr %t121, !tbaa !29
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l9, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb24:
  br label %bb25
bb25:
  %t128 = load ptr, ptr %l9, !tbaa !29
  %t130 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t128)
  store %"compiler/source:Span" %t130, ptr %l96
  br label %bb26
bb26:
  %t131 = getelementptr %"compiler/source:Span", ptr %l96, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  %t134 = sext i32 %t132 to i64
  store i64 %t134, ptr %l98, !tbaa !24
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Func", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb28:
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Func", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Param", ptr %t145, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l10, !tbaa !29
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l10, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l109
  br label %bb33
bb33:
  %t158 = getelementptr %"compiler/source:Span", ptr %l109, i32 0, i32 1
  %t159 = load i32, ptr %t158, !tbaa !23
  %t161 = sext i32 %t159 to i64
  store i64 %t161, ptr %l111, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l112, !tbaa !24
  %t164 = load i64, ptr %l98, !tbaa !24
  %t165 = icmp sge i64 %t164, 0
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load i64, ptr %l98, !tbaa !24
  %t168 = load i64, ptr %l111, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  br i1 %t169, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb36:
  %t171 = load i64, ptr %l111, !tbaa !24
  %t172 = load i64, ptr %l112, !tbaa !24
  %t173 = icmp sle i64 %t171, %t172
  br i1 %t173, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb38:
  %t175 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l98, !tbaa !24
  %t178 = load i64, ptr %l111, !tbaa !24
  %t179 = getelementptr i8, ptr %t176, i64 %t177
  %t180 = sub i64 %t178, %t177
  %t181 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = extractvalue { i64, ptr } %t182, 0
  %t186 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t184, i64 %t185)
  %t187 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l117, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l119, !tbaa !24
  %t194 = load i64, ptr %l119, !tbaa !24
  %t195 = icmp eq i64 %t190, %t194
  br i1 %t195, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb40:
  %t197 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l119, !tbaa !24
  %t202 = mul i64 %t201, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  br label %bb42
bb41:
  %t203 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t203, ptr %l8, !tbaa !27
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l121, !tbaa !29
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l122, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t206, ptr %l123, !tbaa !27
  %t207 = load ptr, ptr %l5, !tbaa !29
  %t209 = getelementptr %"compiler/ast:Func", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb44, label %bb45
bb44:
  %t216 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  store i64 %t216, ptr %l128, !tbaa !24
  br label %bb46
bb45:
  %t218 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  store i64 %t218, ptr %l128, !tbaa !24
  br label %bb46
bb46:
  %t220 = load ptr, ptr %l5, !tbaa !29
  %t222 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 0
  %t223 = getelementptr %"compiler/source:Span", ptr %t222, i32 0, i32 0
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = sext i32 %t224 to i64
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Func", ptr %t227, i32 0, i32 0
  %t230 = getelementptr %"compiler/source:Span", ptr %t229, i32 0, i32 1
  %t231 = load i32, ptr %t230, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t234 = load i64, ptr %l7, !tbaa !24
  %t235 = load i64, ptr %l7, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t241 = add i64 %t235, %t238
  %t242 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t243 = load ptr, ptr %l121, !tbaa !29
  %t244 = load ptr, ptr %l122, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t246 = load i64, ptr %l128, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s1, ptr %t243, ptr %t244, { i64, ptr } %t245, i64 %t246, i64 %t226, i64 %t233, i64 %t234, i64 %t241, { i64, ptr } %t242)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s1)
  br label %bb160
bb48:
  %t252 = load ptr, ptr %l2, !tbaa !29
  store ptr %t252, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t253 = load ptr, ptr %l143, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb49, label %bb50
bb49:
  %t256 = load ptr, ptr %l143, !tbaa !29
  %t257 = load i64, ptr %t256
  %t259 = icmp eq i64 %t257, 2
  store i1 %t259, ptr %l144, !tbaa !21
  br label %bb50
bb50:
  %t260 = load i1, ptr %l144, !tbaa !21
  br i1 %t260, label %bb51, label %bb52
bb51:
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t263 = getelementptr { i64, [6 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", ptr }, ptr %t263, i32 0, i32 0
  %t265 = load %"compiler/source:Span", ptr %t264
  store %"compiler/source:Span" %t265, ptr %l11
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr { i64, [6 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l12, !tbaa !29
  br label %bb53
bb52:
  br label %bb92
bb53:
  store %olang.scope zeroinitializer, ptr %s4
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  %t276 = getelementptr %"compiler/ast:TypeDecl", ptr %t274, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  %t280 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t273, i32 %t277)
  store { i64, ptr } %t280, ptr %l154
  br label %bb54
bb54:
  %t281 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t281, ptr %l13, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t283 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t286 = sext i32 %t284 to i64
  %t287 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t291 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t282, i64 %t286, { i64, ptr } %t287)
  store i64 %t291, ptr %l159
  br label %bb55
bb55:
  %t292 = load i64, ptr %l159, !tbaa !24
  store i64 %t292, ptr %l14, !tbaa !24
  %t293 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t293, ptr %l15, !tbaa !24
  %t295 = load ptr, ptr %l12, !tbaa !29
  %t297 = getelementptr %"compiler/ast:TypeDecl", ptr %t295, i32 0, i32 3
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb56, label %bb57
bb56:
  %t304 = load ptr, ptr %l12, !tbaa !29
  %t306 = getelementptr %"compiler/ast:TypeDecl", ptr %t304, i32 0, i32 3
  %t307 = load ptr, ptr %t306, !tbaa !29
  store ptr %t307, ptr %l16, !tbaa !29
  %t309 = load ptr, ptr %l16, !tbaa !29
  store ptr %t309, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t310 = load ptr, ptr %l168, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb58, label %bb59
bb57:
  br label %bb81
bb58:
  %t313 = load ptr, ptr %l168, !tbaa !29
  %t314 = load i64, ptr %t313
  %t316 = icmp eq i64 %t314, 0
  store i1 %t316, ptr %l169, !tbaa !21
  br label %bb59
bb59:
  %t317 = load i1, ptr %l169, !tbaa !21
  br i1 %t317, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t318 = load i64, ptr @G_2ecompiler_2fsession_2eKindStruct, !tbaa !24
  store i64 %t318, ptr %l167, !tbaa !24
  br label %bb80
bb63:
  %t320 = load ptr, ptr %l16, !tbaa !29
  store ptr %t320, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t321 = load ptr, ptr %l173, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb64, label %bb65
bb64:
  %t324 = load ptr, ptr %l173, !tbaa !29
  %t325 = load i64, ptr %t324
  %t327 = icmp eq i64 %t325, 1
  store i1 %t327, ptr %l174, !tbaa !21
  br label %bb65
bb65:
  %t328 = load i1, ptr %l174, !tbaa !21
  br i1 %t328, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t329 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  store i64 %t329, ptr %l167, !tbaa !24
  br label %bb80
bb69:
  %t331 = load ptr, ptr %l16, !tbaa !29
  store ptr %t331, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t332 = load ptr, ptr %l178, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb70, label %bb71
bb70:
  %t335 = load ptr, ptr %l178, !tbaa !29
  %t336 = load i64, ptr %t335
  %t338 = icmp eq i64 %t336, 2
  store i1 %t338, ptr %l179, !tbaa !21
  br label %bb71
bb71:
  %t339 = load i1, ptr %l179, !tbaa !21
  br i1 %t339, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t340 = load i64, ptr @G_2ecompiler_2fsession_2eKindInterface, !tbaa !24
  store i64 %t340, ptr %l167, !tbaa !24
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  %t342 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t342, ptr %l167, !tbaa !24
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_647b5c14292f4276_1cbe6dd578a95e8a)
  unreachable
bb80:
  %t344 = load i64, ptr %l167, !tbaa !24
  store i64 %t344, ptr %l15, !tbaa !24
  br label %bb81
bb81:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t348 = load i64, ptr %l15, !tbaa !24
  %t349 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t350 = load i32, ptr %t349, !tbaa !23
  %t352 = sext i32 %t350 to i64
  %t353 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t354 = load i32, ptr %t353, !tbaa !23
  %t356 = sext i32 %t354 to i64
  %t357 = load i64, ptr %l14, !tbaa !24
  %t358 = load i64, ptr %l14, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t364 = add i64 %t358, %t361
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s4, ptr %t345, ptr %t346, { i64, ptr } %t347, i64 %t348, i64 %t352, i64 %t356, i64 %t357, i64 %t364, { i64, ptr } { i64 0, ptr @.d127 })
  br label %bb82
bb82:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/session:symWriter", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s4, ptr %t376)
  store %"compiler/session:symWriter" %t378, ptr %l199
  br label %bb83
bb83:
  %t379 = load %"compiler/session:symWriter", ptr %l199
  store %"compiler/session:symWriter" %t379, ptr %l17
  %t380 = load ptr, ptr %l12, !tbaa !29
  %t382 = getelementptr %"compiler/ast:TypeDecl", ptr %t380, i32 0, i32 3
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = icmp eq ptr %t383, null
  %t387 = xor i1 %t385, true
  br i1 %t387, label %bb84, label %bb85
bb84:
  store ptr %l17, ptr %l204, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l205, !tbaa !29
  %t390 = load ptr, ptr %l12, !tbaa !29
  %t392 = getelementptr %"compiler/ast:TypeDecl", ptr %t390, i32 0, i32 3
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = icmp eq ptr %t393, null
  br i1 %t395, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_4f7bb28debca73d0_f3d58f15dee72c24)
  unreachable
bb87:
  br label %bb88
bb88:
  %t397 = load ptr, ptr %l12, !tbaa !29
  %t399 = getelementptr %"compiler/ast:TypeDecl", ptr %t397, i32 0, i32 3
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t401 = load ptr, ptr %l3, !tbaa !29
  %t402 = load ptr, ptr %l204, !tbaa !29
  %t403 = load ptr, ptr %l205, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %s4, ptr %v1, ptr %v2, ptr %v3, ptr %t402, ptr %t403, ptr %t400, ptr %t401)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t406 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t406, { i64, ptr } { i64 2, ptr @.d128 })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s4)
  br label %bb160
bb92:
  %t408 = load ptr, ptr %l2, !tbaa !29
  store ptr %t408, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t409 = load ptr, ptr %l213, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb93, label %bb94
bb93:
  %t412 = load ptr, ptr %l213, !tbaa !29
  %t413 = load i64, ptr %t412
  %t415 = icmp eq i64 %t413, 3
  store i1 %t415, ptr %l214, !tbaa !21
  br label %bb94
bb94:
  %t416 = load i1, ptr %l214, !tbaa !21
  br i1 %t416, label %bb95, label %bb96
bb95:
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t419 = getelementptr { i64, [6 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr }, ptr %t419, i32 0, i32 0
  %t421 = load %"compiler/source:Span", ptr %t420
  store %"compiler/source:Span" %t421, ptr %l18
  %t423 = load ptr, ptr %l2, !tbaa !29
  %t425 = getelementptr { i64, [6 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr }, ptr %t425, i32 0, i32 1
  %t427 = load ptr, ptr %t426
  store ptr %t427, ptr %l19, !tbaa !29
  br label %bb97
bb96:
  br label %bb112
bb97:
  store i64 0, ptr %l20, !tbaa !24
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = getelementptr %"compiler/ast:VarDecl", ptr %t429, i32 0, i32 0
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t436 = load i64, ptr %l21, !tbaa !24
  %t437 = load i64, ptr %l20, !tbaa !24
  %t440 = icmp sgt i64 %t436, %t437
  br i1 %t440, label %bb98, label %bb99
bb98:
  %t442 = load i64, ptr %l22, !tbaa !24
  %t444 = icmp sgt i64 %t442, 0
  br i1 %t444, label %bb100, label %bb101
bb99:
  store i64 0, ptr %l227, !tbaa !24
  br label %bb103
bb100:
  %t446 = load i64, ptr %l21, !tbaa !24
  %t447 = load i64, ptr %l20, !tbaa !24
  %t450 = sub i64 %t446, %t447
  %t451 = load i64, ptr %l22, !tbaa !24
  %t454 = add i64 %t450, %t451
  %t456 = sub i64 %t454, 1
  %t457 = load i64, ptr %l22, !tbaa !24
  %t460 = sdiv i64 %t456, %t457
  store i64 %t460, ptr %l230, !tbaa !24
  br label %bb102
bb101:
  store i64 0, ptr %l230, !tbaa !24
  br label %bb102
bb102:
  %t462 = load i64, ptr %l230, !tbaa !24
  store i64 %t462, ptr %l227, !tbaa !24
  br label %bb103
bb103:
  %t463 = load i64, ptr %l227, !tbaa !24
  store i64 %t463, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s13
  %t464 = load i64, ptr %l24, !tbaa !24
  %t465 = load i64, ptr %l23, !tbaa !24
  %t468 = icmp slt i64 %t464, %t465
  %t470 = xor i1 %t468, true
  br i1 %t470, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s13)
  br label %bb111
bb106:
  br label %bb107
bb107:
  %t472 = load i64, ptr %l20, !tbaa !24
  %t473 = load i64, ptr %l24, !tbaa !24
  %t474 = load i64, ptr %l22, !tbaa !24
  %t477 = mul i64 %t473, %t474
  %t480 = add i64 %t472, %t477
  store i64 %t480, ptr %l25, !tbaa !24
  %t482 = load ptr, ptr %l19, !tbaa !29
  %t484 = getelementptr %"compiler/ast:VarDecl", ptr %t482, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  store { i64, ptr } %t485, ptr %l249, !tbaa !27
  %t486 = load i64, ptr %l25, !tbaa !24
  %t488 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr %"compiler/source:Span", ptr %t489, i64 %t486
  %t491 = load %"compiler/source:Span", ptr %t490
  store %"compiler/source:Span" %t491, ptr %l26
  %t493 = load ptr, ptr %l0, !tbaa !29
  store ptr %t493, ptr %l252, !tbaa !29
  %t494 = load ptr, ptr %l1, !tbaa !29
  store ptr %t494, ptr %l253, !tbaa !29
  %t495 = load ptr, ptr %l3, !tbaa !29
  %t496 = load ptr, ptr %l19, !tbaa !29
  %t498 = getelementptr %"compiler/ast:VarDecl", ptr %t496, i32 0, i32 0
  %t499 = load { i64, ptr }, ptr %t498, !tbaa !27
  store { i64, ptr } %t499, ptr %l256, !tbaa !27
  %t500 = load i64, ptr %l25, !tbaa !24
  %t502 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t503 = load ptr, ptr %t502, !tbaa !27
  %t504 = getelementptr i32, ptr %t503, i64 %t500
  %t505 = load i32, ptr %t504, !tbaa !33
  %t508 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t495, i32 %t505)
  store { i64, ptr } %t508, ptr %l259
  br label %bb108
bb108:
  %t509 = load i64, ptr @G_2ecompiler_2fsession_2eKindVariable, !tbaa !24
  %t510 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t511 = load i32, ptr %t510, !tbaa !23
  %t513 = sext i32 %t511 to i64
  %t514 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t515 = load i32, ptr %t514, !tbaa !23
  %t517 = sext i32 %t515 to i64
  %t518 = getelementptr %"compiler/source:Span", ptr %l26, i32 0, i32 0
  %t519 = load i32, ptr %t518, !tbaa !23
  %t521 = sext i32 %t519 to i64
  %t522 = getelementptr %"compiler/source:Span", ptr %l26, i32 0, i32 1
  %t523 = load i32, ptr %t522, !tbaa !23
  %t525 = sext i32 %t523 to i64
  %t526 = load ptr, ptr %l252, !tbaa !29
  %t527 = load ptr, ptr %l253, !tbaa !29
  %t528 = load { i64, ptr }, ptr %l259, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s13, ptr %t526, ptr %t527, { i64, ptr } %t528, i64 %t509, i64 %t513, i64 %t517, i64 %t521, i64 %t525, { i64, ptr } { i64 0, ptr @.d129 })
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s13)
  br label %bb110
bb110:
  %t534 = load i64, ptr %l24, !tbaa !24
  %t536 = add i64 %t534, 1
  store i64 %t536, ptr %l24, !tbaa !24
  br label %bb104
bb111:
  br label %bb160
bb112:
  %t538 = load ptr, ptr %l2, !tbaa !29
  store ptr %t538, ptr %l271, !tbaa !29
  store i1 false, ptr %l272, !tbaa !21
  %t539 = load ptr, ptr %l271, !tbaa !29
  %t540 = icmp ne ptr %t539, null
  br i1 %t540, label %bb113, label %bb114
bb113:
  %t542 = load ptr, ptr %l271, !tbaa !29
  %t543 = load i64, ptr %t542
  %t545 = icmp eq i64 %t543, 5
  store i1 %t545, ptr %l272, !tbaa !21
  br label %bb114
bb114:
  %t546 = load i1, ptr %l272, !tbaa !21
  br i1 %t546, label %bb115, label %bb116
bb115:
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t549 = getelementptr { i64, [6 x i64] }, ptr %t547, i32 0, i32 1
  %t550 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t549, i32 0, i32 0
  %t551 = load %"compiler/source:Span", ptr %t550
  store %"compiler/source:Span" %t551, ptr %l27
  %t553 = load ptr, ptr %l2, !tbaa !29
  %t555 = getelementptr { i64, [6 x i64] }, ptr %t553, i32 0, i32 1
  %t556 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t555, i32 0, i32 1
  %t557 = load i32, ptr %t556
  store i32 %t557, ptr %l28, !tbaa !23
  %t559 = load ptr, ptr %l2, !tbaa !29
  %t561 = getelementptr { i64, [6 x i64] }, ptr %t559, i32 0, i32 1
  %t562 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t561, i32 0, i32 2
  %t563 = load { i64, ptr }, ptr %t562
  store { i64, ptr } %t563, ptr %l29, !tbaa !27
  br label %bb117
bb116:
  br label %bb135
bb117:
  store %olang.scope zeroinitializer, ptr %s15
  %t565 = load ptr, ptr %l3, !tbaa !29
  %t566 = load i32, ptr %l28, !tbaa !23
  %t569 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t565, i32 %t566)
  store { i64, ptr } %t569, ptr %l283
  br label %bb118
bb118:
  %t570 = load { i64, ptr }, ptr %l283, !tbaa !27
  store { i64, ptr } %t570, ptr %l30, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t572 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 0
  %t573 = load i32, ptr %t572, !tbaa !23
  %t575 = sext i32 %t573 to i64
  %t576 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t580 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t571, i64 %t575, { i64, ptr } %t576)
  store i64 %t580, ptr %l288
  br label %bb119
bb119:
  %t581 = load i64, ptr %l288, !tbaa !24
  store i64 %t581, ptr %l31, !tbaa !24
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load ptr, ptr %l1, !tbaa !29
  %t584 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t585 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  %t586 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 0
  %t587 = load i32, ptr %t586, !tbaa !23
  %t589 = sext i32 %t587 to i64
  %t590 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 1
  %t591 = load i32, ptr %t590, !tbaa !23
  %t593 = sext i32 %t591 to i64
  %t594 = load i64, ptr %l31, !tbaa !24
  %t595 = load i64, ptr %l31, !tbaa !24
  %t596 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t596, 0
  %t601 = add i64 %t595, %t598
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s15, ptr %t582, ptr %t583, { i64, ptr } %t584, i64 %t585, i64 %t589, i64 %t593, i64 %t594, i64 %t601, { i64, ptr } { i64 5, ptr @.d130 })
  br label %bb120
bb120:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t612 = getelementptr %"compiler/session:symWriter", ptr %t610, i32 0, i32 0
  %t613 = load ptr, ptr %t612, !tbaa !29
  %t615 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s15, ptr %t613)
  store %"compiler/session:symWriter" %t615, ptr %l304
  br label %bb121
bb121:
  %t616 = load %"compiler/session:symWriter", ptr %l304
  store %"compiler/session:symWriter" %t616, ptr %l32
  %t617 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t617, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t619 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t619, 0
  store i64 %t621, ptr %l35, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s17
  %t623 = load i64, ptr %l34, !tbaa !24
  %t624 = load i64, ptr %l35, !tbaa !24
  %t627 = icmp slt i64 %t623, %t624
  %t629 = xor i1 %t627, true
  br i1 %t629, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb124:
  br label %bb125
bb125:
  %t631 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t631, ptr %l312, !tbaa !27
  %t632 = load i64, ptr %l34, !tbaa !24
  %t634 = getelementptr { i64, ptr }, ptr %l312, i32 0, i32 1
  %t635 = load ptr, ptr %t634, !tbaa !27
  %t636 = getelementptr i32, ptr %t635, i64 %t632
  %t637 = load i32, ptr %t636, !tbaa !33
  %t639 = load ptr, ptr %l3, !tbaa !29
  %t643 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t639, i32 %t637)
  store { i64, ptr } %t643, ptr %l317
  br label %bb126
bb126:
  %t644 = load { i64, ptr }, ptr %l317, !tbaa !27
  store { i64, ptr } %t644, ptr %l37, !tbaa !27
  %t645 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t646 = load i64, ptr %l31, !tbaa !24
  %t647 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t647, 0
  %t652 = add i64 %t646, %t649
  %t653 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t657 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v3, { i64, ptr } %t645, i64 %t652, { i64, ptr } %t653)
  store i64 %t657, ptr %l324
  br label %bb127
bb127:
  %t658 = load i64, ptr %l324, !tbaa !24
  store i64 %t658, ptr %l38, !tbaa !24
  %t659 = load i64, ptr %l38, !tbaa !24
  %t661 = icmp sge i64 %t659, 0
  br i1 %t661, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s18
  %t663 = load ptr, ptr %l1, !tbaa !29
  %t664 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t665 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t666 = load i64, ptr %l38, !tbaa !24
  %t667 = load i64, ptr %l38, !tbaa !24
  %t668 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t670 = extractvalue { i64, ptr } %t668, 0
  %t673 = add i64 %t667, %t670
  %t674 = load i64, ptr %l38, !tbaa !24
  %t675 = load i64, ptr %l38, !tbaa !24
  %t676 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t678 = extractvalue { i64, ptr } %t676, 0
  %t681 = add i64 %t675, %t678
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %s15, ptr %v1, ptr %v3, ptr %s18, ptr %l32, ptr %t663, { i64, ptr } %t664, i64 %t665, i64 %t666, i64 %t673, i64 %t674, i64 %t681, { i64, ptr } { i64 0, ptr @.d131 })
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s18)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s17)
  br label %bb132
bb132:
  %t690 = load i64, ptr %l34, !tbaa !24
  %t692 = add i64 %t690, 1
  store i64 %t692, ptr %l34, !tbaa !24
  br label %bb122
bb133:
  %t694 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s15, ptr %t694, { i64, ptr } { i64 2, ptr @.d132 })
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s15)
  br label %bb160
bb135:
  %t696 = load ptr, ptr %l2, !tbaa !29
  store ptr %t696, ptr %l344, !tbaa !29
  store i1 false, ptr %l345, !tbaa !21
  %t697 = load ptr, ptr %l344, !tbaa !29
  %t698 = icmp ne ptr %t697, null
  br i1 %t698, label %bb136, label %bb137
bb136:
  %t700 = load ptr, ptr %l344, !tbaa !29
  %t701 = load i64, ptr %t700
  %t703 = icmp eq i64 %t701, 6
  store i1 %t703, ptr %l345, !tbaa !21
  br label %bb137
bb137:
  %t704 = load i1, ptr %l345, !tbaa !21
  br i1 %t704, label %bb138, label %bb139
bb138:
  %t705 = load ptr, ptr %l2, !tbaa !29
  %t707 = getelementptr { i64, [6 x i64] }, ptr %t705, i32 0, i32 1
  %t708 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t707, i32 0, i32 0
  %t709 = load %"compiler/source:Span", ptr %t708
  store %"compiler/source:Span" %t709, ptr %l39
  %t711 = load ptr, ptr %l2, !tbaa !29
  %t713 = getelementptr { i64, [6 x i64] }, ptr %t711, i32 0, i32 1
  %t714 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t713, i32 0, i32 1
  %t715 = load %"compiler/source:Span", ptr %t714
  store %"compiler/source:Span" %t715, ptr %l40
  br label %bb140
bb139:
  br label %bb148
bb140:
  store %olang.scope zeroinitializer, ptr %s20
  %t717 = load ptr, ptr %l0, !tbaa !29
  store ptr %t717, ptr %l352, !tbaa !29
  %t718 = load ptr, ptr %l1, !tbaa !29
  store ptr %t718, ptr %l353, !tbaa !29
  %t719 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t719, ptr %l354, !tbaa !27
  %t720 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 0
  %t721 = load i32, ptr %t720, !tbaa !23
  %t723 = sext i32 %t721 to i64
  store i64 %t723, ptr %l356, !tbaa !24
  %t724 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 1
  %t725 = load i32, ptr %t724, !tbaa !23
  %t727 = sext i32 %t725 to i64
  store i64 %t727, ptr %l358, !tbaa !24
  %t728 = load { i64, ptr }, ptr %l354, !tbaa !27
  %t729 = extractvalue { i64, ptr } %t728, 0
  store i64 %t729, ptr %l359, !tbaa !24
  %t730 = load i64, ptr %l356, !tbaa !24
  %t731 = icmp sge i64 %t730, 0
  br i1 %t731, label %bb141, label %bb142
bb141:
  %t733 = load i64, ptr %l356, !tbaa !24
  %t734 = load i64, ptr %l358, !tbaa !24
  %t735 = icmp sle i64 %t733, %t734
  br i1 %t735, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb143:
  %t737 = load i64, ptr %l358, !tbaa !24
  %t738 = load i64, ptr %l359, !tbaa !24
  %t739 = icmp sle i64 %t737, %t738
  br i1 %t739, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb145:
  %t741 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t742 = load ptr, ptr %t741, !tbaa !27
  %t743 = load i64, ptr %l356, !tbaa !24
  %t744 = load i64, ptr %l358, !tbaa !24
  %t745 = getelementptr i8, ptr %t742, i64 %t743
  %t746 = sub i64 %t744, %t743
  %t747 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t748 = insertvalue { i64, ptr } %t747, ptr %t745, 1
  %t749 = extractvalue { i64, ptr } { i64 5, ptr @.d133 }, 1
  %t750 = extractvalue { i64, ptr } { i64 5, ptr @.d133 }, 0
  %t752 = extractvalue { i64, ptr } %t748, 1
  %t753 = extractvalue { i64, ptr } %t748, 0
  %t754 = add i64 %t750, %t753
  %t755 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t754)
  call void @olang_textcopy(ptr %t755, ptr %t749, i64 %t750)
  %t756 = getelementptr i8, ptr %t755, i64 %t750
  call void @olang_textcopy(ptr %t756, ptr %t752, i64 %t753)
  %t757 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t755, 1
  %t760 = extractvalue { i64, ptr } %t758, 0
  %t761 = extractvalue { i64, ptr } %t758, 1
  %t762 = mul i64 %t760, 1
  %t763 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t762)
  call void @llvm.memcpy.p0.p0.i64(ptr %t763, ptr %t761, i64 %t762, i1 false)
  %t764 = insertvalue { i64, ptr } undef, i64 %t760, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  %t766 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  %t767 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 0
  %t768 = load i32, ptr %t767, !tbaa !23
  %t770 = sext i32 %t768 to i64
  %t771 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 1
  %t772 = load i32, ptr %t771, !tbaa !23
  %t774 = sext i32 %t772 to i64
  %t775 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 0
  %t776 = load i32, ptr %t775, !tbaa !23
  %t778 = sext i32 %t776 to i64
  %t779 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 1
  %t780 = load i32, ptr %t779, !tbaa !23
  %t782 = sext i32 %t780 to i64
  %t783 = load ptr, ptr %l352, !tbaa !29
  %t784 = load ptr, ptr %l353, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %s20, ptr %s20, ptr %t783, ptr %t784, { i64, ptr } %t765, i64 %t766, i64 %t770, i64 %t774, i64 %t778, i64 %t782, { i64, ptr } { i64 0, ptr @.d134 })
  br label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb147:
  call void @__olang_scope_close(ptr %s20)
  br label %bb160
bb148:
  %t791 = load ptr, ptr %l2, !tbaa !29
  store ptr %t791, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t792 = load ptr, ptr %l375, !tbaa !29
  %t793 = icmp ne ptr %t792, null
  br i1 %t793, label %bb149, label %bb150
bb149:
  %t795 = load ptr, ptr %l375, !tbaa !29
  %t796 = load i64, ptr %t795
  %t798 = icmp eq i64 %t796, 7
  store i1 %t798, ptr %l376, !tbaa !21
  br label %bb150
bb150:
  %t799 = load i1, ptr %l376, !tbaa !21
  br i1 %t799, label %bb151, label %bb152
bb151:
  %t800 = load ptr, ptr %l2, !tbaa !29
  %t802 = getelementptr { i64, [6 x i64] }, ptr %t800, i32 0, i32 1
  %t803 = getelementptr { %"compiler/source:Span", ptr }, ptr %t802, i32 0, i32 1
  %t804 = load ptr, ptr %t803
  store ptr %t804, ptr %l41, !tbaa !29
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load ptr, ptr %l1, !tbaa !29
  %t808 = load ptr, ptr %l41, !tbaa !29
  %t810 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t806, ptr %t807, ptr %t808, ptr %t810)
  br label %bb154
bb154:
  br label %bb160
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd)
  unreachable
bb160:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8) #0 {
entry:
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t2, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8)
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t19, { i64, ptr } { i64 2, ptr @.d135 })
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i64
  %l92 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l117 = alloca i1
  %l129 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca i1
  %l170 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l182 = alloca i64
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t10 = load ptr, ptr %l35, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l35, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l36, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [6 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb40
bb5:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/ast:StructBody", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = getelementptr %"compiler/ast:StructBody", ptr %t33, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb11:
  br label %bb12
bb12:
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l53, !tbaa !27
  %t51 = load i64, ptr %l7, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l9, !tbaa !29
  %t58 = load ptr, ptr %l9, !tbaa !29
  store ptr %t58, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l56, !tbaa !29
  %t63 = load i64, ptr %t62
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l57, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l57, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t67 = load ptr, ptr %l9, !tbaa !29
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/source:Span", ptr %t70
  store %"compiler/source:Span" %t71, ptr %l10
  %t73 = load ptr, ptr %l9, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l11, !tbaa !29
  br label %bb17
bb16:
  br label %bb32
bb17:
  store i64 0, ptr %l12, !tbaa !24
  %t79 = load ptr, ptr %l11, !tbaa !29
  %t81 = getelementptr %"compiler/ast:VarDecl", ptr %t79, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t86 = load i64, ptr %l13, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb18, label %bb19
bb18:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb23
bb20:
  %t96 = load i64, ptr %l13, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l14, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l14, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l73, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb22
bb22:
  %t112 = load i64, ptr %l73, !tbaa !24
  store i64 %t112, ptr %l70, !tbaa !24
  br label %bb23
bb23:
  %t113 = load i64, ptr %l70, !tbaa !24
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t114 = load i64, ptr %l16, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t122 = load i64, ptr %l12, !tbaa !24
  %t123 = load i64, ptr %l16, !tbaa !24
  %t124 = load i64, ptr %l14, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l17, !tbaa !24
  %t132 = load ptr, ptr %l11, !tbaa !29
  %t134 = getelementptr %"compiler/ast:VarDecl", ptr %t132, i32 0, i32 1
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l92, !tbaa !27
  %t136 = load i64, ptr %l17, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr %"compiler/source:Span", ptr %t139, i64 %t136
  %t141 = load %"compiler/source:Span", ptr %t140
  store %"compiler/source:Span" %t141, ptr %l18
  %t143 = load ptr, ptr %l0, !tbaa !29
  store ptr %t143, ptr %l95, !tbaa !29
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l96, !tbaa !29
  %t145 = load ptr, ptr %l3, !tbaa !29
  %t146 = load ptr, ptr %l11, !tbaa !29
  %t148 = getelementptr %"compiler/ast:VarDecl", ptr %t146, i32 0, i32 0
  %t149 = load { i64, ptr }, ptr %t148, !tbaa !27
  store { i64, ptr } %t149, ptr %l99, !tbaa !27
  %t150 = load i64, ptr %l17, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t158 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t145, i32 %t155)
  store { i64, ptr } %t158, ptr %l102
  br label %bb28
bb28:
  %t159 = load i64, ptr @G_2ecompiler_2fsession_2eKindField, !tbaa !24
  %t160 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t161 = load i32, ptr %t160, !tbaa !23
  %t163 = sext i32 %t161 to i64
  %t164 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 1
  %t165 = load i32, ptr %t164, !tbaa !23
  %t167 = sext i32 %t165 to i64
  %t168 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  %t171 = sext i32 %t169 to i64
  %t172 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  %t175 = sext i32 %t173 to i64
  %t176 = load ptr, ptr %l95, !tbaa !29
  %t177 = load ptr, ptr %l96, !tbaa !29
  %t178 = load { i64, ptr }, ptr %l102, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s7, ptr %t176, ptr %t177, { i64, ptr } %t178, i64 %t159, i64 %t163, i64 %t167, i64 %t171, i64 %t175, { i64, ptr } { i64 0, ptr @.d136 })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t184 = load i64, ptr %l16, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l16, !tbaa !24
  br label %bb24
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_59453385dbeab0f1_a10e94e6ba58edc5)
  unreachable
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb38:
  %t188 = load i64, ptr %l7, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l7, !tbaa !24
  br label %bb9
bb39:
  br label %bb74
bb40:
  %t192 = load ptr, ptr %l2, !tbaa !29
  store ptr %t192, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t193 = load ptr, ptr %l116, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb41, label %bb42
bb41:
  %t196 = load ptr, ptr %l116, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 1
  store i1 %t199, ptr %l117, !tbaa !21
  br label %bb42
bb42:
  %t200 = load i1, ptr %l117, !tbaa !21
  br i1 %t200, label %bb43, label %bb44
bb43:
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t203 = getelementptr { i64, [6 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { { i64, ptr }, ptr }, ptr %t203, i32 0, i32 0
  %t205 = load { i64, ptr }, ptr %t204
  store { i64, ptr } %t205, ptr %l19, !tbaa !27
  br label %bb45
bb44:
  br label %bb54
bb45:
  %t207 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t207, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t213 = load i64, ptr %l21, !tbaa !24
  %t214 = load i64, ptr %l22, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s13)
  br label %bb53
bb48:
  br label %bb49
bb49:
  %t221 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t221, ptr %l129, !tbaa !27
  %t222 = load i64, ptr %l21, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  store ptr %t227, ptr %l23, !tbaa !29
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t230 = load ptr, ptr %l23, !tbaa !29
  %t232 = getelementptr %"compiler/ast:CaseDecl", ptr %t230, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  %t236 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t229, i32 %t233)
  store { i64, ptr } %t236, ptr %l135
  br label %bb50
bb50:
  %t237 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t237, ptr %l24, !tbaa !27
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t241 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t242 = load ptr, ptr %l23, !tbaa !29
  %t244 = getelementptr %"compiler/ast:CaseDecl", ptr %t242, i32 0, i32 0
  %t245 = getelementptr %"compiler/source:Span", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t249 = load ptr, ptr %l23, !tbaa !29
  %t251 = getelementptr %"compiler/ast:CaseDecl", ptr %t249, i32 0, i32 0
  %t252 = getelementptr %"compiler/source:Span", ptr %t251, i32 0, i32 1
  %t253 = load i32, ptr %t252, !tbaa !23
  %t255 = sext i32 %t253 to i64
  %t256 = load ptr, ptr %l23, !tbaa !29
  %t258 = getelementptr %"compiler/ast:CaseDecl", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  %t263 = load ptr, ptr %l23, !tbaa !29
  %t265 = getelementptr %"compiler/ast:CaseDecl", ptr %t263, i32 0, i32 0
  %t266 = getelementptr %"compiler/source:Span", ptr %t265, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t270 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t275 = add i64 %t269, %t272
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s13, ptr %t238, ptr %t239, { i64, ptr } %t240, i64 %t241, i64 %t248, i64 %t255, i64 %t262, i64 %t275, { i64, ptr } { i64 0, ptr @.d137 })
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s13)
  br label %bb52
bb52:
  %t284 = load i64, ptr %l21, !tbaa !24
  %t286 = add i64 %t284, 1
  store i64 %t286, ptr %l21, !tbaa !24
  br label %bb46
bb53:
  br label %bb74
bb54:
  %t288 = load ptr, ptr %l2, !tbaa !29
  store ptr %t288, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t289 = load ptr, ptr %l157, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb55, label %bb56
bb55:
  %t292 = load ptr, ptr %l157, !tbaa !29
  %t293 = load i64, ptr %t292
  %t295 = icmp eq i64 %t293, 2
  store i1 %t295, ptr %l158, !tbaa !21
  br label %bb56
bb56:
  %t296 = load i1, ptr %l158, !tbaa !21
  br i1 %t296, label %bb57, label %bb58
bb57:
  %t297 = load ptr, ptr %l2, !tbaa !29
  %t299 = getelementptr { i64, [6 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t299, i32 0, i32 0
  %t301 = load { i64, ptr }, ptr %t300
  store { i64, ptr } %t301, ptr %l25, !tbaa !27
  br label %bb59
bb58:
  br label %bb69
bb59:
  %t303 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t303, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l28, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s17
  %t309 = load i64, ptr %l27, !tbaa !24
  %t310 = load i64, ptr %l28, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s17)
  br label %bb68
bb62:
  br label %bb63
bb63:
  %t317 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t317, ptr %l170, !tbaa !27
  %t318 = load i64, ptr %l27, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  store ptr %t323, ptr %l29, !tbaa !29
  %t325 = load ptr, ptr %l3, !tbaa !29
  %t326 = load ptr, ptr %l29, !tbaa !29
  %t328 = getelementptr %"compiler/ast:Func", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %t328, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %t325, i32 %t329)
  store { i64, ptr } %t332, ptr %l176
  br label %bb64
bb64:
  %t333 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t333, ptr %l30, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t335 = load ptr, ptr %l29, !tbaa !29
  %t337 = getelementptr %"compiler/ast:Func", ptr %t335, i32 0, i32 0
  %t338 = getelementptr %"compiler/source:Span", ptr %t337, i32 0, i32 0
  %t339 = load i32, ptr %t338, !tbaa !23
  %t341 = sext i32 %t339 to i64
  %t342 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t346 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t334, i64 %t341, { i64, ptr } %t342)
  store i64 %t346, ptr %l182
  br label %bb65
bb65:
  %t347 = load i64, ptr %l182, !tbaa !24
  store i64 %t347, ptr %l31, !tbaa !24
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load ptr, ptr %l1, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t351 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  %t352 = load ptr, ptr %l29, !tbaa !29
  %t354 = getelementptr %"compiler/ast:Func", ptr %t352, i32 0, i32 0
  %t355 = getelementptr %"compiler/source:Span", ptr %t354, i32 0, i32 0
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t359 = load ptr, ptr %l29, !tbaa !29
  %t361 = getelementptr %"compiler/ast:Func", ptr %t359, i32 0, i32 0
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 1
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t366 = load i64, ptr %l31, !tbaa !24
  %t367 = load i64, ptr %l31, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t373 = add i64 %t367, %t370
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s17, ptr %t348, ptr %t349, { i64, ptr } %t350, i64 %t351, i64 %t358, i64 %t365, i64 %t366, i64 %t373, { i64, ptr } { i64 0, ptr @.d138 })
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s17)
  br label %bb67
bb67:
  %t382 = load i64, ptr %l27, !tbaa !24
  %t384 = add i64 %t382, 1
  store i64 %t384, ptr %l27, !tbaa !24
  br label %bb60
bb68:
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_5620e65a2f0e2ce0_731e90c9e662bd14)
  unreachable
bb74:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l39 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t8, i8 44)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = getelementptr %"compiler/session:symWriter", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = add i64 %t13, 1
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = getelementptr %"compiler/session:symWriter", ptr %t17, i32 0, i32 1
  store i64 %t15, ptr %t18, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t19, { i64, ptr } { i64 8, ptr @.d139 })
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l17, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr @.d140 })
  store i1 %t24, ptr %l19
  br label %bb6
bb6:
  %t25 = load i1, ptr %l19, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr @.d141 }, ptr %l21, !tbaa !27
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v2, ptr %t30, { i64, ptr } %t31)
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = extractvalue { i64, ptr } { i64 8, ptr @.d142 }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr @.d142 }, 0
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %a3)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 9, ptr @.d143 }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr @.d143 }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %a3)
  %t45 = getelementptr i8, ptr %t43, i64 %t37
  call void @olang_textcopy(ptr %t45, ptr %t39, i64 %t40)
  %t46 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t42, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t32, { i64, ptr } %t54)
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:symWriter", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %t60, ptr %t61, i64 %a4, i64 %a5)
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t68, { i64, ptr } { i64 18, ptr @.d144 })
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/session:symWriter", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %t73, ptr %t74, i64 %a6, i64 %a7)
  br label %bb14
bb14:
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t81, { i64, ptr } { i64 0, ptr @.d145 })
  store i1 %t83, ptr %l39
  br label %bb15
bb15:
  %t84 = load i1, ptr %l39, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t87, { i64, ptr } { i64 10, ptr @.d146 })
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v3, ptr %t89, { i64, ptr } %t90)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t93, { i64, ptr } { i64 13, ptr @.d147 })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i1
  %l41 = alloca { i64, ptr }
  %l59 = alloca i1
  %l82 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5)
  unreachable
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopIf", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TopBranch", ptr %t24, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sgt i64 %t30, 0
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb12, label %bb13
bb11:
  br label %bb22
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7c90741a89491e92_62c7d4207901162e)
  unreachable
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TopIf", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TopBranch", ptr %t45, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t63, ptr %l41, !tbaa !27
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr ptr, ptr %t67, i64 %t64
  %t69 = load ptr, ptr %t68, !tbaa !39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t71, ptr %t72, ptr %t69, ptr %t74)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/ast:TopIf", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t83, ptr %t84, ptr %t88, ptr %t89)
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr %"compiler/ast:TopIf", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/ast:TopIf", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f)
  unreachable
bb27:
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:TopIf", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopBranch", ptr %t113, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t123 = load i1, ptr %l59, !tbaa !21
  br i1 %t123, label %bb30, label %bb31
bb30:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr %"compiler/ast:TopIf", ptr %t124, i32 0, i32 3
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb32, label %bb33
bb31:
  br label %bb42
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0)
  unreachable
bb33:
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopIf", ptr %t131, i32 0, i32 3
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = getelementptr %"compiler/ast:TopBranch", ptr %t134, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t152, ptr %l82, !tbaa !27
  %t153 = load i64, ptr %l9, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t160, ptr %t161, ptr %t158, ptr %t163)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb40:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l9, !tbaa !24
  br label %bb35
bb41:
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l85 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l107 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca i1
  %l128 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l211 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l215 = alloca i1
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l37
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l39
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l35, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l37
  %t14 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %t12, %"compiler/source:Span" %t13, i32 %t14)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t16 = load ptr, ptr %l40, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l40, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l41, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb19
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t31 = load ptr, ptr %l46, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l46, !tbaa !29
  %t35 = load i64, ptr %t34
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l47, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l2, !tbaa !29
  br label %bb19
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t46 = load ptr, ptr %l52, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l52, !tbaa !29
  %t50 = load i64, ptr %t49
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l53, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb20
bb20:
  br label %bb133
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t66 = load ptr, ptr %l61, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l61, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l62, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l62, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Promote", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb27
bb27:
  br label %bb133
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t89 = load ptr, ptr %l71, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l71, !tbaa !29
  %t93 = load i64, ptr %t92
  %t95 = icmp eq i64 %t93, 6
  store i1 %t95, ptr %l72, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l72, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb41
bb33:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Call", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t120, ptr %l85, !tbaa !27
  %t121 = load i64, ptr %l6, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t126)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb34
bb40:
  br label %bb133
bb41:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t138 = load ptr, ptr %l93, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb42, label %bb43
bb42:
  %t141 = load ptr, ptr %l93, !tbaa !29
  %t142 = load i64, ptr %t141
  %t144 = icmp eq i64 %t142, 7
  store i1 %t144, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t145 = load i1, ptr %l94, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l9, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Make", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t161 = load i64, ptr %l11, !tbaa !24
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t169, ptr %l107, !tbaa !27
  %t170 = load i64, ptr %l11, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  %t177 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t177, ptr %t175)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb52:
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l11, !tbaa !24
  br label %bb47
bb53:
  br label %bb133
bb54:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t187 = load ptr, ptr %l115, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb55, label %bb56
bb55:
  %t190 = load ptr, ptr %l115, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 9
  store i1 %t193, ptr %l116, !tbaa !21
  br label %bb56
bb56:
  %t194 = load i1, ptr %l116, !tbaa !21
  br i1 %t194, label %bb57, label %bb58
bb57:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t197, i32 0, i32 4
  %t199 = load { i64, ptr }, ptr %t198
  store { i64, ptr } %t199, ptr %l14, !tbaa !27
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t201 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t201, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s14
  %t207 = load i64, ptr %l16, !tbaa !24
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s14)
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t215 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t215, ptr %l128, !tbaa !27
  %t216 = load i64, ptr %l16, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 %t216
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t223 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t221)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s14)
  br label %bb65
bb65:
  %t228 = load i64, ptr %l16, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l16, !tbaa !24
  br label %bb60
bb66:
  br label %bb133
bb67:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t233 = load ptr, ptr %l136, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l136, !tbaa !29
  %t237 = load i64, ptr %t236
  %t239 = icmp eq i64 %t237, 10
  store i1 %t239, ptr %l137, !tbaa !21
  br label %bb69
bb69:
  %t240 = load i1, ptr %l137, !tbaa !21
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 2
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l19, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l19, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Slice", ptr %t248, i32 0, i32 0
  %t251 = load ptr, ptr %t250, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t247, ptr %t251)
  br label %bb73
bb73:
  br label %bb133
bb74:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t256 = load ptr, ptr %l146, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t259 = load ptr, ptr %l146, !tbaa !29
  %t260 = load i64, ptr %t259
  %t262 = icmp eq i64 %t260, 11
  store i1 %t262, ptr %l147, !tbaa !21
  br label %bb76
bb76:
  %t263 = load i1, ptr %l147, !tbaa !21
  br i1 %t263, label %bb77, label %bb78
bb77:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [5 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l20, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l20, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Cond", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t270, ptr %t274)
  br label %bb80
bb80:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l20, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Cond", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t278, ptr %t282)
  br label %bb81
bb81:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l20, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Cond", ptr %t286, i32 0, i32 2
  %t289 = load ptr, ptr %t288, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t285, ptr %t289)
  br label %bb82
bb82:
  br label %bb133
bb83:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t294 = load ptr, ptr %l163, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb84, label %bb85
bb84:
  %t297 = load ptr, ptr %l163, !tbaa !29
  %t298 = load i64, ptr %t297
  %t300 = icmp eq i64 %t298, 12
  store i1 %t300, ptr %l164, !tbaa !21
  br label %bb85
bb85:
  %t301 = load i1, ptr %l164, !tbaa !21
  br i1 %t301, label %bb86, label %bb87
bb86:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t304, i32 0, i32 2
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l21, !tbaa !29
  br label %bb88
bb87:
  br label %bb97
bb88:
  %t308 = load ptr, ptr %l21, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Seq", ptr %t308, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  store { i64, ptr } %t311, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  store i64 %t315, ptr %l24, !tbaa !24
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s20
  %t317 = load i64, ptr %l23, !tbaa !24
  %t318 = load i64, ptr %l24, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s20)
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t325 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t325, ptr %l177, !tbaa !27
  %t326 = load i64, ptr %l23, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  %t333 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %t333, ptr %t331)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s20)
  br label %bb94
bb94:
  %t338 = load i64, ptr %l23, !tbaa !24
  %t340 = add i64 %t338, 1
  store i64 %t340, ptr %l23, !tbaa !24
  br label %bb89
bb95:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l21, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Seq", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346)
  br label %bb96
bb96:
  br label %bb133
bb97:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t350 = load ptr, ptr %l188, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb98, label %bb99
bb98:
  %t353 = load ptr, ptr %l188, !tbaa !29
  %t354 = load i64, ptr %t353
  %t356 = icmp eq i64 %t354, 14
  store i1 %t356, ptr %l189, !tbaa !21
  br label %bb99
bb99:
  %t357 = load i1, ptr %l189, !tbaa !21
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l26, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Try", ptr %t365, i32 0, i32 0
  %t368 = load ptr, ptr %t367, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t364, ptr %t368)
  br label %bb103
bb103:
  br label %bb133
bb104:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t372 = load ptr, ptr %l197, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb105, label %bb106
bb105:
  %t375 = load ptr, ptr %l197, !tbaa !29
  %t376 = load i64, ptr %t375
  %t378 = icmp eq i64 %t376, 16
  store i1 %t378, ptr %l198, !tbaa !21
  br label %bb106
bb106:
  %t379 = load i1, ptr %l198, !tbaa !21
  br i1 %t379, label %bb107, label %bb108
bb107:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l27, !tbaa !29
  br label %bb109
bb108:
  br label %bb128
bb109:
  %t386 = load ptr, ptr %l27, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Text", ptr %t386, i32 0, i32 0
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t391 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  store i64 %t393, ptr %l30, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s25
  %t395 = load i64, ptr %l29, !tbaa !24
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s25)
  br label %bb127
bb112:
  br label %bb113
bb113:
  %t403 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t403, ptr %l211, !tbaa !27
  %t404 = load i64, ptr %l29, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 %t404
  %t409 = load ptr, ptr %t408, !tbaa !39
  store ptr %t409, ptr %l31, !tbaa !29
  %t411 = load ptr, ptr %l31, !tbaa !29
  store ptr %t411, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t412 = load ptr, ptr %l214, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb114, label %bb115
bb114:
  %t415 = load ptr, ptr %l214, !tbaa !29
  %t416 = load i64, ptr %t415
  %t418 = icmp eq i64 %t416, 1
  store i1 %t418, ptr %l215, !tbaa !21
  br label %bb115
bb115:
  %t419 = load i1, ptr %l215, !tbaa !21
  br i1 %t419, label %bb116, label %bb117
bb116:
  %t420 = load ptr, ptr %l31, !tbaa !29
  %t422 = getelementptr { i64, [2 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { ptr }, ptr %t422, i32 0, i32 0
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l32, !tbaa !29
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t426, ptr %t427)
  br label %bb119
bb119:
  br label %bb125
bb120:
  br i1 true, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_df797fad9b49105d_2a8f7c5ad36c2889)
  unreachable
bb125:
  call void @__olang_scope_close(ptr %s25)
  br label %bb126
bb126:
  %t431 = load i64, ptr %l29, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l29, !tbaa !24
  br label %bb110
bb127:
  br label %bb133
bb128:
  br i1 true, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_d2b15075f36d8dac_250aaa3debc302b8)
  unreachable
bb133:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l13
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l11
  %t14 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %t12, %"compiler/source:Span" %t13, i32 %t14)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  br label %bb12
bb12:
  br label %bb47
bb13:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  br label %bb19
bb19:
  br label %bb47
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  br label %bb26
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  br label %bb27
bb27:
  br label %bb47
bb28:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t87 = load ptr, ptr %l46, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l47, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Payload", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t101, ptr %t105)
  br label %bb34
bb34:
  br label %bb47
bb35:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb36, label %bb37
bb36:
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l57, !tbaa !21
  br label %bb37
bb37:
  %t117 = load i1, ptr %l57, !tbaa !21
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l6, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8ea8ca70496d6921_977884330ce8ec6d)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb88
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  br label %bb88
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l5, !tbaa !29
  br label %bb31
bb22:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l46, !tbaa !21
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb31
bb26:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t87 = load ptr, ptr %l51, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb27, label %bb28
bb27:
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 15
  store i1 %t93, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t94 = load i1, ptr %l52, !tbaa !21
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t101, ptr %t102)
  br label %bb32
bb32:
  br label %bb88
bb33:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb34, label %bb35
bb34:
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l60, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [3 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb42
bb38:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l6, !tbaa !29
  %t123 = getelementptr %"compiler/typed:If", ptr %t121, i32 0, i32 0
  %t124 = load ptr, ptr %t123, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t120, ptr %t124)
  br label %bb39
bb39:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l6, !tbaa !29
  %t131 = getelementptr %"compiler/typed:If", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t128, ptr %t132)
  br label %bb40
bb40:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t139 = getelementptr %"compiler/typed:If", ptr %t137, i32 0, i32 2
  %t140 = load ptr, ptr %t139, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t136, ptr %t140)
  br label %bb41
bb41:
  br label %bb88
bb42:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t144 = load ptr, ptr %l76, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb43, label %bb44
bb43:
  %t147 = load ptr, ptr %l76, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 4
  store i1 %t150, ptr %l77, !tbaa !21
  br label %bb44
bb44:
  %t151 = load i1, ptr %l77, !tbaa !21
  br i1 %t151, label %bb45, label %bb46
bb45:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t154, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l7, !tbaa !29
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t160, i32 0, i32 2
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t164, ptr %t165)
  br label %bb48
bb48:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t169, ptr %t170)
  br label %bb49
bb49:
  br label %bb88
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t174 = load ptr, ptr %l89, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l89, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 10
  store i1 %t180, ptr %l90, !tbaa !21
  br label %bb52
bb52:
  %t181 = load i1, ptr %l90, !tbaa !21
  br i1 %t181, label %bb53, label %bb54
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 1
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 2
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l10, !tbaa !29
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t194, ptr %t195)
  br label %bb56
bb56:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t199, ptr %t200)
  br label %bb57
bb57:
  br label %bb88
bb58:
  %t203 = load ptr, ptr %l1, !tbaa !29
  store ptr %t203, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t204 = load ptr, ptr %l102, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb59, label %bb60
bb59:
  %t207 = load ptr, ptr %l102, !tbaa !29
  %t208 = load i64, ptr %t207
  %t210 = icmp eq i64 %t208, 11
  store i1 %t210, ptr %l103, !tbaa !21
  br label %bb60
bb60:
  %t211 = load i1, ptr %l103, !tbaa !21
  br i1 %t211, label %bb61, label %bb62
bb61:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr }, ptr %t214, i32 0, i32 1
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l11, !tbaa !29
  br label %bb67
bb62:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t219 = load ptr, ptr %l108, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t222 = load ptr, ptr %l108, !tbaa !29
  %t223 = load i64, ptr %t222
  %t225 = icmp eq i64 %t223, 12
  store i1 %t225, ptr %l109, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l109, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l11, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t233, ptr %t234)
  br label %bb68
bb68:
  br label %bb88
bb69:
  %t238 = load ptr, ptr %l1, !tbaa !29
  store ptr %t238, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t239 = load ptr, ptr %l117, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t242 = load ptr, ptr %l117, !tbaa !29
  %t243 = load i64, ptr %t242
  %t245 = icmp eq i64 %t243, 13
  store i1 %t245, ptr %l118, !tbaa !21
  br label %bb71
bb71:
  %t246 = load i1, ptr %l118, !tbaa !21
  br i1 %t246, label %bb72, label %bb73
bb72:
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [3 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", ptr }, ptr %t249, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  store ptr %t251, ptr %l12, !tbaa !29
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t254 = load ptr, ptr %l12, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Join", ptr %t254, i32 0, i32 0
  %t257 = load ptr, ptr %t256, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t253, ptr %t257)
  br label %bb75
bb75:
  br label %bb88
bb76:
  %t261 = load ptr, ptr %l1, !tbaa !29
  store ptr %t261, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t262 = load ptr, ptr %l127, !tbaa !29
  %t263 = icmp ne ptr %t262, null
  br i1 %t263, label %bb77, label %bb78
bb77:
  %t265 = load ptr, ptr %l127, !tbaa !29
  %t266 = load i64, ptr %t265
  %t268 = icmp eq i64 %t266, 14
  store i1 %t268, ptr %l128, !tbaa !21
  br label %bb78
bb78:
  %t269 = load i1, ptr %l128, !tbaa !21
  br i1 %t269, label %bb79, label %bb80
bb79:
  %t270 = load ptr, ptr %l1, !tbaa !29
  %t272 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", ptr }, ptr %t272, i32 0, i32 1
  %t274 = load ptr, ptr %t273
  store ptr %t274, ptr %l13, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l13, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Spawn", ptr %t277, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t276, ptr %t280)
  br label %bb82
bb82:
  br label %bb88
bb83:
  br i1 true, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_4291427b0116e0e2_c8a2c34732e3da0e)
  unreachable
bb88:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l9 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:typeFinder", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp ne i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t24 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = sub i64 %t23, %t27
  store i64 %t30, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/session:typeFinder", ptr %t33, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = icmp sgt i64 %t32, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr %"compiler/session:typeFinder", ptr %t41, i32 0, i32 2
  store i64 %t42, ptr %t45, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = getelementptr %"compiler/session:typeFinder", ptr %t46, i32 0, i32 1
  store i32 %t47, ptr %t50, !tbaa !23
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/names:Entry"
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i32
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d148 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l14
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l13
  br label %bb1
bb1:
  %t8 = load i64, ptr %l13, !tbaa !24
  store i64 %t8, ptr %l11, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l18, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  br label %bb13
bb6:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l23, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l24, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l25, !tbaa !24
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l24, !tbaa !24
  %t33 = icmp sle i64 0, %t32
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb11:
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l24, !tbaa !24
  %t42 = getelementptr i8, ptr %t40, i64 0
  %t43 = sub i64 %t41, 0
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l21, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb13:
  %t47 = load ptr, ptr %l18, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l30
  br label %bb14
bb14:
  %t50 = load i32, ptr %l30, !tbaa !23
  store i32 %t50, ptr %l4, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 1
  %t63 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t59, i64 %a1)
  store ptr %t63, ptr %l36
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t66 = getelementptr %"compiler/names:Table", ptr %t64, i32 0, i32 0
  store ptr %t66, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t68, i64 %t69)
  %t73 = extractvalue { i32, { i64, ptr } } %t72, 1
  %t74 = extractvalue { i32, { i64, ptr } } %t72, 0
  store i32 %t74, ptr %l43
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb18, label %ok.76
ok.76:
  store { i64, ptr } %t73, ptr %l42
  br label %bb17
bb17:
  %t77 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t77, ptr %l39, !tbaa !27
  br label %bb22
bb18:
  %t78 = load i32, ptr %l43, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c3997a235b3aa6f9_f448e120e58ac085)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb22:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t83, ptr %l7, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  store i64 %t86, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t88 = load i64, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb25:
  br label %bb26
bb26:
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t96, ptr %l52, !tbaa !27
  %t97 = load i64, ptr %l9, !tbaa !24
  %t99 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"compiler/names:Entry", ptr %t100, i64 %t97
  %t102 = load %"compiler/names:Entry", ptr %t101
  store %"compiler/names:Entry" %t102, ptr %l10
  %t104 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load i32, ptr %l4, !tbaa !23
  %t109 = icmp eq i32 %t105, %t106
  br i1 %t109, label %bb27, label %bb28
bb27:
  %t111 = getelementptr %"compiler/names:Entry", ptr %l10, i32 0, i32 1
  %t112 = getelementptr %"compiler/source:Span", ptr %t111, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t115 = sext i32 %t113 to i64
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i64 %t115, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l9, !tbaa !24
  br label %bb23
bb31:
  %t121 = load i64, ptr %l6, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = add i64 %t121, %t122
  store i64 %t125, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb16
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fsession_2edocPage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/doc:Module"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i1
  %l8 = alloca %"compiler/diag:Diagnostics"
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l28 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l49 = alloca %"compiler/doc:Module"
  %l50 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l7
  br label %bb1
bb1:
  %t3 = load i1, ptr %l7, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %v1, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t2, i64 200, i1 false)
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 200, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l8, i64 200, i1 false)
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, ptr } %a0, ptr %l10, !tbaa !27
  store ptr %a1, ptr %l11, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l13
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  %t11 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %t11
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t16 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t12, ptr %t13, ptr %t14, ptr %t11, i1 true)
  store ptr %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l15, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l17
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/session:Analysis", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s1, ptr %t40)
  store { i64, ptr } %t42, ptr %l28
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t43 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t49)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb16:
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/session:Analysis", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb18:
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/session:Analysis", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l35, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/session:Analysis", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/session:Analysis", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l40, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/session:Analysis", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb24:
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/session:Analysis", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/session:Analysis", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/load:Loader", ptr %t88, i32 0, i32 7
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load ptr, ptr %l35, !tbaa !29
  %t93 = load ptr, ptr %l40, !tbaa !29
  %t96 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %t92, ptr %t93, ptr %t84, i64 %t91, i1 false)
  store %"compiler/doc:Module" %t96, ptr %l49
  br label %bb26
bb26:
  %t97 = load %"compiler/doc:Module", ptr %l49
  store %"compiler/doc:Module" %t97, ptr %l5
  store { i64, ptr } %a2, ptr %l50, !tbaa !27
  %t99 = getelementptr %"compiler/doc:Module", ptr %l5, i32 0, i32 0
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %s0, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l52
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t110 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t112 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %v2, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t110, { i64, ptr } %t109, { i64, ptr } { i64 0, ptr @.d149 }, { i64, ptr } { i64 0, ptr @.d150 }, { i64, ptr } { i64 0, ptr @.d151 }, { i64, ptr } { i64 0, ptr @.d152 })
  store { i64, ptr } %t112, ptr %l54
  br label %bb28
bb28:
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l6, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t114, ptr %l55, !tbaa !27
  %t116 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t116, ptr %l57
  br label %bb29
bb29:
  %t117 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t125 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t127 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t125, { i64, ptr } %t124)
  store i32 %t127, ptr %l60
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb31, label %ok.129
ok.129:
  br label %bb30
bb30:
  br label %bb36
bb31:
  %t130 = load i32, ptr %l60, !tbaa !23
  %t131 = ashr i32 %t130, 16
  %t133 = icmp eq i32 %t131, 1
  br i1 %t133, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_c23458d215cf3c0b_da8b12dd0d370c37)
  unreachable
bb34:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t136 = extractvalue { i64, ptr } { i64 7, ptr @.d153 }, 1
  %t137 = extractvalue { i64, ptr } { i64 7, ptr @.d153 }, 0
  %t139 = extractvalue { i64, ptr } %t135, 1
  %t140 = extractvalue { i64, ptr } %t135, 0
  %t141 = add i64 %t137, %t140
  %t142 = extractvalue { i64, ptr } { i64 20, ptr @.d154 }, 1
  %t143 = extractvalue { i64, ptr } { i64 20, ptr @.d154 }, 0
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t136, i64 %t137)
  %t146 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t146, ptr %t139, i64 %t140)
  %t147 = getelementptr i8, ptr %t146, i64 %t140
  call void @olang_textcopy(ptr %t147, ptr %t142, i64 %t143)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t145, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t156)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2efirstLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d155 })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  store i64 %t13, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = icmp sle i64 0, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
bb7:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp sle i64 %t23, %t24
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
bb9:
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l9, !tbaa !24
  %t30 = getelementptr i8, ptr %t28, i64 0
  %t31 = sub i64 %t29, 0
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ehover(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l4, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 9, ptr @.d156 }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr @.d156 }, 0
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 4, ptr @.d157 }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr @.d157 }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr @.d158 })
  store i1 %t31, ptr %l10
  br label %bb4
bb4:
  %t32 = load i1, ptr %l10, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } { i64 2, ptr @.d159 }, 1
  %t37 = extractvalue { i64, ptr } { i64 2, ptr @.d159 }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t52)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t56, ptr %l17
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l18, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l19, !tbaa !24
  %t60 = load i64, ptr %l19, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l20, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l19, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t71, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %t2, { i64, ptr } %a2)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  br label %bb4
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l10, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9
  store i32 %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb2
bb2:
  %t22 = load i32, ptr %l14
  store i32 %t22, ptr %l4
  %t23 = load i32, ptr %l3
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load i32, ptr %l4
  %t30 = trunc i64 18 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l29
  br label %bb9
bb9:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = load i32, ptr %l29, !tbaa !23
  %t56 = icmp eq i32 %t54, %t55
  store i1 %t56, ptr %rv
  br label %ret
bb10:
  %t58 = load i32, ptr %l3
  %t60 = trunc i64 25 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t64 = load i32, ptr %l3
  store i32 %t64, ptr %l34
  %t65 = load i32, ptr %l4
  store i32 %t65, ptr %l36
  %t68 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l34, ptr %l36)
  store i1 %t68, ptr %l38
  br label %bb14
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fsession_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5cf51ca4b5f5f5c8_254dda38d3cb154)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2estdModules(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l25 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr @.d160 }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr @.d161 }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2
  store i64 2, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l2
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = load ptr, ptr @__olang_prog_scope
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t27, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr @.d162 })
  store i1 %t29, ptr %l25
  br label %bb6
bb6:
  %t30 = load i1, ptr %l25, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t35 = load ptr, ptr @__olang_prog_scope
  %t38 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %t35, ptr %s2, ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t33, { i64, ptr } %t34, { i64, ptr } { i64 0, ptr @.d163 }, { i64, ptr } { i64 0, ptr @.d164 }, { i64, ptr } { i64 0, ptr @.d165 }, { i64, ptr } { i64 0, ptr @.d166 })
  store { i64, ptr } %t38, ptr %l30
  br label %bb9
bb8:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 1
  %t42 = extractvalue { i64, ptr } %t39, 0
  %t43 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t41, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  br label %bb10
bb9:
  %t47 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t47, ptr %l27, !tbaa !27
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t48, ptr %l6, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t51 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s2, ptr %s2, { i64, ptr } %t49)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l36
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb12, label %ok.55
ok.55:
  store { i64, ptr } %t52, ptr %l35
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t56, ptr %l33, !tbaa !27
  br label %bb16
bb12:
  %t57 = load i32, ptr %l36, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  br i1 %t60, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_1126565fcbfcf295_ffce34322562f1d9)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb16:
  %t62 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t62, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l10, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l10, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb19:
  br label %bb20
bb20:
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t77, ptr %l46, !tbaa !27
  %t78 = load i64, ptr %l9, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %t81, i64 %t78
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !37
  store { i64, ptr } %t83, ptr %l11, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s2, ptr %s6, { i64, ptr } %t85, { i64, ptr } { i64 6, ptr @.d167 })
  store i1 %t87, ptr %l50
  br label %bb21
bb21:
  %t88 = load i1, ptr %l50, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  store ptr %a0, ptr %l51, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t94 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr @.d168 }, { i64, ptr } { i64 0, ptr @.d169 }, { i64, ptr } { i64 0, ptr @.d170 }, { i64, ptr } { i64 0, ptr @.d171 })
  store { i64, ptr } %t94, ptr %l54
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  %t97 = extractvalue { i64, ptr } %t95, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t102, { i64, ptr } %t101)
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb27:
  %t104 = load i64, ptr %l9, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l9, !tbaa !24
  br label %bb17
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t108 = load i64, ptr %l3, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l3, !tbaa !24
  br label %bb2
bb30:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2eutf16Units(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t3, %a2
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb3:
  br label %bb4
bb4:
  store { i64, ptr } %a0, ptr %l12, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l5, !tbaa !22
  %t20 = load i8, ptr %l5, !tbaa !22
  %t22 = icmp ult i8 %t20, -64
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l18, !tbaa !24
  br label %bb13
bb6:
  %t24 = load i8, ptr %l5, !tbaa !22
  %t26 = icmp ult i8 %t24, -32
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i64 2, ptr %l21, !tbaa !24
  br label %bb12
bb8:
  %t28 = load i8, ptr %l5, !tbaa !22
  %t30 = icmp ult i8 %t28, -16
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i64 3, ptr %l24, !tbaa !24
  br label %bb11
bb10:
  store i64 4, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t32 = load i64, ptr %l24, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb13
bb13:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp eq i64 %t36, 4
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i64 2, ptr %l28, !tbaa !24
  br label %bb16
bb15:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = load i64, ptr %l28, !tbaa !24
  %t42 = add i64 %t40, %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  store i64 %t48, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"compiler/session:Analysis"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/session:Analysis" undef, ptr %a0, 0
  %t6 = insertvalue %"compiler/session:Analysis" %t4, ptr null, 1
  %t8 = insertvalue %"compiler/session:Analysis" %t6, ptr null, 2
  %t10 = insertvalue %"compiler/session:Analysis" %t8, ptr null, 3
  store %"compiler/session:Analysis" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Analysis", ptr %rv
  ret %"compiler/session:Analysis" %rr
}

define dso_local %"compiler/session:FieldInfo" @compiler_2fsession_3aFieldInfo_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/session:FieldInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/session:FieldInfo" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/session:FieldInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/session:FieldInfo" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/session:FieldInfo" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/session:FieldInfo" %t18, i64 %a4, 4
  store %"compiler/session:FieldInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:FieldInfo", ptr %rv
  ret %"compiler/session:FieldInfo" %rr
}

define dso_local %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/session:Found"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/session:Found" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/session:Found" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/session:Found" %t10, i64 %a2, 2
  store %"compiler/session:Found" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Found", ptr %rv
  ret %"compiler/session:Found" %rr
}

define dso_local %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/session:Items"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t3, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l4
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l0
  %t8 = insertvalue %"compiler/session:Items" undef, %"std/prelude/text:StringBuilder" %t7, 0
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = insertvalue %"compiler/session:Items" %t8, i64 %t9, 1
  %t12 = insertvalue %"compiler/session:Items" %t10, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 2
  store %"compiler/session:Items" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Items", ptr %rv
  ret %"compiler/session:Items" %rr
}

define dso_local %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca %"compiler/session:Positions"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i1 %a1, ptr %l3, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = insertvalue %"compiler/session:Positions" undef, { i64, ptr } %t9, 0
  %t11 = load i1, ptr %l3, !tbaa !21
  %t12 = insertvalue %"compiler/session:Positions" %t10, i1 %t11, 1
  %t14 = insertvalue %"compiler/session:Positions" %t12, { i64, ptr } %t8, 2
  store %"compiler/session:Positions" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Positions", ptr %rv
  ret %"compiler/session:Positions" %rr
}

define dso_local %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/session:Reader"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l1, !tbaa !23
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = insertvalue %"compiler/session:Reader" undef, i32 %t5, 0
  %t8 = insertvalue %"compiler/session:Reader" %t6, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, 1
  %t10 = insertvalue %"compiler/session:Reader" %t8, i1 false, 2
  store %"compiler/session:Reader" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Reader", ptr %rv
  ret %"compiler/session:Reader" %rr
}

define dso_local %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/session:finder"
  %t9 = alloca { i64, [6 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [6 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [6 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [6 x i64] }, ptr %t9
  %t14 = insertvalue %"compiler/session:finder" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/session:finder" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/session:finder" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/session:finder" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/session:finder" %t20, i64 -1, 4
  %t24 = insertvalue %"compiler/session:finder" %t22, { i64, [6 x i64] } %t11, 5
  %t26 = insertvalue %"compiler/session:finder" %t24, i64 9223372036854775807, 6
  store %"compiler/session:finder" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:finder", ptr %rv
  ret %"compiler/session:finder" %rr
}

define dso_local %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"compiler/session:symWriter"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/session:symWriter" undef, ptr %a0, 0
  %t6 = insertvalue %"compiler/session:symWriter" %t4, i64 0, 1
  store %"compiler/session:symWriter" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:symWriter", ptr %rv
  ret %"compiler/session:symWriter" %rr
}

define dso_local %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"compiler/session:typeFinder"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = insertvalue %"compiler/session:typeFinder" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/session:typeFinder" %t6, i32 %t3, 1
  %t10 = insertvalue %"compiler/session:typeFinder" %t8, i64 -1, 2
  store %"compiler/session:typeFinder" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:typeFinder", ptr %rv
  ret %"compiler/session:typeFinder" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fsession() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fsession_2eKindMethod_2einit()
  br label %bb1
bb1:
  call void @compiler_2fsession_2eKindField_2einit()
  br label %bb2
bb2:
  call void @compiler_2fsession_2eKindEnum_2einit()
  br label %bb3
bb3:
  call void @compiler_2fsession_2eKindInterface_2einit()
  br label %bb4
bb4:
  call void @compiler_2fsession_2eKindFunction_2einit()
  br label %bb5
bb5:
  call void @compiler_2fsession_2eKindVariable_2einit()
  br label %bb6
bb6:
  call void @compiler_2fsession_2eKindEnumMember_2einit()
  br label %bb7
bb7:
  call void @compiler_2fsession_2eKindStruct_2einit()
  br label %bb8
bb8:
  call void @compiler_2fsession_2eKindClass_2einit()
  br label %bb9
bb9:
  call void @compiler_2fsession_2eCompMethod_2einit()
  br label %bb10
bb10:
  call void @compiler_2fsession_2eCompFunction_2einit()
  br label %bb11
bb11:
  call void @compiler_2fsession_2eCompField_2einit()
  br label %bb12
bb12:
  call void @compiler_2fsession_2eCompVariable_2einit()
  br label %bb13
bb13:
  call void @compiler_2fsession_2eCompModule_2einit()
  br label %bb14
bb14:
  call void @compiler_2fsession_2eCompKeyword_2einit()
  br label %bb15
bb15:
  call void @compiler_2fsession_2eCompConstant_2einit()
  br label %bb16
bb16:
  call void @compiler_2fsession_2eCompStruct_2einit()
  br label %bb17
bb17:
  call void @compiler_2fsession_2eKeywords_2einit()
  br label %bb18
bb18:
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant [7 x i8] c"loaded "
@.d1 = private constant [2 x i8] c" ("
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant [13 x i8] c" modules) in "
@.d3 = private constant [3 x i8] c" ms"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant [11 x i8] c"checked in "
@.d5 = private constant [3 x i8] c" ms"
declare i32 @fork()
declare void @_exit(i32)
declare i32 @close(i32)
@.d6 = private constant [0 x i8] c""
@.d7 = private constant [0 x i8] c""
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d8 = private constant [7 x i8] c"olang: "
@.d9 = private constant [17 x i8] c": cannot be made\0A"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i32 @olang_lambda_10(ptr %env) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, ptr }, ptr %cp2, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fsession_2edocPage(ptr %vc0, ptr %vc1, ptr %vc2, { i64, ptr } %cv0, ptr %cv1, { i64, ptr } %cv2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define internal i1 @olang_lambda_11(ptr %env, ptr %v0, ptr %v1, %"compiler/doc:Module" %a0, %"compiler/doc:Module" %a1) #0 {
entry:
  %l0 = alloca %"compiler/doc:Module"
  %l1 = alloca %"compiler/doc:Module"
  %l4 = alloca i1
  %rv = alloca i1
  store %"compiler/doc:Module" %a0, ptr %l0
  store %"compiler/doc:Module" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/doc:Module", ptr %l0, i32 0, i32 0
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t3 = getelementptr %"compiler/doc:Module", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i1, ptr %l4, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d12 = private constant [10 x i8] c"index.html"
@.d13 = private constant [0 x i8] c""
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [22 x i8] c"olang standard library"
@.d18 = private constant [5 x i8] c"olang"
@.d19 = private constant [7 x i8] c"olang: "
@.d20 = private constant [20 x i8] c": cannot be written\0A"
declare i32 @dup2(i32, i32)
define internal { i64, ptr } @olang_lambda_21(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_7a94fd02074d0ce_d193d84d7f2a309a)
  unreachable
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %t5, i64 %a0)
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_22(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_626d61d2b6cf5220_9a1c4c990765ee54)
  unreachable
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %t5, i32 %a0)
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d23 = private constant [21 x i8] c"held to section 8 in "
@.d24 = private constant [3 x i8] c" ms"
@.d25 = private constant [1 x i8] c"."
@.d26 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [1 x i8] c"/"
@.d29 = private constant [1 x i8] c"/"
@.d30 = private constant [4 x i8] c"std/"
@.d31 = private constant [0 x i8] c""
@.d32 = private constant [6 x i8] c".olang"
declare i64 @signal(i32, i64)
declare i32 @waitpid(i32, ptr, i32)
@.d33 = private constant [2 x i8] c"\5C\22"
@.d34 = private constant [2 x i8] c"\5C\5C"
@.d35 = private constant [2 x i8] c"\5Cn"
@.d36 = private constant [2 x i8] c"\5Cr"
@.d37 = private constant [2 x i8] c"\5Ct"
@.d38 = private constant [4 x i8] c"\5Cu00"
@.d39 = private constant [16 x i8] c"0123456789abcdef"
@.d40 = private constant [16 x i8] c"0123456789abcdef"
@.d41 = private constant [2 x i8] c"fn"
@.d42 = private constant [4 x i8] c"type"
@.d43 = private constant [6 x i8] c"struct"
@.d44 = private constant [4 x i8] c"enum"
@.d45 = private constant [5 x i8] c"trait"
@.d46 = private constant [7 x i8] c"extends"
@.d47 = private constant [6 x i8] c"import"
@.d48 = private constant [4 x i8] c"test"
@.d49 = private constant [6 x i8] c"extern"
@.d50 = private constant [2 x i8] c"if"
@.d51 = private constant [4 x i8] c"else"
@.d52 = private constant [3 x i8] c"for"
@.d53 = private constant [2 x i8] c"in"
@.d54 = private constant [5 x i8] c"range"
@.d55 = private constant [5 x i8] c"match"
@.d56 = private constant [4 x i8] c"case"
@.d57 = private constant [7 x i8] c"nomatch"
@.d58 = private constant [6 x i8] c"return"
@.d59 = private constant [5 x i8] c"break"
@.d60 = private constant [8 x i8] c"continue"
@.d61 = private constant [5 x i8] c"error"
@.d62 = private constant [3 x i8] c"try"
@.d63 = private constant [5 x i8] c"catch"
@.d64 = private constant [7 x i8] c"default"
@.d65 = private constant [4 x i8] c"join"
@.d66 = private constant [5 x i8] c"spawn"
@.d67 = private constant [5 x i8] c"defer"
@.d68 = private constant [6 x i8] c"assert"
@.d69 = private constant [11 x i8] c"unreachable"
@.d70 = private constant [8 x i8] c"noreturn"
@.d71 = private constant [3 x i8] c"mut"
@.d72 = private constant [3 x i8] c"and"
@.d73 = private constant [2 x i8] c"or"
@.d74 = private constant [3 x i8] c"not"
@.d75 = private constant [3 x i8] c"xor"
@.d76 = private constant [2 x i8] c"is"
@.d77 = private constant [2 x i8] c"as"
@.d78 = private constant [4 x i8] c"null"
@.d79 = private constant [4 x i8] c"true"
@.d80 = private constant [5 x i8] c"false"
@.d81 = private constant [8 x i8] c"destruct"
declare i32 @kill(i32, i32)
@.d82 = private constant [14 x i8] c"OLANG_TOOL_LOG"
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [0 x i8] c""
@.d85 = private constant [7 x i8] c"olang: "
@.d86 = private constant [1 x i8] c"\0A"
declare i32 @pipe(ptr)
declare i32 @poll(ptr, i64, i32)
@.d87 = private constant [0 x i8] c""
@.d88 = private constant [0 x i8] c""
@.d89 = private constant [4 x i8] c"std/"
@.d90 = private constant [0 x i8] c""
@.d91 = private constant [0 x i8] c""
@.d92 = private constant [0 x i8] c""
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [6 x i8] c".olang"
@.d95 = private constant [6 x i8] c".olang"
@.d96 = private constant [16 x i8] c"Content-Length: "
@.d97 = private constant [4 x i8] c"\0D\0A\0D\0A"
@.d98 = private constant [7 x i8] c"no type"
@.d99 = private constant [26 x i8] c"completion after a '.' at "
@.d100 = private constant [2 x i8] c": "
@.d101 = private constant [0 x i8] c""
@.d102 = private constant [0 x i8] c""
@.d103 = private constant [0 x i8] c""
@.d104 = private constant [1 x i8] c" "
@.d105 = private constant [10 x i8] c"parameter "
@.d106 = private constant [0 x i8] c""
@.d107 = private constant [1 x i8] c" "
@.d108 = private constant [0 x i8] c""
@.d109 = private constant [0 x i8] c""
@.d110 = private constant [8 x i8] c"import \22"
@.d111 = private constant [1 x i8] c"\22"
@.d112 = private constant [0 x i8] c""
@.d113 = private constant [0 x i8] c""
@.d114 = private constant [0 x i8] c""
@.d115 = private constant [0 x i8] c""
@.d116 = private constant [9 x i8] c"{\22label\22:"
@.d117 = private constant [8 x i8] c",\22kind\22:"
@.d118 = private constant [0 x i8] c""
@.d119 = private constant [10 x i8] c",\22detail\22:"
@.d120 = private constant [17 x i8] c"{\22start\22:{\22line\22:"
@.d121 = private constant [13 x i8] c",\22character\22:"
@.d122 = private constant [16 x i8] c"},\22end\22:{\22line\22:"
@.d123 = private constant [13 x i8] c",\22character\22:"
@.d124 = private constant [2 x i8] c"}}"
declare i64 @read(i32, ptr, i64)
@.d125 = private constant [15 x i8] c"content-length:"
@.d126 = private constant [0 x i8] c""
@.d127 = private constant [0 x i8] c""
@.d128 = private constant [2 x i8] c"]}"
@.d129 = private constant [0 x i8] c""
@.d130 = private constant [5 x i8] c"error"
@.d131 = private constant [0 x i8] c""
@.d132 = private constant [2 x i8] c"]}"
@.d133 = private constant [5 x i8] c"test "
@.d134 = private constant [0 x i8] c""
@.d135 = private constant [2 x i8] c"]}"
@.d136 = private constant [0 x i8] c""
@.d137 = private constant [0 x i8] c""
@.d138 = private constant [0 x i8] c""
@.d139 = private constant [8 x i8] c"{\22name\22:"
@.d140 = private constant [0 x i8] c""
@.d141 = private constant [1 x i8] c"?"
@.d142 = private constant [8 x i8] c",\22kind\22:"
@.d143 = private constant [9 x i8] c",\22range\22:"
@.d144 = private constant [18 x i8] c",\22selectionRange\22:"
@.d145 = private constant [0 x i8] c""
@.d146 = private constant [10 x i8] c",\22detail\22:"
@.d147 = private constant [13 x i8] c",\22children\22:["
@.d148 = private constant [1 x i8] c"."
@.d149 = private constant [0 x i8] c""
@.d150 = private constant [0 x i8] c""
@.d151 = private constant [0 x i8] c""
@.d152 = private constant [0 x i8] c""
@.d153 = private constant [7 x i8] c"olang: "
@.d154 = private constant [20 x i8] c": cannot be written\0A"
@.d155 = private constant [1 x i8] c"\0A"
@.d156 = private constant [9 x i8] c"```olang\0A"
@.d157 = private constant [4 x i8] c"\0A```"
@.d158 = private constant [0 x i8] c""
@.d159 = private constant [2 x i8] c"\0A\0A"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d160 = private constant [0 x i8] c""
@.d161 = private constant [7 x i8] c"prelude"
@.d162 = private constant [0 x i8] c""
@.d163 = private constant [0 x i8] c""
@.d164 = private constant [0 x i8] c""
@.d165 = private constant [0 x i8] c""
@.d166 = private constant [0 x i8] c""
@.d167 = private constant [6 x i8] c".olang"
@.d168 = private constant [0 x i8] c""
@.d169 = private constant [0 x i8] c""
@.d170 = private constant [0 x i8] c""
@.d171 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t1)
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare %"compiler/fetch:Fetcher" @compiler_2ffetch_3aFetcher_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare %"compiler/load:Loader" @compiler_2fload_3aLoader_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare %"std/prelude/map:MapIter.99c147484afd48861ff48b49f12017ce" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_9597a45ffcf3bed9_58043f2be0cce7d = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2ftime_2eNow()
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eSince(i64 %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_35fd852a81194674_cc9a5a6794b34358 = external constant [0 x i8]
@olang_loc_2e5a67dd47f860a5_3bdcee40b40c1629 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3107e0baf714f587_4e2de6149db597f3 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_1ea25794a8230c9f_eba27a85472598cb = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_3d3ecb4e4c1abd3d_61c17d26e89329d9 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_849d325a162e3455_c407129f4a4a7021 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_955ee6d2dd4da682_b67b6619c21949c6 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_59b0d3c23afb5803_7d478ed24d90bfa7 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Module" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2eSort_3_H1ab8198b77e0f018190e9fba053e1380(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1a1e266cc778f828_672b31d7f6f9b22c = external constant [0 x i8]
@olang_loc_eb449e3906b36447_37ec3fcb8d3ba1cb = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
@olang_loc_35f6bc648a66c5f9_fb290a2b6e993705 = external constant [0 x i8]
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
@olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e = external constant [0 x i8]
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, i32 %a2)
@olang_loc_6f935d255f99d513_bebfb26ca618488f = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d = external constant [0 x i8]
@olang_loc_18466e7707586594_33576ced7420fee0 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_decc2d78854299ff_a983c2831d86fddb = external constant [0 x i8]
@olang_loc_ff40fb5988b00df4_fbbcb1c788c8bd28 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_1cc1f1f203352feb_9705d5bb59619eef = external constant [0 x i8]
@olang_loc_6afc88ea1ac145e8_494a63ded86193f4 = external constant [0 x i8]
@olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_b18535922df9c451_739a4491ef7ea55d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
@olang_loc_3e799710a156d065_c0388e63a7e7a1d9 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3178b68d0296f164_92041ef9c14564d0 = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d917d39333aa2133_631bc7dad212aa2f = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_8be86b180d8510f2_8625cf113e27a67e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_804f8b0fb45e435f_c5484f8454187243 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H9642fc84722c85223d960eea7a720e04(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ca0f10400b3a3f07_954154708ee424db = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eRunFrom_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9b218acf13b4620c_e8906e55efde0fe0 = external constant [0 x i8]
@olang_loc_572cffa5a574e22e_260a164ad5cf82c2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fload_3aImport_3e_2eRunFrom_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_854b1337ed7621ea_eafb751d49f74e56 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H8fdab0f9e4aba8682af3c4e1d27c3999(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f733ad54130e916b_d05149f8d1e95327 = external constant [0 x i8]
@olang_loc_657f7671e8d24039_dcdf7cbf2572e335 = external constant [0 x i8]
@olang_loc_34b5353ec7fa6306_74a43705b3ad61d2 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
@olang_loc_913972385efaf6d8_94fc87626a418744 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_50b486dff56c46f7_6641abdfc6e3fb13 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee = external constant [0 x i8]
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
@olang_loc_f7a7bb63ca62da11_77899a051c081195 = external constant [0 x i8]
@olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9453126c7f8f920b_6892400c5eb9861f = external constant [0 x i8]
@olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a = external constant [0 x i8]
@olang_loc_20929c6a5a73c2c_efaf2a5e5b22d0b8 = external constant [0 x i8]
@olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e81878307a0930f8_ac6e376276a113b4 = external constant [0 x i8]
@olang_loc_cf719ce72396210d_6e539aa1951515a9 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_90bed28a447e5726_404cd49f4fb329c2 = external constant [0 x i8]
@olang_loc_966fb838f56733ab_5416c5dd2a23270f = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_55b3f811cb7477b4_5dfc53d9875946d8 = external constant [0 x i8]
@olang_loc_4c52bbc768601131_90801d9bf2a41585 = external constant [0 x i8]
@olang_loc_42ed37d296a6252a_791781e06ef43dde = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_dff094d230471566_615c91b3ab3b0902 = external constant [0 x i8]
@olang_loc_878a1a37f76dded1_df06407b9e0240ed = external constant [0 x i8]
@olang_loc_571c555105558829_b21161f963665c45 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
@olang_loc_ad4014c285adba33_5f0a50bbd6dd5777 = external constant [0 x i8]
@olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758 = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_50adcb75aa4e31d0_b7ad99d78ce5014 = external constant [0 x i8]
declare i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0)
@olang_loc_6010ac475f88a9f2_430aff1aa96b7386 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_64c89934b5f1bf_a2a8dc486100a28b = external constant [0 x i8]
@olang_loc_4a3b8d5757fbfa0_7b802f1ecd3d6b9c = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa = external constant [0 x i8]
@olang_loc_78ada93836b36c6b_7d0979891c04300f = external constant [0 x i8]
@olang_loc_f729b95fcb28e588_e9118b2581b5934c = external constant [0 x i8]
declare %"compiler/names:Entry" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2 = external constant [0 x i8]
@olang_loc_82a1ed1229cd6d99_a8840ba8d5b2a1b5 = external constant [0 x i8]
@olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d = external constant [0 x i8]
@olang_loc_f548539da9e2e40c_6a57728f427e36c8 = external constant [0 x i8]
@olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
@olang_loc_be0af37330f35afe_68a0a057b8d4cca2 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
@olang_loc_7be9b74a0a4337a5_af051c2067e0d709 = external constant [0 x i8]
@olang_loc_a0e32d5552598bb5_d1b40570995ef0d1 = external constant [0 x i8]
@olang_loc_90517919cad2500e_b5e04c9858b7f7ca = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_ce3fd8c720c212bf_60e6469ff90569cb = external constant [0 x i8]
@olang_loc_d27ec903618be0a0_36ec6c4f051caedc = external constant [0 x i8]
@olang_loc_a0487cd0bec06cd0_843576141ef24254 = external constant [0 x i8]
@olang_loc_cf04846f3952f731_2a54d968229bc665 = external constant [0 x i8]
@olang_loc_5cb89564a64a7b89_ef4d611fae5a664d = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ad9e8a7a2a8b2da1_3a700b1f4bcc2495 = external constant [0 x i8]
@olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10 = external constant [0 x i8]
@olang_loc_12a97d69ea90e0b4_1cefa701b7ed5940 = external constant [0 x i8]
@olang_loc_67abeedc6dc3e7e5_22c54dafd155c1d1 = external constant [0 x i8]
@olang_loc_3420eab5d10be317_b620dca566d2bea3 = external constant [0 x i8]
@olang_loc_65524a0775fa0c24_67802a16d5ac44c0 = external constant [0 x i8]
@olang_loc_183418cbaaa3b5f3_579c8efa30db605f = external constant [0 x i8]
@olang_loc_269369d36ae436b2_2e7a039021f1ff2e = external constant [0 x i8]
@olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5 = external constant [0 x i8]
@olang_loc_1aec45c66be069a7_7812cf21d0956dab = external constant [0 x i8]
@olang_loc_237e374d945d777f_399ab2bb28be7e53 = external constant [0 x i8]
@olang_loc_276794097286b2ce_71d39dea21084d12 = external constant [0 x i8]
@olang_loc_82218eacf4543783_985f2bd8de40d207 = external constant [0 x i8]
@olang_loc_f4d7e16f2a7cbb1c_8fb96f5d8af1db38 = external constant [0 x i8]
@olang_loc_1c008e98be3ff20b_924cdfead9f88757 = external constant [0 x i8]
@olang_loc_b565a54699261f06_cef80cb59d129ba = external constant [0 x i8]
@olang_loc_b99b77fc0d6b96a0_446559ab5289c314 = external constant [0 x i8]
@olang_loc_87ffdc4dfe3941b5_82c807225dd1f409 = external constant [0 x i8]
@olang_loc_776e281276b2060e_3c638b59aec5e9a2 = external constant [0 x i8]
@olang_loc_6237d3e91d999133_c33b7259109e18ef = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ba98b6e2ec866164_4230a8105a2f5a90 = external constant [0 x i8]
@olang_loc_7656df89f7661819_748f2d65f1fb15e5 = external constant [0 x i8]
@olang_loc_15086b6df77480f2_b1c913263c09743e = external constant [0 x i8]
@olang_loc_e46064093ccb7737_bcf1b739fe6e0cbb = external constant [0 x i8]
@olang_loc_c9113caf811d0518_bcd4762777a6b04c = external constant [0 x i8]
@olang_loc_ec94e30d90cfb58d_d203b7196ae8f109 = external constant [0 x i8]
@olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_7fa1338bfb5c4549_286381a3bde0b91d = external constant [0 x i8]
@olang_loc_98e1614ed1d054f5_86eb50e982cc0441 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a3421b14f56bfb72_e21214c32a246516 = external constant [0 x i8]
@olang_loc_3aa7b4b0f3deff3_f1c3bb5d68daf437 = external constant [0 x i8]
@olang_loc_6c2d06947719abd6_25c6135ab70ee42 = external constant [0 x i8]
@olang_loc_a4411270f97f17bd_30632737f0d2da29 = external constant [0 x i8]
@olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b = external constant [0 x i8]
@olang_loc_7a96973d190d0d9e_4b6d703943f97c5a = external constant [0 x i8]
@olang_loc_d73c626185112279_563eb35624dc00ed = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
@olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5 = external constant [0 x i8]
@olang_loc_9a3dbb58dbc7a31a_5629726f6c293dd6 = external constant [0 x i8]
@olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca = external constant [0 x i8]
@olang_loc_647b5c14292f4276_1cbe6dd578a95e8a = external constant [0 x i8]
@olang_loc_4f7bb28debca73d0_f3d58f15dee72c24 = external constant [0 x i8]
declare i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_52dc430f3488fa77_8026fac3ef739783 = external constant [0 x i8]
@olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd = external constant [0 x i8]
@olang_loc_59453385dbeab0f1_a10e94e6ba58edc5 = external constant [0 x i8]
@olang_loc_5620e65a2f0e2ce0_731e90c9e662bd14 = external constant [0 x i8]
@olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5 = external constant [0 x i8]
@olang_loc_7c90741a89491e92_62c7d4207901162e = external constant [0 x i8]
@olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f = external constant [0 x i8]
@olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_df797fad9b49105d_2a8f7c5ad36c2889 = external constant [0 x i8]
@olang_loc_d2b15075f36d8dac_250aaa3debc302b8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
@olang_loc_8ea8ca70496d6921_977884330ce8ec6d = external constant [0 x i8]
@olang_loc_4291427b0116e0e2_c8a2c34732e3da0e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5f2579128b68b5af_d9dbce929ac4615b = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c3997a235b3aa6f9_f448e120e58ac085 = external constant [0 x i8]
@olang_loc_e6936df67b662b33_7a0885fa2c8953cf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_c23458d215cf3c0b_da8b12dd0d370c37 = external constant [0 x i8]
@olang_loc_806fd3d74c9283ca_adf24a445d28962e = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_5cf51ca4b5f5f5c8_254dda38d3cb154 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_1126565fcbfcf295_ffce34322562f1d9 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7a94fd02074d0ce_d193d84d7f2a309a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_626d61d2b6cf5220_9a1c4c990765ee54 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
