; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Analysis" = type { ptr, ptr, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/interp:Exec" = type { ptr, ptr, i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"<poll.h>:pollfd" = type { i32, i16, i16 }
%"compiler/session:symWriter" = type { ptr, i64 }
%"compiler/session:Found" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:memberInfo" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/session:finder" = type { i64, i64, { i64, ptr }, ptr, i64, { i64, [6 x i64] }, i64 }
%"compiler/session:typeFinder" = type { i64, i32, i64 }
%"compiler/session:Items" = type { %"std/prelude/text:StringBuilder", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/doc:Example" = type { { i64, ptr }, { i64, ptr } }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
@G_2ecompiler_2fsession_2eCompConstant = constant <{ [8 x i8] }> <{ [8 x i8] c"\15\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompField = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompFunction = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompKeyword = constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompMethod = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompModule = constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompStruct = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompVariable = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKeywords = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k1, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k2, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k3, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k5, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k6, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k8, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k9, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k10, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k11, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k12, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k13, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k15, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k16, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k17, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k18, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k19, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k20, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k21, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k22, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k23, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k24, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k25, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k26, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k27, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k28, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k29, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k30, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k31, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k32, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k33, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k34, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k35, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k36, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k37, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k38, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k39, [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k40, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k41, [8 x i8] c"\02\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k42, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k43, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k44, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k45, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fsession_2eKeywords.k46 }>, align 64
@G_2ecompiler_2fsession_2eKeywords.k1 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\66\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k2 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\79\70\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k3 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k4 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\6E\75\6D" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k5 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\74\72\61\69\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k6 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\65\78\74\65\6E\64\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k7 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\69\6D\70\6F\72\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\65\73\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k9 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\65\78\74\65\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k10 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\66" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k11 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\65\6C\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k12 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\66\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k13 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\64\6F" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k14 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\72\61\6E\67\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k16 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\6D\61\74\63\68" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k17 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\63\61\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k18 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\72\65\74\75\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k19 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\62\72\65\61\6B" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k20 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\6E\74\69\6E\75\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k21 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\72\72\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k22 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\74\72\79" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k23 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\63\61\74\63\68" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k24 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\64\65\66\61\75\6C\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k25 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6A\6F\69\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k26 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\73\70\61\77\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k27 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\64\65\66\65\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k28 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\65\72\72\64\65\66\65\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k29 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\65\6D\62\65\64" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k30 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\79\69\65\6C\64" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k31 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\62\65\63\6F\6D\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k32 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\63\6F\6D\70\74\69\6D\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k33 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\61\73\73\65\72\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k34 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\75\6E\72\65\61\63\68\61\62\6C\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k35 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\6E\6F\72\65\74\75\72\6E" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k36 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6D\75\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k37 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\61\6E\64" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k38 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k39 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\6E\6F\74" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k40 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\78\6F\72" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k41 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\69\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k42 = internal constant <{ [2 x i8] }> <{ [2 x i8] c"\61\73" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k43 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\6E\75\6C\6C" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k44 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\74\72\75\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k45 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\66\61\6C\73\65" }>, align 8
@G_2ecompiler_2fsession_2eKeywords.k46 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\64\65\73\74\72\75\63\74" }>, align 8
@G_2ecompiler_2fsession_2eKindClass = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindEnum = constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindEnumMember = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindField = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindFunction = constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindInterface = constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindMethod = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindStruct = constant <{ [8 x i8] }> <{ [8 x i8] c"\17\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindVariable = constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
define dso_local ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l12 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca %"compiler/fetch:Fetcher"
  %l29 = alloca %"compiler/source:Names"
  %l31 = alloca { i64, ptr }
  %l38 = alloca %"compiler/load:Loader"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l64 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l65 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l67 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l68 = alloca i32
  %l70 = alloca i1
  %l79 = alloca i64
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca %"compiler/session:Analysis"
  %l98 = alloca i1
  %l100 = alloca i1
  %l103 = alloca %"compiler/check:Checker"
  %l108 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l111 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i64
  %l121 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l123 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  %t31 = alloca %"compiler/fetch:Fetcher", align 8
  %t56 = alloca %"compiler/load:Loader", align 8
  %t261 = alloca %"compiler/check:Checker", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v4, { i64, ptr } %t1)
  store { i64, ptr } %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l20, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v4)
  store { i64, ptr } %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v4)
  store { i64, ptr } %t19, ptr %l23
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/build:Config", ptr %t27, i32 0, i32 13
  %t30 = load i1, ptr %t29, !tbaa !21
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t31, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t32, { i64, ptr } %t33, { i64, ptr } %t26, i1 %t30, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t31, i64 184, i1 false)
  br label %bb4
bb4:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %l27, i64 184, i1 false)
  store ptr %t36, ptr %l5, !tbaa !29
  %t38 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v4)
  store %"compiler/source:Names" %t38, ptr %l29
  br label %bb5
bb5:
  %t39 = load %"compiler/source:Names", ptr %l29
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 104, i64 8)
  store %"compiler/source:Names" %t39, ptr %t40
  store ptr %t40, ptr %l6, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %v4)
  store { i64, ptr } %t42, ptr %l31
  br label %bb6
bb6:
  %t43 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t56, ptr %v4, ptr %v1, ptr %v4, ptr %v4, ptr %v2, ptr %v4, { i64, ptr } %t49, ptr %t52, ptr %t53, ptr %t54, ptr %t55)
  call void @llvm.memmove.p0.p0.i64(ptr %l38, ptr %t56, i64 600, i1 false)
  br label %bb7
bb7:
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 600, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %l38, i64 600, i1 false)
  store ptr %t62, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l7, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 1
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t77 = extractvalue { i64, ptr } %t74, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t84 = getelementptr %"compiler/load:Loader", ptr %t64, i32 0, i32 17
  store { i64, ptr } %t81, ptr %t84, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v1, ptr %s2, ptr %t85)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l46
  br label %bb8
bb8:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t89 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %t89
  store ptr %t89, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t91 = load i64, ptr %l9, !tbaa !24
  store i64 %t91, ptr %l48, !tbaa !24
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t92)
  store i64 %t94, ptr %l50
  br label %bb10
bb10:
  %t95 = load i64, ptr %l48, !tbaa !24
  %t96 = load i64, ptr %l50, !tbaa !24
  %t97 = icmp slt i64 %t95, %t96
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  br label %bb13
bb13:
  %t101 = load ptr, ptr %l8, !tbaa !29
  %t102 = load i64, ptr %l9, !tbaa !24
  %t105 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t101, i64 %t102)
  store { i64, ptr } %t105, ptr %l55
  br label %bb14
bb14:
  %t106 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr %"compiler/load:Loader", ptr %t107, i32 0, i32 18
  %t112 = extractvalue { i64, ptr } %t106, 1
  %t113 = extractvalue { i64, ptr } %t106, 0
  %t114 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t112, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t118 = extractvalue { i64, ptr } %t116, 0
  %t119 = extractvalue { i64, ptr } %t116, 1
  %t120 = mul i64 %t118, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t120)
  call void @llvm.memcpy.p0.p0.i64(ptr %t121, ptr %t119, i64 %t120, i1 false)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t109, { i64, ptr } %t123)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l9, !tbaa !24
  br label %bb9
bb17:
  call void @__olang_scope_close(ptr %s2)
  %t132 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v3, ptr %v3, ptr %a3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t132, ptr %l64
  br label %bb18
bb18:
  %t133 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l64
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t133, ptr %l11
  br label %bb19
bb19:
  %t135 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v3, ptr %v3, ptr %l11)
  %t136 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t135, 1
  %t137 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t135, 0
  store i32 %t137, ptr %l68
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb21, label %ok.139, !prof !99
ok.139:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t136, ptr %l67
  br label %bb20
bb20:
  %t140 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l67
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t140, ptr %l65
  br label %bb23
bb21:
  %t141 = load i32, ptr %l68, !tbaa !23
  %t142 = ashr i32 %t141, 16
  %t144 = icmp eq i32 %t142, 1
  store i1 %t144, ptr %l70, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  br label %bb26
bb23:
  %t145 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l65
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t145, ptr %l12
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t148 = getelementptr %"compiler/load:Loader", ptr %t146, i32 0, i32 13
  %t149 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l12, i32 0, i32 0
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = extractvalue { i64, ptr } %t150, 0
  %t154 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t152, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t164 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l12, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t167, i64 %t168)
  %t170 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v4, ptr %v4, ptr %v4, ptr %t148, { i64, ptr } %t163, { i64, ptr } %t178)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb19
bb26:
  %t182 = call i64 @std_2ftime_2eNow()
  store i64 %t182, ptr %l79
  br label %bb27
bb27:
  %t183 = load i64, ptr %l79, !tbaa !24
  store i64 %t183, ptr %l13, !tbaa !24
  %t184 = load ptr, ptr %l7, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t188 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v4, ptr %v0, ptr %t184, { i64, ptr } %t185)
  store i64 %t188, ptr %l82
  br label %bb28
bb28:
  %t189 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t189, ptr %l83, !tbaa !27
  %t190 = load ptr, ptr %l7, !tbaa !29
  %t192 = getelementptr %"compiler/load:Loader", ptr %t190, i32 0, i32 10
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v4, ptr %t192)
  store i64 %t194, ptr %l86
  br label %bb29
bb29:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t197 = call i64 @std_2ftime_2eSince(i64 %t195)
  store i64 %t197, ptr %l88
  br label %bb30
bb30:
  %t198 = load i64, ptr %l88, !tbaa !24
  %t199 = sdiv i64 %t198, 1000000
  %t200 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t202 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = load i64, ptr %l86, !tbaa !24
  %t210 = call i64 @__olang_fmt_i64(ptr null, i64 %t209)
  %t211 = add i64 %t208, %t210
  %t212 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t216 = call i64 @__olang_fmt_i64(ptr null, i64 %t199)
  %t217 = add i64 %t214, %t216
  %t218 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t200, i64 %t201)
  %t222 = getelementptr i8, ptr %t221, i64 %t201
  call void @olang_textcopy(ptr %t222, ptr %t203, i64 %t204)
  %t223 = getelementptr i8, ptr %t222, i64 %t204
  call void @olang_textcopy(ptr %t223, ptr %t206, i64 %t207)
  %t224 = getelementptr i8, ptr %t223, i64 %t207
  %t225 = call i64 @__olang_fmt_i64(ptr %t224, i64 %t209)
  %t226 = getelementptr i8, ptr %t224, i64 %t210
  call void @olang_textcopy(ptr %t226, ptr %t212, i64 %t213)
  %t227 = getelementptr i8, ptr %t226, i64 %t213
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t199)
  %t229 = getelementptr i8, ptr %t227, i64 %t216
  call void @olang_textcopy(ptr %t229, ptr %t218, i64 %t219)
  %t230 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t221, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t238)
  br label %bb31
bb31:
  %t240 = load ptr, ptr %l7, !tbaa !29
  %t242 = call %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v4, ptr %v4, ptr %t240)
  store %"compiler/session:Analysis" %t242, ptr %l93
  br label %bb32
bb32:
  %t243 = load %"compiler/session:Analysis", ptr %l93
  %t244 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"compiler/session:Analysis" %t243, ptr %t244
  store ptr %t244, ptr %l14, !tbaa !29
  %t246 = load ptr, ptr %l7, !tbaa !29
  %t248 = getelementptr %"compiler/load:Loader", ptr %t246, i32 0, i32 12
  %t249 = load i64, ptr %t248, !tbaa !24
  %t251 = icmp slt i64 %t249, 0
  br i1 %t251, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb36
bb34:
  %t253 = load ptr, ptr %l2, !tbaa !29
  %t255 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t253)
  store i1 %t255, ptr %l100
  br label %bb35
bb35:
  %t256 = load i1, ptr %l100, !tbaa !21
  store i1 %t256, ptr %l98, !tbaa !21
  br label %bb36
bb36:
  %t257 = load i1, ptr %l98, !tbaa !21
  br i1 %t257, label %bb37, label %bb38
bb37:
  %t258 = load ptr, ptr %l14, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t258, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t260 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t261, ptr %v4, ptr %v4, ptr %t260, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l103, ptr %t261, i64 4744, i1 false)
  br label %bb40
bb40:
  %t263 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 4744, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t263, ptr %l103, i64 4744, i1 false)
  store ptr %t263, ptr %l15, !tbaa !29
  %t265 = load ptr, ptr %l14, !tbaa !29
  %t266 = load ptr, ptr %l15, !tbaa !29
  %t270 = getelementptr %"compiler/session:Analysis", ptr %t265, i32 0, i32 1
  store ptr %t266, ptr %t270, !tbaa !29
  %t271 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t271, ptr %l108
  br label %bb41
bb41:
  %t272 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l108
  %t273 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t272, ptr %t273
  store ptr %t273, ptr %l16, !tbaa !29
  %t275 = load ptr, ptr %l2, !tbaa !29
  %t277 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t275)
  store i64 %t277, ptr %l111
  br label %bb42
bb42:
  %t278 = load i64, ptr %l111, !tbaa !24
  %t279 = icmp eq i64 %t278, 0
  store i1 %t279, ptr %l17, !tbaa !21
  %t281 = load i1, ptr %l17, !tbaa !21
  br i1 %t281, label %bb43, label %bb44
bb43:
  %t283 = load ptr, ptr %l15, !tbaa !29
  %t285 = call i64 @compiler_2finterp_2eDecideValues(ptr %v4, ptr %t283)
  store i64 %t285, ptr %l115
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t286 = load ptr, ptr %l15, !tbaa !29
  %t287 = load ptr, ptr %l16, !tbaa !29
  %t290 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v4, ptr %s0, ptr %t286, ptr %t287)
  store i64 %t290, ptr %l118
  br label %bb47
bb47:
  %t291 = load i1, ptr %l17, !tbaa !21
  br i1 %t291, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s13
  %t293 = load ptr, ptr %l15, !tbaa !29
  %t295 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v4, ptr %s13, ptr %t293)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t295, ptr %l121
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb51:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t298 = call i64 @std_2ftime_2eSince(i64 %t296)
  store i64 %t298, ptr %l123
  br label %bb52
bb52:
  %t299 = load i64, ptr %l123, !tbaa !24
  %t300 = sdiv i64 %t299, 1000000
  %t301 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t302 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t304 = call i64 @__olang_fmt_i64(ptr null, i64 %t300)
  %t305 = add i64 %t302, %t304
  %t306 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t308)
  call void @olang_textcopy(ptr %t309, ptr %t301, i64 %t302)
  %t310 = getelementptr i8, ptr %t309, i64 %t302
  %t311 = call i64 @__olang_fmt_i64(ptr %t310, i64 %t300)
  %t312 = getelementptr i8, ptr %t310, i64 %t304
  call void @olang_textcopy(ptr %t312, ptr %t306, i64 %t307)
  %t313 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t309, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = extractvalue { i64, ptr } %t314, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t321)
  br label %bb53
bb53:
  br i1 %a4, label %bb54, label %bb55
bb54:
  %t325 = load ptr, ptr %l14, !tbaa !29
  %t326 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2eHold(ptr %v4, ptr %v1, ptr %t325, ptr %t326)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t329 = load ptr, ptr %l14, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t329, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca %"compiler/diag:Diagnostics"
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l12 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l4
  br label %bb1
bb1:
  %t3 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %v1, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %t2, i64 544, i1 false)
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l5, i64 544, i1 false)
  store ptr %t4, ptr %l2, !tbaa !29
  store { i64, ptr } %a0, ptr %l7, !tbaa !27
  store ptr %a1, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l10
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t16 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t12, ptr %t13, ptr %t14, ptr %t11, i1 false)
  store ptr %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l12, !tbaa !29
  store ptr %t17, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l14
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s1, ptr %t32)
  store { i64, ptr } %t34, ptr %l21
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t41)
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v1, ptr %s1, ptr %t43)
  store { i64, ptr } %t45, ptr %l24
  br label %bb13
bb13:
  %t46 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = extractvalue { i64, ptr } %t46, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t52)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/session:Analysis", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  br i1 %t60, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_955cfaf9738e6bc2_e48fc09138963b26)
  unreachable
bb17:
  br label %bb18
bb18:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/session:Analysis", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fexplain_2eCaps(ptr %v1, ptr %s0, ptr %t65)
  store { i64, ptr } %t67, ptr %l32
  br label %bb19
bb19:
  %t68 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @compiler_2fsession_2esay(ptr %s0, { i64, ptr } %t74)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca { i32, i32 }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/session:Reader"
  %l6 = alloca i32
  %l7 = alloca { i32, i32 }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i32
  %l21 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca %"compiler/session:Reader"
  %l38 = alloca i1
  %l42 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load { i32, i32 }, ptr %l7
  store { i32, i32 } %t2, ptr %l1
  %t3 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t6 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t11 = icmp slt i32 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { ptr, ptr }, ptr %l0
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  %t17 = call { i64, ptr } %t15(ptr %t16, ptr %v1)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t19 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t18, 0
  %t20 = insertvalue { { i64, ptr }, i32 } %t19, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t20, ptr %rv
  br label %ret
bb5:
  %t22 = call i32 @fork()
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t28)
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t30 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t30)
  br label %bb10
bb10:
  %t32 = load { ptr, ptr }, ptr %l0
  %t34 = extractvalue { ptr, ptr } %t32, 0
  %t35 = extractvalue { ptr, ptr } %t32, 1
  %t36 = call { i64, ptr } %t34(ptr %t35, ptr %v1)
  store { i64, ptr } %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t38 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t37, 0
  %t39 = insertvalue { { i64, ptr }, i32 } %t38, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t39, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp eq i32 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t45)
  br label %bb15
bb14:
  br label %bb23
bb15:
  call void @compiler_2fsession_2eDup2(i32 2, i32 1)
  br label %bb16
bb16:
  %t47 = load i32, ptr %l3, !tbaa !23
  store i32 %t47, ptr %l26, !tbaa !23
  %t48 = load { ptr, ptr }, ptr %l0
  %t50 = extractvalue { ptr, ptr } %t48, 0
  %t51 = extractvalue { ptr, ptr } %t48, 1
  %t52 = call { i64, ptr } %t50(ptr %t51, ptr %s3)
  store { i64, ptr } %t52, ptr %l28
  br label %bb17
bb17:
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load i32, ptr %l26, !tbaa !23
  %t63 = call i32 @std_2fio_2eWrite(ptr %s3, i32 %t61, { i64, ptr } %t60)
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65, !prof !99
ok.65:
  br label %bb18
bb18:
  br label %bb21
bb19:
  %t66 = load i32, ptr %l31, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  br label %bb21
bb21:
  call void @_exit(i32 0)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_35fd852a81194674_cc9a5a6794b34358)
  unreachable
bb23:
  %t70 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t70)
  br label %bb24
bb24:
  %t72 = load i32, ptr %l2, !tbaa !23
  %t74 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 %t72)
  store %"compiler/session:Reader" %t74, ptr %l36
  br label %bb25
bb25:
  %t75 = load %"compiler/session:Reader", ptr %l36
  store %"compiler/session:Reader" %t75, ptr %l5
  br label %bb26
bb26:
  %t77 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %l5)
  store i1 %t77, ptr %l38
  br label %bb27
bb27:
  %t78 = load i1, ptr %l38, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb28, label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb26
bb32:
  %t81 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t81)
  br label %bb33
bb33:
  %t83 = load i32, ptr %l4, !tbaa !23
  %t85 = call i32 @compiler_2fsession_2eReap(i32 %t83)
  store i32 %t85, ptr %l42
  br label %bb34
bb34:
  %t86 = load i32, ptr %l42, !tbaa !23
  store i32 %t86, ptr %l6, !tbaa !23
  %t87 = getelementptr %"compiler/session:Reader", ptr %l5, i32 0, i32 1
  %t89 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %s0, ptr %s0, ptr %t87)
  store { i64, ptr } %t89, ptr %l44
  br label %bb35
bb35:
  %t90 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l46, !tbaa !24
  %t93 = load i64, ptr %l46, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l47, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l46, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = extractvalue { i64, ptr } %t104, 0
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t106, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load i32, ptr %l6, !tbaa !23
  %t113 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t110, 0
  %t115 = insertvalue { { i64, ptr }, i32 } %t113, i32 %t111, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local void @compiler_2fsession_2eCloseFd(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l4 = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp sge i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l0, !tbaa !23
  %t7 = call i32 @close(i32 %t5)
  store i32 %t7, ptr %l4
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca [2 x { i64, ptr }]
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca %"compiler/diag:Diagnostics"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l31 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i1
  %l39 = alloca i1
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l63 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l76 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca { i64, [3 x i64] }
  %l80 = alloca { i64, ptr }
  %l82 = alloca %"compiler/msgs:Msg"
  %l83 = alloca i64
  %l85 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l99 = alloca ptr
  %l108 = alloca %"compiler/doc:Module"
  %l110 = alloca { i64, ptr }
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca { i64, ptr }
  %l131 = alloca i64
  %l135 = alloca i32
  %l137 = alloca i1
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca { i64, ptr }
  %l156 = alloca i32
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca i32
  %l163 = alloca i1
  %l164 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca %"compiler/doc:Module"
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca i32
  %l196 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca i32
  %t6 = alloca %"compiler/diag:Diagnostics", align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  %t331 = alloca { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t3, ptr %l21
  br label %bb1
bb1:
  %t4 = load i1, ptr %l21, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t5, ptr %l22
  br label %bb4
bb3:
  br label %bb56
bb4:
  %t7 = load i1, ptr %l22, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t6, ptr %v3, i1 %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t6, i64 544, i1 false)
  br label %bb5
bb5:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t8, ptr %l23, i64 544, i1 false)
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l25, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %t12, i64 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !37
  store { i64, ptr } %t14, ptr %l26, !tbaa !27
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l27, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l29
  br label %bb6
bb6:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l29
  %t19 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %t19
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t21 = load ptr, ptr %l27, !tbaa !29
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t24 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v3, ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t20, ptr %t21, ptr %t22, ptr %t19, i1 true)
  store ptr %t24, ptr %l31
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l31, !tbaa !29
  store ptr %t25, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t26)
  store i64 %t28, ptr %l33
  br label %bb8
bb8:
  %t29 = load i64, ptr %l33, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/session:Analysis", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  store i1 %t37, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l35, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/session:Analysis", ptr %t40, i32 0, i32 2
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  store i1 %t45, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l39, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t50 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s2, ptr %t48)
  store { i64, ptr } %t50, ptr %l44
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t51 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t57)
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v3, ptr %s2, ptr %t59)
  store { i64, ptr } %t61, ptr %l47
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  %t64 = extractvalue { i64, ptr } %t62, 1
  %t65 = mul i64 %t63, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t64, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t68)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb21:
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t73, ptr %l51
  br label %bb22
bb22:
  %t74 = load i1, ptr %l51, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/session:Analysis", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb25, label %bb26
bb24:
  br label %bb43
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb26:
  br label %bb27
bb27:
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr %"compiler/session:Analysis", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  store ptr %t87, ptr %l58, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/session:Analysis", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = icmp eq ptr %t91, null
  br i1 %t93, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t97 = getelementptr %"compiler/session:Analysis", ptr %t95, i32 0, i32 2
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l63, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t101 = getelementptr %"compiler/session:Analysis", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l5, !tbaa !29
  %t108 = getelementptr %"compiler/session:Analysis", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load ptr, ptr %l5, !tbaa !29
  %t112 = getelementptr %"compiler/session:Analysis", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 12
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t123 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v3, ptr %v3, ptr %v3, ptr %v1, ptr %s3, ptr %t118, ptr %t119, ptr %t109, i64 %t116, { i64, ptr } %t117)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l74
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb35, label %ok.127, !prof !99
ok.127:
  store { i64, ptr } %t124, ptr %l73
  br label %bb34
bb34:
  %t128 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t128, ptr %l53, !tbaa !27
  br label %bb41
bb35:
  %t129 = load i32, ptr %l74, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t133 = load ptr, ptr %l4, !tbaa !29
  store ptr %t133, ptr %l77, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 0, ptr %t135
  %t136 = load { i64, [3 x i64] }, ptr %t134
  store { i64, [3 x i64] } %t136, ptr %l78
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t138, ptr %l80, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr { i64, ptr }, ptr %t140, i64 0
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !37
  %t145 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v1, ptr %v0, ptr %s4, { i64, ptr } %t137, { i64, ptr } %t142)
  store %"compiler/msgs:Msg" %t145, ptr %l82
  br label %bb37
bb37:
  %t146 = load ptr, ptr %l77, !tbaa !29
  %t147 = load { i64, [3 x i64] }, ptr %l78
  %t148 = load %"compiler/msgs:Msg", ptr %l82
  %t149 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v3, ptr %s4, ptr %t146, { i64, [3 x i64] } %t147, %"compiler/msgs:Msg" %t148)
  store i64 %t149, ptr %l83
  br label %bb38
bb38:
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s4, ptr %t150)
  store { i64, ptr } %t152, ptr %l85
  br label %bb39
bb39:
  %t153 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  call void @compiler_2fsession_2esay(ptr %s4, { i64, ptr } %t159)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb41:
  %t162 = load { i64, ptr }, ptr %l53, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s3, { i64, ptr } %t162)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb43:
  %t166 = load ptr, ptr %l5, !tbaa !29
  %t168 = getelementptr %"compiler/session:Analysis", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb45:
  br label %bb46
bb46:
  %t173 = load ptr, ptr %l5, !tbaa !29
  %t175 = getelementptr %"compiler/session:Analysis", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l94, !tbaa !29
  %t177 = load ptr, ptr %l5, !tbaa !29
  %t179 = getelementptr %"compiler/session:Analysis", ptr %t177, i32 0, i32 2
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = icmp eq ptr %t180, null
  br i1 %t182, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb48:
  br label %bb49
bb49:
  %t184 = load ptr, ptr %l5, !tbaa !29
  %t186 = getelementptr %"compiler/session:Analysis", ptr %t184, i32 0, i32 2
  %t187 = load ptr, ptr %t186, !tbaa !29
  store ptr %t187, ptr %l99, !tbaa !29
  %t188 = load ptr, ptr %l5, !tbaa !29
  %t190 = getelementptr %"compiler/session:Analysis", ptr %t188, i32 0, i32 3
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  br i1 %t193, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb51:
  br label %bb52
bb52:
  %t195 = load ptr, ptr %l5, !tbaa !29
  %t197 = getelementptr %"compiler/session:Analysis", ptr %t195, i32 0, i32 3
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t199 = load ptr, ptr %l5, !tbaa !29
  %t201 = getelementptr %"compiler/session:Analysis", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 12
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = load ptr, ptr %l94, !tbaa !29
  %t207 = load ptr, ptr %l99, !tbaa !29
  %t210 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v3, ptr %v3, ptr %v3, ptr %s1, ptr %t206, ptr %t207, ptr %t198, i64 %t205, i1 false)
  store %"compiler/doc:Module" %t210, ptr %l108
  br label %bb53
bb53:
  %t211 = load %"compiler/doc:Module", ptr %l108
  %t212 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 80, i64 8)
  store %"compiler/doc:Module" %t211, ptr %t212
  %t214 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %s1, ptr %s1, ptr %t212)
  store { i64, ptr } %t214, ptr %l110
  br label %bb54
bb54:
  %t215 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t221)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb56:
  %t224 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l113
  br label %bb57
bb57:
  %t225 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t225, ptr %l7
  %t226 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t226, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l10, !tbaa !24
  br label %bb58
bb58:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t233 = load i64, ptr %l10, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb59, label %bb60
bb59:
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t240 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t240, ptr %l121, !tbaa !27
  %t241 = load i64, ptr %l9, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %t244, i64 %t241
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !37
  %t250 = extractvalue { i64, ptr } %t246, 1
  %t251 = extractvalue { i64, ptr } %t246, 0
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t250, i64 %t251)
  %t253 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = extractvalue { i64, ptr } %t254, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t261)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t264 = load i64, ptr %l9, !tbaa !24
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l9, !tbaa !24
  br label %bb58
bb64:
  %t269 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t269, ptr %l131
  br label %bb65
bb65:
  %t270 = load i64, ptr %l131, !tbaa !24
  %t271 = icmp eq i64 %t270, 0
  br i1 %t271, label %bb66, label %bb67
bb66:
  call void @compiler_2fsession_2estdModules(ptr %s0, ptr %l7)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t274 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t276 = call i32 @std_2fos_2eMkDirAll(ptr %v2, { i64, ptr } %t274)
  store i32 %t276, ptr %l135
  %t277 = icmp ne i32 %t276, 0
  br i1 %t277, label %bb71, label %ok.278, !prof !99
ok.278:
  br label %bb70
bb70:
  br label %bb74
bb71:
  %t279 = load i32, ptr %l135, !tbaa !23
  %t280 = ashr i32 %t279, 16
  %t282 = icmp eq i32 %t280, 1
  store i1 %t282, ptr %l137, !tbaa !21
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t283 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t284 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t285 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t287 = extractvalue { i64, ptr } %t283, 1
  %t288 = extractvalue { i64, ptr } %t283, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t284, i64 %t285)
  %t294 = getelementptr i8, ptr %t293, i64 %t285
  call void @olang_textcopy(ptr %t294, ptr %t287, i64 %t288)
  %t295 = getelementptr i8, ptr %t294, i64 %t288
  call void @olang_textcopy(ptr %t295, ptr %t290, i64 %t291)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t293, 1
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t300 = extractvalue { i64, ptr } %t297, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  call void @compiler_2fsession_2esay(ptr %s10, { i64, ptr } %t304)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb74:
  store i32 0, ptr %l12, !tbaa !23
  %t307 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l142
  br label %bb75
bb75:
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %l13
  store ptr %l7, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s13
  %t310 = load i64, ptr %l15, !tbaa !24
  store i64 %t310, ptr %l144, !tbaa !24
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t311)
  store i64 %t313, ptr %l146
  br label %bb77
bb77:
  %t314 = load i64, ptr %l144, !tbaa !24
  %t315 = load i64, ptr %l146, !tbaa !24
  %t316 = icmp slt i64 %t314, %t315
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb95
bb79:
  br label %bb80
bb80:
  %t320 = load ptr, ptr %l14, !tbaa !29
  %t321 = load i64, ptr %l15, !tbaa !24
  %t324 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t320, i64 %t321)
  store { i64, ptr } %t324, ptr %l151
  br label %bb81
bb81:
  %t325 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t325, ptr %l16, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t327 = load ptr, ptr %l3, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t329 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr null, i32 1
  %t330 = ptrtoint ptr %t329 to i64
  %t332 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 0
  store { i64, ptr } %t326, ptr %t332, !tbaa !28
  %t334 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 1
  store ptr %t327, ptr %t334, !tbaa !28
  %t336 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 2
  store { i64, ptr } %t328, ptr %t336, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t338 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 3
  store ptr %s0, ptr %t338, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t339 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 4
  store ptr %v3, ptr %t339, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t340 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t331, i32 0, i32 5
  store ptr %v2, ptr %t340, !tbaa !28
  %t341 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_10, 0
  %t342 = insertvalue { ptr, ptr } %t341, ptr %t331, 1
  %t344 = extractvalue { ptr, ptr } %t342, 0
  %t345 = extractvalue { ptr, ptr } %t342, 1
  %t346 = call i32 @compiler_2fsession_2eInChild(ptr %s13, ptr %t344, ptr %t345)
  store i32 %t346, ptr %l156
  br label %bb82
bb82:
  %t347 = load i32, ptr %l156, !tbaa !23
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb83, label %bb84
bb83:
  store i32 1, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb94
bb84:
  br label %bb85
bb85:
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t352 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s13, { i64, ptr } %t350)
  %t353 = extractvalue { i32, { i64, ptr } } %t352, 1
  %t354 = extractvalue { i32, { i64, ptr } } %t352, 0
  store i32 %t354, ptr %l161
  %t355 = icmp ne i32 %t354, 0
  br i1 %t355, label %bb87, label %ok.356, !prof !99
ok.356:
  store { i64, ptr } %t353, ptr %l160
  br label %bb86
bb86:
  %t357 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t357, ptr %l158, !tbaa !27
  br label %bb89
bb87:
  %t358 = load i32, ptr %l161, !tbaa !23
  %t359 = ashr i32 %t358, 16
  %t361 = icmp eq i32 %t359, 1
  store i1 %t361, ptr %l163, !tbaa !21
  br label %bb88
bb88:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb94
bb89:
  %t362 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t362, ptr %l17, !tbaa !27
  store ptr %l13, ptr %l164, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t365 = call { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %s0, ptr %s0, { i64, ptr } %t363)
  store { i64, ptr } %t365, ptr %l166
  br label %bb90
bb90:
  %t366 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  %t368 = extractvalue { i64, ptr } %t366, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l167, !tbaa !27
  %t373 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t373, 1
  %t376 = extractvalue { i64, ptr } %t373, 0
  %t377 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t375, i64 %t376)
  %t378 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  %t381 = extractvalue { i64, ptr } %t379, 0
  %t382 = extractvalue { i64, ptr } %t379, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l170, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t389 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %s13, ptr %s0, { i64, ptr } %t387)
  store { i64, ptr } %t389, ptr %l172
  br label %bb91
bb91:
  %t390 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t400 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t396)
  store %"compiler/doc:Module" %t400, ptr %l174
  br label %bb92
bb92:
  %t401 = load ptr, ptr %l164, !tbaa !29
  %t402 = load %"compiler/doc:Module", ptr %l174
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %t401, %"compiler/doc:Module" %t402)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s13)
  br label %bb94
bb94:
  %t403 = load i64, ptr %l15, !tbaa !24
  %t405 = add i64 %t403, 1
  store i64 %t405, ptr %l15, !tbaa !24
  br label %bb76
bb95:
  %t407 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t408 = insertvalue { ptr, ptr } %t407, ptr null, 1
  %t411 = extractvalue { ptr, ptr } %t408, 0
  %t412 = extractvalue { ptr, ptr } %t408, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eSort_3cco_Hfcfbe33647fb7db48e9022f22b0d44cf(ptr %s0, ptr %s0, ptr %l13, ptr %t411, ptr %t412)
  br label %bb96
bb96:
  %t413 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t415 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t413, 0
  %t416 = insertvalue [2 x { i64, ptr }] %t415, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t416, ptr %l18
  %t419 = insertvalue { i64, ptr } undef, i64 2, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %l18, 1
  %t422 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t420)
  store { i64, ptr } %t422, ptr %l183
  br label %bb97
bb97:
  %t423 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t423, ptr %l19, !tbaa !27
  %t424 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t424, ptr %l184, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t429 = icmp eq i64 %t427, 0
  br i1 %t429, label %bb98, label %bb99
bb98:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb100
bb99:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l188, !tbaa !27
  br label %bb100
bb100:
  %t432 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t432, ptr %l190
  br label %bb101
bb101:
  %t433 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t434 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t435 = call { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t433, { i64, ptr } %t434)
  store { i64, ptr } %t435, ptr %l191
  br label %bb102
bb102:
  %t436 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  %t439 = extractvalue { i64, ptr } %t436, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  %t444 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t446 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t444, { i64, ptr } %t443)
  store i32 %t446, ptr %l194
  %t447 = icmp ne i32 %t446, 0
  br i1 %t447, label %bb104, label %ok.448, !prof !99
ok.448:
  br label %bb103
bb103:
  br label %bb107
bb104:
  %t449 = load i32, ptr %l194, !tbaa !23
  %t450 = ashr i32 %t449, 16
  %t452 = icmp eq i32 %t450, 1
  store i1 %t452, ptr %l196, !tbaa !21
  br label %bb105
bb105:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s18
  %t453 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t454 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t457 = extractvalue { i64, ptr } %t453, 1
  %t458 = extractvalue { i64, ptr } %t453, 0
  %t459 = add i64 %t455, %t458
  %t460 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t462 = add i64 %t459, %t461
  %t463 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t462)
  call void @olang_textcopy(ptr %t463, ptr %t454, i64 %t455)
  %t464 = getelementptr i8, ptr %t463, i64 %t455
  call void @olang_textcopy(ptr %t464, ptr %t457, i64 %t458)
  %t465 = getelementptr i8, ptr %t464, i64 %t458
  call void @olang_textcopy(ptr %t465, ptr %t460, i64 %t461)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t463, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } %t467, 1
  %t471 = mul i64 %t469, 1
  %t472 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t471)
  call void @llvm.memcpy.p0.p0.i64(ptr %t472, ptr %t470, i64 %t471, i1 false)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t472, 1
  call void @compiler_2fsession_2esay(ptr %s18, { i64, ptr } %t474)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb107:
  %t477 = load i32, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t477, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2eDup2(i32 %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @dup2(i32 %a0, i32 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eExit(i32 %a0) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_exit(i32 %a0)
  unreachable
bb1:
  call void @__olang_check_failed(ptr @olang_loc_eb449e3906b36447_37ec3fcb8d3ba1cb)
  unreachable
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eExitStatus(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l6 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = and i32 %t1, 127
  store i32 %t3, ptr %l1, !tbaa !23
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = icmp eq i32 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i32, ptr %l0, !tbaa !23
  %t11 = ashr i32 %t9, 8
  %t13 = and i32 %t11, 255
  store i32 %t13, ptr %l6, !tbaa !23
  br label %bb3
bb2:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t17 = add i32 128, %t15
  store i32 %t17, ptr %l6, !tbaa !23
  br label %bb3
bb3:
  %t19 = load i32, ptr %l6, !tbaa !23
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fsession_2eFork() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @fork()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2eFormat(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l11 = alloca %"compiler/source:Source"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l4
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t3, ptr %l5
  br label %bb2
bb2:
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t22 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v2, ptr %v1, ptr %v2, { i64, ptr } %t18, { i64, ptr } %a1)
  store %"compiler/source:Source" %t22, ptr %l11
  br label %bb3
bb3:
  store ptr %l11, ptr %l12, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t26 = call { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %s0, ptr %v2, { i64, ptr } %t24)
  store { i64, ptr } %t26, ptr %l15
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = load ptr, ptr %l12, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t38 = call { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v2, ptr %s0, ptr %v2, ptr %s0, ptr %v2, ptr %t34, { i64, ptr } %t35, { i64, ptr } %t33, i1 false, ptr %l2)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l19
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb6, label %ok.42, !prof !99
ok.42:
  store { i64, ptr } %t39, ptr %l18
  br label %bb5
bb5:
  %t43 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t43, ptr %l6, !tbaa !27
  br label %bb7
bb6:
  %t44 = load i32, ptr %l19, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  call void @__olang_scope_close(ptr %s0)
  %t54 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t52, 0
  store { i32, { i64, ptr } } %t54, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t56 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t55, 1
  store { i32, { i64, ptr } } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fsession_2eHold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l26 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"compiler/scope:Scoper"
  %l36 = alloca %"compiler/scope:Scoper"
  %l48 = alloca i64
  %l59 = alloca ptr
  %l66 = alloca %"compiler/interp:Exec"
  %l68 = alloca ptr
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l75 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %t56 = alloca %"compiler/scope:Scoper", align 8
  %t59 = alloca %"compiler/scope:Scoper", align 8
  %t143 = alloca %"compiler/interp:Exec", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/session:Analysis", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %t24)
  store i1 %t26, ptr %l18
  br label %bb6
bb6:
  %t27 = load i1, ptr %l18, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call i64 @std_2ftime_2eNow()
  store i64 %t29, ptr %l19
  br label %bb11
bb11:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_35f6bc648a66c5f9_fb290a2b6e993705)
  unreachable
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_35f6bc648a66c5f9_fb290a2b6e993705)
  unreachable
bb16:
  br label %bb17
bb17:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 14
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l31
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l33
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  call void @compiler_2fscope_3aScoper_2ector(ptr %t56, ptr %v0, ptr %v0, ptr %v0, ptr %t57, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58)
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %t56, i64 5048, i1 false)
  br label %bb19
bb19:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fscope_3aScoper(ptr %t59, ptr %v0, ptr %l34)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t59, i64 5048, i1 false)
  br label %bb20
bb20:
  %t61 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 5048, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %l36, i64 5048, i1 false)
  store ptr %t61, ptr %l4, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t66 = ptrtoint ptr %t65 to i64
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t66, i64 8)
  %t68 = getelementptr { ptr, ptr }, ptr %t67, i32 0, i32 0
  store ptr %t64, ptr %t68, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t70 = getelementptr { ptr, ptr }, ptr %t67, i32 0, i32 1
  store ptr %v0, ptr %t70, !tbaa !28
  %t71 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_17, 0
  %t72 = insertvalue { ptr, ptr } %t71, ptr %t67, 1
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %t63, i32 0, i32 4
  store { ptr, ptr } %t72, ptr %t76
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t80 = ptrtoint ptr %t79 to i64
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t80, i64 8)
  %t82 = getelementptr { ptr, ptr }, ptr %t81, i32 0, i32 0
  store ptr %t78, ptr %t82, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t84 = getelementptr { ptr, ptr }, ptr %t81, i32 0, i32 1
  store ptr %v0, ptr %t84, !tbaa !28
  %t85 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_18, 0
  %t86 = insertvalue { ptr, ptr } %t85, ptr %t81, 1
  %t90 = getelementptr %"compiler/scope:Scoper", ptr %t77, i32 0, i32 5
  store { ptr, ptr } %t86, ptr %t90
  %t91 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %t91)
  br label %bb21
bb21:
  %t93 = load i64, ptr %l2, !tbaa !24
  %t95 = call i64 @std_2ftime_2eSince(i64 %t93)
  store i64 %t95, ptr %l48
  br label %bb22
bb22:
  %t96 = load i64, ptr %l48, !tbaa !24
  %t97 = sdiv i64 %t96, 1000000
  %t98 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t101 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t102 = add i64 %t99, %t101
  %t103 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t98, i64 %t99)
  %t107 = getelementptr i8, ptr %t106, i64 %t99
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t97)
  %t109 = getelementptr i8, ptr %t107, i64 %t101
  call void @olang_textcopy(ptr %t109, ptr %t103, i64 %t104)
  %t110 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t106, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t118)
  br label %bb23
bb23:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t125 = getelementptr %"compiler/session:Analysis", ptr %t120, i32 0, i32 2
  store ptr %t121, ptr %t125, !tbaa !29
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e)
  unreachable
bb25:
  br label %bb26
bb26:
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l59, !tbaa !29
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  br i1 %t137, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e)
  unreachable
bb28:
  br label %bb29
bb29:
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 14
  %t144 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2finterp_3aExec_2ector(ptr %t143, ptr %v0, ptr %v0, ptr %v0, ptr %t144, ptr %t142, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l66, ptr %t143, i64 3776, i1 false)
  br label %bb30
bb30:
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 3776, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %l66, i64 3776, i1 false)
  store ptr %t147, ptr %l5, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  store ptr %t149, ptr %l68, !tbaa !29
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_6f935d255f99d513_bebfb26ca618488f)
  unreachable
bb32:
  br label %bb33
bb33:
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 124
  %t158 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t157
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t158, ptr %l73
  %t160 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %l73)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t160, ptr %l75
  br label %bb34
bb34:
  %t161 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75
  %t162 = load ptr, ptr %l68, !tbaa !29
  %t163 = getelementptr %"compiler/interp:Exec", ptr %t162, i32 0, i32 10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t161, ptr %t163
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l5, !tbaa !29
  %t169 = getelementptr %"compiler/session:Analysis", ptr %t164, i32 0, i32 3
  store ptr %t165, ptr %t169, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca i64
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i1
  %l71 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l84 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t5, ptr %l9
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %s0, ptr %s0, { i64, ptr } %t12)
  store { i64, ptr } %t14, ptr %l11
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  %t16 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l14
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20, !prof !99
ok.20:
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t22, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l15, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l17, !tbaa !24
  %t26 = load i64, ptr %l17, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t37, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l21, !tbaa !24
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l21, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 1
  %t57 = extractvalue { i64, ptr } %t54, 0
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = getelementptr i8, ptr %t61, i64 %t57
  call void @olang_textcopy(ptr %t62, ptr %t58, i64 %t59)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t61, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t53, { i64, ptr } %t71)
  store i1 %t74, ptr %l27
  br label %bb8
bb8:
  %t75 = load i1, ptr %l27, !tbaa !21
  br i1 %t75, label %bb9, label %bb10
bb9:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l30, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t81, 0
  store i64 %t83, ptr %l32, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l33, !tbaa !24
  %t86 = load i64, ptr %l30, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb11, label %bb12
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = extractvalue { i64, ptr } %t90, 0
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t96)
  call void @olang_textcopy(ptr %t97, ptr %t92, i64 %t93)
  %t98 = getelementptr i8, ptr %t97, i64 %t93
  call void @olang_textcopy(ptr %t98, ptr %t94, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t110 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t89, { i64, ptr } %t107)
  store i1 %t110, ptr %l53
  br label %bb23
bb11:
  %t111 = load i64, ptr %l30, !tbaa !24
  %t112 = load i64, ptr %l32, !tbaa !24
  %t113 = icmp sle i64 %t111, %t112
  br i1 %t113, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb13:
  %t115 = load i64, ptr %l32, !tbaa !24
  %t116 = load i64, ptr %l33, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb15:
  %t119 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l30, !tbaa !24
  %t122 = load i64, ptr %l32, !tbaa !24
  %t123 = getelementptr i8, ptr %t120, i64 %t121
  %t124 = sub i64 %t122, %t121
  %t125 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t128 = extractvalue { i64, ptr } %t126, 1
  %t129 = extractvalue { i64, ptr } %t126, 0
  %t130 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t128, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l38, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l40, !tbaa !24
  %t138 = load i64, ptr %l40, !tbaa !24
  %t139 = icmp eq i64 %t134, %t138
  br i1 %t139, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb17:
  %t141 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = load i64, ptr %l40, !tbaa !24
  %t146 = mul i64 %t145, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t142, ptr %t144, i64 %t146, i1 false)
  br label %bb19
bb18:
  %t147 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t147, ptr %l4, !tbaa !27
  br label %bb19
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t148, ptr %l43, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t151 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  store i64 %t152, ptr %l45, !tbaa !24
  %t154 = load i64, ptr %l45, !tbaa !24
  %t155 = icmp eq i64 %t150, %t154
  br i1 %t155, label %bb20, label %bb21
bb20:
  %t157 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = load i64, ptr %l45, !tbaa !24
  %t162 = mul i64 %t161, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t158, ptr %t160, i64 %t162, i1 false)
  br label %bb22
bb21:
  %t163 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l47, !tbaa !24
  %t165 = load i64, ptr %l47, !tbaa !24
  %t166 = mul i64 %t165, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t166)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  store { i64, ptr } %t169, ptr %l48, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l47, !tbaa !24
  %t175 = mul i64 %t174, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t171, ptr %t173, i64 %t175, i1 false)
  %t176 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t176, ptr %l5, !tbaa !27
  br label %bb22
bb22:
  br label %bb36
bb23:
  %t177 = load i1, ptr %l53, !tbaa !21
  br i1 %t177, label %bb24, label %bb25
bb24:
  %t178 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l56, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l58, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l59, !tbaa !24
  %t188 = load i64, ptr %l56, !tbaa !24
  %t189 = icmp sge i64 %t188, 0
  br i1 %t189, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  %t191 = load i64, ptr %l56, !tbaa !24
  %t192 = load i64, ptr %l58, !tbaa !24
  %t193 = icmp sle i64 %t191, %t192
  br i1 %t193, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb28:
  %t195 = load i64, ptr %l58, !tbaa !24
  %t196 = load i64, ptr %l59, !tbaa !24
  %t197 = icmp sle i64 %t195, %t196
  br i1 %t197, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb30:
  %t199 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l56, !tbaa !24
  %t202 = load i64, ptr %l58, !tbaa !24
  %t203 = getelementptr i8, ptr %t200, i64 %t201
  %t204 = sub i64 %t202, %t201
  %t205 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t203, 1
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = extractvalue { i64, ptr } %t206, 0
  %t210 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t209)
  call void @olang_textcopy(ptr %t210, ptr %t208, i64 %t209)
  %t211 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  store { i64, ptr } %t212, ptr %l64, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 0
  %t215 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l66, !tbaa !24
  %t218 = load i64, ptr %l66, !tbaa !24
  %t219 = icmp eq i64 %t214, %t218
  br i1 %t219, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb32:
  %t221 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = load i64, ptr %l66, !tbaa !24
  %t226 = mul i64 %t225, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t222, ptr %t224, i64 %t226, i1 false)
  br label %bb34
bb33:
  %t227 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t227, ptr %l4, !tbaa !27
  br label %bb34
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t228 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t230 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t228, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t230, ptr %l69
  br label %bb37
bb37:
  %t231 = load i1, ptr %l69, !tbaa !21
  %t232 = xor i1 %t231, true
  br i1 %t232, label %bb38, label %bb39
bb38:
  %t234 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t234, 1
  %t238 = extractvalue { i64, ptr } %t234, 0
  %t240 = extractvalue { i64, ptr } %t235, 1
  %t241 = extractvalue { i64, ptr } %t235, 0
  %t242 = add i64 %t238, %t241
  %t243 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t242)
  call void @olang_textcopy(ptr %t243, ptr %t237, i64 %t238)
  %t244 = getelementptr i8, ptr %t243, i64 %t238
  call void @olang_textcopy(ptr %t244, ptr %t240, i64 %t241)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t243, 1
  store { i64, ptr } %t246, ptr %l71, !tbaa !27
  br label %bb41
bb39:
  %t248 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t250 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s0, { i64, ptr } %t248)
  store { i64, ptr } %t250, ptr %l76
  br label %bb40
bb40:
  %t251 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t252, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l71, !tbaa !27
  br label %bb41
bb41:
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t258, ptr %lp6
  %t259 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t260 = load ptr, ptr %lp6
  store { i64, ptr } %t259, ptr %t260, !tbaa !27
  %t261 = load ptr, ptr %lp6
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t264 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t262, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t264, ptr %l79
  br label %bb42
bb42:
  %t265 = load i1, ptr %l79, !tbaa !21
  br i1 %t265, label %bb43, label %bb44
bb43:
  %t266 = load ptr, ptr %lp6
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t271 = sub i64 %t269, 6
  store i64 %t271, ptr %l83, !tbaa !24
  %t272 = load ptr, ptr %lp6
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  store i64 %t274, ptr %l84, !tbaa !24
  %t275 = icmp sge i64 0, 0
  br i1 %t275, label %bb45, label %bb46
bb44:
  %t277 = load ptr, ptr %lp6
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  store { i64, ptr } %t278, ptr %l80, !tbaa !27
  br label %bb51
bb45:
  %t280 = load i64, ptr %l83, !tbaa !24
  %t281 = icmp sle i64 0, %t280
  br i1 %t281, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb47:
  %t283 = load i64, ptr %l83, !tbaa !24
  %t284 = load i64, ptr %l84, !tbaa !24
  %t285 = icmp sle i64 %t283, %t284
  br i1 %t285, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb49:
  %t287 = load ptr, ptr %lp6
  %t288 = getelementptr { i64, ptr }, ptr %t287, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = load i64, ptr %l83, !tbaa !24
  %t291 = getelementptr i8, ptr %t289, i64 0
  %t292 = sub i64 %t290, 0
  %t293 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t291, 1
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = extractvalue { i64, ptr } %t294, 0
  %t298 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t296, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l80, !tbaa !27
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t302 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t302, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fsession_2eIgnoreBrokenPipes() #0 {
entry:
  %l0 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i64 @signal(i32 13, i64 1)
  store i64 %t1, ptr %l0
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2eInChild(ptr %v0, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca i32
  %l2 = alloca [1 x i32]
  %l3 = alloca i32
  %l7 = alloca i32
  %l11 = alloca i32
  %l16 = alloca i32
  %l20 = alloca i32
  %rv = alloca i32
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @fork()
  store i32 %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load i32, ptr %l3, !tbaa !23
  store i32 %t2, ptr %l1, !tbaa !23
  %t3 = load i32, ptr %l1, !tbaa !23
  %t5 = icmp slt i32 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { ptr, ptr }, ptr %l0
  %t9 = extractvalue { ptr, ptr } %t7, 0
  %t10 = extractvalue { ptr, ptr } %t7, 1
  %t11 = call i32 %t9(ptr %t10)
  store i32 %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t12 = load i32, ptr %l7, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
bb5:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t15 = icmp eq i32 %t13, 0
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t17 = load { ptr, ptr }, ptr %l0
  %t19 = extractvalue { ptr, ptr } %t17, 0
  %t20 = extractvalue { ptr, ptr } %t17, 1
  %t21 = call i32 %t19(ptr %t20)
  store i32 %t21, ptr %l11
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t22 = load i32, ptr %l11, !tbaa !23
  call void @_exit(i32 %t22)
  unreachable
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ff40fb5988b00df4_fbbcb1c788c8bd28)
  unreachable
bb10:
  %t23 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t23, ptr %l2
  %t25 = load i32, ptr %l1, !tbaa !23
  %t27 = insertvalue { i64, ptr } undef, i64 1, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %l2, 1
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = extractvalue { i64, ptr } %t28, 0
  %t33 = call i32 @waitpid(i32 %t25, ptr %t31, i32 0)
  store i32 %t33, ptr %l16
  br label %bb11
bb11:
  %t34 = load i32, ptr %l16, !tbaa !23
  %t35 = icmp slt i32 %t34, 0
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i32 1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t38 = getelementptr [1 x i32], ptr %l2, i64 0, i64 0
  %t39 = load i32, ptr %t38, !tbaa !33
  %t41 = call i32 @compiler_2fsession_2eExitStatus(i32 %t39)
  store i32 %t41, ptr %l20
  br label %bb15
bb15:
  %t42 = load i32, ptr %l20, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l14 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t1, i8 34)
  br label %bb1
bb1:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb34
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 34
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t29, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb8
bb7:
  %t31 = load i8, ptr %l5, !tbaa !22
  %t33 = icmp eq i8 %t31, 92
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s5, ptr %t35, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb11
bb10:
  %t37 = load i8, ptr %l5, !tbaa !22
  %t39 = icmp eq i8 %t37, 10
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s7, ptr %t41, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb14
bb13:
  %t43 = load i8, ptr %l5, !tbaa !22
  %t45 = icmp eq i8 %t43, 13
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  %t47 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s9, ptr %t47, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb17
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 9
  br i1 %t51, label %bb18, label %bb19
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb29
bb18:
  store %olang.scope zeroinitializer, ptr %s11
  %t53 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s11, ptr %t53, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb20
bb19:
  %t55 = load i8, ptr %l5, !tbaa !22
  %t58 = icmp ult i8 %t55, 32
  br i1 %t58, label %bb21, label %bb22
bb20:
  call void @__olang_scope_close(ptr %s11)
  br label %bb28
bb21:
  store %olang.scope zeroinitializer, ptr %s13
  %t60 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t60, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t62, i8 %t63)
  br label %bb26
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t67, ptr %l38, !tbaa !27
  %t68 = load i8, ptr %l5, !tbaa !22
  %t71 = lshr i8 %t68, 4
  %t73 = zext i8 %t71 to i64
  %t75 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t66, i8 %t78)
  br label %bb24
bb24:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l45, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t82, ptr %l46, !tbaa !27
  %t83 = load i8, ptr %l5, !tbaa !22
  %t86 = and i8 %t83, 15
  %t88 = zext i8 %t86 to i64
  %t90 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t88
  %t93 = load i8, ptr %t92, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t81, i8 %t93)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s13)
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l3, !tbaa !24
  br label %bb2
bb34:
  %t100 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t100, i8 34)
  br label %bb35
bb35:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eKillAndReap(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i32
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp sle i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i32, ptr %l0, !tbaa !23
  %t7 = call i32 @kill(i32 %t5, i32 9)
  store i32 %t7, ptr %l4
  br label %bb4
bb4:
  %t8 = load i32, ptr %l0, !tbaa !23
  %t10 = call i32 @compiler_2fsession_2eReap(i32 %t8)
  store i32 %t10, ptr %l6
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2eLog(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i1
  %l8 = alloca i32
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d37, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t8, ptr %l4
  br label %bb5
bb5:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = getelementptr i8, ptr %t21, i64 %t15
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t20, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = extractvalue { i64, ptr } %t24, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t31)
  store i32 %t33, ptr %l8
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb10, label %ok.35, !prof !99
ok.35:
  br label %bb9
bb9:
  br label %bb12
bb10:
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = ashr i32 %t36, 16
  %t39 = icmp eq i32 %t37, 1
  store i1 %t39, ptr %l10, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i32 } @compiler_2fsession_2ePipe() #0 {
entry:
  %l0 = alloca [2 x i32]
  %l4 = alloca i32
  %rv = alloca { i32, i32 }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x i32] undef, i32 0, 0
  %t2 = insertvalue [2 x i32] %t1, i32 0, 1
  store [2 x i32] %t2, ptr %l0
  %t5 = insertvalue { i64, ptr } undef, i64 2, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l0, 1
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call i32 @pipe(ptr %t8)
  store i32 %t10, ptr %l4
  br label %bb1
bb1:
  %t11 = load i32, ptr %l4, !tbaa !23
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = insertvalue { i32, i32 } undef, i32 -1, 0
  %t15 = insertvalue { i32, i32 } %t14, i32 -1, 1
  store { i32, i32 } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = getelementptr [2 x i32], ptr %l0, i64 0, i64 0
  %t18 = load i32, ptr %t17, !tbaa !33
  %t19 = getelementptr [2 x i32], ptr %l0, i64 0, i64 1
  %t20 = load i32, ptr %t19, !tbaa !33
  %t22 = insertvalue { i32, i32 } undef, i32 %t18, 0
  %t24 = insertvalue { i32, i32 } %t22, i32 %t20, 1
  store { i32, i32 } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"<poll.h>:pollfd"
  %l22 = alloca %"<poll.h>:pollfd"
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca i64
  %l67 = alloca i32
  %l74 = alloca i64
  %l77 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t21 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l19, !tbaa !24
  store %"<poll.h>:pollfd" zeroinitializer, ptr %l20
  %t6 = load i64, ptr %l19, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call %"<poll.h>:pollfd" @olang_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd()
  store %"<poll.h>:pollfd" %t9, ptr %l22
  br label %bb3
bb2:
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  %t13 = load %"<poll.h>:pollfd", ptr %l22
  store %"<poll.h>:pollfd" %t13, ptr %l20
  br label %bb2
bb4:
  %t14 = load i64, ptr %l19, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb6:
  %t17 = load i64, ptr %l19, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  %t20 = load %"<poll.h>:pollfd", ptr %l20
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, %t17
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr %"<poll.h>:pollfd", ptr %t19, i64 %t25
  store %"<poll.h>:pollfd" %t20, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t19, 1
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l33, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l30, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l9, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l52, !tbaa !27
  %t82 = load i64, ptr %l9, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i32, ptr %t85, i64 %t82
  %t87 = load i32, ptr %t86, !tbaa !33
  %t90 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr %"<poll.h>:pollfd", ptr %t91, i64 %t80
  %t93 = getelementptr %"<poll.h>:pollfd", ptr %t92, i32 0, i32 0
  store i32 %t87, ptr %t93, !tbaa !23
  %t94 = load i64, ptr %l9, !tbaa !24
  %t95 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t97 = trunc i32 %t95 to i16
  %t100 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr %"<poll.h>:pollfd", ptr %t101, i64 %t94
  %t103 = getelementptr %"<poll.h>:pollfd", ptr %t102, i32 0, i32 1
  store i16 %t97, ptr %t103, !tbaa !62
  br label %bb18
bb18:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l8, !tbaa !24
  br label %bb14
bb19:
  %t108 = load i64, ptr %l2, !tbaa !24
  store i64 %t108, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l60, !tbaa !24
  %t110 = icmp sge i64 %t109, 0
  br i1 %t110, label %bb20, label %bb21
bb20:
  %t112 = load i64, ptr %l60, !tbaa !24
  %t113 = mul i64 %t112, 1
  %t114 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t117, ptr %lp10
  %t119 = load ptr, ptr %lp10
  store { i64, ptr } %t116, ptr %t119, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t121 = load i64, ptr %l2, !tbaa !24
  %t125 = extractvalue { i64, ptr } %t120, 1
  %t126 = extractvalue { i64, ptr } %t120, 0
  %t129 = call i32 @poll(ptr %t125, i64 %t121, i32 %a1)
  store i32 %t129, ptr %l67
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01)
  unreachable
bb22:
  %t130 = load i32, ptr %l67, !tbaa !23
  %t131 = icmp sle i32 %t130, 0
  br i1 %t131, label %bb23, label %bb24
bb23:
  %t133 = load ptr, ptr %lp10
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t134, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l11, !tbaa !24
  %t136 = load i64, ptr %l2, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb26, label %bb27
bb26:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb31
bb28:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l13, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l13, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l77, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb30
bb30:
  %t164 = load i64, ptr %l77, !tbaa !24
  store i64 %t164, ptr %l74, !tbaa !24
  br label %bb31
bb31:
  %t165 = load i64, ptr %l74, !tbaa !24
  store i64 %t165, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t174 = load i64, ptr %l11, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t176 = load i64, ptr %l13, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t187 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = getelementptr %"<poll.h>:pollfd", ptr %t188, i64 %t185
  %t190 = getelementptr %"<poll.h>:pollfd", ptr %t189, i32 0, i32 2
  %t191 = load i16, ptr %t190, !tbaa !62
  %t192 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t193 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLERR, !tbaa !23
  %t196 = or i32 %t192, %t193
  %t197 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLHUP, !tbaa !23
  %t200 = or i32 %t196, %t197
  %t202 = trunc i32 %t200 to i16
  %t205 = and i16 %t191, %t202
  %t207 = icmp ne i16 %t205, 0
  %t209 = load ptr, ptr %lp10
  %t211 = getelementptr { i64, ptr }, ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i1, ptr %t212, i64 %t184
  store i1 %t207, ptr %t213, !tbaa !31
  br label %bb36
bb36:
  %t214 = load i64, ptr %l15, !tbaa !24
  %t216 = add i64 %t214, 1
  store i64 %t216, ptr %l15, !tbaa !24
  br label %bb32
bb37:
  %t218 = load ptr, ptr %lp10
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t219, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %s0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t9, ptr %l1, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t12, ptr %l7
  br label %bb5
bb5:
  %t13 = load i1, ptr %l7, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t18, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l9, !tbaa !27
  br label %bb8
bb7:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t26, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fsession_2eReap(i32 %a0) #0 {
entry:
  %l1 = alloca [1 x i32]
  %l6 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t1, ptr %l1
  %t5 = insertvalue { i64, ptr } undef, i64 1, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %l1, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @waitpid(i32 %a0, ptr %t9, i32 0)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp slt i32 %t12, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i32 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = getelementptr [1 x i32], ptr %l1, i64 0, i64 0
  %t17 = load i32, ptr %t16, !tbaa !33
  %t19 = call i32 @compiler_2fsession_2eExitStatus(i32 %t17)
  store i32 %t19, ptr %l10
  br label %bb5
bb5:
  %t20 = load i32, ptr %l10, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [2 x { i64, ptr }]
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb4
bb3:
  br label %bb12
bb4:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l5, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l6, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t14, 0
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l10, !tbaa !24
  %t20 = icmp sge i64 4, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sle i64 4, %t22
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb7:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l10, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb9:
  %t29 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = getelementptr i8, ptr %t30, i64 4
  %t33 = sub i64 %t31, 4
  %t34 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t32, 1
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t37 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t36, 0
  %t39 = insertvalue [2 x { i64, ptr }] %t37, { i64, ptr } %t35, 1
  store [2 x { i64, ptr }] %t39, ptr %l1
  %t42 = insertvalue { i64, ptr } undef, i64 2, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %l1, 1
  %t45 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %s1, { i64, ptr } %t43)
  store { i64, ptr } %t45, ptr %l18
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb11:
  %t46 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t47, i64 %t48)
  %t53 = getelementptr i8, ptr %t52, i64 %t48
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t55, ptr %rv
  br label %ret
bb12:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = extractvalue { i64, ptr } %t57, 0
  %t61 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t59, i64 %t60)
  %t65 = getelementptr i8, ptr %t64, i64 %t60
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fsession_2eSymbols(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"compiler/session:symWriter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca %"compiler/session:symWriter"
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t1, i8 91)
  br label %bb1
bb1:
  %t5 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v1, ptr %s0, ptr %a1)
  store %"compiler/session:symWriter" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"compiler/session:symWriter", ptr %l11
  store %"compiler/session:symWriter" %t6, ptr %l4
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t13, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l7, !tbaa !24
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t35 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %s0, ptr %v0, ptr %v2, ptr %v3, ptr %l4, ptr %t35, ptr %t33, ptr %a3)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l6, !tbaa !24
  br label %bb5
bb11:
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t46, i8 93)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l18 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l51 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp sgt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l14, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t20, 1
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t22
  %t27 = load i8, ptr %t26, !tbaa !32
  %t29 = call i1 @compiler_2fsession_2eWordChar(i8 %t27)
  store i1 %t29, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb4
bb13:
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load i64, ptr %l2, !tbaa !24
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t54 = icmp slt i64 %t48, %t51
  br i1 %t54, label %bb18, label %bb19
bb18:
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t56, ptr %l32, !tbaa !27
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = call i1 @compiler_2fsession_2eWordChar(i8 %t62)
  store i1 %t64, ptr %l35
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb20:
  %t65 = load i1, ptr %l35, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l31, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l3, !tbaa !24
  br label %bb25
bb25:
  br label %bb17
bb26:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  br i1 %t77, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb30
bb28:
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t79, ptr %l43, !tbaa !27
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t85)
  store i1 %t87, ptr %l46
  br label %bb29
bb29:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %l42, !tbaa !21
  br label %bb30
bb30:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l1, !tbaa !24
  %t92 = trunc i64 %t90 to i32
  %t93 = load i64, ptr %l1, !tbaa !24
  %t95 = trunc i64 %t93 to i32
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t92, i32 %t95)
  store %"compiler/source:Span" %t98, ptr %l51
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load %"compiler/source:Span", ptr %l51
  store %"compiler/source:Span" %t99, ptr %rv
  br label %ret
bb34:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t102 = trunc i64 %t100 to i32
  %t103 = load i64, ptr %l3, !tbaa !24
  %t105 = trunc i64 %t103 to i32
  %t108 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t102, i32 %t105)
  store %"compiler/source:Span" %t108, ptr %l56
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load %"compiler/source:Span", ptr %l56
  store %"compiler/source:Span" %t109, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fsession_2eWordChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t18 = icmp uge i8 %t15, -128
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t20 = load i1, ptr %l9, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fsession_2eWriteFramed(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l9 = alloca i32
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t9 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t10 = add i64 %t7, %t9
  %t11 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = extractvalue { i64, ptr } %t5, 1
  %t16 = extractvalue { i64, ptr } %t5, 0
  %t17 = add i64 %t13, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t6, i64 %t7)
  %t19 = getelementptr i8, ptr %t18, i64 %t7
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t4)
  %t21 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t21, ptr %t11, i64 %t12)
  %t22 = getelementptr i8, ptr %t21, i64 %t12
  call void @olang_textcopy(ptr %t22, ptr %t15, i64 %t16)
  %t23 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t18, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } %t24, 1
  %t29 = mul i64 %t27, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t29)
  call void @llvm.memcpy.p0.p0.i64(ptr %t30, ptr %t28, i64 %t29, i1 false)
  %t31 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t35 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %a0, { i64, ptr } %t32)
  store i32 %t35, ptr %l9
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb2, label %ok.37, !prof !99
ok.37:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t38 = load i32, ptr %l9, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  store i1 %t41, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eLookup(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l12 = alloca i1
  %l19 = alloca { i64, ptr }
  %l22 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, [6 x i64] }
  %l31 = alloca %"compiler/session:Found"
  %l34 = alloca %"compiler/session:Found"
  %l35 = alloca i32
  %rv = alloca { i32, %"compiler/session:Found" }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %a1)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t20, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store { i64, ptr } %t25, ptr %l19
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t31 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t26, i64 %a2)
  store %"compiler/source:Span" %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t32, ptr %l5
  %t33 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  %t35 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = icmp eq i32 %t34, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t42 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t42, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i64, ptr %l3, !tbaa !24
  %t45 = load %"compiler/source:Span", ptr %l5
  %t49 = call { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %v0, ptr %t43, i64 %t44, %"compiler/source:Span" %t45)
  store { i64, [6 x i64] } %t49, ptr %l30
  br label %bb13
bb13:
  %t50 = load { i64, [6 x i64] }, ptr %l30
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t55 = call { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edescribe(ptr %v0, ptr %v0, ptr %v2, ptr %t51, { i64, [6 x i64] } %t50)
  %t56 = extractvalue { i32, %"compiler/session:Found" } %t55, 1
  %t57 = extractvalue { i32, %"compiler/session:Found" } %t55, 0
  store i32 %t57, ptr %l35
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb15, label %ok.59, !prof !99
ok.59:
  store %"compiler/session:Found" %t56, ptr %l34
  br label %bb14
bb14:
  %t60 = load %"compiler/session:Found", ptr %l34
  store %"compiler/session:Found" %t60, ptr %l31
  br label %bb16
bb15:
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = lshr i32 %t61, 16
  %t63 = and i32 %t61, 65535
  %t64 = icmp eq i32 %t62, 1
  %t65 = select i1 %t64, i32 1, i32 0
  %t66 = icmp eq i32 %t61, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t63
  %t69 = select i1 %t66, i32 0, i32 %t68
  %t71 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t69, 0
  store { i32, %"compiler/session:Found" } %t71, ptr %rv
  br label %ret
bb16:
  %t72 = load %"compiler/session:Found", ptr %l31
  %t73 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t72, 1
  store { i32, %"compiler/session:Found" } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/session:Found" }, ptr %rv
  ret { i32, %"compiler/session:Found" } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l38 = alloca i1
  %l51 = alloca %"compiler/names:Ref"
  %l62 = alloca %"compiler/names:Ref"
  %l71 = alloca i32
  %l72 = alloca i64
  %l76 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l24
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/session:Analysis", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 10
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l29
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t42 = getelementptr %"compiler/load:Module", ptr %t40, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t45, i64 %t46)
  store %"compiler/source:Span" %t49, ptr %l34
  br label %bb10
bb10:
  %t50 = load %"compiler/source:Span", ptr %l34
  store %"compiler/source:Span" %t50, ptr %l8
  %t51 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t57 = icmp slt i32 %t52, %t54
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  store i1 %t66, ptr %l38, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l38, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb16, label %bb17
bb15:
  br label %bb31
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3178b68d0296f164_92041ef9c14564d0)
  unreachable
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t87 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t80, i64 %t81, i32 %t83)
  store %"compiler/names:Ref" %t87, ptr %l51
  br label %bb19
bb19:
  %t88 = load %"compiler/names:Ref", ptr %l51
  store %"compiler/names:Ref" %t88, ptr %l9
  %t89 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t90 = load i32, ptr %t89, !range !{i32 0, i32 9}
  %t92 = trunc i64 0 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  br i1 %t97, label %bb22, label %bb23
bb21:
  br label %bb26
bb22:
  call void @__olang_check_failed(ptr @olang_loc_d917d39333aa2133_631bc7dad212aa2f)
  unreachable
bb23:
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load i64, ptr %l7, !tbaa !24
  %t108 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t113 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t106, i64 %t107, i32 %t109)
  store %"compiler/names:Ref" %t113, ptr %l62
  br label %bb25
bb25:
  %t114 = load %"compiler/names:Ref", ptr %l62
  store %"compiler/names:Ref" %t114, ptr %l9
  br label %bb26
bb26:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 9}
  %t118 = trunc i64 5 to i32
  %t119 = icmp eq i32 %t116, %t118
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t121, ptr %t122, i64 %t124, i1 false)
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  br label %bb31
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l3, !tbaa !24
  %t134 = call i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %t128, i64 %t129, i64 %t130)
  store i32 %t134, ptr %l71
  br label %bb32
bb32:
  %t135 = load i32, ptr %l71, !tbaa !23
  store i32 %t135, ptr %l10, !tbaa !23
  %t136 = load i64, ptr %l3, !tbaa !24
  store i64 %t136, ptr %l72, !tbaa !24
  %t137 = load i32, ptr %l10, !tbaa !23
  %t138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t141 = icmp ne i32 %t137, %t138
  br i1 %t141, label %bb33, label %bb34
bb33:
  %t143 = load ptr, ptr %l5, !tbaa !29
  %t145 = icmp eq ptr %t143, null
  br i1 %t145, label %bb35, label %bb36
bb34:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8be86b180d8510f2_8625cf113e27a67e)
  unreachable
bb36:
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l5, !tbaa !29
  %t148 = load i32, ptr %l10, !tbaa !23
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t147, i32 %t148)
  store { i64, ptr } %t151, ptr %l81
  br label %bb38
bb38:
  %t152 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t154 = extractvalue { i64, ptr } %t152, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l76, !tbaa !27
  br label %bb39
bb39:
  %t160 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t162 = load i64, ptr %l72, !tbaa !24
  %t163 = call i64 @__olang_fmt_i64(ptr null, i64 %t162)
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t160, i64 %t161)
  %t173 = getelementptr i8, ptr %t172, i64 %t161
  %t174 = call i64 @__olang_fmt_i64(ptr %t173, i64 %t162)
  %t175 = getelementptr i8, ptr %t173, i64 %t163
  call void @olang_textcopy(ptr %t175, ptr %t165, i64 %t166)
  %t176 = getelementptr i8, ptr %t175, i64 %t166
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t172, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t185)
  br label %bb40
bb40:
  %t187 = load i32, ptr %l10, !tbaa !23
  %t188 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t191 = icmp eq i32 %t187, %t188
  br i1 %t191, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  br label %bb43
bb43:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t195 = load i32, ptr %l10, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %t193, ptr %t194, i32 %t195)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l40 = alloca ptr
  %l44 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/session:Analysis", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 10
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l40
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t69, { i64, ptr } %a1)
  store i1 %t73, ptr %l44
  br label %bb13
bb13:
  %t74 = load i1, ptr %l44, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load i64, ptr %l7, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/load:Import"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i1
  %l38 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca ptr
  %l60 = alloca i1
  %l66 = alloca i1
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"compiler/typed:Local"
  %l84 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l116 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l132 = alloca i64
  %l134 = alloca i64
  %l139 = alloca %"compiler/load:Import"
  %l149 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i64
  %l178 = alloca ptr
  %s8 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i64, ptr %l27, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l30, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l38
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l38, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/session:Analysis", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_804f8b0fb45e435f_c5484f8454187243)
  unreachable
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/session:Analysis", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 14
  store ptr %t47, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l7, !tbaa !24
  store i64 %t49, ptr %l48, !tbaa !24
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l50
  br label %bb13
bb13:
  %t53 = load i64, ptr %l48, !tbaa !24
  %t54 = load i64, ptr %l50, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  br label %bb60
bb15:
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l55
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l55, !tbaa !29
  store ptr %t64, ptr %l8, !tbaa !29
  %t65 = load ptr, ptr %l8, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 3
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp ne i64 %t68, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 4
  %t77 = getelementptr %"compiler/source:Span", ptr %t76, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = icmp sgt i64 %t80, %t81
  store i1 %t84, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 4
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = icmp sgt i64 %t87, %t94
  store i1 %t97, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t99 = load i1, ptr %l66, !tbaa !21
  br i1 %t99, label %bb24, label %bb25
bb24:
  br label %bb59
bb25:
  br label %bb26
bb26:
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Body", ptr %t100, i32 0, i32 7
  store ptr %t102, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l10, !tbaa !24
  store i64 %t104, ptr %l74, !tbaa !24
  %t105 = load ptr, ptr %l9, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t105)
  store i64 %t107, ptr %l76
  br label %bb28
bb28:
  %t108 = load i64, ptr %l74, !tbaa !24
  %t109 = load i64, ptr %l76, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb29, label %bb30
bb29:
  br label %bb58
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l9, !tbaa !29
  %t115 = load i64, ptr %l10, !tbaa !24
  %t118 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t114, i64 %t115)
  store %"compiler/typed:Local" %t118, ptr %l81
  br label %bb32
bb32:
  %t119 = load %"compiler/typed:Local", ptr %l81
  store %"compiler/typed:Local" %t119, ptr %l11
  %t120 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = icmp eq i32 %t121, 0
  br i1 %t123, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb35
bb34:
  %t125 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t126 = getelementptr %"compiler/source:Span", ptr %t125, i32 0, i32 0
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t130 = load i64, ptr %l3, !tbaa !24
  %t133 = icmp sge i64 %t129, %t130
  store i1 %t133, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l84, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  br label %bb57
bb37:
  br label %bb38
bb38:
  %t136 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t137 = load i32, ptr %t136, !range !{i32 0, i32 7}
  %t139 = trunc i64 0 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb41
bb40:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t143 = load i32, ptr %t142, !range !{i32 0, i32 7}
  %t145 = trunc i64 1 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l91, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l91, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb44
bb43:
  %t149 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t150 = load i32, ptr %t149, !range !{i32 0, i32 7}
  %t152 = trunc i64 4 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l94, !tbaa !21
  br label %bb44
bb44:
  %t155 = load i1, ptr %l94, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l97, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/session:Analysis", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb47, label %bb48
bb46:
  br label %bb56
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9033262c592f27c0_922b790dfcbd6cb4)
  unreachable
bb48:
  br label %bb49
bb49:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/session:Analysis", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/load:Loader", ptr %t174, i32 0, i32 3
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s8, ptr %t177, i32 %t179)
  store { i64, ptr } %t182, ptr %l108
  br label %bb50
bb50:
  %t183 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t183, ptr %l109, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/session:Analysis", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_9033262c592f27c0_922b790dfcbd6cb4)
  unreachable
bb52:
  br label %bb53
bb53:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/session:Analysis", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 2
  %t196 = load i32, ptr %t195, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t194, i32 %t196)
  store { i64, ptr } %t199, ptr %l116
  br label %bb54
bb54:
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l97, !tbaa !29
  %t208 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t209 = load i64, ptr %l109, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %s8, ptr %s8, ptr %t207, { i64, ptr } %t208, i64 %t209, { i64, ptr } %t206)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t211 = load i64, ptr %l10, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l10, !tbaa !24
  br label %bb27
bb58:
  br label %bb59
bb59:
  %t215 = load i64, ptr %l7, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l7, !tbaa !24
  br label %bb12
bb60:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t221 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t219, ptr %t220, i64 %t221, i1 true)
  br label %bb61
bb61:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/session:Analysis", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/load:Loader", ptr %t228, i32 0, i32 10
  %t231 = load i64, ptr %l4, !tbaa !24
  %t234 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t230, i64 %t231)
  store ptr %t234, ptr %l129
  br label %bb62
bb62:
  %t235 = load ptr, ptr %l129, !tbaa !29
  %t237 = getelementptr %"compiler/load:Module", ptr %t235, i32 0, i32 11
  store ptr %t237, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb63
bb63:
  %t239 = load i64, ptr %l13, !tbaa !24
  store i64 %t239, ptr %l132, !tbaa !24
  %t240 = load ptr, ptr %l12, !tbaa !29
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t240)
  store i64 %t242, ptr %l134
  br label %bb64
bb64:
  %t243 = load i64, ptr %l132, !tbaa !24
  %t244 = load i64, ptr %l134, !tbaa !24
  %t245 = icmp slt i64 %t243, %t244
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t249 = load ptr, ptr %l12, !tbaa !29
  %t250 = load i64, ptr %l13, !tbaa !24
  %t253 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t249, i64 %t250)
  store %"compiler/load:Import" %t253, ptr %l139
  br label %bb68
bb68:
  %t254 = load %"compiler/load:Import", ptr %l139
  store %"compiler/load:Import" %t254, ptr %l14
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  %t258 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  %t259 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 3
  %t260 = load { i64, ptr }, ptr %t259, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %v0, ptr %t255, { i64, ptr } %t257, i64 %t258, { i64, ptr } %t260)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t265 = load i64, ptr %l13, !tbaa !24
  %t267 = add i64 %t265, 1
  store i64 %t267, ptr %l13, !tbaa !24
  br label %bb63
bb71:
  store i64 0, ptr %l15, !tbaa !24
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/session:Analysis", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/load:Loader", ptr %t272, i32 0, i32 10
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l149
  br label %bb72
bb72:
  %t277 = load i64, ptr %l149, !tbaa !24
  store i64 %t277, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t278 = load i64, ptr %l16, !tbaa !24
  %t279 = load i64, ptr %l15, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb73, label %bb74
bb73:
  %t284 = load i64, ptr %l17, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb78
bb75:
  %t288 = load i64, ptr %l16, !tbaa !24
  %t289 = load i64, ptr %l15, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l17, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l17, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l156, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb77
bb77:
  %t304 = load i64, ptr %l156, !tbaa !24
  store i64 %t304, ptr %l153, !tbaa !24
  br label %bb78
bb78:
  %t305 = load i64, ptr %l153, !tbaa !24
  store i64 %t305, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb79
bb79:
  %t306 = load i64, ptr %l19, !tbaa !24
  %t307 = load i64, ptr %l18, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb80, label %bb81
bb80:
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t314 = load i64, ptr %l15, !tbaa !24
  %t315 = load i64, ptr %l19, !tbaa !24
  %t316 = load i64, ptr %l17, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l20, !tbaa !24
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/session:Analysis", ptr %t324, i32 0, i32 0
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/load:Loader", ptr %t327, i32 0, i32 10
  %t330 = load i64, ptr %l20, !tbaa !24
  %t333 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t329, i64 %t330)
  store ptr %t333, ptr %l178
  br label %bb83
bb83:
  %t334 = load ptr, ptr %l178, !tbaa !29
  %t336 = getelementptr %"compiler/load:Module", ptr %t334, i32 0, i32 3
  %t337 = load i1, ptr %t336, !tbaa !21
  br i1 %t337, label %bb84, label %bb85
bb84:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t341 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t339, ptr %t340, i64 %t341, i1 false)
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t345 = load i64, ptr %l19, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l19, !tbaa !24
  br label %bb79
bb89:
  store ptr @G_2ecompiler_2fsession_2eKeywords, ptr %l21
  store i64 0, ptr %l22, !tbaa !24
  %t350 = load ptr, ptr %l21
  store i64 46, ptr %l23, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s19
  %t353 = load i64, ptr %l22, !tbaa !24
  %t354 = load i64, ptr %l23, !tbaa !24
  %t357 = icmp slt i64 %t353, %t354
  %t359 = xor i1 %t357, true
  br i1 %t359, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb96
bb92:
  br label %bb93
bb93:
  %t361 = load ptr, ptr %l21
  %t362 = load i64, ptr %l22, !tbaa !24
  %t365 = getelementptr [46 x { i64, ptr }], ptr %t361, i64 0, i64 %t362
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !37
  %t368 = load ptr, ptr %l1, !tbaa !29
  %t370 = load i64, ptr @G_2ecompiler_2fsession_2eCompKeyword, !tbaa !24
  %t371 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %t371, ptr %s19, ptr %t368, { i64, ptr } %t366, i64 %t370, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s19)
  br label %bb95
bb95:
  %t375 = load i64, ptr %l22, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l22, !tbaa !24
  br label %bb90
bb96:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eRealOfFile(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca i64
  %l15 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l15, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 4
  %t27 = load i64, ptr %t26, !tbaa !24
  %t31 = icmp eq i64 %t27, %a1
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = extractvalue { i64, ptr } %t36, 0
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t38, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = add i64 %t44, 1
  store i64 %t46, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t48, ptr %l26, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l27, !tbaa !24
  %t51 = load i64, ptr %l27, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = load i64, ptr %l27, !tbaa !24
  %t61 = mul i64 %t60, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t57, ptr %t59, i64 %t61, i1 false)
  %t62 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t62, ptr %l26, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t63, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l7 = alloca ptr
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t10 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t6, i64 %a1)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/load:Module", ptr %t11, i32 0, i32 6
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_657f7671e8d24039_dcdf7cbf2572e335)
  unreachable
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/source:Source", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [6 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [6 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca i64
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca %"compiler/typed:Local"
  %l19 = alloca i64
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l42 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i32
  %l53 = alloca i1
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l90 = alloca %"compiler/session:Found"
  %l100 = alloca i64
  %l107 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca i64
  %l119 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l133 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l171 = alloca %"compiler/session:Found"
  %l176 = alloca %"compiler/session:memberInfo"
  %l180 = alloca %"compiler/session:memberInfo"
  %l181 = alloca i32
  %l183 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l196 = alloca %"compiler/session:Found"
  %l207 = alloca ptr
  %l212 = alloca %"compiler/typed:Local"
  %l216 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l253 = alloca %"compiler/session:Found"
  %l262 = alloca { i64, ptr }
  %l263 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l274 = alloca %"compiler/session:Found"
  %l282 = alloca ptr
  %l286 = alloca { i64, ptr }
  %l294 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l302 = alloca %"compiler/session:Found"
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:Found" }
  store ptr %a0, ptr %l0
  store { i64, [6 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [6 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [6 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, { i64, ptr } }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  %t15 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, { i64, ptr } }, ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  br label %bb33
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l37, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 2
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  br i1 %t29, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l42, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/session:Analysis", ptr %t35, i32 0, i32 3
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/session:Analysis", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t49 = load ptr, ptr %l42, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %s1, ptr %t48, ptr %t49, ptr %t45, i64 %t46, { i64, ptr } %t47)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l51
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb14, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l50
  br label %bb13
bb13:
  %t58 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t58, ptr %l34, !tbaa !27
  br label %bb16
bb14:
  %t59 = load i32, ptr %l51, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l53, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s1)
  %t64 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t64, ptr %rv
  br label %ret
bb16:
  %t65 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9)
  unreachable
bb18:
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t76 = call i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %t70, i64 %t71, { i64, ptr } %t72)
  store i64 %t76, ptr %l60
  br label %bb20
bb20:
  %t77 = load i64, ptr %l60, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t78, ptr %l61, !tbaa !27
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp sge i64 %t79, 0
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l67
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l64, !tbaa !27
  br label %bb25
bb23:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t91 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %s1, { i64, ptr } %t89, i64 %t88, i1 true)
  store { i64, ptr } %t91, ptr %l69
  br label %bb24
bb24:
  %t92 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t94 = extractvalue { i64, ptr } %t92, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l64, !tbaa !27
  br label %bb25
bb25:
  %t100 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t100, { i64, ptr } %t101)
  store { i64, ptr } %t102, ptr %l71
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = icmp eq ptr %t103, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_913972385efaf6d8_94fc87626a418744)
  unreachable
bb28:
  br label %bb29
bb29:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t108 = load i64, ptr %l3, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t113 = call { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %v1, ptr %s1, ptr %t107, i64 %t108, { i64, ptr } %t109)
  store { i64, ptr } %t113, ptr %l77
  br label %bb30
bb30:
  %t114 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  call void @olang_textcopy(ptr %t121, ptr %t115, i64 %t116)
  %t122 = getelementptr i8, ptr %t121, i64 %t116
  call void @olang_textcopy(ptr %t122, ptr %t118, i64 %t119)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  %t125 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t125, ptr %lp7
  %t127 = load ptr, ptr %lp7
  store { i64, ptr } %t124, ptr %t127, !tbaa !27
  %t128 = load ptr, ptr %lp7
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l79, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/session:Analysis", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 10
  %t136 = load i64, ptr %l3, !tbaa !24
  %t139 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t135, i64 %t136)
  store ptr %t139, ptr %l84
  br label %bb31
bb31:
  %t140 = load ptr, ptr %l84, !tbaa !29
  %t142 = getelementptr %"compiler/load:Module", ptr %t140, i32 0, i32 1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t145, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t161 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t158, { i64, ptr } %t156, i64 %t157)
  store %"compiler/session:Found" %t161, ptr %l90
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s1)
  %t162 = load %"compiler/session:Found", ptr %l90
  %t163 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t162, 1
  store { i32, %"compiler/session:Found" } %t163, ptr %rv
  br label %ret
bb33:
  %t164 = load { i64, [6 x i64] }, ptr %l1
  %t166 = extractvalue { i64, [6 x i64] } %t164, 0
  %t167 = icmp eq i64 %t166, 2
  br i1 %t167, label %bb34, label %bb35
bb34:
  %t169 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t170 = getelementptr { i64 }, ptr %t169, i32 0, i32 0
  %t171 = load i64, ptr %t170
  store i64 %t171, ptr %l8, !tbaa !24
  br label %bb36
bb35:
  br label %bb73
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t175 = icmp eq ptr %t173, null
  br i1 %t175, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_50b486dff56c46f7_6641abdfc6e3fb13)
  unreachable
bb38:
  br label %bb39
bb39:
  %t177 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t182 = load i64, ptr %l8, !tbaa !24
  %t185 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t181, i64 %t182)
  store i64 %t185, ptr %l100
  br label %bb40
bb40:
  %t186 = load i64, ptr %l100, !tbaa !24
  store i64 %t186, ptr %l9, !tbaa !24
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee)
  unreachable
bb42:
  br label %bb43
bb43:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = load i64, ptr %l8, !tbaa !24
  %t199 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s5, ptr %t195, i64 %t196)
  store ptr %t199, ptr %l107
  br label %bb44
bb44:
  %t200 = load ptr, ptr %l107, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 0
  %t203 = getelementptr %"compiler/source:Span", ptr %t202, i32 0, i32 0
  %t204 = load i32, ptr %t203, !tbaa !23
  %t206 = sext i32 %t204 to i64
  store i64 %t206, ptr %l10, !tbaa !24
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = icmp eq ptr %t208, null
  br i1 %t210, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb46:
  br label %bb47
bb47:
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %l113, !tbaa !29
  %t213 = load i64, ptr %l9, !tbaa !24
  store i64 %t213, ptr %l114, !tbaa !24
  %t214 = load ptr, ptr %l2, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb49:
  br label %bb50
bb50:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t219 = load i64, ptr %l8, !tbaa !24
  %t222 = call { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %s5, ptr %t218, i64 %t219)
  store { i64, ptr } %t222, ptr %l119
  br label %bb51
bb51:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb53:
  br label %bb54
bb54:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 0
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/load:Loader", ptr %t234, i32 0, i32 3
  %t237 = load ptr, ptr %t236, !tbaa !29
  store ptr %t237, ptr %l126, !tbaa !29
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = icmp eq ptr %t238, null
  br i1 %t240, label %bb55, label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb56:
  br label %bb57
bb57:
  %t242 = load ptr, ptr %l2, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t247 = load i64, ptr %l8, !tbaa !24
  %t250 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s5, ptr %t246, i64 %t247)
  store ptr %t250, ptr %l133
  br label %bb58
bb58:
  %t251 = load ptr, ptr %l133, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Func", ptr %t251, i32 0, i32 2
  %t254 = load i32, ptr %t253, !tbaa !23
  %t255 = load ptr, ptr %l126, !tbaa !29
  %t257 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s5, ptr %t255, i32 %t254)
  store { i64, ptr } %t257, ptr %l136
  br label %bb59
bb59:
  %t258 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t267)
  call void @olang_textcopy(ptr %t268, ptr %t259, i64 %t260)
  %t269 = getelementptr i8, ptr %t268, i64 %t260
  call void @olang_textcopy(ptr %t269, ptr %t261, i64 %t262)
  %t270 = getelementptr i8, ptr %t269, i64 %t262
  call void @olang_textcopy(ptr %t270, ptr %t265, i64 %t266)
  %t271 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t268, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = extractvalue { i64, ptr } %t272, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  %t280 = load ptr, ptr %l113, !tbaa !29
  %t281 = load i64, ptr %l114, !tbaa !24
  %t283 = call { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %s5, ptr %s5, ptr %t280, i64 %t281, { i64, ptr } %t279)
  store { i64, ptr } %t283, ptr %l139
  br label %bb60
bb60:
  %t284 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t284, ptr %l11, !tbaa !27
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb61, label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb62:
  br label %bb63
bb63:
  %t289 = load ptr, ptr %l2, !tbaa !29
  store ptr %t289, ptr %l142, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/session:Analysis", ptr %t290, i32 0, i32 2
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = icmp eq ptr %t293, null
  br i1 %t295, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb65:
  br label %bb66
bb66:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/session:Analysis", ptr %t297, i32 0, i32 2
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load i64, ptr %l8, !tbaa !24
  %t302 = load ptr, ptr %l142, !tbaa !29
  %t305 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s5, ptr %t302, ptr %t300, i64 %t301)
  store { i64, ptr } %t305, ptr %l149
  br label %bb67
bb67:
  %t306 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  %t308 = extractvalue { i64, ptr } %t306, 1
  %t309 = mul i64 %t307, 1
  %t310 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t309)
  call void @llvm.memcpy.p0.p0.i64(ptr %t310, ptr %t308, i64 %t309, i1 false)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l150, !tbaa !27
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i64, ptr %l9, !tbaa !24
  %t317 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t313, i64 %t314)
  store { i64, ptr } %t317, ptr %l153
  br label %bb68
bb68:
  %t318 = load i64, ptr %l10, !tbaa !24
  %t319 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t321 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %s5, { i64, ptr } %t319, i64 %t318)
  store { i64, ptr } %t321, ptr %l155
  br label %bb69
bb69:
  %t322 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 0
  %t324 = extractvalue { i64, ptr } %t322, 1
  %t325 = mul i64 %t323, 1
  %t326 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t325)
  call void @llvm.memcpy.p0.p0.i64(ptr %t326, ptr %t324, i64 %t325, i1 false)
  %t327 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  %t329 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t331 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t329, { i64, ptr } %t328)
  store { i64, ptr } %t331, ptr %l157
  br label %bb70
bb70:
  %t332 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 1
  %t335 = extractvalue { i64, ptr } %t333, 0
  %t337 = extractvalue { i64, ptr } %t332, 1
  %t338 = extractvalue { i64, ptr } %t332, 0
  %t339 = add i64 %t335, %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t339)
  call void @olang_textcopy(ptr %t340, ptr %t334, i64 %t335)
  %t341 = getelementptr i8, ptr %t340, i64 %t335
  call void @olang_textcopy(ptr %t341, ptr %t337, i64 %t338)
  %t342 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t343 = insertvalue { i64, ptr } %t342, ptr %t340, 1
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t346 = extractvalue { i64, ptr } %t343, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  store { i64, ptr } %t350, ptr %l160, !tbaa !27
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/session:Analysis", ptr %t351, i32 0, i32 0
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = getelementptr %"compiler/load:Loader", ptr %t354, i32 0, i32 10
  %t357 = load i64, ptr %l9, !tbaa !24
  %t360 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t356, i64 %t357)
  store ptr %t360, ptr %l165
  br label %bb71
bb71:
  %t361 = load ptr, ptr %l165, !tbaa !29
  %t363 = getelementptr %"compiler/load:Module", ptr %t361, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = extractvalue { i64, ptr } %t364, 0
  %t368 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t367)
  call void @olang_textcopy(ptr %t368, ptr %t366, i64 %t367)
  %t369 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = extractvalue { i64, ptr } %t370, 1
  %t374 = mul i64 %t372, 1
  %t375 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t374)
  call void @llvm.memcpy.p0.p0.i64(ptr %t375, ptr %t373, i64 %t374, i1 false)
  %t376 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  %t378 = load i64, ptr %l10, !tbaa !24
  %t379 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t382 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t379, { i64, ptr } %t377, i64 %t378)
  store %"compiler/session:Found" %t382, ptr %l171
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s5)
  %t383 = load %"compiler/session:Found", ptr %l171
  %t384 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t383, 1
  store { i32, %"compiler/session:Found" } %t384, ptr %rv
  br label %ret
bb73:
  %t385 = load { i64, [6 x i64] }, ptr %l1
  %t387 = extractvalue { i64, [6 x i64] } %t385, 0
  %t388 = icmp eq i64 %t387, 3
  br i1 %t388, label %bb74, label %bb75
bb74:
  %t390 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t391 = getelementptr { i32, i64 }, ptr %t390, i32 0, i32 0
  %t392 = load i32, ptr %t391
  store i32 %t392, ptr %l12, !tbaa !23
  %t394 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t395 = getelementptr { i32, i64 }, ptr %t394, i32 0, i32 1
  %t396 = load i64, ptr %t395
  store i64 %t396, ptr %l13, !tbaa !24
  br label %bb76
bb75:
  br label %bb86
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load i32, ptr %l12, !tbaa !23
  %t400 = load i64, ptr %l13, !tbaa !24
  %t404 = call { i32, %"compiler/session:memberInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v2, ptr %t398, i32 %t399, i64 %t400)
  %t405 = extractvalue { i32, %"compiler/session:memberInfo" } %t404, 1
  %t406 = extractvalue { i32, %"compiler/session:memberInfo" } %t404, 0
  store i32 %t406, ptr %l181
  %t407 = icmp ne i32 %t406, 0
  br i1 %t407, label %bb78, label %ok.408, !prof !99
ok.408:
  store %"compiler/session:memberInfo" %t405, ptr %l180
  br label %bb77
bb77:
  %t409 = load %"compiler/session:memberInfo", ptr %l180
  store %"compiler/session:memberInfo" %t409, ptr %l176
  br label %bb79
bb78:
  %t410 = load i32, ptr %l181, !tbaa !23
  %t411 = lshr i32 %t410, 16
  %t412 = and i32 %t410, 65535
  %t413 = icmp eq i32 %t411, 1
  %t414 = select i1 %t413, i32 1, i32 0
  %t415 = icmp eq i32 %t410, 0
  %t416 = shl i32 %t414, 16
  %t417 = or i32 %t416, %t412
  %t418 = select i1 %t415, i32 0, i32 %t417
  call void @__olang_scope_close(ptr %s9)
  %t420 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t418, 0
  store { i32, %"compiler/session:Found" } %t420, ptr %rv
  br label %ret
bb79:
  %t421 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store ptr %t421, ptr %lp14
  %t422 = load %"compiler/session:memberInfo", ptr %l176
  %t423 = load ptr, ptr %lp14
  store %"compiler/session:memberInfo" %t422, ptr %t423
  %t424 = load ptr, ptr %lp14
  %t425 = getelementptr %"compiler/session:memberInfo", ptr %t424, i32 0, i32 0
  %t426 = load { i64, ptr }, ptr %t425, !tbaa !27
  store { i64, ptr } %t426, ptr %l183, !tbaa !27
  %t427 = load ptr, ptr %l2, !tbaa !29
  %t429 = icmp eq ptr %t427, null
  br i1 %t429, label %bb80, label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_9453126c7f8f920b_6892400c5eb9861f)
  unreachable
bb81:
  br label %bb82
bb82:
  %t431 = load ptr, ptr %l2, !tbaa !29
  %t432 = load ptr, ptr %lp14
  %t433 = getelementptr %"compiler/session:memberInfo", ptr %t432, i32 0, i32 1
  %t434 = load i32, ptr %t433, !tbaa !23
  %t437 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s9, ptr %t431, i32 %t434)
  store { i64, ptr } %t437, ptr %l188
  br label %bb83
bb83:
  %t438 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t438, 1
  %t440 = extractvalue { i64, ptr } %t438, 0
  %t441 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t443 = add i64 %t440, %t442
  %t444 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = extractvalue { i64, ptr } %t444, 0
  %t447 = add i64 %t443, %t446
  %t448 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t447)
  call void @olang_textcopy(ptr %t448, ptr %t439, i64 %t440)
  %t449 = getelementptr i8, ptr %t448, i64 %t440
  call void @olang_textcopy(ptr %t449, ptr %t441, i64 %t442)
  %t450 = getelementptr i8, ptr %t449, i64 %t442
  call void @olang_textcopy(ptr %t450, ptr %t445, i64 %t446)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t448, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = extractvalue { i64, ptr } %t452, 1
  %t456 = mul i64 %t454, 1
  %t457 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t457, ptr %t455, i64 %t456, i1 false)
  %t458 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  %t460 = load ptr, ptr %lp14
  %t461 = getelementptr %"compiler/session:memberInfo", ptr %t460, i32 0, i32 2
  %t462 = load { i64, ptr }, ptr %t461, !tbaa !27
  %t465 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t459, { i64, ptr } %t462)
  store { i64, ptr } %t465, ptr %l192
  br label %bb84
bb84:
  %t466 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  %t468 = extractvalue { i64, ptr } %t466, 1
  %t469 = mul i64 %t467, 1
  %t470 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t469)
  call void @llvm.memcpy.p0.p0.i64(ptr %t470, ptr %t468, i64 %t469, i1 false)
  %t471 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr %t470, 1
  %t473 = load ptr, ptr %lp14
  %t474 = getelementptr %"compiler/session:memberInfo", ptr %t473, i32 0, i32 3
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  %t476 = load ptr, ptr %lp14
  %t477 = getelementptr %"compiler/session:memberInfo", ptr %t476, i32 0, i32 4
  %t478 = load i64, ptr %t477, !tbaa !24
  %t482 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t472, { i64, ptr } %t475, i64 %t478)
  store %"compiler/session:Found" %t482, ptr %l196
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s9)
  %t483 = load %"compiler/session:Found", ptr %l196
  %t484 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t483, 1
  store { i32, %"compiler/session:Found" } %t484, ptr %rv
  br label %ret
bb86:
  %t485 = load { i64, [6 x i64] }, ptr %l1
  %t487 = extractvalue { i64, [6 x i64] } %t485, 0
  %t488 = icmp eq i64 %t487, 4
  br i1 %t488, label %bb87, label %bb88
bb87:
  %t490 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t491 = getelementptr { i64, i32 }, ptr %t490, i32 0, i32 0
  %t492 = load i64, ptr %t491
  store i64 %t492, ptr %l15, !tbaa !24
  %t494 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t495 = getelementptr { i64, i32 }, ptr %t494, i32 0, i32 1
  %t496 = load i32, ptr %t495
  store i32 %t496, ptr %l16, !tbaa !23
  br label %bb89
bb88:
  br label %bb113
bb89:
  store %olang.scope zeroinitializer, ptr %s11
  %t498 = load ptr, ptr %l2, !tbaa !29
  %t500 = icmp eq ptr %t498, null
  br i1 %t500, label %bb90, label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a)
  unreachable
bb91:
  br label %bb92
bb92:
  %t502 = load ptr, ptr %l2, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t502, i32 0, i32 14
  %t506 = load i64, ptr %l15, !tbaa !24
  %t509 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t505, i64 %t506)
  store ptr %t509, ptr %l207
  br label %bb93
bb93:
  %t510 = load ptr, ptr %l207, !tbaa !29
  store ptr %t510, ptr %l17, !tbaa !29
  %t511 = load ptr, ptr %l17, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Body", ptr %t511, i32 0, i32 7
  %t514 = load i32, ptr %l16, !tbaa !23
  %t516 = sext i32 %t514 to i64
  %t519 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t513, i64 %t516)
  store %"compiler/typed:Local" %t519, ptr %l212
  br label %bb94
bb94:
  %t520 = load %"compiler/typed:Local", ptr %l212
  store %"compiler/typed:Local" %t520, ptr %l18
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l17, !tbaa !29
  %t524 = getelementptr %"compiler/typed:Body", ptr %t522, i32 0, i32 3
  %t525 = load i64, ptr %t524, !tbaa !24
  %t528 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t521, i64 %t525)
  store i64 %t528, ptr %l216
  br label %bb95
bb95:
  %t529 = load i64, ptr %l216, !tbaa !24
  store i64 %t529, ptr %l19, !tbaa !24
  %t530 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 4
  %t531 = load i32, ptr %t530, !range !{i32 0, i32 7}
  %t533 = trunc i64 0 to i32
  %t534 = icmp eq i32 %t531, %t533
  br i1 %t534, label %bb96, label %bb97
bb96:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l219, !tbaa !27
  br label %bb98
bb97:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %l219, !tbaa !27
  br label %bb98
bb98:
  %t536 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t536, ptr %l220, !tbaa !27
  %t538 = load ptr, ptr %l2, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  br i1 %t540, label %bb99, label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_8be95a0084a275_27fb33976f90d831)
  unreachable
bb100:
  br label %bb101
bb101:
  %t542 = load ptr, ptr %l2, !tbaa !29
  %t545 = getelementptr %"compiler/check:Checker", ptr %t542, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = getelementptr %"compiler/generic:Program", ptr %t546, i32 0, i32 0
  %t549 = load ptr, ptr %t548, !tbaa !29
  %t551 = getelementptr %"compiler/load:Loader", ptr %t549, i32 0, i32 3
  %t552 = load ptr, ptr %t551, !tbaa !29
  %t553 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t554 = load i32, ptr %t553, !tbaa !23
  %t557 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s11, ptr %t552, i32 %t554)
  store { i64, ptr } %t557, ptr %l229
  br label %bb102
bb102:
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t560 = icmp eq ptr %t558, null
  br i1 %t560, label %bb103, label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_8be95a0084a275_27fb33976f90d831)
  unreachable
bb104:
  br label %bb105
bb105:
  %t562 = load ptr, ptr %l2, !tbaa !29
  %t563 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t564 = load i32, ptr %t563, !tbaa !23
  %t567 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s11, ptr %t562, i32 %t564)
  store { i64, ptr } %t567, ptr %l234
  br label %bb106
bb106:
  %t568 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 1
  %t570 = extractvalue { i64, ptr } %t568, 0
  %t571 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 1
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = add i64 %t570, %t573
  %t575 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t576 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t577 = add i64 %t574, %t576
  %t578 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 1
  %t580 = extractvalue { i64, ptr } %t578, 0
  %t581 = add i64 %t577, %t580
  %t582 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t581)
  call void @olang_textcopy(ptr %t582, ptr %t569, i64 %t570)
  %t583 = getelementptr i8, ptr %t582, i64 %t570
  call void @olang_textcopy(ptr %t583, ptr %t572, i64 %t573)
  %t584 = getelementptr i8, ptr %t583, i64 %t573
  call void @olang_textcopy(ptr %t584, ptr %t575, i64 %t576)
  %t585 = getelementptr i8, ptr %t584, i64 %t576
  call void @olang_textcopy(ptr %t585, ptr %t579, i64 %t580)
  %t586 = insertvalue { i64, ptr } undef, i64 %t581, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t582, 1
  %t589 = extractvalue { i64, ptr } %t587, 0
  %t590 = extractvalue { i64, ptr } %t587, 1
  %t591 = mul i64 %t589, 1
  %t592 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t591)
  call void @llvm.memcpy.p0.p0.i64(ptr %t592, ptr %t590, i64 %t591, i1 false)
  %t593 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  %t596 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t594, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store { i64, ptr } %t596, ptr %l237
  br label %bb107
bb107:
  %t597 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t597, ptr %lp21
  %t598 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t599 = load ptr, ptr %lp21
  store { i64, ptr } %t598, ptr %t599, !tbaa !27
  %t600 = load ptr, ptr %lp21
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  store { i64, ptr } %t601, ptr %l238, !tbaa !27
  %t602 = load i64, ptr %l19, !tbaa !24
  %t604 = icmp sge i64 %t602, 0
  br i1 %t604, label %bb108, label %bb109
bb108:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/session:Analysis", ptr %t606, i32 0, i32 0
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = getelementptr %"compiler/load:Loader", ptr %t609, i32 0, i32 10
  %t612 = load i64, ptr %l19, !tbaa !24
  %t615 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t611, i64 %t612)
  store ptr %t615, ptr %l246
  br label %bb110
bb109:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l241, !tbaa !27
  br label %bb111
bb110:
  %t616 = load ptr, ptr %l246, !tbaa !29
  %t618 = getelementptr %"compiler/load:Module", ptr %t616, i32 0, i32 1
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t619, 1
  %t622 = extractvalue { i64, ptr } %t619, 0
  %t623 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t622)
  call void @olang_textcopy(ptr %t623, ptr %t621, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  %t627 = extractvalue { i64, ptr } %t625, 0
  %t628 = extractvalue { i64, ptr } %t625, 1
  %t629 = mul i64 %t627, 1
  %t630 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t629)
  call void @llvm.memcpy.p0.p0.i64(ptr %t630, ptr %t628, i64 %t629, i1 false)
  %t631 = insertvalue { i64, ptr } undef, i64 %t627, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t630, 1
  store { i64, ptr } %t632, ptr %l241, !tbaa !27
  br label %bb111
bb111:
  %t634 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t635 = getelementptr %"compiler/source:Span", ptr %t634, i32 0, i32 0
  %t636 = load i32, ptr %t635, !tbaa !23
  %t638 = sext i32 %t636 to i64
  %t639 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t640 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t642 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t639, { i64, ptr } %t640, i64 %t638)
  store %"compiler/session:Found" %t642, ptr %l253
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s11)
  %t643 = load %"compiler/session:Found", ptr %l253
  %t644 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t643, 1
  store { i32, %"compiler/session:Found" } %t644, ptr %rv
  br label %ret
bb113:
  %t645 = load { i64, [6 x i64] }, ptr %l1
  %t647 = extractvalue { i64, [6 x i64] } %t645, 0
  %t648 = icmp eq i64 %t647, 5
  br i1 %t648, label %bb114, label %bb115
bb114:
  %t650 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t651 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t650, i32 0, i32 0
  %t652 = load i64, ptr %t651
  store i64 %t652, ptr %l22, !tbaa !24
  %t654 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t655 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t654, i32 0, i32 1
  %t656 = load i64, ptr %t655
  store i64 %t656, ptr %l23, !tbaa !24
  %t658 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t659 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t658, i32 0, i32 2
  %t660 = load { i64, ptr }, ptr %t659
  store { i64, ptr } %t660, ptr %l24, !tbaa !27
  %t662 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t663 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t662, i32 0, i32 3
  %t664 = load { i64, ptr }, ptr %t663
  store { i64, ptr } %t664, ptr %l25, !tbaa !27
  br label %bb116
bb115:
  br label %bb120
bb116:
  %t666 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t667 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t670 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v1, ptr %v1, ptr %v2, { i64, ptr } %t666, { i64, ptr } %t667)
  store { i64, ptr } %t670, ptr %l262
  br label %bb117
bb117:
  %t671 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 0
  %t673 = extractvalue { i64, ptr } %t671, 1
  %t674 = mul i64 %t672, 1
  %t675 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t674)
  call void @llvm.memcpy.p0.p0.i64(ptr %t675, ptr %t673, i64 %t674, i1 false)
  %t676 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t677 = insertvalue { i64, ptr } %t676, ptr %t675, 1
  store { i64, ptr } %t677, ptr %l263, !tbaa !27
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/session:Analysis", ptr %t678, i32 0, i32 0
  %t681 = load ptr, ptr %t680, !tbaa !29
  %t683 = getelementptr %"compiler/load:Loader", ptr %t681, i32 0, i32 10
  %t684 = load i64, ptr %l22, !tbaa !24
  %t687 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t683, i64 %t684)
  store ptr %t687, ptr %l268
  br label %bb118
bb118:
  %t688 = load ptr, ptr %l268, !tbaa !29
  %t690 = getelementptr %"compiler/load:Module", ptr %t688, i32 0, i32 1
  %t691 = load { i64, ptr }, ptr %t690, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t691, 1
  %t694 = extractvalue { i64, ptr } %t691, 0
  %t695 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t694)
  call void @olang_textcopy(ptr %t695, ptr %t693, i64 %t694)
  %t696 = insertvalue { i64, ptr } undef, i64 %t694, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t695, 1
  %t699 = extractvalue { i64, ptr } %t697, 0
  %t700 = extractvalue { i64, ptr } %t697, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t705 = load i64, ptr %l23, !tbaa !24
  %t706 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t709 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t706, { i64, ptr } %t704, i64 %t705)
  store %"compiler/session:Found" %t709, ptr %l274
  br label %bb119
bb119:
  %t710 = load %"compiler/session:Found", ptr %l274
  %t711 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t710, 1
  store { i32, %"compiler/session:Found" } %t711, ptr %rv
  br label %ret
bb120:
  %t712 = load { i64, [6 x i64] }, ptr %l1
  %t714 = extractvalue { i64, [6 x i64] } %t712, 0
  %t715 = icmp eq i64 %t714, 6
  br i1 %t715, label %bb121, label %bb122
bb121:
  %t717 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t718 = getelementptr { i64 }, ptr %t717, i32 0, i32 0
  %t719 = load i64, ptr %t718
  store i64 %t719, ptr %l26, !tbaa !24
  br label %bb123
bb122:
  br label %bb131
bb123:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = getelementptr %"compiler/session:Analysis", ptr %t721, i32 0, i32 0
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = getelementptr %"compiler/load:Loader", ptr %t724, i32 0, i32 10
  %t727 = load i64, ptr %l26, !tbaa !24
  %t730 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t726, i64 %t727)
  store ptr %t730, ptr %l282
  br label %bb124
bb124:
  %t731 = load ptr, ptr %l282, !tbaa !29
  store ptr %t731, ptr %l27, !tbaa !29
  %t732 = load ptr, ptr %l27, !tbaa !29
  %t734 = getelementptr %"compiler/load:Module", ptr %t732, i32 0, i32 2
  %t735 = load { i64, ptr }, ptr %t734, !tbaa !27
  %t736 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t737 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t739 = extractvalue { i64, ptr } %t735, 1
  %t740 = extractvalue { i64, ptr } %t735, 0
  %t741 = add i64 %t737, %t740
  %t742 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t743 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t744 = add i64 %t741, %t743
  %t745 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t744)
  call void @olang_textcopy(ptr %t745, ptr %t736, i64 %t737)
  %t746 = getelementptr i8, ptr %t745, i64 %t737
  call void @olang_textcopy(ptr %t746, ptr %t739, i64 %t740)
  %t747 = getelementptr i8, ptr %t746, i64 %t740
  call void @olang_textcopy(ptr %t747, ptr %t742, i64 %t743)
  %t748 = insertvalue { i64, ptr } undef, i64 %t744, 0
  %t749 = insertvalue { i64, ptr } %t748, ptr %t745, 1
  %t751 = extractvalue { i64, ptr } %t749, 0
  %t752 = extractvalue { i64, ptr } %t749, 1
  %t753 = mul i64 %t751, 1
  %t754 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t753)
  call void @llvm.memcpy.p0.p0.i64(ptr %t754, ptr %t752, i64 %t753, i1 false)
  %t755 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t756 = insertvalue { i64, ptr } %t755, ptr %t754, 1
  store { i64, ptr } %t756, ptr %l286, !tbaa !27
  %t757 = load ptr, ptr %l27, !tbaa !29
  %t759 = getelementptr %"compiler/load:Module", ptr %t757, i32 0, i32 6
  %t760 = load ptr, ptr %t759, !tbaa !29
  %t762 = icmp eq ptr %t760, null
  br i1 %t762, label %bb125, label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_62de0451ac433905_e234825e46030f99)
  unreachable
bb126:
  br label %bb127
bb127:
  %t764 = load ptr, ptr %l27, !tbaa !29
  %t766 = getelementptr %"compiler/load:Module", ptr %t764, i32 0, i32 6
  %t767 = load ptr, ptr %t766, !tbaa !29
  %t770 = getelementptr %"compiler/source:Source", ptr %t767, i32 0, i32 1
  %t771 = load { i64, ptr }, ptr %t770, !tbaa !27
  %t773 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v2, { i64, ptr } %t771)
  store { i64, ptr } %t773, ptr %l294
  br label %bb128
bb128:
  %t774 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t775 = extractvalue { i64, ptr } %t774, 0
  %t776 = extractvalue { i64, ptr } %t774, 1
  %t777 = mul i64 %t775, 1
  %t778 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t777)
  call void @llvm.memcpy.p0.p0.i64(ptr %t778, ptr %t776, i64 %t777, i1 false)
  %t779 = insertvalue { i64, ptr } undef, i64 %t775, 0
  %t780 = insertvalue { i64, ptr } %t779, ptr %t778, 1
  %t781 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t783 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t781, { i64, ptr } %t780)
  store { i64, ptr } %t783, ptr %l296
  br label %bb129
bb129:
  %t784 = load { i64, ptr }, ptr %l296, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t784, 0
  %t786 = extractvalue { i64, ptr } %t784, 1
  %t787 = mul i64 %t785, 1
  %t788 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t787)
  call void @llvm.memcpy.p0.p0.i64(ptr %t788, ptr %t786, i64 %t787, i1 false)
  %t789 = insertvalue { i64, ptr } undef, i64 %t785, 0
  %t790 = insertvalue { i64, ptr } %t789, ptr %t788, 1
  %t791 = load ptr, ptr %l27, !tbaa !29
  %t793 = getelementptr %"compiler/load:Module", ptr %t791, i32 0, i32 1
  %t794 = load { i64, ptr }, ptr %t793, !tbaa !27
  %t796 = extractvalue { i64, ptr } %t794, 1
  %t797 = extractvalue { i64, ptr } %t794, 0
  %t798 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t797)
  call void @olang_textcopy(ptr %t798, ptr %t796, i64 %t797)
  %t799 = insertvalue { i64, ptr } undef, i64 %t797, 0
  %t800 = insertvalue { i64, ptr } %t799, ptr %t798, 1
  %t802 = extractvalue { i64, ptr } %t800, 0
  %t803 = extractvalue { i64, ptr } %t800, 1
  %t804 = mul i64 %t802, 1
  %t805 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t804)
  call void @llvm.memcpy.p0.p0.i64(ptr %t805, ptr %t803, i64 %t804, i1 false)
  %t806 = insertvalue { i64, ptr } undef, i64 %t802, 0
  %t807 = insertvalue { i64, ptr } %t806, ptr %t805, 1
  %t810 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t790, { i64, ptr } %t807, i64 0)
  store %"compiler/session:Found" %t810, ptr %l302
  br label %bb130
bb130:
  %t811 = load %"compiler/session:Found", ptr %l302
  %t812 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t811, 1
  store { i32, %"compiler/session:Found" } %t812, ptr %rv
  br label %ret
bb131:
  %t813 = load { i64, [6 x i64] }, ptr %l1
  %t815 = extractvalue { i64, [6 x i64] } %t813, 0
  %t816 = icmp eq i64 %t815, 0
  br i1 %t816, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb135
bb134:
  %t819 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t819, ptr %rv
  br label %ret
bb135:
  call void @__olang_check_failed(ptr @olang_loc_15e46cfea19645ed_f1e4cdf7ffa66ee1)
  unreachable
ret:
  %rr = load { i32, %"compiler/session:Found" }, ptr %rv
  ret { i32, %"compiler/session:Found" } %rr
}

define dso_local { i32, %"compiler/session:memberInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l26 = alloca i32
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca ptr
  %l84 = alloca i32
  %l88 = alloca i1
  %l96 = alloca i32
  %l99 = alloca i1
  %l100 = alloca i64
  %l103 = alloca i64
  %l106 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca %"compiler/typed:Local"
  %l116 = alloca i64
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l145 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca { i64, ptr }
  %l166 = alloca i32
  %l167 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i32
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l189 = alloca %"compiler/session:memberInfo"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:memberInfo" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l26
  br label %bb4
bb4:
  %t21 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l29, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l37
  br label %bb10
bb10:
  %t43 = load i32, ptr %l37, !tbaa !23
  store i32 %t43, ptr %l29, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e81878307a0930f8_ac6e376276a113b4)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l46
  br label %bb15
bb15:
  %t60 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t68 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t68, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cf719ce72396210d_6e539aa1951515a9)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l58
  br label %bb22
bb22:
  %t84 = load i32, ptr %l58, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_90bed28a447e5726_404cd49f4fb329c2)
  unreachable
bb24:
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 14
  store ptr %t92, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l64, !tbaa !24
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l66
  br label %bb27
bb27:
  %t98 = load i64, ptr %l64, !tbaa !24
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb28, label %bb29
bb28:
  br label %bb94
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t104, i64 %t105)
  store ptr %t108, ptr %l71
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l71, !tbaa !29
  store ptr %t109, ptr %l8, !tbaa !29
  %t110 = load ptr, ptr %l8, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 1
  %t113 = load { i64, [2 x i64] }, ptr %t112
  store { i64, [2 x i64] } %t113, ptr %l9
  %t115 = load { i64, [2 x i64] }, ptr %l9
  %t117 = extractvalue { i64, [2 x i64] } %t115, 0
  %t118 = icmp eq i64 %t117, 1
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t121 = getelementptr { i32, i32 }, ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb87
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb36:
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l10, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l84
  br label %bb38
bb38:
  %t139 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t141 = trunc i64 18 to i32
  %t142 = icmp eq i32 %t139, %t141
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb45
bb40:
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb42:
  br label %bb43
bb43:
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l10, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l96
  br label %bb44
bb44:
  %t161 = load i32, ptr %l5, !tbaa !23
  %t162 = load i32, ptr %l96, !tbaa !23
  %t164 = icmp ne i32 %t162, %t161
  store i1 %t164, ptr %l88, !tbaa !21
  br label %bb45
bb45:
  %t166 = load i1, ptr %l88, !tbaa !21
  br i1 %t166, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb49
bb47:
  %t167 = load i64, ptr %l2, !tbaa !24
  store i64 %t167, ptr %l100, !tbaa !24
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 10
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l103
  br label %bb48
bb48:
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = load i64, ptr %l103, !tbaa !24
  %t175 = icmp sge i64 %t173, %t174
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb49
bb49:
  %t177 = load i1, ptr %l99, !tbaa !21
  br i1 %t177, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %bb93
bb51:
  br label %bb52
bb52:
  %t178 = load ptr, ptr %l8, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 7
  store ptr %t180, ptr %l106, !tbaa !29
  %t181 = load ptr, ptr %l8, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Body", ptr %t181, i32 0, i32 10
  %t184 = load i64, ptr %l2, !tbaa !24
  %t187 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t183, i64 %t184)
  store i32 %t187, ptr %l110
  br label %bb53
bb53:
  %t188 = load i32, ptr %l110, !tbaa !23
  %t189 = sext i32 %t188 to i64
  %t190 = load ptr, ptr %l106, !tbaa !29
  %t192 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t190, i64 %t189)
  store %"compiler/typed:Local" %t192, ptr %l112
  br label %bb54
bb54:
  %t193 = load %"compiler/typed:Local", ptr %l112
  store %"compiler/typed:Local" %t193, ptr %l11
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l8, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Body", ptr %t195, i32 0, i32 3
  %t198 = load i64, ptr %t197, !tbaa !24
  %t201 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t194, i64 %t198)
  store i64 %t201, ptr %l116
  br label %bb55
bb55:
  %t202 = load i64, ptr %l116, !tbaa !24
  store i64 %t202, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t205 = icmp slt i64 %t203, 0
  br i1 %t205, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s4)
  %t208 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t208, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l12, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l122
  br label %bb59
bb59:
  %t214 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t214, ptr %l13, !tbaa !27
  %t215 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = icmp eq i32 %t216, 0
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t220, ptr %l126, !tbaa !27
  %t221 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t222 = getelementptr %"compiler/source:Span", ptr %t221, i32 0, i32 0
  %t223 = load i32, ptr %t222, !tbaa !23
  %t225 = sext i32 %t223 to i64
  store i64 %t225, ptr %l128, !tbaa !24
  %t226 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = sext i32 %t228 to i64
  store i64 %t230, ptr %l130, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l131, !tbaa !24
  %t233 = load i64, ptr %l128, !tbaa !24
  %t234 = icmp sge i64 %t233, 0
  br i1 %t234, label %bb62, label %bb63
bb61:
  %t236 = load ptr, ptr %l3, !tbaa !29
  %t238 = icmp eq ptr %t236, null
  br i1 %t238, label %bb68, label %bb69
bb62:
  %t240 = load i64, ptr %l128, !tbaa !24
  %t241 = load i64, ptr %l130, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  br i1 %t242, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb64:
  %t244 = load i64, ptr %l130, !tbaa !24
  %t245 = load i64, ptr %l131, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb66:
  %t248 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l128, !tbaa !24
  %t251 = load i64, ptr %l130, !tbaa !24
  %t252 = getelementptr i8, ptr %t249, i64 %t250
  %t253 = sub i64 %t251, %t250
  %t254 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = extractvalue { i64, ptr } %t255, 0
  %t259 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t257, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l125, !tbaa !27
  br label %bb72
bb67:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4c52bbc768601131_90801d9bf2a41585)
  unreachable
bb69:
  br label %bb70
bb70:
  %t263 = load ptr, ptr %l3, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/load:Loader", ptr %t270, i32 0, i32 3
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t273, i32 %t275)
  store { i64, ptr } %t278, ptr %l145
  br label %bb71
bb71:
  %t279 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t280, i64 %t281)
  %t283 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  store { i64, ptr } %t284, ptr %l125, !tbaa !27
  br label %bb72
bb72:
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t286, ptr %lp14
  %t287 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t288 = load ptr, ptr %lp14
  store { i64, ptr } %t287, ptr %t288, !tbaa !27
  %t289 = load ptr, ptr %l3, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb73, label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb74:
  br label %bb75
bb75:
  %t293 = load ptr, ptr %l3, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  store ptr %t299, ptr %l152, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  br i1 %t302, label %bb76, label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb77:
  br label %bb78
bb78:
  %t304 = load ptr, ptr %l3, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l4, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t310, i32 %t311)
  store i32 %t314, ptr %l160
  br label %bb79
bb79:
  %t315 = load ptr, ptr %l152, !tbaa !29
  %t316 = load i32, ptr %l160, !tbaa !23
  %t317 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t315, i32 %t316)
  store { i64, ptr } %t317, ptr %l161
  br label %bb80
bb80:
  %t318 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t318, ptr %l15, !tbaa !27
  %t319 = load i64, ptr %l2, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t325 = icmp slt i64 %t319, %t322
  br i1 %t325, label %bb81, label %bb82
bb81:
  %t327 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t327, ptr %l167, !tbaa !27
  %t328 = load i64, ptr %l2, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr i32, ptr %t331, i64 %t328
  %t333 = load i32, ptr %t332, !tbaa !33
  store i32 %t333, ptr %l166, !tbaa !23
  br label %bb83
bb82:
  %t335 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 2
  %t336 = load i32, ptr %t335, !tbaa !23
  store i32 %t336, ptr %l166, !tbaa !23
  br label %bb83
bb83:
  %t338 = load i32, ptr %l166, !tbaa !23
  %t339 = load ptr, ptr %lp14
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l171, !tbaa !27
  store i32 %t338, ptr %l172, !tbaa !23
  %t342 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t343 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t344 = getelementptr %"compiler/source:Span", ptr %t343, i32 0, i32 0
  %t345 = load i32, ptr %t344, !tbaa !23
  %t347 = sext i32 %t345 to i64
  %t350 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %t342, i64 %t347, i1 true)
  store { i64, ptr } %t350, ptr %l176
  br label %bb84
bb84:
  %t351 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  %t353 = extractvalue { i64, ptr } %t351, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  store { i64, ptr } %t357, ptr %l177, !tbaa !27
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/session:Analysis", ptr %t358, i32 0, i32 0
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t363 = getelementptr %"compiler/load:Loader", ptr %t361, i32 0, i32 10
  %t364 = load i64, ptr %l12, !tbaa !24
  %t367 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t363, i64 %t364)
  store ptr %t367, ptr %l182
  br label %bb85
bb85:
  %t368 = load ptr, ptr %l182, !tbaa !29
  %t370 = getelementptr %"compiler/load:Module", ptr %t368, i32 0, i32 1
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 1
  %t374 = extractvalue { i64, ptr } %t371, 0
  %t375 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t374)
  call void @olang_textcopy(ptr %t375, ptr %t373, i64 %t374)
  %t376 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t375, 1
  %t379 = extractvalue { i64, ptr } %t377, 0
  %t380 = extractvalue { i64, ptr } %t377, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t385 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t386 = getelementptr %"compiler/source:Span", ptr %t385, i32 0, i32 0
  %t387 = load i32, ptr %t386, !tbaa !23
  %t389 = sext i32 %t387 to i64
  %t390 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t391 = load i32, ptr %l172, !tbaa !23
  %t392 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t395 = call %"compiler/session:memberInfo" @compiler_2fsession_3amemberInfo_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t390, i32 %t391, { i64, ptr } %t392, { i64, ptr } %t384, i64 %t389)
  store %"compiler/session:memberInfo" %t395, ptr %l189
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s4)
  %t396 = load %"compiler/session:memberInfo", ptr %l189
  %t397 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, %"compiler/session:memberInfo" %t396, 1
  store { i32, %"compiler/session:memberInfo" } %t397, ptr %rv
  br label %ret
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_dff094d230471566_615c91b3ab3b0902)
  unreachable
bb92:
  br label %bb93
bb93:
  %t398 = load i64, ptr %l7, !tbaa !24
  %t400 = add i64 %t398, 1
  store i64 %t400, ptr %l7, !tbaa !24
  br label %bb26
bb94:
  %t403 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t403, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/session:memberInfo" }, ptr %rv
  ret { i32, %"compiler/session:memberInfo" } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/typed:Local"
  %l33 = alloca i32
  %l39 = alloca i64
  %l41 = alloca i64
  %l46 = alloca ptr
  %l52 = alloca i1
  %l62 = alloca i32
  %l66 = alloca i1
  %l76 = alloca i32
  %l86 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l98 = alloca i64
  %l102 = alloca i64
  %l105 = alloca i64
  %l124 = alloca ptr
  %l128 = alloca i32
  %l130 = alloca %"compiler/typed:Local"
  %l133 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l164 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_93ae806d7d0351b8_8e59b8ae3d0673ac)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l33
  br label %bb4
bb4:
  %t21 = load i32, ptr %l33, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9641f0facc09fdd7_c62ff0c79521a99b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 14
  store ptr %t29, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  store i64 %t31, ptr %l39, !tbaa !24
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l41
  br label %bb9
bb9:
  %t35 = load i64, ptr %l39, !tbaa !24
  %t36 = load i64, ptr %l41, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb77
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l46
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l46, !tbaa !29
  store ptr %t46, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l7, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 1
  %t50 = load { i64, [2 x i64] }, ptr %t49
  store { i64, [2 x i64] } %t50, ptr %l8
  %t52 = load { i64, [2 x i64] }, ptr %l8
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb20
bb15:
  %t59 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t60 = getelementptr { i32, i32 }, ptr %t59, i32 0, i32 0
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l9, !tbaa !23
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t64 = getelementptr { i32, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l10, !tbaa !23
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c5788a2fa1963e6_4f790674132263da)
  unreachable
bb17:
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l9, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l62
  br label %bb19
bb19:
  %t82 = load i32, ptr %l62, !range !{i32 0, i32 33}
  %t84 = trunc i64 18 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l52, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l52, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb27
bb22:
  %t90 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t91 = getelementptr { i32, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l11, !tbaa !23
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t95 = getelementptr { i32, i32 }, ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l12, !tbaa !23
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c5788a2fa1963e6_4f790674132263da)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l11, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l76
  br label %bb26
bb26:
  %t113 = load i32, ptr %l4, !tbaa !23
  %t114 = load i32, ptr %l76, !tbaa !23
  %t116 = icmp ne i32 %t114, %t113
  store i1 %t116, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t118 = load i1, ptr %l66, !tbaa !21
  br i1 %t118, label %bb28, label %bb29
bb28:
  br label %bb76
bb29:
  br label %bb30
bb30:
  %t119 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t120 = getelementptr { i32, i32 }, ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l13, !tbaa !23
  %t123 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t124 = getelementptr { i32, i32 }, ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l14, !tbaa !23
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb31, label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561)
  unreachable
bb32:
  br label %bb33
bb33:
  %t131 = load ptr, ptr %l3, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l86, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561)
  unreachable
bb35:
  br label %bb36
bb36:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l2, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l94
  br label %bb37
bb37:
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = load i32, ptr %l94, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t153, i32 %t154)
  store { i64, ptr } %t155, ptr %l95
  br label %bb38
bb38:
  %t156 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t156, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Body", ptr %t157, i32 0, i32 10
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l98
  br label %bb39
bb39:
  %t162 = load i64, ptr %l98, !tbaa !24
  store i64 %t162, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t163 = load i64, ptr %l17, !tbaa !24
  %t164 = load i64, ptr %l16, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load i64, ptr %l18, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb45
bb42:
  %t173 = load i64, ptr %l17, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l18, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l18, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l105, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb44
bb44:
  %t189 = load i64, ptr %l105, !tbaa !24
  store i64 %t189, ptr %l102, !tbaa !24
  br label %bb45
bb45:
  %t190 = load i64, ptr %l102, !tbaa !24
  store i64 %t190, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t191 = load i64, ptr %l20, !tbaa !24
  %t192 = load i64, ptr %l19, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb75
bb48:
  br label %bb49
bb49:
  %t199 = load i64, ptr %l16, !tbaa !24
  %t200 = load i64, ptr %l20, !tbaa !24
  %t201 = load i64, ptr %l18, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l21, !tbaa !24
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Body", ptr %t209, i32 0, i32 7
  store ptr %t211, ptr %l124, !tbaa !29
  %t212 = load ptr, ptr %l7, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Body", ptr %t212, i32 0, i32 10
  %t215 = load i64, ptr %l21, !tbaa !24
  %t218 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l128
  br label %bb50
bb50:
  %t219 = load i32, ptr %l128, !tbaa !23
  %t220 = sext i32 %t219 to i64
  %t221 = load ptr, ptr %l124, !tbaa !29
  %t223 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t221, i64 %t220)
  store %"compiler/typed:Local" %t223, ptr %l130
  br label %bb51
bb51:
  %t224 = load %"compiler/typed:Local", ptr %l130
  store %"compiler/typed:Local" %t224, ptr %l22
  %t225 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 0
  %t226 = load i32, ptr %t225, !tbaa !23
  %t228 = icmp eq i32 %t226, 0
  br i1 %t228, label %bb52, label %bb53
bb52:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/session:Analysis", ptr %t230, i32 0, i32 0
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = getelementptr %"compiler/load:Loader", ptr %t233, i32 0, i32 4
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t237 = load ptr, ptr %l7, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Body", ptr %t237, i32 0, i32 3
  %t240 = load i64, ptr %t239, !tbaa !24
  %t243 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t236, i64 %t240)
  store { i64, ptr } %t243, ptr %l139
  br label %bb54
bb53:
  %t244 = load ptr, ptr %l3, !tbaa !29
  %t246 = icmp eq ptr %t244, null
  br i1 %t246, label %bb61, label %bb62
bb54:
  %t248 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t248, ptr %l140, !tbaa !27
  %t249 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 1
  %t250 = getelementptr %"compiler/source:Span", ptr %t249, i32 0, i32 0
  %t251 = load i32, ptr %t250, !tbaa !23
  %t253 = sext i32 %t251 to i64
  store i64 %t253, ptr %l142, !tbaa !24
  %t254 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 1
  %t255 = getelementptr %"compiler/source:Span", ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255, !tbaa !23
  %t258 = sext i32 %t256 to i64
  store i64 %t258, ptr %l144, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  store i64 %t260, ptr %l145, !tbaa !24
  %t261 = load i64, ptr %l142, !tbaa !24
  %t262 = icmp sge i64 %t261, 0
  br i1 %t262, label %bb55, label %bb56
bb55:
  %t264 = load i64, ptr %l142, !tbaa !24
  %t265 = load i64, ptr %l144, !tbaa !24
  %t266 = icmp sle i64 %t264, %t265
  br i1 %t266, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb57:
  %t268 = load i64, ptr %l144, !tbaa !24
  %t269 = load i64, ptr %l145, !tbaa !24
  %t270 = icmp sle i64 %t268, %t269
  br i1 %t270, label %bb59, label %bb60
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb59:
  %t272 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l142, !tbaa !24
  %t275 = load i64, ptr %l144, !tbaa !24
  %t276 = getelementptr i8, ptr %t273, i64 %t274
  %t277 = sub i64 %t275, %t274
  %t278 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t276, 1
  store { i64, ptr } %t279, ptr %l133, !tbaa !27
  br label %bb65
bb60:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb61:
  call void @__olang_check_failed(ptr @olang_loc_655ed1db7681c96b_c757f347e4ac2c7)
  unreachable
bb62:
  br label %bb63
bb63:
  %t281 = load ptr, ptr %l3, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/generic:Program", ptr %t285, i32 0, i32 0
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/load:Loader", ptr %t288, i32 0, i32 3
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 0
  %t293 = load i32, ptr %t292, !tbaa !23
  %t296 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s5, ptr %t291, i32 %t293)
  store { i64, ptr } %t296, ptr %l158
  br label %bb64
bb64:
  %t297 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t297, ptr %l133, !tbaa !27
  br label %bb65
bb65:
  %t298 = load { i64, ptr }, ptr %l133, !tbaa !27
  store ptr %a1, ptr %l159, !tbaa !29
  store { i64, ptr } %t298, ptr %l160, !tbaa !27
  %t301 = load i64, ptr @G_2ecompiler_2fsession_2eCompField, !tbaa !24
  store i64 %t301, ptr %l161, !tbaa !24
  %t302 = load ptr, ptr %l3, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  br i1 %t304, label %bb66, label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_284eaf45fbe9e9ea_494071f23c61296)
  unreachable
bb67:
  br label %bb68
bb68:
  %t306 = load ptr, ptr %l3, !tbaa !29
  store ptr %t306, ptr %l164, !tbaa !29
  %t307 = load i64, ptr %l21, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t313 = icmp slt i64 %t307, %t310
  br i1 %t313, label %bb69, label %bb70
bb69:
  %t315 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t315, ptr %l170, !tbaa !27
  %t316 = load i64, ptr %l21, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i32, ptr %t319, i64 %t316
  %t321 = load i32, ptr %t320, !tbaa !33
  store i32 %t321, ptr %l169, !tbaa !23
  br label %bb71
bb70:
  %t323 = getelementptr %"compiler/typed:Local", ptr %l22, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  store i32 %t324, ptr %l169, !tbaa !23
  br label %bb71
bb71:
  %t326 = load ptr, ptr %l164, !tbaa !29
  %t327 = load i32, ptr %l169, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t326, i32 %t327)
  store { i64, ptr } %t328, ptr %l174
  br label %bb72
bb72:
  %t329 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load ptr, ptr @__olang_prog_scope
  %t337 = load ptr, ptr %l159, !tbaa !29
  %t338 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t339 = load i64, ptr %l161, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %t336, ptr %s5, ptr %t337, { i64, ptr } %t338, i64 %t339, { i64, ptr } %t335)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s5)
  br label %bb74
bb74:
  %t341 = load i64, ptr %l20, !tbaa !24
  %t343 = add i64 %t341, 1
  store i64 %t343, ptr %l20, !tbaa !24
  br label %bb46
bb75:
  br label %ret
bb76:
  %t345 = load i64, ptr %l6, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l6, !tbaa !24
  br label %bb8
bb77:
  br label %ret
ret:
  ret void
}

define dso_local %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/typed:Local"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l62 = alloca %"compiler/typed:Local"
  %l65 = alloca i1
  %l76 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l81 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_878a1a37f76dded1_df06407b9e0240ed)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 14
  store ptr %t14, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l20, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l22
  br label %bb5
bb5:
  %t20 = load i64, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l22, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  store ptr %t31, ptr %l5, !tbaa !29
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t39 = icmp ne i64 %t35, %a1
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  br label %bb12
bb12:
  store i64 0, ptr %l6, !tbaa !24
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 7
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l34
  br label %bb13
bb13:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb19
bb16:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l41, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t73 = load i64, ptr %l41, !tbaa !24
  store i64 %t73, ptr %l38, !tbaa !24
  br label %bb19
bb19:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  br label %bb33
bb22:
  br label %bb23
bb23:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l11, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 7
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/typed:Local" %t99, ptr %l62
  br label %bb24
bb24:
  %t100 = load %"compiler/typed:Local", ptr %l62
  store %"compiler/typed:Local" %t100, ptr %l12
  %t101 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = icmp ne i32 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 1
  %t107 = getelementptr %"compiler/source:Span", ptr %t106, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t114 = icmp eq i64 %t110, %a2
  store i1 %t114, ptr %l65, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb27
bb27:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 0
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = trunc i64 %t123 to i32
  %t129 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s6, i64 %t122, i32 %t125)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t129, ptr %l76
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l76
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t130, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb20
bb33:
  br label %bb34
bb34:
  %t135 = load i64, ptr %l4, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l4, !tbaa !24
  br label %bb4
bb35:
  %t139 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s0, i64 -1, i32 0)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t139, ptr %l81
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t140 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l81
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t140, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %rv
  ret %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/names:Entry"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/names:Entry"
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i1
  %l57 = alloca i64
  %l60 = alloca i1
  %l67 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l94 = alloca i1
  %l96 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l101 = alloca i64
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_ad4014c285adba33_5f0a50bbd6dd5777)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 3
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758)
  unreachable
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l28
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t42 = getelementptr %"compiler/names:Table", ptr %t40, i32 0, i32 0
  store ptr %t42, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t44 = load i64, ptr %l7, !tbaa !24
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l33, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb68
bb11:
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store %"compiler/names:Entry" %t58, ptr %l38
  br label %bb13
bb13:
  %t59 = load %"compiler/names:Entry", ptr %l38
  store %"compiler/names:Entry" %t59, ptr %l8
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t60, i32 %t62)
  store { i64, ptr } %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t66, ptr %l9, !tbaa !27
  %t69 = xor i1 %a3, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t73 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t71)
  store i1 %t73, ptr %l46
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  %t74 = load i1, ptr %l46, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  br label %bb67
bb20:
  br label %bb21
bb21:
  %t78 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 9}
  %t81 = trunc i64 3 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb24, label %bb25
bb23:
  %t88 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t89 = load i32, ptr %t88, !range !{i32 0, i32 9}
  %t91 = trunc i64 4 to i32
  %t92 = icmp eq i32 %t89, %t91
  br i1 %t92, label %bb47, label %bb48
bb24:
  call void @__olang_check_failed(ptr @olang_loc_c15f20635f7a4119_452b944b82f8966d)
  unreachable
bb25:
  br label %bb26
bb26:
  %t94 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l2, !tbaa !24
  %t100 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 0
  %t101 = load i32, ptr %t100, !tbaa !23
  %t105 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t98, i64 %t99, i32 %t101)
  store i64 %t105, ptr %l57
  br label %bb27
bb27:
  %t106 = load i64, ptr %l57, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t107, 0
  br i1 %t109, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb34
bb29:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_6010ac475f88a9f2_430aff1aa96b7386)
  unreachable
bb31:
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l4, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l10, !tbaa !24
  %t123 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l67
  br label %bb33
bb33:
  %t124 = load ptr, ptr %l67, !tbaa !29
  %t126 = getelementptr %"compiler/ast:Func", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  %t131 = xor i1 %t129, true
  store i1 %t131, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t133 = load i1, ptr %l60, !tbaa !21
  br i1 %t133, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s4)
  br label %bb67
bb36:
  br label %bb37
bb37:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l72, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t135, ptr %l73, !tbaa !27
  %t136 = load i64, ptr @G_2ecompiler_2fsession_2eCompFunction, !tbaa !24
  store i64 %t136, ptr %l74, !tbaa !24
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_64c89934b5f1bf_a2a8dc486100a28b)
  unreachable
bb39:
  br label %bb40
bb40:
  %t141 = load ptr, ptr %l4, !tbaa !29
  store ptr %t141, ptr %l77, !tbaa !29
  %t142 = load ptr, ptr %l4, !tbaa !29
  %t144 = icmp eq ptr %t142, null
  br i1 %t144, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_64c89934b5f1bf_a2a8dc486100a28b)
  unreachable
bb42:
  br label %bb43
bb43:
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t150, i64 %t151)
  store i32 %t154, ptr %l84
  br label %bb44
bb44:
  %t155 = load ptr, ptr %l77, !tbaa !29
  %t156 = load i32, ptr %l84, !tbaa !23
  %t157 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s4, ptr %t155, i32 %t156)
  store { i64, ptr } %t157, ptr %l85
  br label %bb45
bb45:
  %t158 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t165 = load ptr, ptr %l72, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t167 = load i64, ptr %l74, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s4, ptr %t165, { i64, ptr } %t166, i64 %t167, { i64, ptr } %t164)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb66
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t171 = load i64, ptr @G_2ecompiler_2fsession_2eCompStruct, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s7, ptr %t169, { i64, ptr } %t170, i64 %t171, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t175 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t176 = load i32, ptr %t175, !range !{i32 0, i32 9}
  %t178 = trunc i64 2 to i32
  %t179 = icmp eq i32 %t176, %t178
  br i1 %t179, label %bb50, label %bb51
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb50:
  %t181 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t183 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s8, { i64, ptr } %t181, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t183, ptr %l96
  br label %bb52
bb51:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb53
bb52:
  %t184 = load i1, ptr %l96, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l94, !tbaa !21
  br label %bb53
bb53:
  %t187 = load i1, ptr %l94, !tbaa !21
  br i1 %t187, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l98, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t189, ptr %l99, !tbaa !27
  %t190 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 3
  %t191 = load i1, ptr %t190, !tbaa !21
  br i1 %t191, label %bb56, label %bb57
bb55:
  %t193 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t194 = load i32, ptr %t193, !range !{i32 0, i32 9}
  %t196 = trunc i64 5 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb60, label %bb61
bb56:
  %t199 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t199, ptr %l101, !tbaa !24
  br label %bb58
bb57:
  %t201 = load i64, ptr @G_2ecompiler_2fsession_2eCompConstant, !tbaa !24
  store i64 %t201, ptr %l101, !tbaa !24
  br label %bb58
bb58:
  %t203 = load ptr, ptr %l98, !tbaa !29
  %t204 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t205 = load i64, ptr %l101, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s9, ptr %t203, { i64, ptr } %t204, i64 %t205, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb64
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t208 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s11, ptr %t206, { i64, ptr } %t207, i64 %t208, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_scope_close(ptr %s11)
  br label %bb63
bb63:
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb65
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l7, !tbaa !24
  br label %bb8
bb68:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l40 = alloca ptr
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/load:Loader", ptr %t4, i32 0, i32 10
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i64, ptr %l11, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l18, !tbaa !24
  store i64 %t36, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l15, !tbaa !24
  store i64 %t37, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb17
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l2, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l4, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/session:Analysis", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/load:Loader", ptr %t59, i32 0, i32 10
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l40
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l40, !tbaa !29
  %t68 = getelementptr %"compiler/load:Module", ptr %t66, i32 0, i32 4
  %t69 = load i64, ptr %t68, !tbaa !24
  %t73 = icmp eq i64 %t69, %a1
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load i64, ptr %l7, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb17:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/names:Entry"
  %l14 = alloca i64
  %l15 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %lp23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l59 = alloca %"compiler/names:Ref"
  %l65 = alloca %"compiler/names:Ref"
  %l73 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca ptr
  %l88 = alloca %"compiler/names:Entry"
  %l90 = alloca { i64, ptr }
  %l104 = alloca %"compiler/source:Span"
  %l109 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l125 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca i64
  %l135 = alloca %"compiler/names:Entry"
  %l139 = alloca i1
  %l150 = alloca i64
  %l153 = alloca i1
  %l156 = alloca i1
  %l163 = alloca ptr
  %l179 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l195 = alloca i64
  %l199 = alloca i64
  %l202 = alloca i64
  %l226 = alloca i64
  %l235 = alloca ptr
  %l239 = alloca i1
  %l249 = alloca { i64, ptr }
  %l251 = alloca i1
  %l259 = alloca i1
  %l266 = alloca i1
  %l271 = alloca i1
  %l273 = alloca i64
  %l275 = alloca { i64, ptr }
  %l277 = alloca %"compiler/source:Span"
  %l286 = alloca i64
  %l288 = alloca i64
  %l289 = alloca { i64, ptr }
  %l293 = alloca %"compiler/session:finder"
  %l299 = alloca i64
  %l301 = alloca i64
  %l306 = alloca ptr
  %l311 = alloca i1
  %l321 = alloca i1
  %s3 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i64, [6 x i64] }
  %t171 = alloca { i64, [6 x i64] }, align 8
  %t187 = alloca { i64, [6 x i64] }, align 8
  %t231 = alloca { i64, [6 x i64] }, align 8
  %t260 = alloca { i64, [6 x i64] }, align 8
  %t384 = alloca { i64, [6 x i64] }, align 8
  %t417 = alloca { i64, [6 x i64] }, align 8
  %t629 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l39
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store { i64, ptr } %t38, ptr %l44
  br label %bb5
bb5:
  %t39 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t39, ptr %l45, !tbaa !27
  %t40 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l47, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l49, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l50, !tbaa !24
  %t50 = load i64, ptr %l47, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = load i64, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l49, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb8:
  %t57 = load i64, ptr %l49, !tbaa !24
  %t58 = load i64, ptr %l50, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb10:
  %t61 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l47, !tbaa !24
  %t64 = load i64, ptr %l49, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t75, ptr %lp6
  %t77 = load ptr, ptr %lp6
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t85 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t78, i64 %t79, i32 %t81)
  store %"compiler/names:Ref" %t85, ptr %l59
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb12:
  %t86 = load %"compiler/names:Ref", ptr %l59
  store %"compiler/names:Ref" %t86, ptr %l7
  %t87 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87, !range !{i32 0, i32 9}
  %t90 = trunc i64 0 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t100 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t93, i64 %t94, i32 %t96)
  store %"compiler/names:Ref" %t100, ptr %l65
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t101 = load %"compiler/names:Ref", ptr %l65
  store %"compiler/names:Ref" %t101, ptr %l7
  br label %bb16
bb16:
  %t102 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t103 = load i32, ptr %t102, !range !{i32 0, i32 9}
  store i32 %t103, ptr %l8
  %t105 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t110 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t115 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t117 = trunc i64 4 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb30
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l73, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f729b95fcb28e588_e9118b2581b5934c)
  unreachable
bb25:
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 3
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l80, !tbaa !29
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/names:Resolver", ptr %t137, i32 0, i32 1
  %t140 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t139, i64 %t141)
  store ptr %t144, ptr %l84
  br label %bb27
bb27:
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t147 = getelementptr %"compiler/names:Table", ptr %t145, i32 0, i32 0
  %t148 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s3, ptr %t147, i64 %t149)
  store %"compiler/names:Entry" %t152, ptr %l88
  br label %bb28
bb28:
  %t153 = getelementptr %"compiler/names:Entry", ptr %l88, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t155, i32 %t154)
  store { i64, ptr } %t157, ptr %l90
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t159, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = mul i64 %t165, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t167)
  call void @llvm.memcpy.p0.p0.i64(ptr %t168, ptr %t166, i64 %t167, i1 false)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 0
  store i64 1, ptr %t172
  %t173 = load i64, ptr %l73, !tbaa !24
  %t174 = insertvalue { i64, { i64, ptr } } undef, i64 %t173, 0
  %t176 = insertvalue { i64, { i64, ptr } } %t174, { i64, ptr } %t170, 1
  %t177 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 1
  store { i64, { i64, ptr } } %t176, ptr %t177
  %t178 = load { i64, [6 x i64] }, ptr %t171
  call void @__olang_scope_close(ptr %s3)
  store { i64, [6 x i64] } %t178, ptr %rv
  br label %ret
bb30:
  %t180 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t182 = trunc i64 5 to i32
  %t183 = icmp eq i32 %t180, %t182
  br i1 %t183, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t185 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [6 x i64] }, ptr %t187, i32 0, i32 0
  store i64 6, ptr %t188
  %t190 = insertvalue { i64 } undef, i64 %t186, 0
  %t191 = getelementptr { i64, [6 x i64] }, ptr %t187, i32 0, i32 1
  store { i64 } %t190, ptr %t191
  %t192 = load { i64, [6 x i64] }, ptr %t187
  store { i64, [6 x i64] } %t192, ptr %rv
  br label %ret
bb34:
  %t194 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t196 = trunc i64 1 to i32
  %t197 = icmp eq i32 %t194, %t196
  br i1 %t197, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  %t199 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t201 = trunc i64 8 to i32
  %t202 = icmp eq i32 %t199, %t201
  br i1 %t202, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t204 = load ptr, ptr %l4, !tbaa !29
  %t205 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t206 = load i64, ptr %t205, !tbaa !24
  %t209 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %t204, i64 %t206)
  store %"compiler/source:Span" %t209, ptr %l104
  br label %bb40
bb40:
  %t210 = load %"compiler/source:Span", ptr %l104
  store %"compiler/source:Span" %t210, ptr %l9
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load i64, ptr %l5, !tbaa !24
  %t213 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t214 = load i32, ptr %t213, !tbaa !23
  %t216 = sext i32 %t214 to i64
  %t220 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t211, i64 %t212, i64 %t216)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t220, ptr %l109
  br label %bb41
bb41:
  %t221 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l109
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t221, ptr %l10
  %t222 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = icmp sge i64 %t223, 0
  br i1 %t225, label %bb42, label %bb43
bb42:
  %t227 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 1
  %t230 = load i32, ptr %t229, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t231
  %t232 = getelementptr { i64, [6 x i64] }, ptr %t231, i32 0, i32 0
  store i64 4, ptr %t232
  %t234 = insertvalue { i64, i32 } undef, i64 %t228, 0
  %t236 = insertvalue { i64, i32 } %t234, i32 %t230, 1
  %t237 = getelementptr { i64, [6 x i64] }, ptr %t231, i32 0, i32 1
  store { i64, i32 } %t236, ptr %t237
  %t238 = load { i64, [6 x i64] }, ptr %t231
  store { i64, [6 x i64] } %t238, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t240 = load i64, ptr %l1, !tbaa !24
  %t241 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = sext i32 %t242 to i64
  %t245 = load ptr, ptr %lp6
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 1
  %t249 = extractvalue { i64, ptr } %t246, 0
  %t250 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t249)
  call void @olang_textcopy(ptr %t250, ptr %t248, i64 %t249)
  %t251 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = extractvalue { i64, ptr } %t252, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [6 x i64] }, ptr %t260, i32 0, i32 0
  store i64 5, ptr %t261
  %t263 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } undef, i64 %t240, 0
  %t265 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t263, i64 %t244, 1
  %t266 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t265, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, 2
  %t268 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t266, { i64, ptr } %t259, 3
  %t269 = getelementptr { i64, [6 x i64] }, ptr %t260, i32 0, i32 1
  store { i64, i64, { i64, ptr }, { i64, ptr } } %t268, ptr %t269
  %t270 = load { i64, [6 x i64] }, ptr %t260
  store { i64, [6 x i64] } %t270, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2)
  unreachable
bb50:
  %t272 = load ptr, ptr %l4, !tbaa !29
  %t274 = getelementptr %"compiler/names:Resolver", ptr %t272, i32 0, i32 1
  %t275 = load i64, ptr %l1, !tbaa !24
  %t278 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t274, i64 %t275)
  store ptr %t278, ptr %l125
  br label %bb51
bb51:
  %t279 = load ptr, ptr %l125, !tbaa !29
  %t281 = getelementptr %"compiler/names:Table", ptr %t279, i32 0, i32 0
  store ptr %t281, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  %t283 = load i64, ptr %l12, !tbaa !24
  store i64 %t283, ptr %l128, !tbaa !24
  %t284 = load ptr, ptr %l11, !tbaa !29
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l130
  br label %bb53
bb53:
  %t287 = load i64, ptr %l128, !tbaa !24
  %t288 = load i64, ptr %l130, !tbaa !24
  %t289 = icmp slt i64 %t287, %t288
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb54, label %bb55
bb54:
  br label %bb82
bb55:
  br label %bb56
bb56:
  %t293 = load ptr, ptr %l11, !tbaa !29
  %t294 = load i64, ptr %l12, !tbaa !24
  %t297 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t293, i64 %t294)
  store %"compiler/names:Entry" %t297, ptr %l135
  br label %bb57
bb57:
  %t298 = load %"compiler/names:Entry", ptr %l135
  store %"compiler/names:Entry" %t298, ptr %l13
  %t299 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 1
  %t300 = getelementptr %"compiler/source:Span", ptr %t299, i32 0, i32 0
  %t301 = load i32, ptr %t300, !tbaa !23
  %t302 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t306 = icmp eq i32 %t301, %t303
  br i1 %t306, label %bb58, label %bb59
bb58:
  %t308 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 2
  %t309 = load i32, ptr %t308, !range !{i32 0, i32 9}
  %t311 = trunc i64 5 to i32
  %t312 = icmp eq i32 %t309, %t311
  %t314 = xor i1 %t312, true
  store i1 %t314, ptr %l139, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb60
bb60:
  %t316 = load i1, ptr %l139, !tbaa !21
  br i1 %t316, label %bb61, label %bb62
bb61:
  %t317 = load ptr, ptr %l3, !tbaa !29
  %t319 = icmp eq ptr %t317, null
  br i1 %t319, label %bb63, label %bb64
bb62:
  br label %bb80
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a3b4800e6d7209ba_290fe7f1ef38ac36)
  unreachable
bb64:
  br label %bb65
bb65:
  %t321 = load ptr, ptr %l3, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t326 = load i64, ptr %l1, !tbaa !24
  %t327 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 0
  %t328 = load i32, ptr %t327, !tbaa !23
  %t332 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t325, i64 %t326, i32 %t328)
  store i64 %t332, ptr %l150
  br label %bb66
bb66:
  %t333 = load i64, ptr %l150, !tbaa !24
  store i64 %t333, ptr %l14, !tbaa !24
  %t334 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 2
  %t335 = load i32, ptr %t334, !range !{i32 0, i32 9}
  %t337 = trunc i64 3 to i32
  %t338 = icmp eq i32 %t335, %t337
  br i1 %t338, label %bb67, label %bb68
bb67:
  %t340 = load i64, ptr %l14, !tbaa !24
  %t342 = icmp sge i64 %t340, 0
  store i1 %t342, ptr %l153, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb69
bb69:
  %t344 = load i1, ptr %l153, !tbaa !21
  br i1 %t344, label %bb70, label %bb71
bb70:
  %t345 = load ptr, ptr %l3, !tbaa !29
  %t347 = icmp eq ptr %t345, null
  br i1 %t347, label %bb72, label %bb73
bb71:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb76
bb72:
  call void @__olang_check_failed(ptr @olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d)
  unreachable
bb73:
  br label %bb74
bb74:
  %t349 = load ptr, ptr %l3, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t354 = load i64, ptr %l14, !tbaa !24
  %t357 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t353, i64 %t354)
  store ptr %t357, ptr %l163
  br label %bb75
bb75:
  %t358 = load ptr, ptr %l163, !tbaa !29
  %t360 = getelementptr %"compiler/ast:Func", ptr %t358, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t363 = icmp eq ptr %t361, null
  %t365 = xor i1 %t363, true
  store i1 %t365, ptr %l156, !tbaa !21
  br label %bb76
bb76:
  %t367 = load i1, ptr %l156, !tbaa !21
  br i1 %t367, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t368 = load i64, ptr %l1, !tbaa !24
  %t369 = load ptr, ptr %lp6
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 1
  %t373 = extractvalue { i64, ptr } %t370, 0
  %t374 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t373)
  call void @olang_textcopy(ptr %t374, ptr %t372, i64 %t373)
  %t375 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = extractvalue { i64, ptr } %t376, 1
  %t380 = mul i64 %t378, 1
  %t381 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t380)
  call void @llvm.memcpy.p0.p0.i64(ptr %t381, ptr %t379, i64 %t380, i1 false)
  %t382 = insertvalue { i64, ptr } undef, i64 %t378, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t384
  %t385 = getelementptr { i64, [6 x i64] }, ptr %t384, i32 0, i32 0
  store i64 1, ptr %t385
  %t387 = insertvalue { i64, { i64, ptr } } undef, i64 %t368, 0
  %t389 = insertvalue { i64, { i64, ptr } } %t387, { i64, ptr } %t383, 1
  %t390 = getelementptr { i64, [6 x i64] }, ptr %t384, i32 0, i32 1
  store { i64, { i64, ptr } } %t389, ptr %t390
  %t391 = load { i64, [6 x i64] }, ptr %t384
  store { i64, [6 x i64] } %t391, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t393 = load i64, ptr %l12, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l12, !tbaa !24
  br label %bb52
bb82:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i64, ptr %l5, !tbaa !24
  %t399 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t400 = load i32, ptr %t399, !tbaa !23
  %t402 = sext i32 %t400 to i64
  %t406 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t397, i64 %t398, i64 %t402)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t406, ptr %l179
  br label %bb83
bb83:
  %t407 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l179
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t407, ptr %l15
  %t408 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 0
  %t409 = load i64, ptr %t408, !tbaa !24
  %t411 = icmp sge i64 %t409, 0
  br i1 %t411, label %bb84, label %bb85
bb84:
  %t413 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 0
  %t414 = load i64, ptr %t413, !tbaa !24
  %t415 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 1
  %t416 = load i32, ptr %t415, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t417
  %t418 = getelementptr { i64, [6 x i64] }, ptr %t417, i32 0, i32 0
  store i64 4, ptr %t418
  %t420 = insertvalue { i64, i32 } undef, i64 %t414, 0
  %t422 = insertvalue { i64, i32 } %t420, i32 %t416, 1
  %t423 = getelementptr { i64, [6 x i64] }, ptr %t417, i32 0, i32 1
  store { i64, i32 } %t422, ptr %t423
  %t424 = load { i64, [6 x i64] }, ptr %t417
  store { i64, [6 x i64] } %t424, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t426 = load ptr, ptr %l3, !tbaa !29
  %t428 = icmp eq ptr %t426, null
  br i1 %t428, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_f548539da9e2e40c_6a57728f427e36c8)
  unreachable
bb88:
  br label %bb89
bb89:
  %t430 = load ptr, ptr %l3, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t434)
  br label %bb90
bb90:
  store i64 0, ptr %l16, !tbaa !24
  %t436 = load ptr, ptr %l3, !tbaa !29
  %t438 = icmp eq ptr %t436, null
  br i1 %t438, label %bb91, label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7)
  unreachable
bb92:
  br label %bb93
bb93:
  %t440 = load ptr, ptr %l3, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t440, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t446 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t444)
  store i64 %t446, ptr %l195
  br label %bb94
bb94:
  %t447 = load i64, ptr %l195, !tbaa !24
  store i64 %t447, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t448 = load i64, ptr %l17, !tbaa !24
  %t449 = load i64, ptr %l16, !tbaa !24
  %t452 = icmp sgt i64 %t448, %t449
  br i1 %t452, label %bb95, label %bb96
bb95:
  %t454 = load i64, ptr %l18, !tbaa !24
  %t456 = icmp sgt i64 %t454, 0
  br i1 %t456, label %bb97, label %bb98
bb96:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb100
bb97:
  %t458 = load i64, ptr %l17, !tbaa !24
  %t459 = load i64, ptr %l16, !tbaa !24
  %t462 = sub i64 %t458, %t459
  %t463 = load i64, ptr %l18, !tbaa !24
  %t466 = add i64 %t462, %t463
  %t468 = sub i64 %t466, 1
  %t469 = load i64, ptr %l18, !tbaa !24
  %t472 = sdiv i64 %t468, %t469
  store i64 %t472, ptr %l202, !tbaa !24
  br label %bb99
bb98:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb99
bb99:
  %t474 = load i64, ptr %l202, !tbaa !24
  store i64 %t474, ptr %l199, !tbaa !24
  br label %bb100
bb100:
  %t475 = load i64, ptr %l199, !tbaa !24
  store i64 %t475, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb101
bb101:
  store %olang.scope zeroinitializer, ptr %s18
  %t476 = load i64, ptr %l20, !tbaa !24
  %t477 = load i64, ptr %l19, !tbaa !24
  %t480 = icmp slt i64 %t476, %t477
  %t482 = xor i1 %t480, true
  br i1 %t482, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s18)
  br label %bb141
bb103:
  br label %bb104
bb104:
  %t484 = load i64, ptr %l16, !tbaa !24
  %t485 = load i64, ptr %l20, !tbaa !24
  %t486 = load i64, ptr %l18, !tbaa !24
  %t489 = mul i64 %t485, %t486
  %t492 = add i64 %t484, %t489
  store i64 %t492, ptr %l21, !tbaa !24
  %t494 = load ptr, ptr %l3, !tbaa !29
  %t496 = icmp eq ptr %t494, null
  br i1 %t496, label %bb105, label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_be0af37330f35afe_68a0a057b8d4cca2)
  unreachable
bb106:
  br label %bb107
bb107:
  %t498 = load ptr, ptr %l3, !tbaa !29
  %t501 = getelementptr %"compiler/check:Checker", ptr %t498, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !29
  %t503 = load i64, ptr %l21, !tbaa !24
  %t506 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t502, i64 %t503)
  store i64 %t506, ptr %l226
  br label %bb108
bb108:
  %t507 = load i64, ptr %l1, !tbaa !24
  %t508 = load i64, ptr %l226, !tbaa !24
  %t510 = icmp ne i64 %t508, %t507
  br i1 %t510, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s18)
  br label %bb140
bb110:
  br label %bb111
bb111:
  %t512 = load ptr, ptr %l3, !tbaa !29
  %t514 = icmp eq ptr %t512, null
  br i1 %t514, label %bb112, label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_7be9b74a0a4337a5_af051c2067e0d709)
  unreachable
bb113:
  br label %bb114
bb114:
  %t516 = load ptr, ptr %l3, !tbaa !29
  %t519 = getelementptr %"compiler/check:Checker", ptr %t516, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !29
  %t521 = load i64, ptr %l21, !tbaa !24
  %t524 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t520, i64 %t521)
  store ptr %t524, ptr %l235
  br label %bb115
bb115:
  %t525 = load ptr, ptr %l235, !tbaa !29
  store ptr %t525, ptr %l22, !tbaa !29
  %t526 = load ptr, ptr %l22, !tbaa !29
  %t528 = getelementptr %"compiler/ast:Func", ptr %t526, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = icmp eq ptr %t529, null
  br i1 %t531, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l239, !tbaa !21
  br label %bb123
bb117:
  %t533 = load ptr, ptr %l3, !tbaa !29
  %t535 = icmp eq ptr %t533, null
  br i1 %t535, label %bb118, label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_a0e32d5552598bb5_d1b40570995ef0d1)
  unreachable
bb119:
  br label %bb120
bb120:
  %t537 = load ptr, ptr %l3, !tbaa !29
  %t540 = getelementptr %"compiler/check:Checker", ptr %t537, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !29
  %t543 = getelementptr %"compiler/generic:Program", ptr %t541, i32 0, i32 0
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t546 = getelementptr %"compiler/load:Loader", ptr %t544, i32 0, i32 3
  %t547 = load ptr, ptr %t546, !tbaa !29
  %t548 = load ptr, ptr %l22, !tbaa !29
  %t550 = getelementptr %"compiler/ast:Func", ptr %t548, i32 0, i32 2
  %t551 = load i32, ptr %t550, !tbaa !23
  %t554 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s18, ptr %t547, i32 %t551)
  store { i64, ptr } %t554, ptr %l249
  br label %bb121
bb121:
  %t555 = load ptr, ptr %lp6
  %t556 = load { i64, ptr }, ptr %t555, !tbaa !27
  %t557 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t559 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s18, ptr %v1, { i64, ptr } %t557, { i64, ptr } %t556)
  store i1 %t559, ptr %l251
  br label %bb122
bb122:
  %t560 = load i1, ptr %l251, !tbaa !21
  %t561 = xor i1 %t560, true
  store i1 %t561, ptr %l239, !tbaa !21
  br label %bb123
bb123:
  %t563 = load i1, ptr %l239, !tbaa !21
  br i1 %t563, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s18)
  br label %bb140
bb125:
  br label %bb126
bb126:
  %t564 = load ptr, ptr %l22, !tbaa !29
  %t566 = getelementptr %"compiler/ast:Func", ptr %t564, i32 0, i32 0
  %t567 = getelementptr %"compiler/source:Span", ptr %t566, i32 0, i32 0
  %t568 = load i32, ptr %t567, !tbaa !23
  %t570 = sext i32 %t568 to i64
  %t571 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t572 = load i32, ptr %t571, !tbaa !23
  %t574 = sext i32 %t572 to i64
  %t577 = icmp sle i64 %t570, %t574
  br i1 %t577, label %bb127, label %bb128
bb127:
  %t579 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t580 = load i32, ptr %t579, !tbaa !23
  %t582 = sext i32 %t580 to i64
  %t583 = load ptr, ptr %l22, !tbaa !29
  %t585 = getelementptr %"compiler/ast:Func", ptr %t583, i32 0, i32 0
  %t586 = getelementptr %"compiler/source:Span", ptr %t585, i32 0, i32 1
  %t587 = load i32, ptr %t586, !tbaa !23
  %t589 = sext i32 %t587 to i64
  %t592 = icmp slt i64 %t582, %t589
  store i1 %t592, ptr %l259, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb129
bb129:
  %t594 = load i1, ptr %l259, !tbaa !21
  br i1 %t594, label %bb130, label %bb131
bb130:
  %t595 = load ptr, ptr %l22, !tbaa !29
  %t597 = getelementptr %"compiler/ast:Func", ptr %t595, i32 0, i32 4
  %t598 = load { i64, ptr }, ptr %t597, !tbaa !27
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t602 = icmp eq i64 %t600, 0
  br i1 %t602, label %bb132, label %bb133
bb131:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb136
bb132:
  store i1 true, ptr %l271, !tbaa !21
  br label %bb135
bb133:
  %t604 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t605 = load i32, ptr %t604, !tbaa !23
  %t607 = sext i32 %t605 to i64
  store i64 %t607, ptr %l273, !tbaa !24
  %t608 = load ptr, ptr %l22, !tbaa !29
  %t610 = getelementptr %"compiler/ast:Func", ptr %t608, i32 0, i32 4
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l275, !tbaa !27
  %t612 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr ptr, ptr %t613, i64 0
  %t615 = load ptr, ptr %t614, !tbaa !39
  %t617 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %t615)
  store %"compiler/source:Span" %t617, ptr %l277
  br label %bb134
bb134:
  %t618 = getelementptr %"compiler/source:Span", ptr %l277, i32 0, i32 0
  %t619 = load i32, ptr %t618, !tbaa !23
  %t621 = sext i32 %t619 to i64
  %t622 = load i64, ptr %l273, !tbaa !24
  %t624 = icmp slt i64 %t622, %t621
  store i1 %t624, ptr %l271, !tbaa !21
  br label %bb135
bb135:
  %t626 = load i1, ptr %l271, !tbaa !21
  store i1 %t626, ptr %l266, !tbaa !21
  br label %bb136
bb136:
  %t627 = load i1, ptr %l266, !tbaa !21
  br i1 %t627, label %bb137, label %bb138
bb137:
  %t628 = load i64, ptr %l21, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t629
  %t630 = getelementptr { i64, [6 x i64] }, ptr %t629, i32 0, i32 0
  store i64 2, ptr %t630
  %t632 = insertvalue { i64 } undef, i64 %t628, 0
  %t633 = getelementptr { i64, [6 x i64] }, ptr %t629, i32 0, i32 1
  store { i64 } %t632, ptr %t633
  %t634 = load { i64, [6 x i64] }, ptr %t629
  call void @__olang_scope_close(ptr %s18)
  store { i64, [6 x i64] } %t634, ptr %rv
  br label %ret
bb138:
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s18)
  br label %bb140
bb140:
  %t636 = load i64, ptr %l20, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l20, !tbaa !24
  br label %bb101
bb141:
  %t640 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t641 = load i32, ptr %t640, !tbaa !23
  %t643 = sext i32 %t641 to i64
  store i64 %t643, ptr %l286, !tbaa !24
  %t644 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t645 = load i32, ptr %t644, !tbaa !23
  %t647 = sext i32 %t645 to i64
  store i64 %t647, ptr %l288, !tbaa !24
  %t648 = load ptr, ptr %lp6
  %t649 = load { i64, ptr }, ptr %t648, !tbaa !27
  store { i64, ptr } %t649, ptr %l289, !tbaa !27
  %t650 = load ptr, ptr %l3, !tbaa !29
  %t652 = icmp eq ptr %t650, null
  br i1 %t652, label %bb142, label %bb143
bb142:
  call void @__olang_check_failed(ptr @olang_loc_90517919cad2500e_b5e04c9858b7f7ca)
  unreachable
bb143:
  br label %bb144
bb144:
  %t654 = load ptr, ptr %l3, !tbaa !29
  %t655 = load i64, ptr %l286, !tbaa !24
  %t656 = load i64, ptr %l288, !tbaa !24
  %t657 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t659 = call %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v1, ptr %v0, ptr %v1, i64 %t655, i64 %t656, { i64, ptr } %t657, ptr %t654)
  store %"compiler/session:finder" %t659, ptr %l293
  br label %bb145
bb145:
  %t660 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store ptr %t660, ptr %lp23
  %t661 = load %"compiler/session:finder", ptr %l293
  %t662 = load ptr, ptr %lp23
  store %"compiler/session:finder" %t661, ptr %t662
  %t663 = load ptr, ptr %l3, !tbaa !29
  %t665 = icmp eq ptr %t663, null
  br i1 %t665, label %bb146, label %bb147
bb146:
  call void @__olang_check_failed(ptr @olang_loc_ce3fd8c720c212bf_60e6469ff90569cb)
  unreachable
bb147:
  br label %bb148
bb148:
  %t667 = load ptr, ptr %l3, !tbaa !29
  %t670 = getelementptr %"compiler/check:Checker", ptr %t667, i32 0, i32 14
  store ptr %t670, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb149
bb149:
  %t672 = load i64, ptr %l25, !tbaa !24
  store i64 %t672, ptr %l299, !tbaa !24
  %t673 = load ptr, ptr %l24, !tbaa !29
  %t675 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t673)
  store i64 %t675, ptr %l301
  br label %bb150
bb150:
  %t676 = load i64, ptr %l299, !tbaa !24
  %t677 = load i64, ptr %l301, !tbaa !24
  %t678 = icmp slt i64 %t676, %t677
  %t680 = xor i1 %t678, true
  br i1 %t680, label %bb151, label %bb152
bb151:
  br label %bb169
bb152:
  br label %bb153
bb153:
  %t682 = load ptr, ptr %l24, !tbaa !29
  %t683 = load i64, ptr %l25, !tbaa !24
  %t686 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t682, i64 %t683)
  store ptr %t686, ptr %l306
  br label %bb154
bb154:
  %t687 = load ptr, ptr %l306, !tbaa !29
  store ptr %t687, ptr %l26, !tbaa !29
  %t688 = load ptr, ptr %l26, !tbaa !29
  %t690 = getelementptr %"compiler/typed:Body", ptr %t688, i32 0, i32 3
  %t691 = load i64, ptr %t690, !tbaa !24
  %t692 = load i64, ptr %l5, !tbaa !24
  %t695 = icmp ne i64 %t691, %t692
  br i1 %t695, label %bb155, label %bb156
bb155:
  store i1 true, ptr %l311, !tbaa !21
  br label %bb157
bb156:
  %t697 = load ptr, ptr %l26, !tbaa !29
  %t699 = getelementptr %"compiler/typed:Body", ptr %t697, i32 0, i32 11
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = icmp eq ptr %t700, null
  store i1 %t702, ptr %l311, !tbaa !21
  br label %bb157
bb157:
  %t704 = load i1, ptr %l311, !tbaa !21
  br i1 %t704, label %bb158, label %bb159
bb158:
  br label %bb168
bb159:
  br label %bb160
bb160:
  %t705 = load ptr, ptr %l26, !tbaa !29
  %t707 = getelementptr %"compiler/typed:Body", ptr %t705, i32 0, i32 4
  %t708 = getelementptr %"compiler/source:Span", ptr %t707, i32 0, i32 1
  %t709 = load i32, ptr %t708, !tbaa !23
  %t711 = sext i32 %t709 to i64
  %t712 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t713 = load i32, ptr %t712, !tbaa !23
  %t715 = sext i32 %t713 to i64
  %t718 = icmp slt i64 %t711, %t715
  br i1 %t718, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l321, !tbaa !21
  br label %bb163
bb162:
  %t720 = load ptr, ptr %l26, !tbaa !29
  %t722 = getelementptr %"compiler/typed:Body", ptr %t720, i32 0, i32 4
  %t723 = getelementptr %"compiler/source:Span", ptr %t722, i32 0, i32 0
  %t724 = load i32, ptr %t723, !tbaa !23
  %t726 = sext i32 %t724 to i64
  %t727 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t728 = load i32, ptr %t727, !tbaa !23
  %t730 = sext i32 %t728 to i64
  %t733 = icmp sgt i64 %t726, %t730
  store i1 %t733, ptr %l321, !tbaa !21
  br label %bb163
bb163:
  %t735 = load i1, ptr %l321, !tbaa !21
  br i1 %t735, label %bb164, label %bb165
bb164:
  br label %bb168
bb165:
  br label %bb166
bb166:
  %t736 = load ptr, ptr %l26, !tbaa !29
  %t738 = getelementptr %"compiler/typed:Body", ptr %t736, i32 0, i32 0
  %t739 = load i32, ptr %t738, !tbaa !23
  %t741 = sext i32 %t739 to i64
  %t743 = load ptr, ptr %lp23
  %t744 = getelementptr %"compiler/session:finder", ptr %t743, i32 0, i32 4
  store i64 %t741, ptr %t744, !tbaa !24
  %t745 = load ptr, ptr %lp23
  %t746 = load ptr, ptr %l26, !tbaa !29
  %t748 = getelementptr %"compiler/typed:Body", ptr %t746, i32 0, i32 11
  %t749 = load ptr, ptr %t748, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v1, ptr %v0, ptr %t745, ptr %t749)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t752 = load i64, ptr %l25, !tbaa !24
  %t754 = add i64 %t752, 1
  store i64 %t754, ptr %l25, !tbaa !24
  br label %bb149
bb169:
  %t756 = load ptr, ptr %lp23
  %t757 = getelementptr %"compiler/session:finder", ptr %t756, i32 0, i32 5
  %t758 = load { i64, [6 x i64] }, ptr %t757
  store { i64, [6 x i64] } %t758, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [6 x i64] }, ptr %rv
  ret { i64, [6 x i64] } %rr
}

define dso_local i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/session:typeFinder"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/typed:Local"
  %l17 = alloca %"compiler/session:typeFinder"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l37 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca %"compiler/source:Span"
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l79 = alloca i64
  %l81 = alloca i64
  %l86 = alloca ptr
  %l91 = alloca i1
  %l97 = alloca i1
  %l105 = alloca i64
  %l107 = alloca i64
  %l112 = alloca %"compiler/typed:Local"
  %l115 = alloca i1
  %l126 = alloca { i64, ptr }
  %l128 = alloca i1
  %l129 = alloca i1
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = call %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %s0, i64 %t1)
  store %"compiler/session:typeFinder" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"compiler/session:typeFinder", ptr %l17
  store %"compiler/session:typeFinder" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:Analysis", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cf04846f3952f731_2a54d968229bc665)
  unreachable
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/session:Analysis", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 14
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l25, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l27
  br label %bb6
bb6:
  %t24 = load i64, ptr %l25, !tbaa !24
  %t25 = load i64, ptr %l27, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l32
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l32, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp ne i64 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 11
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  store i1 %t50, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l37, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 11
  %t56 = load ptr, ptr %t55, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %s0, ptr %v0, ptr %l3, ptr %t56)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb5
bb19:
  %t63 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t64 = load i32, ptr %t63, !tbaa !23
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t68 = icmp ne i32 %t64, %t65
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t71, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/session:Analysis", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 4
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l1, !tbaa !24
  %t83 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t79, i64 %t80)
  store { i64, ptr } %t83, ptr %l54
  br label %bb23
bb23:
  %t84 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t84, ptr %l7, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = load i64, ptr %l2, !tbaa !24
  %t89 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t85, i64 %t86)
  store %"compiler/source:Span" %t89, ptr %l57
  br label %bb24
bb24:
  %t90 = load %"compiler/source:Span", ptr %l57
  store %"compiler/source:Span" %t90, ptr %l8
  %t91 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t94 = load i32, ptr %t93, !tbaa !23
  %t97 = icmp eq i32 %t92, %t94
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t99, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l62, !tbaa !27
  %t102 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t103 = load i32, ptr %t102, !tbaa !23
  %t105 = sext i32 %t103 to i64
  store i64 %t105, ptr %l64, !tbaa !24
  %t106 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l66, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l67, !tbaa !24
  %t112 = load i64, ptr %l64, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t115 = load i64, ptr %l64, !tbaa !24
  %t116 = load i64, ptr %l66, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb30:
  %t119 = load i64, ptr %l66, !tbaa !24
  %t120 = load i64, ptr %l67, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb32:
  %t123 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l64, !tbaa !24
  %t126 = load i64, ptr %l66, !tbaa !24
  %t127 = getelementptr i8, ptr %t124, i64 %t125
  %t128 = sub i64 %t126, %t125
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  store { i64, ptr } %t130, ptr %l9, !tbaa !27
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/session:Analysis", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = icmp eq ptr %t135, null
  br i1 %t137, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb34:
  call void @__olang_check_failed(ptr @olang_loc_192180e0c65a19ab_79011e5b413ec96f)
  unreachable
bb35:
  br label %bb36
bb36:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/session:Analysis", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 14
  store ptr %t145, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l11, !tbaa !24
  store i64 %t147, ptr %l79, !tbaa !24
  %t148 = load ptr, ptr %l10, !tbaa !29
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t148)
  store i64 %t150, ptr %l81
  br label %bb38
bb38:
  %t151 = load i64, ptr %l79, !tbaa !24
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = icmp slt i64 %t151, %t152
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb39, label %bb40
bb39:
  br label %bb75
bb40:
  br label %bb41
bb41:
  %t157 = load ptr, ptr %l10, !tbaa !29
  %t158 = load i64, ptr %l11, !tbaa !24
  %t161 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t157, i64 %t158)
  store ptr %t161, ptr %l86
  br label %bb42
bb42:
  %t162 = load ptr, ptr %l86, !tbaa !29
  store ptr %t162, ptr %l12, !tbaa !29
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Body", ptr %t163, i32 0, i32 3
  %t166 = load i64, ptr %t165, !tbaa !24
  %t167 = load i64, ptr %l1, !tbaa !24
  %t170 = icmp ne i64 %t166, %t167
  br i1 %t170, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb45
bb44:
  %t172 = load ptr, ptr %l12, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Body", ptr %t172, i32 0, i32 4
  %t175 = getelementptr %"compiler/source:Span", ptr %t174, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t179 = load i64, ptr %l2, !tbaa !24
  %t182 = icmp sgt i64 %t178, %t179
  store i1 %t182, ptr %l91, !tbaa !21
  br label %bb45
bb45:
  %t184 = load i1, ptr %l91, !tbaa !21
  br i1 %t184, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb48
bb47:
  %t185 = load i64, ptr %l2, !tbaa !24
  %t186 = load ptr, ptr %l12, !tbaa !29
  %t188 = getelementptr %"compiler/typed:Body", ptr %t186, i32 0, i32 4
  %t189 = getelementptr %"compiler/source:Span", ptr %t188, i32 0, i32 1
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = sext i32 %t190 to i64
  %t195 = icmp sgt i64 %t185, %t192
  store i1 %t195, ptr %l97, !tbaa !21
  br label %bb48
bb48:
  %t197 = load i1, ptr %l97, !tbaa !21
  br i1 %t197, label %bb49, label %bb50
bb49:
  br label %bb74
bb50:
  br label %bb51
bb51:
  %t198 = load ptr, ptr %l12, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Body", ptr %t198, i32 0, i32 7
  store ptr %t200, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t202 = load i64, ptr %l14, !tbaa !24
  store i64 %t202, ptr %l105, !tbaa !24
  %t203 = load ptr, ptr %l13, !tbaa !29
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l107
  br label %bb53
bb53:
  %t206 = load i64, ptr %l105, !tbaa !24
  %t207 = load i64, ptr %l107, !tbaa !24
  %t208 = icmp slt i64 %t206, %t207
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb55:
  br label %bb56
bb56:
  %t212 = load ptr, ptr %l13, !tbaa !29
  %t213 = load i64, ptr %l14, !tbaa !24
  %t216 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t212, i64 %t213)
  store %"compiler/typed:Local" %t216, ptr %l112
  br label %bb57
bb57:
  %t217 = load %"compiler/typed:Local", ptr %l112
  store %"compiler/typed:Local" %t217, ptr %l15
  %t218 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 0
  %t219 = load i32, ptr %t218, !tbaa !23
  %t221 = icmp ne i32 %t219, 0
  br i1 %t221, label %bb58, label %bb59
bb58:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/session:Analysis", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  br i1 %t228, label %bb60, label %bb61
bb59:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb65
bb60:
  call void @__olang_check_failed(ptr @olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10)
  unreachable
bb61:
  br label %bb62
bb62:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/session:Analysis", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 0
  %t240 = load ptr, ptr %t239, !tbaa !29
  %t242 = getelementptr %"compiler/load:Loader", ptr %t240, i32 0, i32 3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 0
  %t245 = load i32, ptr %t244, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s11, ptr %t243, i32 %t245)
  store { i64, ptr } %t248, ptr %l126
  br label %bb63
bb63:
  %t249 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t252 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s11, ptr %v0, { i64, ptr } %t250, { i64, ptr } %t249)
  store i1 %t252, ptr %l128
  br label %bb64
bb64:
  %t253 = load i1, ptr %l128, !tbaa !21
  store i1 %t253, ptr %l115, !tbaa !21
  br label %bb65
bb65:
  %t254 = load i1, ptr %l115, !tbaa !21
  br i1 %t254, label %bb66, label %bb67
bb66:
  %t255 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 1
  %t256 = getelementptr %"compiler/source:Span", ptr %t255, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = sext i32 %t257 to i64
  %t260 = load i64, ptr %l2, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  store i1 %t263, ptr %l129, !tbaa !21
  br label %bb68
bb67:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb68
bb68:
  %t265 = load i1, ptr %l129, !tbaa !21
  br i1 %t265, label %bb69, label %bb70
bb69:
  %t266 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 2
  %t267 = load i32, ptr %t266, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t267, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  %t269 = load i64, ptr %l14, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l14, !tbaa !24
  br label %bb52
bb73:
  br label %bb74
bb74:
  %t273 = load i64, ptr %l11, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l11, !tbaa !24
  br label %bb37
bb75:
  %t277 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t277, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i32
  %l34 = alloca i32
  %l43 = alloca i32
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l90 = alloca ptr
  %l99 = alloca ptr
  %l105 = alloca ptr
  %l112 = alloca i32
  %l113 = alloca i32
  %l114 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l124 = alloca i32
  %l134 = alloca i32
  %l140 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l155 = alloca i1
  %l162 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l172 = alloca ptr
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l23
  br label %bb4
bb4:
  %t21 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l2, !tbaa !23
  store i32 %t30, ptr %l26, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l34
  br label %bb10
bb10:
  %t43 = load i32, ptr %l34, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_183418cbaaa3b5f3_579c8efa30db605f)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l43
  br label %bb15
bb15:
  %t60 = load i32, ptr %l43, !range !{i32 0, i32 33}
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t67 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldMembers(ptr %v0, ptr %v1, ptr %t65, ptr %t66, i32 %t67)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = icmp eq ptr %t71, null
  br i1 %t73, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_269369d36ae436b2_2e7a039021f1ff2e)
  unreachable
bb21:
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t79)
  br label %bb23
bb23:
  store i64 0, ptr %l5, !tbaa !24
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5)
  unreachable
bb25:
  br label %bb26
bb26:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l59
  br label %bb27
bb27:
  %t92 = load i64, ptr %l59, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb33
bb30:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l5, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l7, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l66, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb32
bb32:
  %t119 = load i64, ptr %l66, !tbaa !24
  store i64 %t119, ptr %l63, !tbaa !24
  br label %bb33
bb33:
  %t120 = load i64, ptr %l63, !tbaa !24
  store i64 %t120, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb100
bb36:
  br label %bb37
bb37:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l10, !tbaa !24
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  br i1 %t141, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_843b58ccd5037a60_511f1c08fd361084)
  unreachable
bb39:
  br label %bb40
bb40:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l10, !tbaa !24
  %t151 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t147, i64 %t148)
  store ptr %t151, ptr %l90
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l90, !tbaa !29
  store ptr %t152, ptr %l11, !tbaa !29
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/ast:Func", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  br i1 %t158, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb99
bb43:
  br label %bb44
bb44:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb46:
  br label %bb47
bb47:
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l99, !tbaa !29
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t173 = icmp eq ptr %t171, null
  br i1 %t173, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb49:
  br label %bb50
bb50:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  store ptr %t181, ptr %l105, !tbaa !29
  %t182 = load ptr, ptr %l3, !tbaa !29
  %t184 = icmp eq ptr %t182, null
  br i1 %t184, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb52:
  br label %bb53
bb53:
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load i64, ptr %l10, !tbaa !24
  %t194 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t190, i64 %t191)
  store i32 %t194, ptr %l112
  br label %bb54
bb54:
  %t195 = load ptr, ptr %l105, !tbaa !29
  %t196 = load i32, ptr %l112, !tbaa !23
  %t197 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t195, i32 %t196)
  store i32 %t197, ptr %l113
  br label %bb55
bb55:
  %t198 = load ptr, ptr %l99, !tbaa !29
  %t199 = load i32, ptr %l113, !tbaa !23
  %t200 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t198, i32 %t199)
  store { i64, ptr } %t200, ptr %l114
  br label %bb56
bb56:
  %t201 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t201, ptr %l115, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i32, ptr %t203, i64 0
  %t205 = load i32, ptr %t204, !tbaa !33
  store i32 %t205, ptr %l12, !tbaa !23
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb57, label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_276794097286b2ce_71d39dea21084d12)
  unreachable
bb58:
  br label %bb59
bb59:
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 2
  %t218 = load i32, ptr %l12, !tbaa !23
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t217, i32 %t218)
  store i32 %t221, ptr %l124
  br label %bb60
bb60:
  %t222 = load i32, ptr %l124, !range !{i32 0, i32 33}
  %t224 = trunc i64 20 to i32
  %t225 = icmp eq i32 %t222, %t224
  br i1 %t225, label %bb61, label %bb62
bb61:
  %t227 = load ptr, ptr %l3, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb63, label %bb64
bb62:
  br label %bb67
bb63:
  call void @__olang_check_failed(ptr @olang_loc_276794097286b2ce_71d39dea21084d12)
  unreachable
bb64:
  br label %bb65
bb65:
  %t231 = load ptr, ptr %l3, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  %t238 = load i32, ptr %l12, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t237, i32 %t238)
  store i32 %t241, ptr %l134
  br label %bb66
bb66:
  %t242 = load i32, ptr %l134, !tbaa !23
  store i32 %t242, ptr %l12, !tbaa !23
  br label %bb67
bb67:
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_883965863f350275_cecb497c93815139)
  unreachable
bb69:
  br label %bb70
bb70:
  %t247 = load ptr, ptr %l3, !tbaa !29
  %t248 = load i32, ptr %l12, !tbaa !23
  %t249 = load i32, ptr %l4, !tbaa !23
  %t253 = call i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %t247, i32 %t248, i32 %t249)
  store i1 %t253, ptr %l140
  br label %bb71
bb71:
  %t254 = load i1, ptr %l140, !tbaa !21
  %t255 = xor i1 %t254, true
  br i1 %t255, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s3)
  br label %bb99
bb73:
  br label %bb74
bb74:
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t259 = icmp eq ptr %t257, null
  br i1 %t259, label %bb75, label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_f4d7e16f2a7cbb1c_8fb96f5d8af1db38)
  unreachable
bb76:
  br label %bb77
bb77:
  %t261 = load ptr, ptr %l3, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/generic:Program", ptr %t265, i32 0, i32 0
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/load:Loader", ptr %t268, i32 0, i32 3
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t272 = load ptr, ptr %l11, !tbaa !29
  %t274 = getelementptr %"compiler/ast:Func", ptr %t272, i32 0, i32 2
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t271, i32 %t275)
  store { i64, ptr } %t278, ptr %l151
  br label %bb78
bb78:
  %t279 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t279, ptr %l13, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t282 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t280)
  store i1 %t282, ptr %l153
  br label %bb79
bb79:
  %t283 = load i1, ptr %l153, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb80, label %bb81
bb80:
  %t286 = load ptr, ptr %l3, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb82, label %bb83
bb81:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb86
bb82:
  call void @__olang_check_failed(ptr @olang_loc_1c008e98be3ff20b_924cdfead9f88757)
  unreachable
bb83:
  br label %bb84
bb84:
  %t290 = load ptr, ptr %l3, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t295 = load i64, ptr %l10, !tbaa !24
  %t298 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t294, i64 %t295)
  store i64 %t298, ptr %l162
  br label %bb85
bb85:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/session:Analysis", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/load:Loader", ptr %t302, i32 0, i32 12
  %t305 = load i64, ptr %t304, !tbaa !24
  %t306 = load i64, ptr %l162, !tbaa !24
  %t308 = icmp ne i64 %t306, %t305
  store i1 %t308, ptr %l155, !tbaa !21
  br label %bb86
bb86:
  %t310 = load i1, ptr %l155, !tbaa !21
  br i1 %t310, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s3)
  br label %bb99
bb88:
  br label %bb89
bb89:
  %t311 = load ptr, ptr %l1, !tbaa !29
  store ptr %t311, ptr %l167, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t312, ptr %l168, !tbaa !27
  %t313 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  store i64 %t313, ptr %l169, !tbaa !24
  %t314 = load ptr, ptr %l3, !tbaa !29
  %t316 = icmp eq ptr %t314, null
  br i1 %t316, label %bb90, label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_b55c87bfcca1c8bf_5b30a336320e23)
  unreachable
bb91:
  br label %bb92
bb92:
  %t318 = load ptr, ptr %l3, !tbaa !29
  store ptr %t318, ptr %l172, !tbaa !29
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/session:Analysis", ptr %t319, i32 0, i32 2
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = icmp eq ptr %t322, null
  br i1 %t324, label %bb93, label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_b55c87bfcca1c8bf_5b30a336320e23)
  unreachable
bb94:
  br label %bb95
bb95:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/session:Analysis", ptr %t326, i32 0, i32 2
  %t329 = load ptr, ptr %t328, !tbaa !29
  %t330 = load i64, ptr %l10, !tbaa !24
  %t331 = load ptr, ptr %l172, !tbaa !29
  %t334 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s3, ptr %t331, ptr %t329, i64 %t330)
  store { i64, ptr } %t334, ptr %l179
  br label %bb96
bb96:
  %t335 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  %t343 = call { i64, ptr } @compiler_2fsession_2efirstLine(ptr %s3, ptr %s3, { i64, ptr } %t341)
  store { i64, ptr } %t343, ptr %l181
  br label %bb97
bb97:
  %t344 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = extractvalue { i64, ptr } %t344, 1
  %t347 = mul i64 %t345, 1
  %t348 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t347)
  call void @llvm.memcpy.p0.p0.i64(ptr %t348, ptr %t346, i64 %t347, i1 false)
  %t349 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t348, 1
  %t351 = load ptr, ptr %l167, !tbaa !29
  %t352 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t353 = load i64, ptr %l169, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s3, ptr %t351, { i64, ptr } %t352, i64 %t353, { i64, ptr } %t350)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s3)
  br label %bb99
bb99:
  %t355 = load i64, ptr %l9, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l9, !tbaa !24
  br label %bb34
bb100:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l19 = alloca i1
  %l32 = alloca ptr
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Items", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l16
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t20, { i64, ptr } %t22)
  store i1 %t25, ptr %l19
  br label %bb7
bb7:
  %t26 = load i1, ptr %l19, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb1
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Items", ptr %t31, i32 0, i32 2
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = extractvalue { i64, ptr } %t34, 0
  %t38 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t36, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = extractvalue { i64, ptr } %t40, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t33, { i64, ptr } %t47)
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/session:Items", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:Items", ptr %t57, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t59, i8 44)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = getelementptr %"compiler/session:Items", ptr %t62, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  %t66 = add i64 %t64, 1
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = getelementptr %"compiler/session:Items", ptr %t68, i32 0, i32 1
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/session:Items", ptr %t70, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t72, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/session:Items", ptr %t74, i32 0, i32 0
  %t77 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v1, ptr %t76, { i64, ptr } %t77)
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/session:Items", ptr %t80, i32 0, i32 0
  %t84 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t87 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t88 = add i64 %t85, %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = getelementptr i8, ptr %t89, i64 %t85
  %t91 = call i64 @__olang_fmt_i64(ptr %t90, i64 %a2)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t89, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t96 = extractvalue { i64, ptr } %t93, 1
  %t97 = mul i64 %t95, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t96, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t82, { i64, ptr } %t100)
  br label %bb20
bb20:
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t105, ptr %l46
  br label %bb21
bb21:
  %t106 = load i1, ptr %l46, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s8
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/session:Items", ptr %t109, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t111, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/session:Items", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v0, ptr %v2, ptr %t115, { i64, ptr } %t116)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s8)
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/session:Items", ptr %t119, i32 0, i32 0
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t121, i8 125)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eOffset(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l21 = alloca { i64, ptr }
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l49 = alloca i64
  %l58 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l88 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/session:Positions", ptr %t7, i32 0, i32 2
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp sge i64 %t6, %t12
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/session:Positions", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Positions", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i32, ptr %t31, i64 %t28
  %t33 = load i32, ptr %t32, !tbaa !33
  %t35 = sext i32 %t33 to i64
  store i64 %t35, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = add i64 %t37, 1
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/session:Positions", ptr %t40, i32 0, i32 2
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp slt i64 %t39, %t45
  br i1 %t48, label %bb7, label %bb8
bb7:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/session:Positions", ptr %t50, i32 0, i32 2
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l33, !tbaa !27
  %t54 = load i64, ptr %l1, !tbaa !24
  %t56 = add i64 %t54, 1
  %t58 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t63 = sext i32 %t61 to i64
  %t65 = sub i64 %t63, 1
  store i64 %t65, ptr %l31, !tbaa !24
  br label %bb9
bb8:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/session:Positions", ptr %t67, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l31, !tbaa !24
  br label %bb9
bb9:
  %t74 = load i64, ptr %l31, !tbaa !24
  store i64 %t74, ptr %l4, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/session:Positions", ptr %t75, i32 0, i32 1
  %t78 = load i1, ptr %t77, !tbaa !21
  br i1 %t78, label %bb10, label %bb11
bb10:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = icmp sle i64 %t84, %t85
  br i1 %t88, label %bb12, label %bb13
bb11:
  br label %bb15
bb12:
  %t90 = load i64, ptr %l3, !tbaa !24
  %t91 = load i64, ptr %l2, !tbaa !24
  %t94 = add i64 %t90, %t91
  store i64 %t94, ptr %l49, !tbaa !24
  br label %bb14
bb13:
  %t96 = load i64, ptr %l4, !tbaa !24
  store i64 %t96, ptr %l49, !tbaa !24
  br label %bb14
bb14:
  %t98 = load i64, ptr %l49, !tbaa !24
  store i64 %t98, ptr %rv
  br label %ret
bb15:
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t101 = load i64, ptr %l5, !tbaa !24
  %t102 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  br i1 %t105, label %bb17, label %bb18
bb17:
  %t107 = load i64, ptr %l6, !tbaa !24
  %t108 = load i64, ptr %l2, !tbaa !24
  %t111 = icmp slt i64 %t107, %t108
  store i1 %t111, ptr %l58, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l58, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb20, label %bb21
bb20:
  br label %bb36
bb21:
  br label %bb22
bb22:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/session:Positions", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  store i8 %t125, ptr %l7, !tbaa !22
  %t128 = load i8, ptr %l7, !tbaa !22
  %t130 = icmp ult i8 %t128, -64
  br i1 %t130, label %bb23, label %bb24
bb23:
  store i64 1, ptr %l70, !tbaa !24
  br label %bb31
bb24:
  %t132 = load i8, ptr %l7, !tbaa !22
  %t134 = icmp ult i8 %t132, -32
  br i1 %t134, label %bb25, label %bb26
bb25:
  store i64 2, ptr %l73, !tbaa !24
  br label %bb30
bb26:
  %t136 = load i8, ptr %l7, !tbaa !22
  %t138 = icmp ult i8 %t136, -16
  br i1 %t138, label %bb27, label %bb28
bb27:
  store i64 3, ptr %l76, !tbaa !24
  br label %bb29
bb28:
  store i64 4, ptr %l76, !tbaa !24
  br label %bb29
bb29:
  %t140 = load i64, ptr %l76, !tbaa !24
  store i64 %t140, ptr %l73, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l73, !tbaa !24
  store i64 %t141, ptr %l70, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l70, !tbaa !24
  store i64 %t142, ptr %l8, !tbaa !24
  %t143 = load i64, ptr %l6, !tbaa !24
  store i64 %t143, ptr %l77, !tbaa !24
  %t144 = load i64, ptr %l8, !tbaa !24
  %t146 = icmp eq i64 %t144, 4
  br i1 %t146, label %bb32, label %bb33
bb32:
  store i64 2, ptr %l80, !tbaa !24
  br label %bb34
bb33:
  store i64 1, ptr %l80, !tbaa !24
  br label %bb34
bb34:
  %t148 = load i64, ptr %l77, !tbaa !24
  %t149 = load i64, ptr %l80, !tbaa !24
  %t150 = add i64 %t148, %t149
  store i64 %t150, ptr %l6, !tbaa !24
  %t152 = load i64, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l8, !tbaa !24
  %t156 = add i64 %t152, %t153
  store i64 %t156, ptr %l5, !tbaa !24
  br label %bb35
bb35:
  br label %bb16
bb36:
  %t158 = load i64, ptr %l5, !tbaa !24
  %t159 = load i64, ptr %l4, !tbaa !24
  %t162 = icmp sle i64 %t158, %t159
  br i1 %t162, label %bb37, label %bb38
bb37:
  %t164 = load i64, ptr %l5, !tbaa !24
  store i64 %t164, ptr %l88, !tbaa !24
  br label %bb39
bb38:
  %t166 = load i64, ptr %l4, !tbaa !24
  store i64 %t166, ptr %l88, !tbaa !24
  br label %bb39
bb39:
  %t168 = load i64, ptr %l88, !tbaa !24
  store i64 %t168, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l32 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l53 = alloca i64
  %l58 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t12 = icmp sgt i64 %t3, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/session:Positions", ptr %t14, i32 0, i32 0
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/session:Positions", ptr %t25, i32 0, i32 2
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l4, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = add i64 %t46, 1
  %t50 = sdiv i64 %t48, 2
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/session:Positions", ptr %t52, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l32, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  %t63 = sext i32 %t61 to i64
  %t64 = load i64, ptr %l2, !tbaa !24
  %t67 = icmp sle i64 %t63, %t64
  br i1 %t67, label %bb11, label %bb12
bb11:
  %t69 = load i64, ptr %l5, !tbaa !24
  store i64 %t69, ptr %l3, !tbaa !24
  br label %bb13
bb12:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb7
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/session:Positions", ptr %t75, i32 0, i32 2
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l42, !tbaa !27
  %t79 = load i64, ptr %l3, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i32, ptr %t82, i64 %t79
  %t84 = load i32, ptr %t83, !tbaa !33
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l6, !tbaa !24
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/session:Positions", ptr %t88, i32 0, i32 1
  %t91 = load i1, ptr %t90, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  %t93 = load i64, ptr %l3, !tbaa !24
  %t94 = load i64, ptr %l2, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t100 = insertvalue { i64, i64 } undef, i64 %t93, 0
  %t102 = insertvalue { i64, i64 } %t100, i64 %t98, 1
  store { i64, i64 } %t102, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t104 = load i64, ptr %l3, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/session:Positions", ptr %t105, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l2, !tbaa !24
  %t114 = call i64 @compiler_2fsession_2eutf16Units(ptr %v0, { i64, ptr } %t108, i64 %t109, i64 %t110)
  store i64 %t114, ptr %l58
  br label %bb19
bb19:
  %t115 = load i64, ptr %l53, !tbaa !24
  %t116 = insertvalue { i64, i64 } undef, i64 %t115, 0
  %t117 = load i64, ptr %l58, !tbaa !24
  %t118 = insertvalue { i64, i64 } %t116, i64 %t117, 1
  store { i64, i64 } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64 }
  %l12 = alloca { i64, i64 }
  %l17 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %t1, i64 %a2)
  store { i64, i64 } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l12
  store { i64, i64 } %t6, ptr %l4
  %t7 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t10 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aPositions_2ePos(ptr %v0, ptr %t13, i64 %a3)
  store { i64, i64 } %t17, ptr %l17
  br label %bb2
bb2:
  %t18 = load { i64, i64 }, ptr %l17
  store { i64, i64 } %t18, ptr %l7
  %t19 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t33 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t34 = add i64 %t31, %t33
  %t35 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = call i64 @__olang_fmt_i64(ptr null, i64 %t27)
  %t40 = add i64 %t37, %t39
  %t41 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = call i64 @__olang_fmt_i64(ptr null, i64 %t23)
  %t52 = add i64 %t49, %t51
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t30, i64 %t31)
  %t57 = getelementptr i8, ptr %t56, i64 %t31
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t26)
  %t59 = getelementptr i8, ptr %t57, i64 %t33
  call void @olang_textcopy(ptr %t59, ptr %t35, i64 %t36)
  %t60 = getelementptr i8, ptr %t59, i64 %t36
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t27)
  %t62 = getelementptr i8, ptr %t60, i64 %t39
  call void @olang_textcopy(ptr %t62, ptr %t41, i64 %t42)
  %t63 = getelementptr i8, ptr %t62, i64 %t42
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t20)
  %t65 = getelementptr i8, ptr %t63, i64 %t45
  call void @olang_textcopy(ptr %t65, ptr %t47, i64 %t48)
  %t66 = getelementptr i8, ptr %t65, i64 %t48
  %t67 = call i64 @__olang_fmt_i64(ptr %t66, i64 %t23)
  %t68 = getelementptr i8, ptr %t66, i64 %t51
  call void @olang_textcopy(ptr %t68, ptr %t53, i64 %t54)
  %t69 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t56, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %a1, { i64, ptr } %t77)
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca [65536 x i8]
  %l2 = alloca i64
  %l3 = alloca [65536 x i8]
  %l7 = alloca [65536 x i8]
  %l10 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 65536
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [65536 x i8], ptr %l3, i64 0, i64 %t5
  store i8 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %l3, i64 65536, i1 false)
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/session:Reader", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l1, i64 65536, i1 false)
  %t13 = load [65536 x i8], ptr %l7
  %t18 = call i64 @read(i32 %t12, ptr %l1, i64 65536)
  store i64 %t18, ptr %l10
  br label %bb1
bb1:
  %t19 = load i64, ptr %l10, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp sle i64 %t20, 0
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Reader", ptr %t24, i32 0, i32 2
  store i1 true, ptr %t26, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/session:Reader", ptr %t28, i32 0, i32 1
  store ptr %t30, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l17, !tbaa !24
  %t32 = load [65536 x i8], ptr %l1
  store i64 65536, ptr %l18, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb7:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l18, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb9:
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = getelementptr i8, ptr %l1, i64 0
  %t44 = sub i64 %t42, 0
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t47 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t46)
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"std/prelude/text:LineIter"
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca i64
  %l91 = alloca i32
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = add i64 %t11, 3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l21, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 13
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb5:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l26, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 10
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l25, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 2
  %t47 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t52 = icmp eq i8 %t50, 13
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 3
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp eq i8 %t63, 10
  store i1 %t65, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l37, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l20, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = add i64 %t77, 3
  %t80 = load i64, ptr %l2, !tbaa !24
  %t83 = icmp sge i64 %t79, %t80
  br i1 %t83, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t86 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t86, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l52, !tbaa !27
  %t88 = load i64, ptr %l3, !tbaa !24
  store i64 %t88, ptr %l53, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l54, !tbaa !24
  %t91 = icmp sge i64 0, 0
  br i1 %t91, label %bb23, label %bb24
bb23:
  %t93 = load i64, ptr %l53, !tbaa !24
  %t94 = icmp sle i64 0, %t93
  br i1 %t94, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb25:
  %t96 = load i64, ptr %l53, !tbaa !24
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb27:
  %t100 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l53, !tbaa !24
  %t103 = getelementptr i8, ptr %t101, i64 0
  %t104 = sub i64 %t102, 0
  %t105 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  store { i64, ptr } %t106, ptr %l59, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l60, !tbaa !24
  %t110 = load i64, ptr %l60, !tbaa !24
  %t111 = mul i64 %t110, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  %t113 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  store { i64, ptr } %t114, ptr %l61, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = load i64, ptr %l60, !tbaa !24
  %t120 = mul i64 %t119, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t116, ptr %t118, i64 %t120, i1 false)
  %t121 = load { i64, ptr }, ptr %l61, !tbaa !27
  store i64 -1, ptr %l5, !tbaa !24
  %t125 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t121)
  store %"std/prelude/text:LineIter" %t125, ptr %l64
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb29:
  %t126 = load %"std/prelude/text:LineIter", ptr %l64
  store %"std/prelude/text:LineIter" %t126, ptr %l6
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l6)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l68
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb32, label %ok.132, !prof !99
ok.132:
  store { i64, ptr } %t129, ptr %l67
  br label %bb31
bb31:
  %t133 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t133, ptr %l65, !tbaa !27
  br label %bb34
bb32:
  %t134 = load i32, ptr %l68, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  store i1 %t137, ptr %l70, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb34:
  %t138 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t141 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l72
  br label %bb35
bb35:
  %t142 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t142, ptr %l8, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %s0, ptr %s4, { i64, ptr } %t143)
  store { i64, ptr } %t145, ptr %l74
  br label %bb36
bb36:
  %t146 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t152, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t154, ptr %l76
  br label %bb37
bb37:
  %t155 = load i1, ptr %l76, !tbaa !21
  br i1 %t155, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t156, ptr %l78, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t157, 0
  store i64 %t160, ptr %l81, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  store i64 %t162, ptr %l82, !tbaa !24
  %t163 = icmp sge i64 15, 0
  br i1 %t163, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = icmp sle i64 15, %t165
  br i1 %t166, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb42:
  %t168 = load i64, ptr %l81, !tbaa !24
  %t169 = load i64, ptr %l82, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb44:
  %t172 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l81, !tbaa !24
  %t175 = getelementptr i8, ptr %t173, i64 15
  %t176 = sub i64 %t174, 15
  %t177 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s5, { i64, ptr } %t178)
  store { i64, ptr } %t180, ptr %l87
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb46:
  %t181 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 10)
  %t182 = extractvalue { i32, i64 } %t181, 1
  %t183 = extractvalue { i32, i64 } %t181, 0
  store i32 %t183, ptr %l89
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb48, label %ok.185, !prof !99
ok.185:
  store i64 %t182, ptr %l88
  br label %bb47
bb47:
  %t186 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t187 = load i64, ptr %l88, !tbaa !24
  %t188 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s5, { i64, ptr } %t186, i64 %t187)
  %t189 = extractvalue { i32, i64 } %t188, 1
  %t190 = extractvalue { i32, i64 } %t188, 0
  store i32 %t190, ptr %l91
  %t191 = icmp ne i32 %t190, 0
  br i1 %t191, label %bb51, label %ok.192, !prof !99
ok.192:
  store i64 %t189, ptr %l90
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l77, !tbaa !24
  br label %bb52
bb50:
  %t193 = load i64, ptr %l90, !tbaa !24
  store i64 %t193, ptr %l77, !tbaa !24
  br label %bb52
bb51:
  br label %bb49
bb52:
  %t194 = load i64, ptr %l77, !tbaa !24
  store i64 %t194, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  br label %bb30
bb55:
  %t195 = load i64, ptr %l3, !tbaa !24
  %t197 = add i64 %t195, 4
  store i64 %t197, ptr %l9, !tbaa !24
  %t199 = load i64, ptr %l5, !tbaa !24
  %t201 = icmp slt i64 %t199, 0
  br i1 %t201, label %bb56, label %bb57
bb56:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t203, i64 %t204)
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t208 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t208, ptr %rv
  br label %ret
bb59:
  %t209 = load i64, ptr %l2, !tbaa !24
  %t210 = load i64, ptr %l9, !tbaa !24
  %t211 = load i64, ptr %l5, !tbaa !24
  %t214 = add i64 %t210, %t211
  %t217 = icmp slt i64 %t209, %t214
  br i1 %t217, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t220 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t220, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t221 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t221, ptr %l105, !tbaa !27
  %t222 = load i64, ptr %l9, !tbaa !24
  store i64 %t222, ptr %l106, !tbaa !24
  %t223 = load i64, ptr %l9, !tbaa !24
  %t224 = load i64, ptr %l5, !tbaa !24
  %t227 = add i64 %t223, %t224
  store i64 %t227, ptr %l109, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l110, !tbaa !24
  %t230 = load i64, ptr %l106, !tbaa !24
  %t231 = icmp sge i64 %t230, 0
  br i1 %t231, label %bb63, label %bb64
bb63:
  %t233 = load i64, ptr %l106, !tbaa !24
  %t234 = load i64, ptr %l109, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb65:
  %t237 = load i64, ptr %l109, !tbaa !24
  %t238 = load i64, ptr %l110, !tbaa !24
  %t239 = icmp sle i64 %t237, %t238
  br i1 %t239, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb67:
  %t241 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = load i64, ptr %l106, !tbaa !24
  %t244 = load i64, ptr %l109, !tbaa !24
  %t245 = getelementptr i8, ptr %t242, i64 %t243
  %t246 = sub i64 %t244, %t243
  %t247 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  store { i64, ptr } %t248, ptr %l115, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  store i64 %t251, ptr %l116, !tbaa !24
  %t252 = load i64, ptr %l116, !tbaa !24
  %t253 = mul i64 %t252, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l117, !tbaa !27
  %t257 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = load i64, ptr %l116, !tbaa !24
  %t262 = mul i64 %t261, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t258, ptr %t260, i64 %t262, i1 false)
  %t263 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t265, i64 %t266)
  %t268 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t270, ptr %lp10
  %t272 = load ptr, ptr %lp10
  store { i64, ptr } %t269, ptr %t272, !tbaa !27
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i64, ptr %l9, !tbaa !24
  %t275 = load i64, ptr %l5, !tbaa !24
  %t278 = add i64 %t274, %t275
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t273, i64 %t278)
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb69:
  %t281 = load ptr, ptr %lp10
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t284 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t282, 1
  store { i32, { i64, ptr } } %t284, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp ne i8 %t23, 10
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l14, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb2
bb10:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  %t38 = icmp sge i64 %t34, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp sgt i64 %t42, 0
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t46 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = sub i64 %t47, 1
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t56 = icmp eq i8 %t54, 13
  store i1 %t56, ptr %l28, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t58 = load i1, ptr %l28, !tbaa !21
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = sub i64 %t59, 1
  store i64 %t61, ptr %l34, !tbaa !24
  br label %bb19
bb18:
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l34, !tbaa !24
  br label %bb19
bb19:
  %t65 = load i64, ptr %l34, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t66, ptr %l38, !tbaa !27
  store i64 %t65, ptr %l39, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l40, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l39, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb22:
  %t75 = load i64, ptr %l39, !tbaa !24
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l39, !tbaa !24
  %t82 = getelementptr i8, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l45, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l46, !tbaa !24
  %t89 = load i64, ptr %l46, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l47, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l46, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = extractvalue { i64, ptr } %t100, 0
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t102, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t107, ptr %lp5
  %t109 = load ptr, ptr %lp5
  store { i64, ptr } %t106, ptr %t109, !tbaa !27
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = add i64 %t111, 1
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t110, i64 %t113)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb26:
  %t116 = load ptr, ptr %lp5
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t117, 1
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l39 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca i8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l20, !tbaa !24
  store i64 %t37, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l17, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:Reader", ptr %t57, i32 0, i32 1
  store ptr %t59, ptr %l39, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = sub i64 %t60, %t61
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/session:Reader", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = call i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %t67, i64 %t68)
  store i8 %t71, ptr %l46
  br label %bb12
bb12:
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i8, ptr %l46, !tbaa !22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %t72, i64 %t73, i8 %t74)
  br label %bb13
bb13:
  br label %bb14
bb14:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l7, !tbaa !24
  br label %bb8
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/session:Reader", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %l2, !tbaa !24
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = sub i64 %t82, %t83
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %t81, i64 %t86)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ebodyCallee(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l14 = alloca i64
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l36 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l51 = alloca i64
  %l65 = alloca i32
  %l74 = alloca i32
  %l79 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca %"compiler/source:Span"
  %l96 = alloca i64
  %s1 = alloca %olang.scope
  %t86 = alloca { i64, [6 x i64] }, align 8
  %t125 = alloca { i64, [6 x i64] }, align 8
  %t246 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb18
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/session:finder", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l14
  br label %bb4
bb4:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/session:finder", ptr %t22, i32 0, i32 3
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/load:Loader", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/session:finder", ptr %t35, i32 0, i32 3
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l24
  br label %bb5
bb5:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Func", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t50 = load ptr, ptr %l19, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t50, i32 %t49)
  store { i64, ptr } %t52, ptr %l27
  br label %bb6
bb6:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/session:finder", ptr %t53, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t57, { i64, ptr } %t56)
  store i1 %t59, ptr %l30
  br label %bb7
bb7:
  %t60 = load i1, ptr %l30, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/session:finder", ptr %t63, i32 0, i32 3
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store ptr %t73, ptr %l36
  br label %bb11
bb11:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb12, label %bb13
bb12:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i64, ptr %l4, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [6 x i64] }, ptr %t86, i32 0, i32 0
  store i64 2, ptr %t87
  %t89 = insertvalue { i64 } undef, i64 %t85, 0
  %t90 = getelementptr { i64, [6 x i64] }, ptr %t86, i32 0, i32 1
  store { i64 } %t89, ptr %t90
  %t91 = load { i64, [6 x i64] }, ptr %t86
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t83, %"compiler/source:Span" %t84, { i64, [6 x i64] } %t91)
  br label %bb14
bb13:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l45, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t96, ptr %l46
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/session:finder", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t104 = load i64, ptr %l4, !tbaa !24
  %t107 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t103, i64 %t104)
  store i64 %t107, ptr %l51
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/session:finder", ptr %t108, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = extractvalue { i64, ptr } %t111, 0
  %t115 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t113, i64 %t114)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = extractvalue { i64, ptr } %t117, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [6 x i64] }, ptr %t125, i32 0, i32 0
  store i64 1, ptr %t126
  %t127 = load i64, ptr %l51, !tbaa !24
  %t128 = insertvalue { i64, { i64, ptr } } undef, i64 %t127, 0
  %t130 = insertvalue { i64, { i64, ptr } } %t128, { i64, ptr } %t124, 1
  %t131 = getelementptr { i64, [6 x i64] }, ptr %t125, i32 0, i32 1
  store { i64, { i64, ptr } } %t130, ptr %t131
  %t132 = load { i64, [6 x i64] }, ptr %t125
  %t133 = load ptr, ptr %l45, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t133, %"compiler/source:Span" %t134, { i64, [6 x i64] } %t132)
  br label %bb16
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %bb40
bb18:
  %t136 = load { i64, [2 x i64] }, ptr %l2
  %t138 = extractvalue { i64, [2 x i64] } %t136, 0
  %t139 = icmp eq i64 %t138, 1
  br i1 %t139, label %bb19, label %bb20
bb19:
  %t141 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t142 = getelementptr { i32, i32 }, ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142
  store i32 %t143, ptr %l5, !tbaa !23
  br label %bb21
bb20:
  br label %bb35
bb21:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/session:finder", ptr %t145, i32 0, i32 3
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l5, !tbaa !23
  %t157 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t153, i32 %t154)
  store i32 %t157, ptr %l65
  br label %bb22
bb22:
  %t158 = load i32, ptr %l65, !range !{i32 0, i32 33}
  %t160 = trunc i64 18 to i32
  %t161 = icmp eq i32 %t158, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/session:finder", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 2
  %t174 = load i32, ptr %l5, !tbaa !23
  %t177 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t177, ptr %l74
  br label %bb26
bb26:
  %t178 = load i32, ptr %l74, !tbaa !23
  store i32 %t178, ptr %l6, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/session:finder", ptr %t179, i32 0, i32 3
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t187 = getelementptr %"compiler/generic:Program", ptr %t185, i32 0, i32 0
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/load:Loader", ptr %t188, i32 0, i32 3
  %t191 = load ptr, ptr %t190, !tbaa !29
  store ptr %t191, ptr %l79, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/session:finder", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l6, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l85
  br label %bb27
bb27:
  %t205 = load ptr, ptr %l79, !tbaa !29
  %t206 = load i32, ptr %l85, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t205, i32 %t206)
  store { i64, ptr } %t207, ptr %l86
  br label %bb28
bb28:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/session:finder", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t212, { i64, ptr } %t211)
  store i1 %t214, ptr %l89
  br label %bb29
bb29:
  %t215 = load i1, ptr %l89, !tbaa !21
  br i1 %t215, label %bb30, label %bb31
bb30:
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l90, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t217, ptr %l91
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/session:finder", ptr %t218, i32 0, i32 3
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = getelementptr %"compiler/check:Checker", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t225 = load i32, ptr %l6, !tbaa !23
  %t228 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t224, i32 %t225)
  store i64 %t228, ptr %l96
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/session:finder", ptr %t229, i32 0, i32 2
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 1
  %t235 = extractvalue { i64, ptr } %t232, 0
  %t236 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t234, i64 %t235)
  %t237 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } %t238, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t246
  %t247 = getelementptr { i64, [6 x i64] }, ptr %t246, i32 0, i32 0
  store i64 1, ptr %t247
  %t248 = load i64, ptr %l96, !tbaa !24
  %t249 = insertvalue { i64, { i64, ptr } } undef, i64 %t248, 0
  %t251 = insertvalue { i64, { i64, ptr } } %t249, { i64, ptr } %t245, 1
  %t252 = getelementptr { i64, [6 x i64] }, ptr %t246, i32 0, i32 1
  store { i64, { i64, ptr } } %t251, ptr %t252
  %t253 = load { i64, [6 x i64] }, ptr %t246
  %t254 = load ptr, ptr %l90, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l91
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t254, %"compiler/source:Span" %t255, { i64, [6 x i64] } %t253)
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_68ddcf9e12618436_cff7fbf614d16d4a)
  unreachable
bb40:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:finder", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sgt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/session:finder", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = icmp sgt i64 %t16, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 5}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { i32 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t42, ptr %l23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/session:finder", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 14
  %t49 = load i32, ptr %l3, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t48, i64 %t51)
  store ptr %t54, ptr %l29
  br label %bb12
bb12:
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 1
  %t58 = load { i64, [2 x i64] }, ptr %t57
  %t59 = load ptr, ptr %l22, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l23
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ebodyCallee(ptr %v0, ptr %t59, %"compiler/source:Span" %t60, { i64, [2 x i64] } %t58)
  br label %bb13
bb13:
  br label %bb26
bb14:
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t63 = load ptr, ptr %l32, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l32, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 5}
  %t69 = icmp eq i64 %t67, 2
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l33, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { ptr }, ptr %t73, i32 0, i32 0
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t77, ptr %t78)
  br label %bb20
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_a3421b14f56bfb72_e21214c32a246516)
  unreachable
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l120 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i1
  %l142 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l179 = alloca { i64, ptr }
  %l187 = alloca ptr
  %l188 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i1
  %l236 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l248 = alloca i1
  %l261 = alloca { i64, ptr }
  %l277 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l320 = alloca ptr
  %l328 = alloca ptr
  %l329 = alloca i1
  %l345 = alloca { i64, ptr }
  %l359 = alloca { i64, ptr }
  %l369 = alloca ptr
  %l370 = alloca i1
  %l377 = alloca ptr
  %l378 = alloca i1
  %l388 = alloca ptr
  %l389 = alloca i1
  %l403 = alloca { i64, ptr }
  %l417 = alloca ptr
  %l425 = alloca ptr
  %l426 = alloca i1
  %l434 = alloca ptr
  %l435 = alloca i1
  %l448 = alloca { i64, ptr }
  %l451 = alloca ptr
  %l452 = alloca i1
  %l462 = alloca ptr
  %l463 = alloca i1
  %s42 = alloca %olang.scope
  %t719 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t6 = load ptr, ptr %l69, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l69, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l70, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l70, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t21 = load ptr, ptr %l75, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l75, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l76, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l76, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t36 = load ptr, ptr %l81, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l81, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l82, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l82, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  br label %bb17
bb17:
  br label %bb241
bb18:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t56 = load ptr, ptr %l90, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l90, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l91, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l91, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Promote", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  br label %bb24
bb24:
  br label %bb241
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t79 = load ptr, ptr %l100, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l100, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l101, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l101, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l4
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l4
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %t99, %"compiler/source:Span" %t100, ptr %t104)
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Call", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb33, label %bb34
bb33:
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l120, !tbaa !27
  %t126 = load i64, ptr %l7, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr ptr, ptr %t129, i64 %t126
  %t131 = load ptr, ptr %t130, !tbaa !39
  %t133 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t133, ptr %t131)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l7, !tbaa !24
  br label %bb32
bb38:
  br label %bb241
bb39:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t143 = load ptr, ptr %l128, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t146 = load ptr, ptr %l128, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l129, !tbaa !21
  br label %bb41
bb41:
  %t150 = load i1, ptr %l129, !tbaa !21
  br i1 %t150, label %bb42, label %bb43
bb42:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t157 = load ptr, ptr %l10, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Make", ptr %t157, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  store i64 %t164, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t166 = load i64, ptr %l12, !tbaa !24
  %t167 = load i64, ptr %l13, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb46, label %bb47
bb46:
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t174 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t174, ptr %l142, !tbaa !27
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t182 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t182, ptr %t180)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t187 = load i64, ptr %l12, !tbaa !24
  %t189 = add i64 %t187, 1
  store i64 %t189, ptr %l12, !tbaa !24
  br label %bb45
bb51:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t194 = getelementptr %"compiler/typed:Make", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t191, ptr %t195)
  br label %bb52
bb52:
  br label %bb241
bb53:
  %t198 = load ptr, ptr %l1, !tbaa !29
  store ptr %t198, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t199 = load ptr, ptr %l153, !tbaa !29
  %t200 = icmp ne ptr %t199, null
  br i1 %t200, label %bb54, label %bb55
bb54:
  %t202 = load ptr, ptr %l153, !tbaa !29
  %t203 = load i64, ptr %t202, !range !{i64 0, i64 18}
  %t205 = icmp eq i64 %t203, 8
  store i1 %t205, ptr %l154, !tbaa !21
  br label %bb55
bb55:
  %t206 = load i1, ptr %l154, !tbaa !21
  br i1 %t206, label %bb56, label %bb57
bb56:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t207, i32 0, i32 1
  %t210 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t209, i32 0, i32 2
  %t211 = load ptr, ptr %t210
  store ptr %t211, ptr %l15, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l15, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Collect", ptr %t214, i32 0, i32 0
  %t217 = load ptr, ptr %t216, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t213, ptr %t217)
  br label %bb59
bb59:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Collect", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t220, ptr %t224)
  br label %bb60
bb60:
  br label %bb241
bb61:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t229 = load ptr, ptr %l166, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t232 = load ptr, ptr %l166, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 18}
  %t235 = icmp eq i64 %t233, 9
  store i1 %t235, ptr %l167, !tbaa !21
  br label %bb63
bb63:
  %t236 = load i1, ptr %l167, !tbaa !21
  br i1 %t236, label %bb64, label %bb65
bb64:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t239, i32 0, i32 4
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t243 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t243, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t245, 0
  store i64 %t247, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  %t249 = load i64, ptr %l18, !tbaa !24
  %t250 = load i64, ptr %l19, !tbaa !24
  %t253 = icmp slt i64 %t249, %t250
  %t255 = xor i1 %t253, true
  br i1 %t255, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t257 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t257, ptr %l179, !tbaa !27
  %t258 = load i64, ptr %l18, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  %t265 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t265, ptr %t263)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t270 = load i64, ptr %l18, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l18, !tbaa !24
  br label %bb67
bb73:
  br label %bb241
bb74:
  %t274 = load ptr, ptr %l1, !tbaa !29
  store ptr %t274, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t275 = load ptr, ptr %l187, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb75, label %bb76
bb75:
  %t278 = load ptr, ptr %l187, !tbaa !29
  %t279 = load i64, ptr %t278, !range !{i64 0, i64 18}
  %t281 = icmp eq i64 %t279, 10
  store i1 %t281, ptr %l188, !tbaa !21
  br label %bb76
bb76:
  %t282 = load i1, ptr %l188, !tbaa !21
  br i1 %t282, label %bb77, label %bb78
bb77:
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l21, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l21, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Slice", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t289, ptr %t293)
  br label %bb80
bb80:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l21, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Slice", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t297, ptr %t301)
  br label %bb81
bb81:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load ptr, ptr %l21, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Slice", ptr %t306, i32 0, i32 2
  %t309 = load ptr, ptr %t308, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t305, ptr %t309)
  br label %bb82
bb82:
  br label %bb241
bb83:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t314 = load ptr, ptr %l205, !tbaa !29
  %t315 = icmp ne ptr %t314, null
  br i1 %t315, label %bb84, label %bb85
bb84:
  %t317 = load ptr, ptr %l205, !tbaa !29
  %t318 = load i64, ptr %t317, !range !{i64 0, i64 18}
  %t320 = icmp eq i64 %t318, 11
  store i1 %t320, ptr %l206, !tbaa !21
  br label %bb85
bb85:
  %t321 = load i1, ptr %l206, !tbaa !21
  br i1 %t321, label %bb86, label %bb87
bb86:
  %t322 = load ptr, ptr %l1, !tbaa !29
  %t324 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t324, i32 0, i32 2
  %t326 = load ptr, ptr %t325
  store ptr %t326, ptr %l22, !tbaa !29
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load ptr, ptr %l22, !tbaa !29
  %t331 = getelementptr %"compiler/typed:Cond", ptr %t329, i32 0, i32 0
  %t332 = load ptr, ptr %t331, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t328, ptr %t332)
  br label %bb89
bb89:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l22, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Cond", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t336, ptr %t340)
  br label %bb90
bb90:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l22, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Cond", ptr %t344, i32 0, i32 2
  %t347 = load ptr, ptr %t346, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t343, ptr %t347)
  br label %bb91
bb91:
  br label %bb241
bb92:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t352 = load ptr, ptr %l222, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb93, label %bb94
bb93:
  %t355 = load ptr, ptr %l222, !tbaa !29
  %t356 = load i64, ptr %t355, !range !{i64 0, i64 18}
  %t358 = icmp eq i64 %t356, 12
  store i1 %t358, ptr %l223, !tbaa !21
  br label %bb94
bb94:
  %t359 = load i1, ptr %l223, !tbaa !21
  br i1 %t359, label %bb95, label %bb96
bb95:
  %t360 = load ptr, ptr %l1, !tbaa !29
  %t362 = getelementptr { i64, [5 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t362, i32 0, i32 2
  %t364 = load ptr, ptr %t363
  store ptr %t364, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb106
bb97:
  %t366 = load ptr, ptr %l23, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Seq", ptr %t366, i32 0, i32 0
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  store { i64, ptr } %t369, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t371, 0
  store i64 %t373, ptr %l26, !tbaa !24
  br label %bb98
bb98:
  %t375 = load i64, ptr %l25, !tbaa !24
  %t376 = load i64, ptr %l26, !tbaa !24
  %t379 = icmp slt i64 %t375, %t376
  %t381 = xor i1 %t379, true
  br i1 %t381, label %bb99, label %bb100
bb99:
  br label %bb104
bb100:
  br label %bb101
bb101:
  %t383 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t383, ptr %l236, !tbaa !27
  %t384 = load i64, ptr %l25, !tbaa !24
  %t386 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = getelementptr ptr, ptr %t387, i64 %t384
  %t389 = load ptr, ptr %t388, !tbaa !39
  %t391 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %t391, ptr %t389)
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t396 = load i64, ptr %l25, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l25, !tbaa !24
  br label %bb98
bb104:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t401 = load ptr, ptr %l23, !tbaa !29
  %t403 = getelementptr %"compiler/typed:Seq", ptr %t401, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t400, ptr %t404)
  br label %bb105
bb105:
  br label %bb241
bb106:
  %t407 = load ptr, ptr %l1, !tbaa !29
  store ptr %t407, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t408 = load ptr, ptr %l247, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb107, label %bb108
bb107:
  %t411 = load ptr, ptr %l247, !tbaa !29
  %t412 = load i64, ptr %t411, !range !{i64 0, i64 18}
  %t414 = icmp eq i64 %t412, 13
  store i1 %t414, ptr %l248, !tbaa !21
  br label %bb108
bb108:
  %t415 = load i1, ptr %l248, !tbaa !21
  br i1 %t415, label %bb109, label %bb110
bb109:
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t418, i32 0, i32 2
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l28, !tbaa !29
  br label %bb111
bb110:
  br label %bb146
bb111:
  %t422 = load ptr, ptr %l28, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Match", ptr %t422, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  store { i64, ptr } %t425, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t427 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t427, 0
  store i64 %t429, ptr %l31, !tbaa !24
  br label %bb112
bb112:
  %t431 = load i64, ptr %l30, !tbaa !24
  %t432 = load i64, ptr %l31, !tbaa !24
  %t435 = icmp slt i64 %t431, %t432
  %t437 = xor i1 %t435, true
  br i1 %t437, label %bb113, label %bb114
bb113:
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t439 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t439, ptr %l261, !tbaa !27
  %t440 = load i64, ptr %l30, !tbaa !24
  %t442 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr ptr, ptr %t443, i64 %t440
  %t445 = load ptr, ptr %t444, !tbaa !39
  %t447 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %t447, ptr %t445)
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t452 = load i64, ptr %l30, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l30, !tbaa !24
  br label %bb112
bb118:
  %t456 = load ptr, ptr %l28, !tbaa !29
  %t458 = getelementptr %"compiler/typed:Match", ptr %t456, i32 0, i32 1
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  store { i64, ptr } %t459, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t461 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t461, 0
  store i64 %t463, ptr %l35, !tbaa !24
  br label %bb119
bb119:
  %t465 = load i64, ptr %l34, !tbaa !24
  %t466 = load i64, ptr %l35, !tbaa !24
  %t469 = icmp slt i64 %t465, %t466
  %t471 = xor i1 %t469, true
  br i1 %t471, label %bb120, label %bb121
bb120:
  br label %bb134
bb121:
  br label %bb122
bb122:
  %t473 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t473, ptr %l277, !tbaa !27
  %t474 = load i64, ptr %l34, !tbaa !24
  %t476 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = getelementptr ptr, ptr %t477, i64 %t474
  %t479 = load ptr, ptr %t478, !tbaa !39
  store ptr %t479, ptr %l36, !tbaa !29
  %t481 = load ptr, ptr %l36, !tbaa !29
  %t483 = getelementptr %"compiler/typed:Arm", ptr %t481, i32 0, i32 1
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t486, 0
  store i64 %t488, ptr %l39, !tbaa !24
  br label %bb123
bb123:
  %t490 = load i64, ptr %l38, !tbaa !24
  %t491 = load i64, ptr %l39, !tbaa !24
  %t494 = icmp slt i64 %t490, %t491
  %t496 = xor i1 %t494, true
  br i1 %t496, label %bb124, label %bb125
bb124:
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t498 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t498, ptr %l288, !tbaa !27
  %t499 = load i64, ptr %l38, !tbaa !24
  %t501 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = getelementptr ptr, ptr %t502, i64 %t499
  %t504 = load ptr, ptr %t503, !tbaa !39
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/typed:Alt", ptr %t504, i32 0, i32 0
  %t510 = load ptr, ptr %t509, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t510)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t514 = load i64, ptr %l38, !tbaa !24
  %t516 = add i64 %t514, 1
  store i64 %t516, ptr %l38, !tbaa !24
  br label %bb123
bb129:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load ptr, ptr %l36, !tbaa !29
  %t521 = getelementptr %"compiler/typed:Arm", ptr %t519, i32 0, i32 2
  %t522 = load ptr, ptr %t521, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t518, ptr %t522)
  br label %bb130
bb130:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l36, !tbaa !29
  %t528 = getelementptr %"compiler/typed:Arm", ptr %t526, i32 0, i32 3
  %t529 = load ptr, ptr %t528, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t525, ptr %t529)
  br label %bb131
bb131:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load ptr, ptr %l36, !tbaa !29
  %t535 = getelementptr %"compiler/typed:Arm", ptr %t533, i32 0, i32 4
  %t536 = load ptr, ptr %t535, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t532, ptr %t536)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t539 = load i64, ptr %l34, !tbaa !24
  %t541 = add i64 %t539, 1
  store i64 %t541, ptr %l34, !tbaa !24
  br label %bb119
bb134:
  %t543 = load ptr, ptr %l28, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Match", ptr %t543, i32 0, i32 2
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  %t550 = xor i1 %t548, true
  br i1 %t550, label %bb135, label %bb136
bb135:
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l312, !tbaa !29
  %t553 = load ptr, ptr %l28, !tbaa !29
  %t555 = getelementptr %"compiler/typed:Match", ptr %t553, i32 0, i32 2
  %t556 = load ptr, ptr %t555, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb137, label %bb138
bb136:
  br label %bb145
bb137:
  call void @__olang_check_failed(ptr @olang_loc_6c2d06947719abd6_25c6135ab70ee42)
  unreachable
bb138:
  br label %bb139
bb139:
  %t560 = load ptr, ptr %l28, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Match", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Arm", ptr %t563, i32 0, i32 3
  %t567 = load ptr, ptr %t566, !tbaa !29
  %t568 = load ptr, ptr %l312, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t568, ptr %t567)
  br label %bb140
bb140:
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l320, !tbaa !29
  %t571 = load ptr, ptr %l28, !tbaa !29
  %t573 = getelementptr %"compiler/typed:Match", ptr %t571, i32 0, i32 2
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = icmp eq ptr %t574, null
  br i1 %t576, label %bb141, label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_a4411270f97f17bd_30632737f0d2da29)
  unreachable
bb142:
  br label %bb143
bb143:
  %t578 = load ptr, ptr %l28, !tbaa !29
  %t580 = getelementptr %"compiler/typed:Match", ptr %t578, i32 0, i32 2
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t584 = getelementptr %"compiler/typed:Arm", ptr %t581, i32 0, i32 4
  %t585 = load ptr, ptr %t584, !tbaa !29
  %t586 = load ptr, ptr %l320, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t586, ptr %t585)
  br label %bb144
bb144:
  br label %bb145
bb145:
  br label %bb241
bb146:
  %t588 = load ptr, ptr %l1, !tbaa !29
  store ptr %t588, ptr %l328, !tbaa !29
  store i1 false, ptr %l329, !tbaa !21
  %t589 = load ptr, ptr %l328, !tbaa !29
  %t590 = icmp ne ptr %t589, null
  br i1 %t590, label %bb147, label %bb148
bb147:
  %t592 = load ptr, ptr %l328, !tbaa !29
  %t593 = load i64, ptr %t592, !range !{i64 0, i64 18}
  %t595 = icmp eq i64 %t593, 14
  store i1 %t595, ptr %l329, !tbaa !21
  br label %bb148
bb148:
  %t596 = load i1, ptr %l329, !tbaa !21
  br i1 %t596, label %bb149, label %bb150
bb149:
  %t597 = load ptr, ptr %l1, !tbaa !29
  %t599 = getelementptr { i64, [5 x i64] }, ptr %t597, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t599, i32 0, i32 2
  %t601 = load ptr, ptr %t600
  store ptr %t601, ptr %l41, !tbaa !29
  br label %bb151
bb150:
  br label %bb167
bb151:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l41, !tbaa !29
  %t606 = getelementptr %"compiler/typed:Try", ptr %t604, i32 0, i32 0
  %t607 = load ptr, ptr %t606, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t603, ptr %t607)
  br label %bb152
bb152:
  %t610 = load ptr, ptr %l41, !tbaa !29
  %t612 = getelementptr %"compiler/typed:Try", ptr %t610, i32 0, i32 1
  %t613 = load { i64, ptr }, ptr %t612, !tbaa !27
  store { i64, ptr } %t613, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t615 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t615, 0
  store i64 %t617, ptr %l44, !tbaa !24
  br label %bb153
bb153:
  %t619 = load i64, ptr %l43, !tbaa !24
  %t620 = load i64, ptr %l44, !tbaa !24
  %t623 = icmp slt i64 %t619, %t620
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb154, label %bb155
bb154:
  br label %bb166
bb155:
  br label %bb156
bb156:
  %t627 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t627, ptr %l345, !tbaa !27
  %t628 = load i64, ptr %l43, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr ptr, ptr %t631, i64 %t628
  %t633 = load ptr, ptr %t632, !tbaa !39
  store ptr %t633, ptr %l45, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load ptr, ptr %l45, !tbaa !29
  %t638 = getelementptr %"compiler/typed:Clause", ptr %t636, i32 0, i32 3
  %t639 = load ptr, ptr %t638, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t635, ptr %t639)
  br label %bb157
bb157:
  %t642 = load ptr, ptr %l45, !tbaa !29
  %t644 = getelementptr %"compiler/typed:Clause", ptr %t642, i32 0, i32 4
  %t645 = load { i64, ptr }, ptr %t644, !tbaa !27
  store { i64, ptr } %t645, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t647 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t649 = extractvalue { i64, ptr } %t647, 0
  store i64 %t649, ptr %l48, !tbaa !24
  br label %bb158
bb158:
  %t651 = load i64, ptr %l47, !tbaa !24
  %t652 = load i64, ptr %l48, !tbaa !24
  %t655 = icmp slt i64 %t651, %t652
  %t657 = xor i1 %t655, true
  br i1 %t657, label %bb159, label %bb160
bb159:
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t659 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t659, ptr %l359, !tbaa !27
  %t660 = load i64, ptr %l47, !tbaa !24
  %t662 = getelementptr { i64, ptr }, ptr %l359, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = getelementptr ptr, ptr %t663, i64 %t660
  %t665 = load ptr, ptr %t664, !tbaa !39
  %t667 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t667, ptr %t665)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t672 = load i64, ptr %l47, !tbaa !24
  %t674 = add i64 %t672, 1
  store i64 %t674, ptr %l47, !tbaa !24
  br label %bb158
bb164:
  br label %bb165
bb165:
  %t676 = load i64, ptr %l43, !tbaa !24
  %t678 = add i64 %t676, 1
  store i64 %t678, ptr %l43, !tbaa !24
  br label %bb153
bb166:
  br label %bb241
bb167:
  %t680 = load ptr, ptr %l1, !tbaa !29
  store ptr %t680, ptr %l369, !tbaa !29
  store i1 false, ptr %l370, !tbaa !21
  %t681 = load ptr, ptr %l369, !tbaa !29
  %t682 = icmp ne ptr %t681, null
  br i1 %t682, label %bb168, label %bb169
bb168:
  %t684 = load ptr, ptr %l369, !tbaa !29
  %t685 = load i64, ptr %t684, !range !{i64 0, i64 18}
  %t687 = icmp eq i64 %t685, 15
  store i1 %t687, ptr %l370, !tbaa !21
  br label %bb169
bb169:
  %t688 = load i1, ptr %l370, !tbaa !21
  br i1 %t688, label %bb170, label %bb171
bb170:
  %t689 = load ptr, ptr %l1, !tbaa !29
  %t691 = getelementptr { i64, [5 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t691, i32 0, i32 0
  %t693 = load %"compiler/source:Span", ptr %t692
  store %"compiler/source:Span" %t693, ptr %l50
  %t695 = load ptr, ptr %l1, !tbaa !29
  %t697 = getelementptr { i64, [5 x i64] }, ptr %t695, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t697, i32 0, i32 2
  %t699 = load ptr, ptr %t698
  store ptr %t699, ptr %l51, !tbaa !29
  br label %bb172
bb171:
  br label %bb206
bb172:
  %t701 = load ptr, ptr %l51, !tbaa !29
  store ptr %t701, ptr %l377, !tbaa !29
  store i1 false, ptr %l378, !tbaa !21
  %t702 = load ptr, ptr %l377, !tbaa !29
  %t703 = icmp ne ptr %t702, null
  br i1 %t703, label %bb173, label %bb174
bb173:
  %t705 = load ptr, ptr %l377, !tbaa !29
  %t706 = load i64, ptr %t705, !range !{i64 0, i64 3}
  %t708 = icmp eq i64 %t706, 0
  store i1 %t708, ptr %l378, !tbaa !21
  br label %bb174
bb174:
  %t709 = load i1, ptr %l378, !tbaa !21
  br i1 %t709, label %bb175, label %bb176
bb175:
  %t710 = load ptr, ptr %l51, !tbaa !29
  %t712 = getelementptr { i64, [4 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { i32 }, ptr %t712, i32 0, i32 0
  %t714 = load i32, ptr %t713
  store i32 %t714, ptr %l52, !tbaa !23
  br label %bb177
bb176:
  br label %bb179
bb177:
  store %olang.scope zeroinitializer, ptr %s42
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load %"compiler/source:Span", ptr %l50
  %t718 = load i32, ptr %l52, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t719
  %t720 = getelementptr { i64, [3 x i64] }, ptr %t719, i32 0, i32 0
  store i64 0, ptr %t720
  %t722 = insertvalue { i32 } undef, i32 %t718, 0
  %t723 = getelementptr { i64, [3 x i64] }, ptr %t719, i32 0, i32 1
  store { i32 } %t722, ptr %t723
  %t724 = load { i64, [3 x i64] }, ptr %t719
  %t726 = call ptr @__olang_scope_alloc_a(ptr %s42, i64 32, i64 8)
  store { i64, [3 x i64] } %t724, ptr %t726
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %s42, ptr %t716, %"compiler/source:Span" %t717, ptr %t726)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s42)
  br label %bb205
bb179:
  %t730 = load ptr, ptr %l51, !tbaa !29
  store ptr %t730, ptr %l388, !tbaa !29
  store i1 false, ptr %l389, !tbaa !21
  %t731 = load ptr, ptr %l388, !tbaa !29
  %t732 = icmp ne ptr %t731, null
  br i1 %t732, label %bb180, label %bb181
bb180:
  %t734 = load ptr, ptr %l388, !tbaa !29
  %t735 = load i64, ptr %t734, !range !{i64 0, i64 3}
  %t737 = icmp eq i64 %t735, 1
  store i1 %t737, ptr %l389, !tbaa !21
  br label %bb181
bb181:
  %t738 = load i1, ptr %l389, !tbaa !21
  br i1 %t738, label %bb182, label %bb183
bb182:
  %t739 = load ptr, ptr %l51, !tbaa !29
  %t741 = getelementptr { i64, [4 x i64] }, ptr %t739, i32 0, i32 1
  %t742 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t741, i32 0, i32 0
  %t743 = load i32, ptr %t742
  store i32 %t743, ptr %l53, !tbaa !23
  %t745 = load ptr, ptr %l51, !tbaa !29
  %t747 = getelementptr { i64, [4 x i64] }, ptr %t745, i32 0, i32 1
  %t748 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t747, i32 0, i32 1
  %t749 = load { i64, ptr }, ptr %t748
  store { i64, ptr } %t749, ptr %l54, !tbaa !27
  br label %bb184
bb183:
  br label %bb197
bb184:
  %t751 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t751, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t753 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t755 = extractvalue { i64, ptr } %t753, 0
  store i64 %t755, ptr %l57, !tbaa !24
  br label %bb185
bb185:
  %t757 = load i64, ptr %l56, !tbaa !24
  %t758 = load i64, ptr %l57, !tbaa !24
  %t761 = icmp slt i64 %t757, %t758
  %t763 = xor i1 %t761, true
  br i1 %t763, label %bb186, label %bb187
bb186:
  br label %bb191
bb187:
  br label %bb188
bb188:
  %t765 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t765, ptr %l403, !tbaa !27
  %t766 = load i64, ptr %l56, !tbaa !24
  %t768 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = getelementptr ptr, ptr %t769, i64 %t766
  %t771 = load ptr, ptr %t770, !tbaa !39
  %t773 = load ptr, ptr %l0, !tbaa !29
  %t776 = getelementptr %"compiler/typed:Capture", ptr %t771, i32 0, i32 1
  %t777 = load ptr, ptr %t776, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t773, ptr %t777)
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t781 = load i64, ptr %l56, !tbaa !24
  %t783 = add i64 %t781, 1
  store i64 %t783, ptr %l56, !tbaa !24
  br label %bb185
bb191:
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t787 = getelementptr %"compiler/session:finder", ptr %t785, i32 0, i32 3
  %t788 = load ptr, ptr %t787, !tbaa !29
  %t790 = getelementptr %"compiler/check:Checker", ptr %t788, i32 0, i32 14
  %t791 = load i32, ptr %l53, !tbaa !23
  %t793 = sext i32 %t791 to i64
  %t796 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t790, i64 %t793)
  store ptr %t796, ptr %l417
  br label %bb192
bb192:
  %t797 = load ptr, ptr %l417, !tbaa !29
  store ptr %t797, ptr %l59, !tbaa !29
  %t798 = load ptr, ptr %l59, !tbaa !29
  %t800 = getelementptr %"compiler/typed:Body", ptr %t798, i32 0, i32 11
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = icmp eq ptr %t801, null
  %t805 = xor i1 %t803, true
  br i1 %t805, label %bb193, label %bb194
bb193:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load ptr, ptr %l59, !tbaa !29
  %t810 = getelementptr %"compiler/typed:Body", ptr %t808, i32 0, i32 11
  %t811 = load ptr, ptr %t810, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v0, ptr %t807, ptr %t811)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb205
bb197:
  %t814 = load ptr, ptr %l51, !tbaa !29
  store ptr %t814, ptr %l425, !tbaa !29
  store i1 false, ptr %l426, !tbaa !21
  %t815 = load ptr, ptr %l425, !tbaa !29
  %t816 = icmp ne ptr %t815, null
  br i1 %t816, label %bb198, label %bb199
bb198:
  %t818 = load ptr, ptr %l425, !tbaa !29
  %t819 = load i64, ptr %t818, !range !{i64 0, i64 3}
  %t821 = icmp eq i64 %t819, 2
  store i1 %t821, ptr %l426, !tbaa !21
  br label %bb199
bb199:
  %t822 = load i1, ptr %l426, !tbaa !21
  br i1 %t822, label %bb200, label %bb201
bb200:
  %t823 = load ptr, ptr %l51, !tbaa !29
  %t825 = getelementptr { i64, [4 x i64] }, ptr %t823, i32 0, i32 1
  %t826 = getelementptr { i32, ptr, i32 }, ptr %t825, i32 0, i32 1
  %t827 = load ptr, ptr %t826
  store ptr %t827, ptr %l60, !tbaa !29
  br label %bb202
bb201:
  br label %bb204
bb202:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t829, ptr %t830)
  br label %bb203
bb203:
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b)
  unreachable
bb205:
  br label %bb241
bb206:
  %t834 = load ptr, ptr %l1, !tbaa !29
  store ptr %t834, ptr %l434, !tbaa !29
  store i1 false, ptr %l435, !tbaa !21
  %t835 = load ptr, ptr %l434, !tbaa !29
  %t836 = icmp ne ptr %t835, null
  br i1 %t836, label %bb207, label %bb208
bb207:
  %t838 = load ptr, ptr %l434, !tbaa !29
  %t839 = load i64, ptr %t838, !range !{i64 0, i64 18}
  %t841 = icmp eq i64 %t839, 16
  store i1 %t841, ptr %l435, !tbaa !21
  br label %bb208
bb208:
  %t842 = load i1, ptr %l435, !tbaa !21
  br i1 %t842, label %bb209, label %bb210
bb209:
  %t843 = load ptr, ptr %l1, !tbaa !29
  %t845 = getelementptr { i64, [5 x i64] }, ptr %t843, i32 0, i32 1
  %t846 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t845, i32 0, i32 2
  %t847 = load ptr, ptr %t846
  store ptr %t847, ptr %l61, !tbaa !29
  br label %bb211
bb210:
  br label %bb230
bb211:
  %t849 = load ptr, ptr %l61, !tbaa !29
  %t851 = getelementptr %"compiler/typed:Text", ptr %t849, i32 0, i32 0
  %t852 = load { i64, ptr }, ptr %t851, !tbaa !27
  store { i64, ptr } %t852, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t854 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t856 = extractvalue { i64, ptr } %t854, 0
  store i64 %t856, ptr %l64, !tbaa !24
  br label %bb212
bb212:
  %t858 = load i64, ptr %l63, !tbaa !24
  %t859 = load i64, ptr %l64, !tbaa !24
  %t862 = icmp slt i64 %t858, %t859
  %t864 = xor i1 %t862, true
  br i1 %t864, label %bb213, label %bb214
bb213:
  br label %bb229
bb214:
  br label %bb215
bb215:
  %t866 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t866, ptr %l448, !tbaa !27
  %t867 = load i64, ptr %l63, !tbaa !24
  %t869 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !27
  %t871 = getelementptr ptr, ptr %t870, i64 %t867
  %t872 = load ptr, ptr %t871, !tbaa !39
  store ptr %t872, ptr %l65, !tbaa !29
  %t874 = load ptr, ptr %l65, !tbaa !29
  store ptr %t874, ptr %l451, !tbaa !29
  store i1 false, ptr %l452, !tbaa !21
  %t875 = load ptr, ptr %l451, !tbaa !29
  %t876 = icmp ne ptr %t875, null
  br i1 %t876, label %bb216, label %bb217
bb216:
  %t878 = load ptr, ptr %l451, !tbaa !29
  %t879 = load i64, ptr %t878, !range !{i64 0, i64 2}
  %t881 = icmp eq i64 %t879, 1
  store i1 %t881, ptr %l452, !tbaa !21
  br label %bb217
bb217:
  %t882 = load i1, ptr %l452, !tbaa !21
  br i1 %t882, label %bb218, label %bb219
bb218:
  %t883 = load ptr, ptr %l65, !tbaa !29
  %t885 = getelementptr { i64, [2 x i64] }, ptr %t883, i32 0, i32 1
  %t886 = getelementptr { ptr }, ptr %t885, i32 0, i32 0
  %t887 = load ptr, ptr %t886
  store ptr %t887, ptr %l66, !tbaa !29
  br label %bb220
bb219:
  br label %bb222
bb220:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t889, ptr %t890)
  br label %bb221
bb221:
  br label %bb227
bb222:
  br i1 true, label %bb223, label %bb224
bb223:
  br label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_7a96973d190d0d9e_4b6d703943f97c5a)
  unreachable
bb227:
  br label %bb228
bb228:
  %t894 = load i64, ptr %l63, !tbaa !24
  %t896 = add i64 %t894, 1
  store i64 %t896, ptr %l63, !tbaa !24
  br label %bb212
bb229:
  br label %bb241
bb230:
  %t898 = load ptr, ptr %l1, !tbaa !29
  store ptr %t898, ptr %l462, !tbaa !29
  store i1 false, ptr %l463, !tbaa !21
  %t899 = load ptr, ptr %l462, !tbaa !29
  %t900 = icmp ne ptr %t899, null
  br i1 %t900, label %bb231, label %bb232
bb231:
  %t902 = load ptr, ptr %l462, !tbaa !29
  %t903 = load i64, ptr %t902, !range !{i64 0, i64 18}
  %t905 = icmp eq i64 %t903, 17
  store i1 %t905, ptr %l463, !tbaa !21
  br label %bb232
bb232:
  %t906 = load i1, ptr %l463, !tbaa !21
  br i1 %t906, label %bb233, label %bb234
bb233:
  br label %bb235
bb234:
  br label %bb236
bb235:
  br label %bb241
bb236:
  br i1 true, label %bb237, label %bb238
bb237:
  br label %bb239
bb238:
  br label %bb240
bb239:
  br label %bb241
bb240:
  call void @__olang_check_failed(ptr @olang_loc_d73c626185112279_563eb35624dc00ed)
  unreachable
bb241:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l29 = alloca i1
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %t90 = alloca { i64, [6 x i64] }, align 8
  %t166 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t6 = load ptr, ptr %l14, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/session:finder", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t35, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/session:finder", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i32, ptr %l4, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t56, i32 %t57)
  store { i64, ptr } %t60, ptr %l36
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb11:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/session:finder", ptr %t61, i32 0, i32 2
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t65, { i64, ptr } %t64)
  store i1 %t67, ptr %l39
  br label %bb12
bb12:
  %t68 = load i1, ptr %l39, !tbaa !21
  store i1 %t68, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l29, !tbaa !21
  br i1 %t69, label %bb14, label %bb15
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l2
  %t72 = load i64, ptr %l3, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/session:finder", ptr %t73, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = extractvalue { i64, ptr } %t76, 0
  %t80 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t78, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } %t82, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [6 x i64] }, ptr %t90, i32 0, i32 0
  store i64 1, ptr %t91
  %t93 = insertvalue { i64, { i64, ptr } } undef, i64 %t72, 0
  %t95 = insertvalue { i64, { i64, ptr } } %t93, { i64, ptr } %t89, 1
  %t96 = getelementptr { i64, [6 x i64] }, ptr %t90, i32 0, i32 1
  store { i64, { i64, ptr } } %t95, ptr %t96
  %t97 = load { i64, [6 x i64] }, ptr %t90
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t70, %"compiler/source:Span" %t71, { i64, [6 x i64] } %t97)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb64
bb18:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t102 = load ptr, ptr %l48, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb19, label %bb20
bb19:
  %t105 = load ptr, ptr %l48, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 8}
  %t108 = icmp eq i64 %t106, 2
  store i1 %t108, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t109 = load i1, ptr %l49, !tbaa !21
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  br label %bb24
bb24:
  br label %bb64
bb25:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 8}
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb27
bb27:
  %t129 = load i1, ptr %l58, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 0
  %t134 = load %"compiler/source:Span", ptr %t133
  store %"compiler/source:Span" %t134, ptr %l6
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l7, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 3
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t148 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t149 = load i32, ptr %t148, !tbaa !23
  %t151 = sext i32 %t149 to i64
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/session:finder", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  %t158 = icmp eq i64 %t151, %t155
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l72, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t161, ptr %l73
  %t162 = load ptr, ptr %l7, !tbaa !29
  %t164 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t162)
  store i32 %t164, ptr %l75
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load i64, ptr %l8, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [6 x i64] }, ptr %t166, i32 0, i32 0
  store i64 3, ptr %t167
  %t168 = load i32, ptr %l75, !tbaa !23
  %t169 = insertvalue { i32, i64 } undef, i32 %t168, 0
  %t171 = insertvalue { i32, i64 } %t169, i64 %t165, 1
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t166, i32 0, i32 1
  store { i32, i64 } %t171, ptr %t172
  %t173 = load { i64, [6 x i64] }, ptr %t166
  %t174 = load ptr, ptr %l72, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l73
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t174, %"compiler/source:Span" %t175, { i64, [6 x i64] } %t173)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb36
bb36:
  br label %bb64
bb37:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t183 = load ptr, ptr %l81, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb38, label %bb39
bb38:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 8}
  %t189 = icmp eq i64 %t187, 4
  store i1 %t189, ptr %l82, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l82, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l9, !tbaa !29
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t197, ptr %t201)
  br label %bb43
bb43:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l9, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Elem", ptr %t206, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t205, ptr %t209)
  br label %bb44
bb44:
  br label %bb64
bb45:
  %t213 = load ptr, ptr %l1, !tbaa !29
  store ptr %t213, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t214 = load ptr, ptr %l95, !tbaa !29
  %t215 = icmp ne ptr %t214, null
  br i1 %t215, label %bb46, label %bb47
bb46:
  %t217 = load ptr, ptr %l95, !tbaa !29
  %t218 = load i64, ptr %t217, !range !{i64 0, i64 8}
  %t220 = icmp eq i64 %t218, 5
  store i1 %t220, ptr %l96, !tbaa !21
  br label %bb47
bb47:
  %t221 = load i1, ptr %l96, !tbaa !21
  br i1 %t221, label %bb48, label %bb49
bb48:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t224 = getelementptr { i64, [4 x i64] }, ptr %t222, i32 0, i32 1
  %t225 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t224, i32 0, i32 2
  %t226 = load ptr, ptr %t225
  store ptr %t226, ptr %l10, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Payload", ptr %t229, i32 0, i32 0
  %t232 = load ptr, ptr %t231, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t228, ptr %t232)
  br label %bb51
bb51:
  br label %bb64
bb52:
  %t236 = load ptr, ptr %l1, !tbaa !29
  store ptr %t236, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t237 = load ptr, ptr %l105, !tbaa !29
  %t238 = icmp ne ptr %t237, null
  br i1 %t238, label %bb53, label %bb54
bb53:
  %t240 = load ptr, ptr %l105, !tbaa !29
  %t241 = load i64, ptr %t240, !range !{i64 0, i64 8}
  %t243 = icmp eq i64 %t241, 6
  store i1 %t243, ptr %l106, !tbaa !21
  br label %bb54
bb54:
  %t244 = load i1, ptr %l106, !tbaa !21
  br i1 %t244, label %bb55, label %bb56
bb55:
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l11, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t251, ptr %t252)
  br label %bb58
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5)
  unreachable
bb64:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l72 = alloca ptr
  %l73 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l159 = alloca { i64, ptr }
  %l170 = alloca ptr
  %l171 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb112
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l32, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l33, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  br label %bb112
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t57 = load ptr, ptr %l46, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l46, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 17}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t72)
  br label %bb24
bb24:
  br label %bb112
bb25:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb26, label %bb27
bb26:
  %t80 = load ptr, ptr %l55, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 17}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l56, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l56, !tbaa !21
  br i1 %t84, label %bb28, label %bb29
bb28:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/typed:If", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l6, !tbaa !29
  %t102 = getelementptr %"compiler/typed:If", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t99, ptr %t103)
  br label %bb32
bb32:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/typed:If", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t107, ptr %t111)
  br label %bb33
bb33:
  br label %bb112
bb34:
  %t114 = load ptr, ptr %l1, !tbaa !29
  store ptr %t114, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t115 = load ptr, ptr %l72, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb35, label %bb36
bb35:
  %t118 = load ptr, ptr %l72, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 17}
  %t121 = icmp eq i64 %t119, 4
  store i1 %t121, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t122 = load i1, ptr %l73, !tbaa !21
  br i1 %t122, label %bb37, label %bb38
bb37:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t125, i32 0, i32 1
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l7, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l8, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t140, ptr %t141)
  br label %bb41
bb41:
  br label %bb112
bb42:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb43, label %bb44
bb43:
  %t148 = load ptr, ptr %l85, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 17}
  %t151 = icmp eq i64 %t149, 6
  store i1 %t151, ptr %l86, !tbaa !21
  br label %bb44
bb44:
  %t152 = load i1, ptr %l86, !tbaa !21
  br i1 %t152, label %bb45, label %bb46
bb45:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", ptr }, ptr %t155, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l9, !tbaa !29
  br label %bb51
bb46:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t160 = load ptr, ptr %l91, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb47, label %bb48
bb47:
  %t163 = load ptr, ptr %l91, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 16
  store i1 %t166, ptr %l92, !tbaa !21
  br label %bb48
bb48:
  %t167 = load i1, ptr %l92, !tbaa !21
  br i1 %t167, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l9, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t174, ptr %t175)
  br label %bb52
bb52:
  br label %bb112
bb53:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t179 = load ptr, ptr %l99, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb54, label %bb55
bb54:
  %t182 = load ptr, ptr %l99, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 17}
  %t185 = icmp eq i64 %t183, 9
  store i1 %t185, ptr %l100, !tbaa !21
  br label %bb55
bb55:
  %t186 = load i1, ptr %l100, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t189, i32 0, i32 2
  %t191 = load ptr, ptr %t190
  store ptr %t191, ptr %l10, !tbaa !29
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t193, ptr %t194)
  br label %bb59
bb59:
  br label %bb112
bb60:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t198 = load ptr, ptr %l107, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb61, label %bb62
bb61:
  %t201 = load ptr, ptr %l107, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 17}
  %t204 = icmp eq i64 %t202, 10
  store i1 %t204, ptr %l108, !tbaa !21
  br label %bb62
bb62:
  %t205 = load i1, ptr %l108, !tbaa !21
  br i1 %t205, label %bb63, label %bb64
bb63:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [3 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t208, i32 0, i32 1
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l11, !tbaa !29
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t214, i32 0, i32 2
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l12, !tbaa !29
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t218, ptr %t219)
  br label %bb66
bb66:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t224)
  br label %bb67
bb67:
  br label %bb112
bb68:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t228 = load ptr, ptr %l120, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l120, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 17}
  %t234 = icmp eq i64 %t232, 11
  store i1 %t234, ptr %l121, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l121, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l13, !tbaa !29
  br label %bb77
bb72:
  %t242 = load ptr, ptr %l1, !tbaa !29
  store ptr %t242, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t243 = load ptr, ptr %l126, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l126, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 17}
  %t249 = icmp eq i64 %t247, 12
  store i1 %t249, ptr %l127, !tbaa !21
  br label %bb74
bb74:
  %t250 = load i1, ptr %l127, !tbaa !21
  br i1 %t250, label %bb75, label %bb76
bb75:
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l13, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  br label %bb78
bb78:
  br label %bb112
bb79:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t263 = load ptr, ptr %l135, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb80, label %bb81
bb80:
  %t266 = load ptr, ptr %l135, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 17}
  %t269 = icmp eq i64 %t267, 13
  store i1 %t269, ptr %l136, !tbaa !21
  br label %bb81
bb81:
  %t270 = load i1, ptr %l136, !tbaa !21
  br i1 %t270, label %bb82, label %bb83
bb82:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l14, !tbaa !29
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l14, !tbaa !29
  %t280 = getelementptr %"compiler/typed:Join", ptr %t278, i32 0, i32 0
  %t281 = load ptr, ptr %t280, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %t277, ptr %t281)
  br label %bb85
bb85:
  br label %bb112
bb86:
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t286 = load ptr, ptr %l145, !tbaa !29
  %t287 = icmp ne ptr %t286, null
  br i1 %t287, label %bb87, label %bb88
bb87:
  %t289 = load ptr, ptr %l145, !tbaa !29
  %t290 = load i64, ptr %t289, !range !{i64 0, i64 17}
  %t292 = icmp eq i64 %t290, 14
  store i1 %t292, ptr %l146, !tbaa !21
  br label %bb88
bb88:
  %t293 = load i1, ptr %l146, !tbaa !21
  br i1 %t293, label %bb89, label %bb90
bb89:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr { i64, [3 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", ptr }, ptr %t296, i32 0, i32 1
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb100
bb91:
  %t300 = load ptr, ptr %l15, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Spawn", ptr %t300, i32 0, i32 0
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  store { i64, ptr } %t303, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t305 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t305, 0
  store i64 %t307, ptr %l18, !tbaa !24
  br label %bb92
bb92:
  %t309 = load i64, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l18, !tbaa !24
  %t313 = icmp slt i64 %t309, %t310
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb93, label %bb94
bb93:
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t317 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t317, ptr %l159, !tbaa !27
  %t318 = load i64, ptr %l17, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  %t325 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %t325, ptr %t323)
  br label %bb96
bb96:
  br label %bb97
bb97:
  %t329 = load i64, ptr %l17, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l17, !tbaa !24
  br label %bb92
bb98:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l15, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Spawn", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t333, ptr %t337)
  br label %bb99
bb99:
  br label %bb112
bb100:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t342 = load ptr, ptr %l170, !tbaa !29
  %t343 = icmp ne ptr %t342, null
  br i1 %t343, label %bb101, label %bb102
bb101:
  %t345 = load ptr, ptr %l170, !tbaa !29
  %t346 = load i64, ptr %t345, !range !{i64 0, i64 17}
  %t348 = icmp eq i64 %t346, 15
  store i1 %t348, ptr %l171, !tbaa !21
  br label %bb102
bb102:
  %t349 = load i1, ptr %l171, !tbaa !21
  br i1 %t349, label %bb103, label %bb104
bb103:
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr { i64, [3 x i64] }, ptr %t350, i32 0, i32 1
  %t353 = getelementptr { %"compiler/source:Span", ptr }, ptr %t352, i32 0, i32 1
  %t354 = load ptr, ptr %t353
  store ptr %t354, ptr %l20, !tbaa !29
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %t356, ptr %t357)
  br label %bb106
bb106:
  br label %bb112
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_check_failed(ptr @olang_loc_9a3dbb58dbc7a31a_5629726f6c293dd6)
  unreachable
bb112:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, [6 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l14 = alloca i1
  %l20 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t8 = sext i32 %t6 to i64
  %t11 = sub i64 %t4, %t8
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/session:finder", ptr %t17, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t23 = icmp sle i64 %t16, %t20
  br i1 %t23, label %bb1, label %bb2
bb1:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/session:finder", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = icmp sle i64 %t28, %t32
  store i1 %t35, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t37 = load i1, ptr %l14, !tbaa !21
  br i1 %t37, label %bb4, label %bb5
bb4:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/session:finder", ptr %t39, i32 0, i32 6
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp slt i64 %t38, %t42
  store i1 %t45, ptr %l20, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t52 = getelementptr %"compiler/session:finder", ptr %t48, i32 0, i32 6
  store i64 %t49, ptr %t52, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/session:finder", ptr %t53, i32 0, i32 5
  store { i64, [6 x i64] } %a2, ptr %t57
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca %"compiler/session:symWriter"
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca %"compiler/session:symWriter"
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l80 = alloca i1
  %l90 = alloca { i64, ptr }
  %l101 = alloca %"compiler/source:Span"
  %l103 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l116 = alloca i64
  %l117 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l133 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca i1
  %l159 = alloca { i64, ptr }
  %l164 = alloca i64
  %l172 = alloca i64
  %l173 = alloca ptr
  %l174 = alloca i1
  %l178 = alloca ptr
  %l179 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l204 = alloca %"compiler/session:symWriter"
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca i1
  %l234 = alloca i64
  %l237 = alloca i64
  %l256 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l260 = alloca ptr
  %l263 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l278 = alloca ptr
  %l279 = alloca i1
  %l290 = alloca { i64, ptr }
  %l295 = alloca i64
  %l311 = alloca %"compiler/session:symWriter"
  %l319 = alloca { i64, ptr }
  %l324 = alloca { i64, ptr }
  %l331 = alloca i64
  %l351 = alloca ptr
  %l352 = alloca i1
  %l359 = alloca ptr
  %l360 = alloca ptr
  %l361 = alloca { i64, ptr }
  %l363 = alloca i64
  %l365 = alloca i64
  %l366 = alloca i64
  %l382 = alloca ptr
  %l383 = alloca i1
  %l393 = alloca ptr
  %l394 = alloca i1
  %l406 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t10 = load ptr, ptr %l50, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l50, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 11}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l51, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l51, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [6 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb9
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t25 = load ptr, ptr %l56, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l56, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 11}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l57, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l57, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { ptr }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb48
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l65
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 0
  %t52 = getelementptr %"compiler/source:Span", ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t48, i64 %t55, { i64, ptr } %t56)
  store i64 %t60, ptr %l71
  br label %bb11
bb11:
  %t61 = load i64, ptr %l71, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l72, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t62, ptr %l73, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l74, !tbaa !24
  %t65 = load i64, ptr %l74, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l75, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l74, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb12, label %bb13
bb12:
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/ast:Func", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb17
bb14:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb15:
  br label %bb16
bb16:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t99 = getelementptr %"compiler/ast:Param", ptr %t96, i32 0, i32 2
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  %t104 = xor i1 %t102, true
  store i1 %t104, ptr %l80, !tbaa !21
  br label %bb17
bb17:
  %t106 = load i1, ptr %l80, !tbaa !21
  br i1 %t106, label %bb18, label %bb19
bb18:
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t107, ptr %l90, !tbaa !27
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Func", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb20, label %bb21
bb19:
  br label %bb43
bb20:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb21:
  br label %bb22
bb22:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:Func", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t121 = getelementptr %"compiler/ast:Param", ptr %t118, i32 0, i32 2
  %t122 = load ptr, ptr %t121, !tbaa !29
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l9, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb24:
  br label %bb25
bb25:
  %t128 = load ptr, ptr %l9, !tbaa !29
  %t130 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t128)
  store %"compiler/source:Span" %t130, ptr %l101
  br label %bb26
bb26:
  %t131 = getelementptr %"compiler/source:Span", ptr %l101, i32 0, i32 0
  %t132 = load i32, ptr %t131, !tbaa !23
  %t134 = sext i32 %t132 to i64
  store i64 %t134, ptr %l103, !tbaa !24
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Func", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  br i1 %t140, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb28:
  br label %bb29
bb29:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr %"compiler/ast:Func", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Param", ptr %t145, i32 0, i32 2
  %t149 = load ptr, ptr %t148, !tbaa !29
  store ptr %t149, ptr %l10, !tbaa !29
  %t151 = load ptr, ptr %l10, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb31:
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l10, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l114
  br label %bb33
bb33:
  %t158 = getelementptr %"compiler/source:Span", ptr %l114, i32 0, i32 1
  %t159 = load i32, ptr %t158, !tbaa !23
  %t161 = sext i32 %t159 to i64
  store i64 %t161, ptr %l116, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l117, !tbaa !24
  %t164 = load i64, ptr %l103, !tbaa !24
  %t165 = icmp sge i64 %t164, 0
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load i64, ptr %l103, !tbaa !24
  %t168 = load i64, ptr %l116, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  br i1 %t169, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb36:
  %t171 = load i64, ptr %l116, !tbaa !24
  %t172 = load i64, ptr %l117, !tbaa !24
  %t173 = icmp sle i64 %t171, %t172
  br i1 %t173, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb38:
  %t175 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l103, !tbaa !24
  %t178 = load i64, ptr %l116, !tbaa !24
  %t179 = getelementptr i8, ptr %t176, i64 %t177
  %t180 = sub i64 %t178, %t177
  %t181 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = extractvalue { i64, ptr } %t182, 0
  %t186 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t184, i64 %t185)
  %t187 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l122, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l124, !tbaa !24
  %t194 = load i64, ptr %l124, !tbaa !24
  %t195 = icmp eq i64 %t190, %t194
  br i1 %t195, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb40:
  %t197 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l124, !tbaa !24
  %t202 = mul i64 %t201, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  br label %bb42
bb41:
  %t203 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t203, ptr %l8, !tbaa !27
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t204 = load ptr, ptr %l0, !tbaa !29
  store ptr %t204, ptr %l126, !tbaa !29
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l127, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t206, ptr %l128, !tbaa !27
  %t207 = load ptr, ptr %l5, !tbaa !29
  %t209 = getelementptr %"compiler/ast:Func", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb44, label %bb45
bb44:
  %t216 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  store i64 %t216, ptr %l133, !tbaa !24
  br label %bb46
bb45:
  %t218 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  store i64 %t218, ptr %l133, !tbaa !24
  br label %bb46
bb46:
  %t220 = load ptr, ptr %l5, !tbaa !29
  %t222 = getelementptr %"compiler/ast:Func", ptr %t220, i32 0, i32 0
  %t223 = getelementptr %"compiler/source:Span", ptr %t222, i32 0, i32 0
  %t224 = load i32, ptr %t223, !tbaa !23
  %t226 = sext i32 %t224 to i64
  %t227 = load ptr, ptr %l5, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Func", ptr %t227, i32 0, i32 0
  %t230 = getelementptr %"compiler/source:Span", ptr %t229, i32 0, i32 1
  %t231 = load i32, ptr %t230, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t234 = load i64, ptr %l7, !tbaa !24
  %t235 = load i64, ptr %l7, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t241 = add i64 %t235, %t238
  %t242 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t243 = load ptr, ptr %l126, !tbaa !29
  %t244 = load ptr, ptr %l127, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t246 = load i64, ptr %l133, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s1, ptr %t243, ptr %t244, { i64, ptr } %t245, i64 %t246, i64 %t226, i64 %t233, i64 %t234, i64 %t241, { i64, ptr } %t242)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s1)
  br label %bb176
bb48:
  %t252 = load ptr, ptr %l2, !tbaa !29
  store ptr %t252, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t253 = load ptr, ptr %l148, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb49, label %bb50
bb49:
  %t256 = load ptr, ptr %l148, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 11}
  %t259 = icmp eq i64 %t257, 2
  store i1 %t259, ptr %l149, !tbaa !21
  br label %bb50
bb50:
  %t260 = load i1, ptr %l149, !tbaa !21
  br i1 %t260, label %bb51, label %bb52
bb51:
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t263 = getelementptr { i64, [6 x i64] }, ptr %t261, i32 0, i32 1
  %t264 = getelementptr { %"compiler/source:Span", ptr }, ptr %t263, i32 0, i32 0
  %t265 = load %"compiler/source:Span", ptr %t264
  store %"compiler/source:Span" %t265, ptr %l11
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr { i64, [6 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", ptr }, ptr %t269, i32 0, i32 1
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l12, !tbaa !29
  br label %bb53
bb52:
  br label %bb92
bb53:
  store %olang.scope zeroinitializer, ptr %s4
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t274 = load ptr, ptr %l12, !tbaa !29
  %t276 = getelementptr %"compiler/ast:TypeDecl", ptr %t274, i32 0, i32 0
  %t277 = load i32, ptr %t276, !tbaa !23
  %t280 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t273, i32 %t277)
  store { i64, ptr } %t280, ptr %l159
  br label %bb54
bb54:
  %t281 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t281, ptr %l13, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t283 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t286 = sext i32 %t284 to i64
  %t287 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t291 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t282, i64 %t286, { i64, ptr } %t287)
  store i64 %t291, ptr %l164
  br label %bb55
bb55:
  %t292 = load i64, ptr %l164, !tbaa !24
  store i64 %t292, ptr %l14, !tbaa !24
  %t293 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t293, ptr %l15, !tbaa !24
  %t295 = load ptr, ptr %l12, !tbaa !29
  %t297 = getelementptr %"compiler/ast:TypeDecl", ptr %t295, i32 0, i32 3
  %t298 = load ptr, ptr %t297, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb56, label %bb57
bb56:
  %t304 = load ptr, ptr %l12, !tbaa !29
  %t306 = getelementptr %"compiler/ast:TypeDecl", ptr %t304, i32 0, i32 3
  %t307 = load ptr, ptr %t306, !tbaa !29
  store ptr %t307, ptr %l16, !tbaa !29
  %t309 = load ptr, ptr %l16, !tbaa !29
  store ptr %t309, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t310 = load ptr, ptr %l173, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb58, label %bb59
bb57:
  br label %bb81
bb58:
  %t313 = load ptr, ptr %l173, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 5}
  %t316 = icmp eq i64 %t314, 0
  store i1 %t316, ptr %l174, !tbaa !21
  br label %bb59
bb59:
  %t317 = load i1, ptr %l174, !tbaa !21
  br i1 %t317, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  %t318 = load i64, ptr @G_2ecompiler_2fsession_2eKindStruct, !tbaa !24
  store i64 %t318, ptr %l172, !tbaa !24
  br label %bb80
bb63:
  %t320 = load ptr, ptr %l16, !tbaa !29
  store ptr %t320, ptr %l178, !tbaa !29
  store i1 false, ptr %l179, !tbaa !21
  %t321 = load ptr, ptr %l178, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb64, label %bb65
bb64:
  %t324 = load ptr, ptr %l178, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 5}
  %t327 = icmp eq i64 %t325, 1
  store i1 %t327, ptr %l179, !tbaa !21
  br label %bb65
bb65:
  %t328 = load i1, ptr %l179, !tbaa !21
  br i1 %t328, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t329 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  store i64 %t329, ptr %l172, !tbaa !24
  br label %bb80
bb69:
  %t331 = load ptr, ptr %l16, !tbaa !29
  store ptr %t331, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t332 = load ptr, ptr %l183, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb70, label %bb71
bb70:
  %t335 = load ptr, ptr %l183, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 5}
  %t338 = icmp eq i64 %t336, 2
  store i1 %t338, ptr %l184, !tbaa !21
  br label %bb71
bb71:
  %t339 = load i1, ptr %l184, !tbaa !21
  br i1 %t339, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t340 = load i64, ptr @G_2ecompiler_2fsession_2eKindInterface, !tbaa !24
  store i64 %t340, ptr %l172, !tbaa !24
  br label %bb80
bb75:
  br i1 true, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  %t342 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t342, ptr %l172, !tbaa !24
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_647b5c14292f4276_1cbe6dd578a95e8a)
  unreachable
bb80:
  %t344 = load i64, ptr %l172, !tbaa !24
  store i64 %t344, ptr %l15, !tbaa !24
  br label %bb81
bb81:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t348 = load i64, ptr %l15, !tbaa !24
  %t349 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t350 = load i32, ptr %t349, !tbaa !23
  %t352 = sext i32 %t350 to i64
  %t353 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t354 = load i32, ptr %t353, !tbaa !23
  %t356 = sext i32 %t354 to i64
  %t357 = load i64, ptr %l14, !tbaa !24
  %t358 = load i64, ptr %l14, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t364 = add i64 %t358, %t361
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s4, ptr %t345, ptr %t346, { i64, ptr } %t347, i64 %t348, i64 %t352, i64 %t356, i64 %t357, i64 %t364, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  br label %bb82
bb82:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/session:symWriter", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s4, ptr %t376)
  store %"compiler/session:symWriter" %t378, ptr %l204
  br label %bb83
bb83:
  %t379 = load %"compiler/session:symWriter", ptr %l204
  store %"compiler/session:symWriter" %t379, ptr %l17
  %t380 = load ptr, ptr %l12, !tbaa !29
  %t382 = getelementptr %"compiler/ast:TypeDecl", ptr %t380, i32 0, i32 3
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = icmp eq ptr %t383, null
  %t387 = xor i1 %t385, true
  br i1 %t387, label %bb84, label %bb85
bb84:
  store ptr %l17, ptr %l209, !tbaa !29
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l210, !tbaa !29
  %t390 = load ptr, ptr %l12, !tbaa !29
  %t392 = getelementptr %"compiler/ast:TypeDecl", ptr %t390, i32 0, i32 3
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = icmp eq ptr %t393, null
  br i1 %t395, label %bb86, label %bb87
bb85:
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_4f7bb28debca73d0_f3d58f15dee72c24)
  unreachable
bb87:
  br label %bb88
bb88:
  %t397 = load ptr, ptr %l12, !tbaa !29
  %t399 = getelementptr %"compiler/ast:TypeDecl", ptr %t397, i32 0, i32 3
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t401 = load ptr, ptr %l3, !tbaa !29
  %t402 = load ptr, ptr %l209, !tbaa !29
  %t403 = load ptr, ptr %l210, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %s4, ptr %v1, ptr %v2, ptr %v3, ptr %t402, ptr %t403, ptr %t400, ptr %t401)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t406 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t406, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s4)
  br label %bb176
bb92:
  %t408 = load ptr, ptr %l2, !tbaa !29
  store ptr %t408, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t409 = load ptr, ptr %l218, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb93, label %bb94
bb93:
  %t412 = load ptr, ptr %l218, !tbaa !29
  %t413 = load i64, ptr %t412, !range !{i64 0, i64 11}
  %t415 = icmp eq i64 %t413, 3
  store i1 %t415, ptr %l219, !tbaa !21
  br label %bb94
bb94:
  %t416 = load i1, ptr %l219, !tbaa !21
  br i1 %t416, label %bb95, label %bb96
bb95:
  %t417 = load ptr, ptr %l2, !tbaa !29
  %t419 = getelementptr { i64, [6 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr }, ptr %t419, i32 0, i32 0
  %t421 = load %"compiler/source:Span", ptr %t420
  store %"compiler/source:Span" %t421, ptr %l18
  %t423 = load ptr, ptr %l2, !tbaa !29
  %t425 = getelementptr { i64, [6 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr }, ptr %t425, i32 0, i32 1
  %t427 = load ptr, ptr %t426
  store ptr %t427, ptr %l19, !tbaa !29
  br label %bb97
bb96:
  br label %bb115
bb97:
  %t429 = load ptr, ptr %l19, !tbaa !29
  %t431 = getelementptr %"compiler/ast:VarDecl", ptr %t429, i32 0, i32 7
  %t432 = load i1, ptr %t431, !tbaa !21
  br i1 %t432, label %bb98, label %bb99
bb98:
  br label %ret
bb99:
  br label %bb100
bb100:
  store i64 0, ptr %l20, !tbaa !24
  %t434 = load ptr, ptr %l19, !tbaa !29
  %t436 = getelementptr %"compiler/ast:VarDecl", ptr %t434, i32 0, i32 0
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  %t439 = extractvalue { i64, ptr } %t437, 0
  store i64 %t439, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t441 = load i64, ptr %l21, !tbaa !24
  %t442 = load i64, ptr %l20, !tbaa !24
  %t445 = icmp sgt i64 %t441, %t442
  br i1 %t445, label %bb101, label %bb102
bb101:
  %t447 = load i64, ptr %l22, !tbaa !24
  %t449 = icmp sgt i64 %t447, 0
  br i1 %t449, label %bb103, label %bb104
bb102:
  store i64 0, ptr %l234, !tbaa !24
  br label %bb106
bb103:
  %t451 = load i64, ptr %l21, !tbaa !24
  %t452 = load i64, ptr %l20, !tbaa !24
  %t455 = sub i64 %t451, %t452
  %t456 = load i64, ptr %l22, !tbaa !24
  %t459 = add i64 %t455, %t456
  %t461 = sub i64 %t459, 1
  %t462 = load i64, ptr %l22, !tbaa !24
  %t465 = sdiv i64 %t461, %t462
  store i64 %t465, ptr %l237, !tbaa !24
  br label %bb105
bb104:
  store i64 0, ptr %l237, !tbaa !24
  br label %bb105
bb105:
  %t467 = load i64, ptr %l237, !tbaa !24
  store i64 %t467, ptr %l234, !tbaa !24
  br label %bb106
bb106:
  %t468 = load i64, ptr %l234, !tbaa !24
  store i64 %t468, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s14
  %t469 = load i64, ptr %l24, !tbaa !24
  %t470 = load i64, ptr %l23, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s14)
  br label %bb114
bb109:
  br label %bb110
bb110:
  %t477 = load i64, ptr %l20, !tbaa !24
  %t478 = load i64, ptr %l24, !tbaa !24
  %t479 = load i64, ptr %l22, !tbaa !24
  %t482 = mul i64 %t478, %t479
  %t485 = add i64 %t477, %t482
  store i64 %t485, ptr %l25, !tbaa !24
  %t487 = load ptr, ptr %l19, !tbaa !29
  %t489 = getelementptr %"compiler/ast:VarDecl", ptr %t487, i32 0, i32 1
  %t490 = load { i64, ptr }, ptr %t489, !tbaa !27
  store { i64, ptr } %t490, ptr %l256, !tbaa !27
  %t491 = load i64, ptr %l25, !tbaa !24
  %t493 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr %"compiler/source:Span", ptr %t494, i64 %t491
  %t496 = load %"compiler/source:Span", ptr %t495
  store %"compiler/source:Span" %t496, ptr %l26
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l259, !tbaa !29
  %t499 = load ptr, ptr %l1, !tbaa !29
  store ptr %t499, ptr %l260, !tbaa !29
  %t500 = load ptr, ptr %l3, !tbaa !29
  %t501 = load ptr, ptr %l19, !tbaa !29
  %t503 = getelementptr %"compiler/ast:VarDecl", ptr %t501, i32 0, i32 0
  %t504 = load { i64, ptr }, ptr %t503, !tbaa !27
  store { i64, ptr } %t504, ptr %l263, !tbaa !27
  %t505 = load i64, ptr %l25, !tbaa !24
  %t507 = getelementptr { i64, ptr }, ptr %l263, i32 0, i32 1
  %t508 = load ptr, ptr %t507, !tbaa !27
  %t509 = getelementptr i32, ptr %t508, i64 %t505
  %t510 = load i32, ptr %t509, !tbaa !33
  %t513 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t500, i32 %t510)
  store { i64, ptr } %t513, ptr %l266
  br label %bb111
bb111:
  %t514 = load i64, ptr @G_2ecompiler_2fsession_2eKindVariable, !tbaa !24
  %t515 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t516 = load i32, ptr %t515, !tbaa !23
  %t518 = sext i32 %t516 to i64
  %t519 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t520 = load i32, ptr %t519, !tbaa !23
  %t522 = sext i32 %t520 to i64
  %t523 = getelementptr %"compiler/source:Span", ptr %l26, i32 0, i32 0
  %t524 = load i32, ptr %t523, !tbaa !23
  %t526 = sext i32 %t524 to i64
  %t527 = getelementptr %"compiler/source:Span", ptr %l26, i32 0, i32 1
  %t528 = load i32, ptr %t527, !tbaa !23
  %t530 = sext i32 %t528 to i64
  %t531 = load ptr, ptr %l259, !tbaa !29
  %t532 = load ptr, ptr %l260, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l266, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s14, ptr %t531, ptr %t532, { i64, ptr } %t533, i64 %t514, i64 %t518, i64 %t522, i64 %t526, i64 %t530, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s14)
  br label %bb113
bb113:
  %t539 = load i64, ptr %l24, !tbaa !24
  %t541 = add i64 %t539, 1
  store i64 %t541, ptr %l24, !tbaa !24
  br label %bb107
bb114:
  br label %bb176
bb115:
  %t543 = load ptr, ptr %l2, !tbaa !29
  store ptr %t543, ptr %l278, !tbaa !29
  store i1 false, ptr %l279, !tbaa !21
  %t544 = load ptr, ptr %l278, !tbaa !29
  %t545 = icmp ne ptr %t544, null
  br i1 %t545, label %bb116, label %bb117
bb116:
  %t547 = load ptr, ptr %l278, !tbaa !29
  %t548 = load i64, ptr %t547, !range !{i64 0, i64 11}
  %t550 = icmp eq i64 %t548, 5
  store i1 %t550, ptr %l279, !tbaa !21
  br label %bb117
bb117:
  %t551 = load i1, ptr %l279, !tbaa !21
  br i1 %t551, label %bb118, label %bb119
bb118:
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr { i64, [6 x i64] }, ptr %t552, i32 0, i32 1
  %t555 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t554, i32 0, i32 0
  %t556 = load %"compiler/source:Span", ptr %t555
  store %"compiler/source:Span" %t556, ptr %l27
  %t558 = load ptr, ptr %l2, !tbaa !29
  %t560 = getelementptr { i64, [6 x i64] }, ptr %t558, i32 0, i32 1
  %t561 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t560, i32 0, i32 1
  %t562 = load i32, ptr %t561
  store i32 %t562, ptr %l28, !tbaa !23
  %t564 = load ptr, ptr %l2, !tbaa !29
  %t566 = getelementptr { i64, [6 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t566, i32 0, i32 2
  %t568 = load { i64, ptr }, ptr %t567
  store { i64, ptr } %t568, ptr %l29, !tbaa !27
  br label %bb120
bb119:
  br label %bb138
bb120:
  store %olang.scope zeroinitializer, ptr %s16
  %t570 = load ptr, ptr %l3, !tbaa !29
  %t571 = load i32, ptr %l28, !tbaa !23
  %t574 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t570, i32 %t571)
  store { i64, ptr } %t574, ptr %l290
  br label %bb121
bb121:
  %t575 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t575, ptr %l30, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t577 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 0
  %t578 = load i32, ptr %t577, !tbaa !23
  %t580 = sext i32 %t578 to i64
  %t581 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t585 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t576, i64 %t580, { i64, ptr } %t581)
  store i64 %t585, ptr %l295
  br label %bb122
bb122:
  %t586 = load i64, ptr %l295, !tbaa !24
  store i64 %t586, ptr %l31, !tbaa !24
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l1, !tbaa !29
  %t589 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t590 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  %t591 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 0
  %t592 = load i32, ptr %t591, !tbaa !23
  %t594 = sext i32 %t592 to i64
  %t595 = getelementptr %"compiler/source:Span", ptr %l27, i32 0, i32 1
  %t596 = load i32, ptr %t595, !tbaa !23
  %t598 = sext i32 %t596 to i64
  %t599 = load i64, ptr %l31, !tbaa !24
  %t600 = load i64, ptr %l31, !tbaa !24
  %t601 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t603 = extractvalue { i64, ptr } %t601, 0
  %t606 = add i64 %t600, %t603
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s16, ptr %t587, ptr %t588, { i64, ptr } %t589, i64 %t590, i64 %t594, i64 %t598, i64 %t599, i64 %t606, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb123
bb123:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/session:symWriter", ptr %t615, i32 0, i32 0
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t620 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s16, ptr %t618)
  store %"compiler/session:symWriter" %t620, ptr %l311
  br label %bb124
bb124:
  %t621 = load %"compiler/session:symWriter", ptr %l311
  store %"compiler/session:symWriter" %t621, ptr %l32
  %t622 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t622, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t624 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t626 = extractvalue { i64, ptr } %t624, 0
  store i64 %t626, ptr %l35, !tbaa !24
  br label %bb125
bb125:
  %t628 = load i64, ptr %l34, !tbaa !24
  %t629 = load i64, ptr %l35, !tbaa !24
  %t632 = icmp slt i64 %t628, %t629
  %t634 = xor i1 %t632, true
  br i1 %t634, label %bb126, label %bb127
bb126:
  br label %bb136
bb127:
  br label %bb128
bb128:
  %t636 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t636, ptr %l319, !tbaa !27
  %t637 = load i64, ptr %l34, !tbaa !24
  %t639 = getelementptr { i64, ptr }, ptr %l319, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = getelementptr i32, ptr %t640, i64 %t637
  %t642 = load i32, ptr %t641, !tbaa !33
  %t644 = load ptr, ptr %l3, !tbaa !29
  %t648 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t644, i32 %t642)
  store { i64, ptr } %t648, ptr %l324
  br label %bb129
bb129:
  %t649 = load { i64, ptr }, ptr %l324, !tbaa !27
  store { i64, ptr } %t649, ptr %l37, !tbaa !27
  %t650 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t651 = load i64, ptr %l31, !tbaa !24
  %t652 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t657 = add i64 %t651, %t654
  %t658 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t662 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v3, { i64, ptr } %t650, i64 %t657, { i64, ptr } %t658)
  store i64 %t662, ptr %l331
  br label %bb130
bb130:
  %t663 = load i64, ptr %l331, !tbaa !24
  store i64 %t663, ptr %l38, !tbaa !24
  %t664 = load i64, ptr %l38, !tbaa !24
  %t666 = icmp sge i64 %t664, 0
  br i1 %t666, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s19
  %t668 = load ptr, ptr %l1, !tbaa !29
  %t669 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t670 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t671 = load i64, ptr %l38, !tbaa !24
  %t672 = load i64, ptr %l38, !tbaa !24
  %t673 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t673, 0
  %t678 = add i64 %t672, %t675
  %t679 = load i64, ptr %l38, !tbaa !24
  %t680 = load i64, ptr %l38, !tbaa !24
  %t681 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t681, 0
  %t686 = add i64 %t680, %t683
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %s16, ptr %v1, ptr %v3, ptr %s19, ptr %l32, ptr %t668, { i64, ptr } %t669, i64 %t670, i64 %t671, i64 %t678, i64 %t679, i64 %t686, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_scope_close(ptr %s19)
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t695 = load i64, ptr %l34, !tbaa !24
  %t697 = add i64 %t695, 1
  store i64 %t697, ptr %l34, !tbaa !24
  br label %bb125
bb136:
  %t699 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t699, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s16)
  br label %bb176
bb138:
  %t701 = load ptr, ptr %l2, !tbaa !29
  store ptr %t701, ptr %l351, !tbaa !29
  store i1 false, ptr %l352, !tbaa !21
  %t702 = load ptr, ptr %l351, !tbaa !29
  %t703 = icmp ne ptr %t702, null
  br i1 %t703, label %bb139, label %bb140
bb139:
  %t705 = load ptr, ptr %l351, !tbaa !29
  %t706 = load i64, ptr %t705, !range !{i64 0, i64 11}
  %t708 = icmp eq i64 %t706, 6
  store i1 %t708, ptr %l352, !tbaa !21
  br label %bb140
bb140:
  %t709 = load i1, ptr %l352, !tbaa !21
  br i1 %t709, label %bb141, label %bb142
bb141:
  %t710 = load ptr, ptr %l2, !tbaa !29
  %t712 = getelementptr { i64, [6 x i64] }, ptr %t710, i32 0, i32 1
  %t713 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t712, i32 0, i32 0
  %t714 = load %"compiler/source:Span", ptr %t713
  store %"compiler/source:Span" %t714, ptr %l39
  %t716 = load ptr, ptr %l2, !tbaa !29
  %t718 = getelementptr { i64, [6 x i64] }, ptr %t716, i32 0, i32 1
  %t719 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t718, i32 0, i32 1
  %t720 = load %"compiler/source:Span", ptr %t719
  store %"compiler/source:Span" %t720, ptr %l40
  br label %bb143
bb142:
  br label %bb151
bb143:
  store %olang.scope zeroinitializer, ptr %s21
  %t722 = load ptr, ptr %l0, !tbaa !29
  store ptr %t722, ptr %l359, !tbaa !29
  %t723 = load ptr, ptr %l1, !tbaa !29
  store ptr %t723, ptr %l360, !tbaa !29
  %t724 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t724, ptr %l361, !tbaa !27
  %t725 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 0
  %t726 = load i32, ptr %t725, !tbaa !23
  %t728 = sext i32 %t726 to i64
  store i64 %t728, ptr %l363, !tbaa !24
  %t729 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 1
  %t730 = load i32, ptr %t729, !tbaa !23
  %t732 = sext i32 %t730 to i64
  store i64 %t732, ptr %l365, !tbaa !24
  %t733 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t734 = extractvalue { i64, ptr } %t733, 0
  store i64 %t734, ptr %l366, !tbaa !24
  %t735 = load i64, ptr %l363, !tbaa !24
  %t736 = icmp sge i64 %t735, 0
  br i1 %t736, label %bb144, label %bb145
bb144:
  %t738 = load i64, ptr %l363, !tbaa !24
  %t739 = load i64, ptr %l365, !tbaa !24
  %t740 = icmp sle i64 %t738, %t739
  br i1 %t740, label %bb146, label %bb147
bb145:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb146:
  %t742 = load i64, ptr %l365, !tbaa !24
  %t743 = load i64, ptr %l366, !tbaa !24
  %t744 = icmp sle i64 %t742, %t743
  br i1 %t744, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb148:
  %t746 = getelementptr { i64, ptr }, ptr %l361, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !27
  %t748 = load i64, ptr %l363, !tbaa !24
  %t749 = load i64, ptr %l365, !tbaa !24
  %t750 = getelementptr i8, ptr %t747, i64 %t748
  %t751 = sub i64 %t749, %t748
  %t752 = insertvalue { i64, ptr } undef, i64 %t751, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t750, 1
  %t754 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t755 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t757 = extractvalue { i64, ptr } %t753, 1
  %t758 = extractvalue { i64, ptr } %t753, 0
  %t759 = add i64 %t755, %t758
  %t760 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t759)
  call void @olang_textcopy(ptr %t760, ptr %t754, i64 %t755)
  %t761 = getelementptr i8, ptr %t760, i64 %t755
  call void @olang_textcopy(ptr %t761, ptr %t757, i64 %t758)
  %t762 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t763 = insertvalue { i64, ptr } %t762, ptr %t760, 1
  %t765 = extractvalue { i64, ptr } %t763, 0
  %t766 = extractvalue { i64, ptr } %t763, 1
  %t767 = mul i64 %t765, 1
  %t768 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t767)
  call void @llvm.memcpy.p0.p0.i64(ptr %t768, ptr %t766, i64 %t767, i1 false)
  %t769 = insertvalue { i64, ptr } undef, i64 %t765, 0
  %t770 = insertvalue { i64, ptr } %t769, ptr %t768, 1
  %t771 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  %t772 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 0
  %t773 = load i32, ptr %t772, !tbaa !23
  %t775 = sext i32 %t773 to i64
  %t776 = getelementptr %"compiler/source:Span", ptr %l39, i32 0, i32 1
  %t777 = load i32, ptr %t776, !tbaa !23
  %t779 = sext i32 %t777 to i64
  %t780 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 0
  %t781 = load i32, ptr %t780, !tbaa !23
  %t783 = sext i32 %t781 to i64
  %t784 = getelementptr %"compiler/source:Span", ptr %l40, i32 0, i32 1
  %t785 = load i32, ptr %t784, !tbaa !23
  %t787 = sext i32 %t785 to i64
  %t788 = load ptr, ptr %l359, !tbaa !29
  %t789 = load ptr, ptr %l360, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %s21, ptr %s21, ptr %t788, ptr %t789, { i64, ptr } %t770, i64 %t771, i64 %t775, i64 %t779, i64 %t783, i64 %t787, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_52dc430f3488fa77_8026fac3ef739783)
  unreachable
bb150:
  call void @__olang_scope_close(ptr %s21)
  br label %bb176
bb151:
  %t796 = load ptr, ptr %l2, !tbaa !29
  store ptr %t796, ptr %l382, !tbaa !29
  store i1 false, ptr %l383, !tbaa !21
  %t797 = load ptr, ptr %l382, !tbaa !29
  %t798 = icmp ne ptr %t797, null
  br i1 %t798, label %bb152, label %bb153
bb152:
  %t800 = load ptr, ptr %l382, !tbaa !29
  %t801 = load i64, ptr %t800, !range !{i64 0, i64 11}
  %t803 = icmp eq i64 %t801, 7
  store i1 %t803, ptr %l383, !tbaa !21
  br label %bb153
bb153:
  %t804 = load i1, ptr %l383, !tbaa !21
  br i1 %t804, label %bb154, label %bb155
bb154:
  %t805 = load ptr, ptr %l2, !tbaa !29
  %t807 = getelementptr { i64, [6 x i64] }, ptr %t805, i32 0, i32 1
  %t808 = getelementptr { %"compiler/source:Span", ptr }, ptr %t807, i32 0, i32 1
  %t809 = load ptr, ptr %t808
  store ptr %t809, ptr %l41, !tbaa !29
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t811 = load ptr, ptr %l0, !tbaa !29
  %t812 = load ptr, ptr %l1, !tbaa !29
  %t813 = load ptr, ptr %l41, !tbaa !29
  %t815 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t811, ptr %t812, ptr %t813, ptr %t815)
  br label %bb157
bb157:
  br label %bb176
bb158:
  %t820 = load ptr, ptr %l2, !tbaa !29
  store ptr %t820, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t821 = load ptr, ptr %l393, !tbaa !29
  %t822 = icmp ne ptr %t821, null
  br i1 %t822, label %bb159, label %bb160
bb159:
  %t824 = load ptr, ptr %l393, !tbaa !29
  %t825 = load i64, ptr %t824, !range !{i64 0, i64 11}
  %t827 = icmp eq i64 %t825, 10
  store i1 %t827, ptr %l394, !tbaa !21
  br label %bb160
bb160:
  %t828 = load i1, ptr %l394, !tbaa !21
  br i1 %t828, label %bb161, label %bb162
bb161:
  %t829 = load ptr, ptr %l2, !tbaa !29
  %t831 = getelementptr { i64, [6 x i64] }, ptr %t829, i32 0, i32 1
  %t832 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t831, i32 0, i32 2
  %t833 = load { i64, ptr }, ptr %t832
  store { i64, ptr } %t833, ptr %l42, !tbaa !27
  br label %bb163
bb162:
  br label %bb171
bb163:
  %t835 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t835, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t837 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t839 = extractvalue { i64, ptr } %t837, 0
  store i64 %t839, ptr %l45, !tbaa !24
  br label %bb164
bb164:
  %t841 = load i64, ptr %l44, !tbaa !24
  %t842 = load i64, ptr %l45, !tbaa !24
  %t845 = icmp slt i64 %t841, %t842
  %t847 = xor i1 %t845, true
  br i1 %t847, label %bb165, label %bb166
bb165:
  br label %bb170
bb166:
  br label %bb167
bb167:
  %t849 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t849, ptr %l406, !tbaa !27
  %t850 = load i64, ptr %l44, !tbaa !24
  %t852 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t853 = load ptr, ptr %t852, !tbaa !27
  %t854 = getelementptr ptr, ptr %t853, i64 %t850
  %t855 = load ptr, ptr %t854, !tbaa !39
  %t857 = load ptr, ptr %l0, !tbaa !29
  %t858 = load ptr, ptr %l1, !tbaa !29
  %t860 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t857, ptr %t858, ptr %t855, ptr %t860)
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t865 = load i64, ptr %l44, !tbaa !24
  %t867 = add i64 %t865, 1
  store i64 %t867, ptr %l44, !tbaa !24
  br label %bb164
bb170:
  br label %bb176
bb171:
  br i1 true, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd)
  unreachable
bb176:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8) #0 {
entry:
  %l1 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %t2, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8)
  br label %bb1
bb1:
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t19, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l122 = alloca ptr
  %l123 = alloca i1
  %l135 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l176 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l188 = alloca i64
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t10 = load ptr, ptr %l35, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l35, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 5}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l36, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [6 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/ast:StructBody", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = getelementptr %"compiler/ast:StructBody", ptr %t33, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l53, !tbaa !27
  %t51 = load i64, ptr %l7, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l9, !tbaa !29
  %t58 = load ptr, ptr %l9, !tbaa !29
  store ptr %t58, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l56, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 22}
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l57, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l57, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l9, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l10
  %t75 = load ptr, ptr %l9, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t81 = load ptr, ptr %l11, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t81, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t89 = load i64, ptr %l13, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load i64, ptr %l14, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb23
bb20:
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l75, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb22
bb22:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l72, !tbaa !24
  br label %bb23
bb23:
  %t116 = load i64, ptr %l72, !tbaa !24
  store i64 %t116, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load i64, ptr %l16, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l17, !tbaa !24
  %t135 = load ptr, ptr %l11, !tbaa !29
  %t138 = getelementptr %"compiler/ast:VarDecl", ptr %t135, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l95, !tbaa !27
  %t140 = load i64, ptr %l17, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/source:Span", ptr %t143, i64 %t140
  %t145 = load %"compiler/source:Span", ptr %t144
  store %"compiler/source:Span" %t145, ptr %l18
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l98, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l99, !tbaa !29
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t150 = load ptr, ptr %l11, !tbaa !29
  %t153 = getelementptr %"compiler/ast:VarDecl", ptr %t150, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l103, !tbaa !27
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t163 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t149, i32 %t160)
  store { i64, ptr } %t163, ptr %l106
  br label %bb28
bb28:
  %t164 = load i64, ptr @G_2ecompiler_2fsession_2eKindField, !tbaa !24
  %t165 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t165, ptr %l108
  %t166 = getelementptr %"compiler/source:Span", ptr %l108, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t170 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t170, ptr %l111
  %t171 = getelementptr %"compiler/source:Span", ptr %l111, i32 0, i32 1
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t179 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l98, !tbaa !29
  %t184 = load ptr, ptr %l99, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l106, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s7, ptr %t183, ptr %t184, { i64, ptr } %t185, i64 %t164, i64 %t169, i64 %t174, i64 %t178, i64 %t182, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t193 = add i64 %t191, 1
  store i64 %t193, ptr %l16, !tbaa !24
  br label %bb24
bb31:
  br label %bb32
bb32:
  %t195 = load i64, ptr %l7, !tbaa !24
  %t197 = add i64 %t195, 1
  store i64 %t197, ptr %l7, !tbaa !24
  br label %bb9
bb33:
  br label %bb68
bb34:
  %t199 = load ptr, ptr %l2, !tbaa !29
  store ptr %t199, ptr %l122, !tbaa !29
  store i1 false, ptr %l123, !tbaa !21
  %t200 = load ptr, ptr %l122, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb35, label %bb36
bb35:
  %t203 = load ptr, ptr %l122, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 5}
  %t206 = icmp eq i64 %t204, 1
  store i1 %t206, ptr %l123, !tbaa !21
  br label %bb36
bb36:
  %t207 = load i1, ptr %l123, !tbaa !21
  br i1 %t207, label %bb37, label %bb38
bb37:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t210 = getelementptr { i64, [6 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { { i64, ptr }, ptr }, ptr %t210, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211
  store { i64, ptr } %t212, ptr %l19, !tbaa !27
  br label %bb39
bb38:
  br label %bb48
bb39:
  %t214 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t214, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t216 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t216, 0
  store i64 %t218, ptr %l22, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t220 = load i64, ptr %l21, !tbaa !24
  %t221 = load i64, ptr %l22, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s12)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t228 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t228, ptr %l135, !tbaa !27
  %t229 = load i64, ptr %l21, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr ptr, ptr %t232, i64 %t229
  %t234 = load ptr, ptr %t233, !tbaa !39
  store ptr %t234, ptr %l23, !tbaa !29
  %t236 = load ptr, ptr %l3, !tbaa !29
  %t237 = load ptr, ptr %l23, !tbaa !29
  %t239 = getelementptr %"compiler/ast:CaseDecl", ptr %t237, i32 0, i32 1
  %t240 = load i32, ptr %t239, !tbaa !23
  %t243 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t236, i32 %t240)
  store { i64, ptr } %t243, ptr %l141
  br label %bb44
bb44:
  %t244 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t244, ptr %l24, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t248 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t249 = load ptr, ptr %l23, !tbaa !29
  %t251 = getelementptr %"compiler/ast:CaseDecl", ptr %t249, i32 0, i32 0
  %t252 = getelementptr %"compiler/source:Span", ptr %t251, i32 0, i32 0
  %t253 = load i32, ptr %t252, !tbaa !23
  %t255 = sext i32 %t253 to i64
  %t256 = load ptr, ptr %l23, !tbaa !29
  %t258 = getelementptr %"compiler/ast:CaseDecl", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 1
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  %t263 = load ptr, ptr %l23, !tbaa !29
  %t265 = getelementptr %"compiler/ast:CaseDecl", ptr %t263, i32 0, i32 0
  %t266 = getelementptr %"compiler/source:Span", ptr %t265, i32 0, i32 0
  %t267 = load i32, ptr %t266, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t270 = load ptr, ptr %l23, !tbaa !29
  %t272 = getelementptr %"compiler/ast:CaseDecl", ptr %t270, i32 0, i32 0
  %t273 = getelementptr %"compiler/source:Span", ptr %t272, i32 0, i32 0
  %t274 = load i32, ptr %t273, !tbaa !23
  %t276 = sext i32 %t274 to i64
  %t277 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t282 = add i64 %t276, %t279
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s12, ptr %t245, ptr %t246, { i64, ptr } %t247, i64 %t248, i64 %t255, i64 %t262, i64 %t269, i64 %t282, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb46:
  %t291 = load i64, ptr %l21, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l21, !tbaa !24
  br label %bb40
bb47:
  br label %bb68
bb48:
  %t295 = load ptr, ptr %l2, !tbaa !29
  store ptr %t295, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t296 = load ptr, ptr %l163, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb49, label %bb50
bb49:
  %t299 = load ptr, ptr %l163, !tbaa !29
  %t300 = load i64, ptr %t299, !range !{i64 0, i64 5}
  %t302 = icmp eq i64 %t300, 2
  store i1 %t302, ptr %l164, !tbaa !21
  br label %bb50
bb50:
  %t303 = load i1, ptr %l164, !tbaa !21
  br i1 %t303, label %bb51, label %bb52
bb51:
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = getelementptr { i64, [6 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t306, i32 0, i32 0
  %t308 = load { i64, ptr }, ptr %t307
  store { i64, ptr } %t308, ptr %l25, !tbaa !27
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t310 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t310, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t312 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t312, 0
  store i64 %t314, ptr %l28, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s16
  %t316 = load i64, ptr %l27, !tbaa !24
  %t317 = load i64, ptr %l28, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s16)
  br label %bb62
bb56:
  br label %bb57
bb57:
  %t324 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t324, ptr %l176, !tbaa !27
  %t325 = load i64, ptr %l27, !tbaa !24
  %t327 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr ptr, ptr %t328, i64 %t325
  %t330 = load ptr, ptr %t329, !tbaa !39
  store ptr %t330, ptr %l29, !tbaa !29
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t333 = load ptr, ptr %l29, !tbaa !29
  %t335 = getelementptr %"compiler/ast:Func", ptr %t333, i32 0, i32 2
  %t336 = load i32, ptr %t335, !tbaa !23
  %t339 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t332, i32 %t336)
  store { i64, ptr } %t339, ptr %l182
  br label %bb58
bb58:
  %t340 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t340, ptr %l30, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t342 = load ptr, ptr %l29, !tbaa !29
  %t344 = getelementptr %"compiler/ast:Func", ptr %t342, i32 0, i32 0
  %t345 = getelementptr %"compiler/source:Span", ptr %t344, i32 0, i32 0
  %t346 = load i32, ptr %t345, !tbaa !23
  %t348 = sext i32 %t346 to i64
  %t349 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t353 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t341, i64 %t348, { i64, ptr } %t349)
  store i64 %t353, ptr %l188
  br label %bb59
bb59:
  %t354 = load i64, ptr %l188, !tbaa !24
  store i64 %t354, ptr %l31, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t357 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t358 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  %t359 = load ptr, ptr %l29, !tbaa !29
  %t361 = getelementptr %"compiler/ast:Func", ptr %t359, i32 0, i32 0
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t366 = load ptr, ptr %l29, !tbaa !29
  %t368 = getelementptr %"compiler/ast:Func", ptr %t366, i32 0, i32 0
  %t369 = getelementptr %"compiler/source:Span", ptr %t368, i32 0, i32 1
  %t370 = load i32, ptr %t369, !tbaa !23
  %t372 = sext i32 %t370 to i64
  %t373 = load i64, ptr %l31, !tbaa !24
  %t374 = load i64, ptr %l31, !tbaa !24
  %t375 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t375, 0
  %t380 = add i64 %t374, %t377
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s16, ptr %t355, ptr %t356, { i64, ptr } %t357, i64 %t358, i64 %t365, i64 %t372, i64 %t373, i64 %t380, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s16)
  br label %bb61
bb61:
  %t389 = load i64, ptr %l27, !tbaa !24
  %t391 = add i64 %t389, 1
  store i64 %t391, ptr %l27, !tbaa !24
  br label %bb54
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_59453385dbeab0f1_a10e94e6ba58edc5)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l17 = alloca ptr
  %l19 = alloca i1
  %l21 = alloca { i64, ptr }
  %l39 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t8, i8 44)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l13, !tbaa !29
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = getelementptr %"compiler/session:symWriter", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = add i64 %t13, 1
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = getelementptr %"compiler/session:symWriter", ptr %t17, i32 0, i32 1
  store i64 %t15, ptr %t18, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t19, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l17, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t24, ptr %l19
  br label %bb6
bb6:
  %t25 = load i1, ptr %l19, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v2, ptr %t30, { i64, ptr } %t31)
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %a3)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %a3)
  %t45 = getelementptr i8, ptr %t43, i64 %t37
  call void @olang_textcopy(ptr %t45, ptr %t39, i64 %t40)
  %t46 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t42, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t32, { i64, ptr } %t54)
  br label %bb11
bb11:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/session:symWriter", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %t60, ptr %t61, i64 %a4, i64 %a5)
  br label %bb12
bb12:
  %t68 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t68, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/session:symWriter", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3aPositions_2eRange(ptr %v0, ptr %v1, ptr %t73, ptr %t74, i64 %a6, i64 %a7)
  br label %bb14
bb14:
  %t81 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s0, { i64, ptr } %t81, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t83, ptr %l39
  br label %bb15
bb15:
  %t84 = load i1, ptr %l39, !tbaa !21
  %t85 = xor i1 %t84, true
  br i1 %t85, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t87 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t87, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2fsession_2eJsonStr(ptr %v1, ptr %v3, ptr %t89, { i64, ptr } %t90)
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t93, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d99, i32 0, i32 1) })
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i1
  %l41 = alloca { i64, ptr }
  %l59 = alloca i1
  %l82 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5)
  unreachable
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopIf", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TopBranch", ptr %t24, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sgt i64 %t30, 0
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb12, label %bb13
bb11:
  br label %bb22
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7c90741a89491e92_62c7d4207901162e)
  unreachable
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TopIf", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TopBranch", ptr %t45, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t63, ptr %l41, !tbaa !27
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr ptr, ptr %t67, i64 %t64
  %t69 = load ptr, ptr %t68, !tbaa !39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t71, ptr %t72, ptr %t69, ptr %t74)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/ast:TopIf", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t83, ptr %t84, ptr %t88, ptr %t89)
  br label %bb23
bb23:
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr %"compiler/ast:TopIf", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb24, label %bb25
bb24:
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/ast:TopIf", ptr %t103, i32 0, i32 3
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f)
  unreachable
bb27:
  br label %bb28
bb28:
  %t110 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/ast:TopIf", ptr %t110, i32 0, i32 3
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopBranch", ptr %t113, i32 0, i32 1
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t121 = icmp sgt i64 %t119, 0
  store i1 %t121, ptr %l59, !tbaa !21
  br label %bb29
bb29:
  %t123 = load i1, ptr %l59, !tbaa !21
  br i1 %t123, label %bb30, label %bb31
bb30:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr %"compiler/ast:TopIf", ptr %t124, i32 0, i32 3
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb32, label %bb33
bb31:
  br label %bb42
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0)
  unreachable
bb33:
  br label %bb34
bb34:
  %t131 = load ptr, ptr %l2, !tbaa !29
  %t133 = getelementptr %"compiler/ast:TopIf", ptr %t131, i32 0, i32 3
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t137 = getelementptr %"compiler/ast:TopBranch", ptr %t134, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t144 = load i64, ptr %l9, !tbaa !24
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t152, ptr %l82, !tbaa !27
  %t153 = load i64, ptr %l9, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t160, ptr %t161, ptr %t158, ptr %t163)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l9, !tbaa !24
  br label %bb35
bb41:
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l85 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l107 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca i1
  %l128 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca i1
  %l146 = alloca ptr
  %l147 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l211 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l215 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l37
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l39
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l35, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l37
  %t14 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %t12, %"compiler/source:Span" %t13, i32 %t14)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t16 = load ptr, ptr %l40, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l40, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l41, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb19
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t31 = load ptr, ptr %l46, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l46, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l47, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l2, !tbaa !29
  br label %bb19
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t46 = load ptr, ptr %l52, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l52, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l53, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb20
bb20:
  br label %bb133
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t66 = load ptr, ptr %l61, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l61, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 18}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l62, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l62, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Promote", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb27
bb27:
  br label %bb133
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t89 = load ptr, ptr %l71, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l71, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 6
  store i1 %t95, ptr %l72, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l72, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb41
bb33:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Call", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb34
bb34:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb35, label %bb36
bb35:
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t120, ptr %l85, !tbaa !27
  %t121 = load i64, ptr %l6, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t126)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb34
bb40:
  br label %bb133
bb41:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t138 = load ptr, ptr %l93, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb42, label %bb43
bb42:
  %t141 = load ptr, ptr %l93, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 7
  store i1 %t144, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t145 = load i1, ptr %l94, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l9, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Make", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  %t161 = load i64, ptr %l11, !tbaa !24
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = icmp slt i64 %t161, %t162
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t169 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t169, ptr %l107, !tbaa !27
  %t170 = load i64, ptr %l11, !tbaa !24
  %t172 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr ptr, ptr %t173, i64 %t170
  %t175 = load ptr, ptr %t174, !tbaa !39
  %t177 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t177, ptr %t175)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t182 = load i64, ptr %l11, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l11, !tbaa !24
  br label %bb47
bb53:
  br label %bb133
bb54:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t187 = load ptr, ptr %l115, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb55, label %bb56
bb55:
  %t190 = load ptr, ptr %l115, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 18}
  %t193 = icmp eq i64 %t191, 9
  store i1 %t193, ptr %l116, !tbaa !21
  br label %bb56
bb56:
  %t194 = load i1, ptr %l116, !tbaa !21
  br i1 %t194, label %bb57, label %bb58
bb57:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t197, i32 0, i32 4
  %t199 = load { i64, ptr }, ptr %t198
  store { i64, ptr } %t199, ptr %l14, !tbaa !27
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t201 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t201, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  %t207 = load i64, ptr %l16, !tbaa !24
  %t208 = load i64, ptr %l17, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t215 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t215, ptr %l128, !tbaa !27
  %t216 = load i64, ptr %l16, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 %t216
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t223 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t221)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t228 = load i64, ptr %l16, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l16, !tbaa !24
  br label %bb60
bb66:
  br label %bb133
bb67:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t233 = load ptr, ptr %l136, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l136, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 10
  store i1 %t239, ptr %l137, !tbaa !21
  br label %bb69
bb69:
  %t240 = load i1, ptr %l137, !tbaa !21
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 2
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l19, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l19, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Slice", ptr %t248, i32 0, i32 0
  %t251 = load ptr, ptr %t250, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t247, ptr %t251)
  br label %bb73
bb73:
  br label %bb133
bb74:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t256 = load ptr, ptr %l146, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb75, label %bb76
bb75:
  %t259 = load ptr, ptr %l146, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 18}
  %t262 = icmp eq i64 %t260, 11
  store i1 %t262, ptr %l147, !tbaa !21
  br label %bb76
bb76:
  %t263 = load i1, ptr %l147, !tbaa !21
  br i1 %t263, label %bb77, label %bb78
bb77:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [5 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l20, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load ptr, ptr %l20, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Cond", ptr %t271, i32 0, i32 0
  %t274 = load ptr, ptr %t273, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t270, ptr %t274)
  br label %bb80
bb80:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l20, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Cond", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t278, ptr %t282)
  br label %bb81
bb81:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l20, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Cond", ptr %t286, i32 0, i32 2
  %t289 = load ptr, ptr %t288, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t285, ptr %t289)
  br label %bb82
bb82:
  br label %bb133
bb83:
  %t293 = load ptr, ptr %l1, !tbaa !29
  store ptr %t293, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t294 = load ptr, ptr %l163, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb84, label %bb85
bb84:
  %t297 = load ptr, ptr %l163, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 18}
  %t300 = icmp eq i64 %t298, 12
  store i1 %t300, ptr %l164, !tbaa !21
  br label %bb85
bb85:
  %t301 = load i1, ptr %l164, !tbaa !21
  br i1 %t301, label %bb86, label %bb87
bb86:
  %t302 = load ptr, ptr %l1, !tbaa !29
  %t304 = getelementptr { i64, [5 x i64] }, ptr %t302, i32 0, i32 1
  %t305 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t304, i32 0, i32 2
  %t306 = load ptr, ptr %t305
  store ptr %t306, ptr %l21, !tbaa !29
  br label %bb88
bb87:
  br label %bb97
bb88:
  %t308 = load ptr, ptr %l21, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Seq", ptr %t308, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  store { i64, ptr } %t311, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  store i64 %t315, ptr %l24, !tbaa !24
  br label %bb89
bb89:
  %t317 = load i64, ptr %l23, !tbaa !24
  %t318 = load i64, ptr %l24, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t325 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t325, ptr %l177, !tbaa !27
  %t326 = load i64, ptr %l23, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  %t333 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %t333, ptr %t331)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t338 = load i64, ptr %l23, !tbaa !24
  %t340 = add i64 %t338, 1
  store i64 %t340, ptr %l23, !tbaa !24
  br label %bb89
bb95:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l21, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Seq", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346)
  br label %bb96
bb96:
  br label %bb133
bb97:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t350 = load ptr, ptr %l188, !tbaa !29
  %t351 = icmp ne ptr %t350, null
  br i1 %t351, label %bb98, label %bb99
bb98:
  %t353 = load ptr, ptr %l188, !tbaa !29
  %t354 = load i64, ptr %t353, !range !{i64 0, i64 18}
  %t356 = icmp eq i64 %t354, 14
  store i1 %t356, ptr %l189, !tbaa !21
  br label %bb99
bb99:
  %t357 = load i1, ptr %l189, !tbaa !21
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t358 = load ptr, ptr %l1, !tbaa !29
  %t360 = getelementptr { i64, [5 x i64] }, ptr %t358, i32 0, i32 1
  %t361 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t360, i32 0, i32 2
  %t362 = load ptr, ptr %t361
  store ptr %t362, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l26, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Try", ptr %t365, i32 0, i32 0
  %t368 = load ptr, ptr %t367, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t364, ptr %t368)
  br label %bb103
bb103:
  br label %bb133
bb104:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t372 = load ptr, ptr %l197, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb105, label %bb106
bb105:
  %t375 = load ptr, ptr %l197, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 16
  store i1 %t378, ptr %l198, !tbaa !21
  br label %bb106
bb106:
  %t379 = load i1, ptr %l198, !tbaa !21
  br i1 %t379, label %bb107, label %bb108
bb107:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l27, !tbaa !29
  br label %bb109
bb108:
  br label %bb128
bb109:
  %t386 = load ptr, ptr %l27, !tbaa !29
  %t388 = getelementptr %"compiler/typed:Text", ptr %t386, i32 0, i32 0
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t391 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t391, 0
  store i64 %t393, ptr %l30, !tbaa !24
  br label %bb110
bb110:
  %t395 = load i64, ptr %l29, !tbaa !24
  %t396 = load i64, ptr %l30, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb111, label %bb112
bb111:
  br label %bb127
bb112:
  br label %bb113
bb113:
  %t403 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t403, ptr %l211, !tbaa !27
  %t404 = load i64, ptr %l29, !tbaa !24
  %t406 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr ptr, ptr %t407, i64 %t404
  %t409 = load ptr, ptr %t408, !tbaa !39
  store ptr %t409, ptr %l31, !tbaa !29
  %t411 = load ptr, ptr %l31, !tbaa !29
  store ptr %t411, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t412 = load ptr, ptr %l214, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb114, label %bb115
bb114:
  %t415 = load ptr, ptr %l214, !tbaa !29
  %t416 = load i64, ptr %t415, !range !{i64 0, i64 2}
  %t418 = icmp eq i64 %t416, 1
  store i1 %t418, ptr %l215, !tbaa !21
  br label %bb115
bb115:
  %t419 = load i1, ptr %l215, !tbaa !21
  br i1 %t419, label %bb116, label %bb117
bb116:
  %t420 = load ptr, ptr %l31, !tbaa !29
  %t422 = getelementptr { i64, [2 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { ptr }, ptr %t422, i32 0, i32 0
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l32, !tbaa !29
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t426, ptr %t427)
  br label %bb119
bb119:
  br label %bb125
bb120:
  br i1 true, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_df797fad9b49105d_2a8f7c5ad36c2889)
  unreachable
bb125:
  br label %bb126
bb126:
  %t431 = load i64, ptr %l29, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l29, !tbaa !24
  br label %bb110
bb127:
  br label %bb133
bb128:
  br i1 true, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_d2b15075f36d8dac_250aaa3debc302b8)
  unreachable
bb133:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l11
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l13
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l11
  %t14 = load i32, ptr %l13, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %t12, %"compiler/source:Span" %t13, i32 %t14)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t16 = load ptr, ptr %l14, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t30, ptr %t31)
  br label %bb12
bb12:
  br label %bb47
bb13:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 8}
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb16, label %bb17
bb16:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t50, ptr %t51)
  br label %bb19
bb19:
  br label %bb47
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l32, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t70, ptr %t74)
  br label %bb26
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t78, ptr %t82)
  br label %bb27
bb27:
  br label %bb47
bb28:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t87 = load ptr, ptr %l46, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t94 = load i1, ptr %l47, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l5, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Payload", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t101, ptr %t105)
  br label %bb34
bb34:
  br label %bb47
bb35:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb36, label %bb37
bb36:
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 8}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l57, !tbaa !21
  br label %bb37
bb37:
  %t117 = load i1, ptr %l57, !tbaa !21
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l6, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  br label %bb41
bb41:
  br label %bb47
bb42:
  br i1 true, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_8ea8ca70496d6921_977884330ce8ec6d)
  unreachable
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l133 = alloca ptr
  %l134 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t6 = load ptr, ptr %l16, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l16, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 17}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l17, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [3 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  br label %bb9
bb9:
  br label %bb92
bb10:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t26 = load ptr, ptr %l25, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l25, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 17}
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l26, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t46, ptr %t47)
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t51, ptr %t52)
  br label %bb17
bb17:
  br label %bb92
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  store ptr %t56, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t57 = load ptr, ptr %l39, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l39, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 17}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l40, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr { i64, [3 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", ptr }, ptr %t67, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l5, !tbaa !29
  br label %bb35
bb22:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t72 = load ptr, ptr %l45, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 17}
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t79 = load i1, ptr %l46, !tbaa !21
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [3 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", ptr }, ptr %t82, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb35
bb26:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t87 = load ptr, ptr %l51, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb27, label %bb28
bb27:
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 15
  store i1 %t93, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t94 = load i1, ptr %l52, !tbaa !21
  br i1 %t94, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  br label %bb35
bb30:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t102 = load ptr, ptr %l57, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb31, label %bb32
bb31:
  %t105 = load ptr, ptr %l57, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 17}
  %t108 = icmp eq i64 %t106, 16
  store i1 %t108, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [3 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", ptr }, ptr %t112, i32 0, i32 1
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l5, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  br label %bb36
bb36:
  br label %bb92
bb37:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t121 = load ptr, ptr %l65, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t124 = load ptr, ptr %l65, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 17}
  %t127 = icmp eq i64 %t125, 3
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb39
bb39:
  %t128 = load i1, ptr %l66, !tbaa !21
  br i1 %t128, label %bb40, label %bb41
bb40:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr }, ptr %t131, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l6, !tbaa !29
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t135, ptr %t139)
  br label %bb43
bb43:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t146 = getelementptr %"compiler/typed:If", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t143, ptr %t147)
  br label %bb44
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l6, !tbaa !29
  %t154 = getelementptr %"compiler/typed:If", ptr %t152, i32 0, i32 2
  %t155 = load ptr, ptr %t154, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t151, ptr %t155)
  br label %bb45
bb45:
  br label %bb92
bb46:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t159 = load ptr, ptr %l82, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb47, label %bb48
bb47:
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 17}
  %t165 = icmp eq i64 %t163, 4
  store i1 %t165, ptr %l83, !tbaa !21
  br label %bb48
bb48:
  %t166 = load i1, ptr %l83, !tbaa !21
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l7, !tbaa !29
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t179, ptr %t180)
  br label %bb52
bb52:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb53
bb53:
  br label %bb92
bb54:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t189 = load ptr, ptr %l95, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l95, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 17}
  %t195 = icmp eq i64 %t193, 10
  store i1 %t195, ptr %l96, !tbaa !21
  br label %bb56
bb56:
  %t196 = load i1, ptr %l96, !tbaa !21
  br i1 %t196, label %bb57, label %bb58
bb57:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [3 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t199, i32 0, i32 1
  %t201 = load ptr, ptr %t200
  store ptr %t201, ptr %l9, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t205, i32 0, i32 2
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l10, !tbaa !29
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t209, ptr %t210)
  br label %bb60
bb60:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t214, ptr %t215)
  br label %bb61
bb61:
  br label %bb92
bb62:
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t219 = load ptr, ptr %l108, !tbaa !29
  %t220 = icmp ne ptr %t219, null
  br i1 %t220, label %bb63, label %bb64
bb63:
  %t222 = load ptr, ptr %l108, !tbaa !29
  %t223 = load i64, ptr %t222, !range !{i64 0, i64 17}
  %t225 = icmp eq i64 %t223, 11
  store i1 %t225, ptr %l109, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l109, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", ptr }, ptr %t229, i32 0, i32 1
  %t231 = load ptr, ptr %t230
  store ptr %t231, ptr %l11, !tbaa !29
  br label %bb71
bb66:
  %t233 = load ptr, ptr %l1, !tbaa !29
  store ptr %t233, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t234 = load ptr, ptr %l114, !tbaa !29
  %t235 = icmp ne ptr %t234, null
  br i1 %t235, label %bb67, label %bb68
bb67:
  %t237 = load ptr, ptr %l114, !tbaa !29
  %t238 = load i64, ptr %t237, !range !{i64 0, i64 17}
  %t240 = icmp eq i64 %t238, 12
  store i1 %t240, ptr %l115, !tbaa !21
  br label %bb68
bb68:
  %t241 = load i1, ptr %l115, !tbaa !21
  br i1 %t241, label %bb69, label %bb70
bb69:
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", ptr }, ptr %t244, i32 0, i32 1
  %t246 = load ptr, ptr %t245
  store ptr %t246, ptr %l11, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t248, ptr %t249)
  br label %bb72
bb72:
  br label %bb92
bb73:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t254 = load ptr, ptr %l123, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb74, label %bb75
bb74:
  %t257 = load ptr, ptr %l123, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 17}
  %t260 = icmp eq i64 %t258, 13
  store i1 %t260, ptr %l124, !tbaa !21
  br label %bb75
bb75:
  %t261 = load i1, ptr %l124, !tbaa !21
  br i1 %t261, label %bb76, label %bb77
bb76:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr }, ptr %t264, i32 0, i32 1
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l12, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l12, !tbaa !29
  %t271 = getelementptr %"compiler/typed:Join", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %t268, ptr %t272)
  br label %bb79
bb79:
  br label %bb92
bb80:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t277 = load ptr, ptr %l133, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb81, label %bb82
bb81:
  %t280 = load ptr, ptr %l133, !tbaa !29
  %t281 = load i64, ptr %t280, !range !{i64 0, i64 17}
  %t283 = icmp eq i64 %t281, 14
  store i1 %t283, ptr %l134, !tbaa !21
  br label %bb82
bb82:
  %t284 = load i1, ptr %l134, !tbaa !21
  br i1 %t284, label %bb83, label %bb84
bb83:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [3 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr }, ptr %t287, i32 0, i32 1
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l13, !tbaa !29
  br label %bb85
bb84:
  br label %bb87
bb85:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load ptr, ptr %l13, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Spawn", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t291, ptr %t295)
  br label %bb86
bb86:
  br label %bb92
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_4291427b0116e0e2_c8a2c34732e3da0e)
  unreachable
bb92:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l9 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:typeFinder", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp ne i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t20 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t24 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = sext i32 %t25 to i64
  %t30 = sub i64 %t23, %t27
  store i64 %t30, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/session:typeFinder", ptr %t33, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = icmp sgt i64 %t32, %t36
  br i1 %t39, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr %"compiler/session:typeFinder", ptr %t41, i32 0, i32 2
  store i64 %t42, ptr %t45, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = getelementptr %"compiler/session:typeFinder", ptr %t46, i32 0, i32 1
  store i32 %t47, ptr %t50, !tbaa !23
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca %"compiler/names:Entry"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d100, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l11
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l10
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l8, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/load:Loader", ptr %t16, i32 0, i32 3
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  br label %bb13
bb6:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l20, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l21, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = icmp sge i64 0, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = icmp sle i64 0, %t32
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb9:
  %t35 = load i64, ptr %l21, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb11:
  %t39 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l21, !tbaa !24
  %t42 = getelementptr i8, ptr %t40, i64 0
  %t43 = sub i64 %t41, 0
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5f2579128b68b5af_d9dbce929ac4615b)
  unreachable
bb13:
  %t47 = load ptr, ptr %l15, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27, !tbaa !23
  store i32 %t50, ptr %l4, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/names:Resolver", ptr %t57, i32 0, i32 1
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t59, i64 %a1)
  store ptr %t63, ptr %l33
  br label %bb15
bb15:
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t66 = getelementptr %"compiler/names:Table", ptr %t64, i32 0, i32 0
  store ptr %t66, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t68 = load i64, ptr %l6, !tbaa !24
  store i64 %t68, ptr %l36, !tbaa !24
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t69)
  store i64 %t71, ptr %l38
  br label %bb17
bb17:
  %t72 = load i64, ptr %l36, !tbaa !24
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store %"compiler/names:Entry" %t82, ptr %l43
  br label %bb21
bb21:
  %t83 = load %"compiler/names:Entry", ptr %l43
  store %"compiler/names:Entry" %t83, ptr %l7
  %t84 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  %t86 = load i32, ptr %l4, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 1
  %t92 = getelementptr %"compiler/source:Span", ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  %t95 = sext i32 %t93 to i64
  call void @__olang_scope_close(ptr %s0)
  store i64 %t95, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t97 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb16
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fsession_2edocPage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/doc:Module"
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca i1
  %l24 = alloca i1
  %l29 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l41 = alloca ptr
  %l50 = alloca %"compiler/doc:Module"
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i32
  %l66 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l8
  br label %bb1
bb1:
  %t3 = load i1, ptr %l8, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %v1, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %t2, i64 544, i1 false)
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 544, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l9, i64 544, i1 false)
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, ptr } %a0, ptr %l11, !tbaa !27
  store ptr %a1, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l13, !tbaa !29
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l14
  br label %bb3
bb3:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t16 = call ptr @compiler_2fsession_2eAnalyze(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t12, ptr %t13, ptr %t14, ptr %t11, i1 true)
  store ptr %t16, ptr %l16
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t18)
  store i64 %t20, ptr %l18
  br label %bb5
bb5:
  %t21 = load i64, ptr %l18, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb8
bb7:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/session:Analysis", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v1, ptr %s1, ptr %t40)
  store { i64, ptr } %t42, ptr %l29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t43 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t49)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb16:
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t54 = getelementptr %"compiler/session:Analysis", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb18:
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/session:Analysis", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/session:Analysis", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb21:
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/session:Analysis", ptr %t70, i32 0, i32 2
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/session:Analysis", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb24:
  br label %bb25
bb25:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/session:Analysis", ptr %t81, i32 0, i32 3
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/session:Analysis", ptr %t85, i32 0, i32 0
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/load:Loader", ptr %t88, i32 0, i32 12
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load ptr, ptr %l36, !tbaa !29
  %t93 = load ptr, ptr %l41, !tbaa !29
  %t96 = call %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v1, ptr %v1, ptr %v1, ptr %s0, ptr %t92, ptr %t93, ptr %t84, i64 %t91, i1 false)
  store %"compiler/doc:Module" %t96, ptr %l50
  br label %bb26
bb26:
  %t97 = load %"compiler/doc:Module", ptr %l50
  store %"compiler/doc:Module" %t97, ptr %l5
  store { i64, ptr } %a2, ptr %l51, !tbaa !27
  %t99 = getelementptr %"compiler/doc:Module", ptr %l5, i32 0, i32 0
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %s0, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l53
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  %t110 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t111 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t110, 0
  %t113 = insertvalue [2 x { i64, ptr }] %t111, { i64, ptr } %t109, 1
  store [2 x { i64, ptr }] %t113, ptr %l6
  %t116 = insertvalue { i64, ptr } undef, i64 2, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %l6, 1
  %t119 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t117)
  store { i64, ptr } %t119, ptr %l58
  br label %bb28
bb28:
  %t120 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l59, !tbaa !27
  %t123 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t123, ptr %l61
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  %t132 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t134 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t132, { i64, ptr } %t131)
  store i32 %t134, ptr %l64
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb31, label %ok.136, !prof !99
ok.136:
  br label %bb30
bb30:
  br label %bb34
bb31:
  %t137 = load i32, ptr %l64, !tbaa !23
  %t138 = ashr i32 %t137, 16
  %t140 = icmp eq i32 %t138, 1
  store i1 %t140, ptr %l66, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t142 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t145 = extractvalue { i64, ptr } %t141, 1
  %t146 = extractvalue { i64, ptr } %t141, 0
  %t147 = add i64 %t143, %t146
  %t148 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t152, ptr %t145, i64 %t146)
  %t153 = getelementptr i8, ptr %t152, i64 %t146
  call void @olang_textcopy(ptr %t153, ptr %t148, i64 %t149)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t151, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t162)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca ptr
  %l19 = alloca %"compiler/doc:Example"
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/doc:Example"
  %l27 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %s0, ptr %a0, i64 %a1, { i64, ptr } %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t31, ptr %l4
  store ptr %l4, ptr %l17, !tbaa !29
  %t33 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/doc:Example" %t33, ptr %l19
  br label %bb7
bb7:
  %t34 = getelementptr %"compiler/doc:Example", ptr %l19, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t37 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/doc:Example" %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = getelementptr %"compiler/doc:Example", ptr %l22, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t42 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t50 = extractvalue { i64, ptr } %t39, 1
  %t51 = extractvalue { i64, ptr } %t39, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t43, i64 %t44)
  %t58 = getelementptr i8, ptr %t57, i64 %t44
  call void @olang_textcopy(ptr %t58, ptr %t46, i64 %t47)
  %t59 = getelementptr i8, ptr %t58, i64 %t47
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t56, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t70, { i64, ptr } %t69)
  br label %bb9
bb9:
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t73, ptr %l27
  br label %bb10
bb10:
  %t74 = load i64, ptr %l27, !tbaa !24
  %t75 = icmp sgt i64 %t74, 1
  br i1 %t75, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l4, ptr %l29, !tbaa !29
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t78, ptr %l31
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t79 = load i64, ptr %l31, !tbaa !24
  %t80 = sub i64 %t79, 1
  store i64 %t80, ptr %l32, !tbaa !24
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t82, ptr %l34
  br label %bb14
bb14:
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = icmp eq i64 %t83, 2
  br i1 %t84, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d108, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb17
bb17:
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t88 = load i64, ptr %l32, !tbaa !24
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t88)
  %t90 = add i64 %t87, %t89
  %t91 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = add i64 %t93, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t86, i64 %t87)
  %t99 = getelementptr i8, ptr %t98, i64 %t87
  %t100 = call i64 @__olang_fmt_i64(ptr %t99, i64 %t88)
  %t101 = getelementptr i8, ptr %t99, i64 %t89
  call void @olang_textcopy(ptr %t101, ptr %t91, i64 %t92)
  %t102 = getelementptr i8, ptr %t101, i64 %t92
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t98, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t112 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t112, { i64, ptr } %t111)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t115 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l4)
  store { i64, ptr } %t115, ptr %l40
  br label %bb20
bb20:
  %t116 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t116, ptr %l41, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l42, !tbaa !24
  %t119 = load i64, ptr %l42, !tbaa !24
  %t120 = mul i64 %t119, 1
  %t121 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t120)
  %t122 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t121, 1
  store { i64, ptr } %t123, ptr %l43, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l42, !tbaa !24
  %t129 = mul i64 %t128, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t125, ptr %t127, i64 %t129, i1 false)
  %t130 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t130, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2efirstLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d111, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  store i64 %t13, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l10, !tbaa !24
  %t18 = icmp sge i64 0, 0
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l9, !tbaa !24
  %t21 = icmp sle i64 0, %t20
  br i1 %t21, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
bb7:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = icmp sle i64 %t23, %t24
  br i1 %t25, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
bb9:
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l9, !tbaa !24
  %t30 = getelementptr i8, ptr %t28, i64 0
  %t31 = sub i64 %t29, 0
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = extractvalue { i64, ptr } %t33, 0
  %t37 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t35, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_806fd3d74c9283ca_adf24a445d28962e)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ehover(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l4, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  %t27 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t26)
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) })
  store i1 %t31, ptr %l10
  br label %bb4
bb4:
  %t32 = load i1, ptr %l10, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t36, i64 %t37)
  %t43 = getelementptr i8, ptr %t42, i64 %t37
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t52)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t56 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t56, ptr %l17
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t57, ptr %l18, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l19, !tbaa !24
  %t60 = load i64, ptr %l19, !tbaa !24
  %t61 = mul i64 %t60, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t61)
  %t63 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l20, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = load i64, ptr %l19, !tbaa !24
  %t70 = mul i64 %t69, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %t68, i64 %t70, i1 false)
  %t71 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t71, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %t2, { i64, ptr } %a2)
  store i64 %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  br label %bb4
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l10, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb2
bb2:
  %t22 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l4
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 18 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l29
  br label %bb9
bb9:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = load i32, ptr %l29, !tbaa !23
  %t56 = icmp eq i32 %t54, %t55
  store i1 %t56, ptr %rv
  br label %ret
bb10:
  %t58 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t60 = trunc i64 25 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t64 = load i32, ptr %l3, !range !{i32 0, i32 33}
  store i32 %t64, ptr %l34
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 33}
  store i32 %t65, ptr %l36
  %t68 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l34, ptr %l36)
  store i1 %t68, ptr %l38
  br label %bb14
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fsession_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2estdModules(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca [2 x { i64, ptr }]
  %l14 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l43 = alloca i1
  %l51 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca ptr
  %l62 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2
  store i64 2, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l2
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = load ptr, ptr @__olang_prog_scope
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t27, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d118, i32 0, i32 1) })
  store i1 %t29, ptr %l27
  br label %bb6
bb6:
  %t30 = load i1, ptr %l27, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t33, 0
  %t38 = insertvalue [2 x { i64, ptr }] %t36, { i64, ptr } %t34, 1
  store [2 x { i64, ptr }] %t38, ptr %l6
  %t41 = insertvalue { i64, ptr } undef, i64 2, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %l6, 1
  %t44 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l35
  br label %bb9
bb8:
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  br label %bb10
bb9:
  %t53 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t53, ptr %l29, !tbaa !27
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s2, ptr %s2, { i64, ptr } %t55)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l41
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb12, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l40
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  br label %bb14
bb12:
  %t63 = load i32, ptr %l41, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l43, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb14:
  %t67 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t67, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l11, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s6)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t82 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 %t83
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  store { i64, ptr } %t88, ptr %l12, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t92 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s2, ptr %s6, { i64, ptr } %t90, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d119, i32 0, i32 1) })
  store i1 %t92, ptr %l55
  br label %bb19
bb19:
  %t93 = load i1, ptr %l55, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a0, ptr %l56, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t98 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t95, 0
  %t100 = insertvalue [2 x { i64, ptr }] %t98, { i64, ptr } %t96, 1
  store [2 x { i64, ptr }] %t100, ptr %l13
  %t103 = insertvalue { i64, ptr } undef, i64 2, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %l13, 1
  %t106 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s7, ptr %v0, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l62
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t107 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t114 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t114, { i64, ptr } %t113)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s7)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb25:
  %t116 = load i64, ptr %l10, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l10, !tbaa !24
  br label %bb15
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t120 = load i64, ptr %l3, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l3, !tbaa !24
  br label %bb2
bb28:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fsession_2eutf16Units(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l18 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t3, %a2
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  store { i64, ptr } %a0, ptr %l12, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l5, !tbaa !22
  %t20 = load i8, ptr %l5, !tbaa !22
  %t22 = icmp ult i8 %t20, -64
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l18, !tbaa !24
  br label %bb13
bb6:
  %t24 = load i8, ptr %l5, !tbaa !22
  %t26 = icmp ult i8 %t24, -32
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i64 2, ptr %l21, !tbaa !24
  br label %bb12
bb8:
  %t28 = load i8, ptr %l5, !tbaa !22
  %t30 = icmp ult i8 %t28, -16
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i64 3, ptr %l24, !tbaa !24
  br label %bb11
bb10:
  store i64 4, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t32 = load i64, ptr %l24, !tbaa !24
  store i64 %t32, ptr %l21, !tbaa !24
  br label %bb12
bb12:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  br label %bb13
bb13:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp eq i64 %t36, 4
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i64 2, ptr %l28, !tbaa !24
  br label %bb16
bb15:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = load i64, ptr %l28, !tbaa !24
  %t42 = add i64 %t40, %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l4, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  store i64 %t48, ptr %l4, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"compiler/session:Analysis"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/session:Analysis" undef, ptr %a0, 0
  %t6 = insertvalue %"compiler/session:Analysis" %t4, ptr null, 1
  %t8 = insertvalue %"compiler/session:Analysis" %t6, ptr null, 2
  %t10 = insertvalue %"compiler/session:Analysis" %t8, ptr null, 3
  store %"compiler/session:Analysis" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Analysis", ptr %rv
  ret %"compiler/session:Analysis" %rr
}

define dso_local %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/session:Found"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/session:Found" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/session:Found" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/session:Found" %t10, i64 %a2, 2
  store %"compiler/session:Found" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Found", ptr %rv
  ret %"compiler/session:Found" %rr
}

define dso_local %"compiler/session:Items" @compiler_2fsession_3aItems_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/session:Items"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  store i64 0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l4
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t5 = load %"std/prelude/text:StringBuilder", ptr %l0
  %t6 = insertvalue %"compiler/session:Items" undef, %"std/prelude/text:StringBuilder" %t5, 0
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue %"compiler/session:Items" %t6, i64 %t7, 1
  %t10 = insertvalue %"compiler/session:Items" %t8, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 2
  store %"compiler/session:Items" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Items", ptr %rv
  ret %"compiler/session:Items" %rr
}

define dso_local %"compiler/session:Positions" @compiler_2fsession_3aPositions_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l8 = alloca { i64, ptr }
  %rv = alloca %"compiler/session:Positions"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i1 %a1, ptr %l3, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %t5)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = insertvalue %"compiler/session:Positions" undef, { i64, ptr } %t9, 0
  %t11 = load i1, ptr %l3, !tbaa !21
  %t12 = insertvalue %"compiler/session:Positions" %t10, i1 %t11, 1
  %t14 = insertvalue %"compiler/session:Positions" %t12, { i64, ptr } %t8, 2
  store %"compiler/session:Positions" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Positions", ptr %rv
  ret %"compiler/session:Positions" %rr
}

define dso_local %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/session:Reader"
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a0, ptr %l1, !tbaa !23
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = insertvalue %"compiler/session:Reader" undef, i32 %t5, 0
  %t8 = insertvalue %"compiler/session:Reader" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 1
  %t10 = insertvalue %"compiler/session:Reader" %t8, i1 false, 2
  store %"compiler/session:Reader" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Reader", ptr %rv
  ret %"compiler/session:Reader" %rr
}

define dso_local %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/session:finder"
  %t9 = alloca { i64, [6 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [6 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [6 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [6 x i64] }, ptr %t9
  %t14 = insertvalue %"compiler/session:finder" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/session:finder" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/session:finder" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/session:finder" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/session:finder" %t20, i64 -1, 4
  %t24 = insertvalue %"compiler/session:finder" %t22, { i64, [6 x i64] } %t11, 5
  %t26 = insertvalue %"compiler/session:finder" %t24, i64 9223372036854775807, 6
  store %"compiler/session:finder" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:finder", ptr %rv
  ret %"compiler/session:finder" %rr
}

define dso_local %"compiler/session:memberInfo" @compiler_2fsession_3amemberInfo_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/session:memberInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/session:memberInfo" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/session:memberInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/session:memberInfo" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/session:memberInfo" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/session:memberInfo" %t18, i64 %a4, 4
  store %"compiler/session:memberInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:memberInfo", ptr %rv
  ret %"compiler/session:memberInfo" %rr
}

define dso_local %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"compiler/session:symWriter"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = insertvalue %"compiler/session:symWriter" undef, ptr %a0, 0
  %t6 = insertvalue %"compiler/session:symWriter" %t4, i64 0, 1
  store %"compiler/session:symWriter" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:symWriter", ptr %rv
  ret %"compiler/session:symWriter" %rr
}

define dso_local %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"compiler/session:typeFinder"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = insertvalue %"compiler/session:typeFinder" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/session:typeFinder" %t6, i32 %t3, 1
  %t10 = insertvalue %"compiler/session:typeFinder" %t8, i64 -1, 2
  store %"compiler/session:typeFinder" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:typeFinder", ptr %rv
  ret %"compiler/session:typeFinder" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"loaded " }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" modules) in " }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ms" }>, align 8
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"checked in " }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ms" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
declare i32 @fork()
declare void @_exit(i32)
declare i32 @close(i32)
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d9 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be made\0A" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i32 @olang_lambda_10(ptr %env) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, ptr }, ptr %cp2, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fsession_2edocPage(ptr %vc0, ptr %vc1, ptr %vc2, { i64, ptr } %cv0, ptr %cv1, { i64, ptr } %cv2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define internal i1 @olang_lambda_11(ptr %env, ptr %v0, ptr %v1, %"compiler/doc:Module" %a0, %"compiler/doc:Module" %a1) #0 {
entry:
  %l0 = alloca %"compiler/doc:Module"
  %l1 = alloca %"compiler/doc:Module"
  %l4 = alloca i1
  %rv = alloca i1
  store %"compiler/doc:Module" %a0, ptr %l0
  store %"compiler/doc:Module" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/doc:Module", ptr %l0, i32 0, i32 0
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t3 = getelementptr %"compiler/doc:Module", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i1, ptr %l4, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d12 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"index.html" }>, align 8
@.d13 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"olang standard library" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"olang" }>, align 8
@.d15 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d16 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
declare i32 @dup2(i32, i32)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fscope_3aScoper(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/scope:Scoper"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"compiler/typed:Plan"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l63 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l67 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l75 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l77 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l79 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l81 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l101 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l121 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l123 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l125 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l127 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l129 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l143 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l145 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l147 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l149 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l151 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l161 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l163 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l165 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l167 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l169 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l175 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l177 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l179 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t108 = alloca %"compiler/typed:Plan", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 5048, i1 false)
  %t2 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 6
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 7
  %t24 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l11
  %t26 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %t26
  %t27 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 8
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 9
  %t34 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %t32)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  %t36 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %t36
  %t37 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 10
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t37)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  %t41 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %t41
  %t42 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 11
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 12
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 13
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 14
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 15
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 16
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 17
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t72)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t76 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  %t77 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 18
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t77)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t81 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %t81
  %t82 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 19
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t82)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t86 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  %t87 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 20
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t87)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  %t91 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %t91
  %t92 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 21
  %t94 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t92)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  %t96 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %t96
  %t97 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 23
  %t99 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t97)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %l41
  br label %bb20
bb20:
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  %t101 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %t101
  %t102 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 24
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l43
  br label %bb21
bb21:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  %t106 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t106
  %t107 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 30
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t108, ptr %v0, ptr %t107)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t108, i64 176, i1 false)
  br label %bb22
bb22:
  %t110 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 30
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %l45, i64 176, i1 false)
  %t111 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 31
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l47
  br label %bb23
bb23:
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t115 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %t115
  %t116 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 32
  %t118 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t116)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l49
  br label %bb24
bb24:
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  %t120 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %t120
  %t121 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 33
  %t123 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t121)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t123, ptr %l51
  br label %bb25
bb25:
  %t124 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l51
  %t125 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 33
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t124, ptr %t125
  %t126 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 34
  %t128 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t126)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %l53
  br label %bb26
bb26:
  %t129 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  %t130 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t129, ptr %t130
  %t131 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 35
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %t131)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l55
  br label %bb27
bb27:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  %t135 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t135
  %t136 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 36
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t136)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l57
  br label %bb28
bb28:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t140 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %t140
  %t141 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 37
  %t143 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t141)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l59
  br label %bb29
bb29:
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t145 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t145
  %t146 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 40
  %t148 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t146)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t148, ptr %l61
  br label %bb30
bb30:
  %t149 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l61
  %t150 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t149, ptr %t150
  %t151 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 41
  %t153 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0, ptr %t151)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t153, ptr %l63
  br label %bb31
bb31:
  %t154 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l63
  %t155 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 41
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t154, ptr %t155
  %t156 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 42
  %t158 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t156)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t158, ptr %l65
  br label %bb32
bb32:
  %t159 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  %t160 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t159, ptr %t160
  %t161 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 43
  %t163 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t161)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t163, ptr %l67
  br label %bb33
bb33:
  %t164 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l67
  %t165 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 43
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t164, ptr %t165
  %t166 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 44
  %t168 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t166)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l69
  br label %bb34
bb34:
  %t169 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  %t170 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %t170
  %t171 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 45
  %t173 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l71
  br label %bb35
bb35:
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  %t175 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %t175
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 46
  %t178 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t176)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t178, ptr %l73
  br label %bb36
bb36:
  %t179 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l73
  %t180 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t179, ptr %t180
  %t181 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 47
  %t183 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t181)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t183, ptr %l75
  br label %bb37
bb37:
  %t184 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l75
  %t185 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 47
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t184, ptr %t185
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 50
  %t188 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aV_H5f2ccf3e4d2f2a18b403dd06a16926e0(ptr %v0, ptr %t186)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t188, ptr %l77
  br label %bb38
bb38:
  %t189 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l77
  %t190 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 50
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t189, ptr %t190
  %t191 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 51
  %t193 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t191)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t193, ptr %l79
  br label %bb39
bb39:
  %t194 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l79
  %t195 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 51
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t194, ptr %t195
  %t196 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 52
  %t198 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t196)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t198, ptr %l81
  br label %bb40
bb40:
  %t199 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l81
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 52
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t199, ptr %t200
  %t201 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 55
  %t203 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t201)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l83
  br label %bb41
bb41:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  %t205 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %t205
  %t206 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 57
  %t208 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %t206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %l85
  br label %bb42
bb42:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  %t210 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %t210
  %t211 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 58
  %t213 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t211)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l87
  br label %bb43
bb43:
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  %t215 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %t215
  %t216 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 59
  %t218 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t216)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l89
  br label %bb44
bb44:
  %t219 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  %t220 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %t220
  %t221 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 61
  %t223 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t221)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t223, ptr %l91
  br label %bb45
bb45:
  %t224 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  %t225 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %t225
  %t226 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 62
  %t228 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t226)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l93
  br label %bb46
bb46:
  %t229 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  %t230 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %t230
  %t231 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 63
  %t233 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t231)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l95
  br label %bb47
bb47:
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  %t235 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %t235
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 64
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t236)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l97
  br label %bb48
bb48:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  %t240 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %t240
  %t241 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 66
  %t243 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0, ptr %t241)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t243, ptr %l99
  br label %bb49
bb49:
  %t244 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l99
  %t245 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 66
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t244, ptr %t245
  %t246 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 68
  %t248 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t246)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t248, ptr %l101
  br label %bb50
bb50:
  %t249 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l101
  %t250 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t249, ptr %t250
  %t251 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 74
  %t253 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t251)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t253, ptr %l103
  br label %bb51
bb51:
  %t254 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  %t255 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t254, ptr %t255
  %t256 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 85
  %t258 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %t256)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t258, ptr %l105
  br label %bb52
bb52:
  %t259 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  %t260 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259, ptr %t260
  %t261 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 86
  %t263 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t261)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l107
  br label %bb53
bb53:
  %t264 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  %t265 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %t265
  %t266 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 87
  %t268 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t266)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l109
  br label %bb54
bb54:
  %t269 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  %t270 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t269, ptr %t270
  %t271 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 88
  %t273 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t271)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %l111
  br label %bb55
bb55:
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l111
  %t275 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %t275
  %t276 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 89
  %t278 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t276)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l113
  br label %bb56
bb56:
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  %t280 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %t280
  %t281 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 90
  %t283 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t281)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %l115
  br label %bb57
bb57:
  %t284 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  %t285 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t284, ptr %t285
  %t286 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 91
  %t288 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t286)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t288, ptr %l117
  br label %bb58
bb58:
  %t289 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  %t290 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 91
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t289, ptr %t290
  %t291 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 92
  %t293 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0, ptr %t291)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t293, ptr %l119
  br label %bb59
bb59:
  %t294 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l119
  %t295 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 92
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t294, ptr %t295
  %t296 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 93
  %t298 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0, ptr %t296)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t298, ptr %l121
  br label %bb60
bb60:
  %t299 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l121
  %t300 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 93
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t299, ptr %t300
  %t301 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 95
  %t303 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t301)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t303, ptr %l123
  br label %bb61
bb61:
  %t304 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l123
  %t305 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 95
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t304, ptr %t305
  %t306 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 96
  %t308 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %t306)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t308, ptr %l125
  br label %bb62
bb62:
  %t309 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l125
  %t310 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 96
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t309, ptr %t310
  %t311 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 97
  %t313 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %t311)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t313, ptr %l127
  br label %bb63
bb63:
  %t314 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l127
  %t315 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 97
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t314, ptr %t315
  %t316 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 98
  %t318 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H86e279efa8e733948b916e4a42c26683(ptr %v0, ptr %t316)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t318, ptr %l129
  br label %bb64
bb64:
  %t319 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l129
  %t320 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 98
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t319, ptr %t320
  %t321 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 100
  %t323 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t321)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %l131
  br label %bb65
bb65:
  %t324 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  %t325 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t324, ptr %t325
  %t326 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 101
  %t328 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t326)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %l133
  br label %bb66
bb66:
  %t329 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  %t330 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t329, ptr %t330
  %t331 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 107
  %t333 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t331)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t333, ptr %l135
  br label %bb67
bb67:
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l135
  %t335 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %t335
  %t336 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 112
  %t338 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t336)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %l137
  br label %bb68
bb68:
  %t339 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  %t340 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t339, ptr %t340
  %t341 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 113
  %t343 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t341)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %l139
  br label %bb69
bb69:
  %t344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  %t345 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %t345
  %t346 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 127
  %t348 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H335d7fb5786b148107844d9b6b4f07f9(ptr %v0, ptr %t346)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t348, ptr %l141
  br label %bb70
bb70:
  %t349 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l141
  %t350 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 127
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t349, ptr %t350
  %t351 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 128
  %t353 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H335d7fb5786b148107844d9b6b4f07f9(ptr %v0, ptr %t351)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t353, ptr %l143
  br label %bb71
bb71:
  %t354 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l143
  %t355 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 128
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t354, ptr %t355
  %t356 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 129
  %t358 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t356)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t358, ptr %l145
  br label %bb72
bb72:
  %t359 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l145
  %t360 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 129
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t359, ptr %t360
  %t361 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 130
  %t363 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t361)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t363, ptr %l147
  br label %bb73
bb73:
  %t364 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147
  %t365 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 130
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t364, ptr %t365
  %t366 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 131
  %t368 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t366)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t368, ptr %l149
  br label %bb74
bb74:
  %t369 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l149
  %t370 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 131
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t369, ptr %t370
  %t371 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 133
  %t373 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %t371)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t373, ptr %l151
  br label %bb75
bb75:
  %t374 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l151
  %t375 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 133
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t374, ptr %t375
  %t376 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 134
  %t378 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t376)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t378, ptr %l153
  br label %bb76
bb76:
  %t379 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  %t380 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t379, ptr %t380
  %t381 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 135
  %t383 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t381)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383, ptr %l155
  br label %bb77
bb77:
  %t384 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l155
  %t385 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t384, ptr %t385
  %t386 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 141
  %t388 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t386)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t388, ptr %l157
  br label %bb78
bb78:
  %t389 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  %t390 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 141
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t389, ptr %t390
  %t391 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 143
  %t393 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t391)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t393, ptr %l159
  br label %bb79
bb79:
  %t394 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l159
  %t395 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 143
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t394, ptr %t395
  %t396 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 144
  %t398 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t396)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t398, ptr %l161
  br label %bb80
bb80:
  %t399 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l161
  %t400 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 144
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t399, ptr %t400
  %t401 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 145
  %t403 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %t401)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t403, ptr %l163
  br label %bb81
bb81:
  %t404 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l163
  %t405 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 145
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t404, ptr %t405
  %t406 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 146
  %t408 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %t406)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t408, ptr %l165
  br label %bb82
bb82:
  %t409 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l165
  %t410 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 146
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t409, ptr %t410
  %t411 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 147
  %t413 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t411)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %l167
  br label %bb83
bb83:
  %t414 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l167
  %t415 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 147
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t414, ptr %t415
  %t416 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 149
  %t418 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t416)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t418, ptr %l169
  br label %bb84
bb84:
  %t419 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l169
  %t420 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 149
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t419, ptr %t420
  %t421 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 156
  %t423 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut__H11318def2bd28b1fb5a9d896e9a2fdc8(ptr %v0, ptr %t421)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t423, ptr %l171
  br label %bb85
bb85:
  %t424 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  %t425 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 156
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t424, ptr %t425
  %t426 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 157
  %t428 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H91272af7a0b96064e12e94542dd09dda(ptr %v0, ptr %t426)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t428, ptr %l173
  br label %bb86
bb86:
  %t429 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173
  %t430 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 157
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t429, ptr %t430
  %t431 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 158
  %t433 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t431)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t433, ptr %l175
  br label %bb87
bb87:
  %t434 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l175
  %t435 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 158
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t434, ptr %t435
  %t436 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 159
  %t438 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t436)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t438, ptr %l177
  br label %bb88
bb88:
  %t439 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l177
  %t440 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 159
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439, ptr %t440
  %t441 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 160
  %t443 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0, ptr %t441)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t443, ptr %l179
  br label %bb89
bb89:
  %t444 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l179
  %t445 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 160
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t444, ptr %t445
  %t446 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 161
  %t448 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t446)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t448, ptr %l181
  br label %bb90
bb90:
  %t449 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  %t450 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 161
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t449, ptr %t450
  %t451 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 162
  %t453 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0, ptr %t451)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t453, ptr %l183
  br label %bb91
bb91:
  %t454 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183
  %t455 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 162
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t454, ptr %t455
  %t456 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 163
  %t458 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t456)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t458, ptr %l185
  br label %bb92
bb92:
  %t459 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  %t460 = getelementptr %"compiler/scope:Scoper", ptr %l1, i32 0, i32 163
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t459, ptr %t460
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 5048, i1 false)
  br label %ret
ret:
  ret void
}

define internal { i64, ptr } @olang_lambda_17(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_51582b1a0e30bcb1_9563e8081c953955)
  unreachable
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %t5, i64 %a0)
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_18(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l1 = alloca ptr
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l1
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_53726bd6cca5663f_63c9f91772010c1b)
  unreachable
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %t5, i32 %a0)
  store { i64, ptr } %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d19 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"held to section 8 in " }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ms" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare i64 @signal(i32, i64)
declare i32 @waitpid(i32, ptr, i32)
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\22" }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cr" }>, align 8
@.d33 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\5Cu00" }>, align 8
@.d35 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789abcdef" }>, align 8
@.d36 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"0123456789abcdef" }>, align 8
declare i32 @kill(i32, i32)
@.d37 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_TOOL_LOG" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare i32 @pipe(ptr)
define linkonce_odr %"<poll.h>:pollfd" @olang_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd() #0 {
entry:
  %l0 = alloca %"<poll.h>:pollfd"
  %rv = alloca %"<poll.h>:pollfd"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %t1)
  store %"<poll.h>:pollfd" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<poll.h>:pollfd", ptr %l0
  store %"<poll.h>:pollfd" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<poll.h>:pollfd", ptr %rv
  ret %"<poll.h>:pollfd" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i32 @poll(ptr, i64, i32)
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d46 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d47 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"Content-Length: " }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0D\0A\0D\0A" }>, align 8
@.d49 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no type" }>, align 8
@.d50 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"completion after a '.' at " }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d57 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"import \22" }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"{\22label\22:" }>, align 8
@.d70 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22kind\22:" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22detail\22:" }>, align 8
@.d73 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"{\22start\22:{\22line\22:" }>, align 8
@.d74 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c",\22character\22:" }>, align 8
@.d75 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"},\22end\22:{\22line\22:" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"}}" }>, align 8
declare i64 @read(i32, ptr, i64)
@.d77 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"content-length:" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d85 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"{\22name\22:" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d94 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c",\22kind\22:" }>, align 8
@.d95 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c",\22range\22:" }>, align 8
@.d96 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c",\22selectionRange\22:" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c",\22detail\22:" }>, align 8
@.d99 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c",\22children\22:[" }>, align 8
@.d100 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d101 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d102 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\0A\0AExample: " }>, align 8
@.d105 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0A```olang\0A" }>, align 8
@.d106 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0A```" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d109 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A\0A+" }>, align 8
@.d110 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" more test" }>, align 8
@.d111 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d112 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"```olang\0A" }>, align 8
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0A```" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0A\0A" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d117 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d118 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d119 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3asummary_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3arel_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 80
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fscope_3aTerm_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aV_H5f2ccf3e4d2f2a18b403dd06a16926e0(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprel_H3af225d3344e2987e2b2e47667c0dd27(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3afnUse_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H86e279efa8e733948b916e4a42c26683(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H335d7fb5786b148107844d9b6b4f07f9(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cmut__H11318def2bd28b1fb5a9d896e9a2fdc8(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_H91272af7a0b96064e12e94542dd09dda(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/typed:Plan", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 176
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/typed:Plan", ptr %t14, i64 %t12
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 176, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 176, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprel_H3af225d3344e2987e2b2e47667c0dd27(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2fve_H8701705e643cd43e095fcd36670c2071(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare ptr @__olang_scope_mine_slow(ptr) noinline
define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2fve_H8701705e643cd43e095fcd36670c2071(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aTerm_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fscope_3acompRun_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2ftime_2eNow()
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eSince(i64 %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_955cfaf9738e6bc2_e48fc09138963b26 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fexplain_2eCaps(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_35fd852a81194674_cc9a5a6794b34358 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3107e0baf714f587_4e2de6149db597f3 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_6636dd2b26b29868_9b4c1750690bee24 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Module" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eSort_3cco_Hfcfbe33647fb7db48e9022f22b0d44cf(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_eb449e3906b36447_37ec3fcb8d3ba1cb = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffmt_2ePreludeTypes(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2ffmt_2eFileLayout(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
@olang_loc_35f6bc648a66c5f9_fb290a2b6e993705 = external constant [0 x i8]
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
@olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e = external constant [0 x i8]
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_6f935d255f99d513_bebfb26ca618488f = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d = external constant [0 x i8]
@olang_loc_18466e7707586594_33576ced7420fee0 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_decc2d78854299ff_a983c2831d86fddb = external constant [0 x i8]
@olang_loc_ff40fb5988b00df4_fbbcb1c788c8bd28 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_6afc88ea1ac145e8_494a63ded86193f4 = external constant [0 x i8]
@G_2e_3cpoll_2eh_3e_2ePOLLIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01 = external constant [0 x i8]
@G_2e_3cpoll_2eh_3e_2ePOLLERR = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cpoll_2eh_3e_2ePOLLHUP = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_b18535922df9c451_739a4491ef7ea55d = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3178b68d0296f164_92041ef9c14564d0 = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d917d39333aa2133_631bc7dad212aa2f = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@olang_loc_8be86b180d8510f2_8625cf113e27a67e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_804f8b0fb45e435f_c5484f8454187243 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9033262c592f27c0_922b790dfcbd6cb4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_657f7671e8d24039_dcdf7cbf2572e335 = external constant [0 x i8]
@olang_loc_34b5353ec7fa6306_74a43705b3ad61d2 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
@olang_loc_913972385efaf6d8_94fc87626a418744 = external constant [0 x i8]
@olang_loc_50b486dff56c46f7_6641abdfc6e3fb13 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f7a7bb63ca62da11_77899a051c081195 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
@olang_loc_9453126c7f8f920b_6892400c5eb9861f = external constant [0 x i8]
@olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a = external constant [0 x i8]
@olang_loc_8be95a0084a275_27fb33976f90d831 = external constant [0 x i8]
@olang_loc_62de0451ac433905_e234825e46030f99 = external constant [0 x i8]
@olang_loc_15e46cfea19645ed_f1e4cdf7ffa66ee1 = external constant [0 x i8]
@olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e81878307a0930f8_ac6e376276a113b4 = external constant [0 x i8]
@olang_loc_cf719ce72396210d_6e539aa1951515a9 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_90bed28a447e5726_404cd49f4fb329c2 = external constant [0 x i8]
@olang_loc_966fb838f56733ab_5416c5dd2a23270f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_55b3f811cb7477b4_5dfc53d9875946d8 = external constant [0 x i8]
@olang_loc_4c52bbc768601131_90801d9bf2a41585 = external constant [0 x i8]
@olang_loc_42ed37d296a6252a_791781e06ef43dde = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_dff094d230471566_615c91b3ab3b0902 = external constant [0 x i8]
@olang_loc_93ae806d7d0351b8_8e59b8ae3d0673ac = external constant [0 x i8]
@olang_loc_9641f0facc09fdd7_c62ff0c79521a99b = external constant [0 x i8]
@olang_loc_c5788a2fa1963e6_4f790674132263da = external constant [0 x i8]
@olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ba93316a311e09f4_9951ae939e9d3a90 = external constant [0 x i8]
@olang_loc_655ed1db7681c96b_c757f347e4ac2c7 = external constant [0 x i8]
@olang_loc_284eaf45fbe9e9ea_494071f23c61296 = external constant [0 x i8]
@olang_loc_878a1a37f76dded1_df06407b9e0240ed = external constant [0 x i8]
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
@olang_loc_ad4014c285adba33_5f0a50bbd6dd5777 = external constant [0 x i8]
@olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0)
@olang_loc_c15f20635f7a4119_452b944b82f8966d = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_6010ac475f88a9f2_430aff1aa96b7386 = external constant [0 x i8]
@olang_loc_64c89934b5f1bf_a2a8dc486100a28b = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa = external constant [0 x i8]
@olang_loc_78ada93836b36c6b_7d0979891c04300f = external constant [0 x i8]
@olang_loc_f729b95fcb28e588_e9118b2581b5934c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2 = external constant [0 x i8]
@olang_loc_a3b4800e6d7209ba_290fe7f1ef38ac36 = external constant [0 x i8]
@olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d = external constant [0 x i8]
@olang_loc_f548539da9e2e40c_6a57728f427e36c8 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
@olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
@olang_loc_be0af37330f35afe_68a0a057b8d4cca2 = external constant [0 x i8]
@olang_loc_7be9b74a0a4337a5_af051c2067e0d709 = external constant [0 x i8]
@olang_loc_a0e32d5552598bb5_d1b40570995ef0d1 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_90517919cad2500e_b5e04c9858b7f7ca = external constant [0 x i8]
@olang_loc_ce3fd8c720c212bf_60e6469ff90569cb = external constant [0 x i8]
@olang_loc_cf04846f3952f731_2a54d968229bc665 = external constant [0 x i8]
@olang_loc_77695651a3cbe722_713723fe03dd0eb6 = external constant [0 x i8]
@olang_loc_192180e0c65a19ab_79011e5b413ec96f = external constant [0 x i8]
@olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10 = external constant [0 x i8]
@olang_loc_65524a0775fa0c24_67802a16d5ac44c0 = external constant [0 x i8]
@olang_loc_183418cbaaa3b5f3_579c8efa30db605f = external constant [0 x i8]
@olang_loc_269369d36ae436b2_2e7a039021f1ff2e = external constant [0 x i8]
@olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5 = external constant [0 x i8]
@olang_loc_843b58ccd5037a60_511f1c08fd361084 = external constant [0 x i8]
@olang_loc_237e374d945d777f_399ab2bb28be7e53 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_276794097286b2ce_71d39dea21084d12 = external constant [0 x i8]
@olang_loc_883965863f350275_cecb497c93815139 = external constant [0 x i8]
@olang_loc_f4d7e16f2a7cbb1c_8fb96f5d8af1db38 = external constant [0 x i8]
@olang_loc_1c008e98be3ff20b_924cdfead9f88757 = external constant [0 x i8]
@olang_loc_b55c87bfcca1c8bf_5b30a336320e23 = external constant [0 x i8]
@olang_loc_bca4a5ed74171cc7_e50f418fa8ad666b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePushAll_3cU8_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_7fa1338bfb5c4549_286381a3bde0b91d = external constant [0 x i8]
@olang_loc_98e1614ed1d054f5_86eb50e982cc0441 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eLen_3cU8_3e(ptr %v0, ptr %a0)
declare i8 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eSetAt_3cU8_3e(ptr %v0, ptr %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eTruncate_3cU8_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_68ddcf9e12618436_cff7fbf614d16d4a = external constant [0 x i8]
@olang_loc_a3421b14f56bfb72_e21214c32a246516 = external constant [0 x i8]
@olang_loc_6c2d06947719abd6_25c6135ab70ee42 = external constant [0 x i8]
@olang_loc_a4411270f97f17bd_30632737f0d2da29 = external constant [0 x i8]
@olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b = external constant [0 x i8]
@olang_loc_7a96973d190d0d9e_4b6d703943f97c5a = external constant [0 x i8]
@olang_loc_d73c626185112279_563eb35624dc00ed = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5 = external constant [0 x i8]
@olang_loc_9a3dbb58dbc7a31a_5629726f6c293dd6 = external constant [0 x i8]
@olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca = external constant [0 x i8]
@olang_loc_647b5c14292f4276_1cbe6dd578a95e8a = external constant [0 x i8]
@olang_loc_4f7bb28debca73d0_f3d58f15dee72c24 = external constant [0 x i8]
declare i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_52dc430f3488fa77_8026fac3ef739783 = external constant [0 x i8]
@olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd = external constant [0 x i8]
@olang_loc_59453385dbeab0f1_a10e94e6ba58edc5 = external constant [0 x i8]
@olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5 = external constant [0 x i8]
@olang_loc_7c90741a89491e92_62c7d4207901162e = external constant [0 x i8]
@olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f = external constant [0 x i8]
@olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_df797fad9b49105d_2a8f7c5ad36c2889 = external constant [0 x i8]
@olang_loc_d2b15075f36d8dac_250aaa3debc302b8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_8ea8ca70496d6921_977884330ce8ec6d = external constant [0 x i8]
@olang_loc_4291427b0116e0e2_c8a2c34732e3da0e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5f2579128b68b5af_d9dbce929ac4615b = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e6936df67b662b33_7a0885fa2c8953cf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0)
declare %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_806fd3d74c9283ca_adf24a445d28962e = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_51582b1a0e30bcb1_9563e8081c953955 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_53726bd6cca5663f_63c9f91772010c1b = external constant [0 x i8]
declare %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
