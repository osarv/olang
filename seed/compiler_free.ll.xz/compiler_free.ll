; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:retire" = type { i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
@G_2ecompiler_2ffree_2eAnyPlace = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eLAssign = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDestroy = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDrop = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLVacate = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLYield = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMovBase = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMustNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eMustTop = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eOMov = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eONew = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPar = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOUnk = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRCopied = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRInPlace = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRMade = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRStore = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRTask = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRView = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k2, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k3, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k4, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k6, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k8, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k9 }>, align 64
@G_2ecompiler_2ffree_2eRemovalNames.k1 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\50\6F\70" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\54\61\6B\65\41\74" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k3 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\52\65\6D\6F\76\65\41\74" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k4 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\77\61\70\52\65\6D\6F\76\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k5 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\52\65\6D\6F\76\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\43\6C\65\61\72" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k7 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\54\72\75\6E\63\61\74\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\54\61\6B\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k9 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\53\77\61\70\54\61\6B\65" }>, align 8
@G_2ecompiler_2ffree_2eSFail = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSFresh = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSOk = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = icmp eq i64 %t18, %t20
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i64 0, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t30, i64 %t31)
  br label %bb12
bb12:
  store i64 1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 11
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 11
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t18, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l10, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 73
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 47
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 47
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:letGo"
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/free:reason"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l64 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca %"compiler/free:letGo"
  %l100 = alloca i1
  %l101 = alloca ptr
  %l105 = alloca %"compiler/free:letGo"
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca %"compiler/free:letGo"
  %l117 = alloca i1
  %l118 = alloca ptr
  %l122 = alloca %"compiler/free:letGo"
  %l126 = alloca %"compiler/free:letGo"
  %l127 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l154 = alloca i64
  %l157 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i32
  %l167 = alloca %"compiler/free:letGo"
  %l172 = alloca i64
  %l176 = alloca i1
  %l180 = alloca %"compiler/free:letGo"
  %l187 = alloca %"compiler/free:letGo"
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l195 = alloca i64
  %l197 = alloca i1
  %l200 = alloca i1
  %l205 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l212 = alloca i64
  %l216 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l223 = alloca i64
  %l228 = alloca %"compiler/free:reason"
  %l233 = alloca i64
  %l238 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l260 = alloca { i64, ptr }
  %l263 = alloca i1
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca i64
  %l280 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca i64
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l299 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l33
  br label %bb1
bb1:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t13, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l34
  br label %bb2
bb2:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 8
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l37
  br label %bb3
bb3:
  %t21 = load i64, ptr %l37, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load i64, ptr %l8, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb9
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l44, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l44, !tbaa !24
  store i64 %t48, ptr %l41, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l41, !tbaa !24
  store i64 %t49, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb122
bb12:
  br label %bb13
bb13:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l11, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l11, !tbaa !24
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l64
  br label %bb14
bb14:
  %t73 = load i1, ptr %l64, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb16:
  br label %bb17
bb17:
  store i64 -1, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:Free", ptr %t76, i32 0, i32 41
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l68
  br label %bb18
bb18:
  %t81 = load i64, ptr %l68, !tbaa !24
  store i64 %t81, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load i64, ptr %l15, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb24
bb21:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l15, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l75, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb23
bb23:
  %t108 = load i64, ptr %l75, !tbaa !24
  store i64 %t108, ptr %l72, !tbaa !24
  br label %bb24
bb24:
  %t109 = load i64, ptr %l72, !tbaa !24
  store i64 %t109, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  %t110 = load i64, ptr %l17, !tbaa !24
  %t111 = load i64, ptr %l16, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  br label %bb52
bb27:
  br label %bb28
bb28:
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l17, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l18, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:Free", ptr %t128, i32 0, i32 41
  %t131 = load i64, ptr %l18, !tbaa !24
  %t134 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t130, i64 %t131)
  store %"compiler/free:letGo" %t134, ptr %l96
  br label %bb29
bb29:
  %t135 = getelementptr %"compiler/free:letGo", ptr %l96, i32 0, i32 0
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp ne i64 %t136, %t137
  br i1 %t140, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb34
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l101, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 41
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t145, i64 %t146)
  store %"compiler/free:letGo" %t149, ptr %l105
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l101, !tbaa !29
  %t151 = load %"compiler/free:letGo", ptr %l105
  %t152 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %t150, %"compiler/free:letGo" %t151)
  store i1 %t152, ptr %l106
  br label %bb33
bb33:
  %t153 = load i1, ptr %l106, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l100, !tbaa !21
  br label %bb34
bb34:
  %t156 = load i1, ptr %l100, !tbaa !21
  br i1 %t156, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb38
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t157, i32 0, i32 41
  %t160 = load i64, ptr %l18, !tbaa !24
  %t163 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t159, i64 %t160)
  store %"compiler/free:letGo" %t163, ptr %l112
  br label %bb37
bb37:
  %t164 = getelementptr %"compiler/free:letGo", ptr %l112, i32 0, i32 8
  %t165 = load i1, ptr %t164, !tbaa !21
  %t167 = xor i1 %t165, true
  store i1 %t167, ptr %l108, !tbaa !21
  br label %bb38
bb38:
  %t169 = load i1, ptr %l108, !tbaa !21
  br i1 %t169, label %bb39, label %bb40
bb39:
  br label %bb51
bb40:
  br label %bb41
bb41:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t172 = icmp slt i64 %t170, 0
  br i1 %t172, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb47
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l118, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 41
  %t178 = load i64, ptr %l18, !tbaa !24
  %t181 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t177, i64 %t178)
  store %"compiler/free:letGo" %t181, ptr %l122
  br label %bb44
bb44:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/free:Free", ptr %t182, i32 0, i32 41
  %t185 = load i64, ptr %l12, !tbaa !24
  %t188 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/free:letGo" %t188, ptr %l126
  br label %bb45
bb45:
  %t189 = load ptr, ptr %l118, !tbaa !29
  %t190 = load %"compiler/free:letGo", ptr %l122
  %t191 = load %"compiler/free:letGo", ptr %l126
  %t192 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %t189, %"compiler/free:letGo" %t190, %"compiler/free:letGo" %t191)
  store i1 %t192, ptr %l127
  br label %bb46
bb46:
  %t193 = load i1, ptr %l127, !tbaa !21
  store i1 %t193, ptr %l117, !tbaa !21
  br label %bb47
bb47:
  %t194 = load i1, ptr %l117, !tbaa !21
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t195 = load i64, ptr %l18, !tbaa !24
  store i64 %t195, ptr %l12, !tbaa !24
  br label %bb50
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t197 = load i64, ptr %l17, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l17, !tbaa !24
  br label %bb25
bb52:
  %t201 = load i64, ptr %l12, !tbaa !24
  %t203 = icmp slt i64 %t201, 0
  br i1 %t203, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb54:
  br label %bb55
bb55:
  %t205 = load i64, ptr %l3, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l3, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t209, i64 %t210)
  store i1 %t213, ptr %l137
  br label %bb56
bb56:
  %t214 = load i1, ptr %l137, !tbaa !21
  br i1 %t214, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb64
bb58:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:Free", ptr %t215, i32 0, i32 68
  %t218 = load i64, ptr %l11, !tbaa !24
  %t221 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t217, i64 %t218)
  store i1 %t221, ptr %l142
  br label %bb59
bb59:
  %t222 = load i1, ptr %l142, !tbaa !21
  br i1 %t222, label %bb60, label %bb61
bb60:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/free:Free", ptr %t223, i32 0, i32 70
  %t226 = load i64, ptr %l11, !tbaa !24
  %t229 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t225, i64 %t226)
  store i1 %t229, ptr %l147
  br label %bb62
bb61:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb63
bb62:
  %t230 = load i1, ptr %l147, !tbaa !21
  store i1 %t230, ptr %l143, !tbaa !21
  br label %bb63
bb63:
  %t231 = load i1, ptr %l143, !tbaa !21
  store i1 %t231, ptr %l138, !tbaa !21
  br label %bb64
bb64:
  %t232 = load i1, ptr %l138, !tbaa !21
  br i1 %t232, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb66:
  br label %bb67
bb67:
  %t233 = load i64, ptr %l4, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l4, !tbaa !24
  %t237 = load i64, ptr %l12, !tbaa !24
  store i64 %t237, ptr %l19, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 42
  %t242 = load i64, ptr %l11, !tbaa !24
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l154
  br label %bb68
bb68:
  %t246 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  %t247 = load i64, ptr %l154, !tbaa !24
  %t249 = icmp eq i64 %t247, %t246
  br i1 %t249, label %bb69, label %bb70
bb69:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/free:Free", ptr %t251, i32 0, i32 57
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t253, i64 %t254)
  %t258 = extractvalue { i32, i64 } %t257, 1
  %t259 = extractvalue { i32, i64 } %t257, 0
  store i32 %t259, ptr %l162
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb72, label %ok.261, !prof !99
ok.261:
  store i64 %t258, ptr %l161
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t262 = load i64, ptr %l161, !tbaa !24
  store i64 %t262, ptr %l157, !tbaa !24
  br label %bb74
bb72:
  br label %bb73
bb73:
  call void @__olang_ert_req_clear()
  %t263 = load i64, ptr %l12, !tbaa !24
  store i64 %t263, ptr %l157, !tbaa !24
  br label %bb74
bb74:
  %t265 = load i64, ptr %l157, !tbaa !24
  store i64 %t265, ptr %l19, !tbaa !24
  br label %bb75
bb75:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 41
  %t269 = load i64, ptr %l19, !tbaa !24
  %t272 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t268, i64 %t269)
  store %"compiler/free:letGo" %t272, ptr %l167
  br label %bb76
bb76:
  %t273 = load %"compiler/free:letGo", ptr %l167
  store %"compiler/free:letGo" %t273, ptr %l20
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t276 = load i64, ptr %t275, !tbaa !24
  %t277 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 3
  %t278 = getelementptr %"compiler/source:Span", ptr %t277, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = sext i32 %t279 to i64
  %t285 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t274, i64 %t276, i64 %t281)
  store i64 %t285, ptr %l172
  br label %bb77
bb77:
  %t286 = load i64, ptr %l172, !tbaa !24
  store i64 %t286, ptr %l21, !tbaa !24
  %t287 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 5
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t292 = icmp eq i64 %t288, %t289
  br i1 %t292, label %bb78, label %bb79
bb78:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/free:Free", ptr %t294, i32 0, i32 41
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t296, i64 %t297)
  store %"compiler/free:letGo" %t300, ptr %l180
  br label %bb80
bb79:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb81
bb80:
  %t301 = getelementptr %"compiler/free:letGo", ptr %l180, i32 0, i32 5
  %t302 = load i64, ptr %t301, !tbaa !24
  %t303 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t306 = icmp ne i64 %t302, %t303
  store i1 %t306, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t308 = load i1, ptr %l176, !tbaa !21
  br i1 %t308, label %bb82, label %bb83
bb82:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:Free", ptr %t309, i32 0, i32 41
  %t312 = load i64, ptr %l12, !tbaa !24
  %t315 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t311, i64 %t312)
  store %"compiler/free:letGo" %t315, ptr %l187
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t316 = load %"compiler/free:letGo", ptr %l187
  store %"compiler/free:letGo" %t316, ptr %l20
  br label %bb85
bb85:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l188, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  store i64 %t319, ptr %l190, !tbaa !24
  %t320 = load i64, ptr %l190, !tbaa !24
  %t321 = mul i64 %t320, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t321)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l191, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l190, !tbaa !24
  %t330 = mul i64 %t329, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t326, ptr %t328, i64 %t330, i1 false)
  %t331 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t331, ptr %l22, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/free:Free", ptr %t332, i32 0, i32 9
  %t335 = load i64, ptr %l11, !tbaa !24
  %t338 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t334, i64 %t335)
  store i64 %t338, ptr %l195
  br label %bb86
bb86:
  %t339 = load i64, ptr %l195, !tbaa !24
  %t340 = icmp slt i64 %t339, 0
  br i1 %t340, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb90
bb88:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l11, !tbaa !24
  %t346 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t342, i64 %t343)
  store i1 %t346, ptr %l200
  br label %bb89
bb89:
  %t347 = load i1, ptr %l200, !tbaa !21
  store i1 %t347, ptr %l197, !tbaa !21
  br label %bb90
bb90:
  %t348 = load i1, ptr %l197, !tbaa !21
  br i1 %t348, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s13
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i64, ptr %l11, !tbaa !24
  %t351 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 1
  %t352 = load i64, ptr %t351, !tbaa !24
  %t353 = load %"compiler/free:letGo", ptr %l20
  %t358 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %s13, ptr %t349, i64 %t350, i64 %t352, %"compiler/free:letGo" %t353)
  store { i64, ptr } %t358, ptr %l205
  br label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load %"compiler/free:letGo", ptr %l20
  %t363 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s15, ptr %t359, %"compiler/free:letGo" %t360)
  store { i64, ptr } %t363, ptr %l216
  br label %bb98
bb93:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/free:letGo", ptr %l20
  %t366 = load i64, ptr %l11, !tbaa !24
  %t370 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %s13, ptr %t364, %"compiler/free:letGo" %t365, i64 %t366)
  store { i64, ptr } %t370, ptr %l209
  br label %bb94
bb94:
  %t371 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t373 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = add i64 %t372, %t375
  %t377 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t380 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = add i64 %t379, %t382
  %t384 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t371, i64 %t372)
  %t388 = getelementptr i8, ptr %t387, i64 %t372
  call void @olang_textcopy(ptr %t388, ptr %t374, i64 %t375)
  %t389 = getelementptr i8, ptr %t388, i64 %t375
  call void @olang_textcopy(ptr %t389, ptr %t377, i64 %t378)
  %t390 = getelementptr i8, ptr %t389, i64 %t378
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t384, i64 %t385)
  %t392 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t387, 1
  store { i64, ptr } %t393, ptr %l210, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 0
  %t396 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  store i64 %t397, ptr %l212, !tbaa !24
  %t399 = load i64, ptr %l212, !tbaa !24
  %t400 = icmp eq i64 %t395, %t399
  br i1 %t400, label %bb95, label %bb96
bb95:
  %t402 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l212, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  br label %bb97
bb96:
  %t408 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t408, ptr %l22, !tbaa !27
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb98:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load %"compiler/free:letGo", ptr %l20
  %t411 = load i64, ptr %l11, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %s15, ptr %t409, %"compiler/free:letGo" %t410, i64 %t411)
  store { i64, ptr } %t415, ptr %l220
  br label %bb99
bb99:
  %t416 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t418 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 1
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t421 = add i64 %t417, %t420
  %t422 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t424 = add i64 %t421, %t423
  %t425 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = add i64 %t424, %t427
  %t429 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t431 = add i64 %t428, %t430
  %t432 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t431)
  call void @olang_textcopy(ptr %t432, ptr %t416, i64 %t417)
  %t433 = getelementptr i8, ptr %t432, i64 %t417
  call void @olang_textcopy(ptr %t433, ptr %t419, i64 %t420)
  %t434 = getelementptr i8, ptr %t433, i64 %t420
  call void @olang_textcopy(ptr %t434, ptr %t422, i64 %t423)
  %t435 = getelementptr i8, ptr %t434, i64 %t423
  call void @olang_textcopy(ptr %t435, ptr %t426, i64 %t427)
  %t436 = getelementptr i8, ptr %t435, i64 %t427
  call void @olang_textcopy(ptr %t436, ptr %t429, i64 %t430)
  %t437 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t432, 1
  store { i64, ptr } %t438, ptr %l221, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  %t441 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 0
  store i64 %t442, ptr %l223, !tbaa !24
  %t444 = load i64, ptr %l223, !tbaa !24
  %t445 = icmp eq i64 %t440, %t444
  br i1 %t445, label %bb100, label %bb101
bb100:
  %t447 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = load i64, ptr %l223, !tbaa !24
  %t452 = mul i64 %t451, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t448, ptr %t450, i64 %t452, i1 false)
  br label %bb102
bb101:
  %t453 = load { i64, ptr }, ptr %l221, !tbaa !27
  store { i64, ptr } %t453, ptr %l22, !tbaa !27
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb103:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/free:Free", ptr %t454, i32 0, i32 44
  %t457 = load i64, ptr %l11, !tbaa !24
  %t460 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t456, i64 %t457)
  store %"compiler/free:reason" %t460, ptr %l228
  br label %bb104
bb104:
  %t461 = load %"compiler/free:reason", ptr %l228
  store %"compiler/free:reason" %t461, ptr %l23
  %t462 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 3
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l24, !tbaa !27
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/free:Free", ptr %t465, i32 0, i32 42
  %t468 = load i64, ptr %l11, !tbaa !24
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t467, i64 %t468)
  store i64 %t471, ptr %l233
  br label %bb105
bb105:
  %t472 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t473 = load i64, ptr %l233, !tbaa !24
  %t475 = icmp eq i64 %t473, %t472
  br i1 %t475, label %bb106, label %bb107
bb106:
  store { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb108
bb107:
  br label %bb108
bb108:
  %t477 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 1
  %t478 = load i64, ptr %t477, !tbaa !24
  %t480 = icmp sge i64 %t478, 0
  br i1 %t480, label %bb109, label %bb110
bb109:
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 1
  %t484 = load i64, ptr %t483, !tbaa !24
  %t485 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 2
  %t486 = getelementptr %"compiler/source:Span", ptr %t485, i32 0, i32 0
  %t487 = load i32, ptr %t486, !tbaa !23
  %t489 = sext i32 %t487 to i64
  %t493 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t482, i64 %t484, i64 %t489)
  store { i64, ptr } %t493, ptr %l243
  br label %bb111
bb110:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t496 = load i64, ptr %t495, !tbaa !24
  %t497 = load i64, ptr %l21, !tbaa !24
  %t501 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t494, i64 %t496, i64 %t497)
  store { i64, ptr } %t501, ptr %l248
  br label %bb112
bb111:
  %t502 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t503, i64 %t504)
  %t506 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  store { i64, ptr } %t507, ptr %l238, !tbaa !27
  br label %bb113
bb112:
  %t509 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 1
  %t511 = extractvalue { i64, ptr } %t509, 0
  %t512 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t510, i64 %t511)
  %t513 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  store { i64, ptr } %t514, ptr %l238, !tbaa !27
  br label %bb113
bb113:
  %t516 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t516, ptr %l25, !tbaa !27
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t519 = load i64, ptr %t518, !tbaa !24
  %t520 = load i64, ptr %l21, !tbaa !24
  %t524 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t517, i64 %t519, i64 %t520)
  store { i64, ptr } %t524, ptr %l253
  br label %bb114
bb114:
  %t525 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t526 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t532 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t533 = add i64 %t530, %t532
  %t535 = extractvalue { i64, ptr } %t525, 1
  %t536 = extractvalue { i64, ptr } %t525, 0
  %t537 = add i64 %t533, %t536
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t540 = add i64 %t537, %t539
  %t542 = extractvalue { i64, ptr } %t526, 1
  %t543 = extractvalue { i64, ptr } %t526, 0
  %t544 = add i64 %t540, %t543
  %t545 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t547 = add i64 %t544, %t546
  %t549 = extractvalue { i64, ptr } %t527, 1
  %t550 = extractvalue { i64, ptr } %t527, 0
  %t551 = add i64 %t547, %t550
  %t552 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t554 = add i64 %t551, %t553
  %t555 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t554)
  call void @olang_textcopy(ptr %t555, ptr %t529, i64 %t530)
  %t556 = getelementptr i8, ptr %t555, i64 %t530
  call void @olang_textcopy(ptr %t556, ptr %t531, i64 %t532)
  %t557 = getelementptr i8, ptr %t556, i64 %t532
  call void @olang_textcopy(ptr %t557, ptr %t535, i64 %t536)
  %t558 = getelementptr i8, ptr %t557, i64 %t536
  call void @olang_textcopy(ptr %t558, ptr %t538, i64 %t539)
  %t559 = getelementptr i8, ptr %t558, i64 %t539
  call void @olang_textcopy(ptr %t559, ptr %t542, i64 %t543)
  %t560 = getelementptr i8, ptr %t559, i64 %t543
  call void @olang_textcopy(ptr %t560, ptr %t545, i64 %t546)
  %t561 = getelementptr i8, ptr %t560, i64 %t546
  call void @olang_textcopy(ptr %t561, ptr %t549, i64 %t550)
  %t562 = getelementptr i8, ptr %t561, i64 %t550
  call void @olang_textcopy(ptr %t562, ptr %t552, i64 %t553)
  %t563 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t555, 1
  store { i64, ptr } %t564, ptr %l26, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t566, ptr %l258, !tbaa !27
  %t567 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  store i64 %t568, ptr %l259, !tbaa !24
  %t569 = load i64, ptr %l259, !tbaa !24
  %t570 = mul i64 %t569, 1
  %t571 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l260, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = load i64, ptr %l259, !tbaa !24
  %t579 = mul i64 %t578, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t575, ptr %t577, i64 %t579, i1 false)
  %t580 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t584 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t580)
  store i1 %t584, ptr %l263
  br label %bb115
bb115:
  %t585 = load i1, ptr %l263, !tbaa !21
  %t586 = xor i1 %t585, true
  br i1 %t586, label %bb116, label %bb117
bb116:
  %t588 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t588, 1
  %t591 = extractvalue { i64, ptr } %t588, 0
  %t592 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t590, i64 %t591)
  %t593 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  %t596 = extractvalue { i64, ptr } %t594, 0
  %t597 = extractvalue { i64, ptr } %t594, 1
  %t598 = mul i64 %t596, 1
  %t599 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t598)
  call void @llvm.memcpy.p0.p0.i64(ptr %t599, ptr %t597, i64 %t598, i1 false)
  %t600 = insertvalue { i64, ptr } undef, i64 %t596, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t599, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t601)
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t604 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t604)
  br label %bb119
bb119:
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb121:
  %t607 = load i64, ptr %l10, !tbaa !24
  %t609 = add i64 %t607, 1
  store i64 %t609, ptr %l10, !tbaa !24
  br label %bb10
bb122:
  %t611 = load i64, ptr %l3, !tbaa !24
  %t613 = icmp eq i64 %t611, 0
  br i1 %t613, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %l2, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t617 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t617, ptr %l277
  br label %bb126
bb126:
  %t618 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t618, ptr %l278, !tbaa !27
  %t619 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 0
  store i64 %t620, ptr %l279, !tbaa !24
  %t621 = load i64, ptr %l279, !tbaa !24
  %t622 = mul i64 %t621, 1
  %t623 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  store { i64, ptr } %t625, ptr %l280, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = load i64, ptr %l279, !tbaa !24
  %t631 = mul i64 %t630, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t627, ptr %t629, i64 %t631, i1 false)
  %t632 = load { i64, ptr }, ptr %l280, !tbaa !27
  store { i64, ptr } %t632, ptr %l278, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t633 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t633, ptr %rv
  br label %ret
bb127:
  %t634 = load i64, ptr %l3, !tbaa !24
  %t635 = load i64, ptr %l4, !tbaa !24
  %t638 = sub i64 %t634, %t635
  store i64 %t638, ptr %l28, !tbaa !24
  store ptr %l2, ptr %l284, !tbaa !29
  %t640 = load i64, ptr %l3, !tbaa !24
  store i64 %t640, ptr %l285, !tbaa !24
  %t641 = load i64, ptr %l3, !tbaa !24
  %t643 = icmp eq i64 %t641, 1
  br i1 %t643, label %bb128, label %bb129
bb128:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l288, !tbaa !27
  br label %bb130
bb129:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l288, !tbaa !27
  br label %bb130
bb130:
  %t645 = load i64, ptr %l3, !tbaa !24
  %t647 = icmp eq i64 %t645, 1
  br i1 %t647, label %bb131, label %bb132
bb131:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l291, !tbaa !27
  br label %bb133
bb132:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l291, !tbaa !27
  br label %bb133
bb133:
  %t649 = load i64, ptr %l28, !tbaa !24
  store i64 %t649, ptr %l292, !tbaa !24
  %t650 = load i64, ptr %l28, !tbaa !24
  %t652 = icmp eq i64 %t650, 1
  br i1 %t652, label %bb134, label %bb135
bb134:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l295, !tbaa !27
  br label %bb136
bb135:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l295, !tbaa !27
  br label %bb136
bb136:
  %t654 = load i64, ptr %l4, !tbaa !24
  store i64 %t654, ptr %l296, !tbaa !24
  %t655 = load i64, ptr %l4, !tbaa !24
  %t657 = icmp eq i64 %t655, 1
  br i1 %t657, label %bb137, label %bb138
bb137:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l299, !tbaa !27
  br label %bb139
bb138:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l299, !tbaa !27
  br label %bb139
bb139:
  %t659 = load i64, ptr %l4, !tbaa !24
  %t661 = icmp sgt i64 %t659, 0
  br i1 %t661, label %bb140, label %bb141
bb140:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l302, !tbaa !27
  br label %bb142
bb141:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l302, !tbaa !27
  br label %bb142
bb142:
  %t663 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t664 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t665 = load i64, ptr %l285, !tbaa !24
  %t666 = call i64 @__olang_fmt_i64(ptr null, i64 %t665)
  %t667 = add i64 %t664, %t666
  %t668 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t671 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t678 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t685 = load i64, ptr %l292, !tbaa !24
  %t686 = call i64 @__olang_fmt_i64(ptr null, i64 %t685)
  %t687 = add i64 %t684, %t686
  %t688 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t691, 1
  %t693 = extractvalue { i64, ptr } %t691, 0
  %t694 = add i64 %t690, %t693
  %t695 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t696 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t697 = add i64 %t694, %t696
  %t698 = load i64, ptr %l296, !tbaa !24
  %t699 = call i64 @__olang_fmt_i64(ptr null, i64 %t698)
  %t700 = add i64 %t697, %t699
  %t701 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t703 = add i64 %t700, %t702
  %t704 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t704, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = add i64 %t703, %t706
  %t708 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t710 = add i64 %t707, %t709
  %t711 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t712 = extractvalue { i64, ptr } %t711, 1
  %t713 = extractvalue { i64, ptr } %t711, 0
  %t714 = add i64 %t710, %t713
  %t715 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t717 = add i64 %t714, %t716
  %t718 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t717)
  call void @olang_textcopy(ptr %t718, ptr %t663, i64 %t664)
  %t719 = getelementptr i8, ptr %t718, i64 %t664
  %t720 = call i64 @__olang_fmt_i64(ptr %t719, i64 %t665)
  %t721 = getelementptr i8, ptr %t719, i64 %t666
  call void @olang_textcopy(ptr %t721, ptr %t668, i64 %t669)
  %t722 = getelementptr i8, ptr %t721, i64 %t669
  call void @olang_textcopy(ptr %t722, ptr %t672, i64 %t673)
  %t723 = getelementptr i8, ptr %t722, i64 %t673
  call void @olang_textcopy(ptr %t723, ptr %t675, i64 %t676)
  %t724 = getelementptr i8, ptr %t723, i64 %t676
  call void @olang_textcopy(ptr %t724, ptr %t679, i64 %t680)
  %t725 = getelementptr i8, ptr %t724, i64 %t680
  call void @olang_textcopy(ptr %t725, ptr %t682, i64 %t683)
  %t726 = getelementptr i8, ptr %t725, i64 %t683
  %t727 = call i64 @__olang_fmt_i64(ptr %t726, i64 %t685)
  %t728 = getelementptr i8, ptr %t726, i64 %t686
  call void @olang_textcopy(ptr %t728, ptr %t688, i64 %t689)
  %t729 = getelementptr i8, ptr %t728, i64 %t689
  call void @olang_textcopy(ptr %t729, ptr %t692, i64 %t693)
  %t730 = getelementptr i8, ptr %t729, i64 %t693
  call void @olang_textcopy(ptr %t730, ptr %t695, i64 %t696)
  %t731 = getelementptr i8, ptr %t730, i64 %t696
  %t732 = call i64 @__olang_fmt_i64(ptr %t731, i64 %t698)
  %t733 = getelementptr i8, ptr %t731, i64 %t699
  call void @olang_textcopy(ptr %t733, ptr %t701, i64 %t702)
  %t734 = getelementptr i8, ptr %t733, i64 %t702
  call void @olang_textcopy(ptr %t734, ptr %t705, i64 %t706)
  %t735 = getelementptr i8, ptr %t734, i64 %t706
  call void @olang_textcopy(ptr %t735, ptr %t708, i64 %t709)
  %t736 = getelementptr i8, ptr %t735, i64 %t709
  call void @olang_textcopy(ptr %t736, ptr %t712, i64 %t713)
  %t737 = getelementptr i8, ptr %t736, i64 %t713
  call void @olang_textcopy(ptr %t737, ptr %t715, i64 %t716)
  %t738 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t718, 1
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = extractvalue { i64, ptr } %t739, 1
  %t743 = mul i64 %t741, 1
  %t744 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t743)
  call void @llvm.memcpy.p0.p0.i64(ptr %t744, ptr %t742, i64 %t743, i1 false)
  %t745 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t746 = insertvalue { i64, ptr } %t745, ptr %t744, 1
  %t747 = load ptr, ptr %l284, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t747, { i64, ptr } %t746)
  br label %bb143
bb143:
  %t750 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t750, ptr %l306
  br label %bb144
bb144:
  %t751 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t751, ptr %l307, !tbaa !27
  %t752 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t753 = extractvalue { i64, ptr } %t752, 0
  store i64 %t753, ptr %l308, !tbaa !24
  %t754 = load i64, ptr %l308, !tbaa !24
  %t755 = mul i64 %t754, 1
  %t756 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t755)
  %t757 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  store { i64, ptr } %t758, ptr %l309, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = load i64, ptr %l308, !tbaa !24
  %t764 = mul i64 %t763, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t760, ptr %t762, i64 %t764, i1 false)
  %t765 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t765, ptr %l307, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t766 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t766, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eRetireDropped(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:retire"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/free:retire"
  %l26 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca i64
  %l43 = alloca i64
  %l46 = alloca i1
  %l48 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 73
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 13
  store ptr %t11, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t13 = load i64, ptr %l4, !tbaa !24
  store i64 %t13, ptr %l15, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eLen_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l17
  br label %bb5
bb5:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb40
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call %"compiler/free:retire" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eAt_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/free:retire" %t27, ptr %l22
  br label %bb9
bb9:
  %t28 = load %"compiler/free:retire", ptr %l22
  store %"compiler/free:retire" %t28, ptr %l5
  %t29 = getelementptr %"compiler/free:retire", ptr %l5, i32 0, i32 0
  %t30 = load i64, ptr %t29, !tbaa !24
  %t34 = icmp ne i64 %t30, %a1
  br i1 %t34, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb13
bb11:
  %t36 = getelementptr %"compiler/free:retire", ptr %l5, i32 0, i32 1
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l27
  store %"compiler/source:Span" %a2, ptr %l29
  %t41 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %l27, ptr %l29)
  store i1 %t41, ptr %l31
  br label %bb12
bb12:
  %t42 = load i1, ptr %l31, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb15:
  br label %bb16
bb16:
  %t46 = getelementptr %"compiler/free:retire", ptr %l5, i32 0, i32 2
  store ptr %t46, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t48 = load i64, ptr %l7, !tbaa !24
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %t49)
  store i64 %t51, ptr %l36
  br label %bb18
bb18:
  %t52 = load i64, ptr %l34, !tbaa !24
  %t53 = load i64, ptr %l36, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb19, label %bb20
bb19:
  br label %bb38
bb20:
  br label %bb21
bb21:
  %t58 = load ptr, ptr %l6, !tbaa !29
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %t58, i64 %t59)
  store i64 %t62, ptr %l41
  br label %bb22
bb22:
  %t63 = load i64, ptr %l41, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @compiler_2ffree_2eokind(i64 %t64)
  store i64 %t66, ptr %l43
  br label %bb23
bb23:
  %t67 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp eq i64 %t68, %t67
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 12
  store ptr %t74, ptr %l48, !tbaa !29
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = call i64 @compiler_2ffree_2eoval(i64 %t75)
  store i64 %t77, ptr %l50
  br label %bb26
bb25:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb28
bb26:
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t79 = load i64, ptr %l50, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t78, i64 %t79)
  store i1 %t80, ptr %l51
  br label %bb27
bb27:
  %t81 = load i1, ptr %l51, !tbaa !21
  store i1 %t81, ptr %l46, !tbaa !21
  br label %bb28
bb28:
  %t82 = load i1, ptr %l46, !tbaa !21
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 47
  store ptr %t85, ptr %l54, !tbaa !29
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2eoval(i64 %t86)
  store i64 %t88, ptr %l56
  br label %bb31
bb30:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb33
bb31:
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = load i64, ptr %l56, !tbaa !24
  %t91 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t91, ptr %l57
  br label %bb32
bb32:
  %t92 = load i1, ptr %l57, !tbaa !21
  store i1 %t92, ptr %l52, !tbaa !21
  br label %bb33
bb33:
  %t93 = load i1, ptr %l52, !tbaa !21
  br i1 %t93, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb17
bb38:
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb39:
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb4
bb40:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 73
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  store i64 %t13, ptr %l9
  br label %bb4
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca i32
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l48 = alloca i64
  %l66 = alloca i64
  %l73 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t8, i64 %a1)
  store ptr %t12, ptr %l16
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 1
  %t16 = load { i64, [2 x i64] }, ptr %t15
  store { i64, [2 x i64] } %t16, ptr %l3
  %t18 = load { i64, [2 x i64] }, ptr %l3
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l25
  br label %bb5
bb5:
  %t32 = load i32, ptr %l25, !tbaa !23
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i64 -3, ptr %l27, !tbaa !24
  br label %bb10
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l28, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l31
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t43, ptr %l32
  br label %bb9
bb9:
  %t44 = load i64, ptr %l32, !tbaa !24
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l19, !tbaa !24
  br label %bb51
bb11:
  %t46 = load { i64, [2 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l5, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t59 = load i32, ptr %l6, !tbaa !23
  %t61 = icmp ne i32 %t59, 0
  br i1 %t61, label %bb15, label %bb16
bb15:
  store i64 -3, ptr %l39, !tbaa !24
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l42
  br label %bb17
bb17:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l39, !tbaa !24
  br label %bb18
bb18:
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l19, !tbaa !24
  br label %bb51
bb19:
  %t70 = load { i64, [2 x i64] }, ptr %l3
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 3
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t76 = getelementptr { i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l7, !tbaa !23
  %t83 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t83, ptr %l48
  br label %bb23
bb23:
  %t84 = load i64, ptr %l48, !tbaa !24
  store i64 %t84, ptr %l19, !tbaa !24
  br label %bb51
bb24:
  %t85 = load { i64, [2 x i64] }, ptr %l3
  %t87 = extractvalue { i64, [2 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 6
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t91 = getelementptr { i64, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load i64, ptr %t91
  store i64 %t92, ptr %l8, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %l19, !tbaa !24
  br label %bb51
bb28:
  %t96 = load { i64, [2 x i64] }, ptr %l3
  %t98 = extractvalue { i64, [2 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 5
  br i1 %t99, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 12
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l19, !tbaa !24
  br label %bb51
bb32:
  %t109 = load { i64, [2 x i64] }, ptr %l3
  %t111 = extractvalue { i64, [2 x i64] } %t109, 0
  %t112 = icmp eq i64 %t111, 9
  br i1 %t112, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 -3, ptr %l19, !tbaa !24
  br label %bb51
bb36:
  %t114 = load { i64, [2 x i64] }, ptr %l3
  %t116 = extractvalue { i64, [2 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 4
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t119 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t120 = getelementptr { i32 }, ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l9, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l9, !tbaa !23
  %t126 = sext i32 %t124 to i64
  %t129 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t123, i64 %t126)
  store i64 %t129, ptr %l66
  br label %bb40
bb40:
  %t130 = load i64, ptr %l66, !tbaa !24
  store i64 %t130, ptr %l19, !tbaa !24
  br label %bb51
bb41:
  %t131 = load { i64, [2 x i64] }, ptr %l3
  %t133 = extractvalue { i64, [2 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 8
  br i1 %t134, label %bb42, label %bb43
bb42:
  %t136 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t137 = getelementptr { i32, i32, i64 }, ptr %t136, i32 0, i32 0
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l10, !tbaa !23
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l10, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t146 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t140, i64 %t143)
  store i64 %t146, ptr %l73
  br label %bb45
bb45:
  %t147 = load i64, ptr %l73, !tbaa !24
  store i64 %t147, ptr %l19, !tbaa !24
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -4, ptr %l19, !tbaa !24
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_26303021143ae8be_4bef98a84a02e70a)
  unreachable
bb51:
  %t148 = load i64, ptr %l19, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { ptr, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 2
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 5
  %t19 = load { ptr, ptr }, ptr %t18
  %t21 = extractvalue { ptr, ptr } %t19, 0
  %t22 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t23 = icmp eq ptr %t21, %t22
  %t24 = extractvalue { ptr, ptr } %t19, 1
  %t25 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t26 = icmp eq ptr %t24, %t25
  %t27 = and i1 %t23, %t26
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l9, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l16, !tbaa !24
  %t33 = load i64, ptr %l16, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l16, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 5
  %t52 = load { ptr, ptr }, ptr %t51
  store { ptr, ptr } %t52, ptr %l20
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l23
  br label %bb9
bb9:
  %t58 = load { ptr, ptr }, ptr %l20
  %t59 = extractvalue { ptr, ptr } %t58, 0
  %t60 = extractvalue { ptr, ptr } %t58, 1
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = call { i64, ptr } %t59(ptr %t60, ptr %s0, i32 %t61)
  store { i64, ptr } %t62, ptr %l24
  br label %bb10
bb10:
  %t63 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = getelementptr i8, ptr %t69, i64 %t65
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t24, i32 %t25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4cef24e7d17769b7_e2744f91577a9953)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestroyErrors(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:reason"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l80 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca %"compiler/typed:Local"
  %l104 = alloca { i64, ptr }
  %l107 = alloca i64
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca %"compiler/source:Span"
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca { i64, [3 x i64] }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l138 = alloca i1
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca ptr
  %l150 = alloca { i64, [3 x i64] }
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l154 = alloca i64
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i64
  %l162 = alloca %"compiler/msgs:Msg"
  %l163 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l166 = alloca { i64, [3 x i64] }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca ptr
  %l170 = alloca { i64, [3 x i64] }
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca i64
  %l177 = alloca %"compiler/free:reason"
  %l180 = alloca ptr
  %l181 = alloca i64
  %l187 = alloca { i64, [3 x i64] }
  %l189 = alloca %"compiler/msgs:Msg"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca { i64, [3 x i64] }
  %l194 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t213 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t365 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 72
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l24
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 8
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l27
  br label %bb5
bb5:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l34, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l54
  br label %bb16
bb16:
  %t78 = load i1, ptr %l54, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb18:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 66
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l60
  br label %bb19
bb19:
  %t88 = load i1, ptr %l60, !tbaa !21
  store i1 %t88, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb22:
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 60
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l64
  br label %bb24
bb24:
  %t97 = load i64, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:Free", ptr %t98, i32 0, i32 1
  %t104 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t100, i64 %t97)
  store ptr %t104, ptr %l68
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l68, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  store ptr %l2, ptr %l69, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 62
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t108, i64 %t109)
  store %"compiler/source:Span" %t112, ptr %l73
  br label %bb26
bb26:
  %t113 = getelementptr %"compiler/source:Span", ptr %l73, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t118 = mul i64 %t116, 4096
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  %t125 = add i64 %t118, %t122
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %t126, i64 %t125)
  store i1 %t128, ptr %l80
  br label %bb27
bb27:
  %t129 = load i1, ptr %l80, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb29:
  br label %bb30
bb30:
  store ptr %l2, ptr %l81, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:Free", ptr %t130, i32 0, i32 62
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t132, i64 %t133)
  store %"compiler/source:Span" %t136, ptr %l85
  br label %bb31
bb31:
  %t137 = getelementptr %"compiler/source:Span", ptr %l85, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t142 = mul i64 %t140, 4096
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 3
  %t146 = load i64, ptr %t145, !tbaa !24
  %t149 = add i64 %t142, %t146
  %t150 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t150, i64 %t149)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l95, !tbaa !29
  %t162 = load ptr, ptr %l10, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 7
  store ptr %t164, ptr %l97, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 61
  %t168 = load i64, ptr %l8, !tbaa !24
  %t171 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l101
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l97, !tbaa !29
  %t173 = load i64, ptr %l101, !tbaa !24
  %t174 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t172, i64 %t173)
  store %"compiler/typed:Local" %t174, ptr %l102
  br label %bb34
bb34:
  %t175 = getelementptr %"compiler/typed:Local", ptr %l102, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t177, i32 %t176)
  store { i64, ptr } %t179, ptr %l104
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t181, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t187 = load ptr, ptr %l10, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 3
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l107, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/free:Free", ptr %t191, i32 0, i32 62
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t193, i64 %t194)
  store %"compiler/source:Span" %t197, ptr %l111
  br label %bb36
bb36:
  %t198 = getelementptr %"compiler/source:Span", ptr %l111, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store i64 %t201, ptr %l113, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:Free", ptr %t202, i32 0, i32 62
  %t205 = load i64, ptr %l8, !tbaa !24
  %t208 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t204, i64 %t205)
  store %"compiler/source:Span" %t208, ptr %l117
  br label %bb37
bb37:
  %t209 = getelementptr %"compiler/source:Span", ptr %l117, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load i64, ptr %l107, !tbaa !24
  %t216 = insertvalue { i64, i64, i64 } undef, i64 %t215, 0
  %t217 = load i64, ptr %l113, !tbaa !24
  %t218 = insertvalue { i64, i64, i64 } %t216, i64 %t217, 1
  %t220 = insertvalue { i64, i64, i64 } %t218, i64 %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { i64, i64, i64 } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  store { i64, [3 x i64] } %t222, ptr %l12
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/free:Free", ptr %t224, i32 0, i32 64
  %t227 = load i64, ptr %l8, !tbaa !24
  %t230 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t226, i64 %t227)
  store i1 %t230, ptr %l124
  br label %bb38
bb38:
  %t231 = load i1, ptr %l124, !tbaa !21
  br i1 %t231, label %bb39, label %bb40
bb39:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/free:Free", ptr %t232, i32 0, i32 65
  %t235 = load i64, ptr %l8, !tbaa !24
  %t238 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l129
  br label %bb41
bb40:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb42
bb41:
  %t239 = load i1, ptr %l129, !tbaa !21
  store i1 %t239, ptr %l125, !tbaa !21
  br label %bb42
bb42:
  %t240 = load i1, ptr %l125, !tbaa !21
  br i1 %t240, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l130, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t242, ptr %l131
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %s3, ptr %s7, { i64, ptr } %t243)
  store %"compiler/msgs:Msg" %t245, ptr %l133
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t246 = load ptr, ptr %l130, !tbaa !29
  %t247 = load { i64, [3 x i64] }, ptr %l131
  %t248 = load %"compiler/msgs:Msg", ptr %l133
  %t249 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t246, { i64, [3 x i64] } %t247, %"compiler/msgs:Msg" %t248)
  store i64 %t249, ptr %l134
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb47:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/free:Free", ptr %t250, i32 0, i32 64
  %t253 = load i64, ptr %l8, !tbaa !24
  %t256 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t252, i64 %t253)
  store i1 %t256, ptr %l138
  br label %bb48
bb48:
  %t257 = load i1, ptr %l138, !tbaa !21
  br i1 %t257, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/free:Free", ptr %t258, i32 0, i32 63
  %t261 = load i64, ptr %l8, !tbaa !24
  %t264 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t260, i64 %t261)
  store %"compiler/source:Span" %t264, ptr %l142
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t265 = load %"compiler/source:Span", ptr %l142
  store %"compiler/source:Span" %t265, ptr %l13
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  %t267 = load ptr, ptr %l10, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t274 = sext i32 %t272 to i64
  %t275 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { i64, i64, i64 } undef, i64 %t270, 0
  %t284 = insertvalue { i64, i64, i64 } %t282, i64 %t274, 1
  %t286 = insertvalue { i64, i64, i64 } %t284, i64 %t278, 2
  %t287 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { i64, i64, i64 } %t286, ptr %t287
  %t288 = load { i64, [3 x i64] }, ptr %t279
  store { i64, [3 x i64] } %t288, ptr %l150
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t289, ptr %l151, !tbaa !27
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l152, !tbaa !29
  %t291 = load ptr, ptr %l10, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 3
  %t294 = load i64, ptr %t293, !tbaa !24
  store i64 %t294, ptr %l154, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/free:Free", ptr %t295, i32 0, i32 62
  %t298 = load i64, ptr %l8, !tbaa !24
  %t301 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t297, i64 %t298)
  store %"compiler/source:Span" %t301, ptr %l158
  br label %bb52
bb52:
  %t302 = getelementptr %"compiler/source:Span", ptr %l158, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = sext i32 %t303 to i64
  %t306 = load ptr, ptr %l152, !tbaa !29
  %t307 = load i64, ptr %l154, !tbaa !24
  %t309 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t306, i64 %t307, i64 %t305)
  store i64 %t309, ptr %l161
  br label %bb53
bb53:
  %t310 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t311 = load i64, ptr %l161, !tbaa !24
  %t312 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %s3, ptr %s8, { i64, ptr } %t310, i64 %t311)
  store %"compiler/msgs:Msg" %t312, ptr %l162
  br label %bb54
bb54:
  %t313 = load ptr, ptr %l143, !tbaa !29
  %t314 = load { i64, [3 x i64] }, ptr %l150
  %t315 = load %"compiler/msgs:Msg", ptr %l162
  %t316 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t313, { i64, [3 x i64] } %t314, %"compiler/msgs:Msg" %t315)
  store i64 %t316, ptr %l163
  br label %bb55
bb55:
  %t317 = load i64, ptr %l163, !tbaa !24
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l164, !tbaa !29
  store i64 %t317, ptr %l165, !tbaa !24
  %t320 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t320, ptr %l166
  %t321 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t323 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %s3, ptr %s8, { i64, ptr } %t321)
  store %"compiler/msgs:Msg" %t323, ptr %l168
  br label %bb56
bb56:
  %t324 = load ptr, ptr %l164, !tbaa !29
  %t325 = load i64, ptr %l165, !tbaa !24
  %t326 = load { i64, [3 x i64] }, ptr %l166
  %t327 = load %"compiler/msgs:Msg", ptr %l168
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t324, i64 %t325, { i64, [3 x i64] } %t326, %"compiler/msgs:Msg" %t327)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb58:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l169, !tbaa !29
  %t329 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t329, ptr %l170
  %t330 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t332 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %s3, ptr %s3, { i64, ptr } %t330)
  store %"compiler/msgs:Msg" %t332, ptr %l172
  br label %bb59
bb59:
  %t333 = load ptr, ptr %l169, !tbaa !29
  %t334 = load { i64, [3 x i64] }, ptr %l170
  %t335 = load %"compiler/msgs:Msg", ptr %l172
  %t336 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t333, { i64, [3 x i64] } %t334, %"compiler/msgs:Msg" %t335)
  store i64 %t336, ptr %l173
  br label %bb60
bb60:
  %t337 = load i64, ptr %l173, !tbaa !24
  store i64 %t337, ptr %l15, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 44
  %t341 = load i64, ptr %l8, !tbaa !24
  %t344 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t340, i64 %t341)
  store %"compiler/free:reason" %t344, ptr %l177
  br label %bb61
bb61:
  %t345 = load %"compiler/free:reason", ptr %l177
  store %"compiler/free:reason" %t345, ptr %l16
  %t346 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  %t349 = icmp sge i64 %t347, 0
  br i1 %t349, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l180, !tbaa !29
  %t352 = load i64, ptr %l15, !tbaa !24
  store i64 %t352, ptr %l181, !tbaa !24
  %t353 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t354 = load i64, ptr %t353, !tbaa !24
  %t355 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t356 = getelementptr %"compiler/source:Span", ptr %t355, i32 0, i32 0
  %t357 = load i32, ptr %t356, !tbaa !23
  %t359 = sext i32 %t357 to i64
  %t360 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t361 = getelementptr %"compiler/source:Span", ptr %t360, i32 0, i32 1
  %t362 = load i32, ptr %t361, !tbaa !23
  %t364 = sext i32 %t362 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 0
  store i64 3, ptr %t366
  %t368 = insertvalue { i64, i64, i64 } undef, i64 %t354, 0
  %t370 = insertvalue { i64, i64, i64 } %t368, i64 %t359, 1
  %t372 = insertvalue { i64, i64, i64 } %t370, i64 %t364, 2
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 1
  store { i64, i64, i64 } %t372, ptr %t373
  %t374 = load { i64, [3 x i64] }, ptr %t365
  store { i64, [3 x i64] } %t374, ptr %l187
  %t375 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  %t378 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s9, { i64, ptr } %t376)
  store %"compiler/msgs:Msg" %t378, ptr %l189
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l190, !tbaa !29
  %t380 = load i64, ptr %l15, !tbaa !24
  store i64 %t380, ptr %l191, !tbaa !24
  %t381 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t381, ptr %l192
  %t382 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s10, { i64, ptr } %t383)
  store %"compiler/msgs:Msg" %t385, ptr %l194
  br label %bb66
bb64:
  %t386 = load ptr, ptr %l180, !tbaa !29
  %t387 = load i64, ptr %l181, !tbaa !24
  %t388 = load { i64, [3 x i64] }, ptr %l187
  %t389 = load %"compiler/msgs:Msg", ptr %l189
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t386, i64 %t387, { i64, [3 x i64] } %t388, %"compiler/msgs:Msg" %t389)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb66:
  %t390 = load ptr, ptr %l190, !tbaa !29
  %t391 = load i64, ptr %l191, !tbaa !24
  %t392 = load { i64, [3 x i64] }, ptr %l192
  %t393 = load %"compiler/msgs:Msg", ptr %l194
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t390, i64 %t391, { i64, [3 x i64] } %t392, %"compiler/msgs:Msg" %t393)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb69:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load i1, ptr %l17, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l26
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l26, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l27
  br label %bb15
bb15:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb19
bb19:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l43
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l43, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l44
  br label %bb24
bb24:
  %t68 = load i32, ptr %l44, !range !{i32 0, i32 6}
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l51
  br label %bb29
bb29:
  %t82 = load i1, ptr %l51, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t88 = load i32, ptr %l3, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l57
  br label %bb33
bb33:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t94, ptr %l58
  br label %bb34
bb34:
  %t95 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t95, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb36, label %bb37
bb36:
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t109
  %t114 = load i32, ptr %t113, !tbaa !33
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t116, i32 %t114)
  store i1 %t120, ptr %l70
  br label %bb39
bb39:
  %t121 = load i1, ptr %l70, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l5, !tbaa !24
  br label %bb35
bb44:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t44, i64 %t45)
  store ptr %t46, ptr %l24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l17, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s1, ptr %t51, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t61, ptr %l10, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb)
  unreachable
bb13:
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 3
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb33
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l23
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store ptr %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t53, i32 %t57)
  store { i64, ptr } %t60, ptr %l31
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t64, ptr %l33
  br label %bb12
bb12:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb14:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load i1, ptr %l36, !tbaa !21
  store i1 %t69, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l34, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t73, ptr %l39
  br label %bb19
bb19:
  %t74 = load i1, ptr %l39, !tbaa !21
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb24
bb22:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t78, ptr %l42
  br label %bb23
bb23:
  %t79 = load i1, ptr %l42, !tbaa !21
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t83, ptr %l45
  br label %bb27
bb27:
  %t84 = load i1, ptr %l45, !tbaa !21
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t88, ptr %l48
  br label %bb31
bb31:
  %t89 = load i1, ptr %l48, !tbaa !21
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  %t90 = load i1, ptr %l46, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_708b3215abbdbba7_3cea2bd689d53e8b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 2
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l34 = alloca %"compiler/free:reason"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 42
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 42
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp ne i64 %t24, %t23
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 42
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 44
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t46 = extractvalue { i64, ptr } %a5, 1
  %t47 = extractvalue { i64, ptr } %a5, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t62 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t41, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %t57)
  store %"compiler/free:reason" %t62, ptr %l34
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t64 = load i64, ptr %l27, !tbaa !24
  %t65 = load %"compiler/free:reason", ptr %l34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64, %"compiler/free:reason" %t65)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 42
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp ne i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %t13, i64 %t14, i64 %t15, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
  br label %bb5
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 57
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i32
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l115 = alloca %"compiler/free:leaf"
  %l117 = alloca %"compiler/free:leaf"
  %l119 = alloca { i64, ptr }
  %l122 = alloca i32
  %l125 = alloca i32
  %l128 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca i32
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca %"compiler/free:leaf"
  %l153 = alloca %"compiler/free:leaf"
  %l156 = alloca i64
  %l166 = alloca i64
  %l169 = alloca i64
  %l193 = alloca ptr
  %l196 = alloca %"compiler/free:leaf"
  %l198 = alloca %"compiler/free:leaf"
  %l204 = alloca ptr
  %l205 = alloca i32
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l30
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l27, !tbaa !29
  %t12 = load i32, ptr %l30, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l31
  br label %bb3
bb3:
  %t14 = load i32, ptr %l31, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l32
  br label %bb4
bb4:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t16, ptr %lp4
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t18 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %t18
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l35
  br label %bb5
bb5:
  %t24 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb9
bb7:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l42
  br label %bb8
bb8:
  %t36 = load i1, ptr %l42, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l39, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb14
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l45, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l48
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l45, !tbaa !29
  %t47 = load i32, ptr %l48, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t48, ptr %l49
  br label %bb13
bb13:
  %t49 = load i32, ptr %l49, !range !{i32 0, i32 6}
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %lp4
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t57
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 18
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %t62, i32 %t63)
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t66, 0
  store i32 %t68, ptr %l59
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb19, label %ok.70, !prof !99
ok.70:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l58
  br label %bb18
bb18:
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %l58)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l61
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l62
  br label %bb22
bb21:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l54
  br label %bb23
bb22:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l54
  br label %bb23
bb23:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t76, ptr %lp5
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  %t78 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:Free", ptr %t79, i32 0, i32 18
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %t81, i32 %t82)
  store i1 %t85, ptr %l66
  br label %bb24
bb24:
  %t86 = load i1, ptr %l66, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %lp5
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t87
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 18
  store ptr %t92, ptr %l69, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  store i32 %t93, ptr %l70, !tbaa !23
  %t94 = load ptr, ptr %lp4
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l71
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l71)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l73
  br label %bb28
bb28:
  %t98 = load ptr, ptr %l69, !tbaa !29
  %t99 = load i32, ptr %l70, !tbaa !23
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t98, i32 %t99, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100)
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l2, !tbaa !29
  store ptr %t101, ptr %l74, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l77
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l74, !tbaa !29
  %t108 = load i32, ptr %l77, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l78
  br label %bb31
bb31:
  %t110 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t110, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load i64, ptr %l7, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t141 = load i64, ptr %l87, !tbaa !24
  store i64 %t141, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t142 = load i64, ptr %l84, !tbaa !24
  store i64 %t142, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb39, label %bb40
bb39:
  br label %bb93
bb40:
  br label %bb41
bb41:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load i64, ptr %l9, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l12, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l3, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t167 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t161, i32 %t162, i64 %t163)
  store i64 %t167, ptr %l108
  br label %bb42
bb42:
  %t168 = load i64, ptr %l108, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  br i1 %t171, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %lp4
  store ptr %t173, ptr %l111, !tbaa !29
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = mul i64 1, 8
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 1, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l113, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 0
  store i64 %t174, ptr %t182, !tbaa !34
  %t183 = load i64, ptr %l13, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t186 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s5, { i64, ptr } %t184, i64 %t183)
  store %"compiler/free:leaf" %t186, ptr %l115
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t188 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s5, ptr %l115)
  store %"compiler/free:leaf" %t188, ptr %l117
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l111, !tbaa !29
  %t190 = load %"compiler/free:leaf", ptr %l117
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s5, ptr %t189, %"compiler/free:leaf" %t190)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb48:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t192, ptr %l119, !tbaa !27
  %t193 = load i64, ptr %l12, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t191, i32 %t198)
  store i32 %t201, ptr %l122
  br label %bb49
bb49:
  %t202 = load i32, ptr %l122, !tbaa !23
  store i32 %t202, ptr %l14, !tbaa !23
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t204 = load i32, ptr %l14, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l125
  br label %bb50
bb50:
  %t208 = load i32, ptr %l125, !range !{i32 0, i32 33}
  %t210 = trunc i64 18 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb51, label %bb52
bb51:
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t214 = load i32, ptr %l14, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l131
  br label %bb53
bb52:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb54
bb53:
  %t218 = load i1, ptr %l131, !tbaa !21
  store i1 %t218, ptr %l128, !tbaa !21
  br label %bb54
bb54:
  %t219 = load i1, ptr %l128, !tbaa !21
  br i1 %t219, label %bb55, label %bb56
bb55:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l133, !tbaa !29
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l136
  br label %bb57
bb56:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb59
bb57:
  %t226 = load ptr, ptr %l133, !tbaa !29
  %t227 = load i32, ptr %l136, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l137
  br label %bb58
bb58:
  %t229 = load i32, ptr %l137, !range !{i32 0, i32 6}
  %t231 = trunc i64 0 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l132, !tbaa !21
  br label %bb59
bb59:
  %t234 = load i1, ptr %l132, !tbaa !21
  br i1 %t234, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l14, !tbaa !23
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s7, ptr %t235, i32 %t236)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l142
  br label %bb62
bb61:
  br label %bb91
bb62:
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  %t241 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %t241
  store ptr %t241, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s8
  %t243 = load i64, ptr %l16, !tbaa !24
  store i64 %t243, ptr %l144, !tbaa !24
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %t244)
  store i64 %t246, ptr %l146
  br label %bb64
bb64:
  %t247 = load i64, ptr %l144, !tbaa !24
  %t248 = load i64, ptr %l146, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s8)
  br label %bb90
bb66:
  br label %bb67
bb67:
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t254 = load i64, ptr %l16, !tbaa !24
  %t257 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %s7, ptr %t253, i64 %t254)
  store %"compiler/free:leaf" %t257, ptr %l151
  br label %bb68
bb68:
  %t259 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s7, ptr %l151)
  store %"compiler/free:leaf" %t259, ptr %l153
  br label %bb69
bb69:
  %t260 = load %"compiler/free:leaf", ptr %l153
  store %"compiler/free:leaf" %t260, ptr %l17
  %t261 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l156, !tbaa !24
  %t267 = load i64, ptr %l156, !tbaa !24
  %t268 = icmp sge i64 %t267, 0
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load i64, ptr %l156, !tbaa !24
  %t271 = icmp sle i64 %t270, 1152921504606846975
  br i1 %t271, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb72:
  %t273 = load i64, ptr %l156, !tbaa !24
  %t274 = mul i64 %t273, 8
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l18, !tbaa !27
  %t279 = load i64, ptr %l12, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i64, ptr %t282, i64 0
  store i64 %t279, ptr %t283, !tbaa !34
  store i64 0, ptr %l19, !tbaa !24
  %t284 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  store i64 %t287, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l19, !tbaa !24
  %t293 = icmp sgt i64 %t289, %t290
  br i1 %t293, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb74:
  %t295 = load i64, ptr %l21, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb79
bb76:
  %t299 = load i64, ptr %l20, !tbaa !24
  %t300 = load i64, ptr %l19, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = add i64 %t303, %t304
  %t309 = sub i64 %t307, 1
  %t310 = load i64, ptr %l21, !tbaa !24
  %t313 = sdiv i64 %t309, %t310
  store i64 %t313, ptr %l169, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb78
bb78:
  %t315 = load i64, ptr %l169, !tbaa !24
  store i64 %t315, ptr %l166, !tbaa !24
  br label %bb79
bb79:
  %t316 = load i64, ptr %l166, !tbaa !24
  store i64 %t316, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb80
bb80:
  %t317 = load i64, ptr %l23, !tbaa !24
  %t318 = load i64, ptr %l22, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t325 = load i64, ptr %l19, !tbaa !24
  %t326 = load i64, ptr %l23, !tbaa !24
  %t327 = load i64, ptr %l21, !tbaa !24
  %t330 = mul i64 %t326, %t327
  %t333 = add i64 %t325, %t330
  store i64 %t333, ptr %l24, !tbaa !24
  %t335 = load i64, ptr %l24, !tbaa !24
  %t337 = add i64 %t335, 1
  %t338 = load i64, ptr %l24, !tbaa !24
  %t339 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t341 = getelementptr { i64, ptr }, ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i64, ptr %t342, i64 %t338
  %t344 = load i64, ptr %t343, !tbaa !34
  %t347 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i64, ptr %t348, i64 %t337
  store i64 %t344, ptr %t349, !tbaa !34
  br label %bb84
bb84:
  %t350 = load i64, ptr %l23, !tbaa !24
  %t352 = add i64 %t350, 1
  store i64 %t352, ptr %l23, !tbaa !24
  br label %bb80
bb85:
  %t354 = load ptr, ptr %lp4
  store ptr %t354, ptr %l193, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t356 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t357 = load i64, ptr %t356, !tbaa !24
  %t360 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s8, { i64, ptr } %t355, i64 %t357)
  store %"compiler/free:leaf" %t360, ptr %l196
  br label %bb86
bb86:
  %t362 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s8, ptr %l196)
  store %"compiler/free:leaf" %t362, ptr %l198
  br label %bb87
bb87:
  %t363 = load ptr, ptr %l193, !tbaa !29
  %t364 = load %"compiler/free:leaf", ptr %l198
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s8, ptr %t363, %"compiler/free:leaf" %t364)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb89:
  %t365 = load i64, ptr %l16, !tbaa !24
  %t367 = add i64 %t365, 1
  store i64 %t367, ptr %l16, !tbaa !24
  br label %bb63
bb90:
  call void @__olang_scope_close(ptr %s7)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t369 = load i64, ptr %l11, !tbaa !24
  %t371 = add i64 %t369, 1
  store i64 %t371, ptr %l11, !tbaa !24
  br label %bb38
bb93:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/free:Free", ptr %t373, i32 0, i32 18
  store ptr %t375, ptr %l204, !tbaa !29
  %t376 = load i32, ptr %l3, !tbaa !23
  store i32 %t376, ptr %l205, !tbaa !23
  %t377 = load ptr, ptr %lp4
  %t378 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t377
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t378, ptr %l206
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l208
  br label %bb94
bb94:
  %t381 = load ptr, ptr %l204, !tbaa !29
  %t382 = load i32, ptr %l205, !tbaa !23
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t381, i32 %t382, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383)
  br label %bb95
bb95:
  %t384 = load ptr, ptr %lp4
  %t385 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t384
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 %a2, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t23, 1
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp ne i8 %t30, 10
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l14, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  br label %bb2
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t47 = icmp slt i64 %t41, %t44
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 32
  br i1 %t57, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb14:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb16
bb15:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t60
  %t65 = load i8, ptr %t64, !tbaa !32
  %t67 = icmp eq i8 %t65, 9
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l32, !tbaa !21
  store i1 %t69, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l27, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l4, !tbaa !24
  br label %bb21
bb21:
  br label %bb11
bb22:
  %t77 = load i64, ptr %l4, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %s0, ptr %t12, i32 %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l11
  br label %bb6
bb6:
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t18 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %t18
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %s0, ptr %t18)
  store i64 %t20, ptr %l13
  br label %bb7
bb7:
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = icmp sgt i64 %t21, 0
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t28, ptr %l18
  br label %bb10
bb9:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l18, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca { i64, [1 x i64] }
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load i64, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 5
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l26
  br label %bb6
bb6:
  %t27 = load i32, ptr %l26, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 6
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i64, ptr %l29, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t82, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l57
  br label %bb18
bb18:
  %t87 = load { i64, [1 x i64] }, ptr %l57
  store { i64, [1 x i64] } %t87, ptr %l11
  %t88 = load { i64, [1 x i64] }, ptr %l11
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l11, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l12, !tbaa !23
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t97 = load i32, ptr %l12, !tbaa !23
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l10, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_bc9d64d7693be970_b83238a2b46aaa8c)
  unreachable
bb30:
  br label %bb31
bb31:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb14
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l54 = alloca { i64, [1 x i64] }
  %l55 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 3
  %t15 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t11, i64 %a1)
  store ptr %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l18, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %a3)
  store ptr %t23, ptr %l22
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l22, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 6
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l25
  br label %bb6
bb6:
  %t29 = load i64, ptr %l25, !tbaa !24
  store i64 %t29, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t56 = load i64, ptr %l32, !tbaa !24
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l29, !tbaa !24
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  %t76 = load ptr, ptr %l4, !tbaa !29
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Call", ptr %t77, i32 0, i32 3
  %t80 = load i32, ptr %t79, !tbaa !23
  %t85 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t76, i32 %t80, i64 %t74)
  store { i64, [1 x i64] } %t85, ptr %l54
  br label %bb17
bb17:
  %t86 = load { i64, [1 x i64] }, ptr %l54
  %t87 = call i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %t86)
  store i1 %t87, ptr %l55
  br label %bb18
bb18:
  %t88 = load i1, ptr %l55, !tbaa !21
  br i1 %t88, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l9, !tbaa !24
  br label %bb13
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l14 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 10
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l22
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i1, ptr %l25, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:store"
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/free:store"
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l67 = alloca i32
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l85 = alloca i64
  %l87 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 40
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l17
  br label %bb6
bb6:
  %t16 = load i64, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = icmp slt i64 %t16, %t17
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb28
bb8:
  br label %bb9
bb9:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/free:store" %t26, ptr %l22
  br label %bb10
bb10:
  %t27 = load %"compiler/free:store", ptr %l22
  store %"compiler/free:store" %t27, ptr %l5
  %t28 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 21
  %t38 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t37, i64 %t39)
  store i1 %t42, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t43 = load i1, ptr %l30, !tbaa !21
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t45 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 6
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb17, label %bb18
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb23
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t50 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t55 = icmp eq i64 %t51, %t52
  store i1 %t55, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l34, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb22
bb21:
  %t58 = getelementptr %"compiler/free:store", ptr %l5, i32 0, i32 4
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t63 = icmp eq i64 %t59, %t60
  store i1 %t63, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t65 = load i1, ptr %l38, !tbaa !21
  store i1 %t65, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb26
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l4, !tbaa !24
  br label %bb5
bb28:
  %t71 = load i1, ptr %l2, !tbaa !21
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l1, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l49
  br label %bb32
bb32:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 9
  %t86 = load i64, ptr %l1, !tbaa !24
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l54
  br label %bb36
bb36:
  %t90 = load i64, ptr %l54, !tbaa !24
  %t91 = icmp slt i64 %t90, 0
  br i1 %t91, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l58
  br label %bb40
bb40:
  %t97 = load ptr, ptr %l58, !tbaa !29
  store ptr %t97, ptr %l6, !tbaa !29
  %t98 = load ptr, ptr %l6, !tbaa !29
  store ptr %t98, ptr %l59, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/free:Free", ptr %t99, i32 0, i32 8
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t101, i64 %t102)
  store i32 %t105, ptr %l63
  br label %bb41
bb41:
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = load i32, ptr %l63, !tbaa !23
  %t108 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t108, ptr %l64
  br label %bb42
bb42:
  %t109 = load i32, ptr %l64, !tbaa !23
  store i32 %t109, ptr %l7, !tbaa !23
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t111 = load i32, ptr %l7, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l67
  br label %bb43
bb43:
  %t115 = load i32, ptr %l67, !range !{i32 0, i32 33}
  %t117 = trunc i64 18 to i32
  %t118 = icmp eq i32 %t115, %t117
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t123 = load ptr, ptr %l6, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t125 = load i32, ptr %l7, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l75
  br label %bb47
bb47:
  %t129 = load ptr, ptr %l72, !tbaa !29
  %t130 = load i32, ptr %l75, !tbaa !23
  %t131 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t131, ptr %l76
  br label %bb48
bb48:
  %t132 = load i64, ptr %l76, !tbaa !24
  store i64 %t132, ptr %l8, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t135 = icmp sge i64 %t133, 0
  br i1 %t135, label %bb49, label %bb50
bb49:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %l80, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/load:Loader", ptr %t144, i32 0, i32 10
  %t148 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l85
  br label %bb51
bb50:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb52
bb51:
  %t149 = load i64, ptr %l80, !tbaa !24
  %t150 = load i64, ptr %l85, !tbaa !24
  %t151 = icmp slt i64 %t149, %t150
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb52
bb52:
  %t153 = load i1, ptr %l79, !tbaa !21
  br i1 %t153, label %bb53, label %bb54
bb53:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/free:Free", ptr %t154, i32 0, i32 0
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 10
  %t163 = load i64, ptr %l8, !tbaa !24
  %t166 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t162, i64 %t163)
  store ptr %t166, ptr %l93
  br label %bb55
bb54:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb57
bb55:
  %t167 = load ptr, ptr %l93, !tbaa !29
  %t169 = getelementptr %"compiler/load:Module", ptr %t167, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t172 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t172, ptr %l96
  br label %bb56
bb56:
  %t173 = load i1, ptr %l96, !tbaa !21
  %t174 = xor i1 %t173, true
  store i1 %t174, ptr %l87, !tbaa !21
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i1, ptr %l87, !tbaa !21
  store i1 %t176, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [1 x i64] }
  %l16 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l49 = alloca { i64, [1 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l16
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 6
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l18
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l18)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l20
  br label %bb5
bb5:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l2)
  store i64 %t21, ptr %l22
  br label %bb6
bb6:
  %t22 = load i64, ptr %l22, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp sgt i64 %t23, %t24
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t31 = icmp sgt i64 %t29, 0
  br i1 %t31, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb9:
  %t33 = load i64, ptr %l4, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = sub i64 %t33, %t34
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t37, %t38
  %t43 = sub i64 %t41, 1
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = sdiv i64 %t43, %t44
  store i64 %t47, ptr %l29, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l29, !tbaa !24
  store i64 %t49, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l26, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  br label %bb16
bb16:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  %t64 = mul i64 %t60, %t61
  %t67 = add i64 %t59, %t64
  store i64 %t67, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %s0, ptr %l2, i64 %t69)
  store { i64, [1 x i64] } %t72, ptr %l49
  br label %bb17
bb17:
  %t73 = load { i64, [1 x i64] }, ptr %l49
  store { i64, [1 x i64] } %t73, ptr %l9
  %t74 = load { i64, [1 x i64] }, ptr %l9
  %t76 = extractvalue { i64, [1 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 1
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  %t79 = load { i64, [1 x i64] }, ptr %l9
  %t81 = extractvalue { i64, [1 x i64] } %t79, 0
  %t82 = icmp eq i64 %t81, 2
  br i1 %t82, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t84 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t84, ptr %rv
  br label %ret
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_97a1f172ac127e68_91804f7c420b5df4)
  unreachable
bb28:
  br label %bb29
bb29:
  %t86 = load i64, ptr %l7, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb13
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l107 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l130 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i32
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca i1
  %l168 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i32
  %l203 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l25, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load i32, ptr %l28, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l31
  br label %bb3
bb3:
  %t16 = load i32, ptr %l31, !range !{i32 0, i32 33}
  store i32 %t16, ptr %l4
  %t17 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l34, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 29 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l37, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t36 = trunc i64 0 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t41 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb16, label %bb17
bb16:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l48
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t51 = load i1, ptr %l48, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb22
bb22:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l54
  br label %bb23
bb23:
  %t62 = load i1, ptr %l54, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb24:
  %t63 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l57, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l60
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t74 = load ptr, ptr %l57, !tbaa !29
  %t75 = load i32, ptr %l60, !tbaa !23
  %t76 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l61
  br label %bb28
bb28:
  %t77 = load i1, ptr %l61, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb29:
  %t78 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb32
bb31:
  %t83 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t85 = trunc i64 23 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l67, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l70
  br label %bb35
bb34:
  br label %bb47
bb35:
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = load i32, ptr %l70, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l71
  br label %bb36
bb36:
  %t98 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb38, label %bb39
bb38:
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t111, ptr %l78, !tbaa !27
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t119, i32 %t117)
  store i1 %t123, ptr %l83
  br label %bb41
bb41:
  %t124 = load i1, ptr %l83, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb42, label %bb43
bb42:
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l6, !tbaa !24
  br label %bb37
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  %t133 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l91, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l94
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t144 = load ptr, ptr %l91, !tbaa !29
  %t145 = load i32, ptr %l94, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t144, i32 %t145)
  store { i64, ptr } %t146, ptr %l95
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t147, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb53, label %bb54
bb53:
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t160, ptr %l102, !tbaa !27
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t168, i32 %t166)
  store i1 %t172, ptr %l107
  br label %bb56
bb56:
  %t173 = load i1, ptr %l107, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb57, label %bb58
bb57:
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l10, !tbaa !24
  br label %bb52
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  %t182 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t184 = trunc i64 18 to i32
  %t185 = icmp eq i32 %t182, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb63, label %bb64
bb63:
  store i1 true, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l119
  br label %bb66
bb66:
  %t195 = load i1, ptr %l119, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 17
  %t202 = load i32, ptr %l3, !tbaa !23
  %t205 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t201, i32 %t202)
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l127
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb71, label %ok.209, !prof !99
ok.209:
  store i64 %t206, ptr %l126
  br label %bb70
bb70:
  %t210 = load i64, ptr %l126, !tbaa !24
  store i64 %t210, ptr %l122, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l122, !tbaa !24
  br label %bb73
bb73:
  %t211 = load i64, ptr %l122, !tbaa !24
  store i64 %t211, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = icmp eq i64 %t212, 1
  br i1 %t214, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = icmp eq i64 %t216, 3
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l130, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp eq i64 %t222, 2
  br i1 %t224, label %bb80, label %bb81
bb80:
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 17
  %t230 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t229, i32 %t230, i64 1)
  br label %bb83
bb83:
  store i1 true, ptr %l14, !tbaa !21
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l140, !tbaa !29
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t235 = load i32, ptr %l3, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t238, ptr %l143
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l140, !tbaa !29
  %t240 = load i32, ptr %l143, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t241, ptr %l144
  br label %bb85
bb85:
  %t242 = load i32, ptr %l144, !range !{i32 0, i32 6}
  store i32 %t242, ptr %l15
  %t243 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t245 = trunc i64 0 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load i32, ptr %l3, !tbaa !23
  %t252 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l149
  br label %bb88
bb87:
  %t253 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t255 = trunc i64 1 to i32
  %t256 = icmp eq i32 %t253, %t255
  br i1 %t256, label %bb107, label %bb108
bb88:
  %t258 = load i1, ptr %l149, !tbaa !21
  br i1 %t258, label %bb89, label %bb90
bb89:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb91
bb90:
  br label %bb91
bb91:
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l150, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i32, ptr %l3, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l153
  br label %bb92
bb92:
  %t265 = load ptr, ptr %l150, !tbaa !29
  %t266 = load i32, ptr %l153, !tbaa !23
  %t267 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t265, i32 %t266)
  store { i64, ptr } %t267, ptr %l154
  br label %bb93
bb93:
  %t268 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t268, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l18, !tbaa !24
  br label %bb94
bb94:
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb95, label %bb96
bb95:
  br label %bb106
bb96:
  br label %bb97
bb97:
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t281, ptr %l161, !tbaa !27
  %t282 = load i64, ptr %l17, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  store i32 %t287, ptr %l19, !tbaa !23
  %t289 = load i1, ptr %l14, !tbaa !21
  br i1 %t289, label %bb98, label %bb99
bb98:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l19, !tbaa !23
  %t295 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t291, i32 %t292)
  store i1 %t295, ptr %l168
  br label %bb100
bb99:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb101
bb100:
  %t296 = load i1, ptr %l168, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l165, !tbaa !21
  br label %bb101
bb101:
  %t299 = load i1, ptr %l165, !tbaa !21
  br i1 %t299, label %bb102, label %bb103
bb102:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l17, !tbaa !24
  br label %bb94
bb106:
  br label %bb128
bb107:
  %t304 = load ptr, ptr %l2, !tbaa !29
  store ptr %t304, ptr %l174, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l177
  br label %bb109
bb108:
  %t310 = load i32, ptr %l15, !range !{i32 0, i32 6}
  %t312 = trunc i64 4 to i32
  %t313 = icmp eq i32 %t310, %t312
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb124, label %bb125
bb109:
  %t317 = load ptr, ptr %l174, !tbaa !29
  %t318 = load i32, ptr %l177, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t317, i32 %t318)
  store { i64, ptr } %t319, ptr %l178
  br label %bb110
bb110:
  %t320 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t320, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb111
bb111:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb112, label %bb113
bb112:
  br label %bb123
bb113:
  br label %bb114
bb114:
  %t333 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t333, ptr %l185, !tbaa !27
  %t334 = load i64, ptr %l21, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  store i32 %t339, ptr %l23, !tbaa !23
  %t341 = load i1, ptr %l14, !tbaa !21
  br i1 %t341, label %bb115, label %bb116
bb115:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l23, !tbaa !23
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l192
  br label %bb117
bb116:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb118
bb117:
  %t348 = load i1, ptr %l192, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l189, !tbaa !21
  br label %bb118
bb118:
  %t351 = load i1, ptr %l189, !tbaa !21
  br i1 %t351, label %bb119, label %bb120
bb119:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb121
bb120:
  br label %bb121
bb121:
  br label %bb122
bb122:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l21, !tbaa !24
  br label %bb111
bb123:
  br label %bb127
bb124:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 17
  store ptr %t358, ptr %l200, !tbaa !29
  %t359 = load i32, ptr %l3, !tbaa !23
  store i32 %t359, ptr %l201, !tbaa !23
  %t360 = load i1, ptr %l14, !tbaa !21
  br i1 %t360, label %bb129, label %bb130
bb129:
  store i64 3, ptr %l203, !tbaa !24
  br label %bb131
bb130:
  store i64 2, ptr %l203, !tbaa !24
  br label %bb131
bb131:
  %t362 = load ptr, ptr %l200, !tbaa !29
  %t363 = load i32, ptr %l201, !tbaa !23
  %t364 = load i64, ptr %l203, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t362, i32 %t363, i64 %t364)
  br label %bb132
bb132:
  %t365 = load i1, ptr %l14, !tbaa !21
  store i1 %t365, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/free:letGo"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %l57 = alloca %"compiler/free:letGo"
  %l61 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l83 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l98 = alloca i64
  %l99 = alloca i64
  %l107 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i64
  %l140 = alloca ptr
  %l144 = alloca %"compiler/typed:Local"
  %l146 = alloca { i64, ptr }
  %l148 = alloca i1
  %l152 = alloca i64
  %l154 = alloca i64
  %l159 = alloca i32
  %l167 = alloca ptr
  %l171 = alloca %"compiler/typed:Local"
  %l173 = alloca i32
  %l176 = alloca i1
  %l177 = alloca ptr
  %l180 = alloca i32
  %l181 = alloca i32
  %l184 = alloca i32
  %l190 = alloca ptr
  %l191 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca i32
  %l196 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/free:letGo", ptr %l1
  %t5 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/free:letGo" %t2)
  store { i64, ptr } %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 9
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l30
  br label %bb2
bb2:
  %t14 = load i64, ptr %l30, !tbaa !24
  %t15 = icmp slt i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t19, ptr %l34
  br label %bb5
bb4:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l34, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l32, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l36, !tbaa !27
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/free:letGo", ptr %l1
  %t30 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s0, ptr %t26, %"compiler/free:letGo" %t27)
  store { i64, ptr } %t30, ptr %l40
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l41, !tbaa !24
  %t34 = load i64, ptr %l41, !tbaa !24
  %t35 = mul i64 %t34, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  store { i64, ptr } %t38, ptr %l42, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = load i64, ptr %l41, !tbaa !24
  %t44 = mul i64 %t43, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %t42, i64 %t44, i1 false)
  %t45 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 9
  %t49 = load i64, ptr %l2, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l46
  br label %bb11
bb11:
  %t53 = load i64, ptr %l46, !tbaa !24
  %t54 = icmp slt i64 %t53, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:Free", ptr %t56, i32 0, i32 41
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb36
bb14:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l50, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l52
  br label %bb15
bb15:
  %t64 = load i64, ptr %l50, !tbaa !24
  %t65 = load i64, ptr %l52, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb16, label %bb17
bb16:
  br label %bb35
bb17:
  br label %bb18
bb18:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t70, i64 %t71)
  store %"compiler/free:letGo" %t74, ptr %l57
  br label %bb19
bb19:
  %t75 = load %"compiler/free:letGo", ptr %l57
  store %"compiler/free:letGo" %t75, ptr %l7
  %t76 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 0
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = icmp eq i64 %t77, %t78
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = getelementptr %"compiler/free:letGo", ptr %l7, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = icmp eq i64 %t84, %t86
  store i1 %t89, ptr %l61, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb22
bb22:
  %t91 = load i1, ptr %l61, !tbaa !21
  br i1 %t91, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load %"compiler/free:letGo", ptr %l7
  %t96 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s4, ptr %t92, %"compiler/free:letGo" %t93)
  store { i64, ptr } %t96, ptr %l67
  br label %bb25
bb24:
  br label %bb33
bb25:
  %t97 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t97, ptr %l8, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s4, ptr %s4, { i64, ptr } %t98, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t100, ptr %l69
  br label %bb26
bb26:
  %t101 = load i1, ptr %l69, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l71, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l73, !tbaa !24
  %t110 = load i64, ptr %l73, !tbaa !24
  %t111 = icmp eq i64 %t106, %t110
  br i1 %t111, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  %t113 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l73, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  br label %bb31
bb30:
  %t119 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l75, !tbaa !24
  %t121 = load i64, ptr %l75, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l76, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l75, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t132, ptr %l4, !tbaa !27
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb14
bb35:
  br label %bb36
bb36:
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = icmp slt i64 %t137, %t140
  br i1 %t143, label %bb38, label %bb39
bb38:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t145
  %t150 = load i8, ptr %t149, !tbaa !32
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t150)
  store i1 %t152, ptr %l86
  br label %bb40
bb39:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb48
bb40:
  %t153 = load i1, ptr %l86, !tbaa !21
  br i1 %t153, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb44
bb42:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t159)
  store i1 %t161, ptr %l90
  br label %bb43
bb43:
  %t162 = load i1, ptr %l90, !tbaa !21
  store i1 %t162, ptr %l87, !tbaa !21
  br label %bb44
bb44:
  %t163 = load i1, ptr %l87, !tbaa !21
  br i1 %t163, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb47
bb46:
  %t164 = load i64, ptr %l9, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t164
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = icmp eq i8 %t169, 95
  store i1 %t171, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l91, !tbaa !21
  store i1 %t173, ptr %l83, !tbaa !21
  br label %bb48
bb48:
  %t174 = load i1, ptr %l83, !tbaa !21
  %t175 = xor i1 %t174, true
  br i1 %t175, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t177 = load i64, ptr %l9, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l9, !tbaa !24
  br label %bb52
bb52:
  br label %bb37
bb53:
  %t181 = load i64, ptr %l9, !tbaa !24
  store i64 %t181, ptr %l98, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l99, !tbaa !24
  %t184 = icmp sge i64 0, 0
  br i1 %t184, label %bb54, label %bb55
bb54:
  %t186 = load i64, ptr %l98, !tbaa !24
  %t187 = icmp sle i64 0, %t186
  br i1 %t187, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb56:
  %t189 = load i64, ptr %l98, !tbaa !24
  %t190 = load i64, ptr %l99, !tbaa !24
  %t191 = icmp sle i64 %t189, %t190
  br i1 %t191, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb58:
  %t193 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = load i64, ptr %l98, !tbaa !24
  %t196 = getelementptr i8, ptr %t194, i64 0
  %t197 = sub i64 %t195, 0
  %t198 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t196, 1
  store { i64, ptr } %t199, ptr %l10, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:Free", ptr %t201, i32 0, i32 1
  %t204 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t205 = load i64, ptr %t204, !tbaa !24
  %t208 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t203, i64 %t205)
  store ptr %t208, ptr %l107
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c)
  unreachable
bb60:
  %t209 = load ptr, ptr %l107, !tbaa !29
  store ptr %t209, ptr %l11, !tbaa !29
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t210)
  store ptr %t212, ptr %l109
  br label %bb61
bb61:
  %t213 = load ptr, ptr %l109, !tbaa !29
  store ptr %t213, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/typed:Body", ptr %t214, i32 0, i32 7
  %t218 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t216)
  store i64 %t218, ptr %l112
  br label %bb62
bb62:
  %t219 = load i64, ptr %l112, !tbaa !24
  store i64 %t219, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t220 = load i64, ptr %l14, !tbaa !24
  %t221 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp sgt i64 %t220, %t221
  br i1 %t224, label %bb63, label %bb64
bb63:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb68
bb65:
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = sub i64 %t230, %t231
  %t235 = load i64, ptr %l15, !tbaa !24
  %t238 = add i64 %t234, %t235
  %t240 = sub i64 %t238, 1
  %t241 = load i64, ptr %l15, !tbaa !24
  %t244 = sdiv i64 %t240, %t241
  store i64 %t244, ptr %l119, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb67
bb67:
  %t246 = load i64, ptr %l119, !tbaa !24
  store i64 %t246, ptr %l116, !tbaa !24
  br label %bb68
bb68:
  %t247 = load i64, ptr %l116, !tbaa !24
  store i64 %t247, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s9
  %t248 = load i64, ptr %l17, !tbaa !24
  %t249 = load i64, ptr %l16, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb110
bb71:
  br label %bb72
bb72:
  %t256 = load i64, ptr %l13, !tbaa !24
  %t257 = load i64, ptr %l17, !tbaa !24
  %t258 = load i64, ptr %l15, !tbaa !24
  %t261 = mul i64 %t257, %t258
  %t264 = add i64 %t256, %t261
  store i64 %t264, ptr %l18, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 0
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = getelementptr %"compiler/generic:Program", ptr %t269, i32 0, i32 0
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t274 = getelementptr %"compiler/load:Loader", ptr %t272, i32 0, i32 3
  %t275 = load ptr, ptr %t274, !tbaa !29
  store ptr %t275, ptr %l140, !tbaa !29
  %t276 = load ptr, ptr %l11, !tbaa !29
  %t278 = getelementptr %"compiler/typed:Body", ptr %t276, i32 0, i32 7
  %t279 = load i64, ptr %l18, !tbaa !24
  %t282 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t278, i64 %t279)
  store %"compiler/typed:Local" %t282, ptr %l144
  br label %bb73
bb73:
  %t283 = getelementptr %"compiler/typed:Local", ptr %l144, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t285 = load ptr, ptr %l140, !tbaa !29
  %t287 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t285, i32 %t284)
  store { i64, ptr } %t287, ptr %l146
  br label %bb74
bb74:
  %t288 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t291 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t289, { i64, ptr } %t288)
  store i1 %t291, ptr %l148
  br label %bb75
bb75:
  %t292 = load i1, ptr %l148, !tbaa !21
  %t293 = xor i1 %t292, true
  br i1 %t293, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s9)
  br label %bb109
bb77:
  br label %bb78
bb78:
  store i1 false, ptr %l19, !tbaa !21
  %t295 = load ptr, ptr %l11, !tbaa !29
  %t297 = getelementptr %"compiler/typed:Body", ptr %t295, i32 0, i32 5
  store ptr %t297, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb79
bb79:
  %t299 = load i64, ptr %l21, !tbaa !24
  store i64 %t299, ptr %l152, !tbaa !24
  %t300 = load ptr, ptr %l20, !tbaa !29
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t300)
  store i64 %t302, ptr %l154
  br label %bb80
bb80:
  %t303 = load i64, ptr %l152, !tbaa !24
  %t304 = load i64, ptr %l154, !tbaa !24
  %t305 = icmp slt i64 %t303, %t304
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb81, label %bb82
bb81:
  br label %bb89
bb82:
  br label %bb83
bb83:
  %t309 = load ptr, ptr %l20, !tbaa !29
  %t310 = load i64, ptr %l21, !tbaa !24
  %t313 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t309, i64 %t310)
  store i32 %t313, ptr %l159
  br label %bb84
bb84:
  %t314 = load i32, ptr %l159, !tbaa !23
  %t317 = sext i32 %t314 to i64
  %t318 = load i64, ptr %l18, !tbaa !24
  %t321 = icmp eq i64 %t317, %t318
  br i1 %t321, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t323 = load i64, ptr %l21, !tbaa !24
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l21, !tbaa !24
  br label %bb79
bb89:
  %t327 = load i1, ptr %l19, !tbaa !21
  br i1 %t327, label %bb90, label %bb91
bb90:
  %t329 = load ptr, ptr %l12, !tbaa !29
  store ptr %t329, ptr %l167, !tbaa !29
  %t330 = load ptr, ptr %l11, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Body", ptr %t330, i32 0, i32 7
  %t333 = load i64, ptr %l18, !tbaa !24
  %t336 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t332, i64 %t333)
  store %"compiler/typed:Local" %t336, ptr %l171
  br label %bb92
bb91:
  br label %bb107
bb92:
  %t337 = getelementptr %"compiler/typed:Local", ptr %l171, i32 0, i32 2
  %t338 = load i32, ptr %t337, !tbaa !23
  %t339 = load ptr, ptr %l167, !tbaa !29
  %t341 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t339, i32 %t338)
  store i32 %t341, ptr %l173
  br label %bb93
bb93:
  %t342 = load i32, ptr %l173, !tbaa !23
  store i32 %t342, ptr %l23, !tbaa !23
  %t343 = load ptr, ptr %l12, !tbaa !29
  %t344 = load i32, ptr %l23, !tbaa !23
  %t347 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l176
  br label %bb94
bb94:
  %t348 = load i1, ptr %l176, !tbaa !21
  br i1 %t348, label %bb95, label %bb96
bb95:
  %t349 = load ptr, ptr %l12, !tbaa !29
  store ptr %t349, ptr %l177, !tbaa !29
  %t350 = load ptr, ptr %l12, !tbaa !29
  %t351 = load i32, ptr %l23, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l180
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t355 = load ptr, ptr %l177, !tbaa !29
  %t356 = load i32, ptr %l180, !tbaa !23
  %t357 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t357, ptr %l181
  br label %bb98
bb98:
  %t358 = load i32, ptr %l181, !tbaa !23
  store i32 %t358, ptr %l23, !tbaa !23
  br label %bb99
bb99:
  %t359 = load ptr, ptr %l12, !tbaa !29
  %t360 = load i32, ptr %l23, !tbaa !23
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t359, i32 %t360)
  store i32 %t363, ptr %l184
  br label %bb100
bb100:
  %t364 = load i32, ptr %l184, !range !{i32 0, i32 33}
  %t366 = trunc i64 18 to i32
  %t367 = icmp eq i32 %t364, %t366
  br i1 %t367, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s17
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/free:Free", ptr %t369, i32 0, i32 0
  %t372 = load ptr, ptr %t371, !tbaa !29
  %t374 = getelementptr %"compiler/generic:Program", ptr %t372, i32 0, i32 0
  %t375 = load ptr, ptr %t374, !tbaa !29
  %t377 = getelementptr %"compiler/load:Loader", ptr %t375, i32 0, i32 3
  %t378 = load ptr, ptr %t377, !tbaa !29
  store ptr %t378, ptr %l190, !tbaa !29
  %t379 = load ptr, ptr %l12, !tbaa !29
  store ptr %t379, ptr %l191, !tbaa !29
  %t380 = load ptr, ptr %l12, !tbaa !29
  %t381 = load i32, ptr %l23, !tbaa !23
  %t384 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t380, i32 %t381)
  store i32 %t384, ptr %l194
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t385 = load ptr, ptr %l191, !tbaa !29
  %t386 = load i32, ptr %l194, !tbaa !23
  %t387 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t385, i32 %t386)
  store i32 %t387, ptr %l195
  br label %bb104
bb104:
  %t388 = load ptr, ptr %l190, !tbaa !29
  %t389 = load i32, ptr %l195, !tbaa !23
  %t390 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s17, ptr %t388, i32 %t389)
  store { i64, ptr } %t390, ptr %l196
  br label %bb105
bb105:
  %t391 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t393 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 1
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t396 = add i64 %t392, %t395
  %t397 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t399)
  call void @olang_textcopy(ptr %t400, ptr %t391, i64 %t392)
  %t401 = getelementptr i8, ptr %t400, i64 %t392
  call void @olang_textcopy(ptr %t401, ptr %t394, i64 %t395)
  %t402 = getelementptr i8, ptr %t401, i64 %t395
  call void @olang_textcopy(ptr %t402, ptr %t397, i64 %t398)
  %t403 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t400, 1
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t404, ptr %rv
  br label %ret
bb106:
  br label %bb107
bb107:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t408 = load i64, ptr %t407, !tbaa !24
  %t411 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s9, ptr %t406, i64 %t408)
  store { i64, ptr } %t411, ptr %l200
  br label %bb108
bb108:
  %t412 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t416 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t417 = add i64 %t414, %t416
  %t418 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t417)
  call void @olang_textcopy(ptr %t418, ptr %t413, i64 %t414)
  %t419 = getelementptr i8, ptr %t418, i64 %t414
  call void @olang_textcopy(ptr %t419, ptr %t415, i64 %t416)
  %t420 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t418, 1
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t421, ptr %rv
  br label %ret
bb109:
  %t423 = load i64, ptr %l17, !tbaa !24
  %t425 = add i64 %t423, 1
  store i64 %t425, ptr %l17, !tbaa !24
  br label %bb69
bb110:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l204, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t427, ptr %l205, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t428, 0
  store i64 %t429, ptr %l206, !tbaa !24
  %t430 = load i64, ptr %l206, !tbaa !24
  %t431 = mul i64 %t430, 1
  %t432 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t431)
  %t433 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t434 = insertvalue { i64, ptr } %t433, ptr %t432, 1
  store { i64, ptr } %t434, ptr %l207, !tbaa !27
  %t435 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = load i64, ptr %l206, !tbaa !24
  %t440 = mul i64 %t439, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t436, ptr %t438, i64 %t440, i1 false)
  %t441 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t441, ptr %l205, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t442 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t442, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 32
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 32
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 34
  store i1 true, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca ptr
  %l17 = alloca i1
  %l23 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca { i64, [1 x i64] }
  %l39 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca { i64, [1 x i64] }
  %l79 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca { i64, [1 x i64] }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l98 = alloca { i64, [1 x i64] }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca { i64, [1 x i64] }
  %l110 = alloca ptr
  %l111 = alloca i64
  %l117 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t178 = alloca { i64, [1 x i64] }, align 8
  %t247 = alloca { i64, [1 x i64] }, align 8
  %t261 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l14, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 18}
  %t16 = icmp eq i64 %t14, 5
  store i1 %t16, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l17, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t20, i32 0, i32 2
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Plan", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Promote", ptr %t28, i32 0, i32 1
  %t31 = load i32, ptr %t30, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t36, i64 %t33
  %t38 = load { i64, [1 x i64] }, ptr %t37
  store { i64, [1 x i64] } %t38, ptr %l15
  br label %bb65
bb7:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb8, label %bb9
bb8:
  %t44 = load ptr, ptr %l28, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 7
  store i1 %t47, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb10, label %bb11
bb10:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Make", ptr %t55, i32 0, i32 4
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = icmp sge i32 %t58, 0
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Plan", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l39, !tbaa !27
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Make", ptr %t66, i32 0, i32 4
  %t69 = load i32, ptr %t68, !tbaa !23
  %t71 = sext i32 %t69 to i64
  %t73 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i64 %t71
  %t76 = load { i64, [1 x i64] }, ptr %t75
  store { i64, [1 x i64] } %t76, ptr %l37
  br label %bb15
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 0, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l37
  br label %bb15
bb15:
  %t82 = load { i64, [1 x i64] }, ptr %l37
  store { i64, [1 x i64] } %t82, ptr %l15
  br label %bb65
bb16:
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t84 = load ptr, ptr %l45, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb17, label %bb18
bb17:
  %t87 = load ptr, ptr %l45, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 16
  store i1 %t90, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t91 = load i1, ptr %l46, !tbaa !21
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Plan", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Text", ptr %t102, i32 0, i32 1
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t109 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, [1 x i64] }, ptr %t110, i64 %t107
  %t112 = load { i64, [1 x i64] }, ptr %t111
  store { i64, [1 x i64] } %t112, ptr %l15
  br label %bb65
bb22:
  %t114 = load ptr, ptr %l2, !tbaa !29
  store ptr %t114, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t115 = load ptr, ptr %l57, !tbaa !29
  %t116 = icmp ne ptr %t115, null
  br i1 %t116, label %bb23, label %bb24
bb23:
  %t118 = load ptr, ptr %l57, !tbaa !29
  %t119 = load i64, ptr %t118, !range !{i64 0, i64 18}
  %t121 = icmp eq i64 %t119, 8
  store i1 %t121, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t122 = load i1, ptr %l58, !tbaa !21
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Plan", ptr %t129, i32 0, i32 0
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l64, !tbaa !27
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Collect", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %t135, !tbaa !23
  %t138 = sext i32 %t136 to i64
  %t140 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, [1 x i64] }, ptr %t141, i64 %t138
  %t143 = load { i64, [1 x i64] }, ptr %t142
  store { i64, [1 x i64] } %t143, ptr %l15
  br label %bb65
bb28:
  %t145 = load ptr, ptr %l2, !tbaa !29
  store ptr %t145, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb29, label %bb30
bb29:
  %t149 = load ptr, ptr %l69, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 6
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb30
bb30:
  %t153 = load i1, ptr %l70, !tbaa !21
  br i1 %t153, label %bb31, label %bb32
bb31:
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb40
bb33:
  %t160 = load ptr, ptr %l8, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Call", ptr %t160, i32 0, i32 3
  %t163 = load i32, ptr %t162, !tbaa !23
  %t165 = icmp sge i32 %t163, 0
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l3, !tbaa !29
  store ptr %t167, ptr %l79, !tbaa !29
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Call", ptr %t168, i32 0, i32 3
  %t171 = load i32, ptr %t170, !tbaa !23
  store i32 %t171, ptr %l81, !tbaa !23
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l82, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l8, !tbaa !29
  %t177 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t173, ptr %t174)
  store i64 %t177, ptr %l85
  br label %bb36
bb35:
  store { i64, [1 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [1 x i64] }, ptr %t178, i32 0, i32 0
  store i64 0, ptr %t179
  %t180 = load { i64, [1 x i64] }, ptr %t178
  store { i64, [1 x i64] } %t180, ptr %l78
  br label %bb39
bb36:
  %t182 = load ptr, ptr %l82, !tbaa !29
  %t183 = load i64, ptr %l85, !tbaa !24
  %t184 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t182, i64 %t183)
  store i64 %t184, ptr %l86
  br label %bb37
bb37:
  %t185 = load ptr, ptr %l79, !tbaa !29
  %t186 = load i32, ptr %l81, !tbaa !23
  %t187 = load i64, ptr %l86, !tbaa !24
  %t188 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t185, i32 %t186, i64 %t187)
  store { i64, [1 x i64] } %t188, ptr %l87
  br label %bb38
bb38:
  %t189 = load { i64, [1 x i64] }, ptr %l87
  store { i64, [1 x i64] } %t189, ptr %l78
  br label %bb39
bb39:
  %t190 = load { i64, [1 x i64] }, ptr %l78
  store { i64, [1 x i64] } %t190, ptr %l15
  br label %bb65
bb40:
  %t191 = load ptr, ptr %l2, !tbaa !29
  store ptr %t191, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t192 = load ptr, ptr %l89, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb41, label %bb42
bb41:
  %t195 = load ptr, ptr %l89, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 18}
  %t198 = icmp eq i64 %t196, 17
  store i1 %t198, ptr %l90, !tbaa !21
  br label %bb42
bb42:
  %t199 = load i1, ptr %l90, !tbaa !21
  br i1 %t199, label %bb43, label %bb44
bb43:
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = load ptr, ptr %l9, !tbaa !29
  %t212 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t206, i64 %t207, ptr %t208)
  store { i64, [1 x i64] } %t212, ptr %l98
  br label %bb46
bb46:
  %t213 = load { i64, [1 x i64] }, ptr %l98
  store { i64, [1 x i64] } %t213, ptr %l15
  br label %bb65
bb47:
  %t214 = load ptr, ptr %l2, !tbaa !29
  store ptr %t214, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t215 = load ptr, ptr %l99, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb48, label %bb49
bb48:
  %t218 = load ptr, ptr %l99, !tbaa !29
  %t219 = load i64, ptr %t218, !range !{i64 0, i64 18}
  %t221 = icmp eq i64 %t219, 12
  store i1 %t221, ptr %l100, !tbaa !21
  br label %bb49
bb49:
  %t222 = load i1, ptr %l100, !tbaa !21
  br i1 %t222, label %bb50, label %bb51
bb50:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l10, !tbaa !29
  br label %bb52
bb51:
  br label %bb60
bb52:
  %t229 = load ptr, ptr %l10, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Seq", ptr %t229, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb53, label %bb54
bb53:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l110, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  store i64 %t239, ptr %l111, !tbaa !24
  %t240 = load ptr, ptr %l10, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Seq", ptr %t240, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb55, label %bb56
bb54:
  store { i64, [1 x i64] } zeroinitializer, ptr %t247
  %t248 = getelementptr { i64, [1 x i64] }, ptr %t247, i32 0, i32 0
  store i64 0, ptr %t248
  %t249 = load { i64, [1 x i64] }, ptr %t247
  store { i64, [1 x i64] } %t249, ptr %l109
  br label %bb59
bb55:
  call void @__olang_check_failed(ptr @olang_loc_ebe5ee6b39eee92e_4ec5471030d8b4f2)
  unreachable
bb56:
  br label %bb57
bb57:
  %t251 = load ptr, ptr %l10, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Seq", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load ptr, ptr %l110, !tbaa !29
  %t256 = load i64, ptr %l111, !tbaa !24
  %t258 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t255, i64 %t256, ptr %t254)
  store { i64, [1 x i64] } %t258, ptr %l117
  br label %bb58
bb58:
  %t259 = load { i64, [1 x i64] }, ptr %l117
  store { i64, [1 x i64] } %t259, ptr %l109
  br label %bb59
bb59:
  %t260 = load { i64, [1 x i64] }, ptr %l109
  store { i64, [1 x i64] } %t260, ptr %l15
  br label %bb65
bb60:
  br i1 true, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  store { i64, [1 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [1 x i64] }, ptr %t261, i32 0, i32 0
  store i64 0, ptr %t262
  %t263 = load { i64, [1 x i64] }, ptr %t261
  store { i64, [1 x i64] } %t263, ptr %l15
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_c32ca46bf6d65f0c_9a54b76873cd9ad0)
  unreachable
bb65:
  %t265 = load { i64, [1 x i64] }, ptr %l15
  store { i64, [1 x i64] } %t265, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b4c0d703fa684531_272a8f4f39064c15)
  unreachable
bb25:
  br label %bb26
bb26:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i64 -3, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aletGo_2eOf(%"compiler/free:letGo" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/free:letGo"
  %l5 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t6 = icmp eq i64 %t2, %a1
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = getelementptr %"compiler/free:letGo", ptr %l0, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l5, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l14 = alloca ptr
  %l23 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:mustW", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l9, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:mustW", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 30
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb9
bb9:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l50 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l148 = alloca ptr
  %l169 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l190 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i1
  %l233 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca i1
  %l250 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t2 = load ptr, ptr %l36, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l36, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l37, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l37, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l50, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t41, ptr %t39)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Seq", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l61, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Seq", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_14962ab25e47b4fc_3749941476b1d040)
  unreachable
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb141
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t73 = load ptr, ptr %l67, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l67, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 13
  store i1 %t79, ptr %l68, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l68, !tbaa !21
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb83
bb25:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Match", ptr %t87, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l81, !tbaa !27
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t112, ptr %t110)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb26
bb32:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  br label %bb66
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t137, ptr %l96, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  store ptr %t143, ptr %l15, !tbaa !29
  %t145 = load ptr, ptr %l15, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Arm", ptr %t145, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l18, !tbaa !24
  br label %bb37
bb37:
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l18, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb38, label %bb39
bb38:
  br label %bb50
bb39:
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t162, ptr %l107, !tbaa !27
  %t163 = load i64, ptr %l17, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = getelementptr %"compiler/typed:Alt", ptr %t168, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l22, !tbaa !24
  br label %bb41
bb41:
  %t179 = load i64, ptr %l21, !tbaa !24
  %t180 = load i64, ptr %l22, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb42, label %bb43
bb42:
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t187 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t187, ptr %l118, !tbaa !27
  %t188 = load i64, ptr %l21, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l23, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:mustW", ptr %t195, i32 0, i32 4
  %t198 = load ptr, ptr %l23, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Bind", ptr %t198, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = sext i32 %t201 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t197, i64 %t203)
  br label %bb45
bb45:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:mustW", ptr %t206, i32 0, i32 5
  %t209 = load ptr, ptr %l23, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Bind", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t208, ptr %t212)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l21, !tbaa !24
  br label %bb41
bb48:
  br label %bb49
bb49:
  %t219 = load i64, ptr %l17, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l17, !tbaa !24
  br label %bb37
bb50:
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Arm", ptr %t223, i32 0, i32 3
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb51, label %bb52
bb51:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l138, !tbaa !29
  %t233 = load ptr, ptr %l15, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Arm", ptr %t233, i32 0, i32 3
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = icmp eq ptr %t236, null
  br i1 %t238, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf)
  unreachable
bb54:
  br label %bb55
bb55:
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Arm", ptr %t240, i32 0, i32 3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t244, ptr %t243)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t246 = load ptr, ptr %l15, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Arm", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb58, label %bb59
bb58:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l15, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Arm", ptr %t256, i32 0, i32 4
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb60, label %bb61
bb59:
  br label %bb64
bb60:
  call void @__olang_check_failed(ptr @olang_loc_502532e2e95f04ea_fe436d8dc2f78aae)
  unreachable
bb61:
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l15, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Arm", ptr %t263, i32 0, i32 4
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t267, ptr %t266)
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t269 = load i64, ptr %l13, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l13, !tbaa !24
  br label %bb33
bb66:
  %t273 = load ptr, ptr %l7, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Match", ptr %t273, i32 0, i32 2
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = icmp eq ptr %t276, null
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb67, label %bb68
bb67:
  %t282 = load ptr, ptr %l7, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Match", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb69, label %bb70
bb68:
  br label %bb82
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb70:
  br label %bb71
bb71:
  %t289 = load ptr, ptr %l7, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Match", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Arm", ptr %t292, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l169, !tbaa !29
  %t303 = load ptr, ptr %l7, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Match", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  br i1 %t308, label %bb74, label %bb75
bb73:
  br label %bb81
bb74:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb75:
  br label %bb76
bb76:
  %t310 = load ptr, ptr %l7, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Match", ptr %t310, i32 0, i32 2
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Arm", ptr %t313, i32 0, i32 3
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l24, !tbaa !29
  %t319 = load ptr, ptr %l24, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb78:
  br label %bb79
bb79:
  %t323 = load ptr, ptr %l24, !tbaa !29
  %t324 = load ptr, ptr %l169, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t324, ptr %t323)
  br label %bb80
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb141
bb83:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t327 = load ptr, ptr %l180, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb84, label %bb85
bb84:
  %t330 = load ptr, ptr %l180, !tbaa !29
  %t331 = load i64, ptr %t330, !range !{i64 0, i64 18}
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb85
bb85:
  %t334 = load i1, ptr %l181, !tbaa !21
  br i1 %t334, label %bb86, label %bb87
bb86:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t337, i32 0, i32 2
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l25, !tbaa !29
  br label %bb88
bb87:
  br label %bb109
bb88:
  %t341 = load ptr, ptr %l25, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Try", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb89, label %bb90
bb89:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l190, !tbaa !29
  %t351 = load ptr, ptr %l25, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Try", ptr %t351, i32 0, i32 0
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb91, label %bb92
bb90:
  br label %bb95
bb91:
  call void @__olang_check_failed(ptr @olang_loc_bb85040a6a786cb8_20e886069e3b9c04)
  unreachable
bb92:
  br label %bb93
bb93:
  %t358 = load ptr, ptr %l25, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Try", ptr %t358, i32 0, i32 0
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t362 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t362, ptr %t361)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t364 = load ptr, ptr %l25, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Try", ptr %t364, i32 0, i32 1
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  store i64 %t371, ptr %l28, !tbaa !24
  br label %bb96
bb96:
  %t373 = load i64, ptr %l27, !tbaa !24
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb97, label %bb98
bb97:
  br label %bb108
bb98:
  br label %bb99
bb99:
  %t381 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t381, ptr %l204, !tbaa !27
  %t382 = load i64, ptr %l27, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t382
  %t387 = load ptr, ptr %t386, !tbaa !39
  store ptr %t387, ptr %l29, !tbaa !29
  %t389 = load ptr, ptr %l29, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Clause", ptr %t389, i32 0, i32 3
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb100, label %bb101
bb100:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l211, !tbaa !29
  %t399 = load ptr, ptr %l29, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Clause", ptr %t399, i32 0, i32 3
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb102, label %bb103
bb101:
  br label %bb106
bb102:
  call void @__olang_check_failed(ptr @olang_loc_be187497b97f18d7_9641cb8c9c409d3)
  unreachable
bb103:
  br label %bb104
bb104:
  %t406 = load ptr, ptr %l29, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Clause", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load ptr, ptr %l211, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t410, ptr %t409)
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t412 = load i64, ptr %l27, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l27, !tbaa !24
  br label %bb96
bb108:
  br label %bb141
bb109:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t417 = load ptr, ptr %l219, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb110, label %bb111
bb110:
  %t420 = load ptr, ptr %l219, !tbaa !29
  %t421 = load i64, ptr %t420, !range !{i64 0, i64 18}
  %t423 = icmp eq i64 %t421, 6
  store i1 %t423, ptr %l220, !tbaa !21
  br label %bb111
bb111:
  %t424 = load i1, ptr %l220, !tbaa !21
  br i1 %t424, label %bb112, label %bb113
bb112:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t427, i32 0, i32 2
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l30, !tbaa !29
  br label %bb114
bb113:
  br label %bb122
bb114:
  %t431 = load ptr, ptr %l30, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Call", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb115
bb115:
  %t440 = load i64, ptr %l32, !tbaa !24
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t448 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t448, ptr %l233, !tbaa !27
  %t449 = load i64, ptr %l32, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr ptr, ptr %t452, i64 %t449
  %t454 = load ptr, ptr %t453, !tbaa !39
  %t456 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t456, ptr %t454)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t460 = load i64, ptr %l32, !tbaa !24
  %t462 = add i64 %t460, 1
  store i64 %t462, ptr %l32, !tbaa !24
  br label %bb115
bb121:
  br label %bb141
bb122:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t465 = load ptr, ptr %l240, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb123, label %bb124
bb123:
  %t468 = load ptr, ptr %l240, !tbaa !29
  %t469 = load i64, ptr %t468, !range !{i64 0, i64 18}
  %t471 = icmp eq i64 %t469, 11
  store i1 %t471, ptr %l241, !tbaa !21
  br label %bb124
bb124:
  %t472 = load i1, ptr %l241, !tbaa !21
  br i1 %t472, label %bb125, label %bb126
bb125:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t475, i32 0, i32 2
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l35, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t479 = load ptr, ptr %l35, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = icmp eq ptr %t482, null
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb128, label %bb129
bb128:
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l250, !tbaa !29
  %t489 = load ptr, ptr %l35, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Cond", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  br i1 %t494, label %bb130, label %bb131
bb129:
  br label %bb134
bb130:
  call void @__olang_check_failed(ptr @olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892)
  unreachable
bb131:
  br label %bb132
bb132:
  %t496 = load ptr, ptr %l35, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Cond", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t500 = load ptr, ptr %l250, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t499)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l35, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Cond", ptr %t503, i32 0, i32 2
  %t506 = load ptr, ptr %t505, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t502, ptr %t506)
  br label %bb135
bb135:
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_d5478abcfcd1a74_537f989617a8cff0)
  unreachable
bb141:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i1
  %l77 = alloca ptr
  %l85 = alloca ptr
  %l89 = alloca i64
  %l96 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l162 = alloca i64
  %l166 = alloca i1
  %l167 = alloca ptr
  %l171 = alloca ptr
  %l174 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l190 = alloca i1
  %l191 = alloca ptr
  %l199 = alloca i1
  %l210 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l228 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l257 = alloca i1
  %l258 = alloca i1
  %l260 = alloca { i64, ptr }
  %l264 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l32
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l32, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 8
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t16 = load ptr, ptr %l36, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l37, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l37, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t25 = load ptr, ptr %l40, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l40, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l41, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t35 = load ptr, ptr %l45, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l45, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 5
  store i1 %t41, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l46, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l49, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t51 = load i1, ptr %l50, !tbaa !21
  br i1 %t51, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t53 = load ptr, ptr %l53, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb23, label %bb24
bb23:
  %t56 = load ptr, ptr %l53, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 18}
  %t59 = icmp eq i64 %t57, 16
  store i1 %t59, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t60 = load i1, ptr %l54, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t62 = load ptr, ptr %l57, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t65 = load ptr, ptr %l57, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 8
  store i1 %t68, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t69 = load i1, ptr %l58, !tbaa !21
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t72 = load ptr, ptr %l62, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb33, label %bb34
bb33:
  %t75 = load ptr, ptr %l62, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb35, label %bb36
bb35:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb63
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i64 %t90, ptr %l70
  br label %bb38
bb38:
  %t91 = load i64, ptr %l70, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb42
bb40:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t98, i64 %t99)
  store ptr %t102, ptr %l77
  br label %bb41
bb41:
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 11
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  store i1 %t108, ptr %l73, !tbaa !21
  br label %bb42
bb42:
  %t110 = load i1, ptr %l73, !tbaa !21
  br i1 %t110, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = getelementptr %"compiler/free:Free", ptr %t112, i32 0, i32 1
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store ptr %t118, ptr %l85
  br label %bb46
bb46:
  %t119 = load ptr, ptr %l85, !tbaa !29
  store ptr %t119, ptr %l7, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t120, i32 %t124)
  store i64 %t127, ptr %l89
  br label %bb47
bb47:
  %t128 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t129 = load i64, ptr %l89, !tbaa !24
  %t131 = icmp eq i64 %t129, %t128
  br i1 %t131, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %t137, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t134, i32 %t138)
  store { i64, ptr } %t141, ptr %l96
  br label %bb51
bb51:
  %t142 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t145 = icmp ne i64 %t143, 1
  br i1 %t145, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t149 = load ptr, ptr %l7, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Body", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t148, i32 %t152, i64 0)
  store i64 %t155, ptr %l103
  br label %bb55
bb55:
  %t156 = load i64, ptr %l103, !tbaa !24
  store i64 %t156, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb58
bb57:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t162 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t165 = icmp eq i64 %t161, %t162
  store i1 %t165, ptr %l106, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l106, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t171 = getelementptr %"compiler/free:Free", ptr %t169, i32 0, i32 31
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t171, i64 %t172)
  store i1 %t175, ptr %l114
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s4)
  %t176 = load i1, ptr %l114, !tbaa !21
  store i1 %t176, ptr %rv
  br label %ret
bb63:
  %t177 = load ptr, ptr %l1, !tbaa !29
  store ptr %t177, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t178 = load ptr, ptr %l115, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb64, label %bb65
bb64:
  %t181 = load ptr, ptr %l115, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 18}
  %t184 = icmp eq i64 %t182, 2
  store i1 %t184, ptr %l116, !tbaa !21
  br label %bb65
bb65:
  %t185 = load i1, ptr %l116, !tbaa !21
  br i1 %t185, label %bb66, label %bb67
bb66:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t188, i32 0, i32 2
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb105
bb68:
  %t192 = load ptr, ptr %l9, !tbaa !29
  store ptr %t192, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t193 = load ptr, ptr %l121, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb69, label %bb70
bb69:
  %t196 = load ptr, ptr %l121, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 8}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t200 = load i1, ptr %l122, !tbaa !21
  br i1 %t200, label %bb71, label %bb72
bb71:
  %t201 = load ptr, ptr %l9, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t203, i32 0, i32 2
  %t205 = load i32, ptr %t204
  store i32 %t205, ptr %l10, !tbaa !23
  br label %bb73
bb72:
  br label %bb100
bb73:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l10, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t213 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t207, i64 %t210)
  store i1 %t213, ptr %l130
  br label %bb74
bb74:
  %t214 = load i1, ptr %l130, !tbaa !21
  br i1 %t214, label %bb75, label %bb76
bb75:
  store i1 false, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  store i64 0, ptr %l11, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/free:mustW", ptr %t216, i32 0, i32 4
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l134
  br label %bb78
bb78:
  %t221 = load i64, ptr %l134, !tbaa !24
  store i64 %t221, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t222 = load i64, ptr %l12, !tbaa !24
  %t223 = load i64, ptr %l11, !tbaa !24
  %t226 = icmp sgt i64 %t222, %t223
  br i1 %t226, label %bb79, label %bb80
bb79:
  %t228 = load i64, ptr %l13, !tbaa !24
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb84
bb81:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t233 = load i64, ptr %l11, !tbaa !24
  %t236 = sub i64 %t232, %t233
  %t237 = load i64, ptr %l13, !tbaa !24
  %t240 = add i64 %t236, %t237
  %t242 = sub i64 %t240, 1
  %t243 = load i64, ptr %l13, !tbaa !24
  %t246 = sdiv i64 %t242, %t243
  store i64 %t246, ptr %l141, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb83
bb83:
  %t248 = load i64, ptr %l141, !tbaa !24
  store i64 %t248, ptr %l138, !tbaa !24
  br label %bb84
bb84:
  %t249 = load i64, ptr %l138, !tbaa !24
  store i64 %t249, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb85
bb85:
  %t250 = load i64, ptr %l15, !tbaa !24
  %t251 = load i64, ptr %l14, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb86, label %bb87
bb86:
  br label %bb99
bb87:
  br label %bb88
bb88:
  %t258 = load i64, ptr %l11, !tbaa !24
  %t259 = load i64, ptr %l15, !tbaa !24
  %t260 = load i64, ptr %l13, !tbaa !24
  %t263 = mul i64 %t259, %t260
  %t266 = add i64 %t258, %t263
  store i64 %t266, ptr %l16, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:mustW", ptr %t268, i32 0, i32 4
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t270, i64 %t271)
  store i64 %t274, ptr %l162
  br label %bb89
bb89:
  %t275 = load i32, ptr %l10, !tbaa !23
  %t277 = sext i32 %t275 to i64
  %t278 = load i64, ptr %l162, !tbaa !24
  %t280 = icmp eq i64 %t278, %t277
  br i1 %t280, label %bb90, label %bb91
bb90:
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l167, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/free:mustW", ptr %t283, i32 0, i32 5
  %t286 = load i64, ptr %l16, !tbaa !24
  %t289 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t285, i64 %t286)
  store ptr %t289, ptr %l171
  br label %bb92
bb91:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb94
bb92:
  %t290 = load i64, ptr %l2, !tbaa !24
  %t292 = add i64 %t290, 1
  %t293 = load ptr, ptr %l167, !tbaa !29
  %t294 = load ptr, ptr %l171, !tbaa !29
  %t296 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t293, ptr %t294, i64 %t292)
  store i1 %t296, ptr %l174
  br label %bb93
bb93:
  %t297 = load i1, ptr %l174, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l166, !tbaa !21
  br label %bb94
bb94:
  %t300 = load i1, ptr %l166, !tbaa !21
  br i1 %t300, label %bb95, label %bb96
bb95:
  store i1 false, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t302 = load i64, ptr %l15, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l15, !tbaa !24
  br label %bb85
bb99:
  store i1 true, ptr %rv
  br label %ret
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  store i1 false, ptr %rv
  br label %ret
bb104:
  call void @__olang_check_failed(ptr @olang_loc_7a954698926d7de_664d4c02e090fa22)
  unreachable
bb105:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t309 = load ptr, ptr %l181, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb106, label %bb107
bb106:
  %t312 = load ptr, ptr %l181, !tbaa !29
  %t313 = load i64, ptr %t312, !range !{i64 0, i64 18}
  %t315 = icmp eq i64 %t313, 14
  store i1 %t315, ptr %l182, !tbaa !21
  br label %bb107
bb107:
  %t316 = load i1, ptr %l182, !tbaa !21
  br i1 %t316, label %bb108, label %bb109
bb108:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t319, i32 0, i32 2
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb137
bb110:
  %t323 = load ptr, ptr %l17, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Try", ptr %t323, i32 0, i32 0
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  br i1 %t328, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb117
bb112:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l191, !tbaa !29
  %t331 = load ptr, ptr %l17, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Try", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = icmp eq ptr %t334, null
  br i1 %t336, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_893474d063c17328_1c44af56cc3f848c)
  unreachable
bb114:
  br label %bb115
bb115:
  %t338 = load ptr, ptr %l17, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Try", ptr %t338, i32 0, i32 0
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t342 = load i64, ptr %l2, !tbaa !24
  %t344 = add i64 %t342, 1
  %t345 = load ptr, ptr %l191, !tbaa !29
  %t348 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t345, ptr %t341, i64 %t344)
  store i1 %t348, ptr %l199
  br label %bb116
bb116:
  %t349 = load i1, ptr %l199, !tbaa !21
  %t350 = xor i1 %t349, true
  store i1 %t350, ptr %l190, !tbaa !21
  br label %bb117
bb117:
  %t352 = load i1, ptr %l190, !tbaa !21
  br i1 %t352, label %bb118, label %bb119
bb118:
  store i1 false, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t354 = load ptr, ptr %l17, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Try", ptr %t354, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  store { i64, ptr } %t357, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  store i64 %t361, ptr %l20, !tbaa !24
  br label %bb121
bb121:
  %t363 = load i64, ptr %l19, !tbaa !24
  %t364 = load i64, ptr %l20, !tbaa !24
  %t367 = icmp slt i64 %t363, %t364
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb122, label %bb123
bb122:
  br label %bb136
bb123:
  br label %bb124
bb124:
  %t371 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t371, ptr %l210, !tbaa !27
  %t372 = load i64, ptr %l19, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr ptr, ptr %t375, i64 %t372
  %t377 = load ptr, ptr %t376, !tbaa !39
  %t381 = getelementptr %"compiler/typed:Clause", ptr %t377, i32 0, i32 4
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t384, 0
  store i64 %t386, ptr %l24, !tbaa !24
  br label %bb125
bb125:
  %t388 = load i64, ptr %l23, !tbaa !24
  %t389 = load i64, ptr %l24, !tbaa !24
  %t392 = icmp slt i64 %t388, %t389
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb126, label %bb127
bb126:
  br label %bb134
bb127:
  br label %bb128
bb128:
  %t396 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t396, ptr %l221, !tbaa !27
  %t397 = load i64, ptr %l23, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr ptr, ptr %t400, i64 %t397
  %t402 = load ptr, ptr %t401, !tbaa !39
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l2, !tbaa !24
  %t408 = add i64 %t406, 1
  %t412 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t404, ptr %t402, i64 %t408)
  store i1 %t412, ptr %l228
  br label %bb129
bb129:
  %t413 = load i1, ptr %l228, !tbaa !21
  %t414 = xor i1 %t413, true
  br i1 %t414, label %bb130, label %bb131
bb130:
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t417 = load i64, ptr %l23, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l23, !tbaa !24
  br label %bb125
bb134:
  br label %bb135
bb135:
  %t421 = load i64, ptr %l19, !tbaa !24
  %t423 = add i64 %t421, 1
  store i64 %t423, ptr %l19, !tbaa !24
  br label %bb121
bb136:
  store i1 true, ptr %rv
  br label %ret
bb137:
  %t426 = load ptr, ptr %l1, !tbaa !29
  store ptr %t426, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t427 = load ptr, ptr %l236, !tbaa !29
  %t428 = icmp ne ptr %t427, null
  br i1 %t428, label %bb138, label %bb139
bb138:
  %t430 = load ptr, ptr %l236, !tbaa !29
  %t431 = load i64, ptr %t430, !range !{i64 0, i64 18}
  %t433 = icmp eq i64 %t431, 17
  store i1 %t433, ptr %l237, !tbaa !21
  br label %bb139
bb139:
  %t434 = load i1, ptr %l237, !tbaa !21
  br i1 %t434, label %bb140, label %bb141
bb140:
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [5 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t437, i32 0, i32 2
  %t439 = load ptr, ptr %t438
  store ptr %t439, ptr %l26, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l26, !tbaa !29
  %t443 = load i64, ptr %l2, !tbaa !24
  %t445 = add i64 %t443, 1
  %t449 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t441, ptr %t442, i64 %t445)
  store i1 %t449, ptr %l246
  br label %bb143
bb143:
  %t450 = load i1, ptr %l246, !tbaa !21
  store i1 %t450, ptr %rv
  br label %ret
bb144:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t452 = load ptr, ptr %l247, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb145, label %bb146
bb145:
  %t455 = load ptr, ptr %l247, !tbaa !29
  %t456 = load i64, ptr %t455, !range !{i64 0, i64 18}
  %t458 = icmp eq i64 %t456, 9
  store i1 %t458, ptr %l248, !tbaa !21
  br label %bb146
bb146:
  %t459 = load i1, ptr %l248, !tbaa !21
  br i1 %t459, label %bb147, label %bb148
bb147:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [5 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t462, i32 0, i32 2
  %t464 = load i32, ptr %t463, !range !{i32 0, i32 43}
  store i32 %t464, ptr %l27
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t468, i32 0, i32 4
  %t470 = load { i64, ptr }, ptr %t469
  store { i64, ptr } %t470, ptr %l28, !tbaa !27
  br label %bb149
bb148:
  br label %bb155
bb149:
  %t472 = load i32, ptr %l27, !range !{i32 0, i32 43}
  %t473 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t476 = call i1 @compiler_2ffree_2eisConversion(ptr %v1, i32 %t472, { i64, ptr } %t473)
  store i1 %t476, ptr %l257
  br label %bb150
bb150:
  %t477 = load i1, ptr %l257, !tbaa !21
  br i1 %t477, label %bb151, label %bb152
bb151:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t479, ptr %l260, !tbaa !27
  %t480 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 0
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t484 = load i64, ptr %l2, !tbaa !24
  %t486 = add i64 %t484, 1
  %t490 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t478, ptr %t483, i64 %t486)
  store i1 %t490, ptr %l264
  br label %bb153
bb152:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb154
bb153:
  %t491 = load i1, ptr %l264, !tbaa !21
  store i1 %t491, ptr %l258, !tbaa !21
  br label %bb154
bb154:
  %t492 = load i1, ptr %l258, !tbaa !21
  store i1 %t492, ptr %rv
  br label %ret
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  store i1 false, ptr %rv
  br label %ret
bb159:
  call void @__olang_check_failed(ptr @olang_loc_a532406d51285a24_27441d0f137c6648)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:mustW", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t21)
  store i64 %t24, ptr %l14
  br label %bb6
bb6:
  %t25 = load i64, ptr %l14, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9be7a7b731d47dfc_cd79088c97deb358)
  unreachable
bb12:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:mustW", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i64 %t33, ptr %l18
  br label %bb13
bb13:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb16
bb15:
  %t41 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t41, ptr %l21, !tbaa !24
  br label %bb16
bb16:
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca i64
  %l30 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1777536395e8cd8b_97ff53b4c3030f1f)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i64 %t24, ptr %l21
  br label %bb7
bb7:
  %t25 = load i64, ptr %l21, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t68, ptr %l41, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t77, ptr %t74)
  store i64 %t81, ptr %l47
  br label %bb16
bb16:
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = call i64 @compiler_2ffree_2emeet(i64 %t82, i64 %t83)
  store i64 %t84, ptr %l48
  br label %bb17
bb17:
  %t85 = load i64, ptr %l48, !tbaa !24
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l4, !tbaa !24
  br label %bb8
bb21:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l37 = alloca i64
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l78 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i1
  %l151 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 67
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t15)
  store i1 %t18, ptr %l26
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t19 = load i1, ptr %l26, !tbaa !21
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l20, !tbaa !21
  store i1 %t20, ptr %l2, !tbaa !21
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l27
  br label %bb5
bb5:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Block", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb8:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb10
bb10:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t76, 1
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Block", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = icmp slt i64 %t78, %t84
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Block", ptr %t89, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l63, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = call i1 @compiler_2ffree_2eleaves(ptr %v1, ptr %t100)
  store i1 %t102, ptr %l67
  br label %bb18
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb19
bb18:
  %t103 = load i1, ptr %l67, !tbaa !21
  store i1 %t103, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t104 = load i1, ptr %l61, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 22
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 11
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t107, i64 %t111)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t114 = load i1, ptr %l2, !tbaa !21
  br i1 %t114, label %bb24, label %bb25
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 11
  %t119 = load i64, ptr %t118, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t119)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l78, !tbaa !27
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t122, ptr %t132)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l8, !tbaa !24
  br label %bb12
bb30:
  %t139 = load i1, ptr %l2, !tbaa !21
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:walker", ptr %t143, i32 0, i32 11
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = sub i64 %t146, 1
  store i64 %t148, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  store i64 -1, ptr %l13, !tbaa !24
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Block", ptr %t150, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = sub i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  br label %bb81
bb36:
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Block", ptr %t165, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr ptr, ptr %t172, i64 %t169
  %t174 = load ptr, ptr %t173, !tbaa !39
  store ptr %t174, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb38, label %bb39
bb38:
  %t180 = load ptr, ptr %l99, !tbaa !29
  %t181 = load i64, ptr %t180, !range !{i64 0, i64 17}
  %t183 = icmp eq i64 %t181, 12
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 54
  store ptr %t187, ptr %l104, !tbaa !29
  %t188 = load i64, ptr %l14, !tbaa !24
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t188)
  store i64 %t191, ptr %l107
  br label %bb43
bb43:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t193, i64 %t194, i64 %t192)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d)
  unreachable
bb50:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb51, label %bb52
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:walker", ptr %t200, i32 0, i32 55
  store ptr %t202, ptr %l112, !tbaa !29
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t203)
  store i64 %t206, ptr %l115
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load i64, ptr %l115, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t208, i64 %t209, i64 %t207)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb56, label %bb57
bb56:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 56
  store ptr %t217, ptr %l120, !tbaa !29
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t218)
  store i64 %t221, ptr %l123
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = load ptr, ptr %l120, !tbaa !29
  %t224 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t223, i64 %t224, i64 %t222)
  br label %bb59
bb59:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 57
  store ptr %t228, ptr %l126, !tbaa !29
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t229)
  store i64 %t232, ptr %l129
  br label %bb60
bb60:
  %t233 = load i64, ptr %l12, !tbaa !24
  %t234 = load ptr, ptr %l126, !tbaa !29
  %t235 = load i64, ptr %l129, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t234, i64 %t235, i64 %t233)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Block", ptr %t237, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l132, !tbaa !27
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  %t248 = call i1 @compiler_2ffree_2eleavesFunction(ptr %v1, ptr %t246)
  store i1 %t248, ptr %l135
  br label %bb63
bb63:
  %t249 = load i1, ptr %l135, !tbaa !21
  br i1 %t249, label %bb64, label %bb65
bb64:
  %t250 = load i64, ptr %l14, !tbaa !24
  %t253 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t250)
  store i64 %t253, ptr %l138
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t254 = load i64, ptr %l138, !tbaa !24
  store i64 %t254, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Block", ptr %t255, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l140, !tbaa !27
  %t259 = load i64, ptr %l14, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  store ptr %t264, ptr %l16, !tbaa !29
  %t266 = load ptr, ptr %l16, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t267 = load ptr, ptr %l143, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb68, label %bb69
bb68:
  %t270 = load ptr, ptr %l143, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 17}
  %t273 = icmp eq i64 %t271, 5
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb69
bb69:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb70, label %bb71
bb70:
  %t275 = load ptr, ptr %l16, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t277, i32 0, i32 2
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l17, !tbaa !23
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t281 = load i64, ptr %l14, !tbaa !24
  %t284 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t281)
  store i64 %t284, ptr %l151
  br label %bb73
bb73:
  %t285 = load i64, ptr %l151, !tbaa !24
  store i64 %t285, ptr %l12, !tbaa !24
  %t286 = load i32, ptr %l17, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l13, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_59a6b24cdfdba848_73366ee735d239ac)
  unreachable
bb79:
  br label %bb80
bb80:
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = sub i64 %t290, 1
  store i64 %t292, ptr %l14, !tbaa !24
  br label %bb34
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l60 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca i1
  %l77 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i64
  %l92 = alloca i1
  %l94 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i1
  %l105 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca ptr
  %l125 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca { i64, ptr }
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca ptr
  %l159 = alloca i32
  %l160 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l172 = alloca i1
  %l173 = alloca i1
  %l177 = alloca ptr
  %l182 = alloca i64
  %l183 = alloca i64
  %l186 = alloca i1
  %l188 = alloca i1
  %l191 = alloca i64
  %l193 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %l212 = alloca i64
  %l214 = alloca i64
  %l219 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l224 = alloca i64
  %l231 = alloca ptr
  %l232 = alloca i64
  %l234 = alloca i64
  %l239 = alloca i64
  %l241 = alloca i64
  %l245 = alloca i64
  %l246 = alloca i64
  %l248 = alloca i64
  %l250 = alloca ptr
  %l253 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l255 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l257 = alloca i64
  %l260 = alloca i64
  %l264 = alloca ptr
  %l268 = alloca ptr
  %l271 = alloca i64
  %l277 = alloca ptr
  %l278 = alloca i64
  %l280 = alloca i64
  %l285 = alloca i64
  %l292 = alloca i64
  %l294 = alloca i64
  %l299 = alloca i1
  %l300 = alloca ptr
  %l301 = alloca i64
  %l303 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l308 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l310 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l320 = alloca ptr
  %l321 = alloca i64
  %l323 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i64
  %l331 = alloca i64
  %l333 = alloca ptr
  %l336 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l338 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l346 = alloca i1
  %l354 = alloca ptr
  %l355 = alloca i64
  %l357 = alloca i64
  %l362 = alloca i64
  %l363 = alloca ptr
  %l364 = alloca i64
  %l365 = alloca i64
  %l366 = alloca %"compiler/source:Span"
  %l368 = alloca %"compiler/source:Span"
  %l374 = alloca i1
  %l381 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l383 = alloca i64
  %l385 = alloca i64
  %l390 = alloca i64
  %l392 = alloca i64
  %l403 = alloca i64
  %l405 = alloca i64
  %l410 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l412 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l415 = alloca i64
  %l423 = alloca ptr
  %l425 = alloca i64
  %l426 = alloca i64
  %l436 = alloca { i64, ptr }
  %l440 = alloca ptr
  %l442 = alloca ptr
  %l444 = alloca i32
  %l445 = alloca i32
  %l446 = alloca i32
  %l457 = alloca i64
  %l459 = alloca i64
  %l464 = alloca i64
  %l471 = alloca ptr
  %l474 = alloca i64
  %l478 = alloca ptr
  %l479 = alloca i64
  %l481 = alloca i1
  %l485 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l56
  br label %bb1
bb1:
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t7, ptr %lp5
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t9 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l10, !tbaa !29
  store ptr %t15, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t16 = load ptr, ptr %l59, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l59, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l60, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l60, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l11, !tbaa !23
  br label %bb6
bb5:
  br label %bb32
bb6:
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = sext i32 %t30 to i64
  store i64 %t32, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l70
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l70, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 11
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l77
  br label %bb10
bb9:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb11
bb10:
  %t53 = load i1, ptr %l77, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l74, !tbaa !21
  br label %bb11
bb11:
  %t56 = load i1, ptr %l74, !tbaa !21
  store i1 %t56, ptr %l7, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 54
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l85
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:walker", ptr %t71, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load ptr, ptr %l85, !tbaa !29
  %t77 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t75, i64 %t74)
  store i64 %t77, ptr %l88
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 2
  %t81 = load i1, ptr %t80, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l7, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb23
bb19:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb22
bb20:
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 32
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l98
  br label %bb21
bb21:
  %t94 = load i1, ptr %l98, !tbaa !21
  store i1 %t94, ptr %l94, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l94, !tbaa !21
  store i1 %t95, ptr %l92, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l92, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t108 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %t97, i64 %t101, ptr %t102, i64 %t103)
  store i1 %t108, ptr %l105
  br label %bb26
bb25:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb27
bb26:
  %t109 = load i1, ptr %l105, !tbaa !21
  store i1 %t109, ptr %l99, !tbaa !21
  br label %bb27
bb27:
  %t110 = load i1, ptr %l99, !tbaa !21
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t111, i64 %t115)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb70
bb32:
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t119 = load ptr, ptr %l109, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load ptr, ptr %l109, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 5}
  %t125 = icmp eq i64 %t123, 2
  store i1 %t125, ptr %l110, !tbaa !21
  br label %bb34
bb34:
  %t126 = load i1, ptr %l110, !tbaa !21
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { ptr }, ptr %t129, i32 0, i32 0
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb43
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l12, !tbaa !29
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s4, ptr %t133, ptr %t134)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l117
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 2
  %t141 = load i1, ptr %t140, !tbaa !21
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb39, label %bb40
bb39:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/free:walker", ptr %t146, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t145, i64 %t149)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb43:
  %t152 = load ptr, ptr %l10, !tbaa !29
  store ptr %t152, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t153 = load ptr, ptr %l124, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l124, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 5}
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l125, !tbaa !21
  br label %bb45
bb45:
  %t160 = load i1, ptr %l125, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb53
bb48:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 2
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l4, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 1
  %t172 = load i64, ptr %t171, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t168, i64 %t172)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb70
bb53:
  %t175 = load ptr, ptr %l10, !tbaa !29
  store ptr %t175, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t176 = load ptr, ptr %l134, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb54, label %bb55
bb54:
  %t179 = load ptr, ptr %l134, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 5}
  %t182 = icmp eq i64 %t180, 4
  store i1 %t182, ptr %l135, !tbaa !21
  br label %bb55
bb55:
  %t183 = load i1, ptr %l135, !tbaa !21
  br i1 %t183, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb70
bb59:
  %t184 = load ptr, ptr %l10, !tbaa !29
  store ptr %t184, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t185 = load ptr, ptr %l138, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb60, label %bb61
bb60:
  %t188 = load ptr, ptr %l138, !tbaa !29
  %t189 = load i64, ptr %t188, !range !{i64 0, i64 5}
  %t191 = icmp eq i64 %t189, 1
  store i1 %t191, ptr %l139, !tbaa !21
  br label %bb61
bb61:
  %t192 = load i1, ptr %l139, !tbaa !21
  br i1 %t192, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ec84fe6443685676_e22a9bc60a48a0b2)
  unreachable
bb70:
  %t193 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l142
  br label %bb71
bb71:
  %t194 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %l13
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Call", ptr %t195, i32 0, i32 1
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l16, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb86
bb74:
  br label %bb75
bb75:
  %t212 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t212, ptr %l151, !tbaa !27
  %t213 = load i64, ptr %l15, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  store ptr %t218, ptr %l17, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l17, !tbaa !29
  %t224 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s12, ptr %t220, ptr %t221)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t224, ptr %l156
  br label %bb76
bb76:
  %t225 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t225, ptr %l18
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l157, !tbaa !29
  %t227 = load ptr, ptr %l17, !tbaa !29
  %t229 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t227)
  store i32 %t229, ptr %l159
  br label %bb77
bb77:
  %t230 = load ptr, ptr %l157, !tbaa !29
  %t231 = load i32, ptr %l159, !tbaa !23
  %t232 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewritable(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t232, ptr %l160
  br label %bb78
bb78:
  %t233 = load i1, ptr %l160, !tbaa !21
  br i1 %t233, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s13
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %s12, ptr %s13, ptr %t234, ptr %l18, i64 -1, %"compiler/source:Span" %t235, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s13)
  br label %bb82
bb82:
  store ptr %l13, ptr %l164, !tbaa !29
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l165
  %t241 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s12, ptr %l165)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t241, ptr %l167
  br label %bb83
bb83:
  %t242 = load ptr, ptr %l164, !tbaa !29
  %t243 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l167
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s12, ptr %t242, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s12)
  br label %bb85
bb85:
  %t244 = load i64, ptr %l15, !tbaa !24
  %t246 = add i64 %t244, 1
  store i64 %t246, ptr %l15, !tbaa !24
  br label %bb72
bb86:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l2, !tbaa !23
  %t252 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l172
  br label %bb87
bb87:
  %t253 = load i1, ptr %l172, !tbaa !21
  br i1 %t253, label %bb88, label %bb89
bb88:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Call", ptr %t254, i32 0, i32 3
  %t257 = load i32, ptr %t256, !tbaa !23
  %t259 = icmp sge i32 %t257, 0
  store i1 %t259, ptr %l173, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l173, !tbaa !21
  br label %bb90
bb90:
  %t261 = load i1, ptr %l173, !tbaa !21
  br i1 %t261, label %bb91, label %bb92
bb91:
  %t262 = load ptr, ptr %lp5
  store ptr %t262, ptr %l177, !tbaa !29
  %t263 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Call", ptr %t264, i32 0, i32 3
  %t267 = load i32, ptr %t266, !tbaa !23
  %t269 = sext i32 %t267 to i64
  %t272 = call i64 @compiler_2ffree_2eorig(i64 %t263, i64 %t269)
  store i64 %t272, ptr %l182
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t273 = load ptr, ptr %l177, !tbaa !29
  %t274 = load i64, ptr %l182, !tbaa !24
  %t275 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t273, i64 %t274)
  store i64 %t275, ptr %l183
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t276 = load i64, ptr %l6, !tbaa !24
  %t278 = icmp slt i64 %t276, 0
  br i1 %t278, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb98
bb97:
  %t280 = load i1, ptr %l7, !tbaa !21
  store i1 %t280, ptr %l186, !tbaa !21
  br label %bb98
bb98:
  %t282 = load i1, ptr %l186, !tbaa !21
  br i1 %t282, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb102
bb100:
  %t283 = load ptr, ptr %l4, !tbaa !29
  %t284 = load i64, ptr %l6, !tbaa !24
  %t287 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t283, i64 %t284)
  store i64 %t287, ptr %l191
  br label %bb101
bb101:
  %t288 = load i64, ptr %l191, !tbaa !24
  %t289 = icmp ne i64 %t288, 0
  store i1 %t289, ptr %l188, !tbaa !21
  br label %bb102
bb102:
  %t291 = load i1, ptr %l188, !tbaa !21
  br i1 %t291, label %bb103, label %bb104
bb103:
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Call", ptr %t292, i32 0, i32 3
  %t295 = load i32, ptr %t294, !tbaa !23
  %t297 = sext i32 %t295 to i64
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/free:walker", ptr %t298, i32 0, i32 32
  %t301 = load i64, ptr %t300, !tbaa !24
  %t304 = icmp ne i64 %t297, %t301
  store i1 %t304, ptr %l193, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb105
bb105:
  %t306 = load i1, ptr %l193, !tbaa !21
  br i1 %t306, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s16
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l2, !tbaa !23
  %t309 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s16, ptr %t307, i32 %t308, %"compiler/source:Span" %t309, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb108
bb107:
  br label %bb109
bb108:
  call void @__olang_scope_close(ptr %s16)
  br label %bb109
bb109:
  %t313 = load i64, ptr %l6, !tbaa !24
  %t315 = icmp sge i64 %t313, 0
  br i1 %t315, label %bb110, label %bb111
bb110:
  %t317 = load i1, ptr %l7, !tbaa !21
  %t319 = xor i1 %t317, true
  store i1 %t319, ptr %l205, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb112
bb112:
  %t321 = load i1, ptr %l205, !tbaa !21
  br i1 %t321, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s17
  %t322 = load ptr, ptr %l4, !tbaa !29
  %t323 = load i64, ptr %l6, !tbaa !24
  %t326 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t322, i64 %t323)
  store i1 %t326, ptr %l210
  br label %bb115
bb114:
  br label %bb225
bb115:
  %t327 = load i1, ptr %l210, !tbaa !21
  br i1 %t327, label %bb116, label %bb117
bb116:
  store ptr %l13, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb118
bb117:
  br label %bb128
bb118:
  store %olang.scope zeroinitializer, ptr %s20
  %t329 = load i64, ptr %l20, !tbaa !24
  store i64 %t329, ptr %l212, !tbaa !24
  %t330 = load ptr, ptr %l19, !tbaa !29
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %t330)
  store i64 %t332, ptr %l214
  br label %bb119
bb119:
  %t333 = load i64, ptr %l212, !tbaa !24
  %t334 = load i64, ptr %l214, !tbaa !24
  %t335 = icmp slt i64 %t333, %t334
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s20)
  br label %bb127
bb121:
  br label %bb122
bb122:
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t340 = load i64, ptr %l20, !tbaa !24
  %t343 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %t339, i64 %t340)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %l219
  br label %bb123
bb123:
  %t345 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l219)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t345, ptr %l221
  br label %bb124
bb124:
  %t346 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, ptr %l21
  %t347 = load ptr, ptr %lp5
  %t350 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s20, ptr %t347, ptr %l21)
  store i64 %t350, ptr %l224
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s20)
  br label %bb126
bb126:
  %t351 = load i64, ptr %l20, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l20, !tbaa !24
  br label %bb118
bb127:
  %t355 = load ptr, ptr %lp5
  %t356 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t355
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t356, ptr %rv
  br label %ret
bb128:
  %t358 = load ptr, ptr %l4, !tbaa !29
  %t360 = getelementptr %"compiler/free:Free", ptr %t358, i32 0, i32 24
  %t361 = load i64, ptr %l6, !tbaa !24
  %t364 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t360, i64 %t361)
  store ptr %t364, ptr %l231
  br label %bb129
bb129:
  %t365 = load ptr, ptr %l231, !tbaa !29
  store ptr %t365, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb130
bb130:
  %t366 = load i64, ptr %l23, !tbaa !24
  store i64 %t366, ptr %l232, !tbaa !24
  %t367 = load ptr, ptr %l22, !tbaa !29
  %t369 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t367)
  store i64 %t369, ptr %l234
  br label %bb131
bb131:
  %t370 = load i64, ptr %l232, !tbaa !24
  %t371 = load i64, ptr %l234, !tbaa !24
  %t372 = icmp slt i64 %t370, %t371
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb132, label %bb133
bb132:
  br label %bb150
bb133:
  br label %bb134
bb134:
  %t376 = load ptr, ptr %l22, !tbaa !29
  %t377 = load i64, ptr %l23, !tbaa !24
  %t380 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t376, i64 %t377)
  store i64 %t380, ptr %l239
  br label %bb135
bb135:
  %t381 = load i64, ptr %l239, !tbaa !24
  store i64 %t381, ptr %l24, !tbaa !24
  %t382 = load i64, ptr %l24, !tbaa !24
  %t384 = call i64 @compiler_2ffree_2eokind(i64 %t382)
  store i64 %t384, ptr %l241
  br label %bb136
bb136:
  %t385 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t386 = load i64, ptr %l241, !tbaa !24
  %t388 = icmp eq i64 %t386, %t385
  br i1 %t388, label %bb137, label %bb138
bb137:
  %t390 = load i64, ptr %l24, !tbaa !24
  %t392 = call i64 @compiler_2ffree_2eoval(i64 %t390)
  store i64 %t392, ptr %l245
  br label %bb139
bb138:
  %t393 = load ptr, ptr %lp5
  %t394 = load i64, ptr %l24, !tbaa !24
  %t397 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t393, i64 %t394)
  store i64 %t397, ptr %l260
  br label %bb147
bb139:
  %t398 = load i64, ptr %l245, !tbaa !24
  store i64 %t398, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l25, !tbaa !24
  store i64 %t399, ptr %l246, !tbaa !24
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l13)
  store i64 %t401, ptr %l248
  br label %bb140
bb140:
  %t402 = load i64, ptr %l246, !tbaa !24
  %t403 = load i64, ptr %l248, !tbaa !24
  %t404 = icmp slt i64 %t402, %t403
  br i1 %t404, label %bb141, label %bb142
bb141:
  store %olang.scope zeroinitializer, ptr %s25
  %t406 = load ptr, ptr %lp5
  store ptr %t406, ptr %l250, !tbaa !29
  %t407 = load i64, ptr %l25, !tbaa !24
  %t410 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l13, i64 %t407)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t410, ptr %l253
  br label %bb143
bb142:
  br label %bb146
bb143:
  %t412 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l253)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t412, ptr %l255
  br label %bb144
bb144:
  %t413 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255
  %t414 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t413, ptr %t414
  %t415 = load ptr, ptr %l250, !tbaa !29
  %t417 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s0, ptr %t415, ptr %t414)
  store i64 %t417, ptr %l257
  br label %bb145
bb145:
  call void @__olang_scope_close(ptr %s25)
  br label %bb146
bb146:
  br label %bb148
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t418 = load i64, ptr %l23, !tbaa !24
  %t420 = add i64 %t418, 1
  store i64 %t420, ptr %l23, !tbaa !24
  br label %bb130
bb150:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t422)
  store ptr %t424, ptr %l264
  br label %bb151
bb151:
  %t425 = load ptr, ptr %l4, !tbaa !29
  %t427 = getelementptr %"compiler/free:Free", ptr %t425, i32 0, i32 1
  %t428 = load i64, ptr %l6, !tbaa !24
  %t431 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t427, i64 %t428)
  store ptr %t431, ptr %l268
  br label %bb152
bb152:
  %t432 = load ptr, ptr %l268, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Body", ptr %t432, i32 0, i32 2
  %t435 = load i32, ptr %t434, !tbaa !23
  %t436 = load ptr, ptr %l264, !tbaa !29
  %t438 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t436, i32 %t435)
  store i64 %t438, ptr %l271
  br label %bb153
bb153:
  %t439 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t440 = load i64, ptr %l271, !tbaa !24
  %t442 = icmp eq i64 %t440, %t439
  store i1 %t442, ptr %l26, !tbaa !21
  %t444 = load ptr, ptr %l4, !tbaa !29
  %t446 = getelementptr %"compiler/free:Free", ptr %t444, i32 0, i32 25
  %t447 = load i64, ptr %l6, !tbaa !24
  %t450 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t446, i64 %t447)
  store ptr %t450, ptr %l277
  br label %bb154
bb154:
  %t451 = load ptr, ptr %l277, !tbaa !29
  store ptr %t451, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb155
bb155:
  %t452 = load i64, ptr %l28, !tbaa !24
  store i64 %t452, ptr %l278, !tbaa !24
  %t453 = load ptr, ptr %l27, !tbaa !29
  %t455 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t453)
  store i64 %t455, ptr %l280
  br label %bb156
bb156:
  %t456 = load i64, ptr %l278, !tbaa !24
  %t457 = load i64, ptr %l280, !tbaa !24
  %t458 = icmp slt i64 %t456, %t457
  %t460 = xor i1 %t458, true
  br i1 %t460, label %bb157, label %bb158
bb157:
  br label %bb170
bb158:
  br label %bb159
bb159:
  %t462 = load ptr, ptr %l27, !tbaa !29
  %t463 = load i64, ptr %l28, !tbaa !24
  %t466 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t462, i64 %t463)
  store i64 %t466, ptr %l285
  br label %bb160
bb160:
  %t467 = load i64, ptr %l285, !tbaa !24
  store i64 %t467, ptr %l29, !tbaa !24
  %t468 = load i64, ptr %l29, !tbaa !24
  %t470 = ashr i64 %t468, 32
  store i64 %t470, ptr %l30, !tbaa !24
  %t472 = load i64, ptr %l29, !tbaa !24
  %t473 = shl i64 1, 32
  %t475 = sub i64 %t473, 1
  %t478 = and i64 %t472, %t475
  store i64 %t478, ptr %l31, !tbaa !24
  %t480 = load i64, ptr %l30, !tbaa !24
  store i64 %t480, ptr %l292, !tbaa !24
  %t482 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l13)
  store i64 %t482, ptr %l294
  br label %bb161
bb161:
  %t483 = load i64, ptr %l292, !tbaa !24
  %t484 = load i64, ptr %l294, !tbaa !24
  %t485 = icmp slt i64 %t483, %t484
  br i1 %t485, label %bb162, label %bb163
bb162:
  store %olang.scope zeroinitializer, ptr %s30
  %t487 = load ptr, ptr %l4, !tbaa !29
  %t488 = load i64, ptr %l6, !tbaa !24
  %t489 = load i64, ptr %l30, !tbaa !24
  %t493 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %t487, i64 %t488, i64 %t489)
  store i1 %t493, ptr %l299
  br label %bb164
bb163:
  br label %bb168
bb164:
  %t494 = load i1, ptr %l299, !tbaa !21
  store i1 %t494, ptr %l32, !tbaa !21
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l300, !tbaa !29
  %t496 = load i64, ptr %l31, !tbaa !24
  store i64 %t496, ptr %l301, !tbaa !24
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr %"compiler/typed:Call", ptr %t497, i32 0, i32 1
  %t500 = load { i64, ptr }, ptr %t499, !tbaa !27
  store { i64, ptr } %t500, ptr %l303, !tbaa !27
  %t501 = load i64, ptr %l30, !tbaa !24
  %t503 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr ptr, ptr %t504, i64 %t501
  %t506 = load ptr, ptr %t505, !tbaa !39
  store ptr %t506, ptr %l305, !tbaa !29
  %t507 = load i64, ptr %l30, !tbaa !24
  %t510 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l13, i64 %t507)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t510, ptr %l308
  br label %bb165
bb165:
  %t512 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l308)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t512, ptr %l310
  br label %bb166
bb166:
  %t513 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l310
  %t514 = call ptr @__olang_scope_alloc_a(ptr %s30, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t513, ptr %t514
  %t515 = load %"compiler/source:Span", ptr %l3
  %t516 = load i1, ptr %l32, !tbaa !21
  %t517 = load i1, ptr %l26, !tbaa !21
  %t518 = load ptr, ptr %l300, !tbaa !29
  %t519 = load i64, ptr %l301, !tbaa !24
  %t520 = load ptr, ptr %l305, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s30, ptr %t518, i64 %t519, ptr %t520, ptr %t514, %"compiler/source:Span" %t515, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, i1 %t516, i1 %t517)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s30)
  br label %bb168
bb168:
  br label %bb169
bb169:
  %t525 = load i64, ptr %l28, !tbaa !24
  %t527 = add i64 %t525, 1
  store i64 %t527, ptr %l28, !tbaa !24
  br label %bb155
bb170:
  %t529 = load ptr, ptr %l4, !tbaa !29
  %t531 = getelementptr %"compiler/free:Free", ptr %t529, i32 0, i32 26
  %t532 = load i64, ptr %l6, !tbaa !24
  %t535 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t531, i64 %t532)
  store ptr %t535, ptr %l320
  br label %bb171
bb171:
  %t536 = load ptr, ptr %l320, !tbaa !29
  store ptr %t536, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb172
bb172:
  %t537 = load i64, ptr %l34, !tbaa !24
  store i64 %t537, ptr %l321, !tbaa !24
  %t538 = load ptr, ptr %l33, !tbaa !29
  %t540 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t538)
  store i64 %t540, ptr %l323
  br label %bb173
bb173:
  %t541 = load i64, ptr %l321, !tbaa !24
  %t542 = load i64, ptr %l323, !tbaa !24
  %t543 = icmp slt i64 %t541, %t542
  %t545 = xor i1 %t543, true
  br i1 %t545, label %bb174, label %bb175
bb174:
  br label %bb186
bb175:
  br label %bb176
bb176:
  %t547 = load ptr, ptr %l33, !tbaa !29
  %t548 = load i64, ptr %l34, !tbaa !24
  %t551 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t547, i64 %t548)
  store i64 %t551, ptr %l328
  br label %bb177
bb177:
  %t552 = load i64, ptr %l328, !tbaa !24
  store i64 %t552, ptr %l35, !tbaa !24
  %t553 = load i64, ptr %l35, !tbaa !24
  store i64 %t553, ptr %l329, !tbaa !24
  %t555 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l13)
  store i64 %t555, ptr %l331
  br label %bb178
bb178:
  %t556 = load i64, ptr %l329, !tbaa !24
  %t557 = load i64, ptr %l331, !tbaa !24
  %t558 = icmp slt i64 %t556, %t557
  br i1 %t558, label %bb179, label %bb180
bb179:
  store %olang.scope zeroinitializer, ptr %s34
  %t560 = load ptr, ptr %l0, !tbaa !29
  store ptr %t560, ptr %l333, !tbaa !29
  %t561 = load i64, ptr %l35, !tbaa !24
  %t564 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l13, i64 %t561)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t564, ptr %l336
  br label %bb181
bb180:
  br label %bb184
bb181:
  %t566 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l336)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t566, ptr %l338
  br label %bb182
bb182:
  %t567 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l338
  %t568 = call ptr @__olang_scope_alloc_a(ptr %s34, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t567, ptr %t568
  %t569 = load %"compiler/source:Span", ptr %l3
  %t570 = load ptr, ptr %l333, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s34, ptr %t570, ptr %t568, %"compiler/source:Span" %t569, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s34)
  br label %bb184
bb184:
  br label %bb185
bb185:
  %t573 = load i64, ptr %l34, !tbaa !24
  %t575 = add i64 %t573, 1
  store i64 %t575, ptr %l34, !tbaa !24
  br label %bb172
bb186:
  %t577 = load ptr, ptr %l4, !tbaa !29
  %t579 = getelementptr %"compiler/free:Free", ptr %t577, i32 0, i32 29
  %t580 = load i64, ptr %l6, !tbaa !24
  %t583 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t579, i64 %t580)
  store i1 %t583, ptr %l346
  br label %bb187
bb187:
  %t584 = load i1, ptr %l346, !tbaa !21
  br i1 %t584, label %bb188, label %bb189
bb188:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l3
  %t587 = load ptr, ptr %l1, !tbaa !29
  %t588 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t585, %"compiler/source:Span" %t586, ptr %t587, i64 %t588)
  br label %bb190
bb189:
  %t593 = load ptr, ptr %l4, !tbaa !29
  %t595 = getelementptr %"compiler/free:Free", ptr %t593, i32 0, i32 28
  %t596 = load i64, ptr %l6, !tbaa !24
  %t599 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t595, i64 %t596)
  store ptr %t599, ptr %l354
  br label %bb191
bb190:
  br label %bb202
bb191:
  %t600 = load ptr, ptr %l354, !tbaa !29
  store ptr %t600, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb192
bb192:
  %t601 = load i64, ptr %l37, !tbaa !24
  store i64 %t601, ptr %l355, !tbaa !24
  %t602 = load ptr, ptr %l36, !tbaa !29
  %t604 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t602)
  store i64 %t604, ptr %l357
  br label %bb193
bb193:
  %t605 = load i64, ptr %l355, !tbaa !24
  %t606 = load i64, ptr %l357, !tbaa !24
  %t607 = icmp slt i64 %t605, %t606
  %t609 = xor i1 %t607, true
  br i1 %t609, label %bb194, label %bb195
bb194:
  br label %bb201
bb195:
  br label %bb196
bb196:
  %t611 = load ptr, ptr %l36, !tbaa !29
  %t612 = load i64, ptr %l37, !tbaa !24
  %t615 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t611, i64 %t612)
  store i64 %t615, ptr %l362
  br label %bb197
bb197:
  %t616 = load i64, ptr %l362, !tbaa !24
  %t617 = load ptr, ptr %l0, !tbaa !29
  store ptr %t617, ptr %l363, !tbaa !29
  store i64 %t616, ptr %l364, !tbaa !24
  %t619 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t619, ptr %l365, !tbaa !24
  %t620 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t620, ptr %l366
  %t621 = load ptr, ptr %l1, !tbaa !29
  %t623 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t621)
  store %"compiler/source:Span" %t623, ptr %l368
  br label %bb198
bb198:
  %t624 = load i64, ptr %l6, !tbaa !24
  %t625 = load ptr, ptr %l363, !tbaa !29
  %t626 = load i64, ptr %l364, !tbaa !24
  %t627 = load i64, ptr %l365, !tbaa !24
  %t628 = load %"compiler/source:Span", ptr %l366
  %t629 = load %"compiler/source:Span", ptr %l368
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t625, i64 %t626, i64 %t627, %"compiler/source:Span" %t628, %"compiler/source:Span" %t629, i64 %t624)
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t631 = load i64, ptr %l37, !tbaa !24
  %t633 = add i64 %t631, 1
  store i64 %t633, ptr %l37, !tbaa !24
  br label %bb192
bb201:
  br label %bb202
bb202:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/free:walker", ptr %t635, i32 0, i32 2
  %t638 = load i1, ptr %t637, !tbaa !21
  br i1 %t638, label %bb203, label %bb204
bb203:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/free:walker", ptr %t640, i32 0, i32 29
  %t643 = load i64, ptr %t642, !tbaa !24
  %t645 = icmp eq i64 %t643, 0
  store i1 %t645, ptr %l374, !tbaa !21
  br label %bb205
bb204:
  store i1 false, ptr %l374, !tbaa !21
  br label %bb205
bb205:
  %t647 = load i1, ptr %l374, !tbaa !21
  br i1 %t647, label %bb206, label %bb207
bb206:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t649 = load ptr, ptr %l1, !tbaa !29
  %t650 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %t648, ptr %t649, i64 %t650)
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb209
bb209:
  %t654 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s17, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t654, ptr %l381
  br label %bb210
bb210:
  %t655 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l381
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t655, ptr %l39
  %t656 = load ptr, ptr %lp5
  store ptr %t656, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb211
bb211:
  %t658 = load i64, ptr %l41, !tbaa !24
  store i64 %t658, ptr %l383, !tbaa !24
  %t659 = load ptr, ptr %l40, !tbaa !29
  %t661 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t659)
  store i64 %t661, ptr %l385
  br label %bb212
bb212:
  %t662 = load i64, ptr %l383, !tbaa !24
  %t663 = load i64, ptr %l385, !tbaa !24
  %t664 = icmp slt i64 %t662, %t663
  %t666 = xor i1 %t664, true
  br i1 %t666, label %bb213, label %bb214
bb213:
  br label %bb223
bb214:
  br label %bb215
bb215:
  %t668 = load ptr, ptr %l40, !tbaa !29
  %t669 = load i64, ptr %l41, !tbaa !24
  %t672 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t668, i64 %t669)
  store i64 %t672, ptr %l390
  br label %bb216
bb216:
  %t673 = load i64, ptr %l390, !tbaa !24
  store i64 %t673, ptr %l42, !tbaa !24
  %t674 = load i64, ptr %l42, !tbaa !24
  %t676 = call i64 @compiler_2ffree_2eokind(i64 %t674)
  store i64 %t676, ptr %l392
  br label %bb217
bb217:
  %t677 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t678 = load i64, ptr %l392, !tbaa !24
  %t680 = icmp eq i64 %t678, %t677
  br i1 %t680, label %bb218, label %bb219
bb218:
  %t682 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s17, ptr %l39, i64 %t682)
  br label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb221
bb221:
  br label %bb222
bb222:
  %t685 = load i64, ptr %l41, !tbaa !24
  %t687 = add i64 %t685, 1
  store i64 %t687, ptr %l41, !tbaa !24
  br label %bb211
bb223:
  %t689 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %s17, ptr %t689, ptr %l39)
  br label %bb224
bb224:
  %t692 = load ptr, ptr %lp5
  %t693 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t692
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t693, ptr %rv
  br label %ret
bb225:
  store ptr %l13, ptr %l43, !tbaa !29
  store i64 0, ptr %l44, !tbaa !24
  br label %bb226
bb226:
  store %olang.scope zeroinitializer, ptr %s47
  %t696 = load i64, ptr %l44, !tbaa !24
  store i64 %t696, ptr %l403, !tbaa !24
  %t697 = load ptr, ptr %l43, !tbaa !29
  %t699 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %t697)
  store i64 %t699, ptr %l405
  br label %bb227
bb227:
  %t700 = load i64, ptr %l403, !tbaa !24
  %t701 = load i64, ptr %l405, !tbaa !24
  %t702 = icmp slt i64 %t700, %t701
  %t704 = xor i1 %t702, true
  br i1 %t704, label %bb228, label %bb229
bb228:
  call void @__olang_scope_close(ptr %s47)
  br label %bb239
bb229:
  br label %bb230
bb230:
  %t706 = load ptr, ptr %l43, !tbaa !29
  %t707 = load i64, ptr %l44, !tbaa !24
  %t710 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %t706, i64 %t707)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t710, ptr %l410
  br label %bb231
bb231:
  %t712 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l410)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t712, ptr %l412
  br label %bb232
bb232:
  %t713 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l412
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t713, ptr %l45
  %t714 = load ptr, ptr %lp5
  %t717 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s47, ptr %t714, ptr %l45)
  store i64 %t717, ptr %l415
  br label %bb233
bb233:
  %t718 = load i1, ptr %l8, !tbaa !21
  %t720 = xor i1 %t718, true
  br i1 %t720, label %bb234, label %bb235
bb234:
  store %olang.scope zeroinitializer, ptr %s48
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t723 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s47, ptr %s48, ptr %t722, ptr %l45, %"compiler/source:Span" %t723, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb236
bb235:
  br label %bb237
bb236:
  call void @__olang_scope_close(ptr %s48)
  br label %bb237
bb237:
  call void @__olang_scope_close(ptr %s47)
  br label %bb238
bb238:
  %t727 = load i64, ptr %l44, !tbaa !24
  %t729 = add i64 %t727, 1
  store i64 %t729, ptr %l44, !tbaa !24
  br label %bb226
bb239:
  %t731 = load ptr, ptr %lp5
  store ptr %t731, ptr %l423, !tbaa !29
  %t732 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t734 = call i64 @compiler_2ffree_2eorig(i64 %t732, i64 0)
  store i64 %t734, ptr %l425
  br label %bb240
bb240:
  %t735 = load ptr, ptr %l423, !tbaa !29
  %t736 = load i64, ptr %l425, !tbaa !24
  %t737 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t735, i64 %t736)
  store i64 %t737, ptr %l426
  br label %bb241
bb241:
  %t738 = load i1, ptr %l9, !tbaa !21
  br i1 %t738, label %bb242, label %bb243
bb242:
  %t740 = load ptr, ptr %l1, !tbaa !29
  %t742 = getelementptr %"compiler/typed:Call", ptr %t740, i32 0, i32 1
  %t743 = load { i64, ptr }, ptr %t742, !tbaa !27
  store { i64, ptr } %t743, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t745 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t745, 0
  store i64 %t747, ptr %l48, !tbaa !24
  br label %bb244
bb243:
  %t749 = load i1, ptr %l8, !tbaa !21
  %t751 = xor i1 %t749, true
  br i1 %t751, label %bb285, label %bb286
bb244:
  %t753 = load i64, ptr %l47, !tbaa !24
  %t754 = load i64, ptr %l48, !tbaa !24
  %t757 = icmp slt i64 %t753, %t754
  %t759 = xor i1 %t757, true
  br i1 %t759, label %bb245, label %bb246
bb245:
  br label %bb258
bb246:
  br label %bb247
bb247:
  %t761 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t761, ptr %l436, !tbaa !27
  %t762 = load i64, ptr %l47, !tbaa !24
  %t764 = getelementptr { i64, ptr }, ptr %l436, i32 0, i32 1
  %t765 = load ptr, ptr %t764, !tbaa !27
  %t766 = getelementptr ptr, ptr %t765, i64 %t762
  %t767 = load ptr, ptr %t766, !tbaa !39
  store ptr %t767, ptr %l49, !tbaa !29
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t769)
  store ptr %t771, ptr %l440
  br label %bb248
bb248:
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t774 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t772)
  store ptr %t774, ptr %l442
  br label %bb249
bb249:
  %t775 = load ptr, ptr %l49, !tbaa !29
  %t777 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t775)
  store i32 %t777, ptr %l444
  br label %bb250
bb250:
  %t778 = load ptr, ptr %l442, !tbaa !29
  %t779 = load i32, ptr %l444, !tbaa !23
  %t780 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t778, i32 %t779)
  store i32 %t780, ptr %l445
  br label %bb251
bb251:
  %t781 = load ptr, ptr %l440, !tbaa !29
  %t782 = load i32, ptr %l445, !tbaa !23
  %t783 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t781, i32 %t782)
  store i32 %t783, ptr %l446
  br label %bb252
bb252:
  %t784 = load i32, ptr %l446, !range !{i32 0, i32 33}
  %t786 = trunc i64 21 to i32
  %t787 = icmp eq i32 %t784, %t786
  br i1 %t787, label %bb253, label %bb254
bb253:
  %t789 = load ptr, ptr %l4, !tbaa !29
  %t791 = getelementptr %"compiler/free:Free", ptr %t789, i32 0, i32 36
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/free:walker", ptr %t792, i32 0, i32 1
  %t795 = load i64, ptr %t794, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t791, i64 %t795, i1 true)
  br label %bb255
bb254:
  br label %bb256
bb255:
  br label %bb256
bb256:
  br label %bb257
bb257:
  %t798 = load i64, ptr %l47, !tbaa !24
  %t800 = add i64 %t798, 1
  store i64 %t800, ptr %l47, !tbaa !24
  br label %bb244
bb258:
  store i1 false, ptr %l50, !tbaa !21
  %t802 = load ptr, ptr %l4, !tbaa !29
  %t804 = getelementptr %"compiler/free:Free", ptr %t802, i32 0, i32 33
  store ptr %t804, ptr %l51, !tbaa !29
  store i64 0, ptr %l52, !tbaa !24
  br label %bb259
bb259:
  %t806 = load i64, ptr %l52, !tbaa !24
  store i64 %t806, ptr %l457, !tbaa !24
  %t807 = load ptr, ptr %l51, !tbaa !29
  %t809 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t807)
  store i64 %t809, ptr %l459
  br label %bb260
bb260:
  %t810 = load i64, ptr %l457, !tbaa !24
  %t811 = load i64, ptr %l459, !tbaa !24
  %t812 = icmp slt i64 %t810, %t811
  %t814 = xor i1 %t812, true
  br i1 %t814, label %bb261, label %bb262
bb261:
  br label %bb280
bb262:
  br label %bb263
bb263:
  %t816 = load ptr, ptr %l51, !tbaa !29
  %t817 = load i64, ptr %l52, !tbaa !24
  %t820 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t816, i64 %t817)
  store i64 %t820, ptr %l464
  br label %bb264
bb264:
  %t821 = load i64, ptr %l464, !tbaa !24
  store i64 %t821, ptr %l53, !tbaa !24
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t824 = getelementptr %"compiler/free:walker", ptr %t822, i32 0, i32 2
  %t825 = load i1, ptr %t824, !tbaa !21
  %t827 = xor i1 %t825, true
  br i1 %t827, label %bb265, label %bb266
bb265:
  %t829 = load ptr, ptr %l4, !tbaa !29
  %t831 = getelementptr %"compiler/free:Free", ptr %t829, i32 0, i32 54
  %t832 = load i64, ptr %l53, !tbaa !24
  %t835 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t831, i64 %t832)
  store ptr %t835, ptr %l471
  br label %bb267
bb266:
  br label %bb269
bb267:
  %t836 = load ptr, ptr %l0, !tbaa !29
  %t838 = getelementptr %"compiler/free:walker", ptr %t836, i32 0, i32 1
  %t839 = load i64, ptr %t838, !tbaa !24
  %t840 = load ptr, ptr %l471, !tbaa !29
  %t842 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t840, i64 %t839)
  store i64 %t842, ptr %l474
  br label %bb268
bb268:
  br label %bb269
bb269:
  %t843 = load ptr, ptr %l4, !tbaa !29
  %t845 = getelementptr %"compiler/free:Free", ptr %t843, i32 0, i32 28
  %t846 = load i64, ptr %l53, !tbaa !24
  %t849 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t845, i64 %t846)
  store ptr %t849, ptr %l478
  br label %bb270
bb270:
  %t850 = load ptr, ptr %l478, !tbaa !29
  %t851 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t850)
  store i64 %t851, ptr %l479
  br label %bb271
bb271:
  %t852 = load i64, ptr %l479, !tbaa !24
  %t853 = icmp sgt i64 %t852, 0
  br i1 %t853, label %bb272, label %bb273
bb272:
  store i1 true, ptr %l481, !tbaa !21
  br label %bb275
bb273:
  %t855 = load ptr, ptr %l4, !tbaa !29
  %t857 = getelementptr %"compiler/free:Free", ptr %t855, i32 0, i32 29
  %t858 = load i64, ptr %l53, !tbaa !24
  %t861 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t857, i64 %t858)
  store i1 %t861, ptr %l485
  br label %bb274
bb274:
  %t862 = load i1, ptr %l485, !tbaa !21
  store i1 %t862, ptr %l481, !tbaa !21
  br label %bb275
bb275:
  %t863 = load i1, ptr %l481, !tbaa !21
  br i1 %t863, label %bb276, label %bb277
bb276:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb278
bb277:
  br label %bb278
bb278:
  br label %bb279
bb279:
  %t864 = load i64, ptr %l52, !tbaa !24
  %t866 = add i64 %t864, 1
  store i64 %t866, ptr %l52, !tbaa !24
  br label %bb259
bb280:
  %t868 = load i1, ptr %l50, !tbaa !21
  br i1 %t868, label %bb281, label %bb282
bb281:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load %"compiler/source:Span", ptr %l3
  %t872 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t870, %"compiler/source:Span" %t871, ptr %t872, i64 -1)
  br label %bb283
bb282:
  br label %bb284
bb283:
  br label %bb284
bb284:
  br label %bb289
bb285:
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load %"compiler/source:Span", ptr %l3
  %t878 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t876, %"compiler/source:Span" %t877, ptr %t878, i64 -1)
  br label %bb287
bb286:
  br label %bb288
bb287:
  br label %bb288
bb288:
  br label %bb289
bb289:
  %t882 = load ptr, ptr %lp5
  %t883 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t882
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t883, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i1
  %l67 = alloca i64
  %l71 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i32
  %l89 = alloca i1
  %l92 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca ptr
  %l103 = alloca %"compiler/typed:Local"
  %l105 = alloca i1
  %l106 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i32
  %l114 = alloca i64
  %l118 = alloca i64
  %l122 = alloca i64
  %l124 = alloca i64
  %l129 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l138 = alloca i64
  %l140 = alloca i1
  %l148 = alloca i64
  %l150 = alloca i1
  %l164 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 54
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l24
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l23
  br label %bb3
bb2:
  br label %bb31
bb3:
  %t16 = load i64, ptr %l23, !tbaa !24
  store i64 %t16, ptr %l19, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 11
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  store ptr %t23, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t25 = load i64, ptr %l7, !tbaa !24
  store i64 %t25, ptr %l28, !tbaa !24
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t26)
  store i64 %t28, ptr %l30
  br label %bb8
bb8:
  %t29 = load i64, ptr %l28, !tbaa !24
  %t30 = load i64, ptr %l30, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l35
  br label %bb12
bb12:
  %t40 = load i64, ptr %l35, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 25
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t43, i64 %t44)
  store i64 %t47, ptr %l39
  br label %bb13
bb13:
  %t48 = load i64, ptr %l39, !tbaa !24
  store i64 %t48, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp sgt i64 %t49, %t50
  br i1 %t53, label %bb14, label %bb15
bb14:
  %t55 = load i64, ptr %l8, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 52
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l47
  br label %bb17
bb17:
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:walker", ptr %t67, i32 0, i32 52
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t69, i64 %t70)
  store i64 %t73, ptr %l53
  br label %bb20
bb19:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb21
bb20:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t75 = load i64, ptr %l53, !tbaa !24
  %t77 = icmp ne i64 %t75, %t74
  store i1 %t77, ptr %l49, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l49, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  store i1 %t84, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l56, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load i64, ptr %l8, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb7
bb29:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l1, !tbaa !24
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t101 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %t93, i64 %t94, i64 %t95, ptr %t96)
  store i64 %t101, ptr %l67
  br label %bb30
bb30:
  %t102 = load i64, ptr %l67, !tbaa !24
  store i64 %t102, ptr %rv
  br label %ret
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/free:walker", ptr %t103, i32 0, i32 20
  %t106 = load i64, ptr %l1, !tbaa !24
  %t109 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t105, i64 %t106)
  store i64 %t109, ptr %l71
  br label %bb32
bb32:
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load i64, ptr %l71, !tbaa !24
  %t113 = icmp sgt i64 %t111, %t110
  br i1 %t113, label %bb33, label %bb34
bb33:
  store i64 -1, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 55
  %t119 = load i64, ptr %l2, !tbaa !24
  %t122 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t118, i64 %t119)
  %t123 = extractvalue { i32, i64 } %t122, 1
  %t124 = extractvalue { i32, i64 } %t122, 0
  store i32 %t124, ptr %l80
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb37, label %ok.126, !prof !99
ok.126:
  store i64 %t123, ptr %l79
  br label %bb36
bb36:
  %t127 = load i64, ptr %l79, !tbaa !24
  store i64 %t127, ptr %l75, !tbaa !24
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l75, !tbaa !24
  br label %bb39
bb39:
  %t128 = load i64, ptr %l75, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 56
  %t132 = load i64, ptr %l2, !tbaa !24
  %t135 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t131, i64 %t132)
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l86
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb41, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l85
  br label %bb40
bb40:
  %t140 = load i64, ptr %l85, !tbaa !24
  store i64 %t140, ptr %l81, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l81, !tbaa !24
  br label %bb43
bb43:
  %t141 = load i64, ptr %l81, !tbaa !24
  store i64 %t141, ptr %l11, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = icmp slt i64 %t142, 0
  br i1 %t144, label %bb44, label %bb45
bb44:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = icmp sge i64 %t146, 0
  store i1 %t148, ptr %l89, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb46
bb46:
  %t150 = load i1, ptr %l89, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t151)
  store ptr %t153, ptr %l94
  br label %bb49
bb48:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb53
bb49:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l97, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t158)
  store ptr %t160, ptr %l99
  br label %bb50
bb50:
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 7
  %t164 = load i64, ptr %l1, !tbaa !24
  %t167 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t163, i64 %t164)
  store %"compiler/typed:Local" %t167, ptr %l103
  br label %bb51
bb51:
  %t168 = getelementptr %"compiler/typed:Local", ptr %l103, i32 0, i32 3
  %t169 = load i32, ptr %t168, !tbaa !23
  %t170 = load ptr, ptr %l94, !tbaa !29
  %t171 = load i32, ptr %l97, !tbaa !23
  %t173 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t170, i32 %t171, i32 %t169)
  store i1 %t173, ptr %l105
  br label %bb52
bb52:
  %t174 = load i1, ptr %l105, !tbaa !21
  store i1 %t174, ptr %l92, !tbaa !21
  br label %bb53
bb53:
  %t175 = load i1, ptr %l92, !tbaa !21
  br i1 %t175, label %bb54, label %bb55
bb54:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/free:walker", ptr %t176, i32 0, i32 57
  %t179 = load i64, ptr %l2, !tbaa !24
  %t182 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t178, i64 %t179)
  %t183 = extractvalue { i32, i64 } %t182, 1
  %t184 = extractvalue { i32, i64 } %t182, 0
  store i32 %t184, ptr %l111
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb57, label %ok.186, !prof !99
ok.186:
  store i64 %t183, ptr %l110
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t187 = load i64, ptr %l110, !tbaa !24
  store i64 %t187, ptr %l106, !tbaa !24
  br label %bb59
bb57:
  br label %bb58
bb58:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l106, !tbaa !24
  br label %bb59
bb59:
  %t188 = load i64, ptr %l106, !tbaa !24
  store i64 %t188, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  %t189 = load i64, ptr %l10, !tbaa !24
  %t191 = icmp sge i64 %t189, 0
  br i1 %t191, label %bb61, label %bb62
bb61:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:walker", ptr %t193, i32 0, i32 13
  %t196 = load i64, ptr %l10, !tbaa !24
  %t199 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t195, i64 %t196)
  store i64 %t199, ptr %l118
  br label %bb63
bb62:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:walker", ptr %t200, i32 0, i32 11
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l114, !tbaa !24
  br label %bb64
bb63:
  %t205 = load i64, ptr %l118, !tbaa !24
  store i64 %t205, ptr %l114, !tbaa !24
  br label %bb64
bb64:
  %t206 = load i64, ptr %l114, !tbaa !24
  store i64 %t206, ptr %l12, !tbaa !24
  %t207 = load ptr, ptr %l4, !tbaa !29
  store ptr %t207, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb65
bb65:
  %t209 = load i64, ptr %l14, !tbaa !24
  store i64 %t209, ptr %l122, !tbaa !24
  %t210 = load ptr, ptr %l13, !tbaa !29
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t210)
  store i64 %t212, ptr %l124
  br label %bb66
bb66:
  %t213 = load i64, ptr %l122, !tbaa !24
  %t214 = load i64, ptr %l124, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb67, label %bb68
bb67:
  br label %bb87
bb68:
  br label %bb69
bb69:
  %t219 = load ptr, ptr %l13, !tbaa !29
  %t220 = load i64, ptr %l14, !tbaa !24
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t219, i64 %t220)
  store i64 %t223, ptr %l129
  br label %bb70
bb70:
  %t224 = load i64, ptr %l129, !tbaa !24
  store i64 %t224, ptr %l15, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/free:walker", ptr %t225, i32 0, i32 25
  %t228 = load i64, ptr %l15, !tbaa !24
  %t231 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t227, i64 %t228)
  store i64 %t231, ptr %l133
  br label %bb71
bb71:
  %t232 = load i64, ptr %l133, !tbaa !24
  store i64 %t232, ptr %l16, !tbaa !24
  %t233 = load i64, ptr %l16, !tbaa !24
  store i64 %t233, ptr %l134, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/free:walker", ptr %t234, i32 0, i32 13
  %t237 = load i64, ptr %l2, !tbaa !24
  %t240 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t236, i64 %t237)
  store i64 %t240, ptr %l138
  br label %bb72
bb72:
  %t241 = load i64, ptr %l134, !tbaa !24
  %t242 = load i64, ptr %l138, !tbaa !24
  %t243 = icmp sgt i64 %t241, %t242
  br i1 %t243, label %bb73, label %bb74
bb73:
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l12, !tbaa !24
  %t249 = icmp sle i64 %t245, %t246
  store i1 %t249, ptr %l140, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb75
bb75:
  %t251 = load i1, ptr %l140, !tbaa !21
  br i1 %t251, label %bb76, label %bb77
bb76:
  %t252 = load i64, ptr %l15, !tbaa !24
  store i64 %t252, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/free:walker", ptr %t254, i32 0, i32 52
  %t257 = load i64, ptr %l15, !tbaa !24
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t256, i64 %t257)
  store i64 %t260, ptr %l148
  br label %bb79
bb79:
  %t261 = load i64, ptr %l148, !tbaa !24
  %t262 = icmp sge i64 %t261, 0
  br i1 %t262, label %bb80, label %bb81
bb80:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l2, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  store i1 %t268, ptr %l150, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb82
bb82:
  %t270 = load i1, ptr %l150, !tbaa !21
  br i1 %t270, label %bb83, label %bb84
bb83:
  %t271 = load i64, ptr %l15, !tbaa !24
  store i64 %t271, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t273 = load i64, ptr %l14, !tbaa !24
  %t275 = add i64 %t273, 1
  store i64 %t275, ptr %l14, !tbaa !24
  br label %bb65
bb87:
  %t277 = load i64, ptr %l10, !tbaa !24
  %t279 = icmp sge i64 %t277, 0
  br i1 %t279, label %bb88, label %bb89
bb88:
  store i64 -1, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load i64, ptr %l1, !tbaa !24
  %t284 = load i64, ptr %l2, !tbaa !24
  %t285 = load ptr, ptr %l4, !tbaa !29
  %t290 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %t282, i64 %t283, i64 %t284, ptr %t285)
  store i64 %t290, ptr %l164
  br label %bb91
bb91:
  %t291 = load i64, ptr %l164, !tbaa !24
  store i64 %t291, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, i64, i64, { i64, ptr } }
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca { i64, i64, i64, { i64, ptr } }
  %l50 = alloca ptr
  %l61 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l19
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  store ptr %l5, ptr %l20, !tbaa !29
  %t13 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @compiler_2ffree_2eorig(i64 %t13, i64 %t14)
  store i64 %t17, ptr %l23
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l20, !tbaa !29
  %t19 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t18, i64 %t19)
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t20, i64 %t21, ptr %l5)
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:walker", ptr %t25, i32 0, i32 2
  %t28 = load i1, ptr %t27, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 29
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l30, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l37
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  %t55 = call ptr @compiler_2ffree_2eunwrapped(ptr %v1, ptr %v1, ptr %a2)
  store ptr %t55, ptr %l41
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l41, !tbaa !29
  store ptr %t56, ptr %l8, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l8, !tbaa !29
  %t61 = call { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %s0, ptr %t57, ptr %t58)
  store { i64, i64, i64, { i64, ptr } } %t61, ptr %l44
  br label %bb17
bb17:
  %t62 = load { i64, i64, i64, { i64, ptr } }, ptr %l44
  store { i64, i64, i64, { i64, ptr } } %t62, ptr %l9
  %t63 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 3
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l13, !tbaa !27
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 40
  store ptr %t77, ptr %l50, !tbaa !29
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t98 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t78, i64 %t82, i64 %t83, %"compiler/source:Span" %t84, i64 %t85, i64 %t67, i64 %t70, ptr %t88, ptr null)
  store %"compiler/free:store" %t98, ptr %l61
  br label %bb18
bb18:
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t100 = load %"compiler/free:store", ptr %l61
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t99, %"compiler/free:store" %t100)
  br label %bb19
bb19:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t102 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb20, label %bb21
bb20:
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t111 = load %"compiler/source:Span", ptr %l3
  %t112 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t107, i64 %t108, i64 %t109, i64 %t110, %"compiler/source:Span" %t111, { i64, ptr } %t112)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca i1
  %l32 = alloca i1
  %l34 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l69 = alloca i32
  %l71 = alloca i1
  %l75 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i64
  %l83 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i64
  %l92 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca %"compiler/source:Span"
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i64
  %l108 = alloca ptr
  %l110 = alloca i64
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i1
  %l115 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  store ptr %a1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l15, !tbaa !24
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l17
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l17, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb65
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load i64, ptr %l9, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l22
  br label %bb6
bb6:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l24
  br label %bb7
bb7:
  %t27 = load i64, ptr %l24, !tbaa !24
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 2
  %t37 = load i1, ptr %t36, !tbaa !21
  %t39 = xor i1 %t37, true
  store i1 %t39, ptr %l28, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l28, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  %t42 = load i64, ptr %l10, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eoval(i64 %t42)
  store i64 %t44, ptr %l34
  br label %bb13
bb12:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb14
bb13:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t48 = icmp ne i64 %t46, %t45
  store i1 %t48, ptr %l32, !tbaa !21
  br label %bb14
bb14:
  %t50 = load i1, ptr %l32, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l7, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 26
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 1
  %t57 = load i64, ptr %t56, !tbaa !24
  %t60 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t53, i64 %t57)
  store ptr %t60, ptr %l41
  br label %bb17
bb16:
  br label %bb34
bb17:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2eoval(i64 %t61)
  store i64 %t63, ptr %l43
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l41, !tbaa !29
  %t65 = load i64, ptr %l43, !tbaa !24
  %t66 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t64, i64 %t65)
  store i64 %t66, ptr %l44
  br label %bb19
bb19:
  %t67 = load i64, ptr %l44, !tbaa !24
  %t68 = icmp sgt i64 %t67, 0
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 34
  store i1 true, ptr %t72, !tbaa !21
  %t73 = load ptr, ptr %l7, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 74
  %t76 = load i1, ptr %t75, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb21:
  br label %bb33
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s5, ptr %t78, i64 %t82)
  store { i64, ptr } %t85, ptr %l52
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2eoval(i64 %t86)
  store i64 %t88, ptr %l54
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l7, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/load:Loader", ptr %t95, i32 0, i32 4
  %t98 = load ptr, ptr %t97, !tbaa !29
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t99)
  store ptr %t101, ptr %l60
  br label %bb26
bb26:
  %t102 = load ptr, ptr %l60, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Body", ptr %t102, i32 0, i32 3
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  %t110 = load ptr, ptr %l58, !tbaa !29
  %t113 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s5, ptr %t110, i64 %t105, i64 %t109)
  store { i64, ptr } %t113, ptr %l65
  br label %bb27
bb27:
  %t114 = load i64, ptr %l5, !tbaa !24
  %t115 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t117 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 1
  %t119 = extractvalue { i64, ptr } %t117, 0
  %t120 = add i64 %t116, %t119
  %t121 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t123 = add i64 %t120, %t122
  %t124 = load i64, ptr %l54, !tbaa !24
  %t125 = call i64 @__olang_fmt_i64(ptr null, i64 %t124)
  %t126 = add i64 %t123, %t125
  %t127 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t138 = call i64 @__olang_fmt_i64(ptr null, i64 %t114)
  %t139 = add i64 %t136, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t142)
  call void @olang_textcopy(ptr %t143, ptr %t115, i64 %t116)
  %t144 = getelementptr i8, ptr %t143, i64 %t116
  call void @olang_textcopy(ptr %t144, ptr %t118, i64 %t119)
  %t145 = getelementptr i8, ptr %t144, i64 %t119
  call void @olang_textcopy(ptr %t145, ptr %t121, i64 %t122)
  %t146 = getelementptr i8, ptr %t145, i64 %t122
  %t147 = call i64 @__olang_fmt_i64(ptr %t146, i64 %t124)
  %t148 = getelementptr i8, ptr %t146, i64 %t125
  call void @olang_textcopy(ptr %t148, ptr %t127, i64 %t128)
  %t149 = getelementptr i8, ptr %t148, i64 %t128
  call void @olang_textcopy(ptr %t149, ptr %t131, i64 %t132)
  %t150 = getelementptr i8, ptr %t149, i64 %t132
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t114)
  %t153 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t153, ptr %t140, i64 %t141)
  %t154 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t143, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = call i32 @std_2fio_2ePrintErr(ptr %s5, { i64, ptr } %t162)
  store i32 %t164, ptr %l69
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb29, label %ok.166, !prof !99
ok.166:
  br label %bb28
bb28:
  br label %bb31
bb29:
  %t167 = load i32, ptr %l69, !tbaa !23
  %t168 = ashr i32 %t167, 16
  %t170 = icmp eq i32 %t168, 1
  store i1 %t170, ptr %l71, !tbaa !21
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t171 = load i64, ptr %l11, !tbaa !24
  %t172 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t175 = icmp eq i64 %t171, %t172
  br i1 %t175, label %bb35, label %bb36
bb35:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 2
  %t180 = load i1, ptr %t179, !tbaa !21
  store i1 %t180, ptr %l75, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb37
bb37:
  %t182 = load i1, ptr %l75, !tbaa !21
  br i1 %t182, label %bb38, label %bb39
bb38:
  %t183 = load i64, ptr %l10, !tbaa !24
  %t185 = call i64 @compiler_2ffree_2eoval(i64 %t183)
  store i64 %t185, ptr %l80
  br label %bb40
bb39:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb41
bb40:
  %t187 = load i64, ptr %l80, !tbaa !24
  %t189 = icmp ne i64 %t187, %a6
  store i1 %t189, ptr %l78, !tbaa !21
  br label %bb41
bb41:
  %t191 = load i1, ptr %l78, !tbaa !21
  br i1 %t191, label %bb42, label %bb43
bb42:
  %t192 = load ptr, ptr %l7, !tbaa !29
  store ptr %t192, ptr %l83, !tbaa !29
  %t193 = load i64, ptr %l10, !tbaa !24
  %t195 = call i64 @compiler_2ffree_2eoval(i64 %t193)
  store i64 %t195, ptr %l85
  br label %bb44
bb43:
  br label %bb63
bb44:
  %t196 = load ptr, ptr %l83, !tbaa !29
  %t197 = load i64, ptr %l85, !tbaa !24
  %t198 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t196, i64 %t197)
  store i1 %t198, ptr %l86
  br label %bb45
bb45:
  %t199 = load i1, ptr %l86, !tbaa !21
  br i1 %t199, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t200 = load ptr, ptr %l7, !tbaa !29
  store ptr %t200, ptr %l87, !tbaa !29
  %t201 = load i64, ptr %l10, !tbaa !24
  %t203 = call i64 @compiler_2ffree_2eoval(i64 %t201)
  store i64 %t203, ptr %l89
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t204 = load ptr, ptr %l7, !tbaa !29
  store ptr %t204, ptr %l103, !tbaa !29
  %t205 = load i64, ptr %l10, !tbaa !24
  %t207 = call i64 @compiler_2ffree_2eoval(i64 %t205)
  store i64 %t207, ptr %l105
  br label %bb55
bb48:
  %t208 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t208, ptr %l90, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t209)
  store ptr %t211, ptr %l92
  br label %bb49
bb49:
  %t212 = load ptr, ptr %l92, !tbaa !29
  %t214 = getelementptr %"compiler/typed:Body", ptr %t212, i32 0, i32 3
  %t215 = load i64, ptr %t214, !tbaa !24
  store i64 %t215, ptr %l94, !tbaa !24
  %t216 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t216, ptr %l95
  %t217 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t219 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s9, { i64, ptr } %t217, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t219, ptr %l97
  br label %bb50
bb50:
  %t220 = load i1, ptr %l97, !tbaa !21
  %t221 = xor i1 %t220, true
  br i1 %t221, label %bb51, label %bb52
bb51:
  %t223 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t224 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t227 = extractvalue { i64, ptr } %t223, 1
  %t228 = extractvalue { i64, ptr } %t223, 0
  %t229 = add i64 %t225, %t228
  %t230 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t224, i64 %t225)
  %t234 = getelementptr i8, ptr %t233, i64 %t225
  call void @olang_textcopy(ptr %t234, ptr %t227, i64 %t228)
  %t235 = getelementptr i8, ptr %t234, i64 %t228
  call void @olang_textcopy(ptr %t235, ptr %t230, i64 %t231)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t233, 1
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t240 = extractvalue { i64, ptr } %t237, 1
  %t241 = mul i64 %t239, 1
  %t242 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t241)
  call void @llvm.memcpy.p0.p0.i64(ptr %t242, ptr %t240, i64 %t241, i1 false)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t242, 1
  store { i64, ptr } %t244, ptr %l99, !tbaa !27
  br label %bb53
bb52:
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb53
bb53:
  %t246 = load ptr, ptr %l87, !tbaa !29
  %t247 = load i64, ptr %l89, !tbaa !24
  %t248 = load i64, ptr %l90, !tbaa !24
  %t249 = load i64, ptr %l94, !tbaa !24
  %t250 = load %"compiler/source:Span", ptr %l95
  %t251 = load { i64, ptr }, ptr %l99, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t246, i64 %t247, i64 %t248, i64 %t249, %"compiler/source:Span" %t250, { i64, ptr } %t251)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb62
bb55:
  %t252 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t252, ptr %l106, !tbaa !24
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t253)
  store ptr %t255, ptr %l108
  br label %bb56
bb56:
  %t256 = load ptr, ptr %l108, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Body", ptr %t256, i32 0, i32 3
  %t259 = load i64, ptr %t258, !tbaa !24
  store i64 %t259, ptr %l110, !tbaa !24
  %t260 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t260, ptr %l111
  %t261 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t261, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t263, ptr %l113
  br label %bb57
bb57:
  %t264 = load i1, ptr %l113, !tbaa !21
  %t265 = xor i1 %t264, true
  br i1 %t265, label %bb58, label %bb59
bb58:
  %t267 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t268 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t271 = extractvalue { i64, ptr } %t267, 1
  %t272 = extractvalue { i64, ptr } %t267, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t268, i64 %t269)
  %t278 = getelementptr i8, ptr %t277, i64 %t269
  call void @olang_textcopy(ptr %t278, ptr %t271, i64 %t272)
  %t279 = getelementptr i8, ptr %t278, i64 %t272
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t277, 1
  %t283 = extractvalue { i64, ptr } %t281, 0
  %t284 = extractvalue { i64, ptr } %t281, 1
  %t285 = mul i64 %t283, 1
  %t286 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t285)
  call void @llvm.memcpy.p0.p0.i64(ptr %t286, ptr %t284, i64 %t285, i1 false)
  %t287 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  store { i64, ptr } %t288, ptr %l115, !tbaa !27
  br label %bb60
bb59:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l115, !tbaa !27
  br label %bb60
bb60:
  %t290 = load ptr, ptr %l103, !tbaa !29
  %t291 = load i64, ptr %l105, !tbaa !24
  %t292 = load i64, ptr %l106, !tbaa !24
  %t293 = load i64, ptr %l110, !tbaa !24
  %t294 = load %"compiler/source:Span", ptr %l111
  %t295 = load { i64, ptr }, ptr %l115, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s11, ptr %t290, i64 %t291, i64 %t292, i64 %t293, %"compiler/source:Span" %t294, { i64, ptr } %t295)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t296 = load i64, ptr %l9, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l9, !tbaa !24
  br label %bb1
bb65:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i32
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca ptr
  %l103 = alloca i1
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l115 = alloca i1
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca ptr
  %l131 = alloca i64
  %l132 = alloca i64
  %l136 = alloca i1
  %l140 = alloca i1
  %l141 = alloca i1
  %l147 = alloca %"compiler/typed:Plan"
  %l149 = alloca %"compiler/typed:Plan"
  %l150 = alloca { i64, ptr }
  %l155 = alloca i1
  %l160 = alloca ptr
  %l161 = alloca i1
  %l174 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca ptr
  %l176 = alloca i1
  %l188 = alloca i1
  %l194 = alloca i1
  %l203 = alloca { i64, ptr }
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca i64
  %l220 = alloca ptr
  %l226 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l230 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca i64
  %l240 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca i1
  %l263 = alloca ptr
  %l269 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l271 = alloca ptr
  %l273 = alloca ptr
  %l277 = alloca i32
  %l278 = alloca i64
  %l280 = alloca ptr
  %l281 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca i64
  %l289 = alloca i64
  %l290 = alloca i32
  %l291 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca i32
  %l296 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca i64
  %l301 = alloca ptr
  %l306 = alloca i64
  %l307 = alloca i64
  %l308 = alloca ptr
  %l309 = alloca i1
  %l320 = alloca i1
  %l324 = alloca i64
  %l325 = alloca { i64, ptr }
  %l327 = alloca i64
  %l335 = alloca ptr
  %l336 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l338 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l341 = alloca ptr
  %l343 = alloca i64
  %l344 = alloca %"compiler/source:Span"
  %l345 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l347 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l348 = alloca %"compiler/free:retire"
  %l350 = alloca %"compiler/free:retire"
  %l358 = alloca { i64, ptr }
  %l361 = alloca ptr
  %l364 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l366 = alloca i64
  %l369 = alloca ptr
  %l370 = alloca i1
  %l375 = alloca ptr
  %l377 = alloca ptr
  %l380 = alloca i32
  %l381 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l385 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l389 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l390 = alloca ptr
  %l391 = alloca i1
  %l399 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l404 = alloca ptr
  %l405 = alloca ptr
  %l411 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l413 = alloca i64
  %l414 = alloca ptr
  %l418 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l420 = alloca i64
  %l421 = alloca ptr
  %l422 = alloca i1
  %l435 = alloca { i64, ptr }
  %l446 = alloca ptr
  %l452 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l453 = alloca ptr
  %l454 = alloca i1
  %l467 = alloca { i64, ptr }
  %l482 = alloca { i64, ptr }
  %l485 = alloca ptr
  %l488 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l490 = alloca i64
  %l497 = alloca ptr
  %l498 = alloca ptr
  %l504 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l506 = alloca i64
  %l507 = alloca ptr
  %l508 = alloca i1
  %l517 = alloca ptr
  %l523 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l532 = alloca { i64, ptr }
  %l539 = alloca ptr
  %l553 = alloca { i64, ptr }
  %l556 = alloca ptr
  %l559 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l561 = alloca i64
  %l566 = alloca ptr
  %l567 = alloca i1
  %l574 = alloca ptr
  %l575 = alloca i1
  %l592 = alloca ptr
  %l595 = alloca i64
  %l601 = alloca i1
  %l613 = alloca { i64, ptr }
  %l619 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l625 = alloca i64
  %l628 = alloca ptr
  %l632 = alloca i64
  %l633 = alloca i64
  %l634 = alloca ptr
  %l635 = alloca i1
  %l645 = alloca ptr
  %l646 = alloca i1
  %l662 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l668 = alloca i64
  %l669 = alloca ptr
  %l673 = alloca i64
  %l674 = alloca i64
  %l675 = alloca ptr
  %l676 = alloca i1
  %l689 = alloca { i64, ptr }
  %l692 = alloca ptr
  %l693 = alloca i1
  %l700 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l703 = alloca ptr
  %l708 = alloca i64
  %l709 = alloca i64
  %l710 = alloca ptr
  %l711 = alloca i1
  %l718 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l719 = alloca ptr
  %l721 = alloca i32
  %l722 = alloca i1
  %l724 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t159 = alloca %"compiler/typed:Plan", align 8
  %t162 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l80
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t6 = load ptr, ptr %l81, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l81, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l82, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l82, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27, i32 %t28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l92
  br label %bb7
bb7:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t34 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %t34
  br label %bb365
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t36 = load ptr, ptr %l93, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l93, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l94, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l94, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %t50, ptr %t51)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l101
  br label %bb14
bb14:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  %t56 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  br label %bb365
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t58 = load ptr, ptr %l102, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l102, !tbaa !29
  %t62 = load i64, ptr %t61, !range !{i64 0, i64 18}
  %t64 = icmp eq i64 %t62, 4
  store i1 %t64, ptr %l103, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l103, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t84 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %t78, ptr %t79, i32 %t80)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l113
  br label %bb21
bb21:
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  %t86 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %t86
  br label %bb365
bb22:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t88 = load ptr, ptr %l114, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l114, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 5
  store i1 %t94, ptr %l115, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l115, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l8, !tbaa !23
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb45
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Promote", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t108, ptr %t112)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l125
  br label %bb28
bb28:
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t117 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t117
  %t118 = load ptr, ptr %lp2
  store ptr %t118, ptr %l126, !tbaa !29
  %t119 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = call i64 @compiler_2ffree_2eorig(i64 %t119, i64 %t125)
  store i64 %t128, ptr %l131
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l126, !tbaa !29
  %t130 = load i64, ptr %l131, !tbaa !24
  %t131 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t129, i64 %t130)
  store i64 %t131, ptr %l132
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 2
  %t135 = load i1, ptr %t134, !tbaa !21
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/free:walker", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l140
  br label %bb33
bb32:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb34
bb33:
  %t147 = load i1, ptr %l140, !tbaa !21
  store i1 %t147, ptr %l136, !tbaa !21
  br label %bb34
bb34:
  %t148 = load i1, ptr %l136, !tbaa !21
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 3
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/free:walker", ptr %t155, i32 0, i32 1
  %t158 = load i64, ptr %t157, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t159, ptr %v0, ptr %v0, ptr %t154, i64 %t158)
  call void @llvm.memmove.p0.p0.i64(ptr %l147, ptr %t159, i64 176, i1 false)
  br label %bb37
bb36:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb40
bb37:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t162, ptr %v0, ptr %l147)
  call void @llvm.memmove.p0.p0.i64(ptr %l149, ptr %t162, i64 176, i1 false)
  br label %bb38
bb38:
  %t164 = getelementptr %"compiler/typed:Plan", ptr %l149, i32 0, i32 0
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l150, !tbaa !27
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Promote", ptr %t166, i32 0, i32 1
  %t169 = load i32, ptr %t168, !tbaa !23
  %t171 = sext i32 %t169 to i64
  %t173 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr { i64, [1 x i64] }, ptr %t174, i64 %t171
  %t176 = load { i64, [1 x i64] }, ptr %t175
  %t178 = call i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %t176)
  store i1 %t178, ptr %l155
  br label %bb39
bb39:
  %t179 = load i1, ptr %l155, !tbaa !21
  store i1 %t179, ptr %l141, !tbaa !21
  br label %bb40
bb40:
  %t180 = load i1, ptr %l141, !tbaa !21
  br i1 %t180, label %bb41, label %bb42
bb41:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 0
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t184, i64 %t188)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb365
bb45:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t192 = load ptr, ptr %l160, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb46, label %bb47
bb46:
  %t195 = load ptr, ptr %l160, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 18}
  %t198 = icmp eq i64 %t196, 6
  store i1 %t198, ptr %l161, !tbaa !21
  br label %bb47
bb47:
  %t199 = load i1, ptr %l161, !tbaa !21
  br i1 %t199, label %bb48, label %bb49
bb48:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 0
  %t204 = load %"compiler/source:Span", ptr %t203
  store %"compiler/source:Span" %t204, ptr %l10
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [5 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 1
  %t210 = load i32, ptr %t209
  store i32 %t210, ptr %l11, !tbaa !23
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr { i64, [5 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t214, i32 0, i32 2
  %t216 = load ptr, ptr %t215
  store ptr %t216, ptr %l12, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l12, !tbaa !29
  %t220 = load i32, ptr %l11, !tbaa !23
  %t221 = load %"compiler/source:Span", ptr %l10
  %t226 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %t218, ptr %t219, i32 %t220, %"compiler/source:Span" %t221)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %l174
  br label %bb51
bb51:
  %t227 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l174
  %t228 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %t228
  br label %bb365
bb52:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t230 = load ptr, ptr %l175, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb53, label %bb54
bb53:
  %t233 = load ptr, ptr %l175, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 18}
  %t236 = icmp eq i64 %t234, 7
  store i1 %t236, ptr %l176, !tbaa !21
  br label %bb54
bb54:
  %t237 = load i1, ptr %l176, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t240, i32 0, i32 0
  %t242 = load %"compiler/source:Span", ptr %t241
  store %"compiler/source:Span" %t242, ptr %l13
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 1
  %t248 = load i32, ptr %t247
  store i32 %t248, ptr %l14, !tbaa !23
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr { i64, [5 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t252, i32 0, i32 2
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l15, !tbaa !29
  br label %bb57
bb56:
  br label %bb93
bb57:
  %t256 = load ptr, ptr %l15, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Make", ptr %t256, i32 0, i32 0
  %t259 = load i32, ptr %t258, !range !{i32 0, i32 5}
  %t261 = trunc i64 3 to i32
  %t262 = icmp eq i32 %t259, %t261
  br i1 %t262, label %bb58, label %bb59
bb58:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/free:walker", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/free:Free", ptr %t267, i32 0, i32 23
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/free:walker", ptr %t270, i32 0, i32 1
  %t273 = load i64, ptr %t272, !tbaa !24
  %t276 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t269, i64 %t273)
  store i1 %t276, ptr %l194
  br label %bb60
bb59:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb61
bb60:
  %t277 = load i1, ptr %l194, !tbaa !21
  store i1 %t277, ptr %l188, !tbaa !21
  br label %bb61
bb61:
  %t278 = load i1, ptr %l188, !tbaa !21
  store i1 %t278, ptr %l16, !tbaa !21
  %t279 = load ptr, ptr %l15, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Make", ptr %t279, i32 0, i32 2
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !27
  store { i64, ptr } %t282, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t284 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 0
  store i64 %t286, ptr %l19, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t288 = load i64, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l19, !tbaa !24
  %t292 = icmp slt i64 %t288, %t289
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb64:
  br label %bb65
bb65:
  %t296 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t296, ptr %l203, !tbaa !27
  %t297 = load i64, ptr %l18, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr ptr, ptr %t300, i64 %t297
  %t302 = load ptr, ptr %t301, !tbaa !39
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t308 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t304, ptr %t302)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %l208
  br label %bb66
bb66:
  %t309 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l21
  %t310 = load i1, ptr %l16, !tbaa !21
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb67, label %bb68
bb67:
  %t314 = load ptr, ptr %lp2
  %t317 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s9, ptr %t314, ptr %l21)
  store i64 %t317, ptr %l213
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  %t318 = load i64, ptr %l18, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l18, !tbaa !24
  br label %bb62
bb72:
  %t322 = load ptr, ptr %l15, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Make", ptr %t322, i32 0, i32 3
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = icmp eq ptr %t325, null
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s12
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l220, !tbaa !29
  %t332 = load ptr, ptr %l15, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Make", ptr %t332, i32 0, i32 3
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t337 = icmp eq ptr %t335, null
  br i1 %t337, label %bb75, label %bb76
bb74:
  br label %bb79
bb75:
  call void @__olang_check_failed(ptr @olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88)
  unreachable
bb76:
  br label %bb77
bb77:
  %t339 = load ptr, ptr %l15, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Make", ptr %t339, i32 0, i32 3
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t343 = load ptr, ptr %l220, !tbaa !29
  %t345 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s12, ptr %t343, ptr %t342)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t345, ptr %l226
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb79:
  %t346 = load ptr, ptr %l15, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Make", ptr %t346, i32 0, i32 4
  %t349 = load i32, ptr %t348, !tbaa !23
  %t351 = icmp sge i32 %t349, 0
  br i1 %t351, label %bb80, label %bb81
bb80:
  %t353 = load ptr, ptr %lp2
  store ptr %t353, ptr %l230, !tbaa !29
  %t354 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t355 = load ptr, ptr %l15, !tbaa !29
  %t357 = getelementptr %"compiler/typed:Make", ptr %t355, i32 0, i32 4
  %t358 = load i32, ptr %t357, !tbaa !23
  %t360 = sext i32 %t358 to i64
  %t363 = call i64 @compiler_2ffree_2eorig(i64 %t354, i64 %t360)
  store i64 %t363, ptr %l235
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t364 = load ptr, ptr %l230, !tbaa !29
  %t365 = load i64, ptr %l235, !tbaa !24
  %t366 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t364, i64 %t365)
  store i64 %t366, ptr %l236
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t367 = load ptr, ptr %l15, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Make", ptr %t367, i32 0, i32 0
  %t370 = load i32, ptr %t369, !range !{i32 0, i32 5}
  %t372 = trunc i64 4 to i32
  %t373 = icmp eq i32 %t370, %t372
  br i1 %t373, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l240, !tbaa !21
  br label %bb87
bb86:
  %t375 = load ptr, ptr %l15, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Make", ptr %t375, i32 0, i32 0
  %t378 = load i32, ptr %t377, !range !{i32 0, i32 5}
  %t380 = trunc i64 3 to i32
  %t381 = icmp eq i32 %t378, %t380
  store i1 %t381, ptr %l240, !tbaa !21
  br label %bb87
bb87:
  %t383 = load i1, ptr %l240, !tbaa !21
  br i1 %t383, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l14, !tbaa !23
  %t386 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s14, ptr %t384, i32 %t385, %"compiler/source:Span" %t386, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb91:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l15, !tbaa !29
  %t392 = load i32, ptr %l14, !tbaa !23
  %t393 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %t390, ptr %t391, i32 %t392, %"compiler/source:Span" %t393)
  br label %bb92
bb92:
  br label %bb365
bb93:
  %t398 = load ptr, ptr %l1, !tbaa !29
  store ptr %t398, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t399 = load ptr, ptr %l251, !tbaa !29
  %t400 = icmp ne ptr %t399, null
  br i1 %t400, label %bb94, label %bb95
bb94:
  %t402 = load ptr, ptr %l251, !tbaa !29
  %t403 = load i64, ptr %t402, !range !{i64 0, i64 18}
  %t405 = icmp eq i64 %t403, 8
  store i1 %t405, ptr %l252, !tbaa !21
  br label %bb95
bb95:
  %t406 = load i1, ptr %l252, !tbaa !21
  br i1 %t406, label %bb96, label %bb97
bb96:
  %t407 = load ptr, ptr %l1, !tbaa !29
  %t409 = getelementptr { i64, [5 x i64] }, ptr %t407, i32 0, i32 1
  %t410 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t409, i32 0, i32 1
  %t411 = load i32, ptr %t410
  store i32 %t411, ptr %l22, !tbaa !23
  %t413 = load ptr, ptr %l1, !tbaa !29
  %t415 = getelementptr { i64, [5 x i64] }, ptr %t413, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t415, i32 0, i32 2
  %t417 = load ptr, ptr %t416
  store ptr %t417, ptr %l23, !tbaa !29
  br label %bb98
bb97:
  br label %bb124
bb98:
  %t419 = load ptr, ptr %l23, !tbaa !29
  %t421 = getelementptr %"compiler/typed:Collect", ptr %t419, i32 0, i32 0
  %t422 = load ptr, ptr %t421, !tbaa !29
  %t424 = icmp eq ptr %t422, null
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s16
  %t428 = load ptr, ptr %l0, !tbaa !29
  store ptr %t428, ptr %l263, !tbaa !29
  %t429 = load ptr, ptr %l23, !tbaa !29
  %t431 = getelementptr %"compiler/typed:Collect", ptr %t429, i32 0, i32 0
  %t432 = load ptr, ptr %t431, !tbaa !29
  %t434 = icmp eq ptr %t432, null
  br i1 %t434, label %bb101, label %bb102
bb100:
  br label %bb105
bb101:
  call void @__olang_check_failed(ptr @olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7)
  unreachable
bb102:
  br label %bb103
bb103:
  %t436 = load ptr, ptr %l23, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Collect", ptr %t436, i32 0, i32 0
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t440 = load ptr, ptr %l263, !tbaa !29
  %t442 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s16, ptr %t440, ptr %t439)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t442, ptr %l269
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s16)
  br label %bb105
bb105:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/free:walker", ptr %t443, i32 0, i32 10
  store ptr %t445, ptr %l271, !tbaa !29
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/free:walker", ptr %t446, i32 0, i32 0
  %t449 = load ptr, ptr %t448, !tbaa !29
  store ptr %t449, ptr %l273, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/free:walker", ptr %t450, i32 0, i32 0
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t454 = load i32, ptr %l22, !tbaa !23
  %t457 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t453, i32 %t454)
  store i32 %t457, ptr %l277
  br label %bb106
bb106:
  %t458 = load ptr, ptr %l273, !tbaa !29
  %t459 = load i32, ptr %l277, !tbaa !23
  %t460 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t458, i32 %t459, i64 -1)
  store i64 %t460, ptr %l278
  br label %bb107
bb107:
  %t461 = load ptr, ptr %l271, !tbaa !29
  %t462 = load i64, ptr %l278, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t461, i64 %t462)
  br label %bb108
bb108:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/free:walker", ptr %t463, i32 0, i32 33
  store ptr %t465, ptr %l280, !tbaa !29
  %t466 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t466, ptr %l281
  br label %bb109
bb109:
  %t467 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l281
  %t468 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t467, ptr %t468
  %t469 = load ptr, ptr %l280, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t469, ptr %t468)
  br label %bb110
bb110:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t472 = load ptr, ptr %l23, !tbaa !29
  %t474 = getelementptr %"compiler/typed:Collect", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t471, ptr %t475)
  br label %bb111
bb111:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/free:walker", ptr %t478, i32 0, i32 10
  %t482 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t480)
  %t483 = extractvalue { i32, i64 } %t482, 1
  %t484 = extractvalue { i32, i64 } %t482, 0
  store i32 %t484, ptr %l290
  %t485 = icmp ne i32 %t484, 0
  br i1 %t485, label %bb113, label %ok.486, !prof !99
ok.486:
  store i64 %t483, ptr %l289
  br label %bb112
bb112:
  %t487 = load i64, ptr %l289, !tbaa !24
  store i64 %t487, ptr %l286, !tbaa !24
  br label %bb115
bb113:
  br label %bb114
bb114:
  call void @__olang_ert_req_clear()
  br label %bb115
bb115:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/free:walker", ptr %t488, i32 0, i32 33
  %t492 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v0, ptr %t490)
  %t493 = extractvalue { i32, ptr } %t492, 1
  %t494 = extractvalue { i32, ptr } %t492, 0
  store i32 %t494, ptr %l295
  %t495 = icmp ne i32 %t494, 0
  br i1 %t495, label %bb117, label %ok.496, !prof !99
ok.496:
  store ptr %t493, ptr %l294
  br label %bb116
bb116:
  %t497 = load ptr, ptr %l294, !tbaa !29
  store ptr %t497, ptr %l291, !tbaa !29
  br label %bb120
bb117:
  br label %bb118
bb118:
  call void @__olang_ert_req_clear()
  %t498 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l296
  br label %bb119
bb119:
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l296
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %t500
  store ptr %t500, ptr %l291, !tbaa !29
  br label %bb120
bb120:
  %t502 = load ptr, ptr %l291, !tbaa !29
  %t503 = load ptr, ptr %lp2
  %t507 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t503, ptr %t502)
  store i64 %t507, ptr %l300
  br label %bb121
bb121:
  %t508 = load ptr, ptr %lp2
  store ptr %t508, ptr %l301, !tbaa !29
  %t509 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t510 = load ptr, ptr %l23, !tbaa !29
  %t512 = getelementptr %"compiler/typed:Collect", ptr %t510, i32 0, i32 2
  %t513 = load i32, ptr %t512, !tbaa !23
  %t515 = sext i32 %t513 to i64
  %t518 = call i64 @compiler_2ffree_2eorig(i64 %t509, i64 %t515)
  store i64 %t518, ptr %l306
  br label %bb122
bb122:
  %t519 = load ptr, ptr %l301, !tbaa !29
  %t520 = load i64, ptr %l306, !tbaa !24
  %t521 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t519, i64 %t520)
  store i64 %t521, ptr %l307
  br label %bb123
bb123:
  br label %bb365
bb124:
  %t522 = load ptr, ptr %l1, !tbaa !29
  store ptr %t522, ptr %l308, !tbaa !29
  store i1 false, ptr %l309, !tbaa !21
  %t523 = load ptr, ptr %l308, !tbaa !29
  %t524 = icmp ne ptr %t523, null
  br i1 %t524, label %bb125, label %bb126
bb125:
  %t526 = load ptr, ptr %l308, !tbaa !29
  %t527 = load i64, ptr %t526, !range !{i64 0, i64 18}
  %t529 = icmp eq i64 %t527, 9
  store i1 %t529, ptr %l309, !tbaa !21
  br label %bb126
bb126:
  %t530 = load i1, ptr %l309, !tbaa !21
  br i1 %t530, label %bb127, label %bb128
bb127:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr { i64, [5 x i64] }, ptr %t531, i32 0, i32 1
  %t534 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t533, i32 0, i32 0
  %t535 = load %"compiler/source:Span", ptr %t534
  store %"compiler/source:Span" %t535, ptr %l25
  %t537 = load ptr, ptr %l1, !tbaa !29
  %t539 = getelementptr { i64, [5 x i64] }, ptr %t537, i32 0, i32 1
  %t540 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t539, i32 0, i32 2
  %t541 = load i32, ptr %t540, !range !{i32 0, i32 43}
  store i32 %t541, ptr %l26
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 1
  %t546 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t545, i32 0, i32 4
  %t547 = load { i64, ptr }, ptr %t546
  store { i64, ptr } %t547, ptr %l27, !tbaa !27
  br label %bb129
bb128:
  br label %bb157
bb129:
  %t549 = load i32, ptr %l26, !range !{i32 0, i32 43}
  %t551 = trunc i64 29 to i32
  %t552 = icmp eq i32 %t549, %t551
  br i1 %t552, label %bb130, label %bb131
bb130:
  %t554 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t556 = extractvalue { i64, ptr } %t554, 0
  %t558 = icmp eq i64 %t556, 1
  store i1 %t558, ptr %l320, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb132
bb132:
  %t560 = load i1, ptr %l320, !tbaa !21
  br i1 %t560, label %bb133, label %bb134
bb133:
  %t561 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t561, ptr %l325, !tbaa !27
  %t562 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr ptr, ptr %t563, i64 0
  %t565 = load ptr, ptr %t564, !tbaa !39
  %t567 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t565)
  store i64 %t567, ptr %l327
  br label %bb135
bb134:
  store i64 -1, ptr %l324, !tbaa !24
  br label %bb136
bb135:
  %t568 = load i64, ptr %l327, !tbaa !24
  store i64 %t568, ptr %l324, !tbaa !24
  br label %bb136
bb136:
  %t569 = load i64, ptr %l324, !tbaa !24
  store i64 %t569, ptr %l28, !tbaa !24
  %t570 = load i64, ptr %l28, !tbaa !24
  %t572 = icmp sge i64 %t570, 0
  br i1 %t572, label %bb137, label %bb138
bb137:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/free:walker", ptr %t574, i32 0, i32 2
  %t577 = load i1, ptr %t576, !tbaa !21
  br i1 %t577, label %bb139, label %bb140
bb138:
  %t579 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t579, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t581 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 0
  store i64 %t583, ptr %l32, !tbaa !24
  br label %bb148
bb139:
  store %olang.scope zeroinitializer, ptr %s20
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/free:walker", ptr %t585, i32 0, i32 3
  %t588 = load i64, ptr %l28, !tbaa !24
  %t591 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t587, i64 %t588)
  store ptr %t591, ptr %l335
  br label %bb141
bb140:
  br label %bb147
bb141:
  %t592 = load ptr, ptr %l335, !tbaa !29
  %t593 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t592
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t593, ptr %l336
  %t595 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s20, ptr %l336)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t595, ptr %l338
  br label %bb142
bb142:
  %t596 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l338
  %t597 = load ptr, ptr %l0, !tbaa !29
  %t599 = getelementptr %"compiler/free:walker", ptr %t597, i32 0, i32 0
  %t600 = load ptr, ptr %t599, !tbaa !29
  %t602 = getelementptr %"compiler/free:Free", ptr %t600, i32 0, i32 13
  store ptr %t602, ptr %l341, !tbaa !29
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t605 = getelementptr %"compiler/free:walker", ptr %t603, i32 0, i32 1
  %t606 = load i64, ptr %t605, !tbaa !24
  store i64 %t606, ptr %l343, !tbaa !24
  %t607 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t607, ptr %l344
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l345
  %t610 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s20, ptr %l345)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t610, ptr %l347
  br label %bb143
bb143:
  %t611 = load i64, ptr %l343, !tbaa !24
  %t612 = load %"compiler/source:Span", ptr %l344
  %t613 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l347
  %t614 = call %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %s20, ptr %s20, i64 %t611, %"compiler/source:Span" %t612, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t613)
  store %"compiler/free:retire" %t614, ptr %l348
  br label %bb144
bb144:
  %t616 = call %"compiler/free:retire" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %s20, ptr %l348)
  store %"compiler/free:retire" %t616, ptr %l350
  br label %bb145
bb145:
  %t617 = load ptr, ptr %l341, !tbaa !29
  %t618 = load %"compiler/free:retire", ptr %l350
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ePush_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %s20, ptr %t617, %"compiler/free:retire" %t618)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s20)
  br label %bb147
bb147:
  br label %bb156
bb148:
  store %olang.scope zeroinitializer, ptr %s23
  %t619 = load i64, ptr %l31, !tbaa !24
  %t620 = load i64, ptr %l32, !tbaa !24
  %t623 = icmp slt i64 %t619, %t620
  %t625 = xor i1 %t623, true
  br i1 %t625, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s23)
  br label %bb155
bb150:
  br label %bb151
bb151:
  %t627 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t627, ptr %l358, !tbaa !27
  %t628 = load i64, ptr %l31, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l358, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr ptr, ptr %t631, i64 %t628
  %t633 = load ptr, ptr %t632, !tbaa !39
  %t635 = load ptr, ptr %lp2
  store ptr %t635, ptr %l361, !tbaa !29
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t640 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s23, ptr %t636, ptr %t633)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t640, ptr %l364
  br label %bb152
bb152:
  %t641 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l364
  %t642 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t641, ptr %t642
  %t643 = load ptr, ptr %l361, !tbaa !29
  %t645 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s23, ptr %t643, ptr %t642)
  store i64 %t645, ptr %l366
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s23)
  br label %bb154
bb154:
  %t646 = load i64, ptr %l31, !tbaa !24
  %t648 = add i64 %t646, 1
  store i64 %t648, ptr %l31, !tbaa !24
  br label %bb148
bb155:
  br label %bb156
bb156:
  br label %bb365
bb157:
  %t650 = load ptr, ptr %l1, !tbaa !29
  store ptr %t650, ptr %l369, !tbaa !29
  store i1 false, ptr %l370, !tbaa !21
  %t651 = load ptr, ptr %l369, !tbaa !29
  %t652 = icmp ne ptr %t651, null
  br i1 %t652, label %bb158, label %bb159
bb158:
  %t654 = load ptr, ptr %l369, !tbaa !29
  %t655 = load i64, ptr %t654, !range !{i64 0, i64 18}
  %t657 = icmp eq i64 %t655, 10
  store i1 %t657, ptr %l370, !tbaa !21
  br label %bb159
bb159:
  %t658 = load i1, ptr %l370, !tbaa !21
  br i1 %t658, label %bb160, label %bb161
bb160:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t661 = getelementptr { i64, [5 x i64] }, ptr %t659, i32 0, i32 1
  %t662 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t661, i32 0, i32 2
  %t663 = load ptr, ptr %t662
  store ptr %t663, ptr %l34, !tbaa !29
  br label %bb162
bb161:
  br label %bb167
bb162:
  store %olang.scope zeroinitializer, ptr %s25
  %t665 = load ptr, ptr %l0, !tbaa !29
  store ptr %t665, ptr %l375, !tbaa !29
  %t666 = load ptr, ptr %l34, !tbaa !29
  %t668 = getelementptr %"compiler/typed:Slice", ptr %t666, i32 0, i32 0
  %t669 = load ptr, ptr %t668, !tbaa !29
  store ptr %t669, ptr %l377, !tbaa !29
  %t670 = load ptr, ptr %l34, !tbaa !29
  %t672 = getelementptr %"compiler/typed:Slice", ptr %t670, i32 0, i32 0
  %t673 = load ptr, ptr %t672, !tbaa !29
  %t675 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t673)
  store i32 %t675, ptr %l380
  br label %bb163
bb163:
  %t676 = load ptr, ptr %l375, !tbaa !29
  %t677 = load ptr, ptr %l377, !tbaa !29
  %t678 = load i32, ptr %l380, !tbaa !23
  %t679 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t676, ptr %t677, i32 %t678)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t679, ptr %l381
  br label %bb164
bb164:
  %t680 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l381
  %t681 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t680, ptr %t681
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load ptr, ptr %l34, !tbaa !29
  %t685 = getelementptr %"compiler/typed:Slice", ptr %t683, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !29
  %t689 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s25, ptr %t682, ptr %t686)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t689, ptr %l385
  br label %bb165
bb165:
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l34, !tbaa !29
  %t693 = getelementptr %"compiler/typed:Slice", ptr %t691, i32 0, i32 2
  %t694 = load ptr, ptr %t693, !tbaa !29
  %t697 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s25, ptr %t690, ptr %t694)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t697, ptr %l389
  br label %bb166
bb166:
  call void @__olang_scope_close(ptr %s25)
  br label %bb365
bb167:
  %t698 = load ptr, ptr %l1, !tbaa !29
  store ptr %t698, ptr %l390, !tbaa !29
  store i1 false, ptr %l391, !tbaa !21
  %t699 = load ptr, ptr %l390, !tbaa !29
  %t700 = icmp ne ptr %t699, null
  br i1 %t700, label %bb168, label %bb169
bb168:
  %t702 = load ptr, ptr %l390, !tbaa !29
  %t703 = load i64, ptr %t702, !range !{i64 0, i64 18}
  %t705 = icmp eq i64 %t703, 11
  store i1 %t705, ptr %l391, !tbaa !21
  br label %bb169
bb169:
  %t706 = load i1, ptr %l391, !tbaa !21
  br i1 %t706, label %bb170, label %bb171
bb170:
  %t707 = load ptr, ptr %l1, !tbaa !29
  %t709 = getelementptr { i64, [5 x i64] }, ptr %t707, i32 0, i32 1
  %t710 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t709, i32 0, i32 2
  %t711 = load ptr, ptr %t710
  store ptr %t711, ptr %l35, !tbaa !29
  br label %bb172
bb171:
  br label %bb184
bb172:
  store %olang.scope zeroinitializer, ptr %s26
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load ptr, ptr %l35, !tbaa !29
  %t716 = getelementptr %"compiler/typed:Cond", ptr %t714, i32 0, i32 0
  %t717 = load ptr, ptr %t716, !tbaa !29
  %t720 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s26, ptr %t713, ptr %t717)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t720, ptr %l399
  br label %bb173
bb173:
  %t721 = load ptr, ptr %l35, !tbaa !29
  %t723 = getelementptr %"compiler/typed:Cond", ptr %t721, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = icmp eq ptr %t724, null
  %t728 = xor i1 %t726, true
  br i1 %t728, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s27
  %t730 = load ptr, ptr %lp2
  store ptr %t730, ptr %l404, !tbaa !29
  %t731 = load ptr, ptr %l0, !tbaa !29
  store ptr %t731, ptr %l405, !tbaa !29
  %t732 = load ptr, ptr %l35, !tbaa !29
  %t734 = getelementptr %"compiler/typed:Cond", ptr %t732, i32 0, i32 1
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = icmp eq ptr %t735, null
  br i1 %t737, label %bb176, label %bb177
bb175:
  br label %bb181
bb176:
  call void @__olang_check_failed(ptr @olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6)
  unreachable
bb177:
  br label %bb178
bb178:
  %t739 = load ptr, ptr %l35, !tbaa !29
  %t741 = getelementptr %"compiler/typed:Cond", ptr %t739, i32 0, i32 1
  %t742 = load ptr, ptr %t741, !tbaa !29
  %t743 = load ptr, ptr %l405, !tbaa !29
  %t745 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s27, ptr %t743, ptr %t742)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t745, ptr %l411
  br label %bb179
bb179:
  %t746 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l411
  %t747 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t746, ptr %t747
  %t748 = load ptr, ptr %l404, !tbaa !29
  %t750 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s27, ptr %t748, ptr %t747)
  store i64 %t750, ptr %l413
  br label %bb180
bb180:
  call void @__olang_scope_close(ptr %s27)
  br label %bb181
bb181:
  %t751 = load ptr, ptr %lp2
  store ptr %t751, ptr %l414, !tbaa !29
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t753 = load ptr, ptr %l35, !tbaa !29
  %t755 = getelementptr %"compiler/typed:Cond", ptr %t753, i32 0, i32 2
  %t756 = load ptr, ptr %t755, !tbaa !29
  %t759 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s26, ptr %t752, ptr %t756)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t759, ptr %l418
  br label %bb182
bb182:
  %t760 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l418
  %t761 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t760, ptr %t761
  %t762 = load ptr, ptr %l414, !tbaa !29
  %t764 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s26, ptr %t762, ptr %t761)
  store i64 %t764, ptr %l420
  br label %bb183
bb183:
  call void @__olang_scope_close(ptr %s26)
  br label %bb365
bb184:
  %t765 = load ptr, ptr %l1, !tbaa !29
  store ptr %t765, ptr %l421, !tbaa !29
  store i1 false, ptr %l422, !tbaa !21
  %t766 = load ptr, ptr %l421, !tbaa !29
  %t767 = icmp ne ptr %t766, null
  br i1 %t767, label %bb185, label %bb186
bb185:
  %t769 = load ptr, ptr %l421, !tbaa !29
  %t770 = load i64, ptr %t769, !range !{i64 0, i64 18}
  %t772 = icmp eq i64 %t770, 12
  store i1 %t772, ptr %l422, !tbaa !21
  br label %bb186
bb186:
  %t773 = load i1, ptr %l422, !tbaa !21
  br i1 %t773, label %bb187, label %bb188
bb187:
  %t774 = load ptr, ptr %l1, !tbaa !29
  %t776 = getelementptr { i64, [5 x i64] }, ptr %t774, i32 0, i32 1
  %t777 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t776, i32 0, i32 2
  %t778 = load ptr, ptr %t777
  store ptr %t778, ptr %l36, !tbaa !29
  br label %bb189
bb188:
  br label %bb204
bb189:
  %t780 = load ptr, ptr %l36, !tbaa !29
  %t782 = getelementptr %"compiler/typed:Seq", ptr %t780, i32 0, i32 0
  %t783 = load { i64, ptr }, ptr %t782, !tbaa !27
  store { i64, ptr } %t783, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t785 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t787 = extractvalue { i64, ptr } %t785, 0
  store i64 %t787, ptr %l39, !tbaa !24
  br label %bb190
bb190:
  %t789 = load i64, ptr %l38, !tbaa !24
  %t790 = load i64, ptr %l39, !tbaa !24
  %t793 = icmp slt i64 %t789, %t790
  %t795 = xor i1 %t793, true
  br i1 %t795, label %bb191, label %bb192
bb191:
  br label %bb196
bb192:
  br label %bb193
bb193:
  %t797 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t797, ptr %l435, !tbaa !27
  %t798 = load i64, ptr %l38, !tbaa !24
  %t800 = getelementptr { i64, ptr }, ptr %l435, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !27
  %t802 = getelementptr ptr, ptr %t801, i64 %t798
  %t803 = load ptr, ptr %t802, !tbaa !39
  %t805 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t805, ptr %t803)
  br label %bb194
bb194:
  br label %bb195
bb195:
  %t809 = load i64, ptr %l38, !tbaa !24
  %t811 = add i64 %t809, 1
  store i64 %t811, ptr %l38, !tbaa !24
  br label %bb190
bb196:
  %t813 = load ptr, ptr %l36, !tbaa !29
  %t815 = getelementptr %"compiler/typed:Seq", ptr %t813, i32 0, i32 1
  %t816 = load ptr, ptr %t815, !tbaa !29
  %t818 = icmp eq ptr %t816, null
  %t820 = xor i1 %t818, true
  br i1 %t820, label %bb197, label %bb198
bb197:
  %t822 = load ptr, ptr %l0, !tbaa !29
  store ptr %t822, ptr %l446, !tbaa !29
  %t823 = load ptr, ptr %l36, !tbaa !29
  %t825 = getelementptr %"compiler/typed:Seq", ptr %t823, i32 0, i32 1
  %t826 = load ptr, ptr %t825, !tbaa !29
  %t828 = icmp eq ptr %t826, null
  br i1 %t828, label %bb199, label %bb200
bb198:
  br label %bb203
bb199:
  call void @__olang_check_failed(ptr @olang_loc_5a2a443e2f2f03b9_3064adab7524445d)
  unreachable
bb200:
  br label %bb201
bb201:
  %t830 = load ptr, ptr %l36, !tbaa !29
  %t832 = getelementptr %"compiler/typed:Seq", ptr %t830, i32 0, i32 1
  %t833 = load ptr, ptr %t832, !tbaa !29
  %t834 = load ptr, ptr %l446, !tbaa !29
  %t836 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t834, ptr %t833)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t836, ptr %l452
  br label %bb202
bb202:
  %t837 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l452
  %t838 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t837, ptr %t838
  br label %bb203
bb203:
  br label %bb365
bb204:
  %t839 = load ptr, ptr %l1, !tbaa !29
  store ptr %t839, ptr %l453, !tbaa !29
  store i1 false, ptr %l454, !tbaa !21
  %t840 = load ptr, ptr %l453, !tbaa !29
  %t841 = icmp ne ptr %t840, null
  br i1 %t841, label %bb205, label %bb206
bb205:
  %t843 = load ptr, ptr %l453, !tbaa !29
  %t844 = load i64, ptr %t843, !range !{i64 0, i64 18}
  %t846 = icmp eq i64 %t844, 13
  store i1 %t846, ptr %l454, !tbaa !21
  br label %bb206
bb206:
  %t847 = load i1, ptr %l454, !tbaa !21
  br i1 %t847, label %bb207, label %bb208
bb207:
  %t848 = load ptr, ptr %l1, !tbaa !29
  %t850 = getelementptr { i64, [5 x i64] }, ptr %t848, i32 0, i32 1
  %t851 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t850, i32 0, i32 2
  %t852 = load ptr, ptr %t851
  store ptr %t852, ptr %l41, !tbaa !29
  br label %bb209
bb208:
  br label %bb233
bb209:
  %t854 = load ptr, ptr %l41, !tbaa !29
  %t856 = getelementptr %"compiler/typed:Match", ptr %t854, i32 0, i32 0
  %t857 = load { i64, ptr }, ptr %t856, !tbaa !27
  store { i64, ptr } %t857, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t859 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t859, 0
  store i64 %t861, ptr %l44, !tbaa !24
  br label %bb210
bb210:
  %t863 = load i64, ptr %l43, !tbaa !24
  %t864 = load i64, ptr %l44, !tbaa !24
  %t867 = icmp slt i64 %t863, %t864
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb211, label %bb212
bb211:
  br label %bb216
bb212:
  br label %bb213
bb213:
  %t871 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t871, ptr %l467, !tbaa !27
  %t872 = load i64, ptr %l43, !tbaa !24
  %t874 = getelementptr { i64, ptr }, ptr %l467, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !27
  %t876 = getelementptr ptr, ptr %t875, i64 %t872
  %t877 = load ptr, ptr %t876, !tbaa !39
  %t879 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t879, ptr %t877)
  br label %bb214
bb214:
  br label %bb215
bb215:
  %t883 = load i64, ptr %l43, !tbaa !24
  %t885 = add i64 %t883, 1
  store i64 %t885, ptr %l43, !tbaa !24
  br label %bb210
bb216:
  %t887 = load ptr, ptr %l41, !tbaa !29
  %t889 = getelementptr %"compiler/typed:Match", ptr %t887, i32 0, i32 1
  %t890 = load { i64, ptr }, ptr %t889, !tbaa !27
  store { i64, ptr } %t890, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t892 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t894 = extractvalue { i64, ptr } %t892, 0
  store i64 %t894, ptr %l48, !tbaa !24
  br label %bb217
bb217:
  store %olang.scope zeroinitializer, ptr %s38
  %t896 = load i64, ptr %l47, !tbaa !24
  %t897 = load i64, ptr %l48, !tbaa !24
  %t900 = icmp slt i64 %t896, %t897
  %t902 = xor i1 %t900, true
  br i1 %t902, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s38)
  br label %bb224
bb219:
  br label %bb220
bb220:
  %t904 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t904, ptr %l482, !tbaa !27
  %t905 = load i64, ptr %l47, !tbaa !24
  %t907 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t908 = load ptr, ptr %t907, !tbaa !27
  %t909 = getelementptr ptr, ptr %t908, i64 %t905
  %t910 = load ptr, ptr %t909, !tbaa !39
  %t912 = load ptr, ptr %lp2
  store ptr %t912, ptr %l485, !tbaa !29
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t917 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s38, ptr %t913, ptr %t910)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t917, ptr %l488
  br label %bb221
bb221:
  %t918 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l488
  %t919 = call ptr @__olang_scope_alloc_a(ptr %s38, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t918, ptr %t919
  %t920 = load ptr, ptr %l485, !tbaa !29
  %t922 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s38, ptr %t920, ptr %t919)
  store i64 %t922, ptr %l490
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s38)
  br label %bb223
bb223:
  %t923 = load i64, ptr %l47, !tbaa !24
  %t925 = add i64 %t923, 1
  store i64 %t925, ptr %l47, !tbaa !24
  br label %bb217
bb224:
  %t927 = load ptr, ptr %l41, !tbaa !29
  %t929 = getelementptr %"compiler/typed:Match", ptr %t927, i32 0, i32 2
  %t930 = load ptr, ptr %t929, !tbaa !29
  %t932 = icmp eq ptr %t930, null
  %t934 = xor i1 %t932, true
  br i1 %t934, label %bb225, label %bb226
bb225:
  store %olang.scope zeroinitializer, ptr %s40
  %t936 = load ptr, ptr %lp2
  store ptr %t936, ptr %l497, !tbaa !29
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l498, !tbaa !29
  %t938 = load ptr, ptr %l41, !tbaa !29
  %t940 = getelementptr %"compiler/typed:Match", ptr %t938, i32 0, i32 2
  %t941 = load ptr, ptr %t940, !tbaa !29
  %t943 = icmp eq ptr %t941, null
  br i1 %t943, label %bb227, label %bb228
bb226:
  br label %bb232
bb227:
  call void @__olang_check_failed(ptr @olang_loc_f2df24d87159f740_3aba0f93d819cd0c)
  unreachable
bb228:
  br label %bb229
bb229:
  %t945 = load ptr, ptr %l41, !tbaa !29
  %t947 = getelementptr %"compiler/typed:Match", ptr %t945, i32 0, i32 2
  %t948 = load ptr, ptr %t947, !tbaa !29
  %t949 = load ptr, ptr %l498, !tbaa !29
  %t951 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s40, ptr %t949, ptr %t948)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t951, ptr %l504
  br label %bb230
bb230:
  %t952 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l504
  %t953 = call ptr @__olang_scope_alloc_a(ptr %s40, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t952, ptr %t953
  %t954 = load ptr, ptr %l497, !tbaa !29
  %t956 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s40, ptr %t954, ptr %t953)
  store i64 %t956, ptr %l506
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s40)
  br label %bb232
bb232:
  br label %bb365
bb233:
  %t957 = load ptr, ptr %l1, !tbaa !29
  store ptr %t957, ptr %l507, !tbaa !29
  store i1 false, ptr %l508, !tbaa !21
  %t958 = load ptr, ptr %l507, !tbaa !29
  %t959 = icmp ne ptr %t958, null
  br i1 %t959, label %bb234, label %bb235
bb234:
  %t961 = load ptr, ptr %l507, !tbaa !29
  %t962 = load i64, ptr %t961, !range !{i64 0, i64 18}
  %t964 = icmp eq i64 %t962, 14
  store i1 %t964, ptr %l508, !tbaa !21
  br label %bb235
bb235:
  %t965 = load i1, ptr %l508, !tbaa !21
  br i1 %t965, label %bb236, label %bb237
bb236:
  %t966 = load ptr, ptr %l1, !tbaa !29
  %t968 = getelementptr { i64, [5 x i64] }, ptr %t966, i32 0, i32 1
  %t969 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t968, i32 0, i32 2
  %t970 = load ptr, ptr %t969
  store ptr %t970, ptr %l50, !tbaa !29
  br label %bb238
bb237:
  br label %bb267
bb238:
  %t972 = load ptr, ptr %l50, !tbaa !29
  %t974 = getelementptr %"compiler/typed:Try", ptr %t972, i32 0, i32 0
  %t975 = load ptr, ptr %t974, !tbaa !29
  %t977 = icmp eq ptr %t975, null
  %t979 = xor i1 %t977, true
  br i1 %t979, label %bb239, label %bb240
bb239:
  %t981 = load ptr, ptr %l0, !tbaa !29
  store ptr %t981, ptr %l517, !tbaa !29
  %t982 = load ptr, ptr %l50, !tbaa !29
  %t984 = getelementptr %"compiler/typed:Try", ptr %t982, i32 0, i32 0
  %t985 = load ptr, ptr %t984, !tbaa !29
  %t987 = icmp eq ptr %t985, null
  br i1 %t987, label %bb241, label %bb242
bb240:
  br label %bb245
bb241:
  call void @__olang_check_failed(ptr @olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b)
  unreachable
bb242:
  br label %bb243
bb243:
  %t989 = load ptr, ptr %l50, !tbaa !29
  %t991 = getelementptr %"compiler/typed:Try", ptr %t989, i32 0, i32 0
  %t992 = load ptr, ptr %t991, !tbaa !29
  %t993 = load ptr, ptr %l517, !tbaa !29
  %t995 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t993, ptr %t992)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t995, ptr %l523
  br label %bb244
bb244:
  %t996 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l523
  %t997 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t996, ptr %t997
  br label %bb245
bb245:
  %t998 = load ptr, ptr %l50, !tbaa !29
  %t1000 = getelementptr %"compiler/typed:Try", ptr %t998, i32 0, i32 1
  %t1001 = load { i64, ptr }, ptr %t1000, !tbaa !27
  store { i64, ptr } %t1001, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t1003 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t1005 = extractvalue { i64, ptr } %t1003, 0
  store i64 %t1005, ptr %l53, !tbaa !24
  br label %bb246
bb246:
  %t1007 = load i64, ptr %l52, !tbaa !24
  %t1008 = load i64, ptr %l53, !tbaa !24
  %t1011 = icmp slt i64 %t1007, %t1008
  %t1013 = xor i1 %t1011, true
  br i1 %t1013, label %bb247, label %bb248
bb247:
  br label %bb266
bb248:
  br label %bb249
bb249:
  %t1015 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t1015, ptr %l532, !tbaa !27
  %t1016 = load i64, ptr %l52, !tbaa !24
  %t1018 = getelementptr { i64, ptr }, ptr %l532, i32 0, i32 1
  %t1019 = load ptr, ptr %t1018, !tbaa !27
  %t1020 = getelementptr ptr, ptr %t1019, i64 %t1016
  %t1021 = load ptr, ptr %t1020, !tbaa !39
  store ptr %t1021, ptr %l54, !tbaa !29
  %t1023 = load ptr, ptr %l54, !tbaa !29
  %t1025 = getelementptr %"compiler/typed:Clause", ptr %t1023, i32 0, i32 3
  %t1026 = load ptr, ptr %t1025, !tbaa !29
  %t1028 = icmp eq ptr %t1026, null
  %t1030 = xor i1 %t1028, true
  br i1 %t1030, label %bb250, label %bb251
bb250:
  %t1032 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1032, ptr %l539, !tbaa !29
  %t1033 = load ptr, ptr %l54, !tbaa !29
  %t1035 = getelementptr %"compiler/typed:Clause", ptr %t1033, i32 0, i32 3
  %t1036 = load ptr, ptr %t1035, !tbaa !29
  %t1038 = icmp eq ptr %t1036, null
  br i1 %t1038, label %bb252, label %bb253
bb251:
  br label %bb256
bb252:
  call void @__olang_check_failed(ptr @olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba)
  unreachable
bb253:
  br label %bb254
bb254:
  %t1040 = load ptr, ptr %l54, !tbaa !29
  %t1042 = getelementptr %"compiler/typed:Clause", ptr %t1040, i32 0, i32 3
  %t1043 = load ptr, ptr %t1042, !tbaa !29
  %t1044 = load ptr, ptr %l539, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1044, ptr %t1043)
  br label %bb255
bb255:
  br label %bb256
bb256:
  %t1046 = load ptr, ptr %l54, !tbaa !29
  %t1048 = getelementptr %"compiler/typed:Clause", ptr %t1046, i32 0, i32 4
  %t1049 = load { i64, ptr }, ptr %t1048, !tbaa !27
  store { i64, ptr } %t1049, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t1051 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t1053 = extractvalue { i64, ptr } %t1051, 0
  store i64 %t1053, ptr %l57, !tbaa !24
  br label %bb257
bb257:
  store %olang.scope zeroinitializer, ptr %s47
  %t1055 = load i64, ptr %l56, !tbaa !24
  %t1056 = load i64, ptr %l57, !tbaa !24
  %t1059 = icmp slt i64 %t1055, %t1056
  %t1061 = xor i1 %t1059, true
  br i1 %t1061, label %bb258, label %bb259
bb258:
  call void @__olang_scope_close(ptr %s47)
  br label %bb264
bb259:
  br label %bb260
bb260:
  %t1063 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t1063, ptr %l553, !tbaa !27
  %t1064 = load i64, ptr %l56, !tbaa !24
  %t1066 = getelementptr { i64, ptr }, ptr %l553, i32 0, i32 1
  %t1067 = load ptr, ptr %t1066, !tbaa !27
  %t1068 = getelementptr ptr, ptr %t1067, i64 %t1064
  %t1069 = load ptr, ptr %t1068, !tbaa !39
  %t1071 = load ptr, ptr %lp2
  store ptr %t1071, ptr %l556, !tbaa !29
  %t1072 = load ptr, ptr %l0, !tbaa !29
  %t1076 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s47, ptr %t1072, ptr %t1069)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1076, ptr %l559
  br label %bb261
bb261:
  %t1077 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l559
  %t1078 = call ptr @__olang_scope_alloc_a(ptr %s47, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1077, ptr %t1078
  %t1079 = load ptr, ptr %l556, !tbaa !29
  %t1081 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s47, ptr %t1079, ptr %t1078)
  store i64 %t1081, ptr %l561
  br label %bb262
bb262:
  call void @__olang_scope_close(ptr %s47)
  br label %bb263
bb263:
  %t1082 = load i64, ptr %l56, !tbaa !24
  %t1084 = add i64 %t1082, 1
  store i64 %t1084, ptr %l56, !tbaa !24
  br label %bb257
bb264:
  br label %bb265
bb265:
  %t1086 = load i64, ptr %l52, !tbaa !24
  %t1088 = add i64 %t1086, 1
  store i64 %t1088, ptr %l52, !tbaa !24
  br label %bb246
bb266:
  br label %bb365
bb267:
  %t1090 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1090, ptr %l566, !tbaa !29
  store i1 false, ptr %l567, !tbaa !21
  %t1091 = load ptr, ptr %l566, !tbaa !29
  %t1092 = icmp ne ptr %t1091, null
  br i1 %t1092, label %bb268, label %bb269
bb268:
  %t1094 = load ptr, ptr %l566, !tbaa !29
  %t1095 = load i64, ptr %t1094, !range !{i64 0, i64 18}
  %t1097 = icmp eq i64 %t1095, 15
  store i1 %t1097, ptr %l567, !tbaa !21
  br label %bb269
bb269:
  %t1098 = load i1, ptr %l567, !tbaa !21
  br i1 %t1098, label %bb270, label %bb271
bb270:
  %t1099 = load ptr, ptr %l1, !tbaa !29
  %t1101 = getelementptr { i64, [5 x i64] }, ptr %t1099, i32 0, i32 1
  %t1102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1101, i32 0, i32 0
  %t1103 = load %"compiler/source:Span", ptr %t1102
  store %"compiler/source:Span" %t1103, ptr %l59
  %t1105 = load ptr, ptr %l1, !tbaa !29
  %t1107 = getelementptr { i64, [5 x i64] }, ptr %t1105, i32 0, i32 1
  %t1108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1107, i32 0, i32 2
  %t1109 = load ptr, ptr %t1108
  store ptr %t1109, ptr %l60, !tbaa !29
  br label %bb272
bb271:
  br label %bb327
bb272:
  %t1111 = load ptr, ptr %l60, !tbaa !29
  store ptr %t1111, ptr %l574, !tbaa !29
  store i1 false, ptr %l575, !tbaa !21
  %t1112 = load ptr, ptr %l574, !tbaa !29
  %t1113 = icmp ne ptr %t1112, null
  br i1 %t1113, label %bb273, label %bb274
bb273:
  %t1115 = load ptr, ptr %l574, !tbaa !29
  %t1116 = load i64, ptr %t1115, !range !{i64 0, i64 3}
  %t1118 = icmp eq i64 %t1116, 1
  store i1 %t1118, ptr %l575, !tbaa !21
  br label %bb274
bb274:
  %t1119 = load i1, ptr %l575, !tbaa !21
  br i1 %t1119, label %bb275, label %bb276
bb275:
  %t1120 = load ptr, ptr %l60, !tbaa !29
  %t1122 = getelementptr { i64, [4 x i64] }, ptr %t1120, i32 0, i32 1
  %t1123 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1122, i32 0, i32 0
  %t1124 = load i32, ptr %t1123
  store i32 %t1124, ptr %l61, !tbaa !23
  %t1126 = load ptr, ptr %l60, !tbaa !29
  %t1128 = getelementptr { i64, [4 x i64] }, ptr %t1126, i32 0, i32 1
  %t1129 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1128, i32 0, i32 1
  %t1130 = load { i64, ptr }, ptr %t1129
  store { i64, ptr } %t1130, ptr %l62, !tbaa !27
  %t1132 = load ptr, ptr %l60, !tbaa !29
  %t1134 = getelementptr { i64, [4 x i64] }, ptr %t1132, i32 0, i32 1
  %t1135 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1134, i32 0, i32 2
  %t1136 = load i32, ptr %t1135
  store i32 %t1136, ptr %l63, !tbaa !23
  br label %bb277
bb276:
  br label %bb299
bb277:
  %t1138 = load ptr, ptr %l0, !tbaa !29
  %t1140 = getelementptr %"compiler/free:walker", ptr %t1138, i32 0, i32 2
  %t1141 = load i1, ptr %t1140, !tbaa !21
  %t1143 = xor i1 %t1141, true
  br i1 %t1143, label %bb278, label %bb279
bb278:
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1147 = getelementptr %"compiler/free:walker", ptr %t1145, i32 0, i32 0
  %t1148 = load ptr, ptr %t1147, !tbaa !29
  %t1150 = getelementptr %"compiler/free:Free", ptr %t1148, i32 0, i32 54
  %t1151 = load i32, ptr %l61, !tbaa !23
  %t1153 = sext i32 %t1151 to i64
  %t1156 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1150, i64 %t1153)
  store ptr %t1156, ptr %l592
  br label %bb280
bb279:
  br label %bb287
bb280:
  %t1157 = load ptr, ptr %l0, !tbaa !29
  %t1159 = getelementptr %"compiler/free:walker", ptr %t1157, i32 0, i32 1
  %t1160 = load i64, ptr %t1159, !tbaa !24
  %t1161 = load ptr, ptr %l592, !tbaa !29
  %t1163 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1161, i64 %t1160)
  store i64 %t1163, ptr %l595
  br label %bb281
bb281:
  %t1164 = load ptr, ptr %l0, !tbaa !29
  %t1166 = getelementptr %"compiler/free:walker", ptr %t1164, i32 0, i32 0
  %t1167 = load ptr, ptr %t1166, !tbaa !29
  %t1169 = getelementptr %"compiler/free:Free", ptr %t1167, i32 0, i32 32
  %t1170 = load i32, ptr %l61, !tbaa !23
  %t1172 = sext i32 %t1170 to i64
  %t1175 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1169, i64 %t1172)
  store i1 %t1175, ptr %l601
  br label %bb282
bb282:
  %t1176 = load i1, ptr %l601, !tbaa !21
  br i1 %t1176, label %bb283, label %bb284
bb283:
  %t1177 = load ptr, ptr %l0, !tbaa !29
  %t1179 = getelementptr %"compiler/free:walker", ptr %t1177, i32 0, i32 0
  %t1180 = load ptr, ptr %t1179, !tbaa !29
  %t1181 = load ptr, ptr %l0, !tbaa !29
  %t1183 = getelementptr %"compiler/free:walker", ptr %t1181, i32 0, i32 1
  %t1184 = load i64, ptr %t1183, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1180, i64 %t1184)
  br label %bb285
bb284:
  br label %bb286
bb285:
  br label %bb286
bb286:
  br label %bb287
bb287:
  %t1187 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t1187, ptr %l64, !tbaa !27
  store i64 0, ptr %l65, !tbaa !24
  %t1189 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t1191 = extractvalue { i64, ptr } %t1189, 0
  store i64 %t1191, ptr %l66, !tbaa !24
  br label %bb288
bb288:
  store %olang.scope zeroinitializer, ptr %s55
  %t1193 = load i64, ptr %l65, !tbaa !24
  %t1194 = load i64, ptr %l66, !tbaa !24
  %t1197 = icmp slt i64 %t1193, %t1194
  %t1199 = xor i1 %t1197, true
  br i1 %t1199, label %bb289, label %bb290
bb289:
  call void @__olang_scope_close(ptr %s55)
  br label %bb296
bb290:
  br label %bb291
bb291:
  %t1201 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t1201, ptr %l613, !tbaa !27
  %t1202 = load i64, ptr %l65, !tbaa !24
  %t1204 = getelementptr { i64, ptr }, ptr %l613, i32 0, i32 1
  %t1205 = load ptr, ptr %t1204, !tbaa !27
  %t1206 = getelementptr ptr, ptr %t1205, i64 %t1202
  %t1207 = load ptr, ptr %t1206, !tbaa !39
  %t1209 = load ptr, ptr %l0, !tbaa !29
  %t1212 = getelementptr %"compiler/typed:Capture", ptr %t1207, i32 0, i32 1
  %t1213 = load ptr, ptr %t1212, !tbaa !29
  %t1216 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s55, ptr %t1209, ptr %t1213)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1216, ptr %l619
  br label %bb292
bb292:
  %t1217 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l619
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1217, ptr %l68
  %t1218 = load ptr, ptr %l0, !tbaa !29
  %t1219 = load %"compiler/source:Span", ptr %l59
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s55, ptr %s55, ptr %t1218, ptr %l68, %"compiler/source:Span" %t1219, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb293
bb293:
  %t1223 = load ptr, ptr %lp2
  %t1226 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s55, ptr %t1223, ptr %l68)
  store i64 %t1226, ptr %l625
  br label %bb294
bb294:
  call void @__olang_scope_close(ptr %s55)
  br label %bb295
bb295:
  %t1227 = load i64, ptr %l65, !tbaa !24
  %t1229 = add i64 %t1227, 1
  store i64 %t1229, ptr %l65, !tbaa !24
  br label %bb288
bb296:
  %t1231 = load ptr, ptr %lp2
  store ptr %t1231, ptr %l628, !tbaa !29
  %t1232 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1233 = load i32, ptr %l63, !tbaa !23
  %t1235 = sext i32 %t1233 to i64
  %t1238 = call i64 @compiler_2ffree_2eorig(i64 %t1232, i64 %t1235)
  store i64 %t1238, ptr %l632
  br label %bb297
bb297:
  %t1239 = load ptr, ptr %l628, !tbaa !29
  %t1240 = load i64, ptr %l632, !tbaa !24
  %t1241 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1239, i64 %t1240)
  store i64 %t1241, ptr %l633
  br label %bb298
bb298:
  br label %bb326
bb299:
  %t1242 = load ptr, ptr %l60, !tbaa !29
  store ptr %t1242, ptr %l634, !tbaa !29
  store i1 false, ptr %l635, !tbaa !21
  %t1243 = load ptr, ptr %l634, !tbaa !29
  %t1244 = icmp ne ptr %t1243, null
  br i1 %t1244, label %bb300, label %bb301
bb300:
  %t1246 = load ptr, ptr %l634, !tbaa !29
  %t1247 = load i64, ptr %t1246, !range !{i64 0, i64 3}
  %t1249 = icmp eq i64 %t1247, 0
  store i1 %t1249, ptr %l635, !tbaa !21
  br label %bb301
bb301:
  %t1250 = load i1, ptr %l635, !tbaa !21
  br i1 %t1250, label %bb302, label %bb303
bb302:
  %t1251 = load ptr, ptr %l60, !tbaa !29
  %t1253 = getelementptr { i64, [4 x i64] }, ptr %t1251, i32 0, i32 1
  %t1254 = getelementptr { i32 }, ptr %t1253, i32 0, i32 0
  %t1255 = load i32, ptr %t1254
  store i32 %t1255, ptr %l69, !tbaa !23
  br label %bb304
bb303:
  br label %bb306
bb304:
  %t1257 = load ptr, ptr %l0, !tbaa !29
  %t1259 = getelementptr %"compiler/free:walker", ptr %t1257, i32 0, i32 0
  %t1260 = load ptr, ptr %t1259, !tbaa !29
  %t1262 = getelementptr %"compiler/free:Free", ptr %t1260, i32 0, i32 37
  %t1263 = load i32, ptr %l69, !tbaa !23
  %t1265 = sext i32 %t1263 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1262, i64 %t1265, i1 true)
  br label %bb305
bb305:
  br label %bb326
bb306:
  %t1268 = load ptr, ptr %l60, !tbaa !29
  store ptr %t1268, ptr %l645, !tbaa !29
  store i1 false, ptr %l646, !tbaa !21
  %t1269 = load ptr, ptr %l645, !tbaa !29
  %t1270 = icmp ne ptr %t1269, null
  br i1 %t1270, label %bb307, label %bb308
bb307:
  %t1272 = load ptr, ptr %l645, !tbaa !29
  %t1273 = load i64, ptr %t1272, !range !{i64 0, i64 3}
  %t1275 = icmp eq i64 %t1273, 2
  store i1 %t1275, ptr %l646, !tbaa !21
  br label %bb308
bb308:
  %t1276 = load i1, ptr %l646, !tbaa !21
  br i1 %t1276, label %bb309, label %bb310
bb309:
  %t1277 = load ptr, ptr %l60, !tbaa !29
  %t1279 = getelementptr { i64, [4 x i64] }, ptr %t1277, i32 0, i32 1
  %t1280 = getelementptr { i32, ptr, i32 }, ptr %t1279, i32 0, i32 1
  %t1281 = load ptr, ptr %t1280
  store ptr %t1281, ptr %l70, !tbaa !29
  %t1283 = load ptr, ptr %l60, !tbaa !29
  %t1285 = getelementptr { i64, [4 x i64] }, ptr %t1283, i32 0, i32 1
  %t1286 = getelementptr { i32, ptr, i32 }, ptr %t1285, i32 0, i32 2
  %t1287 = load i32, ptr %t1286
  store i32 %t1287, ptr %l71, !tbaa !23
  br label %bb311
bb310:
  br label %bb321
bb311:
  store %olang.scope zeroinitializer, ptr %s58
  %t1289 = load ptr, ptr %l0, !tbaa !29
  %t1291 = getelementptr %"compiler/free:walker", ptr %t1289, i32 0, i32 2
  %t1292 = load i1, ptr %t1291, !tbaa !21
  %t1294 = xor i1 %t1292, true
  br i1 %t1294, label %bb312, label %bb313
bb312:
  %t1296 = load ptr, ptr %l0, !tbaa !29
  %t1298 = getelementptr %"compiler/free:walker", ptr %t1296, i32 0, i32 0
  %t1299 = load ptr, ptr %t1298, !tbaa !29
  %t1300 = load ptr, ptr %l0, !tbaa !29
  %t1302 = getelementptr %"compiler/free:walker", ptr %t1300, i32 0, i32 1
  %t1303 = load i64, ptr %t1302, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1299, i64 %t1303)
  br label %bb314
bb313:
  br label %bb315
bb314:
  br label %bb315
bb315:
  %t1306 = load ptr, ptr %l0, !tbaa !29
  %t1307 = load ptr, ptr %l70, !tbaa !29
  %t1310 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s58, ptr %t1306, ptr %t1307)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1310, ptr %l662
  br label %bb316
bb316:
  %t1311 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l662
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1311, ptr %l72
  %t1312 = load ptr, ptr %l0, !tbaa !29
  %t1313 = load %"compiler/source:Span", ptr %l59
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s58, ptr %s58, ptr %t1312, ptr %l72, %"compiler/source:Span" %t1313, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb317
bb317:
  %t1317 = load ptr, ptr %lp2
  %t1320 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s58, ptr %t1317, ptr %l72)
  store i64 %t1320, ptr %l668
  br label %bb318
bb318:
  %t1321 = load ptr, ptr %lp2
  store ptr %t1321, ptr %l669, !tbaa !29
  %t1322 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1323 = load i32, ptr %l71, !tbaa !23
  %t1325 = sext i32 %t1323 to i64
  %t1328 = call i64 @compiler_2ffree_2eorig(i64 %t1322, i64 %t1325)
  store i64 %t1328, ptr %l673
  br label %bb319
bb319:
  %t1329 = load ptr, ptr %l669, !tbaa !29
  %t1330 = load i64, ptr %l673, !tbaa !24
  %t1331 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1329, i64 %t1330)
  store i64 %t1331, ptr %l674
  br label %bb320
bb320:
  call void @__olang_scope_close(ptr %s58)
  br label %bb326
bb321:
  br i1 true, label %bb322, label %bb323
bb322:
  br label %bb324
bb323:
  br label %bb325
bb324:
  br label %bb326
bb325:
  call void @__olang_check_failed(ptr @olang_loc_67165cb650ae48c_1f30efdb88316bc8)
  unreachable
bb326:
  br label %bb365
bb327:
  %t1332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1332, ptr %l675, !tbaa !29
  store i1 false, ptr %l676, !tbaa !21
  %t1333 = load ptr, ptr %l675, !tbaa !29
  %t1334 = icmp ne ptr %t1333, null
  br i1 %t1334, label %bb328, label %bb329
bb328:
  %t1336 = load ptr, ptr %l675, !tbaa !29
  %t1337 = load i64, ptr %t1336, !range !{i64 0, i64 18}
  %t1339 = icmp eq i64 %t1337, 16
  store i1 %t1339, ptr %l676, !tbaa !21
  br label %bb329
bb329:
  %t1340 = load i1, ptr %l676, !tbaa !21
  br i1 %t1340, label %bb330, label %bb331
bb330:
  %t1341 = load ptr, ptr %l1, !tbaa !29
  %t1343 = getelementptr { i64, [5 x i64] }, ptr %t1341, i32 0, i32 1
  %t1344 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1343, i32 0, i32 2
  %t1345 = load ptr, ptr %t1344
  store ptr %t1345, ptr %l73, !tbaa !29
  br label %bb332
bb331:
  br label %bb353
bb332:
  %t1347 = load ptr, ptr %l73, !tbaa !29
  %t1349 = getelementptr %"compiler/typed:Text", ptr %t1347, i32 0, i32 0
  %t1350 = load { i64, ptr }, ptr %t1349, !tbaa !27
  store { i64, ptr } %t1350, ptr %l74, !tbaa !27
  store i64 0, ptr %l75, !tbaa !24
  %t1352 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1354 = extractvalue { i64, ptr } %t1352, 0
  store i64 %t1354, ptr %l76, !tbaa !24
  br label %bb333
bb333:
  %t1356 = load i64, ptr %l75, !tbaa !24
  %t1357 = load i64, ptr %l76, !tbaa !24
  %t1360 = icmp slt i64 %t1356, %t1357
  %t1362 = xor i1 %t1360, true
  br i1 %t1362, label %bb334, label %bb335
bb334:
  br label %bb350
bb335:
  br label %bb336
bb336:
  %t1364 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t1364, ptr %l689, !tbaa !27
  %t1365 = load i64, ptr %l75, !tbaa !24
  %t1367 = getelementptr { i64, ptr }, ptr %l689, i32 0, i32 1
  %t1368 = load ptr, ptr %t1367, !tbaa !27
  %t1369 = getelementptr ptr, ptr %t1368, i64 %t1365
  %t1370 = load ptr, ptr %t1369, !tbaa !39
  store ptr %t1370, ptr %l77, !tbaa !29
  %t1372 = load ptr, ptr %l77, !tbaa !29
  store ptr %t1372, ptr %l692, !tbaa !29
  store i1 false, ptr %l693, !tbaa !21
  %t1373 = load ptr, ptr %l692, !tbaa !29
  %t1374 = icmp ne ptr %t1373, null
  br i1 %t1374, label %bb337, label %bb338
bb337:
  %t1376 = load ptr, ptr %l692, !tbaa !29
  %t1377 = load i64, ptr %t1376, !range !{i64 0, i64 2}
  %t1379 = icmp eq i64 %t1377, 1
  store i1 %t1379, ptr %l693, !tbaa !21
  br label %bb338
bb338:
  %t1380 = load i1, ptr %l693, !tbaa !21
  br i1 %t1380, label %bb339, label %bb340
bb339:
  %t1381 = load ptr, ptr %l77, !tbaa !29
  %t1383 = getelementptr { i64, [2 x i64] }, ptr %t1381, i32 0, i32 1
  %t1384 = getelementptr { ptr }, ptr %t1383, i32 0, i32 0
  %t1385 = load ptr, ptr %t1384
  store ptr %t1385, ptr %l78, !tbaa !29
  br label %bb341
bb340:
  br label %bb343
bb341:
  store %olang.scope zeroinitializer, ptr %s64
  %t1387 = load ptr, ptr %l0, !tbaa !29
  %t1388 = load ptr, ptr %l78, !tbaa !29
  %t1391 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s64, ptr %t1387, ptr %t1388)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1391, ptr %l700
  br label %bb342
bb342:
  call void @__olang_scope_close(ptr %s64)
  br label %bb348
bb343:
  br i1 true, label %bb344, label %bb345
bb344:
  br label %bb346
bb345:
  br label %bb347
bb346:
  br label %bb348
bb347:
  call void @__olang_check_failed(ptr @olang_loc_b6b576316e1b3293_3c9a5af727622297)
  unreachable
bb348:
  br label %bb349
bb349:
  %t1392 = load i64, ptr %l75, !tbaa !24
  %t1394 = add i64 %t1392, 1
  store i64 %t1394, ptr %l75, !tbaa !24
  br label %bb333
bb350:
  %t1396 = load ptr, ptr %lp2
  store ptr %t1396, ptr %l703, !tbaa !29
  %t1397 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1398 = load ptr, ptr %l73, !tbaa !29
  %t1400 = getelementptr %"compiler/typed:Text", ptr %t1398, i32 0, i32 1
  %t1401 = load i32, ptr %t1400, !tbaa !23
  %t1403 = sext i32 %t1401 to i64
  %t1406 = call i64 @compiler_2ffree_2eorig(i64 %t1397, i64 %t1403)
  store i64 %t1406, ptr %l708
  br label %bb351
bb351:
  %t1407 = load ptr, ptr %l703, !tbaa !29
  %t1408 = load i64, ptr %l708, !tbaa !24
  %t1409 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1407, i64 %t1408)
  store i64 %t1409, ptr %l709
  br label %bb352
bb352:
  br label %bb365
bb353:
  %t1410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1410, ptr %l710, !tbaa !29
  store i1 false, ptr %l711, !tbaa !21
  %t1411 = load ptr, ptr %l710, !tbaa !29
  %t1412 = icmp ne ptr %t1411, null
  br i1 %t1412, label %bb354, label %bb355
bb354:
  %t1414 = load ptr, ptr %l710, !tbaa !29
  %t1415 = load i64, ptr %t1414, !range !{i64 0, i64 18}
  %t1417 = icmp eq i64 %t1415, 17
  store i1 %t1417, ptr %l711, !tbaa !21
  br label %bb355
bb355:
  %t1418 = load i1, ptr %l711, !tbaa !21
  br i1 %t1418, label %bb356, label %bb357
bb356:
  %t1419 = load ptr, ptr %l1, !tbaa !29
  %t1421 = getelementptr { i64, [5 x i64] }, ptr %t1419, i32 0, i32 1
  %t1422 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1421, i32 0, i32 2
  %t1423 = load ptr, ptr %t1422
  store ptr %t1423, ptr %l79, !tbaa !29
  br label %bb358
bb357:
  br label %bb360
bb358:
  %t1425 = load ptr, ptr %l0, !tbaa !29
  %t1426 = load ptr, ptr %l79, !tbaa !29
  %t1429 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1425, ptr %t1426)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1429, ptr %l718
  br label %bb359
bb359:
  %t1430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l718
  %t1431 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1430, ptr %t1431
  br label %bb365
bb360:
  br i1 true, label %bb361, label %bb362
bb361:
  br label %bb363
bb362:
  br label %bb364
bb363:
  br label %bb365
bb364:
  call void @__olang_check_failed(ptr @olang_loc_797639ecae530892_5422fc7df8fd29f6)
  unreachable
bb365:
  %t1432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1432, ptr %l719, !tbaa !29
  %t1433 = load ptr, ptr %l1, !tbaa !29
  %t1435 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1433)
  store i32 %t1435, ptr %l721
  br label %bb366
bb366:
  %t1436 = load ptr, ptr %l719, !tbaa !29
  %t1437 = load i32, ptr %l721, !tbaa !23
  %t1438 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t1436, i32 %t1437)
  store i1 %t1438, ptr %l722
  br label %bb367
bb367:
  %t1439 = load i1, ptr %l722, !tbaa !21
  %t1440 = xor i1 %t1439, true
  br i1 %t1440, label %bb368, label %bb369
bb368:
  %t1442 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1442, ptr %l724
  br label %bb370
bb369:
  br label %bb371
bb370:
  %t1443 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l724
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1443, ptr %rv
  br label %ret
bb371:
  %t1444 = load ptr, ptr %lp2
  %t1445 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1444
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1445, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, { i64, ptr } }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, { i64, ptr } }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, { i64, ptr } }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, { i64, ptr } }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, { i64, ptr } }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l114 = alloca i64
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, { i64, ptr } }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca { i64, { i64, ptr } }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca i64
  %l144 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i64
  %l154 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca ptr
  %l165 = alloca i32
  %l167 = alloca %"compiler/typed:Local"
  %l169 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, { i64, ptr } }
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l206 = alloca { i64, ptr }
  %l210 = alloca i1
  %l214 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, { i64, ptr } }
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l228 = alloca { i64, { i64, ptr } }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 5
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = insertvalue { i64, { i64, ptr } } undef, i64 %t30, 0
  %t35 = insertvalue { i64, { i64, ptr } } %t33, { i64, ptr } %t31, 1
  store { i64, { i64, ptr } } %t35, ptr %l28
  %t36 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  store { i64, ptr } %t51, ptr %t52, !tbaa !27
  %t53 = load { i64, { i64, ptr } }, ptr %l28
  store { i64, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb7:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Make", ptr %t69, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { i64, { i64, ptr } } undef, i64 %t74, 0
  %t79 = insertvalue { i64, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  store { i64, { i64, ptr } } %t79, ptr %l43
  %t80 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t96 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load { i64, { i64, ptr } }, ptr %l43
  store { i64, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb13:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb14, label %bb15
bb14:
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i64, ptr %t102, !range !{i64 0, i64 18}
  %t105 = icmp eq i64 %t103, 16
  store i1 %t105, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t106 = load i1, ptr %l48, !tbaa !21
  br i1 %t106, label %bb16, label %bb17
bb16:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Text", ptr %t113, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t121 = insertvalue { i64, { i64, ptr } } undef, i64 %t118, 0
  %t123 = insertvalue { i64, { i64, ptr } } %t121, { i64, ptr } %t119, 1
  store { i64, { i64, ptr } } %t123, ptr %l58
  %t124 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l59, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l60, !tbaa !24
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l61, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l60, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t140 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  store { i64, ptr } %t139, ptr %t140, !tbaa !27
  %t141 = load { i64, { i64, ptr } }, ptr %l58
  store { i64, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb19:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb20, label %bb21
bb20:
  %t146 = load ptr, ptr %l62, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 8
  store i1 %t149, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb22, label %bb23
bb22:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Collect", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t162 = sext i32 %t160 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t165 = insertvalue { i64, { i64, ptr } } undef, i64 %t162, 0
  %t167 = insertvalue { i64, { i64, ptr } } %t165, { i64, ptr } %t163, 1
  store { i64, { i64, ptr } } %t167, ptr %l73
  %t168 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l74, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l75, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l76, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l75, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t184 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  %t185 = load { i64, { i64, ptr } }, ptr %l73
  store { i64, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb25:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t187 = load ptr, ptr %l77, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb26, label %bb27
bb26:
  %t190 = load ptr, ptr %l77, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 18}
  %t193 = icmp eq i64 %t191, 6
  store i1 %t193, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t194 = load i1, ptr %l78, !tbaa !21
  br i1 %t194, label %bb28, label %bb29
bb28:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb78
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t202 = load ptr, ptr %l8, !tbaa !29
  %t205 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store i64 %t205, ptr %l85
  br label %bb31
bb31:
  %t206 = load i64, ptr %l85, !tbaa !24
  store i64 %t206, ptr %l9, !tbaa !24
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb34
bb33:
  %t211 = load ptr, ptr %l8, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Call", ptr %t211, i32 0, i32 3
  %t214 = load i32, ptr %t213, !tbaa !23
  %t216 = icmp slt i32 %t214, 0
  store i1 %t216, ptr %l88, !tbaa !21
  br label %bb34
bb34:
  %t218 = load i1, ptr %l88, !tbaa !21
  br i1 %t218, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t220 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t222 = insertvalue { i64, { i64, ptr } } %t220, { i64, ptr } %t219, 1
  store { i64, { i64, ptr } } %t222, ptr %l94
  %t223 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l95, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l96, !tbaa !24
  %t227 = load i64, ptr %l96, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l97, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l96, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t239 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  store { i64, ptr } %t238, ptr %t239, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t240 = load { i64, { i64, ptr } }, ptr %l94
  store { i64, { i64, ptr } } %t240, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 1
  %t244 = load i64, ptr %l9, !tbaa !24
  %t247 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t247, ptr %l101
  br label %bb38
bb38:
  %t248 = load ptr, ptr %l101, !tbaa !29
  store ptr %t248, ptr %l10, !tbaa !29
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Body", ptr %t249, i32 0, i32 11
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = icmp eq ptr %t252, null
  br i1 %t254, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t257 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t259 = insertvalue { i64, { i64, ptr } } %t257, { i64, ptr } %t256, 1
  store { i64, { i64, ptr } } %t259, ptr %l107
  %t260 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l108, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l109, !tbaa !24
  %t264 = load i64, ptr %l109, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l110, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l109, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  store { i64, ptr } %t275, ptr %t276, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t277 = load { i64, { i64, ptr } }, ptr %l107
  store { i64, { i64, ptr } } %t277, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t278 = load ptr, ptr %l3, !tbaa !29
  %t279 = load ptr, ptr %l10, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t285 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t278, i32 %t282)
  store i64 %t285, ptr %l114
  br label %bb42
bb42:
  %t286 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t287 = load i64, ptr %l114, !tbaa !24
  %t289 = icmp eq i64 %t287, %t286
  br i1 %t289, label %bb43, label %bb44
bb43:
  %t291 = load ptr, ptr %l8, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Call", ptr %t291, i32 0, i32 3
  %t294 = load i32, ptr %t293, !tbaa !23
  %t296 = sext i32 %t294 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l120, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t299 = insertvalue { i64, { i64, ptr } } undef, i64 %t296, 0
  %t301 = insertvalue { i64, { i64, ptr } } %t299, { i64, ptr } %t297, 1
  store { i64, { i64, ptr } } %t301, ptr %l122
  %t302 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  store { i64, ptr } %t303, ptr %l123, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l124, !tbaa !24
  %t306 = load i64, ptr %l124, !tbaa !24
  %t307 = mul i64 %t306, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l125, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l124, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t318 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  store { i64, ptr } %t317, ptr %t318, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t319 = load { i64, { i64, ptr } }, ptr %l122
  store { i64, { i64, ptr } } %t319, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Body", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s5, ptr %t320, i32 %t324)
  store { i64, ptr } %t327, ptr %l129
  br label %bb46
bb46:
  %t328 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t331 = icmp ne i64 %t329, 1
  br i1 %t331, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l132, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t334 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t336 = insertvalue { i64, { i64, ptr } } %t334, { i64, ptr } %t333, 1
  store { i64, { i64, ptr } } %t336, ptr %l134
  %t337 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l135, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l136, !tbaa !24
  %t341 = load i64, ptr %l136, !tbaa !24
  %t342 = mul i64 %t341, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t342)
  %t344 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  store { i64, ptr } %t345, ptr %l137, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = load i64, ptr %l136, !tbaa !24
  %t351 = mul i64 %t350, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t347, ptr %t349, i64 %t351, i1 false)
  %t352 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t353 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  store { i64, ptr } %t352, ptr %t353, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t354 = load { i64, { i64, ptr } }, ptr %l134
  store { i64, { i64, ptr } } %t354, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t355 = load ptr, ptr %l3, !tbaa !29
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Body", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %t358, !tbaa !23
  %t362 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t355, i32 %t359, i64 0)
  store i64 %t362, ptr %l141
  br label %bb50
bb50:
  %t363 = load i64, ptr %l141, !tbaa !24
  store i64 %t363, ptr %l11, !tbaa !24
  %t364 = load i64, ptr %l11, !tbaa !24
  %t366 = icmp sge i64 %t364, 0
  br i1 %t366, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb53
bb52:
  %t368 = load i64, ptr %l11, !tbaa !24
  %t369 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t372 = icmp eq i64 %t368, %t369
  store i1 %t372, ptr %l144, !tbaa !21
  br label %bb53
bb53:
  %t374 = load i1, ptr %l144, !tbaa !21
  br i1 %t374, label %bb54, label %bb55
bb54:
  %t375 = load i64, ptr %l11, !tbaa !24
  %t377 = icmp sge i64 %t375, 0
  br i1 %t377, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t379 = load i64, ptr %l11, !tbaa !24
  store i64 %t379, ptr %l151, !tbaa !24
  %t380 = load ptr, ptr %l10, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Body", ptr %t380, i32 0, i32 5
  %t384 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t382)
  store i64 %t384, ptr %l154
  br label %bb58
bb57:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb59
bb58:
  %t385 = load i64, ptr %l151, !tbaa !24
  %t386 = load i64, ptr %l154, !tbaa !24
  %t387 = icmp slt i64 %t385, %t386
  store i1 %t387, ptr %l150, !tbaa !21
  br label %bb59
bb59:
  %t389 = load i1, ptr %l150, !tbaa !21
  br i1 %t389, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t392 = getelementptr %"compiler/free:Free", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 0
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = getelementptr %"compiler/load:Loader", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  store ptr %t399, ptr %l159, !tbaa !29
  %t400 = load ptr, ptr %l10, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Body", ptr %t400, i32 0, i32 7
  store ptr %t402, ptr %l161, !tbaa !29
  %t403 = load ptr, ptr %l10, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Body", ptr %t403, i32 0, i32 5
  %t406 = load i64, ptr %l11, !tbaa !24
  %t409 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t405, i64 %t406)
  store i32 %t409, ptr %l165
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t410 = load i32, ptr %l165, !tbaa !23
  %t411 = sext i32 %t410 to i64
  %t412 = load ptr, ptr %l161, !tbaa !29
  %t414 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t412, i64 %t411)
  store %"compiler/typed:Local" %t414, ptr %l167
  br label %bb63
bb63:
  %t415 = getelementptr %"compiler/typed:Local", ptr %l167, i32 0, i32 0
  %t416 = load i32, ptr %t415, !tbaa !23
  %t417 = load ptr, ptr %l159, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t417, i32 %t416)
  store { i64, ptr } %t419, ptr %l169
  br label %bb64
bb64:
  %t420 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t420, ptr %l12, !tbaa !27
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t422 = load i64, ptr %l9, !tbaa !24
  %t425 = getelementptr %"compiler/free:Free", ptr %t421, i32 0, i32 48
  store i64 %t422, ptr %t425, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t427 = load ptr, ptr %l10, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Body", ptr %t427, i32 0, i32 3
  %t430 = load i64, ptr %t429, !tbaa !24
  %t433 = getelementptr %"compiler/free:Free", ptr %t426, i32 0, i32 49
  store i64 %t430, ptr %t433, !tbaa !24
  %t434 = load ptr, ptr %l2, !tbaa !29
  store ptr %t434, ptr %l175, !tbaa !29
  %t435 = load ptr, ptr %l10, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Body", ptr %t435, i32 0, i32 4
  %t438 = getelementptr %"compiler/source:Span", ptr %t437, i32 0, i32 0
  %t439 = load i32, ptr %t438, !tbaa !23
  %t440 = load ptr, ptr %l10, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Body", ptr %t440, i32 0, i32 4
  %t443 = getelementptr %"compiler/source:Span", ptr %t442, i32 0, i32 0
  %t444 = load i32, ptr %t443, !tbaa !23
  %t447 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t439, i32 %t444)
  store %"compiler/source:Span" %t447, ptr %l180
  br label %bb65
bb65:
  %t448 = load %"compiler/source:Span", ptr %l180
  %t449 = load ptr, ptr %l175, !tbaa !29
  %t450 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 50
  store %"compiler/source:Span" %t448, ptr %t450
  %t451 = load ptr, ptr %l2, !tbaa !29
  %t452 = load i64, ptr %l9, !tbaa !24
  %t455 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s11, ptr %t451, i64 %t452)
  store { i64, ptr } %t455, ptr %l183
  br label %bb66
bb66:
  %t456 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load ptr, ptr %l2, !tbaa !29
  store ptr %t457, ptr %l185, !tbaa !29
  %t458 = load ptr, ptr %l3, !tbaa !29
  %t459 = load ptr, ptr %l10, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Body", ptr %t459, i32 0, i32 2
  %t462 = load i32, ptr %t461, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t458, i32 %t462)
  store { i64, ptr } %t465, ptr %l189
  br label %bb67
bb67:
  %t466 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr i32, ptr %t467, i64 0
  %t469 = load i32, ptr %t468, !tbaa !33
  %t470 = load ptr, ptr %l185, !tbaa !29
  %t472 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %s11, ptr %t470, i32 %t469)
  store { i64, ptr } %t472, ptr %l191
  br label %bb68
bb68:
  %t473 = load ptr, ptr %l2, !tbaa !29
  store ptr %t473, ptr %l192, !tbaa !29
  %t474 = load ptr, ptr %l3, !tbaa !29
  %t475 = load ptr, ptr %l10, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %t477, !tbaa !23
  %t481 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t474, i32 %t478)
  store { i64, ptr } %t481, ptr %l196
  br label %bb69
bb69:
  %t482 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i32, ptr %t483, i64 0
  %t485 = load i32, ptr %t484, !tbaa !33
  %t486 = load ptr, ptr %l192, !tbaa !29
  %t488 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %s11, ptr %t486, i32 %t485)
  store { i64, ptr } %t488, ptr %l198
  br label %bb70
bb70:
  %t489 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = add i64 %t504, %t507
  %t509 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t511 = add i64 %t508, %t510
  %t512 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = add i64 %t511, %t514
  %t516 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t515)
  call void @olang_textcopy(ptr %t516, ptr %t489, i64 %t490)
  %t517 = getelementptr i8, ptr %t516, i64 %t490
  call void @olang_textcopy(ptr %t517, ptr %t492, i64 %t493)
  %t518 = getelementptr i8, ptr %t517, i64 %t493
  call void @olang_textcopy(ptr %t518, ptr %t495, i64 %t496)
  %t519 = getelementptr i8, ptr %t518, i64 %t496
  call void @olang_textcopy(ptr %t519, ptr %t499, i64 %t500)
  %t520 = getelementptr i8, ptr %t519, i64 %t500
  call void @olang_textcopy(ptr %t520, ptr %t502, i64 %t503)
  %t521 = getelementptr i8, ptr %t520, i64 %t503
  call void @olang_textcopy(ptr %t521, ptr %t506, i64 %t507)
  %t522 = getelementptr i8, ptr %t521, i64 %t507
  call void @olang_textcopy(ptr %t522, ptr %t509, i64 %t510)
  %t523 = getelementptr i8, ptr %t522, i64 %t510
  call void @olang_textcopy(ptr %t523, ptr %t513, i64 %t514)
  %t524 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t516, 1
  %t526 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t528 = insertvalue { i64, { i64, ptr } } %t526, { i64, ptr } %t525, 1
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t528, ptr %rv
  br label %ret
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l201, !tbaa !27
  %t530 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t531 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t533 = insertvalue { i64, { i64, ptr } } %t531, { i64, ptr } %t530, 1
  store { i64, { i64, ptr } } %t533, ptr %l203
  %t534 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l204, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  store i64 %t537, ptr %l205, !tbaa !24
  %t538 = load i64, ptr %l205, !tbaa !24
  %t539 = mul i64 %t538, 1
  %t540 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t539)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  store { i64, ptr } %t542, ptr %l206, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = load i64, ptr %l205, !tbaa !24
  %t548 = mul i64 %t547, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t544, ptr %t546, i64 %t548, i1 false)
  %t549 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t550 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  store { i64, ptr } %t549, ptr %t550, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t551 = load { i64, { i64, ptr } }, ptr %l203
  store { i64, { i64, ptr } } %t551, ptr %rv
  br label %ret
bb72:
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr %"compiler/free:Free", ptr %t552, i32 0, i32 31
  %t555 = load i64, ptr %l9, !tbaa !24
  %t558 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t554, i64 %t555)
  store i1 %t558, ptr %l210
  br label %bb73
bb73:
  %t559 = load i1, ptr %l210, !tbaa !21
  %t560 = xor i1 %t559, true
  br i1 %t560, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t562 = load ptr, ptr %l2, !tbaa !29
  %t563 = load i64, ptr %l9, !tbaa !24
  %t566 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s13, ptr %t562, i64 %t563)
  store { i64, ptr } %t566, ptr %l214
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t567 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t569 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = add i64 %t568, %t571
  %t573 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t574 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t567, i64 %t568)
  %t577 = getelementptr i8, ptr %t576, i64 %t568
  call void @olang_textcopy(ptr %t577, ptr %t570, i64 %t571)
  %t578 = getelementptr i8, ptr %t577, i64 %t571
  call void @olang_textcopy(ptr %t578, ptr %t573, i64 %t574)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t576, 1
  %t581 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t583 = insertvalue { i64, { i64, ptr } } %t581, { i64, ptr } %t580, 1
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t583, ptr %rv
  br label %ret
bb77:
  %t585 = load ptr, ptr %l8, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Call", ptr %t585, i32 0, i32 3
  %t588 = load i32, ptr %t587, !tbaa !23
  %t590 = sext i32 %t588 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l220, !tbaa !27
  %t591 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t593 = insertvalue { i64, { i64, ptr } } undef, i64 %t590, 0
  %t595 = insertvalue { i64, { i64, ptr } } %t593, { i64, ptr } %t591, 1
  store { i64, { i64, ptr } } %t595, ptr %l222
  %t596 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  store { i64, ptr } %t597, ptr %l223, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 0
  store i64 %t599, ptr %l224, !tbaa !24
  %t600 = load i64, ptr %l224, !tbaa !24
  %t601 = mul i64 %t600, 1
  %t602 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t601)
  %t603 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t602, 1
  store { i64, ptr } %t604, ptr %l225, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = load i64, ptr %l224, !tbaa !24
  %t610 = mul i64 %t609, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t606, ptr %t608, i64 %t610, i1 false)
  %t611 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t612 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  store { i64, ptr } %t611, ptr %t612, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t613 = load { i64, { i64, ptr } }, ptr %l222
  store { i64, { i64, ptr } } %t613, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l226, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t615 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t617 = insertvalue { i64, { i64, ptr } } %t615, { i64, ptr } %t614, 1
  store { i64, { i64, ptr } } %t617, ptr %l228
  %t618 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  store { i64, ptr } %t619, ptr %l229, !tbaa !27
  %t620 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 0
  store i64 %t621, ptr %l230, !tbaa !24
  %t622 = load i64, ptr %l230, !tbaa !24
  %t623 = mul i64 %t622, 1
  %t624 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t623)
  %t625 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  store { i64, ptr } %t626, ptr %l231, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = load i64, ptr %l230, !tbaa !24
  %t632 = mul i64 %t631, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t628, ptr %t630, i64 %t632, i1 false)
  %t633 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t634 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  store { i64, ptr } %t633, ptr %t634, !tbaa !27
  %t635 = load { i64, { i64, ptr } }, ptr %l228
  store { i64, { i64, ptr } } %t635, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_fa71248d89b17b0b_39d265aac120d27f)
  unreachable
ret:
  %rr = load { i64, { i64, ptr } }, ptr %rv
  ret { i64, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 7
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t19, i64 %a1)
  store %"compiler/typed:Local" %t23, ptr %l12
  br label %bb2
bb2:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t26, i32 %t25)
  store { i64, ptr } %t28, ptr %l14
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp slt i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l43, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = load i64, ptr %l53, !tbaa !24
  %t88 = icmp slt i64 %t86, %t85
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load i64, ptr %l2, !tbaa !24
  store i64 %t91, ptr %l57, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 15
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l61
  br label %bb23
bb22:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca i1
  %l18 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l59 = alloca i64
  %l64 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca %"compiler/free:orCall"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 21
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t6, i64 %t10)
  store i1 %t13, ptr %l16
  br label %bb1
bb1:
  %t14 = load i1, ptr %l16, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Call", ptr %t17, i32 0, i32 3
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp slt i32 %t20, 0
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Call", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb13
bb10:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t58 = load i64, ptr %l31, !tbaa !24
  store i64 %t58, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb15, label %bb16
bb15:
  br label %bb29
bb16:
  br label %bb17
bb17:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l8, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Call", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr ptr, ptr %t86, i64 %t83
  %t88 = load ptr, ptr %t87, !tbaa !39
  %t91 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v1, ptr %t78, ptr %t88)
  store ptr %t91, ptr %l54
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l54, !tbaa !29
  store ptr %t92, ptr %l9, !tbaa !29
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  br i1 %t95, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t101 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i64 %t101, ptr %l59
  br label %bb22
bb22:
  %t102 = load i64, ptr %l59, !tbaa !24
  store i64 %t102, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  br i1 %t105, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:walker", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 45
  store ptr %t112, ptr %l64, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 3
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Call", ptr %t127, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load i64, ptr %l8, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr ptr, ptr %t134, i64 %t131
  %t136 = load ptr, ptr %t135, !tbaa !39
  %t144 = call %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v1, ptr %v1, ptr %v0, i64 %t116, i64 %t122, i64 %a2, i64 %t124, i64 %t125, ptr %t126, ptr %t136)
  store %"compiler/free:orCall" %t144, ptr %l78
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l64, !tbaa !29
  %t146 = load %"compiler/free:orCall", ptr %l78
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t145, %"compiler/free:orCall" %t146)
  br label %bb27
bb27:
  br label %ret
bb28:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l7, !tbaa !24
  br label %bb14
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca %"compiler/free:orStore"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 21
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t6, i64 %t10)
  store i1 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  store ptr %t20, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i64 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load i64, ptr %l18, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 46
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t52 = call %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v2, ptr %v1, ptr %v0, i64 %t44, i64 %t45, ptr %a2, ptr %t47)
  store %"compiler/free:orStore" %t52, ptr %l29
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = load %"compiler/free:orStore", ptr %l29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t53, %"compiler/free:orStore" %t54)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %lp18 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l58 = alloca i64
  %l61 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i32
  %l120 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca i1
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca ptr
  %l140 = alloca i1
  %l147 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l152 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l169 = alloca ptr
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t7 = load ptr, ptr %l21, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l22, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %t27, i64 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l33
  br label %bb7
bb7:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t36, ptr %lp5
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t38 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %t38
  %t39 = load ptr, ptr %lp5
  store ptr %t39, ptr %l34, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 3
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l39
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t49, ptr %t50)
  store i64 %t51, ptr %l40
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t57, i1 true)
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 7
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t68 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t62, i64 %t65)
  %t69 = extractvalue { i32, i64 } %t68, 1
  %t70 = extractvalue { i32, i64 } %t68, 0
  store i32 %t70, ptr %l51
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb12, label %ok.72, !prof !99
ok.72:
  store i64 %t69, ptr %l50
  br label %bb11
bb11:
  %t73 = load i64, ptr %l50, !tbaa !24
  store i64 %t73, ptr %l45, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 8
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i64, ptr %l6, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t79, i32 %t83, i64 %t84)
  store i64 %t88, ptr %l58
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t89 = load i64, ptr %l58, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %lp5
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call i64 @compiler_2ffree_2eorig(i64 %t95, i64 %t96)
  store i64 %t99, ptr %l64
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t100 = load ptr, ptr %l61, !tbaa !29
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t100, i64 %t101)
  store i64 %t102, ptr %l65
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t103 = load ptr, ptr %lp5
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %rv
  br label %ret
bb24:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t107 = load ptr, ptr %l67, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb25, label %bb26
bb25:
  %t110 = load ptr, ptr %l67, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t114 = load i1, ptr %l68, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t125 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t121, ptr %t122)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t125, ptr %l75
  br label %bb30
bb30:
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %rv
  br label %ret
bb31:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t128 = load ptr, ptr %l76, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t131 = load ptr, ptr %l76, !tbaa !29
  %t132 = load i64, ptr %t131, !range !{i64 0, i64 8}
  %t134 = icmp eq i64 %t132, 3
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l77, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l9, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 3
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l9, !tbaa !29
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t148, ptr %t149)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l86
  br label %bb37
bb37:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t153, ptr %lp11
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t155 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %t155
  %t156 = load ptr, ptr %l2, !tbaa !29
  store ptr %t156, ptr %l87, !tbaa !29
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t159 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t157)
  store i32 %t159, ptr %l89
  br label %bb38
bb38:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t161 = load ptr, ptr %l87, !tbaa !29
  %t162 = load i32, ptr %l89, !tbaa !23
  %t164 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t161, i32 %t162, i64 %t160)
  store i64 %t164, ptr %l91
  br label %bb39
bb39:
  %t165 = load i64, ptr %l91, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb40, label %bb41
bb40:
  %t170 = load ptr, ptr %lp11
  store ptr %t170, ptr %l94, !tbaa !29
  %t171 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call i64 @compiler_2ffree_2eorig(i64 %t171, i64 %t172)
  store i64 %t175, ptr %l97
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t176 = load ptr, ptr %l94, !tbaa !29
  %t177 = load i64, ptr %l97, !tbaa !24
  %t178 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t176, i64 %t177)
  store i64 %t178, ptr %l98
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t179 = load ptr, ptr %lp11
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t179
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %rv
  br label %ret
bb45:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t183 = load ptr, ptr %l100, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 8}
  %t189 = icmp eq i64 %t187, 4
  store i1 %t189, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l101, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l13, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l13, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t204 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t197, ptr %t201)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l109
  br label %bb51
bb51:
  %t205 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t205, ptr %lp14
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  %t207 = load ptr, ptr %lp14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %t207
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Elem", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t215 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t208, ptr %t212)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t215, ptr %l113
  br label %bb52
bb52:
  %t216 = load ptr, ptr %l2, !tbaa !29
  store ptr %t216, ptr %l114, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Elem", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t221)
  store i32 %t223, ptr %l118
  br label %bb53
bb53:
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load i32, ptr %l118, !tbaa !23
  %t226 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t226, ptr %l119
  br label %bb54
bb54:
  %t227 = load ptr, ptr %l114, !tbaa !29
  %t228 = load i32, ptr %l119, !tbaa !23
  %t229 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t227, i32 %t228, i64 -1)
  store i64 %t229, ptr %l120
  br label %bb55
bb55:
  %t230 = load i64, ptr %l120, !tbaa !24
  store i64 %t230, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = icmp sge i64 %t231, 0
  br i1 %t233, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %lp14
  store ptr %t235, ptr %l123, !tbaa !29
  %t236 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t240 = call i64 @compiler_2ffree_2eorig(i64 %t236, i64 %t237)
  store i64 %t240, ptr %l126
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t241 = load ptr, ptr %l123, !tbaa !29
  %t242 = load i64, ptr %l126, !tbaa !24
  %t243 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t241, i64 %t242)
  store i64 %t243, ptr %l127
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t244 = load ptr, ptr %lp14
  %t245 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t244
  call void @__olang_scope_close(ptr %s7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t245, ptr %rv
  br label %ret
bb61:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t248 = load ptr, ptr %l129, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb62, label %bb63
bb62:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 8}
  %t254 = icmp eq i64 %t252, 5
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb63
bb63:
  %t255 = load i1, ptr %l130, !tbaa !21
  br i1 %t255, label %bb64, label %bb65
bb64:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l16, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Payload", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t269 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t262, ptr %t266)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t269, ptr %l138
  br label %bb67
bb67:
  %t270 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t270, ptr %rv
  br label %ret
bb68:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = load ptr, ptr %l139, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 8}
  %t278 = icmp eq i64 %t276, 6
  store i1 %t278, ptr %l140, !tbaa !21
  br label %bb70
bb70:
  %t279 = load i1, ptr %l140, !tbaa !21
  br i1 %t279, label %bb71, label %bb72
bb71:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t282, i32 0, i32 2
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l17, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  %t290 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t286, ptr %t287)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l147
  br label %bb74
bb74:
  %t291 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l147
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %rv
  br label %ret
bb75:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t293 = load ptr, ptr %l148, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb76, label %bb77
bb76:
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 8}
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l149, !tbaa !21
  br label %bb77
bb77:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb89
bb80:
  %t301 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t301, ptr %l152
  br label %bb81
bb81:
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t302, ptr %lp18
  %t303 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l152
  %t304 = load ptr, ptr %lp18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %t304
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/free:walker", ptr %t305, i32 0, i32 9
  %t309 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t307)
  store i64 %t309, ptr %l155
  br label %bb82
bb82:
  %t310 = load i64, ptr %l155, !tbaa !24
  %t311 = icmp sgt i64 %t310, 0
  br i1 %t311, label %bb83, label %bb84
bb83:
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l157, !tbaa !29
  %t314 = load ptr, ptr %l157, !tbaa !29
  %t315 = getelementptr %"compiler/free:walker", ptr %t314, i32 0, i32 29
  %t316 = load i64, ptr %t315, !tbaa !24
  %t318 = add i64 %t316, 1
  %t320 = load ptr, ptr %l157, !tbaa !29
  %t321 = getelementptr %"compiler/free:walker", ptr %t320, i32 0, i32 29
  store i64 %t318, ptr %t321, !tbaa !24
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l160, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:walker", ptr %t323, i32 0, i32 9
  store ptr %t325, ptr %l162, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 9
  %t330 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t328)
  store i64 %t330, ptr %l165
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t331 = load i64, ptr %l165, !tbaa !24
  %t332 = sub i64 %t331, 1
  %t333 = load ptr, ptr %l162, !tbaa !29
  %t335 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t333, i64 %t332)
  store ptr %t335, ptr %l167
  br label %bb86
bb86:
  %t336 = load ptr, ptr %l160, !tbaa !29
  %t337 = load ptr, ptr %l167, !tbaa !29
  %t338 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v0, ptr %v2, ptr %t336, ptr %t337)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %l168
  br label %bb87
bb87:
  %t339 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  %t340 = load ptr, ptr %lp18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t339, ptr %t340
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l169, !tbaa !29
  %t342 = load ptr, ptr %l169, !tbaa !29
  %t343 = getelementptr %"compiler/free:walker", ptr %t342, i32 0, i32 29
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = sub i64 %t344, 1
  %t348 = load ptr, ptr %l169, !tbaa !29
  %t349 = getelementptr %"compiler/free:walker", ptr %t348, i32 0, i32 29
  store i64 %t346, ptr %t349, !tbaa !24
  br label %bb88
bb88:
  %t350 = load ptr, ptr %lp18
  %t351 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t350
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t351, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t353 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %l173
  br label %bb93
bb93:
  %t354 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t354, ptr %rv
  br label %ret
bb94:
  call void @__olang_check_failed(ptr @olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v2, ptr %v2, ptr %a2)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v1, ptr %v2, ptr %a1, ptr %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l49 = alloca ptr
  %l61 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l65 = alloca i1
  %l80 = alloca ptr
  %l82 = alloca i64
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i32
  %l111 = alloca ptr
  %l112 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l188 = alloca ptr
  %l198 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l226 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l234 = alloca i1
  %l240 = alloca i1
  %l242 = alloca i64
  %l244 = alloca i64
  %l249 = alloca i64
  %l251 = alloca i64
  %l254 = alloca i1
  %l256 = alloca ptr
  %l258 = alloca i64
  %l259 = alloca i1
  %l261 = alloca ptr
  %l263 = alloca i64
  %l269 = alloca ptr
  %l270 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i64
  %l277 = alloca i64
  %l278 = alloca %"compiler/source:Span"
  %l279 = alloca %"compiler/source:Span"
  %l280 = alloca ptr
  %l281 = alloca i1
  %l290 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l296 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l297 = alloca ptr
  %l298 = alloca i1
  %l308 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l309 = alloca ptr
  %l310 = alloca i1
  %l317 = alloca ptr
  %l318 = alloca i1
  %l324 = alloca ptr
  %l330 = alloca %"compiler/typed:BlockInfo"
  %l336 = alloca ptr
  %l344 = alloca i64
  %l347 = alloca i64
  %l348 = alloca i32
  %l349 = alloca ptr
  %l352 = alloca ptr
  %l353 = alloca i1
  %l374 = alloca { i64, ptr }
  %l381 = alloca ptr
  %l389 = alloca ptr
  %l390 = alloca i1
  %l405 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l408 = alloca i1
  %l414 = alloca i1
  %l427 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l440 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l443 = alloca ptr
  %l444 = alloca i1
  %l453 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l456 = alloca i64
  %l459 = alloca ptr
  %l462 = alloca i64
  %l464 = alloca ptr
  %l466 = alloca i64
  %l469 = alloca i64
  %l472 = alloca ptr
  %l475 = alloca i64
  %l477 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 11
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l49, !tbaa !29
  %t7 = load ptr, ptr %l49, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 11
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = add i64 %t9, 1
  %t13 = load ptr, ptr %l49, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 11
  store i64 %t11, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:walker", ptr %t15, i32 0, i32 13
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 12
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 34
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 12
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l61, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l63
  br label %bb2
bb2:
  %t40 = load %"compiler/source:Span", ptr %l63
  %t41 = load ptr, ptr %l61, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 34
  store %"compiler/source:Span" %t40, ptr %t42
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t44 = load ptr, ptr %l64, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb3, label %bb4
bb3:
  %t47 = load ptr, ptr %l64, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 17}
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l65, !tbaa !21
  br label %bb4
bb4:
  %t51 = load i1, ptr %l65, !tbaa !21
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 0
  %t56 = load %"compiler/source:Span", ptr %t55
  store %"compiler/source:Span" %t56, ptr %l5
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l6, !tbaa !23
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l7, !tbaa !29
  br label %bb7
bb6:
  br label %bb22
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 20
  %t73 = load i32, ptr %l6, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t75, i64 %t76)
  br label %bb8
bb8:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 21
  store ptr %t82, ptr %l80, !tbaa !29
  %t83 = load i32, ptr %l6, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store i64 %t85, ptr %l82, !tbaa !24
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t86)
  store %"compiler/source:Span" %t88, ptr %l84
  br label %bb9
bb9:
  %t89 = load ptr, ptr %l80, !tbaa !29
  %t90 = load i64, ptr %l82, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l84
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t89, i64 %t90, %"compiler/source:Span" %t91)
  br label %bb10
bb10:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t96 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t92, ptr %t93)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l87
  br label %bb11
bb11:
  %t97 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l8
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l6, !tbaa !23
  %t101 = sext i32 %t99 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s1, ptr %t98, i64 %t101, ptr %l8)
  br label %bb12
bb12:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 7
  %t108 = load i32, ptr %l6, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t107, i64 %t110)
  %t114 = extractvalue { i32, i64 } %t113, 1
  %t115 = extractvalue { i32, i64 } %t113, 0
  store i32 %t115, ptr %l98
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb14, label %ok.117, !prof !99
ok.117:
  store i64 %t114, ptr %l97
  br label %bb13
bb13:
  %t118 = load i64, ptr %l97, !tbaa !24
  store i64 %t118, ptr %l92, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb16
bb16:
  %t119 = load i64, ptr %l92, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  br i1 %t122, label %bb17, label %bb18
bb17:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %s1, ptr %t124, i64 %t125, ptr %t126, ptr %l8, %"compiler/source:Span" %t127)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l6, !tbaa !23
  %t136 = sext i32 %t134 to i64
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %t133, i64 %t136, ptr %t137, %"compiler/source:Span" %t138)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb251
bb22:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t144 = load ptr, ptr %l111, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb23, label %bb24
bb23:
  %t147 = load ptr, ptr %l111, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 17}
  %t150 = icmp eq i64 %t148, 1
  store i1 %t150, ptr %l112, !tbaa !21
  br label %bb24
bb24:
  %t151 = load i1, ptr %l112, !tbaa !21
  br i1 %t151, label %bb25, label %bb26
bb25:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l10
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l11, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l12, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l10
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t173 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t170, %"compiler/source:Span" %t171, ptr %t172, ptr %t173)
  br label %bb28
bb28:
  br label %bb251
bb29:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t179 = load ptr, ptr %l125, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb30, label %bb31
bb30:
  %t182 = load ptr, ptr %l125, !tbaa !29
  %t183 = load i64, ptr %t182, !range !{i64 0, i64 17}
  %t185 = icmp eq i64 %t183, 2
  store i1 %t185, ptr %l126, !tbaa !21
  br label %bb31
bb31:
  %t186 = load i1, ptr %l126, !tbaa !21
  br i1 %t186, label %bb32, label %bb33
bb32:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr }, ptr %t189, i32 0, i32 0
  %t191 = load %"compiler/source:Span", ptr %t190
  store %"compiler/source:Span" %t191, ptr %l13
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l14, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l13
  %t201 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %t199, %"compiler/source:Span" %t200, ptr %t201)
  br label %bb35
bb35:
  br label %bb251
bb36:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t206 = load ptr, ptr %l136, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l136, !tbaa !29
  %t210 = load i64, ptr %t209, !range !{i64 0, i64 17}
  %t212 = icmp eq i64 %t210, 3
  store i1 %t212, ptr %l137, !tbaa !21
  br label %bb38
bb38:
  %t213 = load i1, ptr %l137, !tbaa !21
  br i1 %t213, label %bb39, label %bb40
bb39:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [3 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l15, !tbaa !29
  br label %bb41
bb40:
  br label %bb55
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/typed:If", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t220, ptr %t224)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l145
  br label %bb42
bb42:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/free:walker", ptr %t228, i32 0, i32 11
  %t231 = load i64, ptr %t230, !tbaa !24
  store i64 %t231, ptr %l16, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l15, !tbaa !29
  %t236 = getelementptr %"compiler/typed:If", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t233, ptr %t237)
  br label %bb43
bb43:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:walker", ptr %t240, i32 0, i32 11
  %t243 = load i64, ptr %t242, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l17, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:walker", ptr %t247, i32 0, i32 11
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l18, !tbaa !24
  %t252 = load ptr, ptr %l15, !tbaa !29
  %t254 = getelementptr %"compiler/typed:If", ptr %t252, i32 0, i32 2
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb44, label %bb45
bb44:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l160, !tbaa !29
  %t262 = load ptr, ptr %l15, !tbaa !29
  %t264 = getelementptr %"compiler/typed:If", ptr %t262, i32 0, i32 2
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = icmp eq ptr %t265, null
  br i1 %t267, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d8246f320a19bbf9_8add34a618744eed)
  unreachable
bb47:
  br label %bb48
bb48:
  %t269 = load ptr, ptr %l15, !tbaa !29
  %t271 = getelementptr %"compiler/typed:If", ptr %t269, i32 0, i32 2
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t273 = load ptr, ptr %l160, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t273, ptr %t272)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/free:walker", ptr %t275, i32 0, i32 16
  %t278 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t277, i64 %t278)
  br label %bb51
bb51:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/free:walker", ptr %t281, i32 0, i32 17
  %t284 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t283, i64 %t284)
  br label %bb52
bb52:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/free:walker", ptr %t287, i32 0, i32 18
  %t290 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t289, i64 %t290)
  br label %bb53
bb53:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/free:walker", ptr %t293, i32 0, i32 19
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/free:walker", ptr %t296, i32 0, i32 11
  %t299 = load i64, ptr %t298, !tbaa !24
  %t301 = sub i64 %t299, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t295, i64 %t301)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb251
bb55:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t305 = load ptr, ptr %l180, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb56, label %bb57
bb56:
  %t308 = load ptr, ptr %l180, !tbaa !29
  %t309 = load i64, ptr %t308, !range !{i64 0, i64 17}
  %t311 = icmp eq i64 %t309, 4
  store i1 %t311, ptr %l181, !tbaa !21
  br label %bb57
bb57:
  %t312 = load i1, ptr %l181, !tbaa !21
  br i1 %t312, label %bb58, label %bb59
bb58:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [3 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t315, i32 0, i32 1
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l19, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [3 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t321, i32 0, i32 2
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l20, !tbaa !29
  br label %bb60
bb59:
  br label %bb68
bb60:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l188, !tbaa !29
  %t326 = load ptr, ptr %l188, !tbaa !29
  %t327 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 23
  %t328 = load i64, ptr %t327, !tbaa !24
  %t330 = add i64 %t328, 1
  %t332 = load ptr, ptr %l188, !tbaa !29
  %t333 = getelementptr %"compiler/free:walker", ptr %t332, i32 0, i32 23
  store i64 %t330, ptr %t333, !tbaa !24
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t334, ptr %t335)
  br label %bb61
bb61:
  %t338 = load ptr, ptr %l20, !tbaa !29
  %t340 = icmp eq ptr %t338, null
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb62, label %bb63
bb62:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t344, ptr %t345)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l198, !tbaa !29
  %t349 = load ptr, ptr %l198, !tbaa !29
  %t350 = getelementptr %"compiler/free:walker", ptr %t349, i32 0, i32 23
  %t351 = load i64, ptr %t350, !tbaa !24
  %t353 = sub i64 %t351, 1
  %t355 = load ptr, ptr %l198, !tbaa !29
  %t356 = getelementptr %"compiler/free:walker", ptr %t355, i32 0, i32 23
  store i64 %t353, ptr %t356, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/free:walker", ptr %t357, i32 0, i32 14
  %t360 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t359, i64 %t360)
  br label %bb66
bb66:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/free:walker", ptr %t363, i32 0, i32 15
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/free:walker", ptr %t366, i32 0, i32 11
  %t369 = load i64, ptr %t368, !tbaa !24
  %t371 = sub i64 %t369, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t365, i64 %t371)
  br label %bb67
bb67:
  br label %bb251
bb68:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t375 = load ptr, ptr %l209, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb69, label %bb70
bb69:
  %t378 = load ptr, ptr %l209, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 17}
  %t381 = icmp eq i64 %t379, 6
  store i1 %t381, ptr %l210, !tbaa !21
  br label %bb70
bb70:
  %t382 = load i1, ptr %l210, !tbaa !21
  br i1 %t382, label %bb71, label %bb72
bb71:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr }, ptr %t385, i32 0, i32 1
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l21, !tbaa !29
  br label %bb77
bb72:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t390 = load ptr, ptr %l215, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb73, label %bb74
bb73:
  %t393 = load ptr, ptr %l215, !tbaa !29
  %t394 = load i64, ptr %t393, !range !{i64 0, i64 17}
  %t396 = icmp eq i64 %t394, 16
  store i1 %t396, ptr %l216, !tbaa !21
  br label %bb74
bb74:
  %t397 = load i1, ptr %l216, !tbaa !21
  br i1 %t397, label %bb75, label %bb76
bb75:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l21, !tbaa !29
  br label %bb77
bb76:
  br label %bb126
bb77:
  %t404 = load ptr, ptr %l21, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s10
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l21, !tbaa !29
  %t414 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s10, ptr %t410, ptr %t411)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t414, ptr %l226
  br label %bb80
bb79:
  br label %bb112
bb80:
  %t415 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l226
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t415, ptr %l22
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/free:walker", ptr %t416, i32 0, i32 2
  %t419 = load i1, ptr %t418, !tbaa !21
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb81, label %bb82
bb81:
  %t423 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %s10, ptr %t423, ptr %l22)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/free:walker", ptr %t426, i32 0, i32 2
  %t429 = load i1, ptr %t428, !tbaa !21
  br i1 %t429, label %bb85, label %bb86
bb85:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/free:walker", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = getelementptr %"compiler/free:Free", ptr %t434, i32 0, i32 67
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/free:walker", ptr %t437, i32 0, i32 1
  %t440 = load i64, ptr %t439, !tbaa !24
  %t443 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t436, i64 %t440)
  store i1 %t443, ptr %l240
  br label %bb87
bb86:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb88
bb87:
  %t444 = load i1, ptr %l240, !tbaa !21
  store i1 %t444, ptr %l234, !tbaa !21
  br label %bb88
bb88:
  %t445 = load i1, ptr %l234, !tbaa !21
  br i1 %t445, label %bb89, label %bb90
bb89:
  store ptr %l22, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb91
bb90:
  br label %bb111
bb91:
  %t447 = load i64, ptr %l24, !tbaa !24
  store i64 %t447, ptr %l242, !tbaa !24
  %t448 = load ptr, ptr %l23, !tbaa !29
  %t450 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %t448)
  store i64 %t450, ptr %l244
  br label %bb92
bb92:
  %t451 = load i64, ptr %l242, !tbaa !24
  %t452 = load i64, ptr %l244, !tbaa !24
  %t453 = icmp slt i64 %t451, %t452
  %t455 = xor i1 %t453, true
  br i1 %t455, label %bb93, label %bb94
bb93:
  br label %bb110
bb94:
  br label %bb95
bb95:
  %t457 = load ptr, ptr %l23, !tbaa !29
  %t458 = load i64, ptr %l24, !tbaa !24
  %t461 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %t457, i64 %t458)
  store i64 %t461, ptr %l249
  br label %bb96
bb96:
  %t462 = load i64, ptr %l249, !tbaa !24
  store i64 %t462, ptr %l25, !tbaa !24
  %t463 = load i64, ptr %l25, !tbaa !24
  %t465 = call i64 @compiler_2ffree_2eokind(i64 %t463)
  store i64 %t465, ptr %l251
  br label %bb97
bb97:
  %t466 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t467 = load i64, ptr %l251, !tbaa !24
  %t469 = icmp eq i64 %t467, %t466
  br i1 %t469, label %bb98, label %bb99
bb98:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/free:walker", ptr %t471, i32 0, i32 0
  %t474 = load ptr, ptr %t473, !tbaa !29
  store ptr %t474, ptr %l256, !tbaa !29
  %t475 = load i64, ptr %l25, !tbaa !24
  %t477 = call i64 @compiler_2ffree_2eoval(i64 %t475)
  store i64 %t477, ptr %l258
  br label %bb100
bb99:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb102
bb100:
  %t478 = load ptr, ptr %l256, !tbaa !29
  %t479 = load i64, ptr %l258, !tbaa !24
  %t480 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t478, i64 %t479)
  store i1 %t480, ptr %l259
  br label %bb101
bb101:
  %t481 = load i1, ptr %l259, !tbaa !21
  store i1 %t481, ptr %l254, !tbaa !21
  br label %bb102
bb102:
  %t482 = load i1, ptr %l254, !tbaa !21
  br i1 %t482, label %bb103, label %bb104
bb103:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/free:walker", ptr %t483, i32 0, i32 50
  store ptr %t485, ptr %l261, !tbaa !29
  %t486 = load i64, ptr %l25, !tbaa !24
  %t488 = call i64 @compiler_2ffree_2eoval(i64 %t486)
  store i64 %t488, ptr %l263
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t489 = load ptr, ptr %l261, !tbaa !29
  %t490 = load i64, ptr %l263, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t489, i64 %t490)
  br label %bb106
bb106:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/free:walker", ptr %t491, i32 0, i32 51
  %t494 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t493, i64 %t494)
  br label %bb107
bb107:
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t497 = load i64, ptr %l24, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l24, !tbaa !24
  br label %bb91
bb110:
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s10)
  br label %bb112
bb112:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t502 = load ptr, ptr %l269, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb113, label %bb114
bb113:
  %t505 = load ptr, ptr %l269, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 16
  store i1 %t508, ptr %l270, !tbaa !21
  br label %bb114
bb114:
  %t509 = load i1, ptr %l270, !tbaa !21
  br i1 %t509, label %bb115, label %bb116
bb115:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 0
  %t514 = load %"compiler/source:Span", ptr %t513
  store %"compiler/source:Span" %t514, ptr %l26
  br label %bb117
bb116:
  br label %bb120
bb117:
  store %olang.scope zeroinitializer, ptr %s17
  %t516 = load ptr, ptr %l0, !tbaa !29
  store ptr %t516, ptr %l275, !tbaa !29
  %t517 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t517, ptr %l276, !tbaa !24
  %t518 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  store i64 %t518, ptr %l277, !tbaa !24
  %t519 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t519, ptr %l278
  %t520 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s17, i32 0, i32 0)
  store %"compiler/source:Span" %t520, ptr %l279
  br label %bb118
bb118:
  %t521 = load ptr, ptr %l275, !tbaa !29
  %t522 = load i64, ptr %l276, !tbaa !24
  %t523 = load i64, ptr %l277, !tbaa !24
  %t524 = load %"compiler/source:Span", ptr %l278
  %t525 = load %"compiler/source:Span", ptr %l279
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t521, i64 %t522, i64 %t523, %"compiler/source:Span" %t524, %"compiler/source:Span" %t525, i64 -1)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s17)
  br label %bb125
bb120:
  br i1 true, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_5d7536cc463ccac1_135a9313c745645)
  unreachable
bb125:
  br label %bb251
bb126:
  %t526 = load ptr, ptr %l1, !tbaa !29
  store ptr %t526, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t527 = load ptr, ptr %l280, !tbaa !29
  %t528 = icmp ne ptr %t527, null
  br i1 %t528, label %bb127, label %bb128
bb127:
  %t530 = load ptr, ptr %l280, !tbaa !29
  %t531 = load i64, ptr %t530, !range !{i64 0, i64 17}
  %t533 = icmp eq i64 %t531, 10
  store i1 %t533, ptr %l281, !tbaa !21
  br label %bb128
bb128:
  %t534 = load i1, ptr %l281, !tbaa !21
  br i1 %t534, label %bb129, label %bb130
bb129:
  %t535 = load ptr, ptr %l1, !tbaa !29
  %t537 = getelementptr { i64, [3 x i64] }, ptr %t535, i32 0, i32 1
  %t538 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t537, i32 0, i32 1
  %t539 = load ptr, ptr %t538
  store ptr %t539, ptr %l27, !tbaa !29
  %t541 = load ptr, ptr %l1, !tbaa !29
  %t543 = getelementptr { i64, [3 x i64] }, ptr %t541, i32 0, i32 1
  %t544 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t543, i32 0, i32 2
  %t545 = load ptr, ptr %t544
  store ptr %t545, ptr %l28, !tbaa !29
  br label %bb131
bb130:
  br label %bb137
bb131:
  store %olang.scope zeroinitializer, ptr %s19
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load ptr, ptr %l27, !tbaa !29
  %t551 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %t547, ptr %t548)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t551, ptr %l290
  br label %bb132
bb132:
  %t552 = load ptr, ptr %l28, !tbaa !29
  %t554 = icmp eq ptr %t552, null
  %t556 = xor i1 %t554, true
  br i1 %t556, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s20
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load ptr, ptr %l28, !tbaa !29
  %t562 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s20, ptr %t558, ptr %t559)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t562, ptr %l296
  br label %bb135
bb134:
  br label %bb136
bb135:
  call void @__olang_scope_close(ptr %s20)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s19)
  br label %bb251
bb137:
  %t563 = load ptr, ptr %l1, !tbaa !29
  store ptr %t563, ptr %l297, !tbaa !29
  store i1 false, ptr %l298, !tbaa !21
  %t564 = load ptr, ptr %l297, !tbaa !29
  %t565 = icmp ne ptr %t564, null
  br i1 %t565, label %bb138, label %bb139
bb138:
  %t567 = load ptr, ptr %l297, !tbaa !29
  %t568 = load i64, ptr %t567, !range !{i64 0, i64 17}
  %t570 = icmp eq i64 %t568, 9
  store i1 %t570, ptr %l298, !tbaa !21
  br label %bb139
bb139:
  %t571 = load i1, ptr %l298, !tbaa !21
  br i1 %t571, label %bb140, label %bb141
bb140:
  %t572 = load ptr, ptr %l1, !tbaa !29
  %t574 = getelementptr { i64, [3 x i64] }, ptr %t572, i32 0, i32 1
  %t575 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t574, i32 0, i32 2
  %t576 = load ptr, ptr %t575
  store ptr %t576, ptr %l29, !tbaa !29
  br label %bb142
bb141:
  br label %bb147
bb142:
  %t578 = load ptr, ptr %l29, !tbaa !29
  %t580 = icmp eq ptr %t578, null
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb143, label %bb144
bb143:
  store %olang.scope zeroinitializer, ptr %s22
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load ptr, ptr %l29, !tbaa !29
  %t588 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t584, ptr %t585)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t588, ptr %l308
  br label %bb145
bb144:
  br label %bb146
bb145:
  call void @__olang_scope_close(ptr %s22)
  br label %bb146
bb146:
  br label %bb251
bb147:
  %t589 = load ptr, ptr %l1, !tbaa !29
  store ptr %t589, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t590 = load ptr, ptr %l309, !tbaa !29
  %t591 = icmp ne ptr %t590, null
  br i1 %t591, label %bb148, label %bb149
bb148:
  %t593 = load ptr, ptr %l309, !tbaa !29
  %t594 = load i64, ptr %t593, !range !{i64 0, i64 17}
  %t596 = icmp eq i64 %t594, 11
  store i1 %t596, ptr %l310, !tbaa !21
  br label %bb149
bb149:
  %t597 = load i1, ptr %l310, !tbaa !21
  br i1 %t597, label %bb150, label %bb151
bb150:
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t600 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 1
  %t601 = getelementptr { %"compiler/source:Span", ptr }, ptr %t600, i32 0, i32 1
  %t602 = load ptr, ptr %t601
  store ptr %t602, ptr %l30, !tbaa !29
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t605 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t604, ptr %t605)
  br label %bb153
bb153:
  br label %bb251
bb154:
  %t608 = load ptr, ptr %l1, !tbaa !29
  store ptr %t608, ptr %l317, !tbaa !29
  store i1 false, ptr %l318, !tbaa !21
  %t609 = load ptr, ptr %l317, !tbaa !29
  %t610 = icmp ne ptr %t609, null
  br i1 %t610, label %bb155, label %bb156
bb155:
  %t612 = load ptr, ptr %l317, !tbaa !29
  %t613 = load i64, ptr %t612, !range !{i64 0, i64 17}
  %t615 = icmp eq i64 %t613, 12
  store i1 %t615, ptr %l318, !tbaa !21
  br label %bb156
bb156:
  %t616 = load i1, ptr %l318, !tbaa !21
  br i1 %t616, label %bb157, label %bb158
bb157:
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t619 = getelementptr { i64, [3 x i64] }, ptr %t617, i32 0, i32 1
  %t620 = getelementptr { %"compiler/source:Span", ptr }, ptr %t619, i32 0, i32 1
  %t621 = load ptr, ptr %t620
  store ptr %t621, ptr %l31, !tbaa !29
  br label %bb159
bb158:
  br label %bb172
bb159:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t625 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t623)
  store ptr %t625, ptr %l324
  br label %bb160
bb160:
  %t626 = load ptr, ptr %l324, !tbaa !29
  %t628 = getelementptr %"compiler/typed:Body", ptr %t626, i32 0, i32 8
  %t629 = load ptr, ptr %l31, !tbaa !29
  %t631 = getelementptr %"compiler/typed:Block", ptr %t629, i32 0, i32 0
  %t632 = load i32, ptr %t631, !tbaa !23
  %t634 = sext i32 %t632 to i64
  %t637 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t628, i64 %t634)
  store %"compiler/typed:BlockInfo" %t637, ptr %l330
  br label %bb161
bb161:
  %t638 = getelementptr %"compiler/typed:BlockInfo", ptr %l330, i32 0, i32 1
  %t639 = load i32, ptr %t638, !range !{i32 0, i32 9}
  %t641 = trunc i64 7 to i32
  %t642 = icmp eq i32 %t639, %t641
  br i1 %t642, label %bb162, label %bb163
bb162:
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t646 = getelementptr %"compiler/free:walker", ptr %t644, i32 0, i32 58
  %t647 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t646, i64 %t647)
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  %t650 = load ptr, ptr %l0, !tbaa !29
  store ptr %t650, ptr %l336, !tbaa !29
  %t651 = load ptr, ptr %l336, !tbaa !29
  %t652 = getelementptr %"compiler/free:walker", ptr %t651, i32 0, i32 28
  %t653 = load i64, ptr %t652, !tbaa !24
  %t655 = add i64 %t653, 1
  %t657 = load ptr, ptr %l336, !tbaa !29
  %t658 = getelementptr %"compiler/free:walker", ptr %t657, i32 0, i32 28
  store i64 %t655, ptr %t658, !tbaa !24
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/free:walker", ptr %t659, i32 0, i32 53
  %t662 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t661, i64 %t662)
  br label %bb166
bb166:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t666 = load ptr, ptr %l31, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t665, ptr %t666)
  br label %bb167
bb167:
  %t669 = load ptr, ptr %l0, !tbaa !29
  %t671 = getelementptr %"compiler/free:walker", ptr %t669, i32 0, i32 53
  %t673 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t671)
  %t674 = extractvalue { i32, i64 } %t673, 1
  %t675 = extractvalue { i32, i64 } %t673, 0
  store i32 %t675, ptr %l348
  %t676 = icmp ne i32 %t675, 0
  br i1 %t676, label %bb169, label %ok.677, !prof !99
ok.677:
  store i64 %t674, ptr %l347
  br label %bb168
bb168:
  %t678 = load i64, ptr %l347, !tbaa !24
  store i64 %t678, ptr %l344, !tbaa !24
  br label %bb171
bb169:
  br label %bb170
bb170:
  call void @__olang_ert_req_clear()
  br label %bb171
bb171:
  %t679 = load ptr, ptr %l0, !tbaa !29
  store ptr %t679, ptr %l349, !tbaa !29
  %t680 = load ptr, ptr %l349, !tbaa !29
  %t681 = getelementptr %"compiler/free:walker", ptr %t680, i32 0, i32 28
  %t682 = load i64, ptr %t681, !tbaa !24
  %t684 = sub i64 %t682, 1
  %t686 = load ptr, ptr %l349, !tbaa !29
  %t687 = getelementptr %"compiler/free:walker", ptr %t686, i32 0, i32 28
  store i64 %t684, ptr %t687, !tbaa !24
  br label %bb251
bb172:
  %t688 = load ptr, ptr %l1, !tbaa !29
  store ptr %t688, ptr %l352, !tbaa !29
  store i1 false, ptr %l353, !tbaa !21
  %t689 = load ptr, ptr %l352, !tbaa !29
  %t690 = icmp ne ptr %t689, null
  br i1 %t690, label %bb173, label %bb174
bb173:
  %t692 = load ptr, ptr %l352, !tbaa !29
  %t693 = load i64, ptr %t692, !range !{i64 0, i64 17}
  %t695 = icmp eq i64 %t693, 13
  store i1 %t695, ptr %l353, !tbaa !21
  br label %bb174
bb174:
  %t696 = load i1, ptr %l353, !tbaa !21
  br i1 %t696, label %bb175, label %bb176
bb175:
  %t697 = load ptr, ptr %l1, !tbaa !29
  %t699 = getelementptr { i64, [3 x i64] }, ptr %t697, i32 0, i32 1
  %t700 = getelementptr { %"compiler/source:Span", ptr }, ptr %t699, i32 0, i32 1
  %t701 = load ptr, ptr %t700
  store ptr %t701, ptr %l32, !tbaa !29
  br label %bb177
bb176:
  br label %bb193
bb177:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t705 = getelementptr %"compiler/free:walker", ptr %t703, i32 0, i32 0
  %t706 = load ptr, ptr %t705, !tbaa !29
  %t708 = getelementptr %"compiler/free:Free", ptr %t706, i32 0, i32 36
  %t709 = load ptr, ptr %l0, !tbaa !29
  %t711 = getelementptr %"compiler/free:walker", ptr %t709, i32 0, i32 1
  %t712 = load i64, ptr %t711, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t708, i64 %t712, i1 true)
  br label %bb178
bb178:
  %t715 = load ptr, ptr %l0, !tbaa !29
  %t716 = load ptr, ptr %l32, !tbaa !29
  %t718 = getelementptr %"compiler/typed:Join", ptr %t716, i32 0, i32 0
  %t719 = load ptr, ptr %t718, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t715, ptr %t719)
  br label %bb179
bb179:
  %t722 = load ptr, ptr %l32, !tbaa !29
  %t724 = getelementptr %"compiler/typed:Join", ptr %t722, i32 0, i32 2
  %t725 = load { i64, ptr }, ptr %t724, !tbaa !27
  store { i64, ptr } %t725, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t727 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t729 = extractvalue { i64, ptr } %t727, 0
  store i64 %t729, ptr %l35, !tbaa !24
  br label %bb180
bb180:
  %t731 = load i64, ptr %l34, !tbaa !24
  %t732 = load i64, ptr %l35, !tbaa !24
  %t735 = icmp slt i64 %t731, %t732
  %t737 = xor i1 %t735, true
  br i1 %t737, label %bb181, label %bb182
bb181:
  br label %bb192
bb182:
  br label %bb183
bb183:
  %t739 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t739, ptr %l374, !tbaa !27
  %t740 = load i64, ptr %l34, !tbaa !24
  %t742 = getelementptr { i64, ptr }, ptr %l374, i32 0, i32 1
  %t743 = load ptr, ptr %t742, !tbaa !27
  %t744 = getelementptr ptr, ptr %t743, i64 %t740
  %t745 = load ptr, ptr %t744, !tbaa !39
  store ptr %t745, ptr %l36, !tbaa !29
  %t747 = load ptr, ptr %l36, !tbaa !29
  %t749 = getelementptr %"compiler/typed:Clause", ptr %t747, i32 0, i32 3
  %t750 = load ptr, ptr %t749, !tbaa !29
  %t752 = icmp eq ptr %t750, null
  %t754 = xor i1 %t752, true
  br i1 %t754, label %bb184, label %bb185
bb184:
  %t756 = load ptr, ptr %l0, !tbaa !29
  store ptr %t756, ptr %l381, !tbaa !29
  %t757 = load ptr, ptr %l36, !tbaa !29
  %t759 = getelementptr %"compiler/typed:Clause", ptr %t757, i32 0, i32 3
  %t760 = load ptr, ptr %t759, !tbaa !29
  %t762 = icmp eq ptr %t760, null
  br i1 %t762, label %bb186, label %bb187
bb185:
  br label %bb190
bb186:
  call void @__olang_check_failed(ptr @olang_loc_11c10ff2df4ccb13_a4bbf1166c590ff7)
  unreachable
bb187:
  br label %bb188
bb188:
  %t764 = load ptr, ptr %l36, !tbaa !29
  %t766 = getelementptr %"compiler/typed:Clause", ptr %t764, i32 0, i32 3
  %t767 = load ptr, ptr %t766, !tbaa !29
  %t768 = load ptr, ptr %l381, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t768, ptr %t767)
  br label %bb189
bb189:
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t770 = load i64, ptr %l34, !tbaa !24
  %t772 = add i64 %t770, 1
  store i64 %t772, ptr %l34, !tbaa !24
  br label %bb180
bb192:
  br label %bb251
bb193:
  %t774 = load ptr, ptr %l1, !tbaa !29
  store ptr %t774, ptr %l389, !tbaa !29
  store i1 false, ptr %l390, !tbaa !21
  %t775 = load ptr, ptr %l389, !tbaa !29
  %t776 = icmp ne ptr %t775, null
  br i1 %t776, label %bb194, label %bb195
bb194:
  %t778 = load ptr, ptr %l389, !tbaa !29
  %t779 = load i64, ptr %t778, !range !{i64 0, i64 17}
  %t781 = icmp eq i64 %t779, 14
  store i1 %t781, ptr %l390, !tbaa !21
  br label %bb195
bb195:
  %t782 = load i1, ptr %l390, !tbaa !21
  br i1 %t782, label %bb196, label %bb197
bb196:
  %t783 = load ptr, ptr %l1, !tbaa !29
  %t785 = getelementptr { i64, [3 x i64] }, ptr %t783, i32 0, i32 1
  %t786 = getelementptr { %"compiler/source:Span", ptr }, ptr %t785, i32 0, i32 0
  %t787 = load %"compiler/source:Span", ptr %t786
  store %"compiler/source:Span" %t787, ptr %l37
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t791 = getelementptr { i64, [3 x i64] }, ptr %t789, i32 0, i32 1
  %t792 = getelementptr { %"compiler/source:Span", ptr }, ptr %t791, i32 0, i32 1
  %t793 = load ptr, ptr %t792
  store ptr %t793, ptr %l38, !tbaa !29
  br label %bb198
bb197:
  br label %bb222
bb198:
  store %olang.scope zeroinitializer, ptr %s32
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/free:walker", ptr %t795, i32 0, i32 0
  %t798 = load ptr, ptr %t797, !tbaa !29
  %t800 = getelementptr %"compiler/free:Free", ptr %t798, i32 0, i32 36
  %t801 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/free:walker", ptr %t801, i32 0, i32 1
  %t804 = load i64, ptr %t803, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t800, i64 %t804, i1 true)
  br label %bb199
bb199:
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load ptr, ptr %l38, !tbaa !29
  %t810 = getelementptr %"compiler/typed:Spawn", ptr %t808, i32 0, i32 1
  %t811 = load ptr, ptr %t810, !tbaa !29
  %t814 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s32, ptr %t807, ptr %t811)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t814, ptr %l405
  br label %bb200
bb200:
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/free:walker", ptr %t815, i32 0, i32 2
  %t818 = load i1, ptr %t817, !tbaa !21
  br i1 %t818, label %bb201, label %bb202
bb201:
  %t820 = load ptr, ptr %l0, !tbaa !29
  %t822 = getelementptr %"compiler/free:walker", ptr %t820, i32 0, i32 0
  %t823 = load ptr, ptr %t822, !tbaa !29
  %t825 = getelementptr %"compiler/free:Free", ptr %t823, i32 0, i32 67
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t828 = getelementptr %"compiler/free:walker", ptr %t826, i32 0, i32 1
  %t829 = load i64, ptr %t828, !tbaa !24
  %t832 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t825, i64 %t829)
  store i1 %t832, ptr %l414
  br label %bb203
bb202:
  store i1 false, ptr %l408, !tbaa !21
  br label %bb204
bb203:
  %t833 = load i1, ptr %l414, !tbaa !21
  store i1 %t833, ptr %l408, !tbaa !21
  br label %bb204
bb204:
  %t834 = load i1, ptr %l408, !tbaa !21
  br i1 %t834, label %bb205, label %bb206
bb205:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load %"compiler/source:Span", ptr %l37
  %t837 = load ptr, ptr %l38, !tbaa !29
  %t839 = getelementptr %"compiler/typed:Spawn", ptr %t837, i32 0, i32 1
  %t840 = load ptr, ptr %t839, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedToTask(ptr %v0, ptr %v1, ptr %t835, %"compiler/source:Span" %t836, ptr %t840)
  br label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb208
bb208:
  %t844 = load ptr, ptr %l38, !tbaa !29
  %t846 = getelementptr %"compiler/typed:Spawn", ptr %t844, i32 0, i32 2
  %t847 = load { i64, ptr }, ptr %t846, !tbaa !27
  store { i64, ptr } %t847, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t849 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t851 = extractvalue { i64, ptr } %t849, 0
  store i64 %t851, ptr %l41, !tbaa !24
  br label %bb209
bb209:
  %t853 = load i64, ptr %l40, !tbaa !24
  %t854 = load i64, ptr %l41, !tbaa !24
  %t857 = icmp slt i64 %t853, %t854
  %t859 = xor i1 %t857, true
  br i1 %t859, label %bb210, label %bb211
bb210:
  br label %bb221
bb211:
  br label %bb212
bb212:
  %t861 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t861, ptr %l427, !tbaa !27
  %t862 = load i64, ptr %l40, !tbaa !24
  %t864 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t865 = load ptr, ptr %t864, !tbaa !27
  %t866 = getelementptr ptr, ptr %t865, i64 %t862
  %t867 = load ptr, ptr %t866, !tbaa !39
  store ptr %t867, ptr %l42, !tbaa !29
  %t869 = load ptr, ptr %l42, !tbaa !29
  %t871 = getelementptr %"compiler/typed:TaskClause", ptr %t869, i32 0, i32 3
  %t872 = load ptr, ptr %t871, !tbaa !29
  %t874 = icmp eq ptr %t872, null
  %t876 = xor i1 %t874, true
  br i1 %t876, label %bb213, label %bb214
bb213:
  store %olang.scope zeroinitializer, ptr %s36
  %t878 = load ptr, ptr %l0, !tbaa !29
  store ptr %t878, ptr %l434, !tbaa !29
  %t879 = load ptr, ptr %l42, !tbaa !29
  %t881 = getelementptr %"compiler/typed:TaskClause", ptr %t879, i32 0, i32 3
  %t882 = load ptr, ptr %t881, !tbaa !29
  %t884 = icmp eq ptr %t882, null
  br i1 %t884, label %bb215, label %bb216
bb214:
  br label %bb219
bb215:
  call void @__olang_check_failed(ptr @olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8)
  unreachable
bb216:
  br label %bb217
bb217:
  %t886 = load ptr, ptr %l42, !tbaa !29
  %t888 = getelementptr %"compiler/typed:TaskClause", ptr %t886, i32 0, i32 3
  %t889 = load ptr, ptr %t888, !tbaa !29
  %t890 = load ptr, ptr %l434, !tbaa !29
  %t892 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s36, ptr %t890, ptr %t889)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t892, ptr %l440
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s36)
  br label %bb219
bb219:
  br label %bb220
bb220:
  %t893 = load i64, ptr %l40, !tbaa !24
  %t895 = add i64 %t893, 1
  store i64 %t895, ptr %l40, !tbaa !24
  br label %bb209
bb221:
  call void @__olang_scope_close(ptr %s32)
  br label %bb251
bb222:
  %t897 = load ptr, ptr %l1, !tbaa !29
  store ptr %t897, ptr %l443, !tbaa !29
  store i1 false, ptr %l444, !tbaa !21
  %t898 = load ptr, ptr %l443, !tbaa !29
  %t899 = icmp ne ptr %t898, null
  br i1 %t899, label %bb223, label %bb224
bb223:
  %t901 = load ptr, ptr %l443, !tbaa !29
  %t902 = load i64, ptr %t901, !range !{i64 0, i64 17}
  %t904 = icmp eq i64 %t902, 15
  store i1 %t904, ptr %l444, !tbaa !21
  br label %bb224
bb224:
  %t905 = load i1, ptr %l444, !tbaa !21
  br i1 %t905, label %bb225, label %bb226
bb225:
  %t906 = load ptr, ptr %l1, !tbaa !29
  %t908 = getelementptr { i64, [3 x i64] }, ptr %t906, i32 0, i32 1
  %t909 = getelementptr { %"compiler/source:Span", ptr }, ptr %t908, i32 0, i32 0
  %t910 = load %"compiler/source:Span", ptr %t909
  store %"compiler/source:Span" %t910, ptr %l43
  %t912 = load ptr, ptr %l1, !tbaa !29
  %t914 = getelementptr { i64, [3 x i64] }, ptr %t912, i32 0, i32 1
  %t915 = getelementptr { %"compiler/source:Span", ptr }, ptr %t914, i32 0, i32 1
  %t916 = load ptr, ptr %t915
  store ptr %t916, ptr %l44, !tbaa !29
  br label %bb227
bb226:
  br label %bb246
bb227:
  store %olang.scope zeroinitializer, ptr %s38
  %t918 = load ptr, ptr %l0, !tbaa !29
  %t919 = load ptr, ptr %l44, !tbaa !29
  %t922 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s38, ptr %t918, ptr %t919)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t922, ptr %l453
  br label %bb228
bb228:
  %t923 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l453
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t923, ptr %l45
  %t924 = load ptr, ptr %l0, !tbaa !29
  %t926 = getelementptr %"compiler/free:walker", ptr %t924, i32 0, i32 33
  %t928 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t926)
  store i64 %t928, ptr %l456
  br label %bb229
bb229:
  %t929 = load i64, ptr %l456, !tbaa !24
  %t930 = icmp sgt i64 %t929, 0
  br i1 %t930, label %bb230, label %bb231
bb230:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t934 = getelementptr %"compiler/free:walker", ptr %t932, i32 0, i32 33
  store ptr %t934, ptr %l459, !tbaa !29
  %t935 = load ptr, ptr %l0, !tbaa !29
  %t937 = getelementptr %"compiler/free:walker", ptr %t935, i32 0, i32 33
  %t939 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t937)
  store i64 %t939, ptr %l462
  br label %bb232
bb231:
  br label %bb235
bb232:
  %t940 = load i64, ptr %l462, !tbaa !24
  %t941 = sub i64 %t940, 1
  %t942 = load ptr, ptr %l459, !tbaa !29
  %t944 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t942, i64 %t941)
  store ptr %t944, ptr %l464
  br label %bb233
bb233:
  %t945 = load ptr, ptr %l464, !tbaa !29
  %t947 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %s38, ptr %t945, ptr %l45)
  store i64 %t947, ptr %l466
  br label %bb234
bb234:
  br label %bb235
bb235:
  %t948 = load ptr, ptr %l0, !tbaa !29
  %t950 = getelementptr %"compiler/free:walker", ptr %t948, i32 0, i32 10
  %t952 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t950)
  store i64 %t952, ptr %l469
  br label %bb236
bb236:
  %t953 = load i64, ptr %l469, !tbaa !24
  %t954 = icmp sgt i64 %t953, 0
  br i1 %t954, label %bb237, label %bb238
bb237:
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/free:walker", ptr %t956, i32 0, i32 10
  store ptr %t958, ptr %l472, !tbaa !29
  %t959 = load ptr, ptr %l0, !tbaa !29
  %t961 = getelementptr %"compiler/free:walker", ptr %t959, i32 0, i32 10
  %t963 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t961)
  store i64 %t963, ptr %l475
  br label %bb239
bb238:
  br label %bb245
bb239:
  %t964 = load i64, ptr %l475, !tbaa !24
  %t965 = sub i64 %t964, 1
  %t966 = load ptr, ptr %l472, !tbaa !29
  %t968 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t966, i64 %t965)
  store i64 %t968, ptr %l477
  br label %bb240
bb240:
  %t969 = load i64, ptr %l477, !tbaa !24
  store i64 %t969, ptr %l46, !tbaa !24
  %t970 = load i64, ptr %l46, !tbaa !24
  %t972 = icmp sge i64 %t970, 0
  br i1 %t972, label %bb241, label %bb242
bb241:
  store %olang.scope zeroinitializer, ptr %s41
  %t974 = load ptr, ptr %l0, !tbaa !29
  %t975 = load i64, ptr %l46, !tbaa !24
  %t976 = load ptr, ptr %l44, !tbaa !29
  %t977 = load %"compiler/source:Span", ptr %l43
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %s38, ptr %s41, ptr %t974, i64 %t975, ptr %t976, ptr %l45, %"compiler/source:Span" %t977, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, i1 true)
  br label %bb243
bb242:
  br label %bb244
bb243:
  call void @__olang_scope_close(ptr %s41)
  br label %bb244
bb244:
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s38)
  br label %bb251
bb246:
  br i1 true, label %bb247, label %bb248
bb247:
  br label %bb249
bb248:
  br label %bb250
bb249:
  br label %bb251
bb250:
  call void @__olang_check_failed(ptr @olang_loc_ec0dfed271d7eacc_f2c899624053798)
  unreachable
bb251:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t985 = getelementptr %"compiler/free:walker", ptr %t983, i32 0, i32 13
  %t986 = load i64, ptr %l2, !tbaa !24
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t989 = getelementptr %"compiler/free:walker", ptr %t987, i32 0, i32 11
  %t990 = load i64, ptr %t989, !tbaa !24
  %t992 = sub i64 %t990, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t985, i64 %t986, i64 %t992)
  br label %bb252
bb252:
  %t996 = load ptr, ptr %l0, !tbaa !29
  %t997 = load i64, ptr %l3, !tbaa !24
  %t1000 = getelementptr %"compiler/free:walker", ptr %t996, i32 0, i32 12
  store i64 %t997, ptr %t1000, !tbaa !24
  %t1001 = load ptr, ptr %l0, !tbaa !29
  %t1002 = load %"compiler/source:Span", ptr %l4
  %t1005 = getelementptr %"compiler/free:walker", ptr %t1001, i32 0, i32 34
  store %"compiler/source:Span" %t1002, ptr %t1005
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 false, i1 %a6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i64
  %l40 = alloca i1
  %l42 = alloca i64
  %l45 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l70 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca i1
  %l77 = alloca { i64, ptr }
  %l85 = alloca i1
  %l86 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca i64
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca i1
  %l117 = alloca { i64, ptr }
  %l123 = alloca i64
  %l133 = alloca ptr
  %l138 = alloca i64
  %l142 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca i64
  %l167 = alloca i64
  %l169 = alloca i64
  %l174 = alloca i64
  %l176 = alloca i64
  %l179 = alloca i1
  %l181 = alloca i64
  %l185 = alloca i1
  %l190 = alloca ptr
  %l192 = alloca i64
  %l193 = alloca i64
  %l201 = alloca { i64, ptr }
  %l203 = alloca i64
  %l207 = alloca ptr
  %l209 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l219 = alloca i32
  %l221 = alloca i1
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l10, !tbaa !24
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t9)
  store i64 %t11, ptr %l21
  br label %bb2
bb2:
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = load i64, ptr %l21, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb42
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t19 = load i64, ptr %l10, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l26
  br label %bb6
bb6:
  %t23 = load i64, ptr %l26, !tbaa !24
  store i64 %t23, ptr %l11, !tbaa !24
  %t24 = load i64, ptr %l11, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l28
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t28 = load i64, ptr %l28, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 2
  %t35 = load i1, ptr %t34, !tbaa !21
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l31, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l11, !tbaa !24
  %t40 = call i64 @compiler_2ffree_2eoval(i64 %t38)
  store i64 %t40, ptr %l36
  br label %bb13
bb12:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb14
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 31
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l36, !tbaa !24
  %t47 = icmp ne i64 %t45, %t44
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb14
bb14:
  %t49 = load i1, ptr %l34, !tbaa !21
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t50 = load i64, ptr %l11, !tbaa !24
  %t52 = call i64 @compiler_2ffree_2eoval(i64 %t50)
  store i64 %t52, ptr %l42
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load i64, ptr %l42, !tbaa !24
  %t56 = icmp ne i64 %t54, %t53
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l40, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l8, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  %t60 = load i64, ptr %l11, !tbaa !24
  %t62 = call i64 @compiler_2ffree_2eoval(i64 %t60)
  store i64 %t62, ptr %l47
  br label %bb21
bb20:
  br label %bb40
bb21:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t65, ptr %l48
  br label %bb22
bb22:
  %t66 = load i1, ptr %l48, !tbaa !21
  br i1 %t66, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load ptr, ptr %l8, !tbaa !29
  store ptr %t67, ptr %l49, !tbaa !29
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = call i64 @compiler_2ffree_2eoval(i64 %t68)
  store i64 %t70, ptr %l51
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t71 = load ptr, ptr %l8, !tbaa !29
  store ptr %t71, ptr %l65, !tbaa !29
  %t72 = load i64, ptr %l11, !tbaa !24
  %t74 = call i64 @compiler_2ffree_2eoval(i64 %t72)
  store i64 %t74, ptr %l67
  br label %bb32
bb25:
  %t75 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t75, ptr %l52, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t76)
  store ptr %t78, ptr %l54
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l54, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 3
  %t82 = load i64, ptr %t81, !tbaa !24
  store i64 %t82, ptr %l56, !tbaa !24
  %t83 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t83, ptr %l57
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s4, { i64, ptr } %t84, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t86, ptr %l59
  br label %bb27
bb27:
  %t87 = load i1, ptr %l59, !tbaa !21
  %t88 = xor i1 %t87, true
  br i1 %t88, label %bb28, label %bb29
bb28:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t91 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t94 = extractvalue { i64, ptr } %t90, 1
  %t95 = extractvalue { i64, ptr } %t90, 0
  %t96 = add i64 %t92, %t95
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t91, i64 %t92)
  %t101 = getelementptr i8, ptr %t100, i64 %t92
  call void @olang_textcopy(ptr %t101, ptr %t94, i64 %t95)
  %t102 = getelementptr i8, ptr %t101, i64 %t95
  call void @olang_textcopy(ptr %t102, ptr %t97, i64 %t98)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t100, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = extractvalue { i64, ptr } %t104, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l61, !tbaa !27
  br label %bb30
bb29:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l61, !tbaa !27
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l49, !tbaa !29
  %t114 = load i64, ptr %l51, !tbaa !24
  %t115 = load i64, ptr %l52, !tbaa !24
  %t116 = load i64, ptr %l56, !tbaa !24
  %t117 = load %"compiler/source:Span", ptr %l57
  %t118 = load { i64, ptr }, ptr %l61, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s4, ptr %t113, i64 %t114, i64 %t115, i64 %t116, %"compiler/source:Span" %t117, { i64, ptr } %t118)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb32:
  %t119 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t119, ptr %l68, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t120)
  store ptr %t122, ptr %l70
  br label %bb33
bb33:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Body", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %t125, !tbaa !24
  store i64 %t126, ptr %l72, !tbaa !24
  %t127 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t127, ptr %l73
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t130 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s6, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) })
  store i1 %t130, ptr %l75
  br label %bb34
bb34:
  %t131 = load i1, ptr %l75, !tbaa !21
  %t132 = xor i1 %t131, true
  br i1 %t132, label %bb35, label %bb36
bb35:
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t135 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t138 = extractvalue { i64, ptr } %t134, 1
  %t139 = extractvalue { i64, ptr } %t134, 0
  %t140 = add i64 %t136, %t139
  %t141 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t143)
  call void @olang_textcopy(ptr %t144, ptr %t135, i64 %t136)
  %t145 = getelementptr i8, ptr %t144, i64 %t136
  call void @olang_textcopy(ptr %t145, ptr %t138, i64 %t139)
  %t146 = getelementptr i8, ptr %t145, i64 %t139
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l77, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d94, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb37
bb37:
  %t157 = load ptr, ptr %l65, !tbaa !29
  %t158 = load i64, ptr %l67, !tbaa !24
  %t159 = load i64, ptr %l68, !tbaa !24
  %t160 = load i64, ptr %l72, !tbaa !24
  %t161 = load %"compiler/source:Span", ptr %l73
  %t162 = load { i64, ptr }, ptr %l77, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s6, ptr %t157, i64 %t158, i64 %t159, i64 %t160, %"compiler/source:Span" %t161, { i64, ptr } %t162)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t163 = load i64, ptr %l10, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l10, !tbaa !24
  br label %bb1
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 2
  %t170 = load i1, ptr %t169, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  %t172 = load ptr, ptr %l3, !tbaa !29
  store ptr %t172, ptr %l86, !tbaa !29
  %t173 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t174 = load i64, ptr %l1, !tbaa !24
  %t177 = call i64 @compiler_2ffree_2eorig(i64 %t173, i64 %t174)
  store i64 %t177, ptr %l89
  br label %bb45
bb44:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb47
bb45:
  %t178 = load ptr, ptr %l86, !tbaa !29
  %t179 = load i64, ptr %l89, !tbaa !24
  %t180 = call i1 @compiler_2ffree_2ehas(ptr %v2, ptr %t178, i64 %t179)
  store i1 %t180, ptr %l90
  br label %bb46
bb46:
  %t181 = load i1, ptr %l90, !tbaa !21
  store i1 %t181, ptr %l85, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l85, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  %t183 = load i64, ptr %l1, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:walker", ptr %t184, i32 0, i32 31
  %t187 = load i64, ptr %t186, !tbaa !24
  %t190 = icmp ne i64 %t183, %t187
  store i1 %t190, ptr %l91, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t192 = load i1, ptr %l91, !tbaa !21
  br i1 %t192, label %bb51, label %bb52
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t197 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t193, ptr %t194)
  store i64 %t197, ptr %l99
  br label %bb53
bb52:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb54
bb53:
  %t198 = load i64, ptr %l99, !tbaa !24
  %t199 = icmp slt i64 %t198, 0
  store i1 %t199, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t201 = load i1, ptr %l96, !tbaa !21
  br i1 %t201, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l4
  %t206 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t202, i64 %t203, ptr %t204, %"compiler/source:Span" %t205, i1 %t206)
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t212 = load ptr, ptr %l8, !tbaa !29
  store ptr %t212, ptr %l106, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  store i64 %t213, ptr %l107, !tbaa !24
  %t214 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t214, ptr %l108, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t215)
  store ptr %t217, ptr %l110
  br label %bb58
bb58:
  %t218 = load ptr, ptr %l110, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Body", ptr %t218, i32 0, i32 3
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l112, !tbaa !24
  %t222 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t222, ptr %l113
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t225 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s9, { i64, ptr } %t223, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) })
  store i1 %t225, ptr %l115
  br label %bb59
bb59:
  %t226 = load i1, ptr %l115, !tbaa !21
  %t227 = xor i1 %t226, true
  br i1 %t227, label %bb60, label %bb61
bb60:
  %t229 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t230 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t233 = extractvalue { i64, ptr } %t229, 1
  %t234 = extractvalue { i64, ptr } %t229, 0
  %t235 = add i64 %t231, %t234
  %t236 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t239 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t238)
  call void @olang_textcopy(ptr %t239, ptr %t230, i64 %t231)
  %t240 = getelementptr i8, ptr %t239, i64 %t231
  call void @olang_textcopy(ptr %t240, ptr %t233, i64 %t234)
  %t241 = getelementptr i8, ptr %t240, i64 %t234
  call void @olang_textcopy(ptr %t241, ptr %t236, i64 %t237)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t239, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  store { i64, ptr } %t250, ptr %l117, !tbaa !27
  br label %bb62
bb61:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d98, i32 0, i32 1) }, ptr %l117, !tbaa !27
  br label %bb62
bb62:
  %t252 = load ptr, ptr %l106, !tbaa !29
  %t253 = load i64, ptr %l107, !tbaa !24
  %t254 = load i64, ptr %l108, !tbaa !24
  %t255 = load i64, ptr %l112, !tbaa !24
  %t256 = load %"compiler/source:Span", ptr %l113
  %t257 = load { i64, ptr }, ptr %l117, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t252, i64 %t253, i64 %t254, i64 %t255, %"compiler/source:Span" %t256, { i64, ptr } %t257)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s9)
  br label %ret
bb64:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l2, !tbaa !29
  %t262 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t258, ptr %t259)
  store i64 %t262, ptr %l123
  br label %bb65
bb65:
  %t263 = load i64, ptr %l123, !tbaa !24
  store i64 %t263, ptr %l12, !tbaa !24
  %t264 = load i64, ptr %l12, !tbaa !24
  %t266 = icmp sge i64 %t264, 0
  br i1 %t266, label %bb66, label %bb67
bb66:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:walker", ptr %t268, i32 0, i32 2
  %t271 = load i1, ptr %t270, !tbaa !21
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb68, label %bb69
bb67:
  br label %bb87
bb68:
  %t275 = load ptr, ptr %l8, !tbaa !29
  %t277 = getelementptr %"compiler/free:Free", ptr %t275, i32 0, i32 25
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/free:walker", ptr %t278, i32 0, i32 1
  %t281 = load i64, ptr %t280, !tbaa !24
  %t284 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t277, i64 %t281)
  store ptr %t284, ptr %l133
  br label %bb70
bb69:
  br label %bb83
bb70:
  %t285 = load i64, ptr %l12, !tbaa !24
  %t287 = shl i64 %t285, 32
  %t288 = load i64, ptr %l1, !tbaa !24
  %t291 = or i64 %t287, %t288
  %t292 = load ptr, ptr %l133, !tbaa !29
  %t294 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t292, i64 %t291)
  store i64 %t294, ptr %l138
  br label %bb71
bb71:
  %t295 = load i64, ptr %l138, !tbaa !24
  %t296 = icmp sgt i64 %t295, 0
  br i1 %t296, label %bb72, label %bb73
bb72:
  %t298 = load ptr, ptr %l8, !tbaa !29
  %t300 = getelementptr %"compiler/free:Free", ptr %t298, i32 0, i32 34
  store i1 true, ptr %t300, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  %t301 = load i1, ptr %l6, !tbaa !21
  br i1 %t301, label %bb75, label %bb76
bb75:
  %t303 = load ptr, ptr %l8, !tbaa !29
  %t305 = getelementptr %"compiler/free:Free", ptr %t303, i32 0, i32 27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:walker", ptr %t306, i32 0, i32 1
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t305, i64 %t309)
  store ptr %t312, ptr %l147
  br label %bb77
bb76:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb79
bb77:
  %t313 = load i64, ptr %l12, !tbaa !24
  %t314 = load ptr, ptr %l147, !tbaa !29
  %t316 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t314, i64 %t313)
  store i64 %t316, ptr %l149
  br label %bb78
bb78:
  %t317 = load i64, ptr %l149, !tbaa !24
  %t318 = icmp sgt i64 %t317, 0
  store i1 %t318, ptr %l142, !tbaa !21
  br label %bb79
bb79:
  %t320 = load i1, ptr %l142, !tbaa !21
  br i1 %t320, label %bb80, label %bb81
bb80:
  %t321 = load ptr, ptr %l8, !tbaa !29
  %t323 = getelementptr %"compiler/free:Free", ptr %t321, i32 0, i32 34
  store i1 true, ptr %t323, !tbaa !21
  br label %bb82
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/free:walker", ptr %t324, i32 0, i32 44
  %t327 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t326, i64 %t327)
  br label %bb84
bb84:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/free:walker", ptr %t330, i32 0, i32 45
  %t333 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t332, i64 %t333)
  br label %bb85
bb85:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/free:walker", ptr %t336, i32 0, i32 46
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/free:walker", ptr %t339, i32 0, i32 12
  %t342 = load i64, ptr %t341, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t338, i64 %t342)
  br label %bb86
bb86:
  br label %ret
bb87:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/free:walker", ptr %t345, i32 0, i32 2
  %t348 = load i1, ptr %t347, !tbaa !21
  %t350 = xor i1 %t348, true
  br i1 %t350, label %bb88, label %bb89
bb88:
  br i1 %a7, label %bb90, label %bb91
bb89:
  br label %bb126
bb90:
  br label %ret
bb91:
  br label %bb92
bb92:
  %t354 = load ptr, ptr %l3, !tbaa !29
  store ptr %t354, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb93
bb93:
  %t356 = load i64, ptr %l14, !tbaa !24
  store i64 %t356, ptr %l167, !tbaa !24
  %t357 = load ptr, ptr %l13, !tbaa !29
  %t359 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t357)
  store i64 %t359, ptr %l169
  br label %bb94
bb94:
  %t360 = load i64, ptr %l167, !tbaa !24
  %t361 = load i64, ptr %l169, !tbaa !24
  %t362 = icmp slt i64 %t360, %t361
  %t364 = xor i1 %t362, true
  br i1 %t364, label %bb95, label %bb96
bb95:
  br label %bb125
bb96:
  br label %bb97
bb97:
  %t366 = load ptr, ptr %l13, !tbaa !29
  %t367 = load i64, ptr %l14, !tbaa !24
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t366, i64 %t367)
  store i64 %t370, ptr %l174
  br label %bb98
bb98:
  %t371 = load i64, ptr %l174, !tbaa !24
  store i64 %t371, ptr %l15, !tbaa !24
  %t372 = load i64, ptr %l15, !tbaa !24
  %t374 = call i64 @compiler_2ffree_2eokind(i64 %t372)
  store i64 %t374, ptr %l176
  br label %bb99
bb99:
  %t375 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t376 = load i64, ptr %l176, !tbaa !24
  %t378 = icmp eq i64 %t376, %t375
  br i1 %t378, label %bb100, label %bb101
bb100:
  %t380 = load i64, ptr %l15, !tbaa !24
  %t382 = call i64 @compiler_2ffree_2eoval(i64 %t380)
  store i64 %t382, ptr %l181
  br label %bb102
bb101:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb103
bb102:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/free:walker", ptr %t383, i32 0, i32 30
  %t386 = load i64, ptr %t385, !tbaa !24
  %t387 = load i64, ptr %l181, !tbaa !24
  %t389 = icmp ne i64 %t387, %t386
  store i1 %t389, ptr %l179, !tbaa !21
  br label %bb103
bb103:
  %t391 = load i1, ptr %l179, !tbaa !21
  br i1 %t391, label %bb104, label %bb105
bb104:
  %t392 = load ptr, ptr %l8, !tbaa !29
  %t394 = getelementptr %"compiler/free:Free", ptr %t392, i32 0, i32 26
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/free:walker", ptr %t395, i32 0, i32 1
  %t398 = load i64, ptr %t397, !tbaa !24
  %t401 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t394, i64 %t398)
  store ptr %t401, ptr %l190
  br label %bb106
bb105:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb109
bb106:
  %t402 = load i64, ptr %l15, !tbaa !24
  %t404 = call i64 @compiler_2ffree_2eoval(i64 %t402)
  store i64 %t404, ptr %l192
  br label %bb107
bb107:
  %t405 = load ptr, ptr %l190, !tbaa !29
  %t406 = load i64, ptr %l192, !tbaa !24
  %t407 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t405, i64 %t406)
  store i64 %t407, ptr %l193
  br label %bb108
bb108:
  %t408 = load i64, ptr %l193, !tbaa !24
  %t409 = icmp sgt i64 %t408, 0
  store i1 %t409, ptr %l185, !tbaa !21
  br label %bb109
bb109:
  %t411 = load i1, ptr %l185, !tbaa !21
  br i1 %t411, label %bb110, label %bb111
bb110:
  %t412 = load ptr, ptr %l8, !tbaa !29
  %t414 = getelementptr %"compiler/free:Free", ptr %t412, i32 0, i32 34
  store i1 true, ptr %t414, !tbaa !21
  %t415 = load ptr, ptr %l8, !tbaa !29
  %t417 = getelementptr %"compiler/free:Free", ptr %t415, i32 0, i32 74
  %t418 = load i1, ptr %t417, !tbaa !21
  br i1 %t418, label %bb112, label %bb113
bb111:
  br label %bb123
bb112:
  store %olang.scope zeroinitializer, ptr %s20
  %t420 = load ptr, ptr %l8, !tbaa !29
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:walker", ptr %t421, i32 0, i32 1
  %t424 = load i64, ptr %t423, !tbaa !24
  %t427 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s20, ptr %t420, i64 %t424)
  store { i64, ptr } %t427, ptr %l201
  br label %bb114
bb113:
  br label %bb122
bb114:
  %t428 = load i64, ptr %l15, !tbaa !24
  %t430 = call i64 @compiler_2ffree_2eoval(i64 %t428)
  store i64 %t430, ptr %l203
  br label %bb115
bb115:
  %t431 = load ptr, ptr %l8, !tbaa !29
  %t433 = getelementptr %"compiler/free:Free", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = getelementptr %"compiler/generic:Program", ptr %t434, i32 0, i32 0
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = getelementptr %"compiler/load:Loader", ptr %t437, i32 0, i32 4
  %t440 = load ptr, ptr %t439, !tbaa !29
  store ptr %t440, ptr %l207, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t441)
  store ptr %t443, ptr %l209
  br label %bb116
bb116:
  %t444 = load ptr, ptr %l209, !tbaa !29
  %t446 = getelementptr %"compiler/typed:Body", ptr %t444, i32 0, i32 3
  %t447 = load i64, ptr %t446, !tbaa !24
  %t448 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t449 = load i32, ptr %t448, !tbaa !23
  %t451 = sext i32 %t449 to i64
  %t452 = load ptr, ptr %l207, !tbaa !29
  %t455 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s20, ptr %t452, i64 %t447, i64 %t451)
  store { i64, ptr } %t455, ptr %l214
  br label %bb117
bb117:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/free:walker", ptr %t456, i32 0, i32 30
  %t459 = load i64, ptr %t458, !tbaa !24
  %t460 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t461 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t462 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t462, 1
  %t464 = extractvalue { i64, ptr } %t462, 0
  %t465 = add i64 %t461, %t464
  %t466 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t468 = add i64 %t465, %t467
  %t469 = load i64, ptr %l203, !tbaa !24
  %t470 = call i64 @__olang_fmt_i64(ptr null, i64 %t469)
  %t471 = add i64 %t468, %t470
  %t472 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t476 = extractvalue { i64, ptr } %t475, 1
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = add i64 %t474, %t477
  %t479 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t481 = add i64 %t478, %t480
  %t483 = call i64 @__olang_fmt_i64(ptr null, i64 %t459)
  %t484 = add i64 %t481, %t483
  %t485 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t486 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t487 = add i64 %t484, %t486
  %t488 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t487)
  call void @olang_textcopy(ptr %t488, ptr %t460, i64 %t461)
  %t489 = getelementptr i8, ptr %t488, i64 %t461
  call void @olang_textcopy(ptr %t489, ptr %t463, i64 %t464)
  %t490 = getelementptr i8, ptr %t489, i64 %t464
  call void @olang_textcopy(ptr %t490, ptr %t466, i64 %t467)
  %t491 = getelementptr i8, ptr %t490, i64 %t467
  %t492 = call i64 @__olang_fmt_i64(ptr %t491, i64 %t469)
  %t493 = getelementptr i8, ptr %t491, i64 %t470
  call void @olang_textcopy(ptr %t493, ptr %t472, i64 %t473)
  %t494 = getelementptr i8, ptr %t493, i64 %t473
  call void @olang_textcopy(ptr %t494, ptr %t476, i64 %t477)
  %t495 = getelementptr i8, ptr %t494, i64 %t477
  call void @olang_textcopy(ptr %t495, ptr %t479, i64 %t480)
  %t496 = getelementptr i8, ptr %t495, i64 %t480
  %t497 = call i64 @__olang_fmt_i64(ptr %t496, i64 %t459)
  %t498 = getelementptr i8, ptr %t496, i64 %t483
  call void @olang_textcopy(ptr %t498, ptr %t485, i64 %t486)
  %t499 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t488, 1
  %t502 = extractvalue { i64, ptr } %t500, 0
  %t503 = extractvalue { i64, ptr } %t500, 1
  %t504 = mul i64 %t502, 1
  %t505 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t504)
  call void @llvm.memcpy.p0.p0.i64(ptr %t505, ptr %t503, i64 %t504, i1 false)
  %t506 = insertvalue { i64, ptr } undef, i64 %t502, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  %t509 = call i32 @std_2fio_2ePrintErr(ptr %s20, { i64, ptr } %t507)
  store i32 %t509, ptr %l219
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb119, label %ok.511, !prof !99
ok.511:
  br label %bb118
bb118:
  br label %bb121
bb119:
  %t512 = load i32, ptr %l219, !tbaa !23
  %t513 = ashr i32 %t512, 16
  %t515 = icmp eq i32 %t513, 1
  store i1 %t515, ptr %l221, !tbaa !21
  br label %bb120
bb120:
  call void @__olang_ert_req_clear()
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t516 = load i64, ptr %l14, !tbaa !24
  %t518 = add i64 %t516, 1
  store i64 %t518, ptr %l14, !tbaa !24
  br label %bb93
bb125:
  br label %ret
bb126:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load i64, ptr %l1, !tbaa !24
  %t522 = load ptr, ptr %l2, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l4
  %t524 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t520, i64 %t521, ptr %t522, %"compiler/source:Span" %t523, i1 %t524)
  br label %bb127
bb127:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:leaf"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l25 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/free:leaf"
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %t6, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t11, ptr %lp4
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  %t13 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %t14, ptr %t15, ptr %t16)
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l20
  br label %bb3
bb3:
  %t25 = load i64, ptr %l20, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 22
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t32)
  store i1 %t35, ptr %l25
  br label %bb4
bb4:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l6, !tbaa !21
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load ptr, ptr %lp4
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = call i64 @compiler_2ffree_2eorig(i64 %t44, i64 %t45)
  store i64 %t48, ptr %l32
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s4, ptr %t49, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l40
  br label %bb13
bb7:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %l32, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t54, i64 %t55)
  store i64 %t56, ptr %l33
  br label %bb8
bb8:
  %t57 = load i1, ptr %l6, !tbaa !21
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 43
  %t62 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t61, i64 %t62, i1 true)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb28
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  store ptr %t66, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l8, !tbaa !24
  store i64 %t68, ptr %l42, !tbaa !24
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s4, ptr %t69)
  store i64 %t71, ptr %l44
  br label %bb15
bb15:
  %t72 = load i64, ptr %l42, !tbaa !24
  %t73 = load i64, ptr %l44, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t79 = load i64, ptr %l8, !tbaa !24
  %t82 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s4, ptr %s4, ptr %t78, i64 %t79)
  store %"compiler/free:leaf" %t82, ptr %l49
  br label %bb19
bb19:
  %t83 = load %"compiler/free:leaf", ptr %l49
  store %"compiler/free:leaf" %t83, ptr %l9
  %t84 = load ptr, ptr %lp4
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t86 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call i64 @compiler_2ffree_2eorig(i64 %t85, i64 %t87)
  store i64 %t90, ptr %l53
  br label %bb20
bb20:
  %t91 = load ptr, ptr %l50, !tbaa !29
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t91, i64 %t92)
  store i64 %t93, ptr %l54
  br label %bb21
bb21:
  %t94 = load i1, ptr %l6, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 43
  %t99 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t100 = load i64, ptr %t99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t98, i64 %t100, i1 true)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb14
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t107 = load ptr, ptr %lp4
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i1
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l97 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l107 = alloca i64
  %l109 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l127 = alloca i1
  %l128 = alloca i1
  %l130 = alloca i64
  %l133 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l20, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l27
  br label %bb6
bb6:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l32
  br label %bb10
bb10:
  %t31 = load i64, ptr %l32, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 25
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l36
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 13
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l40
  br label %bb12
bb12:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l40, !tbaa !24
  %t48 = icmp sgt i64 %t46, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb5
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 14
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l47
  br label %bb18
bb18:
  %t61 = load i64, ptr %l47, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t66 = icmp sgt i64 %t62, %t63
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp sgt i64 %t68, 0
  br i1 %t70, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb24
bb21:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sub i64 %t72, %t73
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = add i64 %t76, %t77
  %t82 = sub i64 %t80, 1
  %t83 = load i64, ptr %l9, !tbaa !24
  %t86 = sdiv i64 %t82, %t83
  store i64 %t86, ptr %l54, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l54, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  br label %bb24
bb24:
  %t89 = load i64, ptr %l51, !tbaa !24
  store i64 %t89, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = icmp slt i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb26, label %bb27
bb26:
  br label %bb59
bb27:
  br label %bb28
bb28:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l9, !tbaa !24
  %t103 = mul i64 %t99, %t100
  %t106 = add i64 %t98, %t103
  store i64 %t106, ptr %l12, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 14
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  store i64 %t114, ptr %l75
  br label %bb29
bb29:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l2, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  br i1 %t120, label %bb30, label %bb31
bb30:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l80, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 15
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l84
  br label %bb32
bb31:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i64, ptr %l80, !tbaa !24
  %t131 = load i64, ptr %l84, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l79, !tbaa !21
  br label %bb33
bb33:
  %t134 = load i1, ptr %l79, !tbaa !21
  %t135 = xor i1 %t134, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb37
bb35:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 20
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t139, i64 %t140)
  store i64 %t143, ptr %l91
  br label %bb36
bb36:
  %t144 = load i64, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l91, !tbaa !24
  %t147 = icmp sgt i64 %t145, %t144
  store i1 %t147, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t149 = load i1, ptr %l87, !tbaa !21
  br i1 %t149, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l3, !tbaa !29
  store ptr %t150, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t152 = load i64, ptr %l15, !tbaa !24
  store i64 %t152, ptr %l95, !tbaa !24
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t153)
  store i64 %t155, ptr %l97
  br label %bb42
bb42:
  %t156 = load i64, ptr %l95, !tbaa !24
  %t157 = load i64, ptr %l97, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t162 = load ptr, ptr %l14, !tbaa !29
  %t163 = load i64, ptr %l15, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l102
  br label %bb46
bb46:
  %t167 = load i64, ptr %l102, !tbaa !24
  store i64 %t167, ptr %l16, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  store i64 %t168, ptr %l103, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 25
  %t172 = load i64, ptr %l16, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l107
  br label %bb47
bb47:
  %t176 = load i64, ptr %l103, !tbaa !24
  %t177 = load i64, ptr %l107, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  br i1 %t178, label %bb48, label %bb49
bb48:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:walker", ptr %t180, i32 0, i32 25
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t182, i64 %t183)
  store i64 %t186, ptr %l113
  br label %bb50
bb49:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb52
bb50:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/free:walker", ptr %t187, i32 0, i32 15
  %t190 = load i64, ptr %l12, !tbaa !24
  %t193 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t189, i64 %t190)
  store i64 %t193, ptr %l117
  br label %bb51
bb51:
  %t194 = load i64, ptr %l113, !tbaa !24
  %t195 = load i64, ptr %l117, !tbaa !24
  %t196 = icmp sle i64 %t194, %t195
  store i1 %t196, ptr %l109, !tbaa !21
  br label %bb52
bb52:
  %t198 = load i1, ptr %l109, !tbaa !21
  br i1 %t198, label %bb53, label %bb54
bb53:
  %t199 = load i64, ptr %l16, !tbaa !24
  store i64 %t199, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t201 = load i64, ptr %l15, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l15, !tbaa !24
  br label %bb41
bb57:
  br label %bb58
bb58:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb25
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 27
  %t212 = load i64, ptr %l1, !tbaa !24
  %t215 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t211, i64 %t212)
  store i1 %t215, ptr %l127
  br label %bb60
bb60:
  %t216 = load i1, ptr %l127, !tbaa !21
  br i1 %t216, label %bb61, label %bb62
bb61:
  %t217 = load ptr, ptr %l3, !tbaa !29
  %t219 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t217)
  store i64 %t219, ptr %l130
  br label %bb63
bb62:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb64
bb63:
  %t220 = load i64, ptr %l130, !tbaa !24
  %t221 = icmp sgt i64 %t220, 0
  store i1 %t221, ptr %l128, !tbaa !21
  br label %bb64
bb64:
  %t223 = load i1, ptr %l128, !tbaa !21
  br i1 %t223, label %bb65, label %bb66
bb65:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t224, i64 0)
  store i64 %t226, ptr %l133
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t227 = load i64, ptr %l133, !tbaa !24
  store i64 %t227, ptr %rv
  br label %ret
bb68:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:leaf"
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l19 = alloca i1
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/free:leaf"
  %l34 = alloca %"compiler/free:leaf"
  %l37 = alloca i1
  %l43 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i1
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i64
  %l73 = alloca ptr
  %l75 = alloca i64
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca i64
  %l82 = alloca i64
  %l88 = alloca %"compiler/free:store"
  %l91 = alloca ptr
  %l92 = alloca i64
  %l93 = alloca i64
  %l95 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 29
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  store i1 %t18, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l19, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l23
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l6
  store ptr %a1, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t25 = load i64, ptr %l8, !tbaa !24
  store i64 %t25, ptr %l25, !tbaa !24
  %t26 = load ptr, ptr %l7, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t26)
  store i64 %t28, ptr %l27
  br label %bb9
bb9:
  %t29 = load i64, ptr %l25, !tbaa !24
  %t30 = load i64, ptr %l27, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t36 = load i64, ptr %l8, !tbaa !24
  %t39 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t35, i64 %t36)
  store %"compiler/free:leaf" %t39, ptr %l32
  br label %bb13
bb13:
  %t41 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v1, ptr %l32)
  store %"compiler/free:leaf" %t41, ptr %l34
  br label %bb14
bb14:
  %t42 = load %"compiler/free:leaf", ptr %l34
  store %"compiler/free:leaf" %t42, ptr %l9
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t43, i64 %t45)
  store i1 %t48, ptr %l37
  br label %bb15
bb15:
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t51 = load i64, ptr %t50, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l6, i64 %t51)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l8, !tbaa !24
  br label %bb8
bb21:
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t59, ptr %l43
  br label %bb22
bb22:
  %t60 = load i64, ptr %l43, !tbaa !24
  %t61 = icmp eq i64 %t60, 0
  br i1 %t61, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t64, ptr %l46
  br label %bb26
bb26:
  %t65 = load i64, ptr %l46, !tbaa !24
  %t66 = icmp eq i64 %t65, 1
  br i1 %t66, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Call", ptr %t68, i32 0, i32 3
  %t71 = load i32, ptr %t70, !tbaa !23
  %t73 = icmp sge i32 %t71, 0
  store i1 %t73, ptr %l48, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb29
bb29:
  %t75 = load i1, ptr %l48, !tbaa !21
  br i1 %t75, label %bb30, label %bb31
bb30:
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t78 = getelementptr %"compiler/free:Free", ptr %t76, i32 0, i32 21
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t78, i64 %t82)
  store i1 %t85, ptr %l57
  br label %bb32
bb31:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb33
bb32:
  %t86 = load i1, ptr %l57, !tbaa !21
  store i1 %t86, ptr %l52, !tbaa !21
  br label %bb33
bb33:
  %t87 = load i1, ptr %l52, !tbaa !21
  store i1 %t87, ptr %l10, !tbaa !21
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb34
bb34:
  %t89 = load i64, ptr %l12, !tbaa !24
  store i64 %t89, ptr %l59, !tbaa !24
  %t90 = load ptr, ptr %l11, !tbaa !29
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t90)
  store i64 %t92, ptr %l61
  br label %bb35
bb35:
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = load i64, ptr %l61, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb36, label %bb37
bb36:
  br label %bb57
bb37:
  br label %bb38
bb38:
  %t99 = load ptr, ptr %l11, !tbaa !29
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l66
  br label %bb39
bb39:
  %t104 = load i64, ptr %l66, !tbaa !24
  store i64 %t104, ptr %l13, !tbaa !24
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 40
  store ptr %t107, ptr %l68, !tbaa !29
  %t108 = load i64, ptr %l13, !tbaa !24
  store i64 %t108, ptr %l69, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 1
  %t112 = load i64, ptr %t111, !tbaa !24
  store i64 %t112, ptr %l71, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t113)
  store ptr %t115, ptr %l73
  br label %bb40
bb40:
  %t116 = load ptr, ptr %l73, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Body", ptr %t116, i32 0, i32 3
  %t119 = load i64, ptr %t118, !tbaa !24
  store i64 %t119, ptr %l75, !tbaa !24
  %t120 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t120, ptr %l76
  %t121 = load i1, ptr %l10, !tbaa !21
  br i1 %t121, label %bb41, label %bb42
bb41:
  %t123 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t123, ptr %l78, !tbaa !24
  br label %bb43
bb42:
  %t125 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t125, ptr %l78, !tbaa !24
  br label %bb43
bb43:
  %t127 = load i1, ptr %l10, !tbaa !21
  br i1 %t127, label %bb44, label %bb45
bb44:
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Call", ptr %t129, i32 0, i32 3
  %t132 = load i32, ptr %t131, !tbaa !23
  %t134 = sext i32 %t132 to i64
  store i64 %t134, ptr %l82, !tbaa !24
  br label %bb46
bb45:
  store i64 -1, ptr %l82, !tbaa !24
  br label %bb46
bb46:
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = load i64, ptr %l69, !tbaa !24
  %t139 = load i64, ptr %l71, !tbaa !24
  %t140 = load i64, ptr %l75, !tbaa !24
  %t141 = load %"compiler/source:Span", ptr %l76
  %t142 = load i64, ptr %l78, !tbaa !24
  %t143 = load i64, ptr %l82, !tbaa !24
  %t145 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v3, ptr %v0, ptr %v0, i64 %t138, i64 %t139, i64 %t140, %"compiler/source:Span" %t141, i64 %t142, i64 -1, i64 %t143, ptr %t136, ptr null)
  store %"compiler/free:store" %t145, ptr %l88
  br label %bb47
bb47:
  %t146 = load ptr, ptr %l68, !tbaa !29
  %t147 = load %"compiler/free:store", ptr %l88
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t146, %"compiler/free:store" %t147)
  br label %bb48
bb48:
  %t148 = load i1, ptr %l10, !tbaa !21
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t152 = load ptr, ptr %l5, !tbaa !29
  store ptr %t152, ptr %l91, !tbaa !29
  %t153 = load i64, ptr %l13, !tbaa !24
  store i64 %t153, ptr %l92, !tbaa !24
  %t154 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t154, ptr %l93, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t155)
  store ptr %t157, ptr %l95
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t158 = load ptr, ptr %l95, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Body", ptr %t158, i32 0, i32 3
  %t161 = load i64, ptr %t160, !tbaa !24
  store i64 %t161, ptr %l97, !tbaa !24
  %t162 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t162, ptr %l98
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l99, !tbaa !29
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t166 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v3, ptr %t164)
  store %"compiler/source:Span" %t166, ptr %l101
  br label %bb52
bb52:
  %t167 = load ptr, ptr %l99, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l101
  %t169 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s9, ptr %t167, %"compiler/source:Span" %t168)
  store { i64, ptr } %t169, ptr %l102
  br label %bb53
bb53:
  %t170 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t172 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t170, i64 %t171)
  %t180 = getelementptr i8, ptr %t179, i64 %t171
  call void @olang_textcopy(ptr %t180, ptr %t173, i64 %t174)
  %t181 = getelementptr i8, ptr %t180, i64 %t174
  call void @olang_textcopy(ptr %t181, ptr %t176, i64 %t177)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t179, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l91, !tbaa !29
  %t192 = load i64, ptr %l92, !tbaa !24
  %t193 = load i64, ptr %l93, !tbaa !24
  %t194 = load i64, ptr %l97, !tbaa !24
  %t195 = load %"compiler/source:Span", ptr %l98
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t191, i64 %t192, i64 %t193, i64 %t194, %"compiler/source:Span" %t195, { i64, ptr } %t190)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t197 = load i64, ptr %l12, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l12, !tbaa !24
  br label %bb34
bb57:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i64 @compiler_2ffree_2eorig(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 3
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i64 @compiler_2ffree_2eorig(i64 %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t31, ptr %l19
  br label %bb8
bb8:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l11, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ebaseOf(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %t13, i64 %t17, ptr %t18)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr %l14, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb11
bb10:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb31
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l23, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb31
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l25, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %s3, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l33
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t67 = icmp eq ptr %t66, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l40
  br label %bb23
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l44
  br label %bb24
bb23:
  %t87 = load ptr, ptr %l40, !tbaa !29
  store ptr %t87, ptr %l36, !tbaa !29
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l44, !tbaa !29
  store ptr %t88, ptr %l36, !tbaa !29
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l36, !tbaa !29
  store ptr %t89, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ee9887f5f58478ff_db34cc814b361eab)
  unreachable
bb31:
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp eq i64 %t18, %a1
  br i1 %t23, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2einElement(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb25
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2einElement(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l15
  br label %bb12
bb12:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb25
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 5
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Payload", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2ffree_2einElement(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l24
  br label %bb19
bb19:
  %t50 = load i1, ptr %l24, !tbaa !21
  store i1 %t50, ptr %l3, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ed7f6e6daad964a6_bdb604c7994d314a)
  unreachable
bb25:
  %t51 = load i1, ptr %l3, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2emeet(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l0, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l0, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a0, 40
  %t7 = or i64 %t3, %a1
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2eoval(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = shl i64 1, 40
  %t4 = sub i64 %t2, 1
  %t7 = and i64 %a0, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 8}
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_11a48ff1e8d67007_90e1a85549f82d33)
  unreachable
bb22:
  %t34 = load i1, ptr %l14, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb24, label %bb25
bb24:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb25
bb25:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb26, label %bb27
bb26:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l26
  br label %bb29
bb29:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e0188cd4392210a6_c14318bc74dc83b2)
  unreachable
bb35:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l20
  br label %bb10
bb10:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb41
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l29
  br label %bb17
bb17:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l11, !tbaa !21
  br label %bb41
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb24
bb24:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  br label %bb41
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb26, label %bb27
bb26:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 9
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb28, label %bb29
bb28:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 43}
  store i32 %t84, ptr %l5
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t88, i32 0, i32 4
  %t90 = load { i64, ptr }, ptr %t89
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t92 = load i32, ptr %l5, !range !{i32 0, i32 43}
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %t92, { i64, ptr } %t93)
  store i1 %t96, ptr %l49
  br label %bb31
bb31:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l51, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 0
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l54
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t107 = load i1, ptr %l54, !tbaa !21
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l50, !tbaa !21
  store i1 %t108, ptr %l11, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_365b62d925fe4616_77c77337a4accaaa)
  unreachable
bb41:
  %t109 = load i1, ptr %l11, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t10, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t11 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 0
  %t19 = load ptr, ptr %t18, !tbaa !39
  %t21 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l9
  br label %bb5
bb5:
  %t22 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [1 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [1 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [1 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [1 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9c97567f05482d15_e6d42a2535d66e1)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b94c5fec836ee160_c106f176e2c66bb4)
  unreachable
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t55, i32 0, i32 3
  %t57 = load i64, ptr %t56
  store i64 %t57, ptr %l5, !tbaa !24
  br label %bb21
bb20:
  br label %bb36
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t76, i32 0, i32 3
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l48
  br label %bb29
bb28:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t91 = load i1, ptr %l48, !tbaa !21
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t92 = load i1, ptr %l45, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_bc70ad18304b6571_160962e965f972e5)
  unreachable
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb53
bb41:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 8}
  %t116 = icmp eq i64 %t114, 2
  store i1 %t116, ptr %l57, !tbaa !21
  br label %bb43
bb43:
  %t117 = load i1, ptr %l57, !tbaa !21
  br i1 %t117, label %bb44, label %bb45
bb44:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t124 = load ptr, ptr %l8, !tbaa !29
  %t125 = load ptr, ptr %l9, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb47
bb47:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %rv
  br label %ret
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  call void @__olang_check_failed(ptr @olang_loc_6c7e0d9d91c4575a_bcb450b004b7d12e)
  unreachable
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_65fd46072274f65b_1273d4b3d3b84def)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l24 = alloca { i64, ptr }
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Try", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t52 = getelementptr %"compiler/typed:Clause", ptr %t48, i32 0, i32 4
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb9
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Try", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_497cb5294fb5d476_59996708b38ef322)
  unreachable
bb19:
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Try", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = call ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %v1, ptr %t75)
  store ptr %t77, ptr %l39
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l39, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d76336629ed12804_de1ad14eaa737c40)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_3aFree_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i1
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l61 = alloca i64
  %l62 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l91 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l92 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l93 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l94 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l108 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l111 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca %"compiler/source:Span"
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l127 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l128 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l129 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca %"compiler/free:Free"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l4
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l81
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l82
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l8
  store ptr null, ptr %l9, !tbaa !29
  store i64 -1, ptr %l10, !tbaa !24
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l83
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l11
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l84
  br label %bb4
bb4:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l12
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l85
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l13
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l86
  br label %bb6
bb6:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l14
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l87
  br label %bb7
bb7:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l15
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l88
  br label %bb8
bb8:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l16
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l89
  br label %bb9
bb9:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l90
  br label %bb10
bb10:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l90
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %l18
  %t27 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t27, ptr %l91
  br label %bb11
bb11:
  %t28 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l91
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t28, ptr %l19
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l92
  br label %bb12
bb12:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l92
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l20
  %t31 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_Hc8a5baaa53b941ecb64fa970dd85be07(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t31, ptr %l93
  br label %bb13
bb13:
  %t32 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l93
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t32, ptr %l21
  %t33 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_H97c25ad44ee4c5f3c548e4ff463613d5(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t33, ptr %l94
  br label %bb14
bb14:
  %t34 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l94
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l22
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l95
  br label %bb15
bb15:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l23
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l96
  br label %bb16
bb16:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l97
  br label %bb17
bb17:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l25
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l98
  br label %bb18
bb18:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l26
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l99
  br label %bb19
bb19:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l27
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l100
  br label %bb20
bb20:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l28
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l101
  br label %bb21
bb21:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l29
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l102
  br label %bb22
bb22:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l30
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l103
  br label %bb23
bb23:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l31
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l104
  br label %bb24
bb24:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l32
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l105
  br label %bb25
bb25:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l105
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l33
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l106
  br label %bb26
bb26:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l34
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l107
  br label %bb27
bb27:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l35
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l108
  br label %bb28
bb28:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l108
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l36
  store i1 false, ptr %l37, !tbaa !21
  store i1 false, ptr %l38, !tbaa !21
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l109
  br label %bb29
bb29:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l39
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l110
  br label %bb30
bb30:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l40
  store i1 false, ptr %l41, !tbaa !21
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l111
  br label %bb31
bb31:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l111
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l42
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l112
  br label %bb32
bb32:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l43
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l113
  br label %bb33
bb33:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l44
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l114
  br label %bb34
bb34:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l114
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l45
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l115
  br label %bb35
bb35:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l46
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l116
  br label %bb36
bb36:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l47
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l117
  br label %bb37
bb37:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l48
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l118
  br label %bb38
bb38:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l49
  %t83 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l119
  br label %bb39
bb39:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l50
  store i64 -1, ptr %l51, !tbaa !24
  store i64 -1, ptr %l52, !tbaa !24
  %t85 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v3, i32 0, i32 0)
  store %"compiler/source:Span" %t85, ptr %l120
  br label %bb40
bb40:
  %t86 = load %"compiler/source:Span", ptr %l120
  store %"compiler/source:Span" %t86, ptr %l53
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l121
  br label %bb41
bb41:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l54
  %t89 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t89, ptr %l122
  br label %bb42
bb42:
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l122
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l55
  %t91 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l123
  br label %bb43
bb43:
  %t92 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l123
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l56
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l124
  br label %bb44
bb44:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l57
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l125
  br label %bb45
bb45:
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %l58
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l126
  br label %bb46
bb46:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %l59
  %t99 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t99, ptr %l127
  br label %bb47
bb47:
  %t100 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l127
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t100, ptr %l60
  store i64 0, ptr %l61, !tbaa !24
  %t101 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t101, ptr %l128
  br label %bb48
bb48:
  %t102 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l128
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t102, ptr %l62
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l129
  br label %bb49
bb49:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l129
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l63
  %t105 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l130
  br label %bb50
bb50:
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l130
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l64
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l131
  br label %bb51
bb51:
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %l65
  %t109 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t109, ptr %l132
  br label %bb52
bb52:
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %l66
  %t111 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %l133
  br label %bb53
bb53:
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l67
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l134
  br label %bb54
bb54:
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l68
  %t115 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l135
  br label %bb55
bb55:
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l69
  %t117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l136
  br label %bb56
bb56:
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %l70
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l137
  br label %bb57
bb57:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l71
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l138
  br label %bb58
bb58:
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l72
  %t123 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %l139
  br label %bb59
bb59:
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  %t125 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 0
  %t126 = load ptr, ptr %l3, !tbaa !29
  store ptr %t126, ptr %t125, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 1
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %t127
  %t129 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 2
  %t130 = load ptr, ptr %l5, !tbaa !29
  store ptr %t130, ptr %t129, !tbaa !29
  %t131 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 3
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %t131
  %t133 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 4
  %t134 = load i64, ptr %l7, !tbaa !24
  store i64 %t134, ptr %t133, !tbaa !24
  %t135 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 5
  %t136 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %t135
  %t137 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 6
  %t138 = load ptr, ptr %l9, !tbaa !29
  store ptr %t138, ptr %t137, !tbaa !29
  %t139 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 7
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %t139, !tbaa !24
  %t141 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 8
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %t141
  %t143 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 9
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t143
  %t145 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 10
  %t146 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t146, ptr %t145
  %t147 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 11
  %t148 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t148, ptr %t147
  %t149 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 12
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %t149
  %t151 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 13
  %t152 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %t151
  %t153 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 14
  %t154 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %t153
  %t155 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 15
  %t156 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t156, ptr %t155
  %t157 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 16
  %t158 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t158, ptr %t157
  %t159 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 17
  %t160 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t160, ptr %t159
  %t161 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 18
  %t162 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t162, ptr %t161
  %t163 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 19
  %t164 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l22
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t164, ptr %t163
  %t165 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 20
  %t166 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t166, ptr %t165
  %t167 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 21
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %t167
  %t169 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 22
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %t169
  %t171 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 23
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %t171
  %t173 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 24
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %t173
  %t175 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 25
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %t175
  %t177 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 26
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %t177
  %t179 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 27
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %t179
  %t181 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 28
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %t181
  %t183 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 29
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %t183
  %t185 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 30
  %t186 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %t185
  %t187 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 31
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %t187
  %t189 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 32
  %t190 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t190, ptr %t189
  %t191 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 33
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %t191
  %t193 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 34
  %t194 = load i1, ptr %l37, !tbaa !21
  store i1 %t194, ptr %t193, !tbaa !21
  %t195 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 35
  %t196 = load i1, ptr %l38, !tbaa !21
  store i1 %t196, ptr %t195, !tbaa !21
  %t197 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 36
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %t197
  %t199 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 37
  %t200 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %t199
  %t201 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 38
  %t202 = load i1, ptr %l41, !tbaa !21
  store i1 %t202, ptr %t201, !tbaa !21
  %t203 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 39
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %t203
  %t205 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 40
  %t206 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %t205
  %t207 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 41
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %t207
  %t209 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 42
  %t210 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %t209
  %t211 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 43
  %t212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %t211
  %t213 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 44
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %t213
  %t215 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 45
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %t215
  %t217 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 46
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %t217
  %t219 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 47
  %t220 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, ptr %t219
  %t221 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 48
  %t222 = load i64, ptr %l51, !tbaa !24
  store i64 %t222, ptr %t221, !tbaa !24
  %t223 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 49
  %t224 = load i64, ptr %l52, !tbaa !24
  store i64 %t224, ptr %t223, !tbaa !24
  %t225 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 50
  %t226 = load %"compiler/source:Span", ptr %l53
  store %"compiler/source:Span" %t226, ptr %t225
  %t227 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 51
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %t227
  %t229 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 52
  %t230 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %t229
  %t231 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 53
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %t231
  %t233 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 54
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %t233
  %t235 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 55
  %t236 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %t235
  %t237 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 56
  %t238 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %t237
  %t239 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 57
  %t240 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l60
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t240, ptr %t239
  %t241 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 58
  %t242 = load i64, ptr %l61, !tbaa !24
  store i64 %t242, ptr %t241, !tbaa !24
  %t243 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 59
  %t244 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l62
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t244, ptr %t243
  %t245 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 60
  %t246 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %t245
  %t247 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 61
  %t248 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %t247
  %t249 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 62
  %t250 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l65
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, ptr %t249
  %t251 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 63
  %t252 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t252, ptr %t251
  %t253 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 64
  %t254 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t254, ptr %t253
  %t255 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 65
  %t256 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %t255
  %t257 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 66
  %t258 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t258, ptr %t257
  %t259 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 67
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %t259
  %t261 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 68
  %t262 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t262, ptr %t261
  %t263 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 69
  %t264 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %t263
  %t265 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %t265
  %t267 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 71
  store i64 -1, ptr %t267, !tbaa !24
  %t269 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 72
  store i1 true, ptr %t269, !tbaa !21
  %t271 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 73
  store i1 false, ptr %t271, !tbaa !21
  %t273 = getelementptr %"compiler/free:Free", ptr %l140, i32 0, i32 74
  store i1 false, ptr %t273, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l140, i64 2272, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %lp2 = alloca ptr
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t2, ptr %lp2
  %t4 = load ptr, ptr %lp2
  store { i64, ptr } %a0, ptr %t4, !tbaa !27
  %t7 = load ptr, ptr %lp2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = insertvalue %"compiler/free:leaf" undef, { i64, ptr } %t8, 0
  %t11 = insertvalue %"compiler/free:leaf" %t9, i64 %a1, 1
  store %"compiler/free:leaf" %t11, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define dso_local %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/free:orStore"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/free:orStore" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/free:orStore" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/free:orStore" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/free:orStore" %t14, ptr %a3, 3
  store %"compiler/free:orStore" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orStore", ptr %rv
  ret %"compiler/free:orStore" %rr
}

define dso_local %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/free:reason"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/free:reason" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/free:reason" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/free:reason" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/free:reason" %t14, { i64, ptr } %a3, 3
  store %"compiler/free:reason" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:reason", ptr %rv
  ret %"compiler/free:reason" %rr
}

define dso_local %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8) #0 {
entry:
  %rv = alloca %"compiler/free:store"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:store" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:store" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:store" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:store" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:store" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/free:store" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:store" %t30, i64 %a6, 6
  %t34 = insertvalue %"compiler/free:store" %t32, ptr %a7, 7
  %t36 = insertvalue %"compiler/free:store" %t34, ptr %a8, 8
  store %"compiler/free:store" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:store", ptr %rv
  ret %"compiler/free:store" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"removed elements of '" }>, align 8
@.d2 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' are kept until " }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" closes" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d5 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"' keeps what it lets go of until " }>, align 8
@.d6 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" closes" }>, align 8
@.d7 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"it lets go only in a module compiled on its own, where nothing is freed early" }>, align 8
@.d8 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d9 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d10 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c": note: " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d11 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"memory: no place lets go of storage in code that runs again\0A" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" (above)" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"memory: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" let" }>, align 8
@.d25 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" go of storage in code that runs again - " }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" free" }>, align 8
@.d27 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" it at once, " }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" keep" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" it" }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fsource_3aSpan(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/source:Span", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/source:Span", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/source:Span", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"T&" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d33 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the function" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d36 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define linkonce_odr %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

@.d40 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"the " }>, align 8
@.d45 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d46 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d47 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"its scope" }>, align 8
@.d48 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a writable reference to it handed to a call" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d49 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a call's value copied" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"esc " }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d56 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" inside " }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d61 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"it is handed here to what may keep it" }>, align 8
@.d62 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d63 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d64 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d65 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a reference into it is kept here" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 176, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

@.d66 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"a copy of a value holding it" }>, align 8
define linkonce_odr %"compiler/free:retire" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:retire"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:retire", ptr %a0
  store %"compiler/free:retire" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/free:retire", ptr %l1
  store %"compiler/free:retire" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"its new value is built where the old one lives: '" }>, align 8
@.d78 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"' borrows its result from '" }>, align 8
@.d79 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"'; a built result ('" }>, align 8
@.d80 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"') frees the old " }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"its new value is not all new: '" }>, align 8
@.d83 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"' returns storage it was given" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d90 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"it is handed here to a call that stores it" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d93 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d94 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d97 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d98 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d99 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"esc-store " }>, align 8
@.d100 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d101 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d102 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" within " }>, align 8
@.d103 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d104 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"its new value is a copy of what a constructor is given, which holds other owners too: '" }>, align 8
@.d105 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_Hc8a5baaa53b941ecb64fa970dd85be07(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cc_Hd7bfb320b31828a1c070683ea7d5fb27(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_H97c25ad44ee4c5f3c548e4ff463613d5(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/free:leaf"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 24
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/free:leaf", ptr %t14, i64 %t12
  %t17 = call %"compiler/free:leaf" @olang_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %t15)
  store %"compiler/free:leaf" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/free:leaf", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/free:leaf", ptr %t22, i64 %t20
  store %"compiler/free:leaf" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/free:letGo" %a3)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eLen_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %a0)
declare %"compiler/free:retire" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2eAt_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eokind(i64 %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_26303021143ae8be_4bef98a84a02e70a = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4cef24e7d17769b7_e2744f91577a9953 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_708b3215abbdbba7_3cea2bd689d53e8b = external constant [0 x i8]
@olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/free:reason" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnchors(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2eLen_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eLen_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bc9d64d7693be970_b83238a2b46aaa8c = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_97a1f172ac127e68_91804f7c420b5df4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_f6dacd44c7154ec0_6b7e2d10b8afc3c = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ebe5ee6b39eee92e_4ec5471030d8b4f2 = external constant [0 x i8]
@olang_loc_c32ca46bf6d65f0c_9a54b76873cd9ad0 = external constant [0 x i8]
@olang_loc_b4c0d703fa684531_272a8f4f39064c15 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_14962ab25e47b4fc_3749941476b1d040 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_502532e2e95f04ea_fe436d8dc2f78aae = external constant [0 x i8]
@olang_loc_ba297c355e3740f1_9975a70d069e6a55 = external constant [0 x i8]
@olang_loc_bb85040a6a786cb8_20e886069e3b9c04 = external constant [0 x i8]
@olang_loc_be187497b97f18d7_9641cb8c9c409d3 = external constant [0 x i8]
@olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892 = external constant [0 x i8]
@olang_loc_d5478abcfcd1a74_537f989617a8cff0 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7a954698926d7de_664d4c02e090fa22 = external constant [0 x i8]
@olang_loc_893474d063c17328_1c44af56cc3f848c = external constant [0 x i8]
declare i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_a532406d51285a24_27441d0f137c6648 = external constant [0 x i8]
@olang_loc_9be7a7b731d47dfc_cd79088c97deb358 = external constant [0 x i8]
@olang_loc_1777536395e8cd8b_97ff53b4c3030f1f = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0)
@olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d = external constant [0 x i8]
declare i1 @compiler_2ffree_2eleavesFunction(ptr %v0, ptr %a0)
@olang_loc_59a6b24cdfdba848_73366ee735d239ac = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ec84fe6443685676_e22a9bc60a48a0b2 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7 = external constant [0 x i8]
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
declare %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ePush_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:retire" %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6 = external constant [0 x i8]
@olang_loc_5a2a443e2f2f03b9_3064adab7524445d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_f2df24d87159f740_3aba0f93d819cd0c = external constant [0 x i8]
@olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b = external constant [0 x i8]
@olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba = external constant [0 x i8]
@olang_loc_67165cb650ae48c_1f30efdb88316bc8 = external constant [0 x i8]
@olang_loc_b6b576316e1b3293_3c9a5af727622297 = external constant [0 x i8]
@olang_loc_797639ecae530892_5422fc7df8fd29f6 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_fa71248d89b17b0b_39d265aac120d27f = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orCall" %a1)
declare ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_d8246f320a19bbf9_8add34a618744eed = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5d7536cc463ccac1_135a9313c745645 = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_11c10ff2df4ccb13_a4bbf1166c590ff7 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedToTask(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
@olang_loc_ec0dfed271d7eacc_f2c899624053798 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ee9887f5f58478ff_db34cc814b361eab = external constant [0 x i8]
@olang_loc_ed7f6e6daad964a6_bdb604c7994d314a = external constant [0 x i8]
@olang_loc_11a48ff1e8d67007_90e1a85549f82d33 = external constant [0 x i8]
@olang_loc_e0188cd4392210a6_c14318bc74dc83b2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_365b62d925fe4616_77c77337a4accaaa = external constant [0 x i8]
@olang_loc_9c97567f05482d15_e6d42a2535d66e1 = external constant [0 x i8]
@olang_loc_b94c5fec836ee160_c106f176e2c66bb4 = external constant [0 x i8]
@olang_loc_bc70ad18304b6571_160962e965f972e5 = external constant [0 x i8]
@olang_loc_6c7e0d9d91c4575a_bcb450b004b7d12e = external constant [0 x i8]
@olang_loc_65fd46072274f65b_1273d4b3d3b84def = external constant [0 x i8]
@olang_loc_497cb5294fb5d476_59996708b38ef322 = external constant [0 x i8]
@olang_loc_d76336629ed12804_de1ad14eaa737c40 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cc_Hd7bfb320b31828a1c070683ea7d5fb27(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
