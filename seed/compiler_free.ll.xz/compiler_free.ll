; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
@G_2ecompiler_2ffree_2eAnyPlace = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eLAssign = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLCall = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDestroy = constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDrop = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLVacate = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLYield = constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMovBase = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMustNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eMustTop = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eOMov = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eONew = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPar = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOUnk = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRDtor = constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRMade = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRNone = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRStore = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRTask = constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRView = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k1, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k2, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k3, [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k4, [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k5, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k6, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k7, [8 x i8] c"\04\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k8, [8 x i8] c"\08\00\00\00\00\00\00\00", ptr @G_2ecompiler_2ffree_2eRemovalNames.k9 }>, align 64
@G_2ecompiler_2ffree_2eRemovalNames.k1 = internal constant <{ [3 x i8] }> <{ [3 x i8] c"\50\6F\70" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k2 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\54\61\6B\65\41\74" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k3 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\52\65\6D\6F\76\65\41\74" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k4 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\77\61\70\52\65\6D\6F\76\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k5 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\52\65\6D\6F\76\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k6 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\43\6C\65\61\72" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k7 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\54\72\75\6E\63\61\74\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k8 = internal constant <{ [4 x i8] }> <{ [4 x i8] c"\54\61\6B\65" }>, align 8
@G_2ecompiler_2ffree_2eRemovalNames.k9 = internal constant <{ [8 x i8] }> <{ [8 x i8] c"\53\77\61\70\54\61\6B\65" }>, align 8
@G_2ecompiler_2ffree_2eSFail = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSFresh = constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSOk = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
define dso_local void @compiler_2ffree_2eLDestroy_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2ffree_2eLDestroy, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLYield_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 7, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eONew_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eOPar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRMade_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRNone_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRemovalNames_2einit() #0 {
entry:
  %l0 = alloca [9 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [9 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t9, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l0, i64 144, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eSFail_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eSMove_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7b44f9c52fd18b13_e1efb1736ad37507)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp eq i64 %t37, %t40
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t56, i64 %t57)
  br label %bb19
bb19:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %l8, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 41
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb7
bb6:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 41
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l17
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t29 = load i1, ptr %l17, !tbaa !21
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t30 = load i1, ptr %l13, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReport(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:letGo"
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/free:reason"
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca i64
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l34 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l64 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca %"compiler/free:letGo"
  %l100 = alloca i1
  %l101 = alloca ptr
  %l105 = alloca %"compiler/free:letGo"
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca %"compiler/free:letGo"
  %l117 = alloca i1
  %l118 = alloca ptr
  %l122 = alloca %"compiler/free:letGo"
  %l126 = alloca %"compiler/free:letGo"
  %l127 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l147 = alloca i1
  %l154 = alloca i64
  %l157 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i32
  %l167 = alloca %"compiler/free:letGo"
  %l172 = alloca i64
  %l176 = alloca i1
  %l180 = alloca %"compiler/free:letGo"
  %l187 = alloca %"compiler/free:letGo"
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l195 = alloca i64
  %l197 = alloca i1
  %l200 = alloca i1
  %l205 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l212 = alloca i64
  %l216 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l223 = alloca i64
  %l228 = alloca %"compiler/free:reason"
  %l233 = alloca i64
  %l238 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l260 = alloca { i64, ptr }
  %l263 = alloca i1
  %l277 = alloca { i64, ptr }
  %l278 = alloca { i64, ptr }
  %l279 = alloca i64
  %l280 = alloca { i64, ptr }
  %l284 = alloca ptr
  %l285 = alloca i64
  %l288 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l292 = alloca i64
  %l295 = alloca { i64, ptr }
  %l296 = alloca i64
  %l299 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l33
  br label %bb1
bb1:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t13, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l34
  br label %bb2
bb2:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 8
  %t20 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l37
  br label %bb3
bb3:
  %t21 = load i64, ptr %l37, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t22 = load i64, ptr %l7, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load i64, ptr %l8, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb9
bb6:
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l44, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l44, !tbaa !24
  store i64 %t48, ptr %l41, !tbaa !24
  br label %bb9
bb9:
  %t49 = load i64, ptr %l41, !tbaa !24
  store i64 %t49, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t50 = load i64, ptr %l10, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb122
bb12:
  br label %bb13
bb13:
  %t58 = load i64, ptr %l6, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l11, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l11, !tbaa !24
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l64
  br label %bb14
bb14:
  %t73 = load i1, ptr %l64, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb16:
  br label %bb17
bb17:
  store i64 -1, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:Free", ptr %t76, i32 0, i32 35
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l68
  br label %bb18
bb18:
  %t81 = load i64, ptr %l68, !tbaa !24
  store i64 %t81, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t88 = load i64, ptr %l15, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb24
bb21:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l15, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l75, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb23
bb23:
  %t108 = load i64, ptr %l75, !tbaa !24
  store i64 %t108, ptr %l72, !tbaa !24
  br label %bb24
bb24:
  %t109 = load i64, ptr %l72, !tbaa !24
  store i64 %t109, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t110 = load i64, ptr %l17, !tbaa !24
  %t111 = load i64, ptr %l16, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb27:
  br label %bb28
bb28:
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l17, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l18, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:Free", ptr %t128, i32 0, i32 35
  %t131 = load i64, ptr %l18, !tbaa !24
  %t134 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t130, i64 %t131)
  store %"compiler/free:letGo" %t134, ptr %l96
  br label %bb29
bb29:
  %t135 = getelementptr %"compiler/free:letGo", ptr %l96, i32 0, i32 0
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load i64, ptr %l11, !tbaa !24
  %t140 = icmp ne i64 %t136, %t137
  br i1 %t140, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb34
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l101, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 35
  %t146 = load i64, ptr %l18, !tbaa !24
  %t149 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t145, i64 %t146)
  store %"compiler/free:letGo" %t149, ptr %l105
  br label %bb32
bb32:
  %t150 = load ptr, ptr %l101, !tbaa !29
  %t151 = load %"compiler/free:letGo", ptr %l105
  %t152 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %t150, %"compiler/free:letGo" %t151)
  store i1 %t152, ptr %l106
  br label %bb33
bb33:
  %t153 = load i1, ptr %l106, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l100, !tbaa !21
  br label %bb34
bb34:
  %t156 = load i1, ptr %l100, !tbaa !21
  br i1 %t156, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb38
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t157, i32 0, i32 35
  %t160 = load i64, ptr %l18, !tbaa !24
  %t163 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t159, i64 %t160)
  store %"compiler/free:letGo" %t163, ptr %l112
  br label %bb37
bb37:
  %t164 = getelementptr %"compiler/free:letGo", ptr %l112, i32 0, i32 8
  %t165 = load i1, ptr %t164, !tbaa !21
  %t167 = xor i1 %t165, true
  store i1 %t167, ptr %l108, !tbaa !21
  br label %bb38
bb38:
  %t169 = load i1, ptr %l108, !tbaa !21
  br i1 %t169, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb40:
  br label %bb41
bb41:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t172 = icmp slt i64 %t170, 0
  br i1 %t172, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb47
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  store ptr %t174, ptr %l118, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 35
  %t178 = load i64, ptr %l18, !tbaa !24
  %t181 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t177, i64 %t178)
  store %"compiler/free:letGo" %t181, ptr %l122
  br label %bb44
bb44:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/free:Free", ptr %t182, i32 0, i32 35
  %t185 = load i64, ptr %l12, !tbaa !24
  %t188 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t184, i64 %t185)
  store %"compiler/free:letGo" %t188, ptr %l126
  br label %bb45
bb45:
  %t189 = load ptr, ptr %l118, !tbaa !29
  %t190 = load %"compiler/free:letGo", ptr %l122
  %t191 = load %"compiler/free:letGo", ptr %l126
  %t192 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %t189, %"compiler/free:letGo" %t190, %"compiler/free:letGo" %t191)
  store i1 %t192, ptr %l127
  br label %bb46
bb46:
  %t193 = load i1, ptr %l127, !tbaa !21
  store i1 %t193, ptr %l117, !tbaa !21
  br label %bb47
bb47:
  %t194 = load i1, ptr %l117, !tbaa !21
  br i1 %t194, label %bb48, label %bb49
bb48:
  %t195 = load i64, ptr %l18, !tbaa !24
  store i64 %t195, ptr %l12, !tbaa !24
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s5)
  br label %bb51
bb51:
  %t197 = load i64, ptr %l17, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l17, !tbaa !24
  br label %bb25
bb52:
  %t201 = load i64, ptr %l12, !tbaa !24
  %t203 = icmp slt i64 %t201, 0
  br i1 %t203, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb54:
  br label %bb55
bb55:
  %t205 = load i64, ptr %l3, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l3, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t209, i64 %t210)
  store i1 %t213, ptr %l137
  br label %bb56
bb56:
  %t214 = load i1, ptr %l137, !tbaa !21
  br i1 %t214, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb64
bb58:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:Free", ptr %t215, i32 0, i32 62
  %t218 = load i64, ptr %l11, !tbaa !24
  %t221 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t217, i64 %t218)
  store i1 %t221, ptr %l142
  br label %bb59
bb59:
  %t222 = load i1, ptr %l142, !tbaa !21
  br i1 %t222, label %bb60, label %bb61
bb60:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/free:Free", ptr %t223, i32 0, i32 64
  %t226 = load i64, ptr %l11, !tbaa !24
  %t229 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t225, i64 %t226)
  store i1 %t229, ptr %l147
  br label %bb62
bb61:
  store i1 false, ptr %l143, !tbaa !21
  br label %bb63
bb62:
  %t230 = load i1, ptr %l147, !tbaa !21
  store i1 %t230, ptr %l143, !tbaa !21
  br label %bb63
bb63:
  %t231 = load i1, ptr %l143, !tbaa !21
  store i1 %t231, ptr %l138, !tbaa !21
  br label %bb64
bb64:
  %t232 = load i1, ptr %l138, !tbaa !21
  br i1 %t232, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb66:
  br label %bb67
bb67:
  %t233 = load i64, ptr %l4, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l4, !tbaa !24
  %t237 = load i64, ptr %l12, !tbaa !24
  store i64 %t237, ptr %l19, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 36
  %t242 = load i64, ptr %l11, !tbaa !24
  %t245 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l154
  br label %bb68
bb68:
  %t246 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  %t247 = load i64, ptr %l154, !tbaa !24
  %t249 = icmp eq i64 %t247, %t246
  br i1 %t249, label %bb69, label %bb70
bb69:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/free:Free", ptr %t251, i32 0, i32 51
  %t254 = load i64, ptr %l11, !tbaa !24
  %t257 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t253, i64 %t254)
  %t258 = extractvalue { i32, i64 } %t257, 1
  %t259 = extractvalue { i32, i64 } %t257, 0
  store i32 %t259, ptr %l162
  %t260 = icmp ne i32 %t259, 0
  br i1 %t260, label %bb72, label %ok.261
ok.261:
  store i64 %t258, ptr %l161
  br label %bb71
bb70:
  br label %bb75
bb71:
  %t262 = load i64, ptr %l161, !tbaa !24
  store i64 %t262, ptr %l157, !tbaa !24
  br label %bb74
bb72:
  br label %bb73
bb73:
  call void @__olang_ert_req_clear()
  %t263 = load i64, ptr %l12, !tbaa !24
  store i64 %t263, ptr %l157, !tbaa !24
  br label %bb74
bb74:
  %t265 = load i64, ptr %l157, !tbaa !24
  store i64 %t265, ptr %l19, !tbaa !24
  br label %bb75
bb75:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 35
  %t269 = load i64, ptr %l19, !tbaa !24
  %t272 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t268, i64 %t269)
  store %"compiler/free:letGo" %t272, ptr %l167
  br label %bb76
bb76:
  %t273 = load %"compiler/free:letGo", ptr %l167
  store %"compiler/free:letGo" %t273, ptr %l20
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t276 = load i64, ptr %t275, !tbaa !24
  %t277 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 3
  %t278 = getelementptr %"compiler/source:Span", ptr %t277, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t281 = sext i32 %t279 to i64
  %t285 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t274, i64 %t276, i64 %t281)
  store i64 %t285, ptr %l172
  br label %bb77
bb77:
  %t286 = load i64, ptr %l172, !tbaa !24
  store i64 %t286, ptr %l21, !tbaa !24
  %t287 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 5
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t292 = icmp eq i64 %t288, %t289
  br i1 %t292, label %bb78, label %bb79
bb78:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/free:Free", ptr %t294, i32 0, i32 35
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t296, i64 %t297)
  store %"compiler/free:letGo" %t300, ptr %l180
  br label %bb80
bb79:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb81
bb80:
  %t301 = getelementptr %"compiler/free:letGo", ptr %l180, i32 0, i32 5
  %t302 = load i64, ptr %t301, !tbaa !24
  %t303 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t306 = icmp ne i64 %t302, %t303
  store i1 %t306, ptr %l176, !tbaa !21
  br label %bb81
bb81:
  %t308 = load i1, ptr %l176, !tbaa !21
  br i1 %t308, label %bb82, label %bb83
bb82:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:Free", ptr %t309, i32 0, i32 35
  %t312 = load i64, ptr %l12, !tbaa !24
  %t315 = call %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t311, i64 %t312)
  store %"compiler/free:letGo" %t315, ptr %l187
  br label %bb84
bb83:
  br label %bb85
bb84:
  %t316 = load %"compiler/free:letGo", ptr %l187
  store %"compiler/free:letGo" %t316, ptr %l20
  br label %bb85
bb85:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l188, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  store i64 %t319, ptr %l190, !tbaa !24
  %t320 = load i64, ptr %l190, !tbaa !24
  %t321 = mul i64 %t320, 1
  %t322 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t321)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  store { i64, ptr } %t324, ptr %l191, !tbaa !27
  %t325 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = load i64, ptr %l190, !tbaa !24
  %t330 = mul i64 %t329, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t326, ptr %t328, i64 %t330, i1 false)
  %t331 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t331, ptr %l22, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/free:Free", ptr %t332, i32 0, i32 9
  %t335 = load i64, ptr %l11, !tbaa !24
  %t338 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t334, i64 %t335)
  store i64 %t338, ptr %l195
  br label %bb86
bb86:
  %t339 = load i64, ptr %l195, !tbaa !24
  %t340 = icmp slt i64 %t339, 0
  br i1 %t340, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb90
bb88:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l11, !tbaa !24
  %t346 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t342, i64 %t343)
  store i1 %t346, ptr %l200
  br label %bb89
bb89:
  %t347 = load i1, ptr %l200, !tbaa !21
  store i1 %t347, ptr %l197, !tbaa !21
  br label %bb90
bb90:
  %t348 = load i1, ptr %l197, !tbaa !21
  br i1 %t348, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s13
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load i64, ptr %l11, !tbaa !24
  %t351 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 1
  %t352 = load i64, ptr %t351, !tbaa !24
  %t353 = load %"compiler/free:letGo", ptr %l20
  %t358 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %s13, ptr %t349, i64 %t350, i64 %t352, %"compiler/free:letGo" %t353)
  store { i64, ptr } %t358, ptr %l205
  br label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load %"compiler/free:letGo", ptr %l20
  %t363 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s15, ptr %t359, %"compiler/free:letGo" %t360)
  store { i64, ptr } %t363, ptr %l216
  br label %bb98
bb93:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load %"compiler/free:letGo", ptr %l20
  %t366 = load i64, ptr %l11, !tbaa !24
  %t370 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %s13, ptr %t364, %"compiler/free:letGo" %t365, i64 %t366)
  store { i64, ptr } %t370, ptr %l209
  br label %bb94
bb94:
  %t371 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t372 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t373 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t373, 1
  %t375 = extractvalue { i64, ptr } %t373, 0
  %t376 = add i64 %t372, %t375
  %t377 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t378 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t379 = add i64 %t376, %t378
  %t380 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = add i64 %t379, %t382
  %t384 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t371, i64 %t372)
  %t388 = getelementptr i8, ptr %t387, i64 %t372
  call void @olang_textcopy(ptr %t388, ptr %t374, i64 %t375)
  %t389 = getelementptr i8, ptr %t388, i64 %t375
  call void @olang_textcopy(ptr %t389, ptr %t377, i64 %t378)
  %t390 = getelementptr i8, ptr %t389, i64 %t378
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t384, i64 %t385)
  %t392 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t387, 1
  store { i64, ptr } %t393, ptr %l210, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 0
  %t396 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  store i64 %t397, ptr %l212, !tbaa !24
  %t399 = load i64, ptr %l212, !tbaa !24
  %t400 = icmp eq i64 %t395, %t399
  br i1 %t400, label %bb95, label %bb96
bb95:
  %t402 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l212, !tbaa !24
  %t407 = mul i64 %t406, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  br label %bb97
bb96:
  %t408 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t408, ptr %l22, !tbaa !27
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb98:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load %"compiler/free:letGo", ptr %l20
  %t411 = load i64, ptr %l11, !tbaa !24
  %t415 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %s15, ptr %t409, %"compiler/free:letGo" %t410, i64 %t411)
  store { i64, ptr } %t415, ptr %l220
  br label %bb99
bb99:
  %t416 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t418 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 1
  %t420 = extractvalue { i64, ptr } %t418, 0
  %t421 = add i64 %t417, %t420
  %t422 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t424 = add i64 %t421, %t423
  %t425 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = extractvalue { i64, ptr } %t425, 0
  %t428 = add i64 %t424, %t427
  %t429 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t430 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t431 = add i64 %t428, %t430
  %t432 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t431)
  call void @olang_textcopy(ptr %t432, ptr %t416, i64 %t417)
  %t433 = getelementptr i8, ptr %t432, i64 %t417
  call void @olang_textcopy(ptr %t433, ptr %t419, i64 %t420)
  %t434 = getelementptr i8, ptr %t433, i64 %t420
  call void @olang_textcopy(ptr %t434, ptr %t422, i64 %t423)
  %t435 = getelementptr i8, ptr %t434, i64 %t423
  call void @olang_textcopy(ptr %t435, ptr %t426, i64 %t427)
  %t436 = getelementptr i8, ptr %t435, i64 %t427
  call void @olang_textcopy(ptr %t436, ptr %t429, i64 %t430)
  %t437 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t438 = insertvalue { i64, ptr } %t437, ptr %t432, 1
  store { i64, ptr } %t438, ptr %l221, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  %t441 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 0
  store i64 %t442, ptr %l223, !tbaa !24
  %t444 = load i64, ptr %l223, !tbaa !24
  %t445 = icmp eq i64 %t440, %t444
  br i1 %t445, label %bb100, label %bb101
bb100:
  %t447 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = load i64, ptr %l223, !tbaa !24
  %t452 = mul i64 %t451, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t448, ptr %t450, i64 %t452, i1 false)
  br label %bb102
bb101:
  %t453 = load { i64, ptr }, ptr %l221, !tbaa !27
  store { i64, ptr } %t453, ptr %l22, !tbaa !27
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s15)
  br label %bb103
bb103:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/free:Free", ptr %t454, i32 0, i32 38
  %t457 = load i64, ptr %l11, !tbaa !24
  %t460 = call %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t456, i64 %t457)
  store %"compiler/free:reason" %t460, ptr %l228
  br label %bb104
bb104:
  %t461 = load %"compiler/free:reason", ptr %l228
  store %"compiler/free:reason" %t461, ptr %l23
  %t462 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 3
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l24, !tbaa !27
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/free:Free", ptr %t465, i32 0, i32 36
  %t468 = load i64, ptr %l11, !tbaa !24
  %t471 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t467, i64 %t468)
  store i64 %t471, ptr %l233
  br label %bb105
bb105:
  %t472 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t473 = load i64, ptr %l233, !tbaa !24
  %t475 = icmp eq i64 %t473, %t472
  br i1 %t475, label %bb106, label %bb107
bb106:
  store { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb108
bb107:
  br label %bb108
bb108:
  %t477 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 1
  %t478 = load i64, ptr %t477, !tbaa !24
  %t480 = icmp sge i64 %t478, 0
  br i1 %t480, label %bb109, label %bb110
bb109:
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t483 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 1
  %t484 = load i64, ptr %t483, !tbaa !24
  %t485 = getelementptr %"compiler/free:reason", ptr %l23, i32 0, i32 2
  %t486 = getelementptr %"compiler/source:Span", ptr %t485, i32 0, i32 0
  %t487 = load i32, ptr %t486, !tbaa !23
  %t489 = sext i32 %t487 to i64
  %t493 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t482, i64 %t484, i64 %t489)
  store { i64, ptr } %t493, ptr %l243
  br label %bb111
bb110:
  %t494 = load ptr, ptr %l1, !tbaa !29
  %t495 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t496 = load i64, ptr %t495, !tbaa !24
  %t497 = load i64, ptr %l21, !tbaa !24
  %t501 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t494, i64 %t496, i64 %t497)
  store { i64, ptr } %t501, ptr %l248
  br label %bb112
bb111:
  %t502 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t503, i64 %t504)
  %t506 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t507 = insertvalue { i64, ptr } %t506, ptr %t505, 1
  store { i64, ptr } %t507, ptr %l238, !tbaa !27
  br label %bb113
bb112:
  %t509 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t510 = extractvalue { i64, ptr } %t509, 1
  %t511 = extractvalue { i64, ptr } %t509, 0
  %t512 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t510, i64 %t511)
  %t513 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  store { i64, ptr } %t514, ptr %l238, !tbaa !27
  br label %bb113
bb113:
  %t516 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t516, ptr %l25, !tbaa !27
  %t517 = load ptr, ptr %l1, !tbaa !29
  %t518 = getelementptr %"compiler/free:letGo", ptr %l20, i32 0, i32 2
  %t519 = load i64, ptr %t518, !tbaa !24
  %t520 = load i64, ptr %l21, !tbaa !24
  %t524 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t517, i64 %t519, i64 %t520)
  store { i64, ptr } %t524, ptr %l253
  br label %bb114
bb114:
  %t525 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t526 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t527 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t528 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t532 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t533 = add i64 %t530, %t532
  %t535 = extractvalue { i64, ptr } %t525, 1
  %t536 = extractvalue { i64, ptr } %t525, 0
  %t537 = add i64 %t533, %t536
  %t538 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t539 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t540 = add i64 %t537, %t539
  %t542 = extractvalue { i64, ptr } %t526, 1
  %t543 = extractvalue { i64, ptr } %t526, 0
  %t544 = add i64 %t540, %t543
  %t545 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t546 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t547 = add i64 %t544, %t546
  %t549 = extractvalue { i64, ptr } %t527, 1
  %t550 = extractvalue { i64, ptr } %t527, 0
  %t551 = add i64 %t547, %t550
  %t552 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t553 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t554 = add i64 %t551, %t553
  %t555 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t554)
  call void @olang_textcopy(ptr %t555, ptr %t529, i64 %t530)
  %t556 = getelementptr i8, ptr %t555, i64 %t530
  call void @olang_textcopy(ptr %t556, ptr %t531, i64 %t532)
  %t557 = getelementptr i8, ptr %t556, i64 %t532
  call void @olang_textcopy(ptr %t557, ptr %t535, i64 %t536)
  %t558 = getelementptr i8, ptr %t557, i64 %t536
  call void @olang_textcopy(ptr %t558, ptr %t538, i64 %t539)
  %t559 = getelementptr i8, ptr %t558, i64 %t539
  call void @olang_textcopy(ptr %t559, ptr %t542, i64 %t543)
  %t560 = getelementptr i8, ptr %t559, i64 %t543
  call void @olang_textcopy(ptr %t560, ptr %t545, i64 %t546)
  %t561 = getelementptr i8, ptr %t560, i64 %t546
  call void @olang_textcopy(ptr %t561, ptr %t549, i64 %t550)
  %t562 = getelementptr i8, ptr %t561, i64 %t550
  call void @olang_textcopy(ptr %t562, ptr %t552, i64 %t553)
  %t563 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t564 = insertvalue { i64, ptr } %t563, ptr %t555, 1
  store { i64, ptr } %t564, ptr %l26, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t566, ptr %l258, !tbaa !27
  %t567 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  store i64 %t568, ptr %l259, !tbaa !24
  %t569 = load i64, ptr %l259, !tbaa !24
  %t570 = mul i64 %t569, 1
  %t571 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t570)
  %t572 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t573 = insertvalue { i64, ptr } %t572, ptr %t571, 1
  store { i64, ptr } %t573, ptr %l260, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = load i64, ptr %l259, !tbaa !24
  %t579 = mul i64 %t578, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t575, ptr %t577, i64 %t579, i1 false)
  %t580 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t584 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t580)
  store i1 %t584, ptr %l263
  br label %bb115
bb115:
  %t585 = load i1, ptr %l263, !tbaa !21
  %t586 = xor i1 %t585, true
  br i1 %t586, label %bb116, label %bb117
bb116:
  %t588 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t590 = extractvalue { i64, ptr } %t588, 1
  %t591 = extractvalue { i64, ptr } %t588, 0
  %t592 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t590, i64 %t591)
  %t593 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  %t596 = extractvalue { i64, ptr } %t594, 0
  %t597 = extractvalue { i64, ptr } %t594, 1
  %t598 = mul i64 %t596, 1
  %t599 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t598)
  call void @llvm.memcpy.p0.p0.i64(ptr %t599, ptr %t597, i64 %t598, i1 false)
  %t600 = insertvalue { i64, ptr } undef, i64 %t596, 0
  %t601 = insertvalue { i64, ptr } %t600, ptr %t599, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } %t601)
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t604 = load { i64, ptr }, ptr %l26, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t604)
  br label %bb119
bb119:
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s2)
  br label %bb121
bb121:
  %t607 = load i64, ptr %l10, !tbaa !24
  %t609 = add i64 %t607, 1
  store i64 %t609, ptr %l10, !tbaa !24
  br label %bb10
bb122:
  %t611 = load i64, ptr %l3, !tbaa !24
  %t613 = icmp eq i64 %t611, 0
  br i1 %t613, label %bb123, label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %l2, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t617 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t617, ptr %l277
  br label %bb126
bb126:
  %t618 = load { i64, ptr }, ptr %l277, !tbaa !27
  store { i64, ptr } %t618, ptr %l278, !tbaa !27
  %t619 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 0
  store i64 %t620, ptr %l279, !tbaa !24
  %t621 = load i64, ptr %l279, !tbaa !24
  %t622 = mul i64 %t621, 1
  %t623 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 %t621, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  store { i64, ptr } %t625, ptr %l280, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !27
  %t630 = load i64, ptr %l279, !tbaa !24
  %t631 = mul i64 %t630, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t627, ptr %t629, i64 %t631, i1 false)
  %t632 = load { i64, ptr }, ptr %l280, !tbaa !27
  store { i64, ptr } %t632, ptr %l278, !tbaa !27
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t633 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t633, ptr %rv
  br label %ret
bb127:
  %t634 = load i64, ptr %l3, !tbaa !24
  %t635 = load i64, ptr %l4, !tbaa !24
  %t638 = sub i64 %t634, %t635
  store i64 %t638, ptr %l28, !tbaa !24
  store ptr %l2, ptr %l284, !tbaa !29
  %t640 = load i64, ptr %l3, !tbaa !24
  store i64 %t640, ptr %l285, !tbaa !24
  %t641 = load i64, ptr %l3, !tbaa !24
  %t643 = icmp eq i64 %t641, 1
  br i1 %t643, label %bb128, label %bb129
bb128:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l288, !tbaa !27
  br label %bb130
bb129:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l288, !tbaa !27
  br label %bb130
bb130:
  %t645 = load i64, ptr %l3, !tbaa !24
  %t647 = icmp eq i64 %t645, 1
  br i1 %t647, label %bb131, label %bb132
bb131:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l291, !tbaa !27
  br label %bb133
bb132:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l291, !tbaa !27
  br label %bb133
bb133:
  %t649 = load i64, ptr %l28, !tbaa !24
  store i64 %t649, ptr %l292, !tbaa !24
  %t650 = load i64, ptr %l28, !tbaa !24
  %t652 = icmp eq i64 %t650, 1
  br i1 %t652, label %bb134, label %bb135
bb134:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l295, !tbaa !27
  br label %bb136
bb135:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l295, !tbaa !27
  br label %bb136
bb136:
  %t654 = load i64, ptr %l4, !tbaa !24
  store i64 %t654, ptr %l296, !tbaa !24
  %t655 = load i64, ptr %l4, !tbaa !24
  %t657 = icmp eq i64 %t655, 1
  br i1 %t657, label %bb137, label %bb138
bb137:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l299, !tbaa !27
  br label %bb139
bb138:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l299, !tbaa !27
  br label %bb139
bb139:
  %t659 = load i64, ptr %l4, !tbaa !24
  %t661 = icmp sgt i64 %t659, 0
  br i1 %t661, label %bb140, label %bb141
bb140:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l302, !tbaa !27
  br label %bb142
bb141:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l302, !tbaa !27
  br label %bb142
bb142:
  %t663 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t664 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t665 = load i64, ptr %l285, !tbaa !24
  %t666 = call i64 @__olang_fmt_i64(ptr null, i64 %t665)
  %t667 = add i64 %t664, %t666
  %t668 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t669 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t670 = add i64 %t667, %t669
  %t671 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t672 = extractvalue { i64, ptr } %t671, 1
  %t673 = extractvalue { i64, ptr } %t671, 0
  %t674 = add i64 %t670, %t673
  %t675 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t678 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t678, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  %t681 = add i64 %t677, %t680
  %t682 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t684 = add i64 %t681, %t683
  %t685 = load i64, ptr %l292, !tbaa !24
  %t686 = call i64 @__olang_fmt_i64(ptr null, i64 %t685)
  %t687 = add i64 %t684, %t686
  %t688 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t691 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t691, 1
  %t693 = extractvalue { i64, ptr } %t691, 0
  %t694 = add i64 %t690, %t693
  %t695 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t696 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t697 = add i64 %t694, %t696
  %t698 = load i64, ptr %l296, !tbaa !24
  %t699 = call i64 @__olang_fmt_i64(ptr null, i64 %t698)
  %t700 = add i64 %t697, %t699
  %t701 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t702 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t703 = add i64 %t700, %t702
  %t704 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t704, 1
  %t706 = extractvalue { i64, ptr } %t704, 0
  %t707 = add i64 %t703, %t706
  %t708 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t710 = add i64 %t707, %t709
  %t711 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t712 = extractvalue { i64, ptr } %t711, 1
  %t713 = extractvalue { i64, ptr } %t711, 0
  %t714 = add i64 %t710, %t713
  %t715 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t717 = add i64 %t714, %t716
  %t718 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t717)
  call void @olang_textcopy(ptr %t718, ptr %t663, i64 %t664)
  %t719 = getelementptr i8, ptr %t718, i64 %t664
  %t720 = call i64 @__olang_fmt_i64(ptr %t719, i64 %t665)
  %t721 = getelementptr i8, ptr %t719, i64 %t666
  call void @olang_textcopy(ptr %t721, ptr %t668, i64 %t669)
  %t722 = getelementptr i8, ptr %t721, i64 %t669
  call void @olang_textcopy(ptr %t722, ptr %t672, i64 %t673)
  %t723 = getelementptr i8, ptr %t722, i64 %t673
  call void @olang_textcopy(ptr %t723, ptr %t675, i64 %t676)
  %t724 = getelementptr i8, ptr %t723, i64 %t676
  call void @olang_textcopy(ptr %t724, ptr %t679, i64 %t680)
  %t725 = getelementptr i8, ptr %t724, i64 %t680
  call void @olang_textcopy(ptr %t725, ptr %t682, i64 %t683)
  %t726 = getelementptr i8, ptr %t725, i64 %t683
  %t727 = call i64 @__olang_fmt_i64(ptr %t726, i64 %t685)
  %t728 = getelementptr i8, ptr %t726, i64 %t686
  call void @olang_textcopy(ptr %t728, ptr %t688, i64 %t689)
  %t729 = getelementptr i8, ptr %t728, i64 %t689
  call void @olang_textcopy(ptr %t729, ptr %t692, i64 %t693)
  %t730 = getelementptr i8, ptr %t729, i64 %t693
  call void @olang_textcopy(ptr %t730, ptr %t695, i64 %t696)
  %t731 = getelementptr i8, ptr %t730, i64 %t696
  %t732 = call i64 @__olang_fmt_i64(ptr %t731, i64 %t698)
  %t733 = getelementptr i8, ptr %t731, i64 %t699
  call void @olang_textcopy(ptr %t733, ptr %t701, i64 %t702)
  %t734 = getelementptr i8, ptr %t733, i64 %t702
  call void @olang_textcopy(ptr %t734, ptr %t705, i64 %t706)
  %t735 = getelementptr i8, ptr %t734, i64 %t706
  call void @olang_textcopy(ptr %t735, ptr %t708, i64 %t709)
  %t736 = getelementptr i8, ptr %t735, i64 %t709
  call void @olang_textcopy(ptr %t736, ptr %t712, i64 %t713)
  %t737 = getelementptr i8, ptr %t736, i64 %t713
  call void @olang_textcopy(ptr %t737, ptr %t715, i64 %t716)
  %t738 = insertvalue { i64, ptr } undef, i64 %t717, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t718, 1
  %t741 = extractvalue { i64, ptr } %t739, 0
  %t742 = extractvalue { i64, ptr } %t739, 1
  %t743 = mul i64 %t741, 1
  %t744 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t743)
  call void @llvm.memcpy.p0.p0.i64(ptr %t744, ptr %t742, i64 %t743, i1 false)
  %t745 = insertvalue { i64, ptr } undef, i64 %t741, 0
  %t746 = insertvalue { i64, ptr } %t745, ptr %t744, 1
  %t747 = load ptr, ptr %l284, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t747, { i64, ptr } %t746)
  br label %bb143
bb143:
  %t750 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t750, ptr %l306
  br label %bb144
bb144:
  %t751 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t751, ptr %l307, !tbaa !27
  %t752 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t753 = extractvalue { i64, ptr } %t752, 0
  store i64 %t753, ptr %l308, !tbaa !24
  %t754 = load i64, ptr %l308, !tbaa !24
  %t755 = mul i64 %t754, 1
  %t756 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t755)
  %t757 = insertvalue { i64, ptr } undef, i64 %t754, 0
  %t758 = insertvalue { i64, ptr } %t757, ptr %t756, 1
  store { i64, ptr } %t758, ptr %l309, !tbaa !27
  %t759 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t760 = load ptr, ptr %t759, !tbaa !27
  %t761 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = load i64, ptr %l308, !tbaa !24
  %t764 = mul i64 %t763, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t760, ptr %t762, i64 %t764, i1 false)
  %t765 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t765, ptr %l307, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t766 = load { i64, ptr }, ptr %l307, !tbaa !27
  store { i64, ptr } %t766, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSolePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  store i64 %t13, ptr %l9
  br label %bb4
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t15, i64 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load i64, ptr %l2, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb8
bb7:
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t23 = load i64, ptr %l13, !tbaa !24
  store i64 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca i64
  %l28 = alloca i32
  %l30 = alloca i64
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i64
  %l69 = alloca i64
  %l76 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:Free", ptr %t10, i32 0, i32 1
  %t16 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t12, i64 %a1)
  store ptr %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l19, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t20 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t20, ptr %l4
  %t22 = load { i64, [2 x i64] }, ptr %l4
  %t24 = extractvalue { i64, [2 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  store i64 %t29, ptr %l5, !tbaa !24
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t31, i64 %t32)
  store i32 %t35, ptr %l28
  br label %bb6
bb6:
  %t36 = load i32, ptr %l28, !tbaa !23
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb7, label %bb8
bb7:
  store i64 -3, ptr %l30, !tbaa !24
  br label %bb11
bb8:
  %t39 = load ptr, ptr %l2, !tbaa !29
  store ptr %t39, ptr %l31, !tbaa !29
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l34
  br label %bb9
bb9:
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t45, i64 %t46)
  store i64 %t47, ptr %l35
  br label %bb10
bb10:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l30, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l30, !tbaa !24
  store i64 %t49, ptr %l22, !tbaa !24
  br label %bb52
bb12:
  %t50 = load { i64, [2 x i64] }, ptr %l4
  %t52 = extractvalue { i64, [2 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 1
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  %t59 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t60 = getelementptr { i32, i32 }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l7, !tbaa !23
  br label %bb15
bb14:
  br label %bb20
bb15:
  %t63 = load i32, ptr %l7, !tbaa !23
  %t65 = icmp ne i32 %t63, 0
  br i1 %t65, label %bb16, label %bb17
bb16:
  store i64 -3, ptr %l42, !tbaa !24
  br label %bb19
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l6, !tbaa !23
  %t71 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l45
  br label %bb18
bb18:
  %t72 = load i64, ptr %l45, !tbaa !24
  store i64 %t72, ptr %l42, !tbaa !24
  br label %bb19
bb19:
  %t73 = load i64, ptr %l42, !tbaa !24
  store i64 %t73, ptr %l22, !tbaa !24
  br label %bb52
bb20:
  %t74 = load { i64, [2 x i64] }, ptr %l4
  %t76 = extractvalue { i64, [2 x i64] } %t74, 0
  %t77 = icmp eq i64 %t76, 3
  br i1 %t77, label %bb21, label %bb22
bb21:
  %t79 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t80 = getelementptr { i32 }, ptr %t79, i32 0, i32 0
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l8, !tbaa !23
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l8, !tbaa !23
  %t87 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l51
  br label %bb24
bb24:
  %t88 = load i64, ptr %l51, !tbaa !24
  store i64 %t88, ptr %l22, !tbaa !24
  br label %bb52
bb25:
  %t89 = load { i64, [2 x i64] }, ptr %l4
  %t91 = extractvalue { i64, [2 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 6
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t95 = getelementptr { i64, i32 }, ptr %t94, i32 0, i32 0
  %t96 = load i64, ptr %t95
  store i64 %t96, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t98 = load i64, ptr %l9, !tbaa !24
  store i64 %t98, ptr %l22, !tbaa !24
  br label %bb52
bb29:
  %t100 = load { i64, [2 x i64] }, ptr %l4
  %t102 = extractvalue { i64, [2 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 5
  br i1 %t103, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/load:Loader", ptr %t108, i32 0, i32 7
  %t111 = load i64, ptr %t110, !tbaa !24
  store i64 %t111, ptr %l22, !tbaa !24
  br label %bb52
bb33:
  %t113 = load { i64, [2 x i64] }, ptr %l4
  %t115 = extractvalue { i64, [2 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 9
  br i1 %t116, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i64 -3, ptr %l22, !tbaa !24
  br label %bb52
bb37:
  %t118 = load { i64, [2 x i64] }, ptr %l4
  %t120 = extractvalue { i64, [2 x i64] } %t118, 0
  %t121 = icmp eq i64 %t120, 4
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t124 = getelementptr { i32 }, ptr %t123, i32 0, i32 0
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l10, !tbaa !23
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l10, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t133 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t127, i64 %t130)
  store i64 %t133, ptr %l69
  br label %bb41
bb41:
  %t134 = load i64, ptr %l69, !tbaa !24
  store i64 %t134, ptr %l22, !tbaa !24
  br label %bb52
bb42:
  %t135 = load { i64, [2 x i64] }, ptr %l4
  %t137 = extractvalue { i64, [2 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 8
  br i1 %t138, label %bb43, label %bb44
bb43:
  %t140 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t141 = getelementptr { i32, i32, i64 }, ptr %t140, i32 0, i32 0
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l11, !tbaa !23
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l11, !tbaa !23
  %t147 = sext i32 %t145 to i64
  %t150 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t144, i64 %t147)
  store i64 %t150, ptr %l76
  br label %bb46
bb46:
  %t151 = load i64, ptr %l76, !tbaa !24
  store i64 %t151, ptr %l22, !tbaa !24
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i64 -4, ptr %l22, !tbaa !24
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_26303021143ae8be_4bef98a84a02e70a)
  unreachable
bb52:
  %t152 = load i64, ptr %l22, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i1
  %l9 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l20 = alloca { ptr, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 2
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 5
  %t19 = load { ptr, ptr }, ptr %t18
  %t21 = extractvalue { ptr, ptr } %t19, 0
  %t22 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t23 = icmp eq ptr %t21, %t22
  %t24 = extractvalue { ptr, ptr } %t19, 1
  %t25 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t26 = icmp eq ptr %t24, %t25
  %t27 = and i1 %t23, %t26
  store i1 %t27, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l9, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l16, !tbaa !24
  %t33 = load i64, ptr %l16, !tbaa !24
  %t34 = mul i64 %t33, 1
  %t35 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t34)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l17, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = load i64, ptr %l16, !tbaa !24
  %t43 = mul i64 %t42, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t39, ptr %t41, i64 %t43, i1 false)
  %t44 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t44, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/scope:Scoper", ptr %t49, i32 0, i32 5
  %t52 = load { ptr, ptr }, ptr %t51
  store { ptr, ptr } %t52, ptr %l20
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load i32, ptr %l1, !tbaa !23
  %t57 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t53, i32 %t54)
  store i32 %t57, ptr %l23
  br label %bb9
bb9:
  %t58 = load { ptr, ptr }, ptr %l20
  %t59 = extractvalue { ptr, ptr } %t58, 0
  %t60 = extractvalue { ptr, ptr } %t58, 1
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = call { i64, ptr } %t59(ptr %t60, ptr %s0, i32 %t61)
  store { i64, ptr } %t62, ptr %l24
  br label %bb10
bb10:
  %t63 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t64, i64 %t65)
  %t70 = getelementptr i8, ptr %t69, i64 %t65
  call void @olang_textcopy(ptr %t70, ptr %t66, i64 %t67)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4cef24e7d17769b7_e2744f91577a9953)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestroyErrors(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:reason"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l56 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i64
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l80 = alloca i1
  %l81 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca %"compiler/typed:Local"
  %l104 = alloca { i64, ptr }
  %l107 = alloca i64
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i64
  %l117 = alloca %"compiler/source:Span"
  %l124 = alloca i1
  %l125 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca { i64, [3 x i64] }
  %l133 = alloca %"compiler/msgs:Msg"
  %l134 = alloca i64
  %l138 = alloca i1
  %l142 = alloca %"compiler/source:Span"
  %l143 = alloca ptr
  %l150 = alloca { i64, [3 x i64] }
  %l151 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l154 = alloca i64
  %l158 = alloca %"compiler/source:Span"
  %l161 = alloca i64
  %l162 = alloca %"compiler/msgs:Msg"
  %l163 = alloca i64
  %l164 = alloca ptr
  %l165 = alloca i64
  %l166 = alloca { i64, [3 x i64] }
  %l168 = alloca %"compiler/msgs:Msg"
  %l169 = alloca ptr
  %l170 = alloca { i64, [3 x i64] }
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca i64
  %l177 = alloca %"compiler/free:reason"
  %l180 = alloca ptr
  %l181 = alloca i64
  %l187 = alloca { i64, [3 x i64] }
  %l189 = alloca %"compiler/msgs:Msg"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca { i64, [3 x i64] }
  %l194 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t213 = alloca { i64, [3 x i64] }, align 8
  %t279 = alloca { i64, [3 x i64] }, align 8
  %t365 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 66
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l1, !tbaa !29
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l24
  br label %bb4
bb4:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 8
  %t25 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l27
  br label %bb5
bb5:
  %t26 = load i64, ptr %l27, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb11
bb8:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l34, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t53 = load i64, ptr %l34, !tbaa !24
  store i64 %t53, ptr %l31, !tbaa !24
  br label %bb11
bb11:
  %t54 = load i64, ptr %l31, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb70
bb14:
  br label %bb15
bb15:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  store i64 %t71, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t73, i64 %t74)
  store i1 %t77, ptr %l54
  br label %bb16
bb16:
  %t78 = load i1, ptr %l54, !tbaa !21
  %t79 = xor i1 %t78, true
  br i1 %t79, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb20
bb18:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 60
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t87, ptr %l60
  br label %bb19
bb19:
  %t88 = load i1, ptr %l60, !tbaa !21
  store i1 %t88, ptr %l56, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l56, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb22:
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 54
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  store i64 %t96, ptr %l64
  br label %bb24
bb24:
  %t97 = load i64, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:Free", ptr %t98, i32 0, i32 1
  %t104 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t100, i64 %t97)
  store ptr %t104, ptr %l68
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l68, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  store ptr %l2, ptr %l69, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 56
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t108, i64 %t109)
  store %"compiler/source:Span" %t112, ptr %l73
  br label %bb26
bb26:
  %t113 = getelementptr %"compiler/source:Span", ptr %l73, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = sext i32 %t114 to i64
  %t118 = mul i64 %t116, 4096
  %t119 = load ptr, ptr %l10, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 3
  %t122 = load i64, ptr %t121, !tbaa !24
  %t125 = add i64 %t118, %t122
  %t126 = load ptr, ptr %l69, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2ehas(ptr %s0, ptr %t126, i64 %t125)
  store i1 %t128, ptr %l80
  br label %bb27
bb27:
  %t129 = load i1, ptr %l80, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb29:
  br label %bb30
bb30:
  store ptr %l2, ptr %l81, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:Free", ptr %t130, i32 0, i32 56
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t132, i64 %t133)
  store %"compiler/source:Span" %t136, ptr %l85
  br label %bb31
bb31:
  %t137 = getelementptr %"compiler/source:Span", ptr %l85, i32 0, i32 0
  %t138 = load i32, ptr %t137, !tbaa !23
  %t140 = sext i32 %t138 to i64
  %t142 = mul i64 %t140, 4096
  %t143 = load ptr, ptr %l10, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 3
  %t146 = load i64, ptr %t145, !tbaa !24
  %t149 = add i64 %t142, %t146
  %t150 = load ptr, ptr %l81, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t150, i64 %t149)
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  store ptr %t161, ptr %l95, !tbaa !29
  %t162 = load ptr, ptr %l10, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 7
  store ptr %t164, ptr %l97, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:Free", ptr %t165, i32 0, i32 55
  %t168 = load i64, ptr %l8, !tbaa !24
  %t171 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t167, i64 %t168)
  store i64 %t171, ptr %l101
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l97, !tbaa !29
  %t173 = load i64, ptr %l101, !tbaa !24
  %t174 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t172, i64 %t173)
  store %"compiler/typed:Local" %t174, ptr %l102
  br label %bb34
bb34:
  %t175 = getelementptr %"compiler/typed:Local", ptr %l102, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t177, i32 %t176)
  store { i64, ptr } %t179, ptr %l104
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t181, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l11, !tbaa !27
  %t187 = load ptr, ptr %l10, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 3
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l107, !tbaa !24
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/free:Free", ptr %t191, i32 0, i32 56
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t193, i64 %t194)
  store %"compiler/source:Span" %t197, ptr %l111
  br label %bb36
bb36:
  %t198 = getelementptr %"compiler/source:Span", ptr %l111, i32 0, i32 0
  %t199 = load i32, ptr %t198, !tbaa !23
  %t201 = sext i32 %t199 to i64
  store i64 %t201, ptr %l113, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:Free", ptr %t202, i32 0, i32 56
  %t205 = load i64, ptr %l8, !tbaa !24
  %t208 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t204, i64 %t205)
  store %"compiler/source:Span" %t208, ptr %l117
  br label %bb37
bb37:
  %t209 = getelementptr %"compiler/source:Span", ptr %l117, i32 0, i32 1
  %t210 = load i32, ptr %t209, !tbaa !23
  %t212 = sext i32 %t210 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 0
  store i64 3, ptr %t214
  %t215 = load i64, ptr %l107, !tbaa !24
  %t216 = insertvalue { i64, i64, i64 } undef, i64 %t215, 0
  %t217 = load i64, ptr %l113, !tbaa !24
  %t218 = insertvalue { i64, i64, i64 } %t216, i64 %t217, 1
  %t220 = insertvalue { i64, i64, i64 } %t218, i64 %t212, 2
  %t221 = getelementptr { i64, [3 x i64] }, ptr %t213, i32 0, i32 1
  store { i64, i64, i64 } %t220, ptr %t221
  %t222 = load { i64, [3 x i64] }, ptr %t213
  store { i64, [3 x i64] } %t222, ptr %l12
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/free:Free", ptr %t224, i32 0, i32 58
  %t227 = load i64, ptr %l8, !tbaa !24
  %t230 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t226, i64 %t227)
  store i1 %t230, ptr %l124
  br label %bb38
bb38:
  %t231 = load i1, ptr %l124, !tbaa !21
  br i1 %t231, label %bb39, label %bb40
bb39:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/free:Free", ptr %t232, i32 0, i32 59
  %t235 = load i64, ptr %l8, !tbaa !24
  %t238 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t234, i64 %t235)
  store i1 %t238, ptr %l129
  br label %bb41
bb40:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb42
bb41:
  %t239 = load i1, ptr %l129, !tbaa !21
  store i1 %t239, ptr %l125, !tbaa !21
  br label %bb42
bb42:
  %t240 = load i1, ptr %l125, !tbaa !21
  br i1 %t240, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  %t241 = load ptr, ptr %l1, !tbaa !29
  store ptr %t241, ptr %l130, !tbaa !29
  %t242 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t242, ptr %l131
  %t243 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t245 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %s3, ptr %s7, { i64, ptr } %t243)
  store %"compiler/msgs:Msg" %t245, ptr %l133
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t246 = load ptr, ptr %l130, !tbaa !29
  %t247 = load { i64, [3 x i64] }, ptr %l131
  %t248 = load %"compiler/msgs:Msg", ptr %l133
  %t249 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s7, ptr %t246, { i64, [3 x i64] } %t247, %"compiler/msgs:Msg" %t248)
  store i64 %t249, ptr %l134
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb47:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/free:Free", ptr %t250, i32 0, i32 58
  %t253 = load i64, ptr %l8, !tbaa !24
  %t256 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t252, i64 %t253)
  store i1 %t256, ptr %l138
  br label %bb48
bb48:
  %t257 = load i1, ptr %l138, !tbaa !21
  br i1 %t257, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/free:Free", ptr %t258, i32 0, i32 57
  %t261 = load i64, ptr %l8, !tbaa !24
  %t264 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t260, i64 %t261)
  store %"compiler/source:Span" %t264, ptr %l142
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t265 = load %"compiler/source:Span", ptr %l142
  store %"compiler/source:Span" %t265, ptr %l13
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  %t267 = load ptr, ptr %l10, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 0
  %t272 = load i32, ptr %t271, !tbaa !23
  %t274 = sext i32 %t272 to i64
  %t275 = getelementptr %"compiler/source:Span", ptr %l13, i32 0, i32 1
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 0
  store i64 3, ptr %t280
  %t282 = insertvalue { i64, i64, i64 } undef, i64 %t270, 0
  %t284 = insertvalue { i64, i64, i64 } %t282, i64 %t274, 1
  %t286 = insertvalue { i64, i64, i64 } %t284, i64 %t278, 2
  %t287 = getelementptr { i64, [3 x i64] }, ptr %t279, i32 0, i32 1
  store { i64, i64, i64 } %t286, ptr %t287
  %t288 = load { i64, [3 x i64] }, ptr %t279
  store { i64, [3 x i64] } %t288, ptr %l150
  %t289 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t289, ptr %l151, !tbaa !27
  %t290 = load ptr, ptr %l1, !tbaa !29
  store ptr %t290, ptr %l152, !tbaa !29
  %t291 = load ptr, ptr %l10, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 3
  %t294 = load i64, ptr %t293, !tbaa !24
  store i64 %t294, ptr %l154, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/free:Free", ptr %t295, i32 0, i32 56
  %t298 = load i64, ptr %l8, !tbaa !24
  %t301 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t297, i64 %t298)
  store %"compiler/source:Span" %t301, ptr %l158
  br label %bb52
bb52:
  %t302 = getelementptr %"compiler/source:Span", ptr %l158, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = sext i32 %t303 to i64
  %t306 = load ptr, ptr %l152, !tbaa !29
  %t307 = load i64, ptr %l154, !tbaa !24
  %t309 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t306, i64 %t307, i64 %t305)
  store i64 %t309, ptr %l161
  br label %bb53
bb53:
  %t310 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t311 = load i64, ptr %l161, !tbaa !24
  %t312 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %s3, ptr %s8, { i64, ptr } %t310, i64 %t311)
  store %"compiler/msgs:Msg" %t312, ptr %l162
  br label %bb54
bb54:
  %t313 = load ptr, ptr %l143, !tbaa !29
  %t314 = load { i64, [3 x i64] }, ptr %l150
  %t315 = load %"compiler/msgs:Msg", ptr %l162
  %t316 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s8, ptr %t313, { i64, [3 x i64] } %t314, %"compiler/msgs:Msg" %t315)
  store i64 %t316, ptr %l163
  br label %bb55
bb55:
  %t317 = load i64, ptr %l163, !tbaa !24
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l164, !tbaa !29
  store i64 %t317, ptr %l165, !tbaa !24
  %t320 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t320, ptr %l166
  %t321 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t323 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %s3, ptr %s8, { i64, ptr } %t321)
  store %"compiler/msgs:Msg" %t323, ptr %l168
  br label %bb56
bb56:
  %t324 = load ptr, ptr %l164, !tbaa !29
  %t325 = load i64, ptr %l165, !tbaa !24
  %t326 = load { i64, [3 x i64] }, ptr %l166
  %t327 = load %"compiler/msgs:Msg", ptr %l168
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s8, ptr %t324, i64 %t325, { i64, [3 x i64] } %t326, %"compiler/msgs:Msg" %t327)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb58:
  %t328 = load ptr, ptr %l1, !tbaa !29
  store ptr %t328, ptr %l169, !tbaa !29
  %t329 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t329, ptr %l170
  %t330 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t332 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %s3, ptr %s3, { i64, ptr } %t330)
  store %"compiler/msgs:Msg" %t332, ptr %l172
  br label %bb59
bb59:
  %t333 = load ptr, ptr %l169, !tbaa !29
  %t334 = load { i64, [3 x i64] }, ptr %l170
  %t335 = load %"compiler/msgs:Msg", ptr %l172
  %t336 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t333, { i64, [3 x i64] } %t334, %"compiler/msgs:Msg" %t335)
  store i64 %t336, ptr %l173
  br label %bb60
bb60:
  %t337 = load i64, ptr %l173, !tbaa !24
  store i64 %t337, ptr %l15, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 38
  %t341 = load i64, ptr %l8, !tbaa !24
  %t344 = call %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t340, i64 %t341)
  store %"compiler/free:reason" %t344, ptr %l177
  br label %bb61
bb61:
  %t345 = load %"compiler/free:reason", ptr %l177
  store %"compiler/free:reason" %t345, ptr %l16
  %t346 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  %t349 = icmp sge i64 %t347, 0
  br i1 %t349, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l180, !tbaa !29
  %t352 = load i64, ptr %l15, !tbaa !24
  store i64 %t352, ptr %l181, !tbaa !24
  %t353 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 1
  %t354 = load i64, ptr %t353, !tbaa !24
  %t355 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t356 = getelementptr %"compiler/source:Span", ptr %t355, i32 0, i32 0
  %t357 = load i32, ptr %t356, !tbaa !23
  %t359 = sext i32 %t357 to i64
  %t360 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 2
  %t361 = getelementptr %"compiler/source:Span", ptr %t360, i32 0, i32 1
  %t362 = load i32, ptr %t361, !tbaa !23
  %t364 = sext i32 %t362 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 0
  store i64 3, ptr %t366
  %t368 = insertvalue { i64, i64, i64 } undef, i64 %t354, 0
  %t370 = insertvalue { i64, i64, i64 } %t368, i64 %t359, 1
  %t372 = insertvalue { i64, i64, i64 } %t370, i64 %t364, 2
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 1
  store { i64, i64, i64 } %t372, ptr %t373
  %t374 = load { i64, [3 x i64] }, ptr %t365
  store { i64, [3 x i64] } %t374, ptr %l187
  %t375 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  %t378 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s9, { i64, ptr } %t376)
  store %"compiler/msgs:Msg" %t378, ptr %l189
  br label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l190, !tbaa !29
  %t380 = load i64, ptr %l15, !tbaa !24
  store i64 %t380, ptr %l191, !tbaa !24
  %t381 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t381, ptr %l192
  %t382 = getelementptr %"compiler/free:reason", ptr %l16, i32 0, i32 3
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t385 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %s10, { i64, ptr } %t383)
  store %"compiler/msgs:Msg" %t385, ptr %l194
  br label %bb66
bb64:
  %t386 = load ptr, ptr %l180, !tbaa !29
  %t387 = load i64, ptr %l181, !tbaa !24
  %t388 = load { i64, [3 x i64] }, ptr %l187
  %t389 = load %"compiler/msgs:Msg", ptr %l189
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s9, ptr %t386, i64 %t387, { i64, [3 x i64] } %t388, %"compiler/msgs:Msg" %t389)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  br label %bb68
bb66:
  %t390 = load ptr, ptr %l190, !tbaa !29
  %t391 = load i64, ptr %l191, !tbaa !24
  %t392 = load { i64, [3 x i64] }, ptr %l192
  %t393 = load %"compiler/msgs:Msg", ptr %l194
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s10, ptr %t390, i64 %t391, { i64, [3 x i64] } %t392, %"compiler/msgs:Msg" %t393)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s10)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb69:
  %t394 = load i64, ptr %l7, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l7, !tbaa !24
  br label %bb12
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edtorCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca ptr
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l51 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb2
bb2:
  %t10 = load i1, ptr %l12, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load i1, ptr %l17, !tbaa !21
  store i1 %t18, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  %t24 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t24, ptr %l21
  br label %bb9
bb9:
  %t25 = load i1, ptr %l21, !tbaa !21
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l23, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l26
  br label %bb14
bb14:
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t35 = load i32, ptr %l26, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l27
  br label %bb15
bb15:
  %t37 = load i32, ptr %l27, !tbaa !23
  store i32 %t37, ptr %l3, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l30
  br label %bb16
bb16:
  %t43 = load i32, ptr %l30
  %t45 = trunc i64 18 to i32
  %t46 = icmp eq i32 %t43, %t45
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb20
bb18:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l37
  br label %bb19
bb19:
  %t55 = load i1, ptr %l37, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l34, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l34, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l40, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l3, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l43
  br label %bb23
bb23:
  %t65 = load ptr, ptr %l40, !tbaa !29
  %t66 = load i32, ptr %l43, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t67, ptr %l44
  br label %bb24
bb24:
  %t68 = load i32, ptr %l44
  %t70 = trunc i64 0 to i32
  %t71 = icmp eq i32 %t68, %t70
  %t73 = xor i1 %t71, true
  store i1 %t73, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t75 = load i1, ptr %l39, !tbaa !21
  br i1 %t75, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t77, i32 %t78)
  store i1 %t81, ptr %l51
  br label %bb29
bb29:
  %t82 = load i1, ptr %l51, !tbaa !21
  %t83 = xor i1 %t82, true
  br i1 %t83, label %bb30, label %bb31
bb30:
  store i1 false, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l54, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t88 = load i32, ptr %l3, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l57
  br label %bb33
bb33:
  %t92 = load ptr, ptr %l54, !tbaa !29
  %t93 = load i32, ptr %l57, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t92, i32 %t93)
  store { i64, ptr } %t94, ptr %l58
  br label %bb34
bb34:
  %t95 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t95, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load i64, ptr %l5, !tbaa !24
  %t101 = load i64, ptr %l6, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l65, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 %t109
  %t114 = load i32, ptr %t113, !tbaa !33
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t116, i32 %t114)
  store i1 %t120, ptr %l70
  br label %bb39
bb39:
  %t121 = load i1, ptr %l70, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t125 = load i64, ptr %l5, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l5, !tbaa !24
  br label %bb35
bb44:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t44, i64 %t45)
  store ptr %t46, ptr %l24
  br label %bb6
bb6:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %t49, !tbaa !23
  %t51 = load ptr, ptr %l17, !tbaa !29
  %t53 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t51, i32 %t50)
  store { i64, ptr } %t53, ptr %l27
  br label %bb7
bb7:
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t55, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l10, !tbaa !27
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t61, ptr %l10, !tbaa !27
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb)
  unreachable
bb13:
  %t63 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l31, !tbaa !24
  %t66 = mul i64 %t65, 1
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = load i64, ptr %l31, !tbaa !24
  %t75 = mul i64 %t74, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t71, ptr %t73, i64 %t75, i1 false)
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t76, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eimplicit(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 3
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %rv
  br label %ret
bb5:
  %t19 = load { i64, [2 x i64] }, ptr %l2
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb33
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l23
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t40, i64 %t41)
  store ptr %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/load:Loader", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t53, i32 %t57)
  store { i64, ptr } %t60, ptr %l31
  br label %bb11
bb11:
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t62, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t64, ptr %l33
  br label %bb12
bb12:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb16
bb14:
  %t66 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t66, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t68, ptr %l36
  br label %bb15
bb15:
  %t69 = load i1, ptr %l36, !tbaa !21
  store i1 %t69, ptr %l34, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l34, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t73, ptr %l39
  br label %bb19
bb19:
  %t74 = load i1, ptr %l39, !tbaa !21
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb24
bb22:
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t76, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t78, ptr %l42
  br label %bb23
bb23:
  %t79 = load i1, ptr %l42, !tbaa !21
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb24
bb24:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb28
bb26:
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t83 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t81, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t83, ptr %l45
  br label %bb27
bb27:
  %t84 = load i1, ptr %l45, !tbaa !21
  store i1 %t84, ptr %l43, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l43, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb32
bb30:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t86, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t88, ptr %l48
  br label %bb31
bb31:
  %t89 = load i1, ptr %l48, !tbaa !21
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  %t90 = load i1, ptr %l46, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_708b3215abbdbba7_3cea2bd689d53e8b)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 2
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l34 = alloca %"compiler/free:reason"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 36
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 36
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l18
  br label %bb7
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  %t26 = icmp ne i64 %t24, %t23
  store i1 %t26, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 36
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 38
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t46 = extractvalue { i64, ptr } %a5, 1
  %t47 = extractvalue { i64, ptr } %a5, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t62 = call %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v0, i64 %t41, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %t57)
  store %"compiler/free:reason" %t62, ptr %l34
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t64 = load i64, ptr %l27, !tbaa !24
  %t65 = load %"compiler/free:reason", ptr %l34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64, %"compiler/free:reason" %t65)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 36
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp ne i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %t13, i64 %t14, i64 %t15, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
  br label %bb5
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 51
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:leaf"
  %lp21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i32
  %l42 = alloca i1
  %l45 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i32
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca i32
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca i1
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l83 = alloca i64
  %l86 = alloca i64
  %l107 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l114 = alloca %"compiler/free:leaf"
  %l116 = alloca { i64, ptr }
  %l119 = alloca i32
  %l122 = alloca i32
  %l125 = alloca i1
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca ptr
  %l133 = alloca i32
  %l134 = alloca i32
  %l139 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca i32
  %l154 = alloca { i64, ptr }
  %l159 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i64
  %l192 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l200 = alloca %"compiler/free:leaf"
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l29
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l29, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l30, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l33
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l30, !tbaa !29
  %t12 = load i32, ptr %l33, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l34
  br label %bb3
bb3:
  %t14 = load i32, ptr %l34, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l35
  br label %bb4
bb4:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t16, ptr %lp4
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t18 = load ptr, ptr %lp4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %t18
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l38
  br label %bb5
bb5:
  %t24 = load i32, ptr %l38
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb9
bb7:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l45
  br label %bb8
bb8:
  %t36 = load i1, ptr %l45, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l42, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb14
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l48, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l51
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l48, !tbaa !29
  %t47 = load i32, ptr %l51, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t48, ptr %l52
  br label %bb13
bb13:
  %t49 = load i32, ptr %l52
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l47, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %lp4
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 15
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H56aba43bb329356750417c3998c5c01b(ptr %v0, ptr %v1, ptr %t62, i32 %t63)
  %t67 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 0
  store i32 %t68, ptr %l62
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb19, label %ok.70
ok.70:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l61
  br label %bb18
bb18:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l57
  br label %bb22
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  %t72 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l63
  br label %bb21
bb21:
  %t73 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l57
  br label %bb22
bb22:
  %t74 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t74, ptr %lp5
  %t75 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  %t76 = load ptr, ptr %lp5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %t76
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 15
  %t80 = load i32, ptr %l3, !tbaa !23
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H1a2c153a44db96cb4cb83bb1fc8b3b35(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l67
  br label %bb23
bb23:
  %t84 = load i1, ptr %l67, !tbaa !21
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t85 = load ptr, ptr %lp5
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t85
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 15
  %t91 = load i32, ptr %l3, !tbaa !23
  %t92 = load ptr, ptr %lp4
  %t93 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t92
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H760b547a4a2e251e7cfb0c9b0280f392(ptr %v0, ptr %v1, ptr %t90, i32 %t91, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93)
  br label %bb27
bb27:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l73, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l76
  br label %bb28
bb28:
  %t103 = load ptr, ptr %l73, !tbaa !29
  %t104 = load i32, ptr %l76, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l77
  br label %bb29
bb29:
  %t106 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = icmp sgt i64 %t111, %t112
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t119 = icmp sgt i64 %t117, 0
  br i1 %t119, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb35
bb32:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l7, !tbaa !24
  %t125 = sub i64 %t121, %t122
  %t126 = load i64, ptr %l9, !tbaa !24
  %t129 = add i64 %t125, %t126
  %t131 = sub i64 %t129, 1
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = sdiv i64 %t131, %t132
  store i64 %t135, ptr %l86, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb34
bb34:
  %t137 = load i64, ptr %l86, !tbaa !24
  store i64 %t137, ptr %l83, !tbaa !24
  br label %bb35
bb35:
  %t138 = load i64, ptr %l83, !tbaa !24
  store i64 %t138, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s4)
  br label %bb95
bb38:
  br label %bb39
bb39:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t148 = load i64, ptr %l11, !tbaa !24
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = mul i64 %t148, %t149
  %t155 = add i64 %t147, %t152
  store i64 %t155, ptr %l12, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l3, !tbaa !23
  %t159 = load i64, ptr %l12, !tbaa !24
  %t163 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t157, i32 %t158, i64 %t159)
  store i64 %t163, ptr %l107
  br label %bb40
bb40:
  %t164 = load i64, ptr %l107, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load i64, ptr %l13, !tbaa !24
  %t167 = icmp sge i64 %t165, 0
  br i1 %t167, label %bb41, label %bb42
bb41:
  %t169 = load ptr, ptr %lp4
  store ptr %t169, ptr %l110, !tbaa !29
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = mul i64 1, 8
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 1, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l112, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 0
  store i64 %t170, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l13, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t182 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v1, ptr %v1, { i64, ptr } %t180, i64 %t179)
  store %"compiler/free:leaf" %t182, ptr %l114
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t183 = load ptr, ptr %l110, !tbaa !29
  %t184 = load %"compiler/free:leaf", ptr %l114
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t183, %"compiler/free:leaf" %t184)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb94
bb45:
  %t185 = load ptr, ptr %l2, !tbaa !29
  %t186 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t186, ptr %l116, !tbaa !27
  %t187 = load i64, ptr %l12, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t187
  %t192 = load i32, ptr %t191, !tbaa !33
  %t195 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t185, i32 %t192)
  store i32 %t195, ptr %l119
  br label %bb46
bb46:
  %t196 = load i32, ptr %l119, !tbaa !23
  store i32 %t196, ptr %l14, !tbaa !23
  %t197 = load ptr, ptr %l2, !tbaa !29
  %t198 = load i32, ptr %l14, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l122
  br label %bb47
bb47:
  %t202 = load i32, ptr %l122
  %t204 = trunc i64 18 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb48, label %bb49
bb48:
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t208 = load i32, ptr %l14, !tbaa !23
  %t211 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t207, i32 %t208)
  store i1 %t211, ptr %l128
  br label %bb50
bb49:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb51
bb50:
  %t212 = load i1, ptr %l128, !tbaa !21
  store i1 %t212, ptr %l125, !tbaa !21
  br label %bb51
bb51:
  %t213 = load i1, ptr %l125, !tbaa !21
  br i1 %t213, label %bb52, label %bb53
bb52:
  %t214 = load ptr, ptr %l2, !tbaa !29
  store ptr %t214, ptr %l130, !tbaa !29
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t216 = load i32, ptr %l14, !tbaa !23
  %t219 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t215, i32 %t216)
  store i32 %t219, ptr %l133
  br label %bb54
bb53:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb56
bb54:
  %t220 = load ptr, ptr %l130, !tbaa !29
  %t221 = load i32, ptr %l133, !tbaa !23
  %t222 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t220, i32 %t221)
  store i32 %t222, ptr %l134
  br label %bb55
bb55:
  %t223 = load i32, ptr %l134
  %t225 = trunc i64 0 to i32
  %t226 = icmp eq i32 %t223, %t225
  store i1 %t226, ptr %l129, !tbaa !21
  br label %bb56
bb56:
  %t228 = load i1, ptr %l129, !tbaa !21
  br i1 %t228, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s7
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l14, !tbaa !23
  %t233 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t229, i32 %t230)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t233, ptr %l139
  br label %bb59
bb58:
  br label %bb93
bb59:
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  %t235 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t235
  store ptr %t235, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t237 = load ptr, ptr %l15, !tbaa !29
  %t238 = load i64, ptr %l16, !tbaa !24
  %t241 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t237, i64 %t238)
  %t242 = extractvalue { i32, { i64, ptr } } %t241, 1
  %t243 = extractvalue { i32, { i64, ptr } } %t241, 0
  store i32 %t243, ptr %l145
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb62, label %ok.245
ok.245:
  store { i64, ptr } %t242, ptr %l144
  br label %bb61
bb61:
  %t246 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t246, ptr %l141, !tbaa !27
  br label %bb66
bb62:
  %t247 = load i32, ptr %l145, !tbaa !23
  %t248 = ashr i32 %t247, 16
  %t250 = icmp eq i32 %t248, 1
  br i1 %t250, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_f7ad8986a1f0ec72_6f5068ecfabe168e)
  unreachable
bb65:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s8)
  br label %bb92
bb66:
  %t252 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t252, ptr %l17, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  store i64 %t255, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s9
  %t257 = load i64, ptr %l19, !tbaa !24
  %t258 = load i64, ptr %l18, !tbaa !24
  %t261 = icmp slt i64 %t257, %t258
  %t263 = xor i1 %t261, true
  br i1 %t263, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb69:
  br label %bb70
bb70:
  %t265 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t265, ptr %l154, !tbaa !27
  %t266 = load i64, ptr %l19, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr %"compiler/free:leaf", ptr %t269, i64 %t266
  %t271 = load %"compiler/free:leaf", ptr %t270
  store %"compiler/free:leaf" %t271, ptr %l20
  %t273 = getelementptr %"compiler/free:leaf", ptr %l20, i32 0, i32 0
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  %t278 = add i64 %t276, 1
  store i64 %t278, ptr %l159, !tbaa !24
  %t279 = load i64, ptr %l159, !tbaa !24
  %t280 = icmp sge i64 %t279, 0
  br i1 %t280, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l159, !tbaa !24
  %t283 = icmp sle i64 %t282, 1152921504606846975
  br i1 %t283, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_990f3854282db1c_5d9957fc1d229790)
  unreachable
bb73:
  %t285 = load i64, ptr %l159, !tbaa !24
  %t286 = mul i64 %t285, 8
  %t287 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t286)
  %t288 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t290 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t290, ptr %lp21
  %t292 = load ptr, ptr %lp21
  store { i64, ptr } %t289, ptr %t292, !tbaa !27
  %t293 = load i64, ptr %l12, !tbaa !24
  %t295 = load ptr, ptr %lp21
  %t296 = getelementptr { i64, ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr i64, ptr %t297, i64 0
  store i64 %t293, ptr %t298, !tbaa !34
  store i64 0, ptr %l22, !tbaa !24
  %t299 = getelementptr %"compiler/free:leaf", ptr %l20, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  store i64 %t302, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t304 = load i64, ptr %l23, !tbaa !24
  %t305 = load i64, ptr %l22, !tbaa !24
  %t308 = icmp sgt i64 %t304, %t305
  br i1 %t308, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_990f3854282db1c_5d9957fc1d229790)
  unreachable
bb75:
  %t310 = load i64, ptr %l24, !tbaa !24
  %t312 = icmp sgt i64 %t310, 0
  br i1 %t312, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb80
bb77:
  %t314 = load i64, ptr %l23, !tbaa !24
  %t315 = load i64, ptr %l22, !tbaa !24
  %t318 = sub i64 %t314, %t315
  %t319 = load i64, ptr %l24, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t324 = sub i64 %t322, 1
  %t325 = load i64, ptr %l24, !tbaa !24
  %t328 = sdiv i64 %t324, %t325
  store i64 %t328, ptr %l172, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb79
bb79:
  %t330 = load i64, ptr %l172, !tbaa !24
  store i64 %t330, ptr %l169, !tbaa !24
  br label %bb80
bb80:
  %t331 = load i64, ptr %l169, !tbaa !24
  store i64 %t331, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s11
  %t332 = load i64, ptr %l26, !tbaa !24
  %t333 = load i64, ptr %l25, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb83:
  br label %bb84
bb84:
  %t340 = load i64, ptr %l22, !tbaa !24
  %t341 = load i64, ptr %l26, !tbaa !24
  %t342 = load i64, ptr %l24, !tbaa !24
  %t345 = mul i64 %t341, %t342
  %t348 = add i64 %t340, %t345
  store i64 %t348, ptr %l27, !tbaa !24
  %t350 = load i64, ptr %l27, !tbaa !24
  %t352 = add i64 %t350, 1
  %t353 = getelementptr %"compiler/free:leaf", ptr %l20, i32 0, i32 0
  %t354 = load { i64, ptr }, ptr %t353, !tbaa !27
  store { i64, ptr } %t354, ptr %l192, !tbaa !27
  %t355 = load i64, ptr %l27, !tbaa !24
  %t357 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr i64, ptr %t358, i64 %t355
  %t360 = load i64, ptr %t359, !tbaa !34
  %t362 = load ptr, ptr %lp21
  %t364 = getelementptr { i64, ptr }, ptr %t362, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i64, ptr %t365, i64 %t352
  store i64 %t360, ptr %t366, !tbaa !34
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  %t367 = load i64, ptr %l26, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l26, !tbaa !24
  br label %bb81
bb86:
  %t371 = load ptr, ptr %lp4
  store ptr %t371, ptr %l197, !tbaa !29
  %t372 = load ptr, ptr %lp21
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  %t374 = getelementptr %"compiler/free:leaf", ptr %l20, i32 0, i32 1
  %t375 = load i64, ptr %t374, !tbaa !24
  %t378 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v1, ptr %v1, { i64, ptr } %t373, i64 %t375)
  store %"compiler/free:leaf" %t378, ptr %l200
  br label %bb87
bb87:
  %t379 = load ptr, ptr %l197, !tbaa !29
  %t380 = load %"compiler/free:leaf", ptr %l200
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t379, %"compiler/free:leaf" %t380)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s9)
  br label %bb89
bb89:
  %t381 = load i64, ptr %l19, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l19, !tbaa !24
  br label %bb67
bb90:
  %t385 = load i64, ptr %l16, !tbaa !24
  %t386 = load i64, ptr %l18, !tbaa !24
  %t389 = add i64 %t385, %t386
  store i64 %t389, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb91
bb91:
  br label %bb60
bb92:
  call void @__olang_scope_close(ptr %s7)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s4)
  br label %bb94
bb94:
  %t391 = load i64, ptr %l11, !tbaa !24
  %t393 = add i64 %t391, 1
  store i64 %t393, ptr %l11, !tbaa !24
  br label %bb36
bb95:
  %t395 = load ptr, ptr %lp4
  %t396 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t395
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t396, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l10
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 %a2, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t23, 1
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp ne i8 %t30, 10
  store i1 %t32, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l14, !tbaa !21
  %t35 = xor i1 %t34, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb2
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t47 = icmp slt i64 %t41, %t44
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l28, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 32
  br i1 %t57, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb17
bb14:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb16
bb15:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l33, !tbaa !27
  %t60 = load i64, ptr %l4, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i8, ptr %t63, i64 %t60
  %t65 = load i8, ptr %t64, !tbaa !32
  %t67 = icmp eq i8 %t65, 9
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l32, !tbaa !21
  store i1 %t69, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t70 = load i1, ptr %l27, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb11
bb22:
  %t77 = load i64, ptr %l4, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i64
  %l20 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca { i64, [1 x i64] }
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l17, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 5
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l20
  br label %bb2
bb2:
  %t15 = load i64, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = icmp sge i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 -1, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Body", ptr %t20, i32 0, i32 5
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l26
  br label %bb6
bb6:
  %t27 = load i32, ptr %l26, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 6
  %t32 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l29
  br label %bb7
bb7:
  %t33 = load i64, ptr %l29, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l36, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 6
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %t82, i64 %t83)
  store { i64, [1 x i64] } %t86, ptr %l57
  br label %bb18
bb18:
  %t87 = load { i64, [1 x i64] }, ptr %l57
  store { i64, [1 x i64] } %t87, ptr %l11
  %t88 = load { i64, [1 x i64] }, ptr %l11
  %t90 = extractvalue { i64, [1 x i64] } %t88, 0
  %t91 = icmp eq i64 %t90, 0
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = getelementptr { i64, [1 x i64] }, ptr %l11, i32 0, i32 1
  %t94 = getelementptr { i32 }, ptr %t93, i32 0, i32 0
  %t95 = load i32, ptr %t94
  store i32 %t95, ptr %l12, !tbaa !23
  br label %bb21
bb20:
  br label %bb25
bb21:
  %t97 = load i32, ptr %l12, !tbaa !23
  %t98 = load i32, ptr %l4, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t103, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_bc9d64d7693be970_b83238a2b46aaa8c)
  unreachable
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb14
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/typed:Plan"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca %"compiler/typed:Plan"
  %l22 = alloca ptr
  %l25 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i64
  %l54 = alloca { i64, [1 x i64] }
  %l55 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t13 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 3
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t13, ptr %v0, ptr %v0, ptr %t11, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t13, i64 152, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 152, i1 false)
  store i64 0, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 1
  %t22 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t18, i64 %a3)
  store ptr %t22, ptr %l22
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 6
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l25
  br label %bb6
bb6:
  %t28 = load i64, ptr %l25, !tbaa !24
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l29, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Call", ptr %t75, i32 0, i32 3
  %t78 = load i32, ptr %t77, !tbaa !23
  %t83 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l4, i32 %t78, i64 %t73)
  store { i64, [1 x i64] } %t83, ptr %l54
  br label %bb17
bb17:
  %t84 = load { i64, [1 x i64] }, ptr %l54
  %t85 = call i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %t84)
  store i1 %t85, ptr %l55
  br label %bb18
bb18:
  %t86 = load i1, ptr %l55, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l9, !tbaa !24
  br label %bb13
bb23:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l14 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 5
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 5
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l22
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i1, ptr %l25, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereported(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:store"
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca i32
  %l81 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i64
  %l99 = alloca i64
  %l101 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 34
  store ptr %t10, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i64, ptr %l4, !tbaa !24
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l22
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb7, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l21
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  br label %bb11
bb7:
  %t22 = load i32, ptr %l22, !tbaa !23
  %t23 = ashr i32 %t22, 16
  %t25 = icmp eq i32 %t23, 1
  br i1 %t25, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7dd8bd34969f443_39b9f746f8dd52f7)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb11:
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load i64, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb14:
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l31, !tbaa !27
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr %"compiler/free:store", ptr %t44, i64 %t41
  %t46 = load %"compiler/free:store", ptr %t45
  store %"compiler/free:store" %t46, ptr %l8
  %t48 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 17
  %t58 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  %t62 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t59)
  store i1 %t62, ptr %l41
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb19
bb18:
  %t63 = load i1, ptr %l41, !tbaa !21
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l37, !tbaa !21
  br i1 %t64, label %bb20, label %bb21
bb20:
  %t65 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 6
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  br i1 %t68, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb28
bb22:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb24
bb23:
  %t70 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 4
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t75 = icmp eq i64 %t71, %t72
  store i1 %t75, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l45, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb27
bb26:
  %t78 = getelementptr %"compiler/free:store", ptr %l8, i32 0, i32 4
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  store i1 %t83, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t85 = load i1, ptr %l49, !tbaa !21
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb31
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb12
bb33:
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t91, %t92
  store i64 %t95, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  br label %bb5
bb35:
  %t97 = load i1, ptr %l2, !tbaa !21
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t106 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %t102, i64 %t103)
  store i1 %t106, ptr %l63
  br label %bb39
bb39:
  %t107 = load i1, ptr %l63, !tbaa !21
  br i1 %t107, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:Free", ptr %t109, i32 0, i32 9
  %t112 = load i64, ptr %l1, !tbaa !24
  %t115 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l68
  br label %bb43
bb43:
  %t116 = load i64, ptr %l68, !tbaa !24
  %t117 = icmp slt i64 %t116, 0
  br i1 %t117, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t120)
  store ptr %t122, ptr %l72
  br label %bb47
bb47:
  %t123 = load ptr, ptr %l72, !tbaa !29
  store ptr %t123, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l9, !tbaa !29
  store ptr %t124, ptr %l73, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 8
  %t128 = load i64, ptr %l1, !tbaa !24
  %t131 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t127, i64 %t128)
  store i32 %t131, ptr %l77
  br label %bb48
bb48:
  %t132 = load ptr, ptr %l73, !tbaa !29
  %t133 = load i32, ptr %l77, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t134, ptr %l78
  br label %bb49
bb49:
  %t135 = load i32, ptr %l78, !tbaa !23
  store i32 %t135, ptr %l10, !tbaa !23
  %t136 = load ptr, ptr %l9, !tbaa !29
  %t137 = load i32, ptr %l10, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l81
  br label %bb50
bb50:
  %t141 = load i32, ptr %l81
  %t143 = trunc i64 18 to i32
  %t144 = icmp eq i32 %t141, %t143
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t149 = load ptr, ptr %l9, !tbaa !29
  store ptr %t149, ptr %l86, !tbaa !29
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t151 = load i32, ptr %l10, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l89
  br label %bb54
bb54:
  %t155 = load ptr, ptr %l86, !tbaa !29
  %t156 = load i32, ptr %l89, !tbaa !23
  %t157 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t155, i32 %t156)
  store i64 %t157, ptr %l90
  br label %bb55
bb55:
  %t158 = load i64, ptr %l90, !tbaa !24
  store i64 %t158, ptr %l11, !tbaa !24
  %t159 = load i64, ptr %l11, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  br i1 %t161, label %bb56, label %bb57
bb56:
  %t163 = load i64, ptr %l11, !tbaa !24
  store i64 %t163, ptr %l94, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 0
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/load:Loader", ptr %t170, i32 0, i32 5
  %t174 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t172)
  store i64 %t174, ptr %l99
  br label %bb58
bb57:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb59
bb58:
  %t175 = load i64, ptr %l94, !tbaa !24
  %t176 = load i64, ptr %l99, !tbaa !24
  %t177 = icmp slt i64 %t175, %t176
  store i1 %t177, ptr %l93, !tbaa !21
  br label %bb59
bb59:
  %t179 = load i1, ptr %l93, !tbaa !21
  br i1 %t179, label %bb60, label %bb61
bb60:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/load:Loader", ptr %t186, i32 0, i32 5
  %t189 = load i64, ptr %l11, !tbaa !24
  %t192 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t188, i64 %t189)
  store ptr %t192, ptr %l107
  br label %bb62
bb61:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb64
bb62:
  %t193 = load ptr, ptr %l107, !tbaa !29
  %t195 = getelementptr %"compiler/load:Module", ptr %t193, i32 0, i32 2
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t196, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t198, ptr %l110
  br label %bb63
bb63:
  %t199 = load i1, ptr %l110, !tbaa !21
  %t200 = xor i1 %t199, true
  store i1 %t200, ptr %l101, !tbaa !21
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t202 = load i1, ptr %l101, !tbaa !21
  store i1 %t202, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, [1 x i64] }
  %l16 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l47 = alloca { i64, [1 x i64] }
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  store ptr %t12, ptr %l16
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 6
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %l2)
  store i64 %t19, ptr %l20
  br label %bb5
bb5:
  %t20 = load i64, ptr %l20, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb11
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l27, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l24, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l24, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb14:
  br label %bb15
bb15:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = call { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %l2, i64 %t67)
  store { i64, [1 x i64] } %t70, ptr %l47
  br label %bb16
bb16:
  %t71 = load { i64, [1 x i64] }, ptr %l47
  store { i64, [1 x i64] } %t71, ptr %l9
  %t72 = load { i64, [1 x i64] }, ptr %l9
  %t74 = extractvalue { i64, [1 x i64] } %t72, 0
  %t75 = icmp eq i64 %t74, 1
  br i1 %t75, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  %t77 = load { i64, [1 x i64] }, ptr %l9
  %t79 = extractvalue { i64, [1 x i64] } %t77, 0
  %t80 = icmp eq i64 %t79, 2
  br i1 %t80, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t82 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t82, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_97a1f172ac127e68_91804f7c420b5df4)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t84 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb12
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l107 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i32
  %l130 = alloca i1
  %l140 = alloca ptr
  %l143 = alloca i32
  %l144 = alloca i32
  %l149 = alloca i1
  %l150 = alloca ptr
  %l153 = alloca i32
  %l154 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca i1
  %l168 = alloca i1
  %l174 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l189 = alloca i1
  %l192 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i32
  %l203 = alloca i64
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l25
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l25, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l28
  br label %bb2
bb2:
  %t10 = load i32, ptr %l28, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l31
  br label %bb3
bb3:
  %t16 = load i32, ptr %l31
  store i32 %t16, ptr %l4
  %t17 = load i32, ptr %l4
  %t19 = trunc i64 21 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4
  %t24 = trunc i64 25 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l34, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l34, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i32, ptr %l4
  %t30 = trunc i64 29 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l37, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l37, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb12
bb11:
  %t34 = load i32, ptr %l4
  %t36 = trunc i64 0 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t41 = load i32, ptr %l4
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb16, label %bb17
bb16:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l48
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t51 = load i1, ptr %l48, !tbaa !21
  br i1 %t51, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t55 = load i32, ptr %l3, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb22
bb22:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t59, i32 %t60)
  store i1 %t61, ptr %l54
  br label %bb23
bb23:
  %t62 = load i1, ptr %l54, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb24:
  %t63 = load i32, ptr %l4
  %t65 = trunc i64 19 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb25, label %bb26
bb25:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l57, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t70 = load i32, ptr %l3, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l60
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t74 = load ptr, ptr %l57, !tbaa !29
  %t75 = load i32, ptr %l60, !tbaa !23
  %t76 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t76, ptr %l61
  br label %bb28
bb28:
  %t77 = load i1, ptr %l61, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb29:
  %t78 = load i32, ptr %l4
  %t80 = trunc i64 22 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb32
bb31:
  %t83 = load i32, ptr %l4
  %t85 = trunc i64 23 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l64, !tbaa !21
  br label %bb32
bb32:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  %t89 = load ptr, ptr %l2, !tbaa !29
  store ptr %t89, ptr %l67, !tbaa !29
  %t90 = load ptr, ptr %l2, !tbaa !29
  %t91 = load i32, ptr %l3, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l70
  br label %bb35
bb34:
  br label %bb47
bb35:
  %t95 = load ptr, ptr %l67, !tbaa !29
  %t96 = load i32, ptr %l70, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l71
  br label %bb36
bb36:
  %t98 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t98, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb39:
  br label %bb40
bb40:
  %t111 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t111, ptr %l78, !tbaa !27
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i32, ptr %t115, i64 %t112
  %t117 = load i32, ptr %t116, !tbaa !33
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t123 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t119, i32 %t117)
  store i1 %t123, ptr %l83
  br label %bb41
bb41:
  %t124 = load i1, ptr %l83, !tbaa !21
  %t125 = xor i1 %t124, true
  br i1 %t125, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s7)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l6, !tbaa !24
  br label %bb37
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  %t133 = load i32, ptr %l4
  %t135 = trunc i64 24 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb48, label %bb49
bb48:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l91, !tbaa !29
  %t139 = load ptr, ptr %l2, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l94
  br label %bb50
bb49:
  br label %bb62
bb50:
  %t144 = load ptr, ptr %l91, !tbaa !29
  %t145 = load i32, ptr %l94, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t144, i32 %t145)
  store { i64, ptr } %t146, ptr %l95
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t147, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l11, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s12
  %t152 = load i64, ptr %l10, !tbaa !24
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp slt i64 %t152, %t153
  %t158 = xor i1 %t156, true
  br i1 %t158, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s12)
  br label %bb61
bb54:
  br label %bb55
bb55:
  %t160 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t160, ptr %l102, !tbaa !27
  %t161 = load i64, ptr %l10, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t168, i32 %t166)
  store i1 %t172, ptr %l107
  br label %bb56
bb56:
  %t173 = load i1, ptr %l107, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s12)
  store i1 false, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb60:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l10, !tbaa !24
  br label %bb52
bb61:
  store i1 true, ptr %rv
  br label %ret
bb62:
  %t182 = load i32, ptr %l4
  %t184 = trunc i64 18 to i32
  %t185 = icmp eq i32 %t182, %t184
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb63, label %bb64
bb63:
  store i1 true, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t191 = load i32, ptr %l3, !tbaa !23
  %t194 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t190, i32 %t191)
  store i1 %t194, ptr %l119
  br label %bb66
bb66:
  %t195 = load i1, ptr %l119, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 14
  %t202 = load i32, ptr %l3, !tbaa !23
  %t205 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %t201, i32 %t202)
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l127
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb71, label %ok.209
ok.209:
  store i64 %t206, ptr %l126
  br label %bb70
bb70:
  %t210 = load i64, ptr %l126, !tbaa !24
  store i64 %t210, ptr %l122, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l122, !tbaa !24
  br label %bb73
bb73:
  %t211 = load i64, ptr %l122, !tbaa !24
  store i64 %t211, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = icmp eq i64 %t212, 1
  br i1 %t214, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = icmp eq i64 %t216, 3
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t220 = load i1, ptr %l130, !tbaa !21
  br i1 %t220, label %bb77, label %bb78
bb77:
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = icmp eq i64 %t222, 2
  br i1 %t224, label %bb80, label %bb81
bb80:
  store i1 false, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/free:Free", ptr %t227, i32 0, i32 14
  %t230 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t229, i32 %t230, i64 1)
  br label %bb83
bb83:
  store i1 true, ptr %l14, !tbaa !21
  %t233 = load ptr, ptr %l2, !tbaa !29
  store ptr %t233, ptr %l140, !tbaa !29
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t235 = load i32, ptr %l3, !tbaa !23
  %t238 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t234, i32 %t235)
  store i32 %t238, ptr %l143
  br label %bb84
bb84:
  %t239 = load ptr, ptr %l140, !tbaa !29
  %t240 = load i32, ptr %l143, !tbaa !23
  %t241 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t241, ptr %l144
  br label %bb85
bb85:
  %t242 = load i32, ptr %l144
  store i32 %t242, ptr %l15
  %t243 = load i32, ptr %l15
  %t245 = trunc i64 0 to i32
  %t246 = icmp eq i32 %t243, %t245
  br i1 %t246, label %bb86, label %bb87
bb86:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t249 = load i32, ptr %l3, !tbaa !23
  %t252 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t248, i32 %t249)
  store i1 %t252, ptr %l149
  br label %bb88
bb87:
  %t253 = load i32, ptr %l15
  %t255 = trunc i64 1 to i32
  %t256 = icmp eq i32 %t253, %t255
  br i1 %t256, label %bb107, label %bb108
bb88:
  %t258 = load i1, ptr %l149, !tbaa !21
  br i1 %t258, label %bb89, label %bb90
bb89:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb91
bb90:
  br label %bb91
bb91:
  %t259 = load ptr, ptr %l2, !tbaa !29
  store ptr %t259, ptr %l150, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t261 = load i32, ptr %l3, !tbaa !23
  %t264 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l153
  br label %bb92
bb92:
  %t265 = load ptr, ptr %l150, !tbaa !29
  %t266 = load i32, ptr %l153, !tbaa !23
  %t267 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t265, i32 %t266)
  store { i64, ptr } %t267, ptr %l154
  br label %bb93
bb93:
  %t268 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t268, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t269, 0
  store i64 %t271, ptr %l18, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s22
  %t273 = load i64, ptr %l17, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = icmp slt i64 %t273, %t274
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s22)
  br label %bb106
bb96:
  br label %bb97
bb97:
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t281, ptr %l161, !tbaa !27
  %t282 = load i64, ptr %l17, !tbaa !24
  %t284 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !27
  %t286 = getelementptr i32, ptr %t285, i64 %t282
  %t287 = load i32, ptr %t286, !tbaa !33
  store i32 %t287, ptr %l19, !tbaa !23
  %t289 = load i1, ptr %l14, !tbaa !21
  br i1 %t289, label %bb98, label %bb99
bb98:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l19, !tbaa !23
  %t295 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t291, i32 %t292)
  store i1 %t295, ptr %l168
  br label %bb100
bb99:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb101
bb100:
  %t296 = load i1, ptr %l168, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l165, !tbaa !21
  br label %bb101
bb101:
  %t299 = load i1, ptr %l165, !tbaa !21
  br i1 %t299, label %bb102, label %bb103
bb102:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb104
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb105:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l17, !tbaa !24
  br label %bb94
bb106:
  br label %bb128
bb107:
  %t304 = load ptr, ptr %l2, !tbaa !29
  store ptr %t304, ptr %l174, !tbaa !29
  %t305 = load ptr, ptr %l2, !tbaa !29
  %t306 = load i32, ptr %l3, !tbaa !23
  %t309 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t305, i32 %t306)
  store i32 %t309, ptr %l177
  br label %bb109
bb108:
  %t310 = load i32, ptr %l15
  %t312 = trunc i64 4 to i32
  %t313 = icmp eq i32 %t310, %t312
  %t315 = xor i1 %t313, true
  br i1 %t315, label %bb124, label %bb125
bb109:
  %t317 = load ptr, ptr %l174, !tbaa !29
  %t318 = load i32, ptr %l177, !tbaa !23
  %t319 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t317, i32 %t318)
  store { i64, ptr } %t319, ptr %l178
  br label %bb110
bb110:
  %t320 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t320, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s28
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l22, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb112, label %bb113
bb112:
  call void @__olang_scope_close(ptr %s28)
  br label %bb123
bb113:
  br label %bb114
bb114:
  %t333 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t333, ptr %l185, !tbaa !27
  %t334 = load i64, ptr %l21, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  store i32 %t339, ptr %l23, !tbaa !23
  %t341 = load i1, ptr %l14, !tbaa !21
  br i1 %t341, label %bb115, label %bb116
bb115:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i32, ptr %l23, !tbaa !23
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t343, i32 %t344)
  store i1 %t347, ptr %l192
  br label %bb117
bb116:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb118
bb117:
  %t348 = load i1, ptr %l192, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l189, !tbaa !21
  br label %bb118
bb118:
  %t351 = load i1, ptr %l189, !tbaa !21
  br i1 %t351, label %bb119, label %bb120
bb119:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb121
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s28)
  br label %bb122
bb122:
  %t352 = load i64, ptr %l21, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l21, !tbaa !24
  br label %bb111
bb123:
  br label %bb127
bb124:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb126
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 14
  store ptr %t358, ptr %l200, !tbaa !29
  %t359 = load i32, ptr %l3, !tbaa !23
  store i32 %t359, ptr %l201, !tbaa !23
  %t360 = load i1, ptr %l14, !tbaa !21
  br i1 %t360, label %bb129, label %bb130
bb129:
  store i64 3, ptr %l203, !tbaa !24
  br label %bb131
bb130:
  store i64 2, ptr %l203, !tbaa !24
  br label %bb131
bb131:
  %t362 = load ptr, ptr %l200, !tbaa !29
  %t363 = load i32, ptr %l201, !tbaa !23
  %t364 = load i64, ptr %l203, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %t362, i32 %t363, i64 %t364)
  br label %bb132
bb132:
  %t365 = load i1, ptr %l14, !tbaa !21
  store i1 %t365, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2escopeName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/free:letGo"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i32
  %l32 = alloca { i64, ptr }
  %l36 = alloca i64
  %l38 = alloca i1
  %l40 = alloca i1
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l67 = alloca { i64, ptr }
  %l73 = alloca i1
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l83 = alloca { i64, ptr }
  %l85 = alloca i64
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l122 = alloca ptr
  %l124 = alloca ptr
  %l127 = alloca i64
  %l131 = alloca i64
  %l134 = alloca i64
  %l155 = alloca ptr
  %l159 = alloca %"compiler/typed:Local"
  %l161 = alloca { i64, ptr }
  %l163 = alloca i1
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i32
  %l180 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l197 = alloca %"compiler/typed:Local"
  %l199 = alloca i32
  %l202 = alloca i1
  %l203 = alloca ptr
  %l206 = alloca i32
  %l207 = alloca i32
  %l210 = alloca i32
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l220 = alloca i32
  %l221 = alloca i32
  %l222 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l233 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/free:letGo", ptr %l1
  %t5 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s0, ptr %t1, %"compiler/free:letGo" %t2)
  store { i64, ptr } %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 9
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l36
  br label %bb2
bb2:
  %t14 = load i64, ptr %l36, !tbaa !24
  %t15 = icmp slt i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t19, ptr %l40
  br label %bb5
bb4:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i1, ptr %l40, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l38, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l38, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l42, !tbaa !27
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/free:letGo", ptr %l1
  %t30 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s0, ptr %t26, %"compiler/free:letGo" %t27)
  store { i64, ptr } %t30, ptr %l46
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t31, ptr %l42, !tbaa !27
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t32, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 9
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l50
  br label %bb11
bb11:
  %t40 = load i64, ptr %l50, !tbaa !24
  %t41 = icmp slt i64 %t40, 0
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 35
  store ptr %t45, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb43
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t47, i64 %t48)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l58
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb16, label %ok.55
ok.55:
  store { i64, ptr } %t52, ptr %l57
  br label %bb15
bb15:
  %t56 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t56, ptr %l54, !tbaa !27
  br label %bb20
bb16:
  %t57 = load i32, ptr %l58, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  br i1 %t60, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f01b6368c240b0ef_955647351bed428b)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb20:
  %t62 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t62, ptr %l7, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  store i64 %t65, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l9, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb23:
  br label %bb24
bb24:
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t75, ptr %l67, !tbaa !27
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr %"compiler/free:letGo", ptr %t79, i64 %t76
  %t81 = load %"compiler/free:letGo", ptr %t80
  store %"compiler/free:letGo" %t81, ptr %l10
  %t83 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = getelementptr %"compiler/free:letGo", ptr %l10, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t96 = icmp eq i64 %t91, %t93
  store i1 %t96, ptr %l73, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb27
bb27:
  %t98 = load i1, ptr %l73, !tbaa !21
  br i1 %t98, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/free:letGo", ptr %l10
  %t103 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %s5, ptr %t99, %"compiler/free:letGo" %t100)
  store { i64, ptr } %t103, ptr %l79
  br label %bb30
bb29:
  br label %bb38
bb30:
  %t104 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t104, ptr %l11, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s5, ptr %s5, { i64, ptr } %t105, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t107, ptr %l81
  br label %bb31
bb31:
  %t108 = load i1, ptr %l81, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb32, label %bb33
bb32:
  %t111 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t111, ptr %l83, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 0
  store i64 %t115, ptr %l85, !tbaa !24
  %t117 = load i64, ptr %l85, !tbaa !24
  %t118 = icmp eq i64 %t113, %t117
  br i1 %t118, label %bb34, label %bb35
bb33:
  br label %bb37
bb34:
  %t120 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l85, !tbaa !24
  %t125 = mul i64 %t124, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t121, ptr %t123, i64 %t125, i1 false)
  br label %bb36
bb35:
  %t126 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l87, !tbaa !24
  %t128 = load i64, ptr %l87, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l88, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l87, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t139, ptr %l4, !tbaa !27
  br label %bb36
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb21
bb40:
  %t144 = load i64, ptr %l6, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t148 = add i64 %t144, %t145
  store i64 %t148, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  br label %bb14
bb42:
  br label %bb43
bb43:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t156 = icmp slt i64 %t150, %t153
  br i1 %t156, label %bb45, label %bb46
bb45:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i8, ptr %t161, i64 %t158
  %t163 = load i8, ptr %t162, !tbaa !32
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t163)
  store i1 %t165, ptr %l101
  br label %bb47
bb46:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb55
bb47:
  %t166 = load i1, ptr %l101, !tbaa !21
  br i1 %t166, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l102, !tbaa !21
  br label %bb51
bb49:
  %t167 = load i64, ptr %l12, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i8, ptr %t170, i64 %t167
  %t172 = load i8, ptr %t171, !tbaa !32
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t172)
  store i1 %t174, ptr %l105
  br label %bb50
bb50:
  %t175 = load i1, ptr %l105, !tbaa !21
  store i1 %t175, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t176 = load i1, ptr %l102, !tbaa !21
  br i1 %t176, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb54
bb53:
  %t177 = load i64, ptr %l12, !tbaa !24
  %t179 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = getelementptr i8, ptr %t180, i64 %t177
  %t182 = load i8, ptr %t181, !tbaa !32
  %t184 = icmp eq i8 %t182, 95
  store i1 %t184, ptr %l106, !tbaa !21
  br label %bb54
bb54:
  %t186 = load i1, ptr %l106, !tbaa !21
  store i1 %t186, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t187 = load i1, ptr %l98, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t190 = load i64, ptr %l12, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb59:
  br label %bb44
bb60:
  %t194 = load i64, ptr %l12, !tbaa !24
  store i64 %t194, ptr %l113, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  store i64 %t196, ptr %l114, !tbaa !24
  %t197 = icmp sge i64 0, 0
  br i1 %t197, label %bb61, label %bb62
bb61:
  %t199 = load i64, ptr %l113, !tbaa !24
  %t200 = icmp sle i64 0, %t199
  br i1 %t200, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_87d02dbc60271a1d_6e1627e36757d429)
  unreachable
bb63:
  %t202 = load i64, ptr %l113, !tbaa !24
  %t203 = load i64, ptr %l114, !tbaa !24
  %t204 = icmp sle i64 %t202, %t203
  br i1 %t204, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_87d02dbc60271a1d_6e1627e36757d429)
  unreachable
bb65:
  %t206 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l113, !tbaa !24
  %t209 = getelementptr i8, ptr %t207, i64 0
  %t210 = sub i64 %t208, 0
  %t211 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t209, 1
  store { i64, ptr } %t212, ptr %l13, !tbaa !27
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/free:Free", ptr %t214, i32 0, i32 1
  %t217 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t218 = load i64, ptr %t217, !tbaa !24
  %t221 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t216, i64 %t218)
  store ptr %t221, ptr %l122
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_87d02dbc60271a1d_6e1627e36757d429)
  unreachable
bb67:
  %t222 = load ptr, ptr %l122, !tbaa !29
  store ptr %t222, ptr %l14, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t223)
  store ptr %t225, ptr %l124
  br label %bb68
bb68:
  %t226 = load ptr, ptr %l124, !tbaa !29
  store ptr %t226, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  %t227 = load ptr, ptr %l14, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Body", ptr %t227, i32 0, i32 7
  %t231 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l127
  br label %bb69
bb69:
  %t232 = load i64, ptr %l127, !tbaa !24
  store i64 %t232, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l17, !tbaa !24
  %t234 = load i64, ptr %l16, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb70, label %bb71
bb70:
  %t239 = load i64, ptr %l18, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb75
bb72:
  %t243 = load i64, ptr %l17, !tbaa !24
  %t244 = load i64, ptr %l16, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l18, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l18, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l134, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb74
bb74:
  %t259 = load i64, ptr %l134, !tbaa !24
  store i64 %t259, ptr %l131, !tbaa !24
  br label %bb75
bb75:
  %t260 = load i64, ptr %l131, !tbaa !24
  store i64 %t260, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s10)
  br label %bb124
bb78:
  br label %bb79
bb79:
  %t269 = load i64, ptr %l16, !tbaa !24
  %t270 = load i64, ptr %l20, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l21, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/free:Free", ptr %t279, i32 0, i32 0
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = getelementptr %"compiler/generic:Program", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = getelementptr %"compiler/load:Loader", ptr %t285, i32 0, i32 3
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l155, !tbaa !29
  %t289 = load ptr, ptr %l14, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Body", ptr %t289, i32 0, i32 7
  %t292 = load i64, ptr %l21, !tbaa !24
  %t295 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t291, i64 %t292)
  store %"compiler/typed:Local" %t295, ptr %l159
  br label %bb80
bb80:
  %t296 = getelementptr %"compiler/typed:Local", ptr %l159, i32 0, i32 0
  %t297 = load i32, ptr %t296, !tbaa !23
  %t298 = load ptr, ptr %l155, !tbaa !29
  %t300 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t298, i32 %t297)
  store { i64, ptr } %t300, ptr %l161
  br label %bb81
bb81:
  %t301 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t302, { i64, ptr } %t301)
  store i1 %t304, ptr %l163
  br label %bb82
bb82:
  %t305 = load i1, ptr %l163, !tbaa !21
  %t306 = xor i1 %t305, true
  br i1 %t306, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s10)
  br label %bb123
bb84:
  br label %bb85
bb85:
  store i1 false, ptr %l22, !tbaa !21
  %t308 = load ptr, ptr %l14, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Body", ptr %t308, i32 0, i32 5
  store ptr %t310, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t312 = load ptr, ptr %l23, !tbaa !29
  %t313 = load i64, ptr %l24, !tbaa !24
  %t316 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t312, i64 %t313)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l171
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb88, label %ok.320
ok.320:
  store { i64, ptr } %t317, ptr %l170
  br label %bb87
bb87:
  %t321 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t321, ptr %l167, !tbaa !27
  br label %bb92
bb88:
  %t322 = load i32, ptr %l171, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  br i1 %t325, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_f3b0f19e5481d5e5_7f2cb84d865178e1)
  unreachable
bb91:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb103
bb92:
  %t327 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t327, ptr %l25, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  store i64 %t330, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s14
  %t332 = load i64, ptr %l27, !tbaa !24
  %t333 = load i64, ptr %l26, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s14)
  br label %bb101
bb95:
  br label %bb96
bb96:
  %t340 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t340, ptr %l180, !tbaa !27
  %t341 = load i64, ptr %l27, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr i32, ptr %t344, i64 %t341
  %t346 = load i32, ptr %t345, !tbaa !33
  %t350 = sext i32 %t346 to i64
  %t351 = load i64, ptr %l21, !tbaa !24
  %t354 = icmp eq i64 %t350, %t351
  br i1 %t354, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb99
bb98:
  br label %bb99
bb99:
  call void @__olang_scope_close(ptr %s14)
  br label %bb100
bb100:
  %t356 = load i64, ptr %l27, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l27, !tbaa !24
  br label %bb93
bb101:
  %t360 = load i64, ptr %l24, !tbaa !24
  %t361 = load i64, ptr %l26, !tbaa !24
  %t364 = add i64 %t360, %t361
  store i64 %t364, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb102
bb102:
  br label %bb86
bb103:
  %t366 = load i1, ptr %l22, !tbaa !21
  br i1 %t366, label %bb104, label %bb105
bb104:
  %t368 = load ptr, ptr %l15, !tbaa !29
  store ptr %t368, ptr %l193, !tbaa !29
  %t369 = load ptr, ptr %l14, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Body", ptr %t369, i32 0, i32 7
  %t372 = load i64, ptr %l21, !tbaa !24
  %t375 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t371, i64 %t372)
  store %"compiler/typed:Local" %t375, ptr %l197
  br label %bb106
bb105:
  br label %bb121
bb106:
  %t376 = getelementptr %"compiler/typed:Local", ptr %l197, i32 0, i32 2
  %t377 = load i32, ptr %t376, !tbaa !23
  %t378 = load ptr, ptr %l193, !tbaa !29
  %t380 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t378, i32 %t377)
  store i32 %t380, ptr %l199
  br label %bb107
bb107:
  %t381 = load i32, ptr %l199, !tbaa !23
  store i32 %t381, ptr %l29, !tbaa !23
  %t382 = load ptr, ptr %l15, !tbaa !29
  %t383 = load i32, ptr %l29, !tbaa !23
  %t386 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t382, i32 %t383)
  store i1 %t386, ptr %l202
  br label %bb108
bb108:
  %t387 = load i1, ptr %l202, !tbaa !21
  br i1 %t387, label %bb109, label %bb110
bb109:
  %t388 = load ptr, ptr %l15, !tbaa !29
  store ptr %t388, ptr %l203, !tbaa !29
  %t389 = load ptr, ptr %l15, !tbaa !29
  %t390 = load i32, ptr %l29, !tbaa !23
  %t393 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t389, i32 %t390)
  store i32 %t393, ptr %l206
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t394 = load ptr, ptr %l203, !tbaa !29
  %t395 = load i32, ptr %l206, !tbaa !23
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t394, i32 %t395)
  store i32 %t396, ptr %l207
  br label %bb112
bb112:
  %t397 = load i32, ptr %l207, !tbaa !23
  store i32 %t397, ptr %l29, !tbaa !23
  br label %bb113
bb113:
  %t398 = load ptr, ptr %l15, !tbaa !29
  %t399 = load i32, ptr %l29, !tbaa !23
  %t402 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t398, i32 %t399)
  store i32 %t402, ptr %l210
  br label %bb114
bb114:
  %t403 = load i32, ptr %l210
  %t405 = trunc i64 18 to i32
  %t406 = icmp eq i32 %t403, %t405
  br i1 %t406, label %bb115, label %bb116
bb115:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/free:Free", ptr %t408, i32 0, i32 0
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 0
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = getelementptr %"compiler/load:Loader", ptr %t414, i32 0, i32 3
  %t417 = load ptr, ptr %t416, !tbaa !29
  store ptr %t417, ptr %l216, !tbaa !29
  %t418 = load ptr, ptr %l15, !tbaa !29
  store ptr %t418, ptr %l217, !tbaa !29
  %t419 = load ptr, ptr %l15, !tbaa !29
  %t420 = load i32, ptr %l29, !tbaa !23
  %t423 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t419, i32 %t420)
  store i32 %t423, ptr %l220
  br label %bb117
bb116:
  br label %bb120
bb117:
  %t424 = load ptr, ptr %l217, !tbaa !29
  %t425 = load i32, ptr %l220, !tbaa !23
  %t426 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t424, i32 %t425)
  store i32 %t426, ptr %l221
  br label %bb118
bb118:
  %t427 = load ptr, ptr %l216, !tbaa !29
  %t428 = load i32, ptr %l221, !tbaa !23
  %t429 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t427, i32 %t428)
  store { i64, ptr } %t429, ptr %l222
  br label %bb119
bb119:
  %t430 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t431 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t432 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 1
  %t434 = extractvalue { i64, ptr } %t432, 0
  %t435 = add i64 %t431, %t434
  %t436 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t438 = add i64 %t435, %t437
  %t439 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t438)
  call void @olang_textcopy(ptr %t439, ptr %t430, i64 %t431)
  %t440 = getelementptr i8, ptr %t439, i64 %t431
  call void @olang_textcopy(ptr %t440, ptr %t433, i64 %t434)
  %t441 = getelementptr i8, ptr %t440, i64 %t434
  call void @olang_textcopy(ptr %t441, ptr %t436, i64 %t437)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t439, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t443, ptr %rv
  br label %ret
bb120:
  br label %bb121
bb121:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t447 = load i64, ptr %t446, !tbaa !24
  %t450 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s10, ptr %t445, i64 %t447)
  store { i64, ptr } %t450, ptr %l226
  br label %bb122
bb122:
  %t451 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 1
  %t453 = extractvalue { i64, ptr } %t451, 0
  %t454 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t455 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t456 = add i64 %t453, %t455
  %t457 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t456)
  call void @olang_textcopy(ptr %t457, ptr %t452, i64 %t453)
  %t458 = getelementptr i8, ptr %t457, i64 %t453
  call void @olang_textcopy(ptr %t458, ptr %t454, i64 %t455)
  %t459 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t457, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t460, ptr %rv
  br label %ret
bb123:
  %t462 = load i64, ptr %l20, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l20, !tbaa !24
  br label %bb76
bb124:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l230, !tbaa !27
  %t466 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t466, ptr %l231, !tbaa !27
  %t467 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 0
  store i64 %t468, ptr %l232, !tbaa !24
  %t469 = load i64, ptr %l232, !tbaa !24
  %t470 = mul i64 %t469, 1
  %t471 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t470)
  %t472 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  store { i64, ptr } %t473, ptr %l233, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = load i64, ptr %l232, !tbaa !24
  %t479 = mul i64 %t478, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t475, ptr %t477, i64 %t479, i1 false)
  %t480 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t480, ptr %l231, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t481 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t481, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 28
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 28
  %t12 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12, i1 true)
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:Free", ptr %t15, i32 0, i32 30
  store i1 true, ptr %t17, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/typed:Plan"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca %"compiler/typed:Plan"
  %l14 = alloca { i64, [1 x i64] }
  %l15 = alloca ptr
  %l16 = alloca i1
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca { i64, [1 x i64] }
  %l36 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca i1
  %l73 = alloca { i64, [1 x i64] }
  %l74 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, [1 x i64] }
  %l84 = alloca ptr
  %l85 = alloca i1
  %l93 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t5 = alloca %"compiler/typed:Plan", align 8
  %t73 = alloca { i64, [1 x i64] }, align 8
  %t168 = alloca { i64, [1 x i64] }, align 8
  %t204 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t5, ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t5, i64 152, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l13, i64 152, i1 false)
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l15, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 5
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l16, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t23 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l21, !tbaa !27
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t32 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t33, i64 %t30
  %t35 = load { i64, [1 x i64] }, ptr %t34
  store { i64, [1 x i64] } %t35, ptr %l14
  br label %bb52
bb7:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 7
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t52 = load ptr, ptr %l5, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Make", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = icmp sge i32 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l36, !tbaa !27
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Make", ptr %t61, i32 0, i32 4
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  %t68 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, [1 x i64] }, ptr %t69, i64 %t66
  %t71 = load { i64, [1 x i64] }, ptr %t70
  store { i64, [1 x i64] } %t71, ptr %l35
  br label %bb15
bb14:
  store { i64, [1 x i64] } zeroinitializer, ptr %t73
  %t74 = getelementptr { i64, [1 x i64] }, ptr %t73, i32 0, i32 0
  store i64 0, ptr %t74
  %t75 = load { i64, [1 x i64] }, ptr %t73
  store { i64, [1 x i64] } %t75, ptr %l35
  br label %bb15
bb15:
  %t77 = load { i64, [1 x i64] }, ptr %l35
  store { i64, [1 x i64] } %t77, ptr %l14
  br label %bb52
bb16:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l42, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 16
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t93 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l48, !tbaa !27
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Text", ptr %t95, i32 0, i32 1
  %t98 = load i32, ptr %t97, !tbaa !23
  %t100 = sext i32 %t98 to i64
  %t102 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr { i64, [1 x i64] }, ptr %t103, i64 %t100
  %t105 = load { i64, [1 x i64] }, ptr %t104
  store { i64, [1 x i64] } %t105, ptr %l14
  br label %bb52
bb22:
  %t107 = load ptr, ptr %l2, !tbaa !29
  store ptr %t107, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = icmp ne ptr %t108, null
  br i1 %t109, label %bb23, label %bb24
bb23:
  %t111 = load ptr, ptr %l53, !tbaa !29
  %t112 = load i64, ptr %t111
  %t114 = icmp eq i64 %t112, 8
  store i1 %t114, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t115 = load i1, ptr %l54, !tbaa !21
  br i1 %t115, label %bb25, label %bb26
bb25:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t118, i32 0, i32 2
  %t120 = load ptr, ptr %t119
  store ptr %t120, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t122 = getelementptr %"compiler/typed:Plan", ptr %l3, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l59, !tbaa !27
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Collect", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t131 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, [1 x i64] }, ptr %t132, i64 %t129
  %t134 = load { i64, [1 x i64] }, ptr %t133
  store { i64, [1 x i64] } %t134, ptr %l14
  br label %bb52
bb28:
  %t136 = load ptr, ptr %l2, !tbaa !29
  store ptr %t136, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t137 = load ptr, ptr %l64, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb29, label %bb30
bb29:
  %t140 = load ptr, ptr %l64, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 6
  store i1 %t143, ptr %l65, !tbaa !21
  br label %bb30
bb30:
  %t144 = load i1, ptr %l65, !tbaa !21
  br i1 %t144, label %bb31, label %bb32
bb31:
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t147, i32 0, i32 2
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb40
bb33:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 3
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = icmp sge i32 %t154, 0
  br i1 %t156, label %bb34, label %bb35
bb34:
  store ptr %l3, ptr %l74, !tbaa !29
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Call", ptr %t158, i32 0, i32 3
  %t161 = load i32, ptr %t160, !tbaa !23
  store i32 %t161, ptr %l76, !tbaa !23
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l77, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t167 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i64 %t167, ptr %l80
  br label %bb36
bb35:
  store { i64, [1 x i64] } zeroinitializer, ptr %t168
  %t169 = getelementptr { i64, [1 x i64] }, ptr %t168, i32 0, i32 0
  store i64 0, ptr %t169
  %t170 = load { i64, [1 x i64] }, ptr %t168
  store { i64, [1 x i64] } %t170, ptr %l73
  br label %bb39
bb36:
  %t172 = load ptr, ptr %l77, !tbaa !29
  %t173 = load i64, ptr %l80, !tbaa !24
  %t174 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t172, i64 %t173)
  store i64 %t174, ptr %l81
  br label %bb37
bb37:
  %t175 = load ptr, ptr %l74, !tbaa !29
  %t176 = load i32, ptr %l76, !tbaa !23
  %t177 = load i64, ptr %l81, !tbaa !24
  %t178 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t175, i32 %t176, i64 %t177)
  store { i64, [1 x i64] } %t178, ptr %l82
  br label %bb38
bb38:
  %t179 = load { i64, [1 x i64] }, ptr %l82
  store { i64, [1 x i64] } %t179, ptr %l73
  br label %bb39
bb39:
  %t180 = load { i64, [1 x i64] }, ptr %l73
  store { i64, [1 x i64] } %t180, ptr %l14
  br label %bb52
bb40:
  %t181 = load ptr, ptr %l2, !tbaa !29
  store ptr %t181, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t182 = load ptr, ptr %l84, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l84, !tbaa !29
  %t186 = load i64, ptr %t185
  %t188 = icmp eq i64 %t186, 17
  store i1 %t188, ptr %l85, !tbaa !21
  br label %bb42
bb42:
  %t189 = load i1, ptr %l85, !tbaa !21
  br i1 %t189, label %bb43, label %bb44
bb43:
  %t190 = load ptr, ptr %l2, !tbaa !29
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t192, i32 0, i32 2
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load i64, ptr %l1, !tbaa !24
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t202 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t196, i64 %t197, ptr %t198)
  store { i64, [1 x i64] } %t202, ptr %l93
  br label %bb46
bb46:
  %t203 = load { i64, [1 x i64] }, ptr %l93
  store { i64, [1 x i64] } %t203, ptr %l14
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store { i64, [1 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [1 x i64] }, ptr %t204, i32 0, i32 0
  store i64 0, ptr %t205
  %t206 = load { i64, [1 x i64] }, ptr %t204
  store { i64, [1 x i64] } %t206, ptr %l14
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_78dfe086e9f9163d_4fecfa12a5383061)
  unreachable
bb52:
  %t208 = load { i64, [1 x i64] }, ptr %l14
  store { i64, [1 x i64] } %t208, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b4c0d703fa684531_272a8f4f39064c15)
  unreachable
bb25:
  br label %bb26
bb26:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr %l11
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i64 -3, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aletGo_2eOf(%"compiler/free:letGo" %a0, i64 %a1) #0 {
entry:
  %l0 = alloca %"compiler/free:letGo"
  %l5 = alloca i1
  %rv = alloca i1
  store %"compiler/free:letGo" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t6 = icmp eq i64 %t2, %a1
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = getelementptr %"compiler/free:letGo", ptr %l0, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l5, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i1
  %l14 = alloca ptr
  %l23 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:mustW", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l14
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l14, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l9, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l9, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t32 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:mustW", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 26
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l23
  br label %bb9
bb9:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l50 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i1
  %l81 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l148 = alloca ptr
  %l169 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l190 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca i1
  %l233 = alloca { i64, ptr }
  %l240 = alloca ptr
  %l241 = alloca i1
  %l250 = alloca ptr
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t2 = load ptr, ptr %l36, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l36, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l37, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l37, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l50, !tbaa !27
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t41, ptr %t39)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Seq", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l61, !tbaa !29
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Seq", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = icmp eq ptr %t62, null
  br i1 %t64, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_14962ab25e47b4fc_3749941476b1d040)
  unreachable
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Seq", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t70 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t70, ptr %t69)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb141
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t73 = load ptr, ptr %l67, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l67, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 13
  store i1 %t79, ptr %l68, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l68, !tbaa !21
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb83
bb25:
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Match", ptr %t87, i32 0, i32 0
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t100 = icmp slt i64 %t96, %t97
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t104 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t104, ptr %l81, !tbaa !27
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 %t105
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %t112, ptr %t110)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb31:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb26
bb32:
  %t120 = load ptr, ptr %l7, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Match", ptr %t120, i32 0, i32 1
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  store i64 %t127, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s11
  %t129 = load i64, ptr %l13, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb35:
  br label %bb36
bb36:
  %t137 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t137, ptr %l96, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  store ptr %t143, ptr %l15, !tbaa !29
  %t145 = load ptr, ptr %l15, !tbaa !29
  %t147 = getelementptr %"compiler/typed:Arm", ptr %t145, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  store i64 %t152, ptr %l18, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s13
  %t154 = load i64, ptr %l17, !tbaa !24
  %t155 = load i64, ptr %l18, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s13)
  br label %bb50
bb39:
  br label %bb40
bb40:
  %t162 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t162, ptr %l107, !tbaa !27
  %t163 = load i64, ptr %l17, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = getelementptr %"compiler/typed:Alt", ptr %t168, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t175 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t175, 0
  store i64 %t177, ptr %l22, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s15
  %t179 = load i64, ptr %l21, !tbaa !24
  %t180 = load i64, ptr %l22, !tbaa !24
  %t183 = icmp slt i64 %t179, %t180
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s15)
  br label %bb48
bb43:
  br label %bb44
bb44:
  %t187 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t187, ptr %l118, !tbaa !27
  %t188 = load i64, ptr %l21, !tbaa !24
  %t190 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr ptr, ptr %t191, i64 %t188
  %t193 = load ptr, ptr %t192, !tbaa !39
  store ptr %t193, ptr %l23, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:mustW", ptr %t195, i32 0, i32 4
  %t198 = load ptr, ptr %l23, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Bind", ptr %t198, i32 0, i32 0
  %t201 = load i32, ptr %t200, !tbaa !23
  %t203 = sext i32 %t201 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t197, i64 %t203)
  br label %bb45
bb45:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:mustW", ptr %t206, i32 0, i32 5
  %t209 = load ptr, ptr %l23, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Bind", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %t208, ptr %t212)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s15)
  br label %bb47
bb47:
  %t215 = load i64, ptr %l21, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l21, !tbaa !24
  br label %bb41
bb48:
  call void @__olang_scope_close(ptr %s13)
  br label %bb49
bb49:
  %t219 = load i64, ptr %l17, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l17, !tbaa !24
  br label %bb37
bb50:
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Arm", ptr %t223, i32 0, i32 3
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb51, label %bb52
bb51:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l138, !tbaa !29
  %t233 = load ptr, ptr %l15, !tbaa !29
  %t235 = getelementptr %"compiler/typed:Arm", ptr %t233, i32 0, i32 3
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = icmp eq ptr %t236, null
  br i1 %t238, label %bb53, label %bb54
bb52:
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf)
  unreachable
bb54:
  br label %bb55
bb55:
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Arm", ptr %t240, i32 0, i32 3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l138, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t244, ptr %t243)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t246 = load ptr, ptr %l15, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Arm", ptr %t246, i32 0, i32 4
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb58, label %bb59
bb58:
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l148, !tbaa !29
  %t256 = load ptr, ptr %l15, !tbaa !29
  %t258 = getelementptr %"compiler/typed:Arm", ptr %t256, i32 0, i32 4
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb60, label %bb61
bb59:
  br label %bb64
bb60:
  call void @__olang_check_failed(ptr @olang_loc_502532e2e95f04ea_fe436d8dc2f78aae)
  unreachable
bb61:
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l15, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Arm", ptr %t263, i32 0, i32 4
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load ptr, ptr %l148, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t267, ptr %t266)
  br label %bb63
bb63:
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  %t269 = load i64, ptr %l13, !tbaa !24
  %t271 = add i64 %t269, 1
  store i64 %t271, ptr %l13, !tbaa !24
  br label %bb33
bb66:
  %t273 = load ptr, ptr %l7, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Match", ptr %t273, i32 0, i32 2
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = icmp eq ptr %t276, null
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb67, label %bb68
bb67:
  %t282 = load ptr, ptr %l7, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Match", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb69, label %bb70
bb68:
  br label %bb82
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb70:
  br label %bb71
bb71:
  %t289 = load ptr, ptr %l7, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Match", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Arm", ptr %t292, i32 0, i32 3
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb72, label %bb73
bb72:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l169, !tbaa !29
  %t303 = load ptr, ptr %l7, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Match", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  br i1 %t308, label %bb74, label %bb75
bb73:
  br label %bb81
bb74:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb75:
  br label %bb76
bb76:
  %t310 = load ptr, ptr %l7, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Match", ptr %t310, i32 0, i32 2
  %t313 = load ptr, ptr %t312, !tbaa !29
  %t316 = getelementptr %"compiler/typed:Arm", ptr %t313, i32 0, i32 3
  %t317 = load ptr, ptr %t316, !tbaa !29
  store ptr %t317, ptr %l24, !tbaa !29
  %t319 = load ptr, ptr %l24, !tbaa !29
  %t321 = icmp eq ptr %t319, null
  br i1 %t321, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_ba297c355e3740f1_9975a70d069e6a55)
  unreachable
bb78:
  br label %bb79
bb79:
  %t323 = load ptr, ptr %l24, !tbaa !29
  %t324 = load ptr, ptr %l169, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t324, ptr %t323)
  br label %bb80
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb141
bb83:
  %t326 = load ptr, ptr %l1, !tbaa !29
  store ptr %t326, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t327 = load ptr, ptr %l180, !tbaa !29
  %t328 = icmp ne ptr %t327, null
  br i1 %t328, label %bb84, label %bb85
bb84:
  %t330 = load ptr, ptr %l180, !tbaa !29
  %t331 = load i64, ptr %t330
  %t333 = icmp eq i64 %t331, 14
  store i1 %t333, ptr %l181, !tbaa !21
  br label %bb85
bb85:
  %t334 = load i1, ptr %l181, !tbaa !21
  br i1 %t334, label %bb86, label %bb87
bb86:
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [5 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t337, i32 0, i32 2
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l25, !tbaa !29
  br label %bb88
bb87:
  br label %bb109
bb88:
  %t341 = load ptr, ptr %l25, !tbaa !29
  %t343 = getelementptr %"compiler/typed:Try", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = icmp eq ptr %t344, null
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb89, label %bb90
bb89:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l190, !tbaa !29
  %t351 = load ptr, ptr %l25, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Try", ptr %t351, i32 0, i32 0
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t356 = icmp eq ptr %t354, null
  br i1 %t356, label %bb91, label %bb92
bb90:
  br label %bb95
bb91:
  call void @__olang_check_failed(ptr @olang_loc_bb85040a6a786cb8_20e886069e3b9c04)
  unreachable
bb92:
  br label %bb93
bb93:
  %t358 = load ptr, ptr %l25, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Try", ptr %t358, i32 0, i32 0
  %t361 = load ptr, ptr %t360, !tbaa !29
  %t362 = load ptr, ptr %l190, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t362, ptr %t361)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t364 = load ptr, ptr %l25, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Try", ptr %t364, i32 0, i32 1
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  store { i64, ptr } %t367, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t369 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  store i64 %t371, ptr %l28, !tbaa !24
  br label %bb96
bb96:
  store %olang.scope zeroinitializer, ptr %s26
  %t373 = load i64, ptr %l27, !tbaa !24
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s26)
  br label %bb108
bb98:
  br label %bb99
bb99:
  %t381 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t381, ptr %l204, !tbaa !27
  %t382 = load i64, ptr %l27, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t382
  %t387 = load ptr, ptr %t386, !tbaa !39
  store ptr %t387, ptr %l29, !tbaa !29
  %t389 = load ptr, ptr %l29, !tbaa !29
  %t391 = getelementptr %"compiler/typed:Clause", ptr %t389, i32 0, i32 3
  %t392 = load ptr, ptr %t391, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb100, label %bb101
bb100:
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l211, !tbaa !29
  %t399 = load ptr, ptr %l29, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Clause", ptr %t399, i32 0, i32 3
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb102, label %bb103
bb101:
  br label %bb106
bb102:
  call void @__olang_check_failed(ptr @olang_loc_be187497b97f18d7_9641cb8c9c409d3)
  unreachable
bb103:
  br label %bb104
bb104:
  %t406 = load ptr, ptr %l29, !tbaa !29
  %t408 = getelementptr %"compiler/typed:Clause", ptr %t406, i32 0, i32 3
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load ptr, ptr %l211, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %t410, ptr %t409)
  br label %bb105
bb105:
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s26)
  br label %bb107
bb107:
  %t412 = load i64, ptr %l27, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l27, !tbaa !24
  br label %bb96
bb108:
  br label %bb141
bb109:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t417 = load ptr, ptr %l219, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb110, label %bb111
bb110:
  %t420 = load ptr, ptr %l219, !tbaa !29
  %t421 = load i64, ptr %t420
  %t423 = icmp eq i64 %t421, 6
  store i1 %t423, ptr %l220, !tbaa !21
  br label %bb111
bb111:
  %t424 = load i1, ptr %l220, !tbaa !21
  br i1 %t424, label %bb112, label %bb113
bb112:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [5 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t427, i32 0, i32 2
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l30, !tbaa !29
  br label %bb114
bb113:
  br label %bb122
bb114:
  %t431 = load ptr, ptr %l30, !tbaa !29
  %t433 = getelementptr %"compiler/typed:Call", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  store { i64, ptr } %t434, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t436 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t436, 0
  store i64 %t438, ptr %l33, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s31
  %t440 = load i64, ptr %l32, !tbaa !24
  %t441 = load i64, ptr %l33, !tbaa !24
  %t444 = icmp slt i64 %t440, %t441
  %t446 = xor i1 %t444, true
  br i1 %t446, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s31)
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t448 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t448, ptr %l233, !tbaa !27
  %t449 = load i64, ptr %l32, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr ptr, ptr %t452, i64 %t449
  %t454 = load ptr, ptr %t453, !tbaa !39
  %t456 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t456, ptr %t454)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s31)
  br label %bb120
bb120:
  %t460 = load i64, ptr %l32, !tbaa !24
  %t462 = add i64 %t460, 1
  store i64 %t462, ptr %l32, !tbaa !24
  br label %bb115
bb121:
  br label %bb141
bb122:
  %t464 = load ptr, ptr %l1, !tbaa !29
  store ptr %t464, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t465 = load ptr, ptr %l240, !tbaa !29
  %t466 = icmp ne ptr %t465, null
  br i1 %t466, label %bb123, label %bb124
bb123:
  %t468 = load ptr, ptr %l240, !tbaa !29
  %t469 = load i64, ptr %t468
  %t471 = icmp eq i64 %t469, 11
  store i1 %t471, ptr %l241, !tbaa !21
  br label %bb124
bb124:
  %t472 = load i1, ptr %l241, !tbaa !21
  br i1 %t472, label %bb125, label %bb126
bb125:
  %t473 = load ptr, ptr %l1, !tbaa !29
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t473, i32 0, i32 1
  %t476 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t475, i32 0, i32 2
  %t477 = load ptr, ptr %t476
  store ptr %t477, ptr %l35, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t479 = load ptr, ptr %l35, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Cond", ptr %t479, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t484 = icmp eq ptr %t482, null
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb128, label %bb129
bb128:
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l250, !tbaa !29
  %t489 = load ptr, ptr %l35, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Cond", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = icmp eq ptr %t492, null
  br i1 %t494, label %bb130, label %bb131
bb129:
  br label %bb134
bb130:
  call void @__olang_check_failed(ptr @olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892)
  unreachable
bb131:
  br label %bb132
bb132:
  %t496 = load ptr, ptr %l35, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Cond", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t500 = load ptr, ptr %l250, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t500, ptr %t499)
  br label %bb133
bb133:
  br label %bb134
bb134:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t503 = load ptr, ptr %l35, !tbaa !29
  %t505 = getelementptr %"compiler/typed:Cond", ptr %t503, i32 0, i32 2
  %t506 = load ptr, ptr %t505, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexpr(ptr %v0, ptr %v1, ptr %t502, ptr %t506)
  br label %bb135
bb135:
  br label %bb141
bb136:
  br i1 true, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  call void @__olang_check_failed(ptr @olang_loc_d5478abcfcd1a74_537f989617a8cff0)
  unreachable
bb141:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i1
  %l77 = alloca ptr
  %l85 = alloca ptr
  %l89 = alloca i64
  %l96 = alloca { i64, ptr }
  %l103 = alloca i64
  %l106 = alloca i1
  %l114 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i64
  %l138 = alloca i64
  %l141 = alloca i64
  %l162 = alloca i64
  %l166 = alloca i1
  %l167 = alloca ptr
  %l171 = alloca ptr
  %l174 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l190 = alloca i1
  %l191 = alloca ptr
  %l199 = alloca i1
  %l210 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l228 = alloca i1
  %l236 = alloca ptr
  %l237 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l257 = alloca i1
  %l258 = alloca i1
  %l260 = alloca { i64, ptr }
  %l264 = alloca i1
  %s4 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l32
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l32, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 8
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t16 = load ptr, ptr %l36, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l37, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l37, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t25 = load ptr, ptr %l40, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l40, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l41, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t35 = load ptr, ptr %l45, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l45, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 5
  store i1 %t41, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l46, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l49, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t51 = load i1, ptr %l50, !tbaa !21
  br i1 %t51, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t53 = load ptr, ptr %l53, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb23, label %bb24
bb23:
  %t56 = load ptr, ptr %l53, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 16
  store i1 %t59, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t60 = load i1, ptr %l54, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t62 = load ptr, ptr %l57, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t65 = load ptr, ptr %l57, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 8
  store i1 %t68, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t69 = load i1, ptr %l58, !tbaa !21
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t72 = load ptr, ptr %l62, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb33, label %bb34
bb33:
  %t75 = load ptr, ptr %l62, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l63, !tbaa !21
  br label %bb34
bb34:
  %t79 = load i1, ptr %l63, !tbaa !21
  br i1 %t79, label %bb35, label %bb36
bb35:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb63
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t87 = load ptr, ptr %l5, !tbaa !29
  %t90 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i64 %t90, ptr %l70
  br label %bb38
bb38:
  %t91 = load i64, ptr %l70, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t94 = icmp slt i64 %t92, 0
  br i1 %t94, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb42
bb40:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t98, i64 %t99)
  store ptr %t102, ptr %l77
  br label %bb41
bb41:
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 11
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  store i1 %t108, ptr %l73, !tbaa !21
  br label %bb42
bb42:
  %t110 = load i1, ptr %l73, !tbaa !21
  br i1 %t110, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = getelementptr %"compiler/free:Free", ptr %t112, i32 0, i32 1
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t114, i64 %t115)
  store ptr %t118, ptr %l85
  br label %bb46
bb46:
  %t119 = load ptr, ptr %l85, !tbaa !29
  store ptr %t119, ptr %l7, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load ptr, ptr %l7, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Body", ptr %t121, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t127 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t120, i32 %t124)
  store i64 %t127, ptr %l89
  br label %bb47
bb47:
  %t128 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t129 = load i64, ptr %l89, !tbaa !24
  %t131 = icmp eq i64 %t129, %t128
  br i1 %t131, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %t137, !tbaa !23
  %t141 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t134, i32 %t138)
  store { i64, ptr } %t141, ptr %l96
  br label %bb51
bb51:
  %t142 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t145 = icmp ne i64 %t143, 1
  br i1 %t145, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t149 = load ptr, ptr %l7, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Body", ptr %t149, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  %t155 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t148, i32 %t152, i64 0)
  store i64 %t155, ptr %l103
  br label %bb55
bb55:
  %t156 = load i64, ptr %l103, !tbaa !24
  store i64 %t156, ptr %l8, !tbaa !24
  %t157 = load i64, ptr %l8, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb58
bb57:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t162 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t165 = icmp eq i64 %t161, %t162
  store i1 %t165, ptr %l106, !tbaa !21
  br label %bb58
bb58:
  %t167 = load i1, ptr %l106, !tbaa !21
  br i1 %t167, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t169 = load ptr, ptr %l3, !tbaa !29
  %t171 = getelementptr %"compiler/free:Free", ptr %t169, i32 0, i32 27
  %t172 = load i64, ptr %l6, !tbaa !24
  %t175 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t171, i64 %t172)
  store i1 %t175, ptr %l114
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s4)
  %t176 = load i1, ptr %l114, !tbaa !21
  store i1 %t176, ptr %rv
  br label %ret
bb63:
  %t177 = load ptr, ptr %l1, !tbaa !29
  store ptr %t177, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t178 = load ptr, ptr %l115, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb64, label %bb65
bb64:
  %t181 = load ptr, ptr %l115, !tbaa !29
  %t182 = load i64, ptr %t181
  %t184 = icmp eq i64 %t182, 2
  store i1 %t184, ptr %l116, !tbaa !21
  br label %bb65
bb65:
  %t185 = load i1, ptr %l116, !tbaa !21
  br i1 %t185, label %bb66, label %bb67
bb66:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t188, i32 0, i32 2
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb105
bb68:
  %t192 = load ptr, ptr %l9, !tbaa !29
  store ptr %t192, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t193 = load ptr, ptr %l121, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb69, label %bb70
bb69:
  %t196 = load ptr, ptr %l121, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t200 = load i1, ptr %l122, !tbaa !21
  br i1 %t200, label %bb71, label %bb72
bb71:
  %t201 = load ptr, ptr %l9, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t203, i32 0, i32 2
  %t205 = load i32, ptr %t204
  store i32 %t205, ptr %l10, !tbaa !23
  br label %bb73
bb72:
  br label %bb100
bb73:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l10, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t213 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t207, i64 %t210)
  store i1 %t213, ptr %l130
  br label %bb74
bb74:
  %t214 = load i1, ptr %l130, !tbaa !21
  br i1 %t214, label %bb75, label %bb76
bb75:
  store i1 false, ptr %rv
  br label %ret
bb76:
  br label %bb77
bb77:
  store i64 0, ptr %l11, !tbaa !24
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/free:mustW", ptr %t216, i32 0, i32 4
  %t220 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t218)
  store i64 %t220, ptr %l134
  br label %bb78
bb78:
  %t221 = load i64, ptr %l134, !tbaa !24
  store i64 %t221, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t222 = load i64, ptr %l12, !tbaa !24
  %t223 = load i64, ptr %l11, !tbaa !24
  %t226 = icmp sgt i64 %t222, %t223
  br i1 %t226, label %bb79, label %bb80
bb79:
  %t228 = load i64, ptr %l13, !tbaa !24
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb84
bb81:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t233 = load i64, ptr %l11, !tbaa !24
  %t236 = sub i64 %t232, %t233
  %t237 = load i64, ptr %l13, !tbaa !24
  %t240 = add i64 %t236, %t237
  %t242 = sub i64 %t240, 1
  %t243 = load i64, ptr %l13, !tbaa !24
  %t246 = sdiv i64 %t242, %t243
  store i64 %t246, ptr %l141, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb83
bb83:
  %t248 = load i64, ptr %l141, !tbaa !24
  store i64 %t248, ptr %l138, !tbaa !24
  br label %bb84
bb84:
  %t249 = load i64, ptr %l138, !tbaa !24
  store i64 %t249, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t250 = load i64, ptr %l15, !tbaa !24
  %t251 = load i64, ptr %l14, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb87:
  br label %bb88
bb88:
  %t258 = load i64, ptr %l11, !tbaa !24
  %t259 = load i64, ptr %l15, !tbaa !24
  %t260 = load i64, ptr %l13, !tbaa !24
  %t263 = mul i64 %t259, %t260
  %t266 = add i64 %t258, %t263
  store i64 %t266, ptr %l16, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:mustW", ptr %t268, i32 0, i32 4
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t270, i64 %t271)
  store i64 %t274, ptr %l162
  br label %bb89
bb89:
  %t275 = load i32, ptr %l10, !tbaa !23
  %t277 = sext i32 %t275 to i64
  %t278 = load i64, ptr %l162, !tbaa !24
  %t280 = icmp eq i64 %t278, %t277
  br i1 %t280, label %bb90, label %bb91
bb90:
  %t282 = load ptr, ptr %l0, !tbaa !29
  store ptr %t282, ptr %l167, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/free:mustW", ptr %t283, i32 0, i32 5
  %t286 = load i64, ptr %l16, !tbaa !24
  %t289 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t285, i64 %t286)
  store ptr %t289, ptr %l171
  br label %bb92
bb91:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb94
bb92:
  %t290 = load i64, ptr %l2, !tbaa !24
  %t292 = add i64 %t290, 1
  %t293 = load ptr, ptr %l167, !tbaa !29
  %t294 = load ptr, ptr %l171, !tbaa !29
  %t296 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t293, ptr %t294, i64 %t292)
  store i1 %t296, ptr %l174
  br label %bb93
bb93:
  %t297 = load i1, ptr %l174, !tbaa !21
  %t298 = xor i1 %t297, true
  store i1 %t298, ptr %l166, !tbaa !21
  br label %bb94
bb94:
  %t300 = load i1, ptr %l166, !tbaa !21
  br i1 %t300, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s13)
  store i1 false, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb98:
  %t302 = load i64, ptr %l15, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l15, !tbaa !24
  br label %bb85
bb99:
  store i1 true, ptr %rv
  br label %ret
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  store i1 false, ptr %rv
  br label %ret
bb104:
  call void @__olang_check_failed(ptr @olang_loc_7a954698926d7de_664d4c02e090fa22)
  unreachable
bb105:
  %t308 = load ptr, ptr %l1, !tbaa !29
  store ptr %t308, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t309 = load ptr, ptr %l181, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb106, label %bb107
bb106:
  %t312 = load ptr, ptr %l181, !tbaa !29
  %t313 = load i64, ptr %t312
  %t315 = icmp eq i64 %t313, 14
  store i1 %t315, ptr %l182, !tbaa !21
  br label %bb107
bb107:
  %t316 = load i1, ptr %l182, !tbaa !21
  br i1 %t316, label %bb108, label %bb109
bb108:
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t319, i32 0, i32 2
  %t321 = load ptr, ptr %t320
  store ptr %t321, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb137
bb110:
  %t323 = load ptr, ptr %l17, !tbaa !29
  %t325 = getelementptr %"compiler/typed:Try", ptr %t323, i32 0, i32 0
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = icmp eq ptr %t326, null
  br i1 %t328, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb117
bb112:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l191, !tbaa !29
  %t331 = load ptr, ptr %l17, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Try", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = icmp eq ptr %t334, null
  br i1 %t336, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_893474d063c17328_1c44af56cc3f848c)
  unreachable
bb114:
  br label %bb115
bb115:
  %t338 = load ptr, ptr %l17, !tbaa !29
  %t340 = getelementptr %"compiler/typed:Try", ptr %t338, i32 0, i32 0
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t342 = load i64, ptr %l2, !tbaa !24
  %t344 = add i64 %t342, 1
  %t345 = load ptr, ptr %l191, !tbaa !29
  %t348 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t345, ptr %t341, i64 %t344)
  store i1 %t348, ptr %l199
  br label %bb116
bb116:
  %t349 = load i1, ptr %l199, !tbaa !21
  %t350 = xor i1 %t349, true
  store i1 %t350, ptr %l190, !tbaa !21
  br label %bb117
bb117:
  %t352 = load i1, ptr %l190, !tbaa !21
  br i1 %t352, label %bb118, label %bb119
bb118:
  store i1 false, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  %t354 = load ptr, ptr %l17, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Try", ptr %t354, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  store { i64, ptr } %t357, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t359, 0
  store i64 %t361, ptr %l20, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s20
  %t363 = load i64, ptr %l19, !tbaa !24
  %t364 = load i64, ptr %l20, !tbaa !24
  %t367 = icmp slt i64 %t363, %t364
  %t369 = xor i1 %t367, true
  br i1 %t369, label %bb122, label %bb123
bb122:
  call void @__olang_scope_close(ptr %s20)
  br label %bb136
bb123:
  br label %bb124
bb124:
  %t371 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t371, ptr %l210, !tbaa !27
  %t372 = load i64, ptr %l19, !tbaa !24
  %t374 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = getelementptr ptr, ptr %t375, i64 %t372
  %t377 = load ptr, ptr %t376, !tbaa !39
  %t381 = getelementptr %"compiler/typed:Clause", ptr %t377, i32 0, i32 4
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t384, 0
  store i64 %t386, ptr %l24, !tbaa !24
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s22
  %t388 = load i64, ptr %l23, !tbaa !24
  %t389 = load i64, ptr %l24, !tbaa !24
  %t392 = icmp slt i64 %t388, %t389
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s22)
  br label %bb134
bb127:
  br label %bb128
bb128:
  %t396 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t396, ptr %l221, !tbaa !27
  %t397 = load i64, ptr %l23, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr ptr, ptr %t400, i64 %t397
  %t402 = load ptr, ptr %t401, !tbaa !39
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i64, ptr %l2, !tbaa !24
  %t408 = add i64 %t406, 1
  %t412 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t404, ptr %t402, i64 %t408)
  store i1 %t412, ptr %l228
  br label %bb129
bb129:
  %t413 = load i1, ptr %l228, !tbaa !21
  %t414 = xor i1 %t413, true
  br i1 %t414, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s20)
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s22)
  br label %bb133
bb133:
  %t417 = load i64, ptr %l23, !tbaa !24
  %t419 = add i64 %t417, 1
  store i64 %t419, ptr %l23, !tbaa !24
  br label %bb125
bb134:
  call void @__olang_scope_close(ptr %s20)
  br label %bb135
bb135:
  %t421 = load i64, ptr %l19, !tbaa !24
  %t423 = add i64 %t421, 1
  store i64 %t423, ptr %l19, !tbaa !24
  br label %bb121
bb136:
  store i1 true, ptr %rv
  br label %ret
bb137:
  %t426 = load ptr, ptr %l1, !tbaa !29
  store ptr %t426, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t427 = load ptr, ptr %l236, !tbaa !29
  %t428 = icmp ne ptr %t427, null
  br i1 %t428, label %bb138, label %bb139
bb138:
  %t430 = load ptr, ptr %l236, !tbaa !29
  %t431 = load i64, ptr %t430
  %t433 = icmp eq i64 %t431, 17
  store i1 %t433, ptr %l237, !tbaa !21
  br label %bb139
bb139:
  %t434 = load i1, ptr %l237, !tbaa !21
  br i1 %t434, label %bb140, label %bb141
bb140:
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr { i64, [5 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t437, i32 0, i32 2
  %t439 = load ptr, ptr %t438
  store ptr %t439, ptr %l26, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l26, !tbaa !29
  %t443 = load i64, ptr %l2, !tbaa !24
  %t445 = add i64 %t443, 1
  %t449 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t441, ptr %t442, i64 %t445)
  store i1 %t449, ptr %l246
  br label %bb143
bb143:
  %t450 = load i1, ptr %l246, !tbaa !21
  store i1 %t450, ptr %rv
  br label %ret
bb144:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t452 = load ptr, ptr %l247, !tbaa !29
  %t453 = icmp ne ptr %t452, null
  br i1 %t453, label %bb145, label %bb146
bb145:
  %t455 = load ptr, ptr %l247, !tbaa !29
  %t456 = load i64, ptr %t455
  %t458 = icmp eq i64 %t456, 9
  store i1 %t458, ptr %l248, !tbaa !21
  br label %bb146
bb146:
  %t459 = load i1, ptr %l248, !tbaa !21
  br i1 %t459, label %bb147, label %bb148
bb147:
  %t460 = load ptr, ptr %l1, !tbaa !29
  %t462 = getelementptr { i64, [5 x i64] }, ptr %t460, i32 0, i32 1
  %t463 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t462, i32 0, i32 2
  %t464 = load i32, ptr %t463
  store i32 %t464, ptr %l27
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t468, i32 0, i32 4
  %t470 = load { i64, ptr }, ptr %t469
  store { i64, ptr } %t470, ptr %l28, !tbaa !27
  br label %bb149
bb148:
  br label %bb155
bb149:
  %t472 = load i32, ptr %l27
  %t473 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t476 = call i1 @compiler_2ffree_2eisConversion(ptr %v1, i32 %t472, { i64, ptr } %t473)
  store i1 %t476, ptr %l257
  br label %bb150
bb150:
  %t477 = load i1, ptr %l257, !tbaa !21
  br i1 %t477, label %bb151, label %bb152
bb151:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t479, ptr %l260, !tbaa !27
  %t480 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 0
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t484 = load i64, ptr %l2, !tbaa !24
  %t486 = add i64 %t484, 1
  %t490 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t478, ptr %t483, i64 %t486)
  store i1 %t490, ptr %l264
  br label %bb153
bb152:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb154
bb153:
  %t491 = load i1, ptr %l264, !tbaa !21
  store i1 %t491, ptr %l258, !tbaa !21
  br label %bb154
bb154:
  %t492 = load i1, ptr %l258, !tbaa !21
  store i1 %t492, ptr %rv
  br label %ret
bb155:
  br i1 true, label %bb156, label %bb157
bb156:
  br label %bb158
bb157:
  br label %bb159
bb158:
  store i1 false, ptr %rv
  br label %ret
bb159:
  call void @__olang_check_failed(ptr @olang_loc_a532406d51285a24_27441d0f137c6648)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:mustW", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t21)
  store i64 %t24, ptr %l14
  br label %bb6
bb6:
  %t25 = load i64, ptr %l14, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9be7a7b731d47dfc_cd79088c97deb358)
  unreachable
bb12:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:mustW", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i64 %t33, ptr %l18
  br label %bb13
bb13:
  %t34 = load i64, ptr %l18, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = icmp sge i64 %t35, 0
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb16
bb15:
  %t41 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t41, ptr %l21, !tbaa !24
  br label %bb16
bb16:
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca i64
  %l30 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1777536395e8cd8b_97ff53b4c3030f1f)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i64 %t24, ptr %l21
  br label %bb7
bb7:
  %t25 = load i64, ptr %l21, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t68, ptr %l41, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t77, ptr %t74)
  store i64 %t81, ptr %l47
  br label %bb16
bb16:
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = call i64 @compiler_2ffree_2emeet(i64 %t82, i64 %t83)
  store i64 %t84, ptr %l48
  br label %bb17
bb17:
  %t85 = load i64, ptr %l48, !tbaa !24
  store i64 %t85, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb18:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l4, !tbaa !24
  br label %bb8
bb21:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca i64
  %l37 = alloca i64
  %l61 = alloca i1
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l78 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l104 = alloca ptr
  %l107 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca i64
  %l120 = alloca ptr
  %l123 = alloca i64
  %l126 = alloca ptr
  %l129 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca i1
  %l138 = alloca i64
  %l140 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l144 = alloca i1
  %l151 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 61
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t12, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t15)
  store i1 %t18, ptr %l26
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb4
bb3:
  %t19 = load i1, ptr %l26, !tbaa !21
  store i1 %t19, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l20, !tbaa !21
  store i1 %t20, ptr %l2, !tbaa !21
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l27
  br label %bb5
bb5:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Block", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb8:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb10
bb10:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l9, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = add i64 %t76, 1
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Block", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = icmp slt i64 %t78, %t84
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Block", ptr %t89, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l63, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 %t95
  %t100 = load ptr, ptr %t99, !tbaa !39
  %t102 = call i1 @compiler_2ffree_2eleaves(ptr %v1, ptr %t100)
  store i1 %t102, ptr %l67
  br label %bb18
bb17:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb19
bb18:
  %t103 = load i1, ptr %l67, !tbaa !21
  store i1 %t103, ptr %l61, !tbaa !21
  br label %bb19
bb19:
  %t104 = load i1, ptr %l61, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 22
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 11
  %t111 = load i64, ptr %t110, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t107, i64 %t111)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t114 = load i1, ptr %l2, !tbaa !21
  br i1 %t114, label %bb24, label %bb25
bb24:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:walker", ptr %t116, i32 0, i32 11
  %t119 = load i64, ptr %t118, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t119)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Block", ptr %t123, i32 0, i32 1
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l78, !tbaa !27
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t127
  %t132 = load ptr, ptr %t131, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t122, ptr %t132)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l8, !tbaa !24
  br label %bb12
bb30:
  %t139 = load i1, ptr %l2, !tbaa !21
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  br label %bb33
bb33:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:walker", ptr %t143, i32 0, i32 11
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = sub i64 %t146, 1
  store i64 %t148, ptr %l10, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  store i64 -1, ptr %l13, !tbaa !24
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/typed:Block", ptr %t150, i32 0, i32 1
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t153, 0
  %t157 = sub i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t159 = load i64, ptr %l14, !tbaa !24
  %t161 = icmp sge i64 %t159, 0
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s8)
  br label %bb81
bb36:
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Block", ptr %t165, i32 0, i32 1
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l96, !tbaa !27
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr ptr, ptr %t172, i64 %t169
  %t174 = load ptr, ptr %t173, !tbaa !39
  store ptr %t174, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t177 = load ptr, ptr %l99, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb38, label %bb39
bb38:
  %t180 = load ptr, ptr %l99, !tbaa !29
  %t181 = load i64, ptr %t180
  %t183 = icmp eq i64 %t181, 12
  store i1 %t183, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l100, !tbaa !21
  br i1 %t184, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 53
  store ptr %t187, ptr %l104, !tbaa !29
  %t188 = load i64, ptr %l14, !tbaa !24
  %t191 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t188)
  store i64 %t191, ptr %l107
  br label %bb43
bb43:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = load i64, ptr %l107, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t193, i64 %t194, i64 %t192)
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d)
  unreachable
bb50:
  %t196 = load i64, ptr %l11, !tbaa !24
  %t198 = icmp sge i64 %t196, 0
  br i1 %t198, label %bb51, label %bb52
bb51:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:walker", ptr %t200, i32 0, i32 54
  store ptr %t202, ptr %l112, !tbaa !29
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t203)
  store i64 %t206, ptr %l115
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t208 = load ptr, ptr %l112, !tbaa !29
  %t209 = load i64, ptr %l115, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t208, i64 %t209, i64 %t207)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t211 = load i64, ptr %l12, !tbaa !24
  %t213 = icmp sge i64 %t211, 0
  br i1 %t213, label %bb56, label %bb57
bb56:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 55
  store ptr %t217, ptr %l120, !tbaa !29
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t218)
  store i64 %t221, ptr %l123
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = load ptr, ptr %l120, !tbaa !29
  %t224 = load i64, ptr %l123, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t223, i64 %t224, i64 %t222)
  br label %bb59
bb59:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 56
  store ptr %t228, ptr %l126, !tbaa !29
  %t229 = load i64, ptr %l14, !tbaa !24
  %t232 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t229)
  store i64 %t232, ptr %l129
  br label %bb60
bb60:
  %t233 = load i64, ptr %l12, !tbaa !24
  %t234 = load ptr, ptr %l126, !tbaa !29
  %t235 = load i64, ptr %l129, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t234, i64 %t235, i64 %t233)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Block", ptr %t237, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l132, !tbaa !27
  %t241 = load i64, ptr %l14, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  %t248 = call i1 @compiler_2ffree_2eleavesFunction(ptr %v1, ptr %t246)
  store i1 %t248, ptr %l135
  br label %bb63
bb63:
  %t249 = load i1, ptr %l135, !tbaa !21
  br i1 %t249, label %bb64, label %bb65
bb64:
  %t250 = load i64, ptr %l14, !tbaa !24
  %t253 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t250)
  store i64 %t253, ptr %l138
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t254 = load i64, ptr %l138, !tbaa !24
  store i64 %t254, ptr %l11, !tbaa !24
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l1, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Block", ptr %t255, i32 0, i32 1
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l140, !tbaa !27
  %t259 = load i64, ptr %l14, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  store ptr %t264, ptr %l16, !tbaa !29
  %t266 = load ptr, ptr %l16, !tbaa !29
  store ptr %t266, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t267 = load ptr, ptr %l143, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb68, label %bb69
bb68:
  %t270 = load ptr, ptr %l143, !tbaa !29
  %t271 = load i64, ptr %t270
  %t273 = icmp eq i64 %t271, 5
  store i1 %t273, ptr %l144, !tbaa !21
  br label %bb69
bb69:
  %t274 = load i1, ptr %l144, !tbaa !21
  br i1 %t274, label %bb70, label %bb71
bb70:
  %t275 = load ptr, ptr %l16, !tbaa !29
  %t277 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t277, i32 0, i32 2
  %t279 = load i32, ptr %t278
  store i32 %t279, ptr %l17, !tbaa !23
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t281 = load i64, ptr %l14, !tbaa !24
  %t284 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t281)
  store i64 %t284, ptr %l151
  br label %bb73
bb73:
  %t285 = load i64, ptr %l151, !tbaa !24
  store i64 %t285, ptr %l12, !tbaa !24
  %t286 = load i32, ptr %l17, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l13, !tbaa !24
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb79
bb74:
  br i1 true, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_59a6b24cdfdba848_73366ee735d239ac)
  unreachable
bb79:
  call void @__olang_scope_close(ptr %s8)
  br label %bb80
bb80:
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = sub i64 %t290, 1
  store i64 %t292, ptr %l14, !tbaa !24
  br label %bb34
bb81:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca ptr
  %l83 = alloca i1
  %l93 = alloca ptr
  %l97 = alloca i1
  %l100 = alloca i1
  %l108 = alloca ptr
  %l111 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l128 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l147 = alloca ptr
  %l148 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l165 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l174 = alloca { i64, ptr }
  %l177 = alloca ptr
  %l180 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l185 = alloca i1
  %l186 = alloca i1
  %l190 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca i1
  %l199 = alloca i1
  %l204 = alloca i1
  %l206 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca i32
  %l219 = alloca { i64, ptr }
  %l224 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i32
  %l248 = alloca { i64, ptr }
  %l252 = alloca i64
  %l256 = alloca i64
  %l257 = alloca i64
  %l259 = alloca i64
  %l261 = alloca ptr
  %l264 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l266 = alloca i1
  %l269 = alloca i1
  %l276 = alloca ptr
  %l280 = alloca ptr
  %l283 = alloca i64
  %l289 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l294 = alloca i32
  %l303 = alloca { i64, ptr }
  %l312 = alloca i64
  %l314 = alloca i64
  %l319 = alloca i1
  %l320 = alloca ptr
  %l321 = alloca i64
  %l323 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l328 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l341 = alloca ptr
  %l342 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l346 = alloca i32
  %l355 = alloca { i64, ptr }
  %l358 = alloca i64
  %l360 = alloca i64
  %l362 = alloca ptr
  %l365 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l376 = alloca i1
  %l384 = alloca ptr
  %l385 = alloca { i64, ptr }
  %l388 = alloca { i64, ptr }
  %l389 = alloca i32
  %l398 = alloca { i64, ptr }
  %l401 = alloca ptr
  %l402 = alloca i64
  %l403 = alloca i64
  %l404 = alloca %"compiler/source:Span"
  %l406 = alloca %"compiler/source:Span"
  %l415 = alloca i1
  %l422 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l424 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l428 = alloca i32
  %l437 = alloca { i64, ptr }
  %l441 = alloca i64
  %l455 = alloca { i64, ptr }
  %l458 = alloca { i64, ptr }
  %l459 = alloca i32
  %l468 = alloca { i64, ptr }
  %l473 = alloca i1
  %l484 = alloca ptr
  %l486 = alloca i64
  %l487 = alloca i1
  %l497 = alloca { i64, ptr }
  %l501 = alloca ptr
  %l503 = alloca ptr
  %l505 = alloca i32
  %l506 = alloca i32
  %l507 = alloca i32
  %l515 = alloca { i64, ptr }
  %l518 = alloca { i64, ptr }
  %l519 = alloca i32
  %l528 = alloca { i64, ptr }
  %l537 = alloca ptr
  %l540 = alloca i1
  %l544 = alloca ptr
  %l545 = alloca i64
  %l547 = alloca i1
  %l551 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l79
  br label %bb1
bb1:
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t7, ptr %lp5
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  %t9 = load ptr, ptr %lp5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l10, !tbaa !29
  store ptr %t15, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t16 = load ptr, ptr %l82, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l82, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l83, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l83, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l10, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l11, !tbaa !23
  br label %bb6
bb5:
  br label %bb32
bb6:
  %t30 = load i32, ptr %l11, !tbaa !23
  %t32 = sext i32 %t30 to i64
  store i64 %t32, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l93
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l93, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 11
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l100
  br label %bb10
bb9:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb11
bb10:
  %t53 = load i1, ptr %l100, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l97, !tbaa !21
  br label %bb11
bb11:
  %t56 = load i1, ptr %l97, !tbaa !21
  store i1 %t56, ptr %l7, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 48
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store ptr %t70, ptr %l108
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:walker", ptr %t71, i32 0, i32 1
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load ptr, ptr %l108, !tbaa !29
  %t77 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t75, i64 %t74)
  store i1 %t77, ptr %l111
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 2
  %t81 = load i1, ptr %t80, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb17, label %bb18
bb17:
  %t85 = load i1, ptr %l7, !tbaa !21
  br i1 %t85, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb23
bb19:
  store i1 true, ptr %l117, !tbaa !21
  br label %bb22
bb20:
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 28
  %t90 = load i64, ptr %l6, !tbaa !24
  %t93 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l121
  br label %bb21
bb21:
  %t94 = load i1, ptr %l121, !tbaa !21
  store i1 %t94, ptr %l117, !tbaa !21
  br label %bb22
bb22:
  %t95 = load i1, ptr %l117, !tbaa !21
  store i1 %t95, ptr %l115, !tbaa !21
  br label %bb23
bb23:
  %t96 = load i1, ptr %l115, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load i64, ptr %l6, !tbaa !24
  %t108 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %t97, i64 %t101, ptr %t102, i64 %t103)
  store i1 %t108, ptr %l128
  br label %bb26
bb25:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb27
bb26:
  %t109 = load i1, ptr %l128, !tbaa !21
  store i1 %t109, ptr %l122, !tbaa !21
  br label %bb27
bb27:
  %t110 = load i1, ptr %l122, !tbaa !21
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/free:walker", ptr %t112, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t111, i64 %t115)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb70
bb32:
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t119 = load ptr, ptr %l132, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb33, label %bb34
bb33:
  %t122 = load ptr, ptr %l132, !tbaa !29
  %t123 = load i64, ptr %t122
  %t125 = icmp eq i64 %t123, 2
  store i1 %t125, ptr %l133, !tbaa !21
  br label %bb34
bb34:
  %t126 = load i1, ptr %l133, !tbaa !21
  br i1 %t126, label %bb35, label %bb36
bb35:
  %t127 = load ptr, ptr %l10, !tbaa !29
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { ptr }, ptr %t129, i32 0, i32 0
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l12, !tbaa !29
  br label %bb37
bb36:
  br label %bb43
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l12, !tbaa !29
  %t137 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s4, ptr %t133, ptr %t134)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l140
  br label %bb38
bb38:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 2
  %t141 = load i1, ptr %t140, !tbaa !21
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb39, label %bb40
bb39:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/free:walker", ptr %t146, i32 0, i32 1
  %t149 = load i64, ptr %t148, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t145, i64 %t149)
  br label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb70
bb43:
  %t152 = load ptr, ptr %l10, !tbaa !29
  store ptr %t152, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t153 = load ptr, ptr %l147, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l147, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 3
  store i1 %t159, ptr %l148, !tbaa !21
  br label %bb45
bb45:
  %t160 = load i1, ptr %l148, !tbaa !21
  br i1 %t160, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb53
bb48:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 2
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb49, label %bb50
bb49:
  %t168 = load ptr, ptr %l4, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 1
  %t172 = load i64, ptr %t171, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t168, i64 %t172)
  br label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb52
bb52:
  br label %bb70
bb53:
  %t175 = load ptr, ptr %l10, !tbaa !29
  store ptr %t175, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t176 = load ptr, ptr %l157, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb54, label %bb55
bb54:
  %t179 = load ptr, ptr %l157, !tbaa !29
  %t180 = load i64, ptr %t179
  %t182 = icmp eq i64 %t180, 4
  store i1 %t182, ptr %l158, !tbaa !21
  br label %bb55
bb55:
  %t183 = load i1, ptr %l158, !tbaa !21
  br i1 %t183, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb70
bb59:
  %t184 = load ptr, ptr %l10, !tbaa !29
  store ptr %t184, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t185 = load ptr, ptr %l161, !tbaa !29
  %t186 = icmp ne ptr %t185, null
  br i1 %t186, label %bb60, label %bb61
bb60:
  %t188 = load ptr, ptr %l161, !tbaa !29
  %t189 = load i64, ptr %t188
  %t191 = icmp eq i64 %t189, 1
  store i1 %t191, ptr %l162, !tbaa !21
  br label %bb61
bb61:
  %t192 = load i1, ptr %l162, !tbaa !21
  br i1 %t192, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb70
bb65:
  br i1 true, label %bb66, label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_check_failed(ptr @olang_loc_ec84fe6443685676_e22a9bc60a48a0b2)
  unreachable
bb70:
  %t193 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %l165
  br label %bb71
bb71:
  %t194 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l165
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %l13
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Call", ptr %t195, i32 0, i32 1
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l16, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t204 = load i64, ptr %l15, !tbaa !24
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb79
bb74:
  br label %bb75
bb75:
  %t212 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t212, ptr %l174, !tbaa !27
  %t213 = load i64, ptr %l15, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  store ptr %l13, ptr %l177, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t224 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t220, ptr %t218)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l180
  br label %bb76
bb76:
  %t225 = load ptr, ptr %l177, !tbaa !29
  %t226 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l180
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H514c3278d648f49337aafc4c9fcf3b34(ptr %s0, ptr %s0, ptr %t225, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s12)
  br label %bb78
bb78:
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = add i64 %t227, 1
  store i64 %t229, ptr %l15, !tbaa !24
  br label %bb72
bb79:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t235 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t231, i32 %a2)
  store i1 %t235, ptr %l185
  br label %bb80
bb80:
  %t236 = load i1, ptr %l185, !tbaa !21
  br i1 %t236, label %bb81, label %bb82
bb81:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/typed:Call", ptr %t237, i32 0, i32 3
  %t240 = load i32, ptr %t239, !tbaa !23
  %t242 = icmp sge i32 %t240, 0
  store i1 %t242, ptr %l186, !tbaa !21
  br label %bb83
bb82:
  store i1 false, ptr %l186, !tbaa !21
  br label %bb83
bb83:
  %t244 = load i1, ptr %l186, !tbaa !21
  br i1 %t244, label %bb84, label %bb85
bb84:
  %t245 = load ptr, ptr %lp5
  store ptr %t245, ptr %l190, !tbaa !29
  %t246 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr %"compiler/typed:Call", ptr %t247, i32 0, i32 3
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t255 = call i64 @compiler_2ffree_2eorig(i64 %t246, i64 %t252)
  store i64 %t255, ptr %l195
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t256 = load ptr, ptr %l190, !tbaa !29
  %t257 = load i64, ptr %l195, !tbaa !24
  %t258 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t256, i64 %t257)
  store i1 %t258, ptr %l196
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t259 = load i64, ptr %l6, !tbaa !24
  %t261 = icmp sge i64 %t259, 0
  br i1 %t261, label %bb89, label %bb90
bb89:
  %t263 = load i1, ptr %l7, !tbaa !21
  %t265 = xor i1 %t263, true
  store i1 %t265, ptr %l199, !tbaa !21
  br label %bb91
bb90:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb91
bb91:
  %t267 = load i1, ptr %l199, !tbaa !21
  br i1 %t267, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s15
  %t268 = load ptr, ptr %l4, !tbaa !29
  %t269 = load i64, ptr %l6, !tbaa !24
  %t272 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t268, i64 %t269)
  store i1 %t272, ptr %l204
  br label %bb94
bb93:
  br label %bb242
bb94:
  %t273 = load i1, ptr %l204, !tbaa !21
  br i1 %t273, label %bb95, label %bb96
bb95:
  store ptr %l13, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb97
bb96:
  br label %bb113
bb97:
  store %olang.scope zeroinitializer, ptr %s18
  %t275 = load ptr, ptr %l18, !tbaa !29
  %t276 = load i64, ptr %l19, !tbaa !24
  %t279 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_Hfda32f46ad718b1ec245a2f2facf857a(ptr %s0, ptr %t275, i64 %t276)
  %t280 = extractvalue { i32, { i64, ptr } } %t279, 1
  %t281 = extractvalue { i32, { i64, ptr } } %t279, 0
  store i32 %t281, ptr %l210
  %t282 = icmp ne i32 %t281, 0
  br i1 %t282, label %bb99, label %ok.283
ok.283:
  store { i64, ptr } %t280, ptr %l209
  br label %bb98
bb98:
  %t284 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t284, ptr %l206, !tbaa !27
  br label %bb103
bb99:
  %t285 = load i32, ptr %l210, !tbaa !23
  %t286 = ashr i32 %t285, 16
  %t288 = icmp eq i32 %t286, 1
  br i1 %t288, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_d4fc5cdd71cd4f17_b1c92b5edf644a33)
  unreachable
bb102:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s18)
  br label %bb112
bb103:
  %t290 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t290, ptr %l20, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t293 = extractvalue { i64, ptr } %t291, 0
  store i64 %t293, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s19
  %t295 = load i64, ptr %l22, !tbaa !24
  %t296 = load i64, ptr %l21, !tbaa !24
  %t299 = icmp slt i64 %t295, %t296
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb106:
  br label %bb107
bb107:
  %t303 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t303, ptr %l219, !tbaa !27
  %t304 = load i64, ptr %l22, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t307, i64 %t304
  %t309 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t308
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t309, ptr %l23
  %t311 = load ptr, ptr %lp5
  %t314 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s19, ptr %t311, ptr %l23)
  store i1 %t314, ptr %l224
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t315 = load i64, ptr %l22, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l22, !tbaa !24
  br label %bb104
bb110:
  %t319 = load i64, ptr %l19, !tbaa !24
  %t320 = load i64, ptr %l21, !tbaa !24
  %t323 = add i64 %t319, %t320
  store i64 %t323, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb111
bb111:
  br label %bb97
bb112:
  %t325 = load ptr, ptr %lp5
  %t326 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t325
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t326, ptr %rv
  br label %ret
bb113:
  %t328 = load ptr, ptr %l4, !tbaa !29
  %t330 = getelementptr %"compiler/free:Free", ptr %t328, i32 0, i32 20
  %t331 = load i64, ptr %l6, !tbaa !24
  %t334 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t330, i64 %t331)
  store ptr %t334, ptr %l234
  br label %bb114
bb114:
  %t335 = load ptr, ptr %l234, !tbaa !29
  store ptr %t335, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s22
  %t336 = load ptr, ptr %l24, !tbaa !29
  %t337 = load i64, ptr %l25, !tbaa !24
  %t340 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t336, i64 %t337)
  %t341 = extractvalue { i32, { i64, ptr } } %t340, 1
  %t342 = extractvalue { i32, { i64, ptr } } %t340, 0
  store i32 %t342, ptr %l239
  %t343 = icmp ne i32 %t342, 0
  br i1 %t343, label %bb117, label %ok.344
ok.344:
  store { i64, ptr } %t341, ptr %l238
  br label %bb116
bb116:
  %t345 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t345, ptr %l235, !tbaa !27
  br label %bb121
bb117:
  %t346 = load i32, ptr %l239, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  br i1 %t349, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_990ecb27a91b16dc_4f01b12db61c2318)
  unreachable
bb120:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb141
bb121:
  %t351 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t351, ptr %l26, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t352, 0
  store i64 %t354, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s23
  %t356 = load i64, ptr %l28, !tbaa !24
  %t357 = load i64, ptr %l27, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s23)
  br label %bb139
bb124:
  br label %bb125
bb125:
  %t364 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t364, ptr %l248, !tbaa !27
  %t365 = load i64, ptr %l28, !tbaa !24
  %t367 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !27
  %t369 = getelementptr i64, ptr %t368, i64 %t365
  %t370 = load i64, ptr %t369, !tbaa !34
  store i64 %t370, ptr %l29, !tbaa !24
  %t372 = load i64, ptr %l29, !tbaa !24
  %t374 = call i64 @compiler_2ffree_2eokind(i64 %t372)
  store i64 %t374, ptr %l252
  br label %bb126
bb126:
  %t375 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t376 = load i64, ptr %l252, !tbaa !24
  %t378 = icmp eq i64 %t376, %t375
  br i1 %t378, label %bb127, label %bb128
bb127:
  %t380 = load i64, ptr %l29, !tbaa !24
  %t382 = call i64 @compiler_2ffree_2eoval(i64 %t380)
  store i64 %t382, ptr %l256
  br label %bb129
bb128:
  %t383 = load ptr, ptr %lp5
  %t384 = load i64, ptr %l29, !tbaa !24
  %t387 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t383, i64 %t384)
  store i1 %t387, ptr %l269
  br label %bb136
bb129:
  %t388 = load i64, ptr %l256, !tbaa !24
  store i64 %t388, ptr %l30, !tbaa !24
  %t389 = load i64, ptr %l30, !tbaa !24
  store i64 %t389, ptr %l257, !tbaa !24
  %t391 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H12039caf93b9d99069d4e03abd3c3b80(ptr %s0, ptr %l13)
  store i64 %t391, ptr %l259
  br label %bb130
bb130:
  %t392 = load i64, ptr %l257, !tbaa !24
  %t393 = load i64, ptr %l259, !tbaa !24
  %t394 = icmp slt i64 %t392, %t393
  br i1 %t394, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s25
  %t396 = load ptr, ptr %lp5
  store ptr %t396, ptr %l261, !tbaa !29
  %t397 = load i64, ptr %l30, !tbaa !24
  %t400 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %s0, ptr %s0, ptr %l13, i64 %t397)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t400, ptr %l264
  br label %bb133
bb132:
  br label %bb135
bb133:
  %t401 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l264
  %t402 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t401, ptr %t402
  %t403 = load ptr, ptr %l261, !tbaa !29
  %t405 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s0, ptr %t403, ptr %t402)
  store i1 %t405, ptr %l266
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s25)
  br label %bb135
bb135:
  br label %bb137
bb136:
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s23)
  br label %bb138
bb138:
  %t406 = load i64, ptr %l28, !tbaa !24
  %t408 = add i64 %t406, 1
  store i64 %t408, ptr %l28, !tbaa !24
  br label %bb122
bb139:
  %t410 = load i64, ptr %l25, !tbaa !24
  %t411 = load i64, ptr %l27, !tbaa !24
  %t414 = add i64 %t410, %t411
  store i64 %t414, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb140
bb140:
  br label %bb115
bb141:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t416)
  store ptr %t418, ptr %l276
  br label %bb142
bb142:
  %t419 = load ptr, ptr %l4, !tbaa !29
  %t421 = getelementptr %"compiler/free:Free", ptr %t419, i32 0, i32 1
  %t422 = load i64, ptr %l6, !tbaa !24
  %t425 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t421, i64 %t422)
  store ptr %t425, ptr %l280
  br label %bb143
bb143:
  %t426 = load ptr, ptr %l280, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Body", ptr %t426, i32 0, i32 2
  %t429 = load i32, ptr %t428, !tbaa !23
  %t430 = load ptr, ptr %l276, !tbaa !29
  %t432 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t430, i32 %t429)
  store i64 %t432, ptr %l283
  br label %bb144
bb144:
  %t433 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t434 = load i64, ptr %l283, !tbaa !24
  %t436 = icmp eq i64 %t434, %t433
  store i1 %t436, ptr %l31, !tbaa !21
  %t438 = load ptr, ptr %l4, !tbaa !29
  %t440 = getelementptr %"compiler/free:Free", ptr %t438, i32 0, i32 21
  %t441 = load i64, ptr %l6, !tbaa !24
  %t444 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t440, i64 %t441)
  store ptr %t444, ptr %l289
  br label %bb145
bb145:
  %t445 = load ptr, ptr %l289, !tbaa !29
  store ptr %t445, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s29
  %t446 = load ptr, ptr %l32, !tbaa !29
  %t447 = load i64, ptr %l33, !tbaa !24
  %t450 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t446, i64 %t447)
  %t451 = extractvalue { i32, { i64, ptr } } %t450, 1
  %t452 = extractvalue { i32, { i64, ptr } } %t450, 0
  store i32 %t452, ptr %l294
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb148, label %ok.454
ok.454:
  store { i64, ptr } %t451, ptr %l293
  br label %bb147
bb147:
  %t455 = load { i64, ptr }, ptr %l293, !tbaa !27
  store { i64, ptr } %t455, ptr %l290, !tbaa !27
  br label %bb152
bb148:
  %t456 = load i32, ptr %l294, !tbaa !23
  %t457 = ashr i32 %t456, 16
  %t459 = icmp eq i32 %t457, 1
  br i1 %t459, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_302fb708de33b00d_c45900720a6919e9)
  unreachable
bb151:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s29)
  br label %bb167
bb152:
  %t461 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t461, ptr %l34, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t462, 0
  store i64 %t464, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb153
bb153:
  store %olang.scope zeroinitializer, ptr %s30
  %t466 = load i64, ptr %l36, !tbaa !24
  %t467 = load i64, ptr %l35, !tbaa !24
  %t470 = icmp slt i64 %t466, %t467
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb154, label %bb155
bb154:
  call void @__olang_scope_close(ptr %s30)
  br label %bb165
bb155:
  br label %bb156
bb156:
  %t474 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t474, ptr %l303, !tbaa !27
  %t475 = load i64, ptr %l36, !tbaa !24
  %t477 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr i64, ptr %t478, i64 %t475
  %t480 = load i64, ptr %t479, !tbaa !34
  store i64 %t480, ptr %l37, !tbaa !24
  %t482 = load i64, ptr %l37, !tbaa !24
  %t484 = ashr i64 %t482, 32
  store i64 %t484, ptr %l38, !tbaa !24
  %t486 = load i64, ptr %l37, !tbaa !24
  %t487 = shl i64 1, 32
  %t489 = sub i64 %t487, 1
  %t492 = and i64 %t486, %t489
  store i64 %t492, ptr %l39, !tbaa !24
  %t494 = load i64, ptr %l38, !tbaa !24
  store i64 %t494, ptr %l312, !tbaa !24
  %t496 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H12039caf93b9d99069d4e03abd3c3b80(ptr %s0, ptr %l13)
  store i64 %t496, ptr %l314
  br label %bb157
bb157:
  %t497 = load i64, ptr %l312, !tbaa !24
  %t498 = load i64, ptr %l314, !tbaa !24
  %t499 = icmp slt i64 %t497, %t498
  br i1 %t499, label %bb158, label %bb159
bb158:
  store %olang.scope zeroinitializer, ptr %s31
  %t501 = load ptr, ptr %l4, !tbaa !29
  %t502 = load i64, ptr %l6, !tbaa !24
  %t503 = load i64, ptr %l38, !tbaa !24
  %t507 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %t501, i64 %t502, i64 %t503)
  store i1 %t507, ptr %l319
  br label %bb160
bb159:
  br label %bb163
bb160:
  %t508 = load i1, ptr %l319, !tbaa !21
  store i1 %t508, ptr %l40, !tbaa !21
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l320, !tbaa !29
  %t510 = load i64, ptr %l39, !tbaa !24
  store i64 %t510, ptr %l321, !tbaa !24
  %t511 = load ptr, ptr %l1, !tbaa !29
  %t513 = getelementptr %"compiler/typed:Call", ptr %t511, i32 0, i32 1
  %t514 = load { i64, ptr }, ptr %t513, !tbaa !27
  store { i64, ptr } %t514, ptr %l323, !tbaa !27
  %t515 = load i64, ptr %l38, !tbaa !24
  %t517 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t518 = load ptr, ptr %t517, !tbaa !27
  %t519 = getelementptr ptr, ptr %t518, i64 %t515
  %t520 = load ptr, ptr %t519, !tbaa !39
  store ptr %t520, ptr %l325, !tbaa !29
  %t521 = load i64, ptr %l38, !tbaa !24
  %t524 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %s0, ptr %s0, ptr %l13, i64 %t521)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t524, ptr %l328
  br label %bb161
bb161:
  %t525 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l328
  %t526 = call ptr @__olang_scope_alloc_a(ptr %s31, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t525, ptr %t526
  %t527 = load %"compiler/source:Span", ptr %l3
  %t528 = load i1, ptr %l40, !tbaa !21
  %t529 = load i1, ptr %l31, !tbaa !21
  %t530 = load ptr, ptr %l320, !tbaa !29
  %t531 = load i64, ptr %l321, !tbaa !24
  %t532 = load ptr, ptr %l325, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s31, ptr %t530, i64 %t531, ptr %t532, ptr %t526, %"compiler/source:Span" %t527, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, i1 %t528, i1 %t529)
  br label %bb162
bb162:
  call void @__olang_scope_close(ptr %s31)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s30)
  br label %bb164
bb164:
  %t537 = load i64, ptr %l36, !tbaa !24
  %t539 = add i64 %t537, 1
  store i64 %t539, ptr %l36, !tbaa !24
  br label %bb153
bb165:
  %t541 = load i64, ptr %l33, !tbaa !24
  %t542 = load i64, ptr %l35, !tbaa !24
  %t545 = add i64 %t541, %t542
  store i64 %t545, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s29)
  br label %bb166
bb166:
  br label %bb146
bb167:
  %t547 = load ptr, ptr %l4, !tbaa !29
  %t549 = getelementptr %"compiler/free:Free", ptr %t547, i32 0, i32 22
  %t550 = load i64, ptr %l6, !tbaa !24
  %t553 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t549, i64 %t550)
  store ptr %t553, ptr %l341
  br label %bb168
bb168:
  %t554 = load ptr, ptr %l341, !tbaa !29
  store ptr %t554, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s34
  %t555 = load ptr, ptr %l41, !tbaa !29
  %t556 = load i64, ptr %l42, !tbaa !24
  %t559 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t555, i64 %t556)
  %t560 = extractvalue { i32, { i64, ptr } } %t559, 1
  %t561 = extractvalue { i32, { i64, ptr } } %t559, 0
  store i32 %t561, ptr %l346
  %t562 = icmp ne i32 %t561, 0
  br i1 %t562, label %bb171, label %ok.563
ok.563:
  store { i64, ptr } %t560, ptr %l345
  br label %bb170
bb170:
  %t564 = load { i64, ptr }, ptr %l345, !tbaa !27
  store { i64, ptr } %t564, ptr %l342, !tbaa !27
  br label %bb175
bb171:
  %t565 = load i32, ptr %l346, !tbaa !23
  %t566 = ashr i32 %t565, 16
  %t568 = icmp eq i32 %t566, 1
  br i1 %t568, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  call void @__olang_check_failed(ptr @olang_loc_c391f8a5735a8ffa_e072efe91399830e)
  unreachable
bb174:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s34)
  br label %bb189
bb175:
  %t570 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t570, ptr %l43, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t573 = extractvalue { i64, ptr } %t571, 0
  store i64 %t573, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb176
bb176:
  store %olang.scope zeroinitializer, ptr %s35
  %t575 = load i64, ptr %l45, !tbaa !24
  %t576 = load i64, ptr %l44, !tbaa !24
  %t579 = icmp slt i64 %t575, %t576
  %t581 = xor i1 %t579, true
  br i1 %t581, label %bb177, label %bb178
bb177:
  call void @__olang_scope_close(ptr %s35)
  br label %bb187
bb178:
  br label %bb179
bb179:
  %t583 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t583, ptr %l355, !tbaa !27
  %t584 = load i64, ptr %l45, !tbaa !24
  %t586 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = getelementptr i64, ptr %t587, i64 %t584
  %t589 = load i64, ptr %t588, !tbaa !34
  store i64 %t589, ptr %l46, !tbaa !24
  %t591 = load i64, ptr %l46, !tbaa !24
  store i64 %t591, ptr %l358, !tbaa !24
  %t593 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H12039caf93b9d99069d4e03abd3c3b80(ptr %s0, ptr %l13)
  store i64 %t593, ptr %l360
  br label %bb180
bb180:
  %t594 = load i64, ptr %l358, !tbaa !24
  %t595 = load i64, ptr %l360, !tbaa !24
  %t596 = icmp slt i64 %t594, %t595
  br i1 %t596, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s36
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l362, !tbaa !29
  %t599 = load i64, ptr %l46, !tbaa !24
  %t602 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %s0, ptr %s0, ptr %l13, i64 %t599)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t602, ptr %l365
  br label %bb183
bb182:
  br label %bb185
bb183:
  %t603 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l365
  %t604 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t603, ptr %t604
  %t605 = load %"compiler/source:Span", ptr %l3
  %t606 = load ptr, ptr %l362, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s36, ptr %t606, ptr %t604, %"compiler/source:Span" %t605, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d58, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s36)
  br label %bb185
bb185:
  call void @__olang_scope_close(ptr %s35)
  br label %bb186
bb186:
  %t609 = load i64, ptr %l45, !tbaa !24
  %t611 = add i64 %t609, 1
  store i64 %t611, ptr %l45, !tbaa !24
  br label %bb176
bb187:
  %t613 = load i64, ptr %l42, !tbaa !24
  %t614 = load i64, ptr %l44, !tbaa !24
  %t617 = add i64 %t613, %t614
  store i64 %t617, ptr %l42, !tbaa !24
  call void @__olang_scope_close(ptr %s34)
  br label %bb188
bb188:
  br label %bb169
bb189:
  %t619 = load ptr, ptr %l4, !tbaa !29
  %t621 = getelementptr %"compiler/free:Free", ptr %t619, i32 0, i32 25
  %t622 = load i64, ptr %l6, !tbaa !24
  %t625 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t621, i64 %t622)
  store i1 %t625, ptr %l376
  br label %bb190
bb190:
  %t626 = load i1, ptr %l376, !tbaa !21
  br i1 %t626, label %bb191, label %bb192
bb191:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l3
  %t629 = load ptr, ptr %l1, !tbaa !29
  %t630 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i64 %t630)
  br label %bb193
bb192:
  %t635 = load ptr, ptr %l4, !tbaa !29
  %t637 = getelementptr %"compiler/free:Free", ptr %t635, i32 0, i32 24
  %t638 = load i64, ptr %l6, !tbaa !24
  %t641 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t637, i64 %t638)
  store ptr %t641, ptr %l384
  br label %bb194
bb193:
  br label %bb212
bb194:
  %t642 = load ptr, ptr %l384, !tbaa !29
  store ptr %t642, ptr %l47, !tbaa !29
  store i64 0, ptr %l48, !tbaa !24
  br label %bb195
bb195:
  store %olang.scope zeroinitializer, ptr %s41
  %t643 = load ptr, ptr %l47, !tbaa !29
  %t644 = load i64, ptr %l48, !tbaa !24
  %t647 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t643, i64 %t644)
  %t648 = extractvalue { i32, { i64, ptr } } %t647, 1
  %t649 = extractvalue { i32, { i64, ptr } } %t647, 0
  store i32 %t649, ptr %l389
  %t650 = icmp ne i32 %t649, 0
  br i1 %t650, label %bb197, label %ok.651
ok.651:
  store { i64, ptr } %t648, ptr %l388
  br label %bb196
bb196:
  %t652 = load { i64, ptr }, ptr %l388, !tbaa !27
  store { i64, ptr } %t652, ptr %l385, !tbaa !27
  br label %bb201
bb197:
  %t653 = load i32, ptr %l389, !tbaa !23
  %t654 = ashr i32 %t653, 16
  %t656 = icmp eq i32 %t654, 1
  br i1 %t656, label %bb198, label %bb199
bb198:
  br label %bb200
bb199:
  call void @__olang_check_failed(ptr @olang_loc_7230618287f0b47b_1190ffd62bcfb34f)
  unreachable
bb200:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s41)
  br label %bb211
bb201:
  %t658 = load { i64, ptr }, ptr %l385, !tbaa !27
  store { i64, ptr } %t658, ptr %l49, !tbaa !27
  %t659 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t659, 0
  store i64 %t661, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb202
bb202:
  store %olang.scope zeroinitializer, ptr %s42
  %t663 = load i64, ptr %l51, !tbaa !24
  %t664 = load i64, ptr %l50, !tbaa !24
  %t667 = icmp slt i64 %t663, %t664
  %t669 = xor i1 %t667, true
  br i1 %t669, label %bb203, label %bb204
bb203:
  call void @__olang_scope_close(ptr %s42)
  br label %bb209
bb204:
  br label %bb205
bb205:
  %t671 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t671, ptr %l398, !tbaa !27
  %t672 = load i64, ptr %l51, !tbaa !24
  %t674 = getelementptr { i64, ptr }, ptr %l398, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = getelementptr i64, ptr %t675, i64 %t672
  %t677 = load i64, ptr %t676, !tbaa !34
  %t679 = load ptr, ptr %l0, !tbaa !29
  store ptr %t679, ptr %l401, !tbaa !29
  store i64 %t677, ptr %l402, !tbaa !24
  %t681 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t681, ptr %l403, !tbaa !24
  %t682 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t682, ptr %l404
  %t683 = load ptr, ptr %l1, !tbaa !29
  %t685 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t683)
  store %"compiler/source:Span" %t685, ptr %l406
  br label %bb206
bb206:
  %t686 = load i64, ptr %l6, !tbaa !24
  %t687 = load ptr, ptr %l401, !tbaa !29
  %t688 = load i64, ptr %l402, !tbaa !24
  %t689 = load i64, ptr %l403, !tbaa !24
  %t690 = load %"compiler/source:Span", ptr %l404
  %t691 = load %"compiler/source:Span", ptr %l406
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t687, i64 %t688, i64 %t689, %"compiler/source:Span" %t690, %"compiler/source:Span" %t691, i64 %t686)
  br label %bb207
bb207:
  call void @__olang_scope_close(ptr %s42)
  br label %bb208
bb208:
  %t693 = load i64, ptr %l51, !tbaa !24
  %t695 = add i64 %t693, 1
  store i64 %t695, ptr %l51, !tbaa !24
  br label %bb202
bb209:
  %t697 = load i64, ptr %l48, !tbaa !24
  %t698 = load i64, ptr %l50, !tbaa !24
  %t701 = add i64 %t697, %t698
  store i64 %t701, ptr %l48, !tbaa !24
  call void @__olang_scope_close(ptr %s41)
  br label %bb210
bb210:
  br label %bb195
bb211:
  br label %bb212
bb212:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t705 = getelementptr %"compiler/free:walker", ptr %t703, i32 0, i32 2
  %t706 = load i1, ptr %t705, !tbaa !21
  br i1 %t706, label %bb213, label %bb214
bb213:
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t710 = getelementptr %"compiler/free:walker", ptr %t708, i32 0, i32 29
  %t711 = load i64, ptr %t710, !tbaa !24
  %t713 = icmp eq i64 %t711, 0
  store i1 %t713, ptr %l415, !tbaa !21
  br label %bb215
bb214:
  store i1 false, ptr %l415, !tbaa !21
  br label %bb215
bb215:
  %t715 = load i1, ptr %l415, !tbaa !21
  br i1 %t715, label %bb216, label %bb217
bb216:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t717 = load ptr, ptr %l1, !tbaa !29
  %t718 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %t716, ptr %t717, i64 %t718)
  br label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb219
bb219:
  %t722 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s15)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t722, ptr %l422
  br label %bb220
bb220:
  %t723 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l422
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t723, ptr %l53
  %t724 = load ptr, ptr %lp5
  store ptr %t724, ptr %l54, !tbaa !29
  store i64 0, ptr %l55, !tbaa !24
  br label %bb221
bb221:
  store %olang.scope zeroinitializer, ptr %s46
  %t726 = load ptr, ptr %l54, !tbaa !29
  %t727 = load i64, ptr %l55, !tbaa !24
  %t730 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t726, i64 %t727)
  %t731 = extractvalue { i32, { i64, ptr } } %t730, 1
  %t732 = extractvalue { i32, { i64, ptr } } %t730, 0
  store i32 %t732, ptr %l428
  %t733 = icmp ne i32 %t732, 0
  br i1 %t733, label %bb223, label %ok.734
ok.734:
  store { i64, ptr } %t731, ptr %l427
  br label %bb222
bb222:
  %t735 = load { i64, ptr }, ptr %l427, !tbaa !27
  store { i64, ptr } %t735, ptr %l424, !tbaa !27
  br label %bb227
bb223:
  %t736 = load i32, ptr %l428, !tbaa !23
  %t737 = ashr i32 %t736, 16
  %t739 = icmp eq i32 %t737, 1
  br i1 %t739, label %bb224, label %bb225
bb224:
  br label %bb226
bb225:
  call void @__olang_check_failed(ptr @olang_loc_73260fd8b35b9100_131accabfa951114)
  unreachable
bb226:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s46)
  br label %bb240
bb227:
  %t741 = load { i64, ptr }, ptr %l424, !tbaa !27
  store { i64, ptr } %t741, ptr %l56, !tbaa !27
  %t742 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t744 = extractvalue { i64, ptr } %t742, 0
  store i64 %t744, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb228
bb228:
  store %olang.scope zeroinitializer, ptr %s47
  %t746 = load i64, ptr %l58, !tbaa !24
  %t747 = load i64, ptr %l57, !tbaa !24
  %t750 = icmp slt i64 %t746, %t747
  %t752 = xor i1 %t750, true
  br i1 %t752, label %bb229, label %bb230
bb229:
  call void @__olang_scope_close(ptr %s47)
  br label %bb238
bb230:
  br label %bb231
bb231:
  %t754 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t754, ptr %l437, !tbaa !27
  %t755 = load i64, ptr %l58, !tbaa !24
  %t757 = getelementptr { i64, ptr }, ptr %l437, i32 0, i32 1
  %t758 = load ptr, ptr %t757, !tbaa !27
  %t759 = getelementptr i64, ptr %t758, i64 %t755
  %t760 = load i64, ptr %t759, !tbaa !34
  store i64 %t760, ptr %l59, !tbaa !24
  %t762 = load i64, ptr %l59, !tbaa !24
  %t764 = call i64 @compiler_2ffree_2eokind(i64 %t762)
  store i64 %t764, ptr %l441
  br label %bb232
bb232:
  %t765 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t766 = load i64, ptr %l441, !tbaa !24
  %t768 = icmp eq i64 %t766, %t765
  br i1 %t768, label %bb233, label %bb234
bb233:
  %t770 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s15, ptr %l53, i64 %t770)
  br label %bb235
bb234:
  br label %bb236
bb235:
  br label %bb236
bb236:
  call void @__olang_scope_close(ptr %s47)
  br label %bb237
bb237:
  %t773 = load i64, ptr %l58, !tbaa !24
  %t775 = add i64 %t773, 1
  store i64 %t775, ptr %l58, !tbaa !24
  br label %bb228
bb238:
  %t777 = load i64, ptr %l55, !tbaa !24
  %t778 = load i64, ptr %l57, !tbaa !24
  %t781 = add i64 %t777, %t778
  store i64 %t781, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s46)
  br label %bb239
bb239:
  br label %bb221
bb240:
  %t783 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %s15, ptr %t783, ptr %l53)
  br label %bb241
bb241:
  %t786 = load ptr, ptr %lp5
  %t787 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t786
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t787, ptr %rv
  br label %ret
bb242:
  store ptr %l13, ptr %l60, !tbaa !29
  store i64 0, ptr %l61, !tbaa !24
  br label %bb243
bb243:
  store %olang.scope zeroinitializer, ptr %s51
  %t790 = load ptr, ptr %l60, !tbaa !29
  %t791 = load i64, ptr %l61, !tbaa !24
  %t794 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_Hfda32f46ad718b1ec245a2f2facf857a(ptr %s0, ptr %t790, i64 %t791)
  %t795 = extractvalue { i32, { i64, ptr } } %t794, 1
  %t796 = extractvalue { i32, { i64, ptr } } %t794, 0
  store i32 %t796, ptr %l459
  %t797 = icmp ne i32 %t796, 0
  br i1 %t797, label %bb245, label %ok.798
ok.798:
  store { i64, ptr } %t795, ptr %l458
  br label %bb244
bb244:
  %t799 = load { i64, ptr }, ptr %l458, !tbaa !27
  store { i64, ptr } %t799, ptr %l455, !tbaa !27
  br label %bb249
bb245:
  %t800 = load i32, ptr %l459, !tbaa !23
  %t801 = ashr i32 %t800, 16
  %t803 = icmp eq i32 %t801, 1
  br i1 %t803, label %bb246, label %bb247
bb246:
  br label %bb248
bb247:
  call void @__olang_check_failed(ptr @olang_loc_f51d6afa4bf67191_410ad0c8ce8b41c5)
  unreachable
bb248:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s51)
  br label %bb262
bb249:
  %t805 = load { i64, ptr }, ptr %l455, !tbaa !27
  store { i64, ptr } %t805, ptr %l62, !tbaa !27
  %t806 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t806, 0
  store i64 %t808, ptr %l63, !tbaa !24
  store i64 0, ptr %l64, !tbaa !24
  br label %bb250
bb250:
  store %olang.scope zeroinitializer, ptr %s52
  %t810 = load i64, ptr %l64, !tbaa !24
  %t811 = load i64, ptr %l63, !tbaa !24
  %t814 = icmp slt i64 %t810, %t811
  %t816 = xor i1 %t814, true
  br i1 %t816, label %bb251, label %bb252
bb251:
  call void @__olang_scope_close(ptr %s52)
  br label %bb260
bb252:
  br label %bb253
bb253:
  %t818 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t818, ptr %l468, !tbaa !27
  %t819 = load i64, ptr %l64, !tbaa !24
  %t821 = getelementptr { i64, ptr }, ptr %l468, i32 0, i32 1
  %t822 = load ptr, ptr %t821, !tbaa !27
  %t823 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t822, i64 %t819
  %t824 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t823
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t824, ptr %l65
  %t826 = load ptr, ptr %lp5
  %t829 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s52, ptr %t826, ptr %l65)
  store i1 %t829, ptr %l473
  br label %bb254
bb254:
  %t830 = load i1, ptr %l8, !tbaa !21
  %t832 = xor i1 %t830, true
  br i1 %t832, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s53
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s52, ptr %s53, ptr %t834, ptr %l65, %"compiler/source:Span" %t835, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d59, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb257
bb256:
  br label %bb258
bb257:
  call void @__olang_scope_close(ptr %s53)
  br label %bb258
bb258:
  call void @__olang_scope_close(ptr %s52)
  br label %bb259
bb259:
  %t839 = load i64, ptr %l64, !tbaa !24
  %t841 = add i64 %t839, 1
  store i64 %t841, ptr %l64, !tbaa !24
  br label %bb250
bb260:
  %t843 = load i64, ptr %l61, !tbaa !24
  %t844 = load i64, ptr %l63, !tbaa !24
  %t847 = add i64 %t843, %t844
  store i64 %t847, ptr %l61, !tbaa !24
  call void @__olang_scope_close(ptr %s51)
  br label %bb261
bb261:
  br label %bb243
bb262:
  %t849 = load ptr, ptr %lp5
  store ptr %t849, ptr %l484, !tbaa !29
  %t850 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t852 = call i64 @compiler_2ffree_2eorig(i64 %t850, i64 0)
  store i64 %t852, ptr %l486
  br label %bb263
bb263:
  %t853 = load ptr, ptr %l484, !tbaa !29
  %t854 = load i64, ptr %l486, !tbaa !24
  %t855 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t853, i64 %t854)
  store i1 %t855, ptr %l487
  br label %bb264
bb264:
  %t856 = load i1, ptr %l9, !tbaa !21
  br i1 %t856, label %bb265, label %bb266
bb265:
  %t858 = load ptr, ptr %l1, !tbaa !29
  %t860 = getelementptr %"compiler/typed:Call", ptr %t858, i32 0, i32 1
  %t861 = load { i64, ptr }, ptr %t860, !tbaa !27
  store { i64, ptr } %t861, ptr %l66, !tbaa !27
  store i64 0, ptr %l67, !tbaa !24
  %t863 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t865 = extractvalue { i64, ptr } %t863, 0
  store i64 %t865, ptr %l68, !tbaa !24
  br label %bb267
bb266:
  %t867 = load i1, ptr %l8, !tbaa !21
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb314, label %bb315
bb267:
  store %olang.scope zeroinitializer, ptr %s57
  %t871 = load i64, ptr %l67, !tbaa !24
  %t872 = load i64, ptr %l68, !tbaa !24
  %t875 = icmp slt i64 %t871, %t872
  %t877 = xor i1 %t875, true
  br i1 %t877, label %bb268, label %bb269
bb268:
  call void @__olang_scope_close(ptr %s57)
  br label %bb280
bb269:
  br label %bb270
bb270:
  %t879 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t879, ptr %l497, !tbaa !27
  %t880 = load i64, ptr %l67, !tbaa !24
  %t882 = getelementptr { i64, ptr }, ptr %l497, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr ptr, ptr %t883, i64 %t880
  %t885 = load ptr, ptr %t884, !tbaa !39
  store ptr %t885, ptr %l69, !tbaa !29
  %t887 = load ptr, ptr %l0, !tbaa !29
  %t889 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t887)
  store ptr %t889, ptr %l501
  br label %bb271
bb271:
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t890)
  store ptr %t892, ptr %l503
  br label %bb272
bb272:
  %t893 = load ptr, ptr %l69, !tbaa !29
  %t895 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t893)
  store i32 %t895, ptr %l505
  br label %bb273
bb273:
  %t896 = load ptr, ptr %l503, !tbaa !29
  %t897 = load i32, ptr %l505, !tbaa !23
  %t898 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t896, i32 %t897)
  store i32 %t898, ptr %l506
  br label %bb274
bb274:
  %t899 = load ptr, ptr %l501, !tbaa !29
  %t900 = load i32, ptr %l506, !tbaa !23
  %t901 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t899, i32 %t900)
  store i32 %t901, ptr %l507
  br label %bb275
bb275:
  %t902 = load i32, ptr %l507
  %t904 = trunc i64 21 to i32
  %t905 = icmp eq i32 %t902, %t904
  br i1 %t905, label %bb276, label %bb277
bb276:
  %t907 = load ptr, ptr %l4, !tbaa !29
  %t909 = getelementptr %"compiler/free:Free", ptr %t907, i32 0, i32 31
  store i1 true, ptr %t909, !tbaa !21
  br label %bb278
bb277:
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s57)
  br label %bb279
bb279:
  %t910 = load i64, ptr %l67, !tbaa !24
  %t912 = add i64 %t910, 1
  store i64 %t912, ptr %l67, !tbaa !24
  br label %bb267
bb280:
  store i1 false, ptr %l70, !tbaa !21
  %t914 = load ptr, ptr %l4, !tbaa !29
  %t916 = getelementptr %"compiler/free:Free", ptr %t914, i32 0, i32 29
  store ptr %t916, ptr %l71, !tbaa !29
  store i64 0, ptr %l72, !tbaa !24
  br label %bb281
bb281:
  store %olang.scope zeroinitializer, ptr %s61
  %t918 = load ptr, ptr %l71, !tbaa !29
  %t919 = load i64, ptr %l72, !tbaa !24
  %t922 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t918, i64 %t919)
  %t923 = extractvalue { i32, { i64, ptr } } %t922, 1
  %t924 = extractvalue { i32, { i64, ptr } } %t922, 0
  store i32 %t924, ptr %l519
  %t925 = icmp ne i32 %t924, 0
  br i1 %t925, label %bb283, label %ok.926
ok.926:
  store { i64, ptr } %t923, ptr %l518
  br label %bb282
bb282:
  %t927 = load { i64, ptr }, ptr %l518, !tbaa !27
  store { i64, ptr } %t927, ptr %l515, !tbaa !27
  br label %bb287
bb283:
  %t928 = load i32, ptr %l519, !tbaa !23
  %t929 = ashr i32 %t928, 16
  %t931 = icmp eq i32 %t929, 1
  br i1 %t931, label %bb284, label %bb285
bb284:
  br label %bb286
bb285:
  call void @__olang_check_failed(ptr @olang_loc_29274a8a17644d3e_88c903589875bd0a)
  unreachable
bb286:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s61)
  br label %bb309
bb287:
  %t933 = load { i64, ptr }, ptr %l515, !tbaa !27
  store { i64, ptr } %t933, ptr %l73, !tbaa !27
  %t934 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t936 = extractvalue { i64, ptr } %t934, 0
  store i64 %t936, ptr %l74, !tbaa !24
  store i64 0, ptr %l75, !tbaa !24
  br label %bb288
bb288:
  store %olang.scope zeroinitializer, ptr %s62
  %t938 = load i64, ptr %l75, !tbaa !24
  %t939 = load i64, ptr %l74, !tbaa !24
  %t942 = icmp slt i64 %t938, %t939
  %t944 = xor i1 %t942, true
  br i1 %t944, label %bb289, label %bb290
bb289:
  call void @__olang_scope_close(ptr %s62)
  br label %bb307
bb290:
  br label %bb291
bb291:
  %t946 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t946, ptr %l528, !tbaa !27
  %t947 = load i64, ptr %l75, !tbaa !24
  %t949 = getelementptr { i64, ptr }, ptr %l528, i32 0, i32 1
  %t950 = load ptr, ptr %t949, !tbaa !27
  %t951 = getelementptr i64, ptr %t950, i64 %t947
  %t952 = load i64, ptr %t951, !tbaa !34
  store i64 %t952, ptr %l76, !tbaa !24
  %t954 = load ptr, ptr %l0, !tbaa !29
  %t956 = getelementptr %"compiler/free:walker", ptr %t954, i32 0, i32 2
  %t957 = load i1, ptr %t956, !tbaa !21
  %t959 = xor i1 %t957, true
  br i1 %t959, label %bb292, label %bb293
bb292:
  %t961 = load ptr, ptr %l4, !tbaa !29
  %t963 = getelementptr %"compiler/free:Free", ptr %t961, i32 0, i32 48
  %t964 = load i64, ptr %l76, !tbaa !24
  %t967 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t963, i64 %t964)
  store ptr %t967, ptr %l537
  br label %bb294
bb293:
  br label %bb296
bb294:
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t970 = getelementptr %"compiler/free:walker", ptr %t968, i32 0, i32 1
  %t971 = load i64, ptr %t970, !tbaa !24
  %t972 = load ptr, ptr %l537, !tbaa !29
  %t974 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t972, i64 %t971)
  store i1 %t974, ptr %l540
  br label %bb295
bb295:
  br label %bb296
bb296:
  %t975 = load ptr, ptr %l4, !tbaa !29
  %t977 = getelementptr %"compiler/free:Free", ptr %t975, i32 0, i32 24
  %t978 = load i64, ptr %l76, !tbaa !24
  %t981 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t977, i64 %t978)
  store ptr %t981, ptr %l544
  br label %bb297
bb297:
  %t982 = load ptr, ptr %l544, !tbaa !29
  %t983 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t982)
  store i64 %t983, ptr %l545
  br label %bb298
bb298:
  %t984 = load i64, ptr %l545, !tbaa !24
  %t985 = icmp sgt i64 %t984, 0
  br i1 %t985, label %bb299, label %bb300
bb299:
  store i1 true, ptr %l547, !tbaa !21
  br label %bb302
bb300:
  %t987 = load ptr, ptr %l4, !tbaa !29
  %t989 = getelementptr %"compiler/free:Free", ptr %t987, i32 0, i32 25
  %t990 = load i64, ptr %l76, !tbaa !24
  %t993 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t989, i64 %t990)
  store i1 %t993, ptr %l551
  br label %bb301
bb301:
  %t994 = load i1, ptr %l551, !tbaa !21
  store i1 %t994, ptr %l547, !tbaa !21
  br label %bb302
bb302:
  %t995 = load i1, ptr %l547, !tbaa !21
  br i1 %t995, label %bb303, label %bb304
bb303:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb305
bb304:
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s62)
  br label %bb306
bb306:
  %t996 = load i64, ptr %l75, !tbaa !24
  %t998 = add i64 %t996, 1
  store i64 %t998, ptr %l75, !tbaa !24
  br label %bb288
bb307:
  %t1000 = load i64, ptr %l72, !tbaa !24
  %t1001 = load i64, ptr %l74, !tbaa !24
  %t1004 = add i64 %t1000, %t1001
  store i64 %t1004, ptr %l72, !tbaa !24
  call void @__olang_scope_close(ptr %s61)
  br label %bb308
bb308:
  br label %bb281
bb309:
  %t1006 = load i1, ptr %l70, !tbaa !21
  br i1 %t1006, label %bb310, label %bb311
bb310:
  %t1008 = load ptr, ptr %l0, !tbaa !29
  %t1009 = load %"compiler/source:Span", ptr %l3
  %t1010 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t1008, %"compiler/source:Span" %t1009, ptr %t1010, i64 -1)
  br label %bb312
bb311:
  br label %bb313
bb312:
  br label %bb313
bb313:
  br label %bb318
bb314:
  %t1014 = load ptr, ptr %l0, !tbaa !29
  %t1015 = load %"compiler/source:Span", ptr %l3
  %t1016 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t1014, %"compiler/source:Span" %t1015, ptr %t1016, i64 -1)
  br label %bb316
bb315:
  br label %bb317
bb316:
  br label %bb317
bb317:
  br label %bb318
bb318:
  %t1020 = load ptr, ptr %lp5
  %t1021 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1020
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1021, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i32
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l47 = alloca { i64, ptr }
  %l53 = alloca i64
  %l61 = alloca i64
  %l63 = alloca i1
  %l67 = alloca i64
  %l70 = alloca i1
  %l84 = alloca i64
  %l88 = alloca i64
  %l92 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i32
  %l98 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i32
  %l106 = alloca i1
  %l109 = alloca i1
  %l111 = alloca ptr
  %l114 = alloca i32
  %l116 = alloca ptr
  %l120 = alloca %"compiler/typed:Local"
  %l122 = alloca i1
  %l123 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i32
  %l131 = alloca i64
  %l135 = alloca i64
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i32
  %l152 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca i64
  %l163 = alloca i64
  %l165 = alloca i1
  %l173 = alloca i64
  %l175 = alloca i1
  %l192 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 53
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l30
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store i64 %t12, ptr %l29
  br label %bb3
bb2:
  br label %bb38
bb3:
  %t16 = load i64, ptr %l29, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  br label %bb6
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 11
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l25, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l4, !tbaa !29
  store ptr %t23, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load ptr, ptr %l6, !tbaa !29
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t25, i64 %t26)
  %t30 = extractvalue { i32, { i64, ptr } } %t29, 1
  %t31 = extractvalue { i32, { i64, ptr } } %t29, 0
  store i32 %t31, ptr %l38
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33
ok.33:
  store { i64, ptr } %t30, ptr %l37
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t34, ptr %l34, !tbaa !27
  br label %bb13
bb9:
  %t35 = load i32, ptr %l38, !tbaa !23
  %t36 = ashr i32 %t35, 16
  %t38 = icmp eq i32 %t36, 1
  br i1 %t38, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9770790e28a8e96_84f72a57a788a45a)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb13:
  %t40 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t40, ptr %l8, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load i64, ptr %l10, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb16:
  br label %bb17
bb17:
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t53, ptr %l47, !tbaa !27
  %t54 = load i64, ptr %l10, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i64, ptr %t57, i64 %t54
  %t59 = load i64, ptr %t58, !tbaa !34
  store i64 %t59, ptr %l11, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:walker", ptr %t61, i32 0, i32 25
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l53
  br label %bb18
bb18:
  %t68 = load i64, ptr %l53, !tbaa !24
  store i64 %t68, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb19, label %bb20
bb19:
  %t75 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t75, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 51
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t79, i64 %t80)
  store i64 %t83, ptr %l61
  br label %bb22
bb22:
  %t84 = load i64, ptr %l61, !tbaa !24
  %t85 = icmp sge i64 %t84, 0
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:walker", ptr %t87, i32 0, i32 51
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l67
  br label %bb25
bb24:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb26
bb25:
  %t94 = load i64, ptr %l3, !tbaa !24
  %t95 = load i64, ptr %l67, !tbaa !24
  %t97 = icmp ne i64 %t95, %t94
  store i1 %t97, ptr %l63, !tbaa !21
  br label %bb26
bb26:
  %t99 = load i1, ptr %l63, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  store i1 %t104, ptr %l70, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb29
bb29:
  %t106 = load i1, ptr %l70, !tbaa !21
  br i1 %t106, label %bb30, label %bb31
bb30:
  %t107 = load i64, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t107, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t109 = load i64, ptr %l10, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l10, !tbaa !24
  br label %bb14
bb34:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t113, %t114
  store i64 %t117, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  br label %bb7
bb36:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i64, ptr %l1, !tbaa !24
  %t121 = load i64, ptr %l3, !tbaa !24
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t127 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %t119, i64 %t120, i64 %t121, ptr %t122)
  store i64 %t127, ptr %l84
  br label %bb37
bb37:
  %t128 = load i64, ptr %l84, !tbaa !24
  store i64 %t128, ptr %rv
  br label %ret
bb38:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 20
  %t132 = load i64, ptr %l1, !tbaa !24
  %t135 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l88
  br label %bb39
bb39:
  %t136 = load i64, ptr %l2, !tbaa !24
  %t137 = load i64, ptr %l88, !tbaa !24
  %t139 = icmp sgt i64 %t137, %t136
  br i1 %t139, label %bb40, label %bb41
bb40:
  store i64 -1, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/free:walker", ptr %t142, i32 0, i32 54
  %t145 = load i64, ptr %l2, !tbaa !24
  %t148 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t144, i64 %t145)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l97
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb44, label %ok.152
ok.152:
  store i64 %t149, ptr %l96
  br label %bb43
bb43:
  %t153 = load i64, ptr %l96, !tbaa !24
  store i64 %t153, ptr %l92, !tbaa !24
  br label %bb46
bb44:
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb46
bb46:
  %t154 = load i64, ptr %l92, !tbaa !24
  store i64 %t154, ptr %l13, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/free:walker", ptr %t155, i32 0, i32 55
  %t158 = load i64, ptr %l2, !tbaa !24
  %t161 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t157, i64 %t158)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l103
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb48, label %ok.165
ok.165:
  store i64 %t162, ptr %l102
  br label %bb47
bb47:
  %t166 = load i64, ptr %l102, !tbaa !24
  store i64 %t166, ptr %l98, !tbaa !24
  br label %bb50
bb48:
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l98, !tbaa !24
  br label %bb50
bb50:
  %t167 = load i64, ptr %l98, !tbaa !24
  store i64 %t167, ptr %l14, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t170 = icmp slt i64 %t168, 0
  br i1 %t170, label %bb51, label %bb52
bb51:
  %t172 = load i64, ptr %l14, !tbaa !24
  %t174 = icmp sge i64 %t172, 0
  store i1 %t174, ptr %l106, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb53
bb53:
  %t176 = load i1, ptr %l106, !tbaa !21
  br i1 %t176, label %bb54, label %bb55
bb54:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t177)
  store ptr %t179, ptr %l111
  br label %bb56
bb55:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb60
bb56:
  %t180 = load i64, ptr %l14, !tbaa !24
  %t182 = trunc i64 %t180 to i32
  store i32 %t182, ptr %l114, !tbaa !23
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t184)
  store ptr %t186, ptr %l116
  br label %bb57
bb57:
  %t187 = load ptr, ptr %l116, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 7
  %t190 = load i64, ptr %l1, !tbaa !24
  %t193 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t189, i64 %t190)
  store %"compiler/typed:Local" %t193, ptr %l120
  br label %bb58
bb58:
  %t194 = getelementptr %"compiler/typed:Local", ptr %l120, i32 0, i32 3
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = load i32, ptr %l114, !tbaa !23
  %t199 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t196, i32 %t197, i32 %t195)
  store i1 %t199, ptr %l122
  br label %bb59
bb59:
  %t200 = load i1, ptr %l122, !tbaa !21
  store i1 %t200, ptr %l109, !tbaa !21
  br label %bb60
bb60:
  %t201 = load i1, ptr %l109, !tbaa !21
  br i1 %t201, label %bb61, label %bb62
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/free:walker", ptr %t202, i32 0, i32 56
  %t205 = load i64, ptr %l2, !tbaa !24
  %t208 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t204, i64 %t205)
  %t209 = extractvalue { i32, i64 } %t208, 1
  %t210 = extractvalue { i32, i64 } %t208, 0
  store i32 %t210, ptr %l128
  %t211 = icmp ne i32 %t210, 0
  br i1 %t211, label %bb64, label %ok.212
ok.212:
  store i64 %t209, ptr %l127
  br label %bb63
bb62:
  br label %bb67
bb63:
  %t213 = load i64, ptr %l127, !tbaa !24
  store i64 %t213, ptr %l123, !tbaa !24
  br label %bb66
bb64:
  br label %bb65
bb65:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l123, !tbaa !24
  br label %bb66
bb66:
  %t214 = load i64, ptr %l123, !tbaa !24
  store i64 %t214, ptr %l13, !tbaa !24
  br label %bb67
bb67:
  %t215 = load i64, ptr %l13, !tbaa !24
  %t217 = icmp sge i64 %t215, 0
  br i1 %t217, label %bb68, label %bb69
bb68:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/free:walker", ptr %t219, i32 0, i32 13
  %t222 = load i64, ptr %l13, !tbaa !24
  %t225 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l135
  br label %bb70
bb69:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 11
  %t229 = load i64, ptr %t228, !tbaa !24
  store i64 %t229, ptr %l131, !tbaa !24
  br label %bb71
bb70:
  %t231 = load i64, ptr %l135, !tbaa !24
  store i64 %t231, ptr %l131, !tbaa !24
  br label %bb71
bb71:
  %t232 = load i64, ptr %l131, !tbaa !24
  store i64 %t232, ptr %l15, !tbaa !24
  %t233 = load ptr, ptr %l4, !tbaa !29
  store ptr %t233, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s11
  %t235 = load ptr, ptr %l16, !tbaa !29
  %t236 = load i64, ptr %l17, !tbaa !24
  %t239 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t235, i64 %t236)
  %t240 = extractvalue { i32, { i64, ptr } } %t239, 1
  %t241 = extractvalue { i32, { i64, ptr } } %t239, 0
  store i32 %t241, ptr %l143
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb74, label %ok.243
ok.243:
  store { i64, ptr } %t240, ptr %l142
  br label %bb73
bb73:
  %t244 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t244, ptr %l139, !tbaa !27
  br label %bb78
bb74:
  %t245 = load i32, ptr %l143, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  br i1 %t248, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_1928ae2b21411db7_7e7662c13839435b)
  unreachable
bb77:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb101
bb78:
  %t250 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t250, ptr %l18, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t255 = load i64, ptr %l20, !tbaa !24
  %t256 = load i64, ptr %l19, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s12)
  br label %bb99
bb81:
  br label %bb82
bb82:
  %t263 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t263, ptr %l152, !tbaa !27
  %t264 = load i64, ptr %l20, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i64, ptr %t267, i64 %t264
  %t269 = load i64, ptr %t268, !tbaa !34
  store i64 %t269, ptr %l21, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/free:walker", ptr %t271, i32 0, i32 25
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l158
  br label %bb83
bb83:
  %t278 = load i64, ptr %l158, !tbaa !24
  store i64 %t278, ptr %l22, !tbaa !24
  %t279 = load i64, ptr %l22, !tbaa !24
  store i64 %t279, ptr %l159, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:walker", ptr %t280, i32 0, i32 13
  %t283 = load i64, ptr %l2, !tbaa !24
  %t286 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t282, i64 %t283)
  store i64 %t286, ptr %l163
  br label %bb84
bb84:
  %t287 = load i64, ptr %l159, !tbaa !24
  %t288 = load i64, ptr %l163, !tbaa !24
  %t289 = icmp sgt i64 %t287, %t288
  br i1 %t289, label %bb85, label %bb86
bb85:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t292 = load i64, ptr %l15, !tbaa !24
  %t295 = icmp sle i64 %t291, %t292
  store i1 %t295, ptr %l165, !tbaa !21
  br label %bb87
bb86:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb87
bb87:
  %t297 = load i1, ptr %l165, !tbaa !21
  br i1 %t297, label %bb88, label %bb89
bb88:
  %t298 = load i64, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  store i64 %t298, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:walker", ptr %t300, i32 0, i32 51
  %t303 = load i64, ptr %l21, !tbaa !24
  %t306 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t302, i64 %t303)
  store i64 %t306, ptr %l173
  br label %bb91
bb91:
  %t307 = load i64, ptr %l173, !tbaa !24
  %t308 = icmp sge i64 %t307, 0
  br i1 %t308, label %bb92, label %bb93
bb92:
  %t310 = load i64, ptr %l22, !tbaa !24
  %t311 = load i64, ptr %l2, !tbaa !24
  %t314 = icmp slt i64 %t310, %t311
  store i1 %t314, ptr %l175, !tbaa !21
  br label %bb94
bb93:
  store i1 false, ptr %l175, !tbaa !21
  br label %bb94
bb94:
  %t316 = load i1, ptr %l175, !tbaa !21
  br i1 %t316, label %bb95, label %bb96
bb95:
  %t317 = load i64, ptr %l21, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  store i64 %t317, ptr %rv
  br label %ret
bb96:
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  br label %bb98
bb98:
  %t319 = load i64, ptr %l20, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l20, !tbaa !24
  br label %bb79
bb99:
  %t323 = load i64, ptr %l17, !tbaa !24
  %t324 = load i64, ptr %l19, !tbaa !24
  %t327 = add i64 %t323, %t324
  store i64 %t327, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb100
bb100:
  br label %bb72
bb101:
  %t329 = load i64, ptr %l13, !tbaa !24
  %t331 = icmp sge i64 %t329, 0
  br i1 %t331, label %bb102, label %bb103
bb102:
  store i64 -1, ptr %rv
  br label %ret
bb103:
  br label %bb104
bb104:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l1, !tbaa !24
  %t336 = load i64, ptr %l2, !tbaa !24
  %t337 = load ptr, ptr %l4, !tbaa !29
  %t342 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %t334, i64 %t335, i64 %t336, ptr %t337)
  store i64 %t342, ptr %l192
  br label %bb105
bb105:
  %t343 = load i64, ptr %l192, !tbaa !24
  store i64 %t343, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, i64, i64, { i64, ptr } }
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca { i64, i64, i64, { i64, ptr } }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l63 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i64, ptr %l16, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l19
  br label %bb5
bb5:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l5
  store ptr %l5, ptr %l20, !tbaa !29
  %t13 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @compiler_2ffree_2eorig(i64 %t13, i64 %t14)
  store i64 %t17, ptr %l23
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l20, !tbaa !29
  %t19 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t18, i64 %t19)
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s0, ptr %t20, i64 %t21, ptr %l5)
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:walker", ptr %t25, i32 0, i32 2
  %t28 = load i1, ptr %t27, !tbaa !21
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 29
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  store i1 %t37, ptr %l30, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l30, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l6, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l37
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l37, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 3
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  %t55 = call ptr @compiler_2ffree_2eunwrapped(ptr %v1, ptr %a2)
  store ptr %t55, ptr %l41
  br label %bb16
bb16:
  %t56 = load ptr, ptr %l41, !tbaa !29
  store ptr %t56, ptr %l8, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l8, !tbaa !29
  %t61 = call { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %s0, ptr %t57, ptr %t58)
  store { i64, i64, i64, { i64, ptr } } %t61, ptr %l44
  br label %bb17
bb17:
  %t62 = load { i64, i64, i64, { i64, ptr } }, ptr %l44
  store { i64, i64, i64, { i64, ptr } } %t62, ptr %l9
  %t63 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l10, !tbaa !24
  %t66 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t67 = load i64, ptr %t66, !tbaa !24
  %t69 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l9, i32 0, i32 3
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l48, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l49, !tbaa !24
  %t76 = load i64, ptr %l49, !tbaa !24
  %t77 = mul i64 %t76, 1
  %t78 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  store { i64, ptr } %t80, ptr %l50, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = load i64, ptr %l49, !tbaa !24
  %t86 = mul i64 %t85, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t82, ptr %t84, i64 %t86, i1 false)
  %t87 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t87, ptr %l13, !tbaa !27
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 34
  store ptr %t90, ptr %l52, !tbaa !29
  %t91 = load i64, ptr %l4, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load %"compiler/source:Span", ptr %l3
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = load ptr, ptr %l8, !tbaa !29
  %t111 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t91, i64 %t95, i64 %t96, %"compiler/source:Span" %t97, i64 %t98, i64 %t67, i64 %t70, ptr %t101, ptr null)
  store %"compiler/free:store" %t111, ptr %l63
  br label %bb18
bb18:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load %"compiler/free:store", ptr %l63
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t112, %"compiler/free:store" %t113)
  br label %bb19
bb19:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t118 = icmp eq i64 %t114, %t115
  br i1 %t118, label %bb20, label %bb21
bb20:
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t121 = load i64, ptr %l4, !tbaa !24
  %t122 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t123 = load i64, ptr %l7, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l3
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t120, i64 %t121, i64 %t122, i64 %t123, %"compiler/source:Span" %t124, { i64, ptr } %t125)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca i1
  %l43 = alloca i1
  %l45 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i1
  %l62 = alloca { i64, ptr }
  %l64 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l79 = alloca i32
  %l85 = alloca i1
  %l88 = alloca i1
  %l90 = alloca i64
  %l93 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca i64
  %l100 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca i1
  %l109 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca i64
  %l118 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca %"compiler/source:Span"
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  store ptr %a1, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t9 = load i64, ptr %l9, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l22
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l21
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t17, ptr %l18, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l22, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_5ca0c94719aba3bb_f8486f1b87c86b37)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb7:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t23, ptr %l10, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = load i64, ptr %l11, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb72
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t36, ptr %l31, !tbaa !27
  %t37 = load i64, ptr %l12, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i64, ptr %t40, i64 %t37
  %t42 = load i64, ptr %t41, !tbaa !34
  store i64 %t42, ptr %l13, !tbaa !24
  %t44 = load i64, ptr %l13, !tbaa !24
  %t46 = call i64 @compiler_2ffree_2eokind(i64 %t44)
  store i64 %t46, ptr %l35
  br label %bb12
bb12:
  %t47 = load i64, ptr %l35, !tbaa !24
  store i64 %t47, ptr %l14, !tbaa !24
  %t48 = load i64, ptr %l14, !tbaa !24
  %t49 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t52 = icmp eq i64 %t48, %t49
  br i1 %t52, label %bb13, label %bb14
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/free:walker", ptr %t54, i32 0, i32 2
  %t57 = load i1, ptr %t56, !tbaa !21
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l39, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l39, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load i64, ptr %l13, !tbaa !24
  %t64 = call i64 @compiler_2ffree_2eoval(i64 %t62)
  store i64 %t64, ptr %l45
  br label %bb18
bb17:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l45, !tbaa !24
  %t68 = icmp ne i64 %t66, %t65
  store i1 %t68, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l43, !tbaa !21
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 22
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 1
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t73, i64 %t77)
  store ptr %t80, ptr %l52
  br label %bb22
bb21:
  br label %bb41
bb22:
  %t81 = load i64, ptr %l13, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2eoval(i64 %t81)
  store i64 %t83, ptr %l54
  br label %bb23
bb23:
  %t84 = load ptr, ptr %l52, !tbaa !29
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t84, i64 %t85)
  store i1 %t86, ptr %l55
  br label %bb24
bb24:
  %t87 = load i1, ptr %l55, !tbaa !21
  br i1 %t87, label %bb25, label %bb26
bb25:
  %t88 = load ptr, ptr %l7, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 30
  store i1 true, ptr %t90, !tbaa !21
  %t91 = load ptr, ptr %l7, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 68
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb26:
  br label %bb40
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t96 = load ptr, ptr %l7, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 1
  %t100 = load i64, ptr %t99, !tbaa !24
  %t103 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s6, ptr %t96, i64 %t100)
  store { i64, ptr } %t103, ptr %l62
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t104 = load i64, ptr %l13, !tbaa !24
  %t106 = call i64 @compiler_2ffree_2eoval(i64 %t104)
  store i64 %t106, ptr %l64
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr %"compiler/free:Free", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 4
  %t116 = load ptr, ptr %t115, !tbaa !29
  store ptr %t116, ptr %l68, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t117)
  store ptr %t119, ptr %l70
  br label %bb31
bb31:
  %t120 = load ptr, ptr %l70, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Body", ptr %t120, i32 0, i32 3
  %t123 = load i64, ptr %t122, !tbaa !24
  %t124 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s6, ptr %t128, i64 %t123, i64 %t127)
  store { i64, ptr } %t131, ptr %l75
  br label %bb32
bb32:
  %t132 = load i64, ptr %l5, !tbaa !24
  %t133 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t135 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = add i64 %t134, %t137
  %t139 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load i64, ptr %l64, !tbaa !24
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t141, %t143
  %t145 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t146 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t147 = add i64 %t144, %t146
  %t148 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t156 = call i64 @__olang_fmt_i64(ptr null, i64 %t132)
  %t157 = add i64 %t154, %t156
  %t158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t133, i64 %t134)
  %t162 = getelementptr i8, ptr %t161, i64 %t134
  call void @olang_textcopy(ptr %t162, ptr %t136, i64 %t137)
  %t163 = getelementptr i8, ptr %t162, i64 %t137
  call void @olang_textcopy(ptr %t163, ptr %t139, i64 %t140)
  %t164 = getelementptr i8, ptr %t163, i64 %t140
  %t165 = call i64 @__olang_fmt_i64(ptr %t164, i64 %t142)
  %t166 = getelementptr i8, ptr %t164, i64 %t143
  call void @olang_textcopy(ptr %t166, ptr %t145, i64 %t146)
  %t167 = getelementptr i8, ptr %t166, i64 %t146
  call void @olang_textcopy(ptr %t167, ptr %t149, i64 %t150)
  %t168 = getelementptr i8, ptr %t167, i64 %t150
  call void @olang_textcopy(ptr %t168, ptr %t152, i64 %t153)
  %t169 = getelementptr i8, ptr %t168, i64 %t153
  %t170 = call i64 @__olang_fmt_i64(ptr %t169, i64 %t132)
  %t171 = getelementptr i8, ptr %t169, i64 %t156
  call void @olang_textcopy(ptr %t171, ptr %t158, i64 %t159)
  %t172 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t161, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t182 = call i32 @std_2fio_2ePrintErr(ptr %s6, { i64, ptr } %t180)
  store i32 %t182, ptr %l79
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb34, label %ok.184
ok.184:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t185 = load i32, ptr %l79, !tbaa !23
  %t186 = ashr i32 %t185, 16
  %t188 = icmp eq i32 %t186, 1
  br i1 %t188, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_1d32823effd2173a_e896c8814911dc16)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t190 = load i64, ptr %l14, !tbaa !24
  %t191 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t194 = icmp eq i64 %t190, %t191
  br i1 %t194, label %bb42, label %bb43
bb42:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:walker", ptr %t196, i32 0, i32 2
  %t199 = load i1, ptr %t198, !tbaa !21
  store i1 %t199, ptr %l85, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t201 = load i1, ptr %l85, !tbaa !21
  br i1 %t201, label %bb45, label %bb46
bb45:
  %t202 = load i64, ptr %l13, !tbaa !24
  %t204 = call i64 @compiler_2ffree_2eoval(i64 %t202)
  store i64 %t204, ptr %l90
  br label %bb47
bb46:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb48
bb47:
  %t206 = load i64, ptr %l90, !tbaa !24
  %t208 = icmp ne i64 %t206, %a6
  store i1 %t208, ptr %l88, !tbaa !21
  br label %bb48
bb48:
  %t210 = load i1, ptr %l88, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  %t211 = load ptr, ptr %l7, !tbaa !29
  store ptr %t211, ptr %l93, !tbaa !29
  %t212 = load i64, ptr %l13, !tbaa !24
  %t214 = call i64 @compiler_2ffree_2eoval(i64 %t212)
  store i64 %t214, ptr %l95
  br label %bb51
bb50:
  br label %bb70
bb51:
  %t215 = load ptr, ptr %l93, !tbaa !29
  %t216 = load i64, ptr %l95, !tbaa !24
  %t217 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t215, i64 %t216)
  store i1 %t217, ptr %l96
  br label %bb52
bb52:
  %t218 = load i1, ptr %l96, !tbaa !21
  br i1 %t218, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t219 = load ptr, ptr %l7, !tbaa !29
  store ptr %t219, ptr %l97, !tbaa !29
  %t220 = load i64, ptr %l13, !tbaa !24
  %t222 = call i64 @compiler_2ffree_2eoval(i64 %t220)
  store i64 %t222, ptr %l99
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t223 = load ptr, ptr %l7, !tbaa !29
  store ptr %t223, ptr %l113, !tbaa !29
  %t224 = load i64, ptr %l13, !tbaa !24
  %t226 = call i64 @compiler_2ffree_2eoval(i64 %t224)
  store i64 %t226, ptr %l115
  br label %bb62
bb55:
  %t227 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t227, ptr %l100, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t228)
  store ptr %t230, ptr %l102
  br label %bb56
bb56:
  %t231 = load ptr, ptr %l102, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Body", ptr %t231, i32 0, i32 3
  %t234 = load i64, ptr %t233, !tbaa !24
  store i64 %t234, ptr %l104, !tbaa !24
  %t235 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t235, ptr %l105
  %t236 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s10, { i64, ptr } %t236, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t238, ptr %l107
  br label %bb57
bb57:
  %t239 = load i1, ptr %l107, !tbaa !21
  %t240 = xor i1 %t239, true
  br i1 %t240, label %bb58, label %bb59
bb58:
  %t242 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t243 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t246 = extractvalue { i64, ptr } %t242, 1
  %t247 = extractvalue { i64, ptr } %t242, 0
  %t248 = add i64 %t244, %t247
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t243, i64 %t244)
  %t253 = getelementptr i8, ptr %t252, i64 %t244
  call void @olang_textcopy(ptr %t253, ptr %t246, i64 %t247)
  %t254 = getelementptr i8, ptr %t253, i64 %t247
  call void @olang_textcopy(ptr %t254, ptr %t249, i64 %t250)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t252, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = mul i64 %t258, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t261, ptr %t259, i64 %t260, i1 false)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l109, !tbaa !27
  br label %bb60
bb59:
  store { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb60
bb60:
  %t265 = load ptr, ptr %l97, !tbaa !29
  %t266 = load i64, ptr %l99, !tbaa !24
  %t267 = load i64, ptr %l100, !tbaa !24
  %t268 = load i64, ptr %l104, !tbaa !24
  %t269 = load %"compiler/source:Span", ptr %l105
  %t270 = load { i64, ptr }, ptr %l109, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s10, ptr %t265, i64 %t266, i64 %t267, i64 %t268, %"compiler/source:Span" %t269, { i64, ptr } %t270)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb69
bb62:
  %t271 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t271, ptr %l116, !tbaa !24
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t272)
  store ptr %t274, ptr %l118
  br label %bb63
bb63:
  %t275 = load ptr, ptr %l118, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Body", ptr %t275, i32 0, i32 3
  %t278 = load i64, ptr %t277, !tbaa !24
  store i64 %t278, ptr %l120, !tbaa !24
  %t279 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t279, ptr %l121
  %t280 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t282 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s12, { i64, ptr } %t280, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) })
  store i1 %t282, ptr %l123
  br label %bb64
bb64:
  %t283 = load i1, ptr %l123, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb65, label %bb66
bb65:
  %t286 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t287 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t290 = extractvalue { i64, ptr } %t286, 1
  %t291 = extractvalue { i64, ptr } %t286, 0
  %t292 = add i64 %t288, %t291
  %t293 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t295 = add i64 %t292, %t294
  %t296 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t295)
  call void @olang_textcopy(ptr %t296, ptr %t287, i64 %t288)
  %t297 = getelementptr i8, ptr %t296, i64 %t288
  call void @olang_textcopy(ptr %t297, ptr %t290, i64 %t291)
  %t298 = getelementptr i8, ptr %t297, i64 %t291
  call void @olang_textcopy(ptr %t298, ptr %t293, i64 %t294)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t296, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  store { i64, ptr } %t307, ptr %l125, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l125, !tbaa !27
  br label %bb67
bb67:
  %t309 = load ptr, ptr %l113, !tbaa !29
  %t310 = load i64, ptr %l115, !tbaa !24
  %t311 = load i64, ptr %l116, !tbaa !24
  %t312 = load i64, ptr %l120, !tbaa !24
  %t313 = load %"compiler/source:Span", ptr %l121
  %t314 = load { i64, ptr }, ptr %l125, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s12, ptr %t309, i64 %t310, i64 %t311, i64 %t312, %"compiler/source:Span" %t313, { i64, ptr } %t314)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb71
bb71:
  %t315 = load i64, ptr %l12, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l12, !tbaa !24
  br label %bb8
bb72:
  %t319 = load i64, ptr %l9, !tbaa !24
  %t320 = load i64, ptr %l11, !tbaa !24
  %t323 = add i64 %t319, %t320
  store i64 %t323, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb73:
  br label %bb1
bb74:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca ptr
  %l67 = alloca i32
  %l68 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca ptr
  %l78 = alloca i1
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca ptr
  %l99 = alloca i1
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca ptr
  %l111 = alloca i1
  %l121 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca ptr
  %l127 = alloca i64
  %l128 = alloca i1
  %l132 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l143 = alloca %"compiler/typed:Plan"
  %l144 = alloca { i64, ptr }
  %l149 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l168 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca ptr
  %l170 = alloca i1
  %l182 = alloca i1
  %l188 = alloca i1
  %l197 = alloca { i64, ptr }
  %l202 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l207 = alloca i1
  %l214 = alloca ptr
  %l220 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l224 = alloca ptr
  %l229 = alloca i64
  %l230 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l249 = alloca ptr
  %l255 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l257 = alloca ptr
  %l259 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca i64
  %l266 = alloca ptr
  %l267 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l272 = alloca i64
  %l275 = alloca i64
  %l276 = alloca i32
  %l277 = alloca ptr
  %l280 = alloca ptr
  %l281 = alloca i32
  %l282 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l286 = alloca i1
  %l287 = alloca ptr
  %l292 = alloca i64
  %l293 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i1
  %l307 = alloca { i64, ptr }
  %l310 = alloca ptr
  %l313 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l315 = alloca i1
  %l318 = alloca ptr
  %l319 = alloca i1
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l329 = alloca i32
  %l330 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l334 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l338 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l339 = alloca ptr
  %l340 = alloca i1
  %l348 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l360 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l362 = alloca i1
  %l363 = alloca ptr
  %l367 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l369 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca i1
  %l384 = alloca { i64, ptr }
  %l395 = alloca ptr
  %l401 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l402 = alloca ptr
  %l403 = alloca i1
  %l416 = alloca { i64, ptr }
  %l431 = alloca { i64, ptr }
  %l434 = alloca ptr
  %l437 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l439 = alloca i1
  %l446 = alloca ptr
  %l447 = alloca ptr
  %l453 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l455 = alloca i1
  %l456 = alloca ptr
  %l457 = alloca i1
  %l466 = alloca ptr
  %l472 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l481 = alloca { i64, ptr }
  %l488 = alloca ptr
  %l502 = alloca { i64, ptr }
  %l505 = alloca ptr
  %l508 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l510 = alloca i1
  %l515 = alloca ptr
  %l516 = alloca i1
  %l523 = alloca ptr
  %l524 = alloca i1
  %l541 = alloca ptr
  %l544 = alloca i1
  %l550 = alloca i1
  %l562 = alloca { i64, ptr }
  %l568 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l574 = alloca i1
  %l577 = alloca ptr
  %l581 = alloca i64
  %l582 = alloca i1
  %l583 = alloca ptr
  %l584 = alloca i1
  %l600 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l606 = alloca i1
  %l607 = alloca ptr
  %l611 = alloca i64
  %l612 = alloca i1
  %l613 = alloca ptr
  %l614 = alloca i1
  %l627 = alloca { i64, ptr }
  %l630 = alloca ptr
  %l631 = alloca i1
  %l638 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l641 = alloca ptr
  %l646 = alloca i64
  %l647 = alloca i1
  %l648 = alloca ptr
  %l649 = alloca i1
  %l656 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l657 = alloca ptr
  %l659 = alloca i32
  %l660 = alloca i1
  %l662 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %t159 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l76
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t6 = load ptr, ptr %l77, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l77, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l78, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l78, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t32 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27, i32 %t28)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l88
  br label %bb7
bb7:
  %t33 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t34 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %t34
  br label %bb331
bb8:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t36 = load ptr, ptr %l89, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l89, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 3
  store i1 %t42, ptr %l90, !tbaa !21
  br label %bb10
bb10:
  %t43 = load i1, ptr %l90, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l5, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t54 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %t50, ptr %t51)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l97
  br label %bb14
bb14:
  %t55 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  %t56 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %t56
  br label %bb331
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  store ptr %t57, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t58 = load ptr, ptr %l98, !tbaa !29
  %t59 = icmp ne ptr %t58, null
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l98, !tbaa !29
  %t62 = load i64, ptr %t61
  %t64 = icmp eq i64 %t62, 4
  store i1 %t64, ptr %l99, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l99, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [5 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t68, i32 0, i32 1
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l6, !tbaa !23
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t84 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %t78, ptr %t79, i32 %t80)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l109
  br label %bb21
bb21:
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t86 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %t86
  br label %bb331
bb22:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t88 = load ptr, ptr %l110, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l110, !tbaa !29
  %t92 = load i64, ptr %t91
  %t94 = icmp eq i64 %t92, 5
  store i1 %t94, ptr %l111, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l111, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t98, i32 0, i32 1
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l8, !tbaa !23
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 2
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l9, !tbaa !29
  br label %bb27
bb26:
  br label %bb44
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Promote", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t108, ptr %t112)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %l121
  br label %bb28
bb28:
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l121
  %t117 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t117
  %t118 = load ptr, ptr %lp2
  store ptr %t118, ptr %l122, !tbaa !29
  %t119 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t120 = load ptr, ptr %l9, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Promote", ptr %t120, i32 0, i32 1
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t128 = call i64 @compiler_2ffree_2eorig(i64 %t119, i64 %t125)
  store i64 %t128, ptr %l127
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l122, !tbaa !29
  %t130 = load i64, ptr %l127, !tbaa !24
  %t131 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t129, i64 %t130)
  store i1 %t131, ptr %l128
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 2
  %t135 = load i1, ptr %t134, !tbaa !21
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb31, label %bb32
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/free:walker", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t143 = load i32, ptr %l8, !tbaa !23
  %t146 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t142, i32 %t143)
  store i1 %t146, ptr %l136
  br label %bb33
bb32:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb34
bb33:
  %t147 = load i1, ptr %l136, !tbaa !21
  store i1 %t147, ptr %l132, !tbaa !21
  br label %bb34
bb34:
  %t148 = load i1, ptr %l132, !tbaa !21
  br i1 %t148, label %bb35, label %bb36
bb35:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 3
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/free:walker", ptr %t155, i32 0, i32 1
  %t158 = load i64, ptr %t157, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t159, ptr %v0, ptr %v0, ptr %t154, i64 %t158)
  call void @llvm.memmove.p0.p0.i64(ptr %l143, ptr %t159, i64 152, i1 false)
  br label %bb37
bb36:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb39
bb37:
  %t162 = getelementptr %"compiler/typed:Plan", ptr %l143, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l144, !tbaa !27
  %t164 = load ptr, ptr %l9, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Promote", ptr %t164, i32 0, i32 1
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t171 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, [1 x i64] }, ptr %t172, i64 %t169
  %t174 = load { i64, [1 x i64] }, ptr %t173
  %t176 = call i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %t174)
  store i1 %t176, ptr %l149
  br label %bb38
bb38:
  %t177 = load i1, ptr %l149, !tbaa !21
  store i1 %t177, ptr %l137, !tbaa !21
  br label %bb39
bb39:
  %t178 = load i1, ptr %l137, !tbaa !21
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/free:walker", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t182, i64 %t186)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb331
bb44:
  %t189 = load ptr, ptr %l1, !tbaa !29
  store ptr %t189, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t190 = load ptr, ptr %l154, !tbaa !29
  %t191 = icmp ne ptr %t190, null
  br i1 %t191, label %bb45, label %bb46
bb45:
  %t193 = load ptr, ptr %l154, !tbaa !29
  %t194 = load i64, ptr %t193
  %t196 = icmp eq i64 %t194, 6
  store i1 %t196, ptr %l155, !tbaa !21
  br label %bb46
bb46:
  %t197 = load i1, ptr %l155, !tbaa !21
  br i1 %t197, label %bb47, label %bb48
bb47:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  %t201 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t200, i32 0, i32 0
  %t202 = load %"compiler/source:Span", ptr %t201
  store %"compiler/source:Span" %t202, ptr %l10
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [5 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207
  store i32 %t208, ptr %l11, !tbaa !23
  %t210 = load ptr, ptr %l1, !tbaa !29
  %t212 = getelementptr { i64, [5 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t212, i32 0, i32 2
  %t214 = load ptr, ptr %t213
  store ptr %t214, ptr %l12, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l12, !tbaa !29
  %t218 = load i32, ptr %l11, !tbaa !23
  %t219 = load %"compiler/source:Span", ptr %l10
  %t224 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %t216, ptr %t217, i32 %t218, %"compiler/source:Span" %t219)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %l168
  br label %bb50
bb50:
  %t225 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  %t226 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t225, ptr %t226
  br label %bb331
bb51:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t228 = load ptr, ptr %l169, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb52, label %bb53
bb52:
  %t231 = load ptr, ptr %l169, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 7
  store i1 %t234, ptr %l170, !tbaa !21
  br label %bb53
bb53:
  %t235 = load i1, ptr %l170, !tbaa !21
  br i1 %t235, label %bb54, label %bb55
bb54:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t238, i32 0, i32 0
  %t240 = load %"compiler/source:Span", ptr %t239
  store %"compiler/source:Span" %t240, ptr %l13
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr { i64, [5 x i64] }, ptr %t242, i32 0, i32 1
  %t245 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t244, i32 0, i32 1
  %t246 = load i32, ptr %t245
  store i32 %t246, ptr %l14, !tbaa !23
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l15, !tbaa !29
  br label %bb56
bb55:
  br label %bb85
bb56:
  %t254 = load ptr, ptr %l15, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 0
  %t257 = load i32, ptr %t256
  %t259 = trunc i64 3 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb57, label %bb58
bb57:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/free:walker", ptr %t262, i32 0, i32 0
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = getelementptr %"compiler/free:Free", ptr %t265, i32 0, i32 19
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/free:walker", ptr %t268, i32 0, i32 1
  %t271 = load i64, ptr %t270, !tbaa !24
  %t274 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t267, i64 %t271)
  store i1 %t274, ptr %l188
  br label %bb59
bb58:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb60
bb59:
  %t275 = load i1, ptr %l188, !tbaa !21
  store i1 %t275, ptr %l182, !tbaa !21
  br label %bb60
bb60:
  %t276 = load i1, ptr %l182, !tbaa !21
  store i1 %t276, ptr %l16, !tbaa !21
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Make", ptr %t277, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  store i64 %t284, ptr %l19, !tbaa !24
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t286 = load i64, ptr %l18, !tbaa !24
  %t287 = load i64, ptr %l19, !tbaa !24
  %t290 = icmp slt i64 %t286, %t287
  %t292 = xor i1 %t290, true
  br i1 %t292, label %bb62, label %bb63
bb62:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb63:
  br label %bb64
bb64:
  %t294 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t294, ptr %l197, !tbaa !27
  %t295 = load i64, ptr %l18, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t306 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t302, ptr %t300)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %l202
  br label %bb65
bb65:
  %t307 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l202
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t307, ptr %l21
  %t308 = load i1, ptr %l16, !tbaa !21
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb66, label %bb67
bb66:
  %t312 = load ptr, ptr %lp2
  %t315 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s9, ptr %t312, ptr %l21)
  store i1 %t315, ptr %l207
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb70
bb70:
  %t316 = load i64, ptr %l18, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l18, !tbaa !24
  br label %bb61
bb71:
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Make", ptr %t320, i32 0, i32 3
  %t323 = load ptr, ptr %t322, !tbaa !29
  %t325 = icmp eq ptr %t323, null
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l214, !tbaa !29
  %t330 = load ptr, ptr %l15, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Make", ptr %t330, i32 0, i32 3
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = icmp eq ptr %t333, null
  br i1 %t335, label %bb74, label %bb75
bb73:
  br label %bb78
bb74:
  call void @__olang_check_failed(ptr @olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88)
  unreachable
bb75:
  br label %bb76
bb76:
  %t337 = load ptr, ptr %l15, !tbaa !29
  %t339 = getelementptr %"compiler/typed:Make", ptr %t337, i32 0, i32 3
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t341 = load ptr, ptr %l214, !tbaa !29
  %t343 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s12, ptr %t341, ptr %t340)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t343, ptr %l220
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s12)
  br label %bb78
bb78:
  %t344 = load ptr, ptr %l15, !tbaa !29
  %t346 = getelementptr %"compiler/typed:Make", ptr %t344, i32 0, i32 4
  %t347 = load i32, ptr %t346, !tbaa !23
  %t349 = icmp sge i32 %t347, 0
  br i1 %t349, label %bb79, label %bb80
bb79:
  %t351 = load ptr, ptr %lp2
  store ptr %t351, ptr %l224, !tbaa !29
  %t352 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t353 = load ptr, ptr %l15, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Make", ptr %t353, i32 0, i32 4
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t361 = call i64 @compiler_2ffree_2eorig(i64 %t352, i64 %t358)
  store i64 %t361, ptr %l229
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t362 = load ptr, ptr %l224, !tbaa !29
  %t363 = load i64, ptr %l229, !tbaa !24
  %t364 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t362, i64 %t363)
  store i1 %t364, ptr %l230
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load ptr, ptr %l15, !tbaa !29
  %t367 = load i32, ptr %l14, !tbaa !23
  %t368 = load %"compiler/source:Span", ptr %l13
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %t365, ptr %t366, i32 %t367, %"compiler/source:Span" %t368)
  br label %bb84
bb84:
  br label %bb331
bb85:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t374 = load ptr, ptr %l235, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb86, label %bb87
bb86:
  %t377 = load ptr, ptr %l235, !tbaa !29
  %t378 = load i64, ptr %t377
  %t380 = icmp eq i64 %t378, 8
  store i1 %t380, ptr %l236, !tbaa !21
  br label %bb87
bb87:
  %t381 = load i1, ptr %l236, !tbaa !21
  br i1 %t381, label %bb88, label %bb89
bb88:
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t384, i32 0, i32 0
  %t386 = load %"compiler/source:Span", ptr %t385
  store %"compiler/source:Span" %t386, ptr %l22
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr { i64, [5 x i64] }, ptr %t388, i32 0, i32 1
  %t391 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t390, i32 0, i32 1
  %t392 = load i32, ptr %t391
  store i32 %t392, ptr %l23, !tbaa !23
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr { i64, [5 x i64] }, ptr %t394, i32 0, i32 1
  %t397 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t396, i32 0, i32 2
  %t398 = load ptr, ptr %t397
  store ptr %t398, ptr %l24, !tbaa !29
  br label %bb90
bb89:
  br label %bb116
bb90:
  %t400 = load ptr, ptr %l24, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Collect", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = icmp eq ptr %t403, null
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  %t409 = load ptr, ptr %l0, !tbaa !29
  store ptr %t409, ptr %l249, !tbaa !29
  %t410 = load ptr, ptr %l24, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Collect", ptr %t410, i32 0, i32 0
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb93, label %bb94
bb92:
  br label %bb97
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7)
  unreachable
bb94:
  br label %bb95
bb95:
  %t417 = load ptr, ptr %l24, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Collect", ptr %t417, i32 0, i32 0
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t421 = load ptr, ptr %l249, !tbaa !29
  %t423 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s15, ptr %t421, ptr %t420)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %l255
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s15)
  br label %bb97
bb97:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:walker", ptr %t424, i32 0, i32 10
  store ptr %t426, ptr %l257, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/free:walker", ptr %t427, i32 0, i32 0
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l259, !tbaa !29
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/free:walker", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t435 = load i32, ptr %l23, !tbaa !23
  %t438 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t438, ptr %l263
  br label %bb98
bb98:
  %t439 = load ptr, ptr %l259, !tbaa !29
  %t440 = load i32, ptr %l263, !tbaa !23
  %t441 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t439, i32 %t440, i64 -1)
  store i64 %t441, ptr %l264
  br label %bb99
bb99:
  %t442 = load ptr, ptr %l257, !tbaa !29
  %t443 = load i64, ptr %l264, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t442, i64 %t443)
  br label %bb100
bb100:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t446 = getelementptr %"compiler/free:walker", ptr %t444, i32 0, i32 32
  store ptr %t446, ptr %l266, !tbaa !29
  %t447 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t447, ptr %l267
  br label %bb101
bb101:
  %t448 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l267
  %t449 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t448, ptr %t449
  %t450 = load ptr, ptr %l266, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t450, ptr %t449)
  br label %bb102
bb102:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load ptr, ptr %l24, !tbaa !29
  %t455 = getelementptr %"compiler/typed:Collect", ptr %t453, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t452, ptr %t456)
  br label %bb103
bb103:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/free:walker", ptr %t459, i32 0, i32 10
  %t463 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t461)
  %t464 = extractvalue { i32, i64 } %t463, 1
  %t465 = extractvalue { i32, i64 } %t463, 0
  store i32 %t465, ptr %l276
  %t466 = icmp ne i32 %t465, 0
  br i1 %t466, label %bb105, label %ok.467
ok.467:
  store i64 %t464, ptr %l275
  br label %bb104
bb104:
  %t468 = load i64, ptr %l275, !tbaa !24
  store i64 %t468, ptr %l272, !tbaa !24
  br label %bb107
bb105:
  br label %bb106
bb106:
  call void @__olang_ert_req_clear()
  br label %bb107
bb107:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = getelementptr %"compiler/free:walker", ptr %t469, i32 0, i32 32
  %t473 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H082aedcd3ddb8fe82d6ff12d18e6e8d5(ptr %v0, ptr %v0, ptr %t471)
  %t474 = extractvalue { i32, ptr } %t473, 1
  %t475 = extractvalue { i32, ptr } %t473, 0
  store i32 %t475, ptr %l281
  %t476 = icmp ne i32 %t475, 0
  br i1 %t476, label %bb109, label %ok.477
ok.477:
  store ptr %t474, ptr %l280
  br label %bb108
bb108:
  %t478 = load ptr, ptr %l280, !tbaa !29
  store ptr %t478, ptr %l277, !tbaa !29
  br label %bb112
bb109:
  br label %bb110
bb110:
  call void @__olang_ert_req_clear()
  %t479 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t479, ptr %l282
  br label %bb111
bb111:
  %t480 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l282
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t480, ptr %t481
  store ptr %t481, ptr %l277, !tbaa !29
  br label %bb112
bb112:
  %t483 = load ptr, ptr %l277, !tbaa !29
  %t484 = load ptr, ptr %lp2
  %t488 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t484, ptr %t483)
  store i1 %t488, ptr %l286
  br label %bb113
bb113:
  %t489 = load ptr, ptr %lp2
  store ptr %t489, ptr %l287, !tbaa !29
  %t490 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t491 = load ptr, ptr %l24, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Collect", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %t493, !tbaa !23
  %t496 = sext i32 %t494 to i64
  %t499 = call i64 @compiler_2ffree_2eorig(i64 %t490, i64 %t496)
  store i64 %t499, ptr %l292
  br label %bb114
bb114:
  %t500 = load ptr, ptr %l287, !tbaa !29
  %t501 = load i64, ptr %l292, !tbaa !24
  %t502 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t500, i64 %t501)
  store i1 %t502, ptr %l293
  br label %bb115
bb115:
  br label %bb331
bb116:
  %t503 = load ptr, ptr %l1, !tbaa !29
  store ptr %t503, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t504 = load ptr, ptr %l294, !tbaa !29
  %t505 = icmp ne ptr %t504, null
  br i1 %t505, label %bb117, label %bb118
bb117:
  %t507 = load ptr, ptr %l294, !tbaa !29
  %t508 = load i64, ptr %t507
  %t510 = icmp eq i64 %t508, 9
  store i1 %t510, ptr %l295, !tbaa !21
  br label %bb118
bb118:
  %t511 = load i1, ptr %l295, !tbaa !21
  br i1 %t511, label %bb119, label %bb120
bb119:
  %t512 = load ptr, ptr %l1, !tbaa !29
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t512, i32 0, i32 1
  %t515 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t514, i32 0, i32 4
  %t516 = load { i64, ptr }, ptr %t515
  store { i64, ptr } %t516, ptr %l26, !tbaa !27
  br label %bb121
bb120:
  br label %bb130
bb121:
  %t518 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t518, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t520 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t520, 0
  store i64 %t522, ptr %l29, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s19
  %t524 = load i64, ptr %l28, !tbaa !24
  %t525 = load i64, ptr %l29, !tbaa !24
  %t528 = icmp slt i64 %t524, %t525
  %t530 = xor i1 %t528, true
  br i1 %t530, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s19)
  br label %bb129
bb124:
  br label %bb125
bb125:
  %t532 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t532, ptr %l307, !tbaa !27
  %t533 = load i64, ptr %l28, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr ptr, ptr %t536, i64 %t533
  %t538 = load ptr, ptr %t537, !tbaa !39
  %t540 = load ptr, ptr %lp2
  store ptr %t540, ptr %l310, !tbaa !29
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t545 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s19, ptr %t541, ptr %t538)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t545, ptr %l313
  br label %bb126
bb126:
  %t546 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l313
  %t547 = call ptr @__olang_scope_alloc_a(ptr %s19, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t546, ptr %t547
  %t548 = load ptr, ptr %l310, !tbaa !29
  %t550 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s19, ptr %t548, ptr %t547)
  store i1 %t550, ptr %l315
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s19)
  br label %bb128
bb128:
  %t551 = load i64, ptr %l28, !tbaa !24
  %t553 = add i64 %t551, 1
  store i64 %t553, ptr %l28, !tbaa !24
  br label %bb122
bb129:
  br label %bb331
bb130:
  %t555 = load ptr, ptr %l1, !tbaa !29
  store ptr %t555, ptr %l318, !tbaa !29
  store i1 false, ptr %l319, !tbaa !21
  %t556 = load ptr, ptr %l318, !tbaa !29
  %t557 = icmp ne ptr %t556, null
  br i1 %t557, label %bb131, label %bb132
bb131:
  %t559 = load ptr, ptr %l318, !tbaa !29
  %t560 = load i64, ptr %t559
  %t562 = icmp eq i64 %t560, 10
  store i1 %t562, ptr %l319, !tbaa !21
  br label %bb132
bb132:
  %t563 = load i1, ptr %l319, !tbaa !21
  br i1 %t563, label %bb133, label %bb134
bb133:
  %t564 = load ptr, ptr %l1, !tbaa !29
  %t566 = getelementptr { i64, [5 x i64] }, ptr %t564, i32 0, i32 1
  %t567 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t566, i32 0, i32 2
  %t568 = load ptr, ptr %t567
  store ptr %t568, ptr %l31, !tbaa !29
  br label %bb135
bb134:
  br label %bb140
bb135:
  store %olang.scope zeroinitializer, ptr %s21
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l324, !tbaa !29
  %t571 = load ptr, ptr %l31, !tbaa !29
  %t573 = getelementptr %"compiler/typed:Slice", ptr %t571, i32 0, i32 0
  %t574 = load ptr, ptr %t573, !tbaa !29
  store ptr %t574, ptr %l326, !tbaa !29
  %t575 = load ptr, ptr %l31, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Slice", ptr %t575, i32 0, i32 0
  %t578 = load ptr, ptr %t577, !tbaa !29
  %t580 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t578)
  store i32 %t580, ptr %l329
  br label %bb136
bb136:
  %t581 = load ptr, ptr %l324, !tbaa !29
  %t582 = load ptr, ptr %l326, !tbaa !29
  %t583 = load i32, ptr %l329, !tbaa !23
  %t584 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t581, ptr %t582, i32 %t583)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t584, ptr %l330
  br label %bb137
bb137:
  %t585 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l330
  %t586 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t585, ptr %t586
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load ptr, ptr %l31, !tbaa !29
  %t590 = getelementptr %"compiler/typed:Slice", ptr %t588, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t594 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t587, ptr %t591)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t594, ptr %l334
  br label %bb138
bb138:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l31, !tbaa !29
  %t598 = getelementptr %"compiler/typed:Slice", ptr %t596, i32 0, i32 2
  %t599 = load ptr, ptr %t598, !tbaa !29
  %t602 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t595, ptr %t599)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t602, ptr %l338
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s21)
  br label %bb331
bb140:
  %t603 = load ptr, ptr %l1, !tbaa !29
  store ptr %t603, ptr %l339, !tbaa !29
  store i1 false, ptr %l340, !tbaa !21
  %t604 = load ptr, ptr %l339, !tbaa !29
  %t605 = icmp ne ptr %t604, null
  br i1 %t605, label %bb141, label %bb142
bb141:
  %t607 = load ptr, ptr %l339, !tbaa !29
  %t608 = load i64, ptr %t607
  %t610 = icmp eq i64 %t608, 11
  store i1 %t610, ptr %l340, !tbaa !21
  br label %bb142
bb142:
  %t611 = load i1, ptr %l340, !tbaa !21
  br i1 %t611, label %bb143, label %bb144
bb143:
  %t612 = load ptr, ptr %l1, !tbaa !29
  %t614 = getelementptr { i64, [5 x i64] }, ptr %t612, i32 0, i32 1
  %t615 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t614, i32 0, i32 2
  %t616 = load ptr, ptr %t615
  store ptr %t616, ptr %l32, !tbaa !29
  br label %bb145
bb144:
  br label %bb157
bb145:
  store %olang.scope zeroinitializer, ptr %s22
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t619 = load ptr, ptr %l32, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Cond", ptr %t619, i32 0, i32 0
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t625 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t618, ptr %t622)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t625, ptr %l348
  br label %bb146
bb146:
  %t626 = load ptr, ptr %l32, !tbaa !29
  %t628 = getelementptr %"compiler/typed:Cond", ptr %t626, i32 0, i32 1
  %t629 = load ptr, ptr %t628, !tbaa !29
  %t631 = icmp eq ptr %t629, null
  %t633 = xor i1 %t631, true
  br i1 %t633, label %bb147, label %bb148
bb147:
  store %olang.scope zeroinitializer, ptr %s23
  %t635 = load ptr, ptr %lp2
  store ptr %t635, ptr %l353, !tbaa !29
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l354, !tbaa !29
  %t637 = load ptr, ptr %l32, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Cond", ptr %t637, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !29
  %t642 = icmp eq ptr %t640, null
  br i1 %t642, label %bb149, label %bb150
bb148:
  br label %bb154
bb149:
  call void @__olang_check_failed(ptr @olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6)
  unreachable
bb150:
  br label %bb151
bb151:
  %t644 = load ptr, ptr %l32, !tbaa !29
  %t646 = getelementptr %"compiler/typed:Cond", ptr %t644, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !29
  %t648 = load ptr, ptr %l354, !tbaa !29
  %t650 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s23, ptr %t648, ptr %t647)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t650, ptr %l360
  br label %bb152
bb152:
  %t651 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l360
  %t652 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t651, ptr %t652
  %t653 = load ptr, ptr %l353, !tbaa !29
  %t655 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s23, ptr %t653, ptr %t652)
  store i1 %t655, ptr %l362
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s23)
  br label %bb154
bb154:
  %t656 = load ptr, ptr %lp2
  store ptr %t656, ptr %l363, !tbaa !29
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l32, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Cond", ptr %t658, i32 0, i32 2
  %t661 = load ptr, ptr %t660, !tbaa !29
  %t664 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s22, ptr %t657, ptr %t661)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t664, ptr %l367
  br label %bb155
bb155:
  %t665 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l367
  %t666 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t665, ptr %t666
  %t667 = load ptr, ptr %l363, !tbaa !29
  %t669 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s22, ptr %t667, ptr %t666)
  store i1 %t669, ptr %l369
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s22)
  br label %bb331
bb157:
  %t670 = load ptr, ptr %l1, !tbaa !29
  store ptr %t670, ptr %l370, !tbaa !29
  store i1 false, ptr %l371, !tbaa !21
  %t671 = load ptr, ptr %l370, !tbaa !29
  %t672 = icmp ne ptr %t671, null
  br i1 %t672, label %bb158, label %bb159
bb158:
  %t674 = load ptr, ptr %l370, !tbaa !29
  %t675 = load i64, ptr %t674
  %t677 = icmp eq i64 %t675, 12
  store i1 %t677, ptr %l371, !tbaa !21
  br label %bb159
bb159:
  %t678 = load i1, ptr %l371, !tbaa !21
  br i1 %t678, label %bb160, label %bb161
bb160:
  %t679 = load ptr, ptr %l1, !tbaa !29
  %t681 = getelementptr { i64, [5 x i64] }, ptr %t679, i32 0, i32 1
  %t682 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t681, i32 0, i32 2
  %t683 = load ptr, ptr %t682
  store ptr %t683, ptr %l33, !tbaa !29
  br label %bb162
bb161:
  br label %bb177
bb162:
  %t685 = load ptr, ptr %l33, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Seq", ptr %t685, i32 0, i32 0
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  store { i64, ptr } %t688, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t690 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t692 = extractvalue { i64, ptr } %t690, 0
  store i64 %t692, ptr %l36, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s26
  %t694 = load i64, ptr %l35, !tbaa !24
  %t695 = load i64, ptr %l36, !tbaa !24
  %t698 = icmp slt i64 %t694, %t695
  %t700 = xor i1 %t698, true
  br i1 %t700, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s26)
  br label %bb169
bb165:
  br label %bb166
bb166:
  %t702 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t702, ptr %l384, !tbaa !27
  %t703 = load i64, ptr %l35, !tbaa !24
  %t705 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t706 = load ptr, ptr %t705, !tbaa !27
  %t707 = getelementptr ptr, ptr %t706, i64 %t703
  %t708 = load ptr, ptr %t707, !tbaa !39
  %t710 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t710, ptr %t708)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s26)
  br label %bb168
bb168:
  %t714 = load i64, ptr %l35, !tbaa !24
  %t716 = add i64 %t714, 1
  store i64 %t716, ptr %l35, !tbaa !24
  br label %bb163
bb169:
  %t718 = load ptr, ptr %l33, !tbaa !29
  %t720 = getelementptr %"compiler/typed:Seq", ptr %t718, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !29
  %t723 = icmp eq ptr %t721, null
  %t725 = xor i1 %t723, true
  br i1 %t725, label %bb170, label %bb171
bb170:
  %t727 = load ptr, ptr %l0, !tbaa !29
  store ptr %t727, ptr %l395, !tbaa !29
  %t728 = load ptr, ptr %l33, !tbaa !29
  %t730 = getelementptr %"compiler/typed:Seq", ptr %t728, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !29
  %t733 = icmp eq ptr %t731, null
  br i1 %t733, label %bb172, label %bb173
bb171:
  br label %bb176
bb172:
  call void @__olang_check_failed(ptr @olang_loc_5a2a443e2f2f03b9_3064adab7524445d)
  unreachable
bb173:
  br label %bb174
bb174:
  %t735 = load ptr, ptr %l33, !tbaa !29
  %t737 = getelementptr %"compiler/typed:Seq", ptr %t735, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t739 = load ptr, ptr %l395, !tbaa !29
  %t741 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t739, ptr %t738)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t741, ptr %l401
  br label %bb175
bb175:
  %t742 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l401
  %t743 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t742, ptr %t743
  br label %bb176
bb176:
  br label %bb331
bb177:
  %t744 = load ptr, ptr %l1, !tbaa !29
  store ptr %t744, ptr %l402, !tbaa !29
  store i1 false, ptr %l403, !tbaa !21
  %t745 = load ptr, ptr %l402, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb178, label %bb179
bb178:
  %t748 = load ptr, ptr %l402, !tbaa !29
  %t749 = load i64, ptr %t748
  %t751 = icmp eq i64 %t749, 13
  store i1 %t751, ptr %l403, !tbaa !21
  br label %bb179
bb179:
  %t752 = load i1, ptr %l403, !tbaa !21
  br i1 %t752, label %bb180, label %bb181
bb180:
  %t753 = load ptr, ptr %l1, !tbaa !29
  %t755 = getelementptr { i64, [5 x i64] }, ptr %t753, i32 0, i32 1
  %t756 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t755, i32 0, i32 2
  %t757 = load ptr, ptr %t756
  store ptr %t757, ptr %l38, !tbaa !29
  br label %bb182
bb181:
  br label %bb206
bb182:
  %t759 = load ptr, ptr %l38, !tbaa !29
  %t761 = getelementptr %"compiler/typed:Match", ptr %t759, i32 0, i32 0
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  store { i64, ptr } %t762, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t764 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t766 = extractvalue { i64, ptr } %t764, 0
  store i64 %t766, ptr %l41, !tbaa !24
  br label %bb183
bb183:
  store %olang.scope zeroinitializer, ptr %s31
  %t768 = load i64, ptr %l40, !tbaa !24
  %t769 = load i64, ptr %l41, !tbaa !24
  %t772 = icmp slt i64 %t768, %t769
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s31)
  br label %bb189
bb185:
  br label %bb186
bb186:
  %t776 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t776, ptr %l416, !tbaa !27
  %t777 = load i64, ptr %l40, !tbaa !24
  %t779 = getelementptr { i64, ptr }, ptr %l416, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !27
  %t781 = getelementptr ptr, ptr %t780, i64 %t777
  %t782 = load ptr, ptr %t781, !tbaa !39
  %t784 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t784, ptr %t782)
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s31)
  br label %bb188
bb188:
  %t788 = load i64, ptr %l40, !tbaa !24
  %t790 = add i64 %t788, 1
  store i64 %t790, ptr %l40, !tbaa !24
  br label %bb183
bb189:
  %t792 = load ptr, ptr %l38, !tbaa !29
  %t794 = getelementptr %"compiler/typed:Match", ptr %t792, i32 0, i32 1
  %t795 = load { i64, ptr }, ptr %t794, !tbaa !27
  store { i64, ptr } %t795, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t797 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t797, 0
  store i64 %t799, ptr %l45, !tbaa !24
  br label %bb190
bb190:
  store %olang.scope zeroinitializer, ptr %s34
  %t801 = load i64, ptr %l44, !tbaa !24
  %t802 = load i64, ptr %l45, !tbaa !24
  %t805 = icmp slt i64 %t801, %t802
  %t807 = xor i1 %t805, true
  br i1 %t807, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s34)
  br label %bb197
bb192:
  br label %bb193
bb193:
  %t809 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t809, ptr %l431, !tbaa !27
  %t810 = load i64, ptr %l44, !tbaa !24
  %t812 = getelementptr { i64, ptr }, ptr %l431, i32 0, i32 1
  %t813 = load ptr, ptr %t812, !tbaa !27
  %t814 = getelementptr ptr, ptr %t813, i64 %t810
  %t815 = load ptr, ptr %t814, !tbaa !39
  %t817 = load ptr, ptr %lp2
  store ptr %t817, ptr %l434, !tbaa !29
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t822 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s34, ptr %t818, ptr %t815)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t822, ptr %l437
  br label %bb194
bb194:
  %t823 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l437
  %t824 = call ptr @__olang_scope_alloc_a(ptr %s34, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t823, ptr %t824
  %t825 = load ptr, ptr %l434, !tbaa !29
  %t827 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s34, ptr %t825, ptr %t824)
  store i1 %t827, ptr %l439
  br label %bb195
bb195:
  call void @__olang_scope_close(ptr %s34)
  br label %bb196
bb196:
  %t828 = load i64, ptr %l44, !tbaa !24
  %t830 = add i64 %t828, 1
  store i64 %t830, ptr %l44, !tbaa !24
  br label %bb190
bb197:
  %t832 = load ptr, ptr %l38, !tbaa !29
  %t834 = getelementptr %"compiler/typed:Match", ptr %t832, i32 0, i32 2
  %t835 = load ptr, ptr %t834, !tbaa !29
  %t837 = icmp eq ptr %t835, null
  %t839 = xor i1 %t837, true
  br i1 %t839, label %bb198, label %bb199
bb198:
  store %olang.scope zeroinitializer, ptr %s36
  %t841 = load ptr, ptr %lp2
  store ptr %t841, ptr %l446, !tbaa !29
  %t842 = load ptr, ptr %l0, !tbaa !29
  store ptr %t842, ptr %l447, !tbaa !29
  %t843 = load ptr, ptr %l38, !tbaa !29
  %t845 = getelementptr %"compiler/typed:Match", ptr %t843, i32 0, i32 2
  %t846 = load ptr, ptr %t845, !tbaa !29
  %t848 = icmp eq ptr %t846, null
  br i1 %t848, label %bb200, label %bb201
bb199:
  br label %bb205
bb200:
  call void @__olang_check_failed(ptr @olang_loc_f2df24d87159f740_3aba0f93d819cd0c)
  unreachable
bb201:
  br label %bb202
bb202:
  %t850 = load ptr, ptr %l38, !tbaa !29
  %t852 = getelementptr %"compiler/typed:Match", ptr %t850, i32 0, i32 2
  %t853 = load ptr, ptr %t852, !tbaa !29
  %t854 = load ptr, ptr %l447, !tbaa !29
  %t856 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s36, ptr %t854, ptr %t853)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t856, ptr %l453
  br label %bb203
bb203:
  %t857 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l453
  %t858 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t857, ptr %t858
  %t859 = load ptr, ptr %l446, !tbaa !29
  %t861 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s36, ptr %t859, ptr %t858)
  store i1 %t861, ptr %l455
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s36)
  br label %bb205
bb205:
  br label %bb331
bb206:
  %t862 = load ptr, ptr %l1, !tbaa !29
  store ptr %t862, ptr %l456, !tbaa !29
  store i1 false, ptr %l457, !tbaa !21
  %t863 = load ptr, ptr %l456, !tbaa !29
  %t864 = icmp ne ptr %t863, null
  br i1 %t864, label %bb207, label %bb208
bb207:
  %t866 = load ptr, ptr %l456, !tbaa !29
  %t867 = load i64, ptr %t866
  %t869 = icmp eq i64 %t867, 14
  store i1 %t869, ptr %l457, !tbaa !21
  br label %bb208
bb208:
  %t870 = load i1, ptr %l457, !tbaa !21
  br i1 %t870, label %bb209, label %bb210
bb209:
  %t871 = load ptr, ptr %l1, !tbaa !29
  %t873 = getelementptr { i64, [5 x i64] }, ptr %t871, i32 0, i32 1
  %t874 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t873, i32 0, i32 2
  %t875 = load ptr, ptr %t874
  store ptr %t875, ptr %l47, !tbaa !29
  br label %bb211
bb210:
  br label %bb240
bb211:
  %t877 = load ptr, ptr %l47, !tbaa !29
  %t879 = getelementptr %"compiler/typed:Try", ptr %t877, i32 0, i32 0
  %t880 = load ptr, ptr %t879, !tbaa !29
  %t882 = icmp eq ptr %t880, null
  %t884 = xor i1 %t882, true
  br i1 %t884, label %bb212, label %bb213
bb212:
  %t886 = load ptr, ptr %l0, !tbaa !29
  store ptr %t886, ptr %l466, !tbaa !29
  %t887 = load ptr, ptr %l47, !tbaa !29
  %t889 = getelementptr %"compiler/typed:Try", ptr %t887, i32 0, i32 0
  %t890 = load ptr, ptr %t889, !tbaa !29
  %t892 = icmp eq ptr %t890, null
  br i1 %t892, label %bb214, label %bb215
bb213:
  br label %bb218
bb214:
  call void @__olang_check_failed(ptr @olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b)
  unreachable
bb215:
  br label %bb216
bb216:
  %t894 = load ptr, ptr %l47, !tbaa !29
  %t896 = getelementptr %"compiler/typed:Try", ptr %t894, i32 0, i32 0
  %t897 = load ptr, ptr %t896, !tbaa !29
  %t898 = load ptr, ptr %l466, !tbaa !29
  %t900 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t898, ptr %t897)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t900, ptr %l472
  br label %bb217
bb217:
  %t901 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l472
  %t902 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t901, ptr %t902
  br label %bb218
bb218:
  %t903 = load ptr, ptr %l47, !tbaa !29
  %t905 = getelementptr %"compiler/typed:Try", ptr %t903, i32 0, i32 1
  %t906 = load { i64, ptr }, ptr %t905, !tbaa !27
  store { i64, ptr } %t906, ptr %l48, !tbaa !27
  store i64 0, ptr %l49, !tbaa !24
  %t908 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t910 = extractvalue { i64, ptr } %t908, 0
  store i64 %t910, ptr %l50, !tbaa !24
  br label %bb219
bb219:
  store %olang.scope zeroinitializer, ptr %s40
  %t912 = load i64, ptr %l49, !tbaa !24
  %t913 = load i64, ptr %l50, !tbaa !24
  %t916 = icmp slt i64 %t912, %t913
  %t918 = xor i1 %t916, true
  br i1 %t918, label %bb220, label %bb221
bb220:
  call void @__olang_scope_close(ptr %s40)
  br label %bb239
bb221:
  br label %bb222
bb222:
  %t920 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t920, ptr %l481, !tbaa !27
  %t921 = load i64, ptr %l49, !tbaa !24
  %t923 = getelementptr { i64, ptr }, ptr %l481, i32 0, i32 1
  %t924 = load ptr, ptr %t923, !tbaa !27
  %t925 = getelementptr ptr, ptr %t924, i64 %t921
  %t926 = load ptr, ptr %t925, !tbaa !39
  store ptr %t926, ptr %l51, !tbaa !29
  %t928 = load ptr, ptr %l51, !tbaa !29
  %t930 = getelementptr %"compiler/typed:Clause", ptr %t928, i32 0, i32 3
  %t931 = load ptr, ptr %t930, !tbaa !29
  %t933 = icmp eq ptr %t931, null
  %t935 = xor i1 %t933, true
  br i1 %t935, label %bb223, label %bb224
bb223:
  %t937 = load ptr, ptr %l0, !tbaa !29
  store ptr %t937, ptr %l488, !tbaa !29
  %t938 = load ptr, ptr %l51, !tbaa !29
  %t940 = getelementptr %"compiler/typed:Clause", ptr %t938, i32 0, i32 3
  %t941 = load ptr, ptr %t940, !tbaa !29
  %t943 = icmp eq ptr %t941, null
  br i1 %t943, label %bb225, label %bb226
bb224:
  br label %bb229
bb225:
  call void @__olang_check_failed(ptr @olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba)
  unreachable
bb226:
  br label %bb227
bb227:
  %t945 = load ptr, ptr %l51, !tbaa !29
  %t947 = getelementptr %"compiler/typed:Clause", ptr %t945, i32 0, i32 3
  %t948 = load ptr, ptr %t947, !tbaa !29
  %t949 = load ptr, ptr %l488, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t949, ptr %t948)
  br label %bb228
bb228:
  br label %bb229
bb229:
  %t951 = load ptr, ptr %l51, !tbaa !29
  %t953 = getelementptr %"compiler/typed:Clause", ptr %t951, i32 0, i32 4
  %t954 = load { i64, ptr }, ptr %t953, !tbaa !27
  store { i64, ptr } %t954, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  %t956 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t958 = extractvalue { i64, ptr } %t956, 0
  store i64 %t958, ptr %l54, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s43
  %t960 = load i64, ptr %l53, !tbaa !24
  %t961 = load i64, ptr %l54, !tbaa !24
  %t964 = icmp slt i64 %t960, %t961
  %t966 = xor i1 %t964, true
  br i1 %t966, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s43)
  br label %bb237
bb232:
  br label %bb233
bb233:
  %t968 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t968, ptr %l502, !tbaa !27
  %t969 = load i64, ptr %l53, !tbaa !24
  %t971 = getelementptr { i64, ptr }, ptr %l502, i32 0, i32 1
  %t972 = load ptr, ptr %t971, !tbaa !27
  %t973 = getelementptr ptr, ptr %t972, i64 %t969
  %t974 = load ptr, ptr %t973, !tbaa !39
  %t976 = load ptr, ptr %lp2
  store ptr %t976, ptr %l505, !tbaa !29
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t981 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s43, ptr %t977, ptr %t974)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t981, ptr %l508
  br label %bb234
bb234:
  %t982 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l508
  %t983 = call ptr @__olang_scope_alloc_a(ptr %s43, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t982, ptr %t983
  %t984 = load ptr, ptr %l505, !tbaa !29
  %t986 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s43, ptr %t984, ptr %t983)
  store i1 %t986, ptr %l510
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s43)
  br label %bb236
bb236:
  %t987 = load i64, ptr %l53, !tbaa !24
  %t989 = add i64 %t987, 1
  store i64 %t989, ptr %l53, !tbaa !24
  br label %bb230
bb237:
  call void @__olang_scope_close(ptr %s40)
  br label %bb238
bb238:
  %t991 = load i64, ptr %l49, !tbaa !24
  %t993 = add i64 %t991, 1
  store i64 %t993, ptr %l49, !tbaa !24
  br label %bb219
bb239:
  br label %bb331
bb240:
  %t995 = load ptr, ptr %l1, !tbaa !29
  store ptr %t995, ptr %l515, !tbaa !29
  store i1 false, ptr %l516, !tbaa !21
  %t996 = load ptr, ptr %l515, !tbaa !29
  %t997 = icmp ne ptr %t996, null
  br i1 %t997, label %bb241, label %bb242
bb241:
  %t999 = load ptr, ptr %l515, !tbaa !29
  %t1000 = load i64, ptr %t999
  %t1002 = icmp eq i64 %t1000, 15
  store i1 %t1002, ptr %l516, !tbaa !21
  br label %bb242
bb242:
  %t1003 = load i1, ptr %l516, !tbaa !21
  br i1 %t1003, label %bb243, label %bb244
bb243:
  %t1004 = load ptr, ptr %l1, !tbaa !29
  %t1006 = getelementptr { i64, [5 x i64] }, ptr %t1004, i32 0, i32 1
  %t1007 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1006, i32 0, i32 0
  %t1008 = load %"compiler/source:Span", ptr %t1007
  store %"compiler/source:Span" %t1008, ptr %l56
  %t1010 = load ptr, ptr %l1, !tbaa !29
  %t1012 = getelementptr { i64, [5 x i64] }, ptr %t1010, i32 0, i32 1
  %t1013 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1012, i32 0, i32 2
  %t1014 = load ptr, ptr %t1013
  store ptr %t1014, ptr %l57, !tbaa !29
  br label %bb245
bb244:
  br label %bb293
bb245:
  %t1016 = load ptr, ptr %l57, !tbaa !29
  store ptr %t1016, ptr %l523, !tbaa !29
  store i1 false, ptr %l524, !tbaa !21
  %t1017 = load ptr, ptr %l523, !tbaa !29
  %t1018 = icmp ne ptr %t1017, null
  br i1 %t1018, label %bb246, label %bb247
bb246:
  %t1020 = load ptr, ptr %l523, !tbaa !29
  %t1021 = load i64, ptr %t1020
  %t1023 = icmp eq i64 %t1021, 1
  store i1 %t1023, ptr %l524, !tbaa !21
  br label %bb247
bb247:
  %t1024 = load i1, ptr %l524, !tbaa !21
  br i1 %t1024, label %bb248, label %bb249
bb248:
  %t1025 = load ptr, ptr %l57, !tbaa !29
  %t1027 = getelementptr { i64, [4 x i64] }, ptr %t1025, i32 0, i32 1
  %t1028 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1027, i32 0, i32 0
  %t1029 = load i32, ptr %t1028
  store i32 %t1029, ptr %l58, !tbaa !23
  %t1031 = load ptr, ptr %l57, !tbaa !29
  %t1033 = getelementptr { i64, [4 x i64] }, ptr %t1031, i32 0, i32 1
  %t1034 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1033, i32 0, i32 1
  %t1035 = load { i64, ptr }, ptr %t1034
  store { i64, ptr } %t1035, ptr %l59, !tbaa !27
  %t1037 = load ptr, ptr %l57, !tbaa !29
  %t1039 = getelementptr { i64, [4 x i64] }, ptr %t1037, i32 0, i32 1
  %t1040 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t1039, i32 0, i32 2
  %t1041 = load i32, ptr %t1040
  store i32 %t1041, ptr %l60, !tbaa !23
  br label %bb250
bb249:
  br label %bb272
bb250:
  %t1043 = load ptr, ptr %l0, !tbaa !29
  %t1045 = getelementptr %"compiler/free:walker", ptr %t1043, i32 0, i32 2
  %t1046 = load i1, ptr %t1045, !tbaa !21
  %t1048 = xor i1 %t1046, true
  br i1 %t1048, label %bb251, label %bb252
bb251:
  %t1050 = load ptr, ptr %l0, !tbaa !29
  %t1052 = getelementptr %"compiler/free:walker", ptr %t1050, i32 0, i32 0
  %t1053 = load ptr, ptr %t1052, !tbaa !29
  %t1055 = getelementptr %"compiler/free:Free", ptr %t1053, i32 0, i32 48
  %t1056 = load i32, ptr %l58, !tbaa !23
  %t1058 = sext i32 %t1056 to i64
  %t1061 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t1055, i64 %t1058)
  store ptr %t1061, ptr %l541
  br label %bb253
bb252:
  br label %bb260
bb253:
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1064 = getelementptr %"compiler/free:walker", ptr %t1062, i32 0, i32 1
  %t1065 = load i64, ptr %t1064, !tbaa !24
  %t1066 = load ptr, ptr %l541, !tbaa !29
  %t1068 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1066, i64 %t1065)
  store i1 %t1068, ptr %l544
  br label %bb254
bb254:
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1071 = getelementptr %"compiler/free:walker", ptr %t1069, i32 0, i32 0
  %t1072 = load ptr, ptr %t1071, !tbaa !29
  %t1074 = getelementptr %"compiler/free:Free", ptr %t1072, i32 0, i32 28
  %t1075 = load i32, ptr %l58, !tbaa !23
  %t1077 = sext i32 %t1075 to i64
  %t1080 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1074, i64 %t1077)
  store i1 %t1080, ptr %l550
  br label %bb255
bb255:
  %t1081 = load i1, ptr %l550, !tbaa !21
  br i1 %t1081, label %bb256, label %bb257
bb256:
  %t1082 = load ptr, ptr %l0, !tbaa !29
  %t1084 = getelementptr %"compiler/free:walker", ptr %t1082, i32 0, i32 0
  %t1085 = load ptr, ptr %t1084, !tbaa !29
  %t1086 = load ptr, ptr %l0, !tbaa !29
  %t1088 = getelementptr %"compiler/free:walker", ptr %t1086, i32 0, i32 1
  %t1089 = load i64, ptr %t1088, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1085, i64 %t1089)
  br label %bb258
bb257:
  br label %bb259
bb258:
  br label %bb259
bb259:
  br label %bb260
bb260:
  %t1092 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t1092, ptr %l61, !tbaa !27
  store i64 0, ptr %l62, !tbaa !24
  %t1094 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t1096 = extractvalue { i64, ptr } %t1094, 0
  store i64 %t1096, ptr %l63, !tbaa !24
  br label %bb261
bb261:
  store %olang.scope zeroinitializer, ptr %s51
  %t1098 = load i64, ptr %l62, !tbaa !24
  %t1099 = load i64, ptr %l63, !tbaa !24
  %t1102 = icmp slt i64 %t1098, %t1099
  %t1104 = xor i1 %t1102, true
  br i1 %t1104, label %bb262, label %bb263
bb262:
  call void @__olang_scope_close(ptr %s51)
  br label %bb269
bb263:
  br label %bb264
bb264:
  %t1106 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t1106, ptr %l562, !tbaa !27
  %t1107 = load i64, ptr %l62, !tbaa !24
  %t1109 = getelementptr { i64, ptr }, ptr %l562, i32 0, i32 1
  %t1110 = load ptr, ptr %t1109, !tbaa !27
  %t1111 = getelementptr ptr, ptr %t1110, i64 %t1107
  %t1112 = load ptr, ptr %t1111, !tbaa !39
  %t1114 = load ptr, ptr %l0, !tbaa !29
  %t1117 = getelementptr %"compiler/typed:Capture", ptr %t1112, i32 0, i32 1
  %t1118 = load ptr, ptr %t1117, !tbaa !29
  %t1121 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s51, ptr %t1114, ptr %t1118)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1121, ptr %l568
  br label %bb265
bb265:
  %t1122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l568
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1122, ptr %l65
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1124 = load %"compiler/source:Span", ptr %l56
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s51, ptr %s51, ptr %t1123, ptr %l65, %"compiler/source:Span" %t1124, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb266
bb266:
  %t1128 = load ptr, ptr %lp2
  %t1131 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s51, ptr %t1128, ptr %l65)
  store i1 %t1131, ptr %l574
  br label %bb267
bb267:
  call void @__olang_scope_close(ptr %s51)
  br label %bb268
bb268:
  %t1132 = load i64, ptr %l62, !tbaa !24
  %t1134 = add i64 %t1132, 1
  store i64 %t1134, ptr %l62, !tbaa !24
  br label %bb261
bb269:
  %t1136 = load ptr, ptr %lp2
  store ptr %t1136, ptr %l577, !tbaa !29
  %t1137 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1138 = load i32, ptr %l60, !tbaa !23
  %t1140 = sext i32 %t1138 to i64
  %t1143 = call i64 @compiler_2ffree_2eorig(i64 %t1137, i64 %t1140)
  store i64 %t1143, ptr %l581
  br label %bb270
bb270:
  %t1144 = load ptr, ptr %l577, !tbaa !29
  %t1145 = load i64, ptr %l581, !tbaa !24
  %t1146 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1144, i64 %t1145)
  store i1 %t1146, ptr %l582
  br label %bb271
bb271:
  br label %bb292
bb272:
  %t1147 = load ptr, ptr %l57, !tbaa !29
  store ptr %t1147, ptr %l583, !tbaa !29
  store i1 false, ptr %l584, !tbaa !21
  %t1148 = load ptr, ptr %l583, !tbaa !29
  %t1149 = icmp ne ptr %t1148, null
  br i1 %t1149, label %bb273, label %bb274
bb273:
  %t1151 = load ptr, ptr %l583, !tbaa !29
  %t1152 = load i64, ptr %t1151
  %t1154 = icmp eq i64 %t1152, 2
  store i1 %t1154, ptr %l584, !tbaa !21
  br label %bb274
bb274:
  %t1155 = load i1, ptr %l584, !tbaa !21
  br i1 %t1155, label %bb275, label %bb276
bb275:
  %t1156 = load ptr, ptr %l57, !tbaa !29
  %t1158 = getelementptr { i64, [4 x i64] }, ptr %t1156, i32 0, i32 1
  %t1159 = getelementptr { i32, ptr, i32 }, ptr %t1158, i32 0, i32 1
  %t1160 = load ptr, ptr %t1159
  store ptr %t1160, ptr %l66, !tbaa !29
  %t1162 = load ptr, ptr %l57, !tbaa !29
  %t1164 = getelementptr { i64, [4 x i64] }, ptr %t1162, i32 0, i32 1
  %t1165 = getelementptr { i32, ptr, i32 }, ptr %t1164, i32 0, i32 2
  %t1166 = load i32, ptr %t1165
  store i32 %t1166, ptr %l67, !tbaa !23
  br label %bb277
bb276:
  br label %bb287
bb277:
  store %olang.scope zeroinitializer, ptr %s53
  %t1168 = load ptr, ptr %l0, !tbaa !29
  %t1170 = getelementptr %"compiler/free:walker", ptr %t1168, i32 0, i32 2
  %t1171 = load i1, ptr %t1170, !tbaa !21
  %t1173 = xor i1 %t1171, true
  br i1 %t1173, label %bb278, label %bb279
bb278:
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1177 = getelementptr %"compiler/free:walker", ptr %t1175, i32 0, i32 0
  %t1178 = load ptr, ptr %t1177, !tbaa !29
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1181 = getelementptr %"compiler/free:walker", ptr %t1179, i32 0, i32 1
  %t1182 = load i64, ptr %t1181, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t1178, i64 %t1182)
  br label %bb280
bb279:
  br label %bb281
bb280:
  br label %bb281
bb281:
  %t1185 = load ptr, ptr %l0, !tbaa !29
  %t1186 = load ptr, ptr %l66, !tbaa !29
  %t1189 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s53, ptr %t1185, ptr %t1186)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1189, ptr %l600
  br label %bb282
bb282:
  %t1190 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l600
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1190, ptr %l68
  %t1191 = load ptr, ptr %l0, !tbaa !29
  %t1192 = load %"compiler/source:Span", ptr %l56
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s53, ptr %s53, ptr %t1191, ptr %l68, %"compiler/source:Span" %t1192, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb283
bb283:
  %t1196 = load ptr, ptr %lp2
  %t1199 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s53, ptr %t1196, ptr %l68)
  store i1 %t1199, ptr %l606
  br label %bb284
bb284:
  %t1200 = load ptr, ptr %lp2
  store ptr %t1200, ptr %l607, !tbaa !29
  %t1201 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1202 = load i32, ptr %l67, !tbaa !23
  %t1204 = sext i32 %t1202 to i64
  %t1207 = call i64 @compiler_2ffree_2eorig(i64 %t1201, i64 %t1204)
  store i64 %t1207, ptr %l611
  br label %bb285
bb285:
  %t1208 = load ptr, ptr %l607, !tbaa !29
  %t1209 = load i64, ptr %l611, !tbaa !24
  %t1210 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1208, i64 %t1209)
  store i1 %t1210, ptr %l612
  br label %bb286
bb286:
  call void @__olang_scope_close(ptr %s53)
  br label %bb292
bb287:
  br i1 true, label %bb288, label %bb289
bb288:
  br label %bb290
bb289:
  br label %bb291
bb290:
  br label %bb292
bb291:
  call void @__olang_check_failed(ptr @olang_loc_67165cb650ae48c_1f30efdb88316bc8)
  unreachable
bb292:
  br label %bb331
bb293:
  %t1211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1211, ptr %l613, !tbaa !29
  store i1 false, ptr %l614, !tbaa !21
  %t1212 = load ptr, ptr %l613, !tbaa !29
  %t1213 = icmp ne ptr %t1212, null
  br i1 %t1213, label %bb294, label %bb295
bb294:
  %t1215 = load ptr, ptr %l613, !tbaa !29
  %t1216 = load i64, ptr %t1215
  %t1218 = icmp eq i64 %t1216, 16
  store i1 %t1218, ptr %l614, !tbaa !21
  br label %bb295
bb295:
  %t1219 = load i1, ptr %l614, !tbaa !21
  br i1 %t1219, label %bb296, label %bb297
bb296:
  %t1220 = load ptr, ptr %l1, !tbaa !29
  %t1222 = getelementptr { i64, [5 x i64] }, ptr %t1220, i32 0, i32 1
  %t1223 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1222, i32 0, i32 2
  %t1224 = load ptr, ptr %t1223
  store ptr %t1224, ptr %l69, !tbaa !29
  br label %bb298
bb297:
  br label %bb319
bb298:
  %t1226 = load ptr, ptr %l69, !tbaa !29
  %t1228 = getelementptr %"compiler/typed:Text", ptr %t1226, i32 0, i32 0
  %t1229 = load { i64, ptr }, ptr %t1228, !tbaa !27
  store { i64, ptr } %t1229, ptr %l70, !tbaa !27
  store i64 0, ptr %l71, !tbaa !24
  %t1231 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t1233 = extractvalue { i64, ptr } %t1231, 0
  store i64 %t1233, ptr %l72, !tbaa !24
  br label %bb299
bb299:
  store %olang.scope zeroinitializer, ptr %s58
  %t1235 = load i64, ptr %l71, !tbaa !24
  %t1236 = load i64, ptr %l72, !tbaa !24
  %t1239 = icmp slt i64 %t1235, %t1236
  %t1241 = xor i1 %t1239, true
  br i1 %t1241, label %bb300, label %bb301
bb300:
  call void @__olang_scope_close(ptr %s58)
  br label %bb316
bb301:
  br label %bb302
bb302:
  %t1243 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t1243, ptr %l627, !tbaa !27
  %t1244 = load i64, ptr %l71, !tbaa !24
  %t1246 = getelementptr { i64, ptr }, ptr %l627, i32 0, i32 1
  %t1247 = load ptr, ptr %t1246, !tbaa !27
  %t1248 = getelementptr ptr, ptr %t1247, i64 %t1244
  %t1249 = load ptr, ptr %t1248, !tbaa !39
  store ptr %t1249, ptr %l73, !tbaa !29
  %t1251 = load ptr, ptr %l73, !tbaa !29
  store ptr %t1251, ptr %l630, !tbaa !29
  store i1 false, ptr %l631, !tbaa !21
  %t1252 = load ptr, ptr %l630, !tbaa !29
  %t1253 = icmp ne ptr %t1252, null
  br i1 %t1253, label %bb303, label %bb304
bb303:
  %t1255 = load ptr, ptr %l630, !tbaa !29
  %t1256 = load i64, ptr %t1255
  %t1258 = icmp eq i64 %t1256, 1
  store i1 %t1258, ptr %l631, !tbaa !21
  br label %bb304
bb304:
  %t1259 = load i1, ptr %l631, !tbaa !21
  br i1 %t1259, label %bb305, label %bb306
bb305:
  %t1260 = load ptr, ptr %l73, !tbaa !29
  %t1262 = getelementptr { i64, [2 x i64] }, ptr %t1260, i32 0, i32 1
  %t1263 = getelementptr { ptr }, ptr %t1262, i32 0, i32 0
  %t1264 = load ptr, ptr %t1263
  store ptr %t1264, ptr %l74, !tbaa !29
  br label %bb307
bb306:
  br label %bb309
bb307:
  store %olang.scope zeroinitializer, ptr %s59
  %t1266 = load ptr, ptr %l0, !tbaa !29
  %t1267 = load ptr, ptr %l74, !tbaa !29
  %t1270 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s59, ptr %t1266, ptr %t1267)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1270, ptr %l638
  br label %bb308
bb308:
  call void @__olang_scope_close(ptr %s59)
  br label %bb314
bb309:
  br i1 true, label %bb310, label %bb311
bb310:
  br label %bb312
bb311:
  br label %bb313
bb312:
  br label %bb314
bb313:
  call void @__olang_check_failed(ptr @olang_loc_b6b576316e1b3293_3c9a5af727622297)
  unreachable
bb314:
  call void @__olang_scope_close(ptr %s58)
  br label %bb315
bb315:
  %t1271 = load i64, ptr %l71, !tbaa !24
  %t1273 = add i64 %t1271, 1
  store i64 %t1273, ptr %l71, !tbaa !24
  br label %bb299
bb316:
  %t1275 = load ptr, ptr %lp2
  store ptr %t1275, ptr %l641, !tbaa !29
  %t1276 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t1277 = load ptr, ptr %l69, !tbaa !29
  %t1279 = getelementptr %"compiler/typed:Text", ptr %t1277, i32 0, i32 1
  %t1280 = load i32, ptr %t1279, !tbaa !23
  %t1282 = sext i32 %t1280 to i64
  %t1285 = call i64 @compiler_2ffree_2eorig(i64 %t1276, i64 %t1282)
  store i64 %t1285, ptr %l646
  br label %bb317
bb317:
  %t1286 = load ptr, ptr %l641, !tbaa !29
  %t1287 = load i64, ptr %l646, !tbaa !24
  %t1288 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1286, i64 %t1287)
  store i1 %t1288, ptr %l647
  br label %bb318
bb318:
  br label %bb331
bb319:
  %t1289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1289, ptr %l648, !tbaa !29
  store i1 false, ptr %l649, !tbaa !21
  %t1290 = load ptr, ptr %l648, !tbaa !29
  %t1291 = icmp ne ptr %t1290, null
  br i1 %t1291, label %bb320, label %bb321
bb320:
  %t1293 = load ptr, ptr %l648, !tbaa !29
  %t1294 = load i64, ptr %t1293
  %t1296 = icmp eq i64 %t1294, 17
  store i1 %t1296, ptr %l649, !tbaa !21
  br label %bb321
bb321:
  %t1297 = load i1, ptr %l649, !tbaa !21
  br i1 %t1297, label %bb322, label %bb323
bb322:
  %t1298 = load ptr, ptr %l1, !tbaa !29
  %t1300 = getelementptr { i64, [5 x i64] }, ptr %t1298, i32 0, i32 1
  %t1301 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1300, i32 0, i32 2
  %t1302 = load ptr, ptr %t1301
  store ptr %t1302, ptr %l75, !tbaa !29
  br label %bb324
bb323:
  br label %bb326
bb324:
  %t1304 = load ptr, ptr %l0, !tbaa !29
  %t1305 = load ptr, ptr %l75, !tbaa !29
  %t1308 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1304, ptr %t1305)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1308, ptr %l656
  br label %bb325
bb325:
  %t1309 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l656
  %t1310 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1309, ptr %t1310
  br label %bb331
bb326:
  br i1 true, label %bb327, label %bb328
bb327:
  br label %bb329
bb328:
  br label %bb330
bb329:
  br label %bb331
bb330:
  call void @__olang_check_failed(ptr @olang_loc_797639ecae530892_5422fc7df8fd29f6)
  unreachable
bb331:
  %t1311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1311, ptr %l657, !tbaa !29
  %t1312 = load ptr, ptr %l1, !tbaa !29
  %t1314 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1312)
  store i32 %t1314, ptr %l659
  br label %bb332
bb332:
  %t1315 = load ptr, ptr %l657, !tbaa !29
  %t1316 = load i32, ptr %l659, !tbaa !23
  %t1317 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t1315, i32 %t1316)
  store i1 %t1317, ptr %l660
  br label %bb333
bb333:
  %t1318 = load i1, ptr %l660, !tbaa !21
  %t1319 = xor i1 %t1318, true
  br i1 %t1319, label %bb334, label %bb335
bb334:
  %t1321 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1321, ptr %l662
  br label %bb336
bb335:
  br label %bb337
bb336:
  %t1322 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l662
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1322, ptr %rv
  br label %ret
bb337:
  %t1323 = load ptr, ptr %lp2
  %t1324 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1323
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1324, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca { i64, { i64, ptr } }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, { i64, ptr } }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, { i64, ptr } }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i1
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, { i64, ptr } }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, { i64, ptr } }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l110 = alloca { i64, ptr }
  %l114 = alloca i64
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, { i64, ptr } }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l134 = alloca { i64, { i64, ptr } }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l141 = alloca i64
  %l144 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i64
  %l154 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca ptr
  %l165 = alloca i32
  %l167 = alloca %"compiler/typed:Local"
  %l169 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l180 = alloca %"compiler/source:Span"
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, { i64, ptr } }
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l206 = alloca { i64, ptr }
  %l210 = alloca i1
  %l214 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, { i64, ptr } }
  %l223 = alloca { i64, ptr }
  %l224 = alloca i64
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l228 = alloca { i64, { i64, ptr } }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l16
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l16, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l17, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 5
  store i1 %t17, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Promote", ptr %t25, i32 0, i32 1
  %t28 = load i32, ptr %t27, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t33 = insertvalue { i64, { i64, ptr } } undef, i64 %t30, 0
  %t35 = insertvalue { i64, { i64, ptr } } %t33, { i64, ptr } %t31, 1
  store { i64, { i64, ptr } } %t35, ptr %l28
  %t36 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = mul i64 %t40, 1
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = mul i64 %t49, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t46, ptr %t48, i64 %t50, i1 false)
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, { i64, ptr } }, ptr %l28, i32 0, i32 1
  store { i64, ptr } %t51, ptr %t52, !tbaa !27
  %t53 = load { i64, { i64, ptr } }, ptr %l28
  store { i64, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb7:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t62 = load i1, ptr %l33, !tbaa !21
  br i1 %t62, label %bb10, label %bb11
bb10:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/typed:Make", ptr %t69, i32 0, i32 4
  %t72 = load i32, ptr %t71, !tbaa !23
  %t74 = sext i32 %t72 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = insertvalue { i64, { i64, ptr } } undef, i64 %t74, 0
  %t79 = insertvalue { i64, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  store { i64, { i64, ptr } } %t79, ptr %l43
  %t80 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l46, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l45, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t96 = getelementptr { i64, { i64, ptr } }, ptr %l43, i32 0, i32 1
  store { i64, ptr } %t95, ptr %t96, !tbaa !27
  %t97 = load { i64, { i64, ptr } }, ptr %l43
  store { i64, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb13:
  %t98 = load ptr, ptr %l1, !tbaa !29
  store ptr %t98, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb14, label %bb15
bb14:
  %t102 = load ptr, ptr %l47, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 16
  store i1 %t105, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t106 = load i1, ptr %l48, !tbaa !21
  br i1 %t106, label %bb16, label %bb17
bb16:
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load ptr, ptr %t110
  store ptr %t111, ptr %l6, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Text", ptr %t113, i32 0, i32 1
  %t116 = load i32, ptr %t115, !tbaa !23
  %t118 = sext i32 %t116 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t121 = insertvalue { i64, { i64, ptr } } undef, i64 %t118, 0
  %t123 = insertvalue { i64, { i64, ptr } } %t121, { i64, ptr } %t119, 1
  store { i64, { i64, ptr } } %t123, ptr %l58
  %t124 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l59, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 0
  store i64 %t127, ptr %l60, !tbaa !24
  %t128 = load i64, ptr %l60, !tbaa !24
  %t129 = mul i64 %t128, 1
  %t130 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t129)
  %t131 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t130, 1
  store { i64, ptr } %t132, ptr %l61, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l60, !tbaa !24
  %t138 = mul i64 %t137, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t134, ptr %t136, i64 %t138, i1 false)
  %t139 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t140 = getelementptr { i64, { i64, ptr } }, ptr %l58, i32 0, i32 1
  store { i64, ptr } %t139, ptr %t140, !tbaa !27
  %t141 = load { i64, { i64, ptr } }, ptr %l58
  store { i64, { i64, ptr } } %t141, ptr %rv
  br label %ret
bb19:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t143 = load ptr, ptr %l62, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb20, label %bb21
bb20:
  %t146 = load ptr, ptr %l62, !tbaa !29
  %t147 = load i64, ptr %t146
  %t149 = icmp eq i64 %t147, 8
  store i1 %t149, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t150 = load i1, ptr %l63, !tbaa !21
  br i1 %t150, label %bb22, label %bb23
bb22:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Collect", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %t159, !tbaa !23
  %t162 = sext i32 %t160 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t165 = insertvalue { i64, { i64, ptr } } undef, i64 %t162, 0
  %t167 = insertvalue { i64, { i64, ptr } } %t165, { i64, ptr } %t163, 1
  store { i64, { i64, ptr } } %t167, ptr %l73
  %t168 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l74, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 0
  store i64 %t171, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l75, !tbaa !24
  %t173 = mul i64 %t172, 1
  %t174 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l76, !tbaa !27
  %t177 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !27
  %t181 = load i64, ptr %l75, !tbaa !24
  %t182 = mul i64 %t181, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %t180, i64 %t182, i1 false)
  %t183 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t184 = getelementptr { i64, { i64, ptr } }, ptr %l73, i32 0, i32 1
  store { i64, ptr } %t183, ptr %t184, !tbaa !27
  %t185 = load { i64, { i64, ptr } }, ptr %l73
  store { i64, { i64, ptr } } %t185, ptr %rv
  br label %ret
bb25:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t187 = load ptr, ptr %l77, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb26, label %bb27
bb26:
  %t190 = load ptr, ptr %l77, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 6
  store i1 %t193, ptr %l78, !tbaa !21
  br label %bb27
bb27:
  %t194 = load i1, ptr %l78, !tbaa !21
  br i1 %t194, label %bb28, label %bb29
bb28:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t197, i32 0, i32 2
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l8, !tbaa !29
  br label %bb30
bb29:
  br label %bb78
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t201 = load ptr, ptr %l2, !tbaa !29
  %t202 = load ptr, ptr %l8, !tbaa !29
  %t205 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  store i64 %t205, ptr %l85
  br label %bb31
bb31:
  %t206 = load i64, ptr %l85, !tbaa !24
  store i64 %t206, ptr %l9, !tbaa !24
  %t207 = load i64, ptr %l9, !tbaa !24
  %t209 = icmp slt i64 %t207, 0
  br i1 %t209, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb34
bb33:
  %t211 = load ptr, ptr %l8, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Call", ptr %t211, i32 0, i32 3
  %t214 = load i32, ptr %t213, !tbaa !23
  %t216 = icmp slt i32 %t214, 0
  store i1 %t216, ptr %l88, !tbaa !21
  br label %bb34
bb34:
  %t218 = load i1, ptr %l88, !tbaa !21
  br i1 %t218, label %bb35, label %bb36
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t220 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t222 = insertvalue { i64, { i64, ptr } } %t220, { i64, ptr } %t219, 1
  store { i64, { i64, ptr } } %t222, ptr %l94
  %t223 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l95, !tbaa !27
  %t225 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l96, !tbaa !24
  %t227 = load i64, ptr %l96, !tbaa !24
  %t228 = mul i64 %t227, 1
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l97, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l96, !tbaa !24
  %t237 = mul i64 %t236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t239 = getelementptr { i64, { i64, ptr } }, ptr %l94, i32 0, i32 1
  store { i64, ptr } %t238, ptr %t239, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t240 = load { i64, { i64, ptr } }, ptr %l94
  store { i64, { i64, ptr } } %t240, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/free:Free", ptr %t241, i32 0, i32 1
  %t244 = load i64, ptr %l9, !tbaa !24
  %t247 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t243, i64 %t244)
  store ptr %t247, ptr %l101
  br label %bb38
bb38:
  %t248 = load ptr, ptr %l101, !tbaa !29
  store ptr %t248, ptr %l10, !tbaa !29
  %t249 = load ptr, ptr %l10, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Body", ptr %t249, i32 0, i32 11
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = icmp eq ptr %t252, null
  br i1 %t254, label %bb39, label %bb40
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t257 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t259 = insertvalue { i64, { i64, ptr } } %t257, { i64, ptr } %t256, 1
  store { i64, { i64, ptr } } %t259, ptr %l107
  %t260 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l108, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  store i64 %t263, ptr %l109, !tbaa !24
  %t264 = load i64, ptr %l109, !tbaa !24
  %t265 = mul i64 %t264, 1
  %t266 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t265)
  %t267 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  store { i64, ptr } %t268, ptr %l110, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = load i64, ptr %l109, !tbaa !24
  %t274 = mul i64 %t273, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t270, ptr %t272, i64 %t274, i1 false)
  %t275 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t276 = getelementptr { i64, { i64, ptr } }, ptr %l107, i32 0, i32 1
  store { i64, ptr } %t275, ptr %t276, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t277 = load { i64, { i64, ptr } }, ptr %l107
  store { i64, { i64, ptr } } %t277, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t278 = load ptr, ptr %l3, !tbaa !29
  %t279 = load ptr, ptr %l10, !tbaa !29
  %t281 = getelementptr %"compiler/typed:Body", ptr %t279, i32 0, i32 2
  %t282 = load i32, ptr %t281, !tbaa !23
  %t285 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t278, i32 %t282)
  store i64 %t285, ptr %l114
  br label %bb42
bb42:
  %t286 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t287 = load i64, ptr %l114, !tbaa !24
  %t289 = icmp eq i64 %t287, %t286
  br i1 %t289, label %bb43, label %bb44
bb43:
  %t291 = load ptr, ptr %l8, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Call", ptr %t291, i32 0, i32 3
  %t294 = load i32, ptr %t293, !tbaa !23
  %t296 = sext i32 %t294 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %l120, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t299 = insertvalue { i64, { i64, ptr } } undef, i64 %t296, 0
  %t301 = insertvalue { i64, { i64, ptr } } %t299, { i64, ptr } %t297, 1
  store { i64, { i64, ptr } } %t301, ptr %l122
  %t302 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  store { i64, ptr } %t303, ptr %l123, !tbaa !27
  %t304 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  store i64 %t305, ptr %l124, !tbaa !24
  %t306 = load i64, ptr %l124, !tbaa !24
  %t307 = mul i64 %t306, 1
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l125, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = load i64, ptr %l124, !tbaa !24
  %t316 = mul i64 %t315, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t312, ptr %t314, i64 %t316, i1 false)
  %t317 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t318 = getelementptr { i64, { i64, ptr } }, ptr %l122, i32 0, i32 1
  store { i64, ptr } %t317, ptr %t318, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t319 = load { i64, { i64, ptr } }, ptr %l122
  store { i64, { i64, ptr } } %t319, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t321 = load ptr, ptr %l10, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Body", ptr %t321, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  %t327 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s5, ptr %t320, i32 %t324)
  store { i64, ptr } %t327, ptr %l129
  br label %bb46
bb46:
  %t328 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  %t331 = icmp ne i64 %t329, 1
  br i1 %t331, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %l132, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t334 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t336 = insertvalue { i64, { i64, ptr } } %t334, { i64, ptr } %t333, 1
  store { i64, { i64, ptr } } %t336, ptr %l134
  %t337 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l135, !tbaa !27
  %t339 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  store i64 %t340, ptr %l136, !tbaa !24
  %t341 = load i64, ptr %l136, !tbaa !24
  %t342 = mul i64 %t341, 1
  %t343 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t342)
  %t344 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  store { i64, ptr } %t345, ptr %l137, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = load i64, ptr %l136, !tbaa !24
  %t351 = mul i64 %t350, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t347, ptr %t349, i64 %t351, i1 false)
  %t352 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t353 = getelementptr { i64, { i64, ptr } }, ptr %l134, i32 0, i32 1
  store { i64, ptr } %t352, ptr %t353, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t354 = load { i64, { i64, ptr } }, ptr %l134
  store { i64, { i64, ptr } } %t354, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t355 = load ptr, ptr %l3, !tbaa !29
  %t356 = load ptr, ptr %l10, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Body", ptr %t356, i32 0, i32 2
  %t359 = load i32, ptr %t358, !tbaa !23
  %t362 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t355, i32 %t359, i64 0)
  store i64 %t362, ptr %l141
  br label %bb50
bb50:
  %t363 = load i64, ptr %l141, !tbaa !24
  store i64 %t363, ptr %l11, !tbaa !24
  %t364 = load i64, ptr %l11, !tbaa !24
  %t366 = icmp sge i64 %t364, 0
  br i1 %t366, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb53
bb52:
  %t368 = load i64, ptr %l11, !tbaa !24
  %t369 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t372 = icmp eq i64 %t368, %t369
  store i1 %t372, ptr %l144, !tbaa !21
  br label %bb53
bb53:
  %t374 = load i1, ptr %l144, !tbaa !21
  br i1 %t374, label %bb54, label %bb55
bb54:
  %t375 = load i64, ptr %l11, !tbaa !24
  %t377 = icmp sge i64 %t375, 0
  br i1 %t377, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t379 = load i64, ptr %l11, !tbaa !24
  store i64 %t379, ptr %l151, !tbaa !24
  %t380 = load ptr, ptr %l10, !tbaa !29
  %t382 = getelementptr %"compiler/typed:Body", ptr %t380, i32 0, i32 5
  %t384 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t382)
  store i64 %t384, ptr %l154
  br label %bb58
bb57:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb59
bb58:
  %t385 = load i64, ptr %l151, !tbaa !24
  %t386 = load i64, ptr %l154, !tbaa !24
  %t387 = icmp slt i64 %t385, %t386
  store i1 %t387, ptr %l150, !tbaa !21
  br label %bb59
bb59:
  %t389 = load i1, ptr %l150, !tbaa !21
  br i1 %t389, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s11
  %t390 = load ptr, ptr %l2, !tbaa !29
  %t392 = getelementptr %"compiler/free:Free", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 0
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = getelementptr %"compiler/load:Loader", ptr %t396, i32 0, i32 3
  %t399 = load ptr, ptr %t398, !tbaa !29
  store ptr %t399, ptr %l159, !tbaa !29
  %t400 = load ptr, ptr %l10, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Body", ptr %t400, i32 0, i32 7
  store ptr %t402, ptr %l161, !tbaa !29
  %t403 = load ptr, ptr %l10, !tbaa !29
  %t405 = getelementptr %"compiler/typed:Body", ptr %t403, i32 0, i32 5
  %t406 = load i64, ptr %l11, !tbaa !24
  %t409 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t405, i64 %t406)
  store i32 %t409, ptr %l165
  br label %bb62
bb61:
  br label %bb71
bb62:
  %t410 = load i32, ptr %l165, !tbaa !23
  %t411 = sext i32 %t410 to i64
  %t412 = load ptr, ptr %l161, !tbaa !29
  %t414 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t412, i64 %t411)
  store %"compiler/typed:Local" %t414, ptr %l167
  br label %bb63
bb63:
  %t415 = getelementptr %"compiler/typed:Local", ptr %l167, i32 0, i32 0
  %t416 = load i32, ptr %t415, !tbaa !23
  %t417 = load ptr, ptr %l159, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t417, i32 %t416)
  store { i64, ptr } %t419, ptr %l169
  br label %bb64
bb64:
  %t420 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t420, ptr %l12, !tbaa !27
  %t421 = load ptr, ptr %l2, !tbaa !29
  %t422 = load i64, ptr %l9, !tbaa !24
  %t425 = getelementptr %"compiler/free:Free", ptr %t421, i32 0, i32 42
  store i64 %t422, ptr %t425, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t427 = load ptr, ptr %l10, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Body", ptr %t427, i32 0, i32 3
  %t430 = load i64, ptr %t429, !tbaa !24
  %t433 = getelementptr %"compiler/free:Free", ptr %t426, i32 0, i32 43
  store i64 %t430, ptr %t433, !tbaa !24
  %t434 = load ptr, ptr %l2, !tbaa !29
  store ptr %t434, ptr %l175, !tbaa !29
  %t435 = load ptr, ptr %l10, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Body", ptr %t435, i32 0, i32 4
  %t438 = getelementptr %"compiler/source:Span", ptr %t437, i32 0, i32 0
  %t439 = load i32, ptr %t438, !tbaa !23
  %t440 = load ptr, ptr %l10, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Body", ptr %t440, i32 0, i32 4
  %t443 = getelementptr %"compiler/source:Span", ptr %t442, i32 0, i32 0
  %t444 = load i32, ptr %t443, !tbaa !23
  %t447 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t439, i32 %t444)
  store %"compiler/source:Span" %t447, ptr %l180
  br label %bb65
bb65:
  %t448 = load %"compiler/source:Span", ptr %l180
  %t449 = load ptr, ptr %l175, !tbaa !29
  %t450 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 44
  store %"compiler/source:Span" %t448, ptr %t450
  %t451 = load ptr, ptr %l2, !tbaa !29
  %t452 = load i64, ptr %l9, !tbaa !24
  %t455 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s11, ptr %t451, i64 %t452)
  store { i64, ptr } %t455, ptr %l183
  br label %bb66
bb66:
  %t456 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t456, ptr %l184, !tbaa !27
  %t457 = load ptr, ptr %l2, !tbaa !29
  store ptr %t457, ptr %l185, !tbaa !29
  %t458 = load ptr, ptr %l3, !tbaa !29
  %t459 = load ptr, ptr %l10, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Body", ptr %t459, i32 0, i32 2
  %t462 = load i32, ptr %t461, !tbaa !23
  %t465 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t458, i32 %t462)
  store { i64, ptr } %t465, ptr %l189
  br label %bb67
bb67:
  %t466 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t467 = load ptr, ptr %t466, !tbaa !27
  %t468 = getelementptr i32, ptr %t467, i64 0
  %t469 = load i32, ptr %t468, !tbaa !33
  %t470 = load ptr, ptr %l185, !tbaa !29
  %t472 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebuiltSpell(ptr %v0, ptr %s11, ptr %t470, i32 %t469)
  store { i64, ptr } %t472, ptr %l191
  br label %bb68
bb68:
  %t473 = load ptr, ptr %l2, !tbaa !29
  store ptr %t473, ptr %l192, !tbaa !29
  %t474 = load ptr, ptr %l3, !tbaa !29
  %t475 = load ptr, ptr %l10, !tbaa !29
  %t477 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %t477, !tbaa !23
  %t481 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s11, ptr %t474, i32 %t478)
  store { i64, ptr } %t481, ptr %l196
  br label %bb69
bb69:
  %t482 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr i32, ptr %t483, i64 0
  %t485 = load i32, ptr %t484, !tbaa !33
  %t486 = load ptr, ptr %l192, !tbaa !29
  %t488 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %s11, ptr %t486, i32 %t485)
  store { i64, ptr } %t488, ptr %l198
  br label %bb70
bb70:
  %t489 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t491 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = add i64 %t490, %t493
  %t495 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t496 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t497 = add i64 %t494, %t496
  %t498 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 1
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t501 = add i64 %t497, %t500
  %t502 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 1
  %t507 = extractvalue { i64, ptr } %t505, 0
  %t508 = add i64 %t504, %t507
  %t509 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t510 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t511 = add i64 %t508, %t510
  %t512 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 1
  %t514 = extractvalue { i64, ptr } %t512, 0
  %t515 = add i64 %t511, %t514
  %t516 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t515)
  call void @olang_textcopy(ptr %t516, ptr %t489, i64 %t490)
  %t517 = getelementptr i8, ptr %t516, i64 %t490
  call void @olang_textcopy(ptr %t517, ptr %t492, i64 %t493)
  %t518 = getelementptr i8, ptr %t517, i64 %t493
  call void @olang_textcopy(ptr %t518, ptr %t495, i64 %t496)
  %t519 = getelementptr i8, ptr %t518, i64 %t496
  call void @olang_textcopy(ptr %t519, ptr %t499, i64 %t500)
  %t520 = getelementptr i8, ptr %t519, i64 %t500
  call void @olang_textcopy(ptr %t520, ptr %t502, i64 %t503)
  %t521 = getelementptr i8, ptr %t520, i64 %t503
  call void @olang_textcopy(ptr %t521, ptr %t506, i64 %t507)
  %t522 = getelementptr i8, ptr %t521, i64 %t507
  call void @olang_textcopy(ptr %t522, ptr %t509, i64 %t510)
  %t523 = getelementptr i8, ptr %t522, i64 %t510
  call void @olang_textcopy(ptr %t523, ptr %t513, i64 %t514)
  %t524 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t525 = insertvalue { i64, ptr } %t524, ptr %t516, 1
  %t526 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t528 = insertvalue { i64, { i64, ptr } } %t526, { i64, ptr } %t525, 1
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t528, ptr %rv
  br label %ret
bb71:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l201, !tbaa !27
  %t530 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t531 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t533 = insertvalue { i64, { i64, ptr } } %t531, { i64, ptr } %t530, 1
  store { i64, { i64, ptr } } %t533, ptr %l203
  %t534 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l204, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t537 = extractvalue { i64, ptr } %t536, 0
  store i64 %t537, ptr %l205, !tbaa !24
  %t538 = load i64, ptr %l205, !tbaa !24
  %t539 = mul i64 %t538, 1
  %t540 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t539)
  %t541 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t540, 1
  store { i64, ptr } %t542, ptr %l206, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = load i64, ptr %l205, !tbaa !24
  %t548 = mul i64 %t547, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t544, ptr %t546, i64 %t548, i1 false)
  %t549 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t550 = getelementptr { i64, { i64, ptr } }, ptr %l203, i32 0, i32 1
  store { i64, ptr } %t549, ptr %t550, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t551 = load { i64, { i64, ptr } }, ptr %l203
  store { i64, { i64, ptr } } %t551, ptr %rv
  br label %ret
bb72:
  %t552 = load ptr, ptr %l2, !tbaa !29
  %t554 = getelementptr %"compiler/free:Free", ptr %t552, i32 0, i32 27
  %t555 = load i64, ptr %l9, !tbaa !24
  %t558 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t554, i64 %t555)
  store i1 %t558, ptr %l210
  br label %bb73
bb73:
  %t559 = load i1, ptr %l210, !tbaa !21
  %t560 = xor i1 %t559, true
  br i1 %t560, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t562 = load ptr, ptr %l2, !tbaa !29
  %t563 = load i64, ptr %l9, !tbaa !24
  %t566 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s13, ptr %t562, i64 %t563)
  store { i64, ptr } %t566, ptr %l214
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t567 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t568 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t569 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t570 = extractvalue { i64, ptr } %t569, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = add i64 %t568, %t571
  %t573 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t574 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t575 = add i64 %t572, %t574
  %t576 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t575)
  call void @olang_textcopy(ptr %t576, ptr %t567, i64 %t568)
  %t577 = getelementptr i8, ptr %t576, i64 %t568
  call void @olang_textcopy(ptr %t577, ptr %t570, i64 %t571)
  %t578 = getelementptr i8, ptr %t577, i64 %t571
  call void @olang_textcopy(ptr %t578, ptr %t573, i64 %t574)
  %t579 = insertvalue { i64, ptr } undef, i64 %t575, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t576, 1
  %t581 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t583 = insertvalue { i64, { i64, ptr } } %t581, { i64, ptr } %t580, 1
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s5)
  store { i64, { i64, ptr } } %t583, ptr %rv
  br label %ret
bb77:
  %t585 = load ptr, ptr %l8, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Call", ptr %t585, i32 0, i32 3
  %t588 = load i32, ptr %t587, !tbaa !23
  %t590 = sext i32 %t588 to i64
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l220, !tbaa !27
  %t591 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t593 = insertvalue { i64, { i64, ptr } } undef, i64 %t590, 0
  %t595 = insertvalue { i64, { i64, ptr } } %t593, { i64, ptr } %t591, 1
  store { i64, { i64, ptr } } %t595, ptr %l222
  %t596 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  %t597 = load { i64, ptr }, ptr %t596, !tbaa !27
  store { i64, ptr } %t597, ptr %l223, !tbaa !27
  %t598 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 0
  store i64 %t599, ptr %l224, !tbaa !24
  %t600 = load i64, ptr %l224, !tbaa !24
  %t601 = mul i64 %t600, 1
  %t602 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t601)
  %t603 = insertvalue { i64, ptr } undef, i64 %t600, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t602, 1
  store { i64, ptr } %t604, ptr %l225, !tbaa !27
  %t605 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = load i64, ptr %l224, !tbaa !24
  %t610 = mul i64 %t609, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t606, ptr %t608, i64 %t610, i1 false)
  %t611 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t612 = getelementptr { i64, { i64, ptr } }, ptr %l222, i32 0, i32 1
  store { i64, ptr } %t611, ptr %t612, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  %t613 = load { i64, { i64, ptr } }, ptr %l222
  store { i64, { i64, ptr } } %t613, ptr %rv
  br label %ret
bb78:
  br i1 true, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb82
bb81:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l226, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t615 = insertvalue { i64, { i64, ptr } } undef, i64 -1, 0
  %t617 = insertvalue { i64, { i64, ptr } } %t615, { i64, ptr } %t614, 1
  store { i64, { i64, ptr } } %t617, ptr %l228
  %t618 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  %t619 = load { i64, ptr }, ptr %t618, !tbaa !27
  store { i64, ptr } %t619, ptr %l229, !tbaa !27
  %t620 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 0
  store i64 %t621, ptr %l230, !tbaa !24
  %t622 = load i64, ptr %l230, !tbaa !24
  %t623 = mul i64 %t622, 1
  %t624 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t623)
  %t625 = insertvalue { i64, ptr } undef, i64 %t622, 0
  %t626 = insertvalue { i64, ptr } %t625, ptr %t624, 1
  store { i64, ptr } %t626, ptr %l231, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t628 = load ptr, ptr %t627, !tbaa !27
  %t629 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t630 = load ptr, ptr %t629, !tbaa !27
  %t631 = load i64, ptr %l230, !tbaa !24
  %t632 = mul i64 %t631, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t628, ptr %t630, i64 %t632, i1 false)
  %t633 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t634 = getelementptr { i64, { i64, ptr } }, ptr %l228, i32 0, i32 1
  store { i64, ptr } %t633, ptr %t634, !tbaa !27
  %t635 = load { i64, { i64, ptr } }, ptr %l228
  store { i64, { i64, ptr } } %t635, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @olang_loc_fa71248d89b17b0b_39d265aac120d27f)
  unreachable
ret:
  %rr = load { i64, { i64, ptr } }, ptr %rv
  ret { i64, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l14 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 7
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t19, i64 %a1)
  store %"compiler/typed:Local" %t23, ptr %l12
  br label %bb2
bb2:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t26, i32 %t25)
  store { i64, ptr } %t28, ptr %l14
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i1
  %l53 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i64
  %l61 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t60 = load i64, ptr %l1, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp slt i64 %t61, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l1, !tbaa !24
  store i64 %t65, ptr %l43, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 15
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb16
bb15:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = icmp sle i64 %t73, %t74
  store i1 %t75, ptr %l42, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t80, i64 %t81)
  store i64 %t84, ptr %l53
  br label %bb19
bb18:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t86 = load i64, ptr %l53, !tbaa !24
  %t88 = icmp slt i64 %t86, %t85
  store i1 %t88, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t90 = load i1, ptr %l49, !tbaa !21
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t91 = load i64, ptr %l2, !tbaa !24
  store i64 %t91, ptr %l57, !tbaa !24
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 15
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l61
  br label %bb23
bb22:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb24
bb23:
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  store i1 %t101, ptr %l56, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l56, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb8
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca i1
  %l18 = alloca i1
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l59 = alloca i64
  %l64 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca %"compiler/free:orCall"
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 17
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t6, i64 %t10)
  store i1 %t13, ptr %l16
  br label %bb1
bb1:
  %t14 = load i1, ptr %l16, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb3:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Call", ptr %t17, i32 0, i32 3
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = icmp slt i32 %t20, 0
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Call", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb8, label %bb9
bb8:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb13
bb10:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t58 = load i64, ptr %l31, !tbaa !24
  store i64 %t58, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l7, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb16:
  br label %bb17
bb17:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l8, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Call", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr ptr, ptr %t86, i64 %t83
  %t88 = load ptr, ptr %t87, !tbaa !39
  %t91 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %t78, ptr %t88)
  store ptr %t91, ptr %l54
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l54, !tbaa !29
  store ptr %t92, ptr %l9, !tbaa !29
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  br i1 %t95, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t101 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i64 %t101, ptr %l59
  br label %bb22
bb22:
  %t102 = load i64, ptr %l59, !tbaa !24
  store i64 %t102, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t105 = icmp slt i64 %t103, 0
  br i1 %t105, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/free:walker", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 39
  store ptr %t112, ptr %l64, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 3
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t124 = load i64, ptr %l8, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Call", ptr %t127, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l75, !tbaa !27
  %t131 = load i64, ptr %l8, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr ptr, ptr %t134, i64 %t131
  %t136 = load ptr, ptr %t135, !tbaa !39
  %t144 = call %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v1, ptr %v1, ptr %v0, i64 %t116, i64 %t122, i64 %a2, i64 %t124, i64 %t125, ptr %t126, ptr %t136)
  store %"compiler/free:orCall" %t144, ptr %l78
  br label %bb26
bb26:
  %t145 = load ptr, ptr %l64, !tbaa !29
  %t146 = load %"compiler/free:orCall", ptr %l78
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t145, %"compiler/free:orCall" %t146)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb28:
  %t147 = load i64, ptr %l7, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l7, !tbaa !24
  br label %bb14
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorStoreOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l10 = alloca i1
  %l13 = alloca ptr
  %l18 = alloca i64
  %l23 = alloca ptr
  %l29 = alloca %"compiler/free:orStore"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 17
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t6, i64 %t10)
  store i1 %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load i1, ptr %l10, !tbaa !21
  %t15 = xor i1 %t14, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t19 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %a1)
  store ptr %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  store ptr %t20, ptr %l3, !tbaa !29
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = icmp eq ptr %t21, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i64 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load i64, ptr %l18, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 40
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t52 = call %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v2, ptr %v1, ptr %v0, i64 %t44, i64 %t45, ptr %a2, ptr %t47)
  store %"compiler/free:orStore" %t52, ptr %l29
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = load %"compiler/free:orStore", ptr %l29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t53, %"compiler/free:orStore" %t54)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %lp14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %lp18 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l58 = alloca i64
  %l61 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca i64
  %l98 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l118 = alloca i32
  %l119 = alloca i32
  %l120 = alloca i64
  %l123 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l138 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l139 = alloca ptr
  %l140 = alloca i1
  %l147 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l148 = alloca ptr
  %l149 = alloca i1
  %l152 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l155 = alloca i64
  %l157 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca ptr
  %l168 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l169 = alloca ptr
  %l173 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t7 = load ptr, ptr %l21, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l21, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l22, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %t27, i64 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l33
  br label %bb7
bb7:
  %t36 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t36, ptr %lp5
  %t37 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t38 = load ptr, ptr %lp5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %t38
  %t39 = load ptr, ptr %lp5
  store ptr %t39, ptr %l34, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 3
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t48 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t42, i64 %t45)
  store ptr %t48, ptr %l39
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t49, ptr %t50)
  store i1 %t51, ptr %l40
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 4
  %t55 = load i32, ptr %l4, !tbaa !23
  %t57 = sext i32 %t55 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t57, i1 true)
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 7
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = sext i32 %t63 to i64
  %t68 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t62, i64 %t65)
  %t69 = extractvalue { i32, i64 } %t68, 1
  %t70 = extractvalue { i32, i64 } %t68, 0
  store i32 %t70, ptr %l51
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb12, label %ok.72
ok.72:
  store i64 %t69, ptr %l50
  br label %bb11
bb11:
  %t73 = load i64, ptr %l50, !tbaa !24
  store i64 %t73, ptr %l45, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb14
bb14:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 8
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i64, ptr %l6, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t79, i32 %t83, i64 %t84)
  store i64 %t88, ptr %l58
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t89 = load i64, ptr %l58, !tbaa !24
  store i64 %t89, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sge i64 %t90, 0
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %lp5
  store ptr %t94, ptr %l61, !tbaa !29
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = call i64 @compiler_2ffree_2eorig(i64 %t95, i64 %t96)
  store i64 %t99, ptr %l64
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t100 = load ptr, ptr %l61, !tbaa !29
  %t101 = load i64, ptr %l64, !tbaa !24
  %t102 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t100, i64 %t101)
  store i1 %t102, ptr %l65
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t103 = load ptr, ptr %lp5
  %t104 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t103
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %rv
  br label %ret
bb24:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t107 = load ptr, ptr %l67, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb25, label %bb26
bb25:
  %t110 = load ptr, ptr %l67, !tbaa !29
  %t111 = load i64, ptr %t110
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t114 = load i1, ptr %l68, !tbaa !21
  br i1 %t114, label %bb27, label %bb28
bb27:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l8, !tbaa !29
  %t125 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t121, ptr %t122)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l75
  br label %bb30
bb30:
  %t126 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t126, ptr %rv
  br label %ret
bb31:
  %t127 = load ptr, ptr %l1, !tbaa !29
  store ptr %t127, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t128 = load ptr, ptr %l76, !tbaa !29
  %t129 = icmp ne ptr %t128, null
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t131 = load ptr, ptr %l76, !tbaa !29
  %t132 = load i64, ptr %t131
  %t134 = icmp eq i64 %t132, 3
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l77, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb34:
  %t136 = load ptr, ptr %l1, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t138, i32 0, i32 2
  %t140 = load ptr, ptr %t139
  store ptr %t140, ptr %l9, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t142, i32 0, i32 1
  %t145 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t144, i32 0, i32 3
  %t146 = load i64, ptr %t145
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load ptr, ptr %l9, !tbaa !29
  %t152 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t148, ptr %t149)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %l86
  br label %bb37
bb37:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t153, ptr %lp11
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  %t155 = load ptr, ptr %lp11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t155
  %t156 = load ptr, ptr %l2, !tbaa !29
  store ptr %t156, ptr %l87, !tbaa !29
  %t157 = load ptr, ptr %l9, !tbaa !29
  %t159 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t157)
  store i32 %t159, ptr %l89
  br label %bb38
bb38:
  %t160 = load i64, ptr %l10, !tbaa !24
  %t161 = load ptr, ptr %l87, !tbaa !29
  %t162 = load i32, ptr %l89, !tbaa !23
  %t164 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t161, i32 %t162, i64 %t160)
  store i64 %t164, ptr %l91
  br label %bb39
bb39:
  %t165 = load i64, ptr %l91, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb40, label %bb41
bb40:
  %t170 = load ptr, ptr %lp11
  store ptr %t170, ptr %l94, !tbaa !29
  %t171 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call i64 @compiler_2ffree_2eorig(i64 %t171, i64 %t172)
  store i64 %t175, ptr %l97
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t176 = load ptr, ptr %l94, !tbaa !29
  %t177 = load i64, ptr %l97, !tbaa !24
  %t178 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t176, i64 %t177)
  store i1 %t178, ptr %l98
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t179 = load ptr, ptr %lp11
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t179
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %rv
  br label %ret
bb45:
  %t182 = load ptr, ptr %l1, !tbaa !29
  store ptr %t182, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t183 = load ptr, ptr %l100, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t187 = load i64, ptr %t186
  %t189 = icmp eq i64 %t187, 4
  store i1 %t189, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l101, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr { i64, [4 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l13, !tbaa !29
  br label %bb50
bb49:
  br label %bb61
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l13, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Elem", ptr %t198, i32 0, i32 0
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t204 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t197, ptr %t201)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %l109
  br label %bb51
bb51:
  %t205 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t205, ptr %lp14
  %t206 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  %t207 = load ptr, ptr %lp14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %t207
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Elem", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t215 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t208, ptr %t212)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t215, ptr %l113
  br label %bb52
bb52:
  %t216 = load ptr, ptr %l2, !tbaa !29
  store ptr %t216, ptr %l114, !tbaa !29
  %t217 = load ptr, ptr %l2, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  %t218 = load ptr, ptr %l13, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Elem", ptr %t218, i32 0, i32 0
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t221)
  store i32 %t223, ptr %l118
  br label %bb53
bb53:
  %t224 = load ptr, ptr %l115, !tbaa !29
  %t225 = load i32, ptr %l118, !tbaa !23
  %t226 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t224, i32 %t225)
  store i32 %t226, ptr %l119
  br label %bb54
bb54:
  %t227 = load ptr, ptr %l114, !tbaa !29
  %t228 = load i32, ptr %l119, !tbaa !23
  %t229 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t227, i32 %t228, i64 -1)
  store i64 %t229, ptr %l120
  br label %bb55
bb55:
  %t230 = load i64, ptr %l120, !tbaa !24
  store i64 %t230, ptr %l15, !tbaa !24
  %t231 = load i64, ptr %l15, !tbaa !24
  %t233 = icmp sge i64 %t231, 0
  br i1 %t233, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %lp14
  store ptr %t235, ptr %l123, !tbaa !29
  %t236 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t240 = call i64 @compiler_2ffree_2eorig(i64 %t236, i64 %t237)
  store i64 %t240, ptr %l126
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t241 = load ptr, ptr %l123, !tbaa !29
  %t242 = load i64, ptr %l126, !tbaa !24
  %t243 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t241, i64 %t242)
  store i1 %t243, ptr %l127
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t244 = load ptr, ptr %lp14
  %t245 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t244
  call void @__olang_scope_close(ptr %s7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t245, ptr %rv
  br label %ret
bb61:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t248 = load ptr, ptr %l129, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb62, label %bb63
bb62:
  %t251 = load ptr, ptr %l129, !tbaa !29
  %t252 = load i64, ptr %t251
  %t254 = icmp eq i64 %t252, 5
  store i1 %t254, ptr %l130, !tbaa !21
  br label %bb63
bb63:
  %t255 = load i1, ptr %l130, !tbaa !21
  br i1 %t255, label %bb64, label %bb65
bb64:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [4 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l16, !tbaa !29
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load ptr, ptr %l16, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Payload", ptr %t263, i32 0, i32 0
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t269 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t262, ptr %t266)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %l138
  br label %bb67
bb67:
  %t270 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l138
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t270, ptr %rv
  br label %ret
bb68:
  %t271 = load ptr, ptr %l1, !tbaa !29
  store ptr %t271, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t272 = load ptr, ptr %l139, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = load ptr, ptr %l139, !tbaa !29
  %t276 = load i64, ptr %t275
  %t278 = icmp eq i64 %t276, 6
  store i1 %t278, ptr %l140, !tbaa !21
  br label %bb70
bb70:
  %t279 = load i1, ptr %l140, !tbaa !21
  br i1 %t279, label %bb71, label %bb72
bb71:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t282, i32 0, i32 2
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l17, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l17, !tbaa !29
  %t290 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t286, ptr %t287)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t290, ptr %l147
  br label %bb74
bb74:
  %t291 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l147
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t291, ptr %rv
  br label %ret
bb75:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t293 = load ptr, ptr %l148, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb76, label %bb77
bb76:
  %t296 = load ptr, ptr %l148, !tbaa !29
  %t297 = load i64, ptr %t296
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l149, !tbaa !21
  br label %bb77
bb77:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb89
bb80:
  %t301 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t301, ptr %l152
  br label %bb81
bb81:
  %t302 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t302, ptr %lp18
  %t303 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l152
  %t304 = load ptr, ptr %lp18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t303, ptr %t304
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/free:walker", ptr %t305, i32 0, i32 9
  %t309 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t307)
  store i64 %t309, ptr %l155
  br label %bb82
bb82:
  %t310 = load i64, ptr %l155, !tbaa !24
  %t311 = icmp sgt i64 %t310, 0
  br i1 %t311, label %bb83, label %bb84
bb83:
  %t313 = load ptr, ptr %l0, !tbaa !29
  store ptr %t313, ptr %l157, !tbaa !29
  %t314 = load ptr, ptr %l157, !tbaa !29
  %t315 = getelementptr %"compiler/free:walker", ptr %t314, i32 0, i32 29
  %t316 = load i64, ptr %t315, !tbaa !24
  %t318 = add i64 %t316, 1
  %t320 = load ptr, ptr %l157, !tbaa !29
  %t321 = getelementptr %"compiler/free:walker", ptr %t320, i32 0, i32 29
  store i64 %t318, ptr %t321, !tbaa !24
  %t322 = load ptr, ptr %l0, !tbaa !29
  store ptr %t322, ptr %l160, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:walker", ptr %t323, i32 0, i32 9
  store ptr %t325, ptr %l162, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 9
  %t330 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %t328)
  store i64 %t330, ptr %l165
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t331 = load i64, ptr %l165, !tbaa !24
  %t332 = sub i64 %t331, 1
  %t333 = load ptr, ptr %l162, !tbaa !29
  %t335 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v0, ptr %t333, i64 %t332)
  store ptr %t335, ptr %l167
  br label %bb86
bb86:
  %t336 = load ptr, ptr %l160, !tbaa !29
  %t337 = load ptr, ptr %l167, !tbaa !29
  %t338 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v0, ptr %v2, ptr %t336, ptr %t337)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t338, ptr %l168
  br label %bb87
bb87:
  %t339 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l168
  %t340 = load ptr, ptr %lp18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t339, ptr %t340
  %t341 = load ptr, ptr %l0, !tbaa !29
  store ptr %t341, ptr %l169, !tbaa !29
  %t342 = load ptr, ptr %l169, !tbaa !29
  %t343 = getelementptr %"compiler/free:walker", ptr %t342, i32 0, i32 29
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = sub i64 %t344, 1
  %t348 = load ptr, ptr %l169, !tbaa !29
  %t349 = getelementptr %"compiler/free:walker", ptr %t348, i32 0, i32 29
  store i64 %t346, ptr %t349, !tbaa !24
  br label %bb88
bb88:
  %t350 = load ptr, ptr %lp18
  %t351 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t350
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t353 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t353, ptr %l173
  br label %bb93
bb93:
  %t354 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l173
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t354, ptr %rv
  br label %ret
bb94:
  call void @__olang_check_failed(ptr @olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3)
  unreachable
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2esameValue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ederefRoot(ptr %v2, ptr %a2)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t14 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v1, ptr %v2, ptr %a1, ptr %t11)
  store i1 %t14, ptr %l11
  br label %bb5
bb5:
  %t15 = load i1, ptr %l11, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca ptr
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca i64
  %l52 = alloca ptr
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l68 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca i64
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i32
  %l114 = alloca ptr
  %l115 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l148 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l163 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca i1
  %l191 = alloca ptr
  %l201 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l229 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l237 = alloca i1
  %l243 = alloca i1
  %l245 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca i32
  %l258 = alloca { i64, ptr }
  %l262 = alloca i64
  %l265 = alloca i1
  %l267 = alloca ptr
  %l269 = alloca i64
  %l270 = alloca i1
  %l272 = alloca ptr
  %l274 = alloca i64
  %l283 = alloca ptr
  %l284 = alloca i1
  %l289 = alloca ptr
  %l290 = alloca i64
  %l291 = alloca i64
  %l292 = alloca %"compiler/source:Span"
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca ptr
  %l295 = alloca i1
  %l304 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l310 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l311 = alloca ptr
  %l312 = alloca i1
  %l322 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l323 = alloca ptr
  %l324 = alloca i1
  %l331 = alloca ptr
  %l332 = alloca i1
  %l338 = alloca ptr
  %l344 = alloca %"compiler/typed:BlockInfo"
  %l350 = alloca ptr
  %l358 = alloca i64
  %l361 = alloca i64
  %l362 = alloca i32
  %l363 = alloca ptr
  %l366 = alloca ptr
  %l367 = alloca i1
  %l385 = alloca { i64, ptr }
  %l392 = alloca ptr
  %l400 = alloca ptr
  %l401 = alloca i1
  %l413 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l416 = alloca i1
  %l422 = alloca i1
  %l435 = alloca { i64, ptr }
  %l442 = alloca ptr
  %l448 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l451 = alloca ptr
  %l452 = alloca i1
  %l461 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l464 = alloca i64
  %l467 = alloca ptr
  %l470 = alloca i64
  %l472 = alloca ptr
  %l474 = alloca i1
  %l477 = alloca i64
  %l480 = alloca ptr
  %l483 = alloca i64
  %l485 = alloca i64
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 11
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l52, !tbaa !29
  %t7 = load ptr, ptr %l52, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 11
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = add i64 %t9, 1
  %t13 = load ptr, ptr %l52, !tbaa !29
  %t14 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 11
  store i64 %t11, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/free:walker", ptr %t15, i32 0, i32 13
  %t18 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 12
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 33
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 12
  store i64 %t32, ptr %t35, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l64, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v1, ptr %t37)
  store %"compiler/source:Span" %t39, ptr %l66
  br label %bb2
bb2:
  %t40 = load %"compiler/source:Span", ptr %l66
  %t41 = load ptr, ptr %l64, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 33
  store %"compiler/source:Span" %t40, ptr %t42
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t44 = load ptr, ptr %l67, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb3, label %bb4
bb3:
  %t47 = load ptr, ptr %l67, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 0
  store i1 %t50, ptr %l68, !tbaa !21
  br label %bb4
bb4:
  %t51 = load i1, ptr %l68, !tbaa !21
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [3 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 0
  %t56 = load %"compiler/source:Span", ptr %t55
  store %"compiler/source:Span" %t56, ptr %l5
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61
  store i32 %t62, ptr %l6, !tbaa !23
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [3 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l7, !tbaa !29
  br label %bb7
bb6:
  br label %bb22
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 20
  %t73 = load i32, ptr %l6, !tbaa !23
  %t75 = sext i32 %t73 to i64
  %t76 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t72, i64 %t75, i64 %t76)
  br label %bb8
bb8:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 21
  store ptr %t82, ptr %l83, !tbaa !29
  %t83 = load i32, ptr %l6, !tbaa !23
  %t85 = sext i32 %t83 to i64
  store i64 %t85, ptr %l85, !tbaa !24
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t86)
  store %"compiler/source:Span" %t88, ptr %l87
  br label %bb9
bb9:
  %t89 = load ptr, ptr %l83, !tbaa !29
  %t90 = load i64, ptr %l85, !tbaa !24
  %t91 = load %"compiler/source:Span", ptr %l87
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t89, i64 %t90, %"compiler/source:Span" %t91)
  br label %bb10
bb10:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l7, !tbaa !29
  %t96 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s1, ptr %t92, ptr %t93)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l90
  br label %bb11
bb11:
  %t97 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l8
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i32, ptr %l6, !tbaa !23
  %t101 = sext i32 %t99 to i64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s1, ptr %t98, i64 %t101, ptr %l8)
  br label %bb12
bb12:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 7
  %t108 = load i32, ptr %l6, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t113 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t107, i64 %t110)
  %t114 = extractvalue { i32, i64 } %t113, 1
  %t115 = extractvalue { i32, i64 } %t113, 0
  store i32 %t115, ptr %l101
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb14, label %ok.117
ok.117:
  store i64 %t114, ptr %l100
  br label %bb13
bb13:
  %t118 = load i64, ptr %l100, !tbaa !24
  store i64 %t118, ptr %l95, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l95, !tbaa !24
  br label %bb16
bb16:
  %t119 = load i64, ptr %l95, !tbaa !24
  store i64 %t119, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sge i64 %t120, 0
  br i1 %t122, label %bb17, label %bb18
bb17:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load i64, ptr %l9, !tbaa !24
  %t126 = load ptr, ptr %l7, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %s1, ptr %t124, i64 %t125, ptr %t126, ptr %l8, %"compiler/source:Span" %t127)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l6, !tbaa !23
  %t136 = sext i32 %t134 to i64
  %t137 = load ptr, ptr %l7, !tbaa !29
  %t138 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyStore(ptr %v0, ptr %v1, ptr %t133, i64 %t136, ptr %t137, %"compiler/source:Span" %t138)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb257
bb22:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t144 = load ptr, ptr %l114, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb23, label %bb24
bb23:
  %t147 = load ptr, ptr %l114, !tbaa !29
  %t148 = load i64, ptr %t147
  %t150 = icmp eq i64 %t148, 1
  store i1 %t150, ptr %l115, !tbaa !21
  br label %bb24
bb24:
  %t151 = load i1, ptr %l115, !tbaa !21
  br i1 %t151, label %bb25, label %bb26
bb25:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t154, i32 0, i32 0
  %t156 = load %"compiler/source:Span", ptr %t155
  store %"compiler/source:Span" %t156, ptr %l10
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l11, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t166, i32 0, i32 2
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l12, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l10
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t173 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t170, %"compiler/source:Span" %t171, ptr %t172, ptr %t173)
  br label %bb28
bb28:
  br label %bb257
bb29:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t179 = load ptr, ptr %l128, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb30, label %bb31
bb30:
  %t182 = load ptr, ptr %l128, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 2
  store i1 %t185, ptr %l129, !tbaa !21
  br label %bb31
bb31:
  %t186 = load i1, ptr %l129, !tbaa !21
  br i1 %t186, label %bb32, label %bb33
bb32:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [3 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr }, ptr %t189, i32 0, i32 0
  %t191 = load %"compiler/source:Span", ptr %t190
  store %"compiler/source:Span" %t191, ptr %l13
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [3 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l14, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l13
  %t201 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %t199, %"compiler/source:Span" %t200, ptr %t201)
  br label %bb35
bb35:
  br label %bb257
bb36:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t206 = load ptr, ptr %l139, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l139, !tbaa !29
  %t210 = load i64, ptr %t209
  %t212 = icmp eq i64 %t210, 3
  store i1 %t212, ptr %l140, !tbaa !21
  br label %bb38
bb38:
  %t213 = load i1, ptr %l140, !tbaa !21
  br i1 %t213, label %bb39, label %bb40
bb39:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [3 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", ptr }, ptr %t216, i32 0, i32 1
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l15, !tbaa !29
  br label %bb41
bb40:
  br label %bb55
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l15, !tbaa !29
  %t223 = getelementptr %"compiler/typed:If", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t220, ptr %t224)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t227, ptr %l148
  br label %bb42
bb42:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/free:walker", ptr %t228, i32 0, i32 11
  %t231 = load i64, ptr %t230, !tbaa !24
  store i64 %t231, ptr %l16, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l15, !tbaa !29
  %t236 = getelementptr %"compiler/typed:If", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t233, ptr %t237)
  br label %bb43
bb43:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:walker", ptr %t240, i32 0, i32 11
  %t243 = load i64, ptr %t242, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l17, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:walker", ptr %t247, i32 0, i32 11
  %t250 = load i64, ptr %t249, !tbaa !24
  store i64 %t250, ptr %l18, !tbaa !24
  %t252 = load ptr, ptr %l15, !tbaa !29
  %t254 = getelementptr %"compiler/typed:If", ptr %t252, i32 0, i32 2
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = icmp eq ptr %t255, null
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb44, label %bb45
bb44:
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l163, !tbaa !29
  %t262 = load ptr, ptr %l15, !tbaa !29
  %t264 = getelementptr %"compiler/typed:If", ptr %t262, i32 0, i32 2
  %t265 = load ptr, ptr %t264, !tbaa !29
  %t267 = icmp eq ptr %t265, null
  br i1 %t267, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_d8246f320a19bbf9_8add34a618744eed)
  unreachable
bb47:
  br label %bb48
bb48:
  %t269 = load ptr, ptr %l15, !tbaa !29
  %t271 = getelementptr %"compiler/typed:If", ptr %t269, i32 0, i32 2
  %t272 = load ptr, ptr %t271, !tbaa !29
  %t273 = load ptr, ptr %l163, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t273, ptr %t272)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/free:walker", ptr %t275, i32 0, i32 16
  %t278 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t277, i64 %t278)
  br label %bb51
bb51:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/free:walker", ptr %t281, i32 0, i32 17
  %t284 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t283, i64 %t284)
  br label %bb52
bb52:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/free:walker", ptr %t287, i32 0, i32 18
  %t290 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t289, i64 %t290)
  br label %bb53
bb53:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/free:walker", ptr %t293, i32 0, i32 19
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/free:walker", ptr %t296, i32 0, i32 11
  %t299 = load i64, ptr %t298, !tbaa !24
  %t301 = sub i64 %t299, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t295, i64 %t301)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb257
bb55:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t305 = load ptr, ptr %l183, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb56, label %bb57
bb56:
  %t308 = load ptr, ptr %l183, !tbaa !29
  %t309 = load i64, ptr %t308
  %t311 = icmp eq i64 %t309, 4
  store i1 %t311, ptr %l184, !tbaa !21
  br label %bb57
bb57:
  %t312 = load i1, ptr %l184, !tbaa !21
  br i1 %t312, label %bb58, label %bb59
bb58:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [3 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t315, i32 0, i32 1
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l19, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [3 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t321, i32 0, i32 2
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l20, !tbaa !29
  br label %bb60
bb59:
  br label %bb68
bb60:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l191, !tbaa !29
  %t326 = load ptr, ptr %l191, !tbaa !29
  %t327 = getelementptr %"compiler/free:walker", ptr %t326, i32 0, i32 23
  %t328 = load i64, ptr %t327, !tbaa !24
  %t330 = add i64 %t328, 1
  %t332 = load ptr, ptr %l191, !tbaa !29
  %t333 = getelementptr %"compiler/free:walker", ptr %t332, i32 0, i32 23
  store i64 %t330, ptr %t333, !tbaa !24
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t334, ptr %t335)
  br label %bb61
bb61:
  %t338 = load ptr, ptr %l20, !tbaa !29
  %t340 = icmp eq ptr %t338, null
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb62, label %bb63
bb62:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t344, ptr %t345)
  br label %bb64
bb63:
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l201, !tbaa !29
  %t349 = load ptr, ptr %l201, !tbaa !29
  %t350 = getelementptr %"compiler/free:walker", ptr %t349, i32 0, i32 23
  %t351 = load i64, ptr %t350, !tbaa !24
  %t353 = sub i64 %t351, 1
  %t355 = load ptr, ptr %l201, !tbaa !29
  %t356 = getelementptr %"compiler/free:walker", ptr %t355, i32 0, i32 23
  store i64 %t353, ptr %t356, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/free:walker", ptr %t357, i32 0, i32 14
  %t360 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t359, i64 %t360)
  br label %bb66
bb66:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/free:walker", ptr %t363, i32 0, i32 15
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/free:walker", ptr %t366, i32 0, i32 11
  %t369 = load i64, ptr %t368, !tbaa !24
  %t371 = sub i64 %t369, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t365, i64 %t371)
  br label %bb67
bb67:
  br label %bb257
bb68:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l212, !tbaa !29
  store i1 false, ptr %l213, !tbaa !21
  %t375 = load ptr, ptr %l212, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb69, label %bb70
bb69:
  %t378 = load ptr, ptr %l212, !tbaa !29
  %t379 = load i64, ptr %t378
  %t381 = icmp eq i64 %t379, 6
  store i1 %t381, ptr %l213, !tbaa !21
  br label %bb70
bb70:
  %t382 = load i1, ptr %l213, !tbaa !21
  br i1 %t382, label %bb71, label %bb72
bb71:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr }, ptr %t385, i32 0, i32 1
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l21, !tbaa !29
  br label %bb77
bb72:
  %t389 = load ptr, ptr %l1, !tbaa !29
  store ptr %t389, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t390 = load ptr, ptr %l218, !tbaa !29
  %t391 = icmp ne ptr %t390, null
  br i1 %t391, label %bb73, label %bb74
bb73:
  %t393 = load ptr, ptr %l218, !tbaa !29
  %t394 = load i64, ptr %t393
  %t396 = icmp eq i64 %t394, 16
  store i1 %t396, ptr %l219, !tbaa !21
  br label %bb74
bb74:
  %t397 = load i1, ptr %l219, !tbaa !21
  br i1 %t397, label %bb75, label %bb76
bb75:
  %t398 = load ptr, ptr %l1, !tbaa !29
  %t400 = getelementptr { i64, [3 x i64] }, ptr %t398, i32 0, i32 1
  %t401 = getelementptr { %"compiler/source:Span", ptr }, ptr %t400, i32 0, i32 1
  %t402 = load ptr, ptr %t401
  store ptr %t402, ptr %l21, !tbaa !29
  br label %bb77
bb76:
  br label %bb133
bb77:
  %t404 = load ptr, ptr %l21, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s10
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l21, !tbaa !29
  %t414 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s10, ptr %t410, ptr %t411)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t414, ptr %l229
  br label %bb80
bb79:
  br label %bb119
bb80:
  %t415 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l229
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t415, ptr %l22
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/free:walker", ptr %t416, i32 0, i32 2
  %t419 = load i1, ptr %t418, !tbaa !21
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb81, label %bb82
bb81:
  %t423 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %s10, ptr %t423, ptr %l22)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/free:walker", ptr %t426, i32 0, i32 2
  %t429 = load i1, ptr %t428, !tbaa !21
  br i1 %t429, label %bb85, label %bb86
bb85:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/free:walker", ptr %t431, i32 0, i32 0
  %t434 = load ptr, ptr %t433, !tbaa !29
  %t436 = getelementptr %"compiler/free:Free", ptr %t434, i32 0, i32 61
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/free:walker", ptr %t437, i32 0, i32 1
  %t440 = load i64, ptr %t439, !tbaa !24
  %t443 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t436, i64 %t440)
  store i1 %t443, ptr %l243
  br label %bb87
bb86:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb88
bb87:
  %t444 = load i1, ptr %l243, !tbaa !21
  store i1 %t444, ptr %l237, !tbaa !21
  br label %bb88
bb88:
  %t445 = load i1, ptr %l237, !tbaa !21
  br i1 %t445, label %bb89, label %bb90
bb89:
  store ptr %l22, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb91
bb90:
  br label %bb118
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t447 = load ptr, ptr %l23, !tbaa !29
  %t448 = load i64, ptr %l24, !tbaa !24
  %t451 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s10, ptr %t447, i64 %t448)
  %t452 = extractvalue { i32, { i64, ptr } } %t451, 1
  %t453 = extractvalue { i32, { i64, ptr } } %t451, 0
  store i32 %t453, ptr %l249
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb93, label %ok.455
ok.455:
  store { i64, ptr } %t452, ptr %l248
  br label %bb92
bb92:
  %t456 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t456, ptr %l245, !tbaa !27
  br label %bb97
bb93:
  %t457 = load i32, ptr %l249, !tbaa !23
  %t458 = ashr i32 %t457, 16
  %t460 = icmp eq i32 %t458, 1
  br i1 %t460, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_5d7536cc463ccac1_135a9313c745645)
  unreachable
bb96:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb117
bb97:
  %t462 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t462, ptr %l25, !tbaa !27
  %t463 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t463, 0
  store i64 %t465, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s15
  %t467 = load i64, ptr %l27, !tbaa !24
  %t468 = load i64, ptr %l26, !tbaa !24
  %t471 = icmp slt i64 %t467, %t468
  %t473 = xor i1 %t471, true
  br i1 %t473, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s15)
  br label %bb115
bb100:
  br label %bb101
bb101:
  %t475 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t475, ptr %l258, !tbaa !27
  %t476 = load i64, ptr %l27, !tbaa !24
  %t478 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr i64, ptr %t479, i64 %t476
  %t481 = load i64, ptr %t480, !tbaa !34
  store i64 %t481, ptr %l28, !tbaa !24
  %t483 = load i64, ptr %l28, !tbaa !24
  %t485 = call i64 @compiler_2ffree_2eokind(i64 %t483)
  store i64 %t485, ptr %l262
  br label %bb102
bb102:
  %t486 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t487 = load i64, ptr %l262, !tbaa !24
  %t489 = icmp eq i64 %t487, %t486
  br i1 %t489, label %bb103, label %bb104
bb103:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/free:walker", ptr %t491, i32 0, i32 0
  %t494 = load ptr, ptr %t493, !tbaa !29
  store ptr %t494, ptr %l267, !tbaa !29
  %t495 = load i64, ptr %l28, !tbaa !24
  %t497 = call i64 @compiler_2ffree_2eoval(i64 %t495)
  store i64 %t497, ptr %l269
  br label %bb105
bb104:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb107
bb105:
  %t498 = load ptr, ptr %l267, !tbaa !29
  %t499 = load i64, ptr %l269, !tbaa !24
  %t500 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t498, i64 %t499)
  store i1 %t500, ptr %l270
  br label %bb106
bb106:
  %t501 = load i1, ptr %l270, !tbaa !21
  store i1 %t501, ptr %l265, !tbaa !21
  br label %bb107
bb107:
  %t502 = load i1, ptr %l265, !tbaa !21
  br i1 %t502, label %bb108, label %bb109
bb108:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/free:walker", ptr %t503, i32 0, i32 49
  store ptr %t505, ptr %l272, !tbaa !29
  %t506 = load i64, ptr %l28, !tbaa !24
  %t508 = call i64 @compiler_2ffree_2eoval(i64 %t506)
  store i64 %t508, ptr %l274
  br label %bb110
bb109:
  br label %bb113
bb110:
  %t509 = load ptr, ptr %l272, !tbaa !29
  %t510 = load i64, ptr %l274, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t509, i64 %t510)
  br label %bb111
bb111:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/free:walker", ptr %t511, i32 0, i32 50
  %t514 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t513, i64 %t514)
  br label %bb112
bb112:
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s15)
  br label %bb114
bb114:
  %t517 = load i64, ptr %l27, !tbaa !24
  %t519 = add i64 %t517, 1
  store i64 %t519, ptr %l27, !tbaa !24
  br label %bb98
bb115:
  %t521 = load i64, ptr %l24, !tbaa !24
  %t522 = load i64, ptr %l26, !tbaa !24
  %t525 = add i64 %t521, %t522
  store i64 %t525, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb116
bb116:
  br label %bb91
bb117:
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s10)
  br label %bb119
bb119:
  %t527 = load ptr, ptr %l1, !tbaa !29
  store ptr %t527, ptr %l283, !tbaa !29
  store i1 false, ptr %l284, !tbaa !21
  %t528 = load ptr, ptr %l283, !tbaa !29
  %t529 = icmp ne ptr %t528, null
  br i1 %t529, label %bb120, label %bb121
bb120:
  %t531 = load ptr, ptr %l283, !tbaa !29
  %t532 = load i64, ptr %t531
  %t534 = icmp eq i64 %t532, 16
  store i1 %t534, ptr %l284, !tbaa !21
  br label %bb121
bb121:
  %t535 = load i1, ptr %l284, !tbaa !21
  br i1 %t535, label %bb122, label %bb123
bb122:
  %t536 = load ptr, ptr %l1, !tbaa !29
  %t538 = getelementptr { i64, [3 x i64] }, ptr %t536, i32 0, i32 1
  %t539 = getelementptr { %"compiler/source:Span", ptr }, ptr %t538, i32 0, i32 0
  %t540 = load %"compiler/source:Span", ptr %t539
  store %"compiler/source:Span" %t540, ptr %l29
  br label %bb124
bb123:
  br label %bb127
bb124:
  store %olang.scope zeroinitializer, ptr %s18
  %t542 = load ptr, ptr %l0, !tbaa !29
  store ptr %t542, ptr %l289, !tbaa !29
  %t543 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t543, ptr %l290, !tbaa !24
  %t544 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  store i64 %t544, ptr %l291, !tbaa !24
  %t545 = load %"compiler/source:Span", ptr %l29
  store %"compiler/source:Span" %t545, ptr %l292
  %t546 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s18, i32 0, i32 0)
  store %"compiler/source:Span" %t546, ptr %l293
  br label %bb125
bb125:
  %t547 = load ptr, ptr %l289, !tbaa !29
  %t548 = load i64, ptr %l290, !tbaa !24
  %t549 = load i64, ptr %l291, !tbaa !24
  %t550 = load %"compiler/source:Span", ptr %l292
  %t551 = load %"compiler/source:Span", ptr %l293
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t547, i64 %t548, i64 %t549, %"compiler/source:Span" %t550, %"compiler/source:Span" %t551, i64 -1)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s18)
  br label %bb132
bb127:
  br i1 true, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_c29efbd07efcecaa_a09dc8518182978e)
  unreachable
bb132:
  br label %bb257
bb133:
  %t552 = load ptr, ptr %l1, !tbaa !29
  store ptr %t552, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t553 = load ptr, ptr %l294, !tbaa !29
  %t554 = icmp ne ptr %t553, null
  br i1 %t554, label %bb134, label %bb135
bb134:
  %t556 = load ptr, ptr %l294, !tbaa !29
  %t557 = load i64, ptr %t556
  %t559 = icmp eq i64 %t557, 10
  store i1 %t559, ptr %l295, !tbaa !21
  br label %bb135
bb135:
  %t560 = load i1, ptr %l295, !tbaa !21
  br i1 %t560, label %bb136, label %bb137
bb136:
  %t561 = load ptr, ptr %l1, !tbaa !29
  %t563 = getelementptr { i64, [3 x i64] }, ptr %t561, i32 0, i32 1
  %t564 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t563, i32 0, i32 1
  %t565 = load ptr, ptr %t564
  store ptr %t565, ptr %l30, !tbaa !29
  %t567 = load ptr, ptr %l1, !tbaa !29
  %t569 = getelementptr { i64, [3 x i64] }, ptr %t567, i32 0, i32 1
  %t570 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t569, i32 0, i32 2
  %t571 = load ptr, ptr %t570
  store ptr %t571, ptr %l31, !tbaa !29
  br label %bb138
bb137:
  br label %bb144
bb138:
  store %olang.scope zeroinitializer, ptr %s20
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t574 = load ptr, ptr %l30, !tbaa !29
  %t577 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s20, ptr %t573, ptr %t574)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t577, ptr %l304
  br label %bb139
bb139:
  %t578 = load ptr, ptr %l31, !tbaa !29
  %t580 = icmp eq ptr %t578, null
  %t582 = xor i1 %t580, true
  br i1 %t582, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s21
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load ptr, ptr %l31, !tbaa !29
  %t588 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t584, ptr %t585)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t588, ptr %l310
  br label %bb142
bb141:
  br label %bb143
bb142:
  call void @__olang_scope_close(ptr %s21)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s20)
  br label %bb257
bb144:
  %t589 = load ptr, ptr %l1, !tbaa !29
  store ptr %t589, ptr %l311, !tbaa !29
  store i1 false, ptr %l312, !tbaa !21
  %t590 = load ptr, ptr %l311, !tbaa !29
  %t591 = icmp ne ptr %t590, null
  br i1 %t591, label %bb145, label %bb146
bb145:
  %t593 = load ptr, ptr %l311, !tbaa !29
  %t594 = load i64, ptr %t593
  %t596 = icmp eq i64 %t594, 9
  store i1 %t596, ptr %l312, !tbaa !21
  br label %bb146
bb146:
  %t597 = load i1, ptr %l312, !tbaa !21
  br i1 %t597, label %bb147, label %bb148
bb147:
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t600 = getelementptr { i64, [3 x i64] }, ptr %t598, i32 0, i32 1
  %t601 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t600, i32 0, i32 2
  %t602 = load ptr, ptr %t601
  store ptr %t602, ptr %l32, !tbaa !29
  br label %bb149
bb148:
  br label %bb154
bb149:
  %t604 = load ptr, ptr %l32, !tbaa !29
  %t606 = icmp eq ptr %t604, null
  %t608 = xor i1 %t606, true
  br i1 %t608, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s23
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load ptr, ptr %l32, !tbaa !29
  %t614 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s23, ptr %t610, ptr %t611)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t614, ptr %l322
  br label %bb152
bb151:
  br label %bb153
bb152:
  call void @__olang_scope_close(ptr %s23)
  br label %bb153
bb153:
  br label %bb257
bb154:
  %t615 = load ptr, ptr %l1, !tbaa !29
  store ptr %t615, ptr %l323, !tbaa !29
  store i1 false, ptr %l324, !tbaa !21
  %t616 = load ptr, ptr %l323, !tbaa !29
  %t617 = icmp ne ptr %t616, null
  br i1 %t617, label %bb155, label %bb156
bb155:
  %t619 = load ptr, ptr %l323, !tbaa !29
  %t620 = load i64, ptr %t619
  %t622 = icmp eq i64 %t620, 11
  store i1 %t622, ptr %l324, !tbaa !21
  br label %bb156
bb156:
  %t623 = load i1, ptr %l324, !tbaa !21
  br i1 %t623, label %bb157, label %bb158
bb157:
  %t624 = load ptr, ptr %l1, !tbaa !29
  %t626 = getelementptr { i64, [3 x i64] }, ptr %t624, i32 0, i32 1
  %t627 = getelementptr { %"compiler/source:Span", ptr }, ptr %t626, i32 0, i32 1
  %t628 = load ptr, ptr %t627
  store ptr %t628, ptr %l33, !tbaa !29
  br label %bb159
bb158:
  br label %bb161
bb159:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t631 = load ptr, ptr %l33, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t630, ptr %t631)
  br label %bb160
bb160:
  br label %bb257
bb161:
  %t634 = load ptr, ptr %l1, !tbaa !29
  store ptr %t634, ptr %l331, !tbaa !29
  store i1 false, ptr %l332, !tbaa !21
  %t635 = load ptr, ptr %l331, !tbaa !29
  %t636 = icmp ne ptr %t635, null
  br i1 %t636, label %bb162, label %bb163
bb162:
  %t638 = load ptr, ptr %l331, !tbaa !29
  %t639 = load i64, ptr %t638
  %t641 = icmp eq i64 %t639, 12
  store i1 %t641, ptr %l332, !tbaa !21
  br label %bb163
bb163:
  %t642 = load i1, ptr %l332, !tbaa !21
  br i1 %t642, label %bb164, label %bb165
bb164:
  %t643 = load ptr, ptr %l1, !tbaa !29
  %t645 = getelementptr { i64, [3 x i64] }, ptr %t643, i32 0, i32 1
  %t646 = getelementptr { %"compiler/source:Span", ptr }, ptr %t645, i32 0, i32 1
  %t647 = load ptr, ptr %t646
  store ptr %t647, ptr %l34, !tbaa !29
  br label %bb166
bb165:
  br label %bb179
bb166:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t651 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t649)
  store ptr %t651, ptr %l338
  br label %bb167
bb167:
  %t652 = load ptr, ptr %l338, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Body", ptr %t652, i32 0, i32 8
  %t655 = load ptr, ptr %l34, !tbaa !29
  %t657 = getelementptr %"compiler/typed:Block", ptr %t655, i32 0, i32 0
  %t658 = load i32, ptr %t657, !tbaa !23
  %t660 = sext i32 %t658 to i64
  %t663 = call %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %t654, i64 %t660)
  store %"compiler/typed:BlockInfo" %t663, ptr %l344
  br label %bb168
bb168:
  %t664 = getelementptr %"compiler/typed:BlockInfo", ptr %l344, i32 0, i32 1
  %t665 = load i32, ptr %t664
  %t667 = trunc i64 7 to i32
  %t668 = icmp eq i32 %t665, %t667
  br i1 %t668, label %bb169, label %bb170
bb169:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/free:walker", ptr %t670, i32 0, i32 57
  %t673 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t672, i64 %t673)
  br label %bb171
bb170:
  br label %bb172
bb171:
  br label %bb172
bb172:
  %t676 = load ptr, ptr %l0, !tbaa !29
  store ptr %t676, ptr %l350, !tbaa !29
  %t677 = load ptr, ptr %l350, !tbaa !29
  %t678 = getelementptr %"compiler/free:walker", ptr %t677, i32 0, i32 28
  %t679 = load i64, ptr %t678, !tbaa !24
  %t681 = add i64 %t679, 1
  %t683 = load ptr, ptr %l350, !tbaa !29
  %t684 = getelementptr %"compiler/free:walker", ptr %t683, i32 0, i32 28
  store i64 %t681, ptr %t684, !tbaa !24
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t687 = getelementptr %"compiler/free:walker", ptr %t685, i32 0, i32 52
  %t688 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t687, i64 %t688)
  br label %bb173
bb173:
  %t691 = load ptr, ptr %l0, !tbaa !29
  %t692 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t691, ptr %t692)
  br label %bb174
bb174:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = getelementptr %"compiler/free:walker", ptr %t695, i32 0, i32 52
  %t699 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t697)
  %t700 = extractvalue { i32, i64 } %t699, 1
  %t701 = extractvalue { i32, i64 } %t699, 0
  store i32 %t701, ptr %l362
  %t702 = icmp ne i32 %t701, 0
  br i1 %t702, label %bb176, label %ok.703
ok.703:
  store i64 %t700, ptr %l361
  br label %bb175
bb175:
  %t704 = load i64, ptr %l361, !tbaa !24
  store i64 %t704, ptr %l358, !tbaa !24
  br label %bb178
bb176:
  br label %bb177
bb177:
  call void @__olang_ert_req_clear()
  br label %bb178
bb178:
  %t705 = load ptr, ptr %l0, !tbaa !29
  store ptr %t705, ptr %l363, !tbaa !29
  %t706 = load ptr, ptr %l363, !tbaa !29
  %t707 = getelementptr %"compiler/free:walker", ptr %t706, i32 0, i32 28
  %t708 = load i64, ptr %t707, !tbaa !24
  %t710 = sub i64 %t708, 1
  %t712 = load ptr, ptr %l363, !tbaa !29
  %t713 = getelementptr %"compiler/free:walker", ptr %t712, i32 0, i32 28
  store i64 %t710, ptr %t713, !tbaa !24
  br label %bb257
bb179:
  %t714 = load ptr, ptr %l1, !tbaa !29
  store ptr %t714, ptr %l366, !tbaa !29
  store i1 false, ptr %l367, !tbaa !21
  %t715 = load ptr, ptr %l366, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb180, label %bb181
bb180:
  %t718 = load ptr, ptr %l366, !tbaa !29
  %t719 = load i64, ptr %t718
  %t721 = icmp eq i64 %t719, 13
  store i1 %t721, ptr %l367, !tbaa !21
  br label %bb181
bb181:
  %t722 = load i1, ptr %l367, !tbaa !21
  br i1 %t722, label %bb182, label %bb183
bb182:
  %t723 = load ptr, ptr %l1, !tbaa !29
  %t725 = getelementptr { i64, [3 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { %"compiler/source:Span", ptr }, ptr %t725, i32 0, i32 1
  %t727 = load ptr, ptr %t726
  store ptr %t727, ptr %l35, !tbaa !29
  br label %bb184
bb183:
  br label %bb199
bb184:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/free:walker", ptr %t729, i32 0, i32 0
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = getelementptr %"compiler/free:Free", ptr %t732, i32 0, i32 31
  store i1 true, ptr %t734, !tbaa !21
  %t735 = load ptr, ptr %l0, !tbaa !29
  %t736 = load ptr, ptr %l35, !tbaa !29
  %t738 = getelementptr %"compiler/typed:Join", ptr %t736, i32 0, i32 0
  %t739 = load ptr, ptr %t738, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t735, ptr %t739)
  br label %bb185
bb185:
  %t742 = load ptr, ptr %l35, !tbaa !29
  %t744 = getelementptr %"compiler/typed:Join", ptr %t742, i32 0, i32 2
  %t745 = load { i64, ptr }, ptr %t744, !tbaa !27
  store { i64, ptr } %t745, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t747 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t747, 0
  store i64 %t749, ptr %l38, !tbaa !24
  br label %bb186
bb186:
  store %olang.scope zeroinitializer, ptr %s30
  %t751 = load i64, ptr %l37, !tbaa !24
  %t752 = load i64, ptr %l38, !tbaa !24
  %t755 = icmp slt i64 %t751, %t752
  %t757 = xor i1 %t755, true
  br i1 %t757, label %bb187, label %bb188
bb187:
  call void @__olang_scope_close(ptr %s30)
  br label %bb198
bb188:
  br label %bb189
bb189:
  %t759 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t759, ptr %l385, !tbaa !27
  %t760 = load i64, ptr %l37, !tbaa !24
  %t762 = getelementptr { i64, ptr }, ptr %l385, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = getelementptr ptr, ptr %t763, i64 %t760
  %t765 = load ptr, ptr %t764, !tbaa !39
  store ptr %t765, ptr %l39, !tbaa !29
  %t767 = load ptr, ptr %l39, !tbaa !29
  %t769 = getelementptr %"compiler/typed:Clause", ptr %t767, i32 0, i32 3
  %t770 = load ptr, ptr %t769, !tbaa !29
  %t772 = icmp eq ptr %t770, null
  %t774 = xor i1 %t772, true
  br i1 %t774, label %bb190, label %bb191
bb190:
  %t776 = load ptr, ptr %l0, !tbaa !29
  store ptr %t776, ptr %l392, !tbaa !29
  %t777 = load ptr, ptr %l39, !tbaa !29
  %t779 = getelementptr %"compiler/typed:Clause", ptr %t777, i32 0, i32 3
  %t780 = load ptr, ptr %t779, !tbaa !29
  %t782 = icmp eq ptr %t780, null
  br i1 %t782, label %bb192, label %bb193
bb191:
  br label %bb196
bb192:
  call void @__olang_check_failed(ptr @olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8)
  unreachable
bb193:
  br label %bb194
bb194:
  %t784 = load ptr, ptr %l39, !tbaa !29
  %t786 = getelementptr %"compiler/typed:Clause", ptr %t784, i32 0, i32 3
  %t787 = load ptr, ptr %t786, !tbaa !29
  %t788 = load ptr, ptr %l392, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t788, ptr %t787)
  br label %bb195
bb195:
  br label %bb196
bb196:
  call void @__olang_scope_close(ptr %s30)
  br label %bb197
bb197:
  %t790 = load i64, ptr %l37, !tbaa !24
  %t792 = add i64 %t790, 1
  store i64 %t792, ptr %l37, !tbaa !24
  br label %bb186
bb198:
  br label %bb257
bb199:
  %t794 = load ptr, ptr %l1, !tbaa !29
  store ptr %t794, ptr %l400, !tbaa !29
  store i1 false, ptr %l401, !tbaa !21
  %t795 = load ptr, ptr %l400, !tbaa !29
  %t796 = icmp ne ptr %t795, null
  br i1 %t796, label %bb200, label %bb201
bb200:
  %t798 = load ptr, ptr %l400, !tbaa !29
  %t799 = load i64, ptr %t798
  %t801 = icmp eq i64 %t799, 14
  store i1 %t801, ptr %l401, !tbaa !21
  br label %bb201
bb201:
  %t802 = load i1, ptr %l401, !tbaa !21
  br i1 %t802, label %bb202, label %bb203
bb202:
  %t803 = load ptr, ptr %l1, !tbaa !29
  %t805 = getelementptr { i64, [3 x i64] }, ptr %t803, i32 0, i32 1
  %t806 = getelementptr { %"compiler/source:Span", ptr }, ptr %t805, i32 0, i32 0
  %t807 = load %"compiler/source:Span", ptr %t806
  store %"compiler/source:Span" %t807, ptr %l40
  %t809 = load ptr, ptr %l1, !tbaa !29
  %t811 = getelementptr { i64, [3 x i64] }, ptr %t809, i32 0, i32 1
  %t812 = getelementptr { %"compiler/source:Span", ptr }, ptr %t811, i32 0, i32 1
  %t813 = load ptr, ptr %t812
  store ptr %t813, ptr %l41, !tbaa !29
  br label %bb204
bb203:
  br label %bb227
bb204:
  store %olang.scope zeroinitializer, ptr %s33
  %t815 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/free:walker", ptr %t815, i32 0, i32 0
  %t818 = load ptr, ptr %t817, !tbaa !29
  %t820 = getelementptr %"compiler/free:Free", ptr %t818, i32 0, i32 31
  store i1 true, ptr %t820, !tbaa !21
  %t821 = load ptr, ptr %l0, !tbaa !29
  %t822 = load ptr, ptr %l41, !tbaa !29
  %t824 = getelementptr %"compiler/typed:Spawn", ptr %t822, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !29
  %t828 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s33, ptr %t821, ptr %t825)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t828, ptr %l413
  br label %bb205
bb205:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t831 = getelementptr %"compiler/free:walker", ptr %t829, i32 0, i32 2
  %t832 = load i1, ptr %t831, !tbaa !21
  br i1 %t832, label %bb206, label %bb207
bb206:
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t836 = getelementptr %"compiler/free:walker", ptr %t834, i32 0, i32 0
  %t837 = load ptr, ptr %t836, !tbaa !29
  %t839 = getelementptr %"compiler/free:Free", ptr %t837, i32 0, i32 61
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t842 = getelementptr %"compiler/free:walker", ptr %t840, i32 0, i32 1
  %t843 = load i64, ptr %t842, !tbaa !24
  %t846 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t839, i64 %t843)
  store i1 %t846, ptr %l422
  br label %bb208
bb207:
  store i1 false, ptr %l416, !tbaa !21
  br label %bb209
bb208:
  %t847 = load i1, ptr %l422, !tbaa !21
  store i1 %t847, ptr %l416, !tbaa !21
  br label %bb209
bb209:
  %t848 = load i1, ptr %l416, !tbaa !21
  br i1 %t848, label %bb210, label %bb211
bb210:
  %t849 = load ptr, ptr %l0, !tbaa !29
  %t850 = load %"compiler/source:Span", ptr %l40
  %t851 = load ptr, ptr %l41, !tbaa !29
  %t853 = getelementptr %"compiler/typed:Spawn", ptr %t851, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedToTask(ptr %v0, ptr %v1, ptr %t849, %"compiler/source:Span" %t850, ptr %t854)
  br label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb213
bb213:
  %t858 = load ptr, ptr %l41, !tbaa !29
  %t860 = getelementptr %"compiler/typed:Spawn", ptr %t858, i32 0, i32 2
  %t861 = load { i64, ptr }, ptr %t860, !tbaa !27
  store { i64, ptr } %t861, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t863 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t865 = extractvalue { i64, ptr } %t863, 0
  store i64 %t865, ptr %l44, !tbaa !24
  br label %bb214
bb214:
  store %olang.scope zeroinitializer, ptr %s36
  %t867 = load i64, ptr %l43, !tbaa !24
  %t868 = load i64, ptr %l44, !tbaa !24
  %t871 = icmp slt i64 %t867, %t868
  %t873 = xor i1 %t871, true
  br i1 %t873, label %bb215, label %bb216
bb215:
  call void @__olang_scope_close(ptr %s36)
  br label %bb226
bb216:
  br label %bb217
bb217:
  %t875 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t875, ptr %l435, !tbaa !27
  %t876 = load i64, ptr %l43, !tbaa !24
  %t878 = getelementptr { i64, ptr }, ptr %l435, i32 0, i32 1
  %t879 = load ptr, ptr %t878, !tbaa !27
  %t880 = getelementptr ptr, ptr %t879, i64 %t876
  %t881 = load ptr, ptr %t880, !tbaa !39
  store ptr %t881, ptr %l45, !tbaa !29
  %t883 = load ptr, ptr %l45, !tbaa !29
  %t885 = getelementptr %"compiler/typed:TaskClause", ptr %t883, i32 0, i32 3
  %t886 = load ptr, ptr %t885, !tbaa !29
  %t888 = icmp eq ptr %t886, null
  %t890 = xor i1 %t888, true
  br i1 %t890, label %bb218, label %bb219
bb218:
  store %olang.scope zeroinitializer, ptr %s37
  %t892 = load ptr, ptr %l0, !tbaa !29
  store ptr %t892, ptr %l442, !tbaa !29
  %t893 = load ptr, ptr %l45, !tbaa !29
  %t895 = getelementptr %"compiler/typed:TaskClause", ptr %t893, i32 0, i32 3
  %t896 = load ptr, ptr %t895, !tbaa !29
  %t898 = icmp eq ptr %t896, null
  br i1 %t898, label %bb220, label %bb221
bb219:
  br label %bb224
bb220:
  call void @__olang_check_failed(ptr @olang_loc_2308fe183470e195_4baf259a414fa311)
  unreachable
bb221:
  br label %bb222
bb222:
  %t900 = load ptr, ptr %l45, !tbaa !29
  %t902 = getelementptr %"compiler/typed:TaskClause", ptr %t900, i32 0, i32 3
  %t903 = load ptr, ptr %t902, !tbaa !29
  %t904 = load ptr, ptr %l442, !tbaa !29
  %t906 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s37, ptr %t904, ptr %t903)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t906, ptr %l448
  br label %bb223
bb223:
  call void @__olang_scope_close(ptr %s37)
  br label %bb224
bb224:
  call void @__olang_scope_close(ptr %s36)
  br label %bb225
bb225:
  %t907 = load i64, ptr %l43, !tbaa !24
  %t909 = add i64 %t907, 1
  store i64 %t909, ptr %l43, !tbaa !24
  br label %bb214
bb226:
  call void @__olang_scope_close(ptr %s33)
  br label %bb257
bb227:
  %t911 = load ptr, ptr %l1, !tbaa !29
  store ptr %t911, ptr %l451, !tbaa !29
  store i1 false, ptr %l452, !tbaa !21
  %t912 = load ptr, ptr %l451, !tbaa !29
  %t913 = icmp ne ptr %t912, null
  br i1 %t913, label %bb228, label %bb229
bb228:
  %t915 = load ptr, ptr %l451, !tbaa !29
  %t916 = load i64, ptr %t915
  %t918 = icmp eq i64 %t916, 15
  store i1 %t918, ptr %l452, !tbaa !21
  br label %bb229
bb229:
  %t919 = load i1, ptr %l452, !tbaa !21
  br i1 %t919, label %bb230, label %bb231
bb230:
  %t920 = load ptr, ptr %l1, !tbaa !29
  %t922 = getelementptr { i64, [3 x i64] }, ptr %t920, i32 0, i32 1
  %t923 = getelementptr { %"compiler/source:Span", ptr }, ptr %t922, i32 0, i32 0
  %t924 = load %"compiler/source:Span", ptr %t923
  store %"compiler/source:Span" %t924, ptr %l46
  %t926 = load ptr, ptr %l1, !tbaa !29
  %t928 = getelementptr { i64, [3 x i64] }, ptr %t926, i32 0, i32 1
  %t929 = getelementptr { %"compiler/source:Span", ptr }, ptr %t928, i32 0, i32 1
  %t930 = load ptr, ptr %t929
  store ptr %t930, ptr %l47, !tbaa !29
  br label %bb232
bb231:
  br label %bb252
bb232:
  store %olang.scope zeroinitializer, ptr %s39
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t933 = load ptr, ptr %l47, !tbaa !29
  %t936 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s39, ptr %t932, ptr %t933)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t936, ptr %l461
  br label %bb233
bb233:
  %t937 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l461
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t937, ptr %l48
  %t938 = load ptr, ptr %l0, !tbaa !29
  %t940 = getelementptr %"compiler/free:walker", ptr %t938, i32 0, i32 32
  %t942 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t940)
  store i64 %t942, ptr %l464
  br label %bb234
bb234:
  %t943 = load i64, ptr %l464, !tbaa !24
  %t944 = icmp sgt i64 %t943, 0
  br i1 %t944, label %bb235, label %bb236
bb235:
  %t946 = load ptr, ptr %l0, !tbaa !29
  %t948 = getelementptr %"compiler/free:walker", ptr %t946, i32 0, i32 32
  store ptr %t948, ptr %l467, !tbaa !29
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t951 = getelementptr %"compiler/free:walker", ptr %t949, i32 0, i32 32
  %t953 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t951)
  store i64 %t953, ptr %l470
  br label %bb237
bb236:
  br label %bb240
bb237:
  %t954 = load i64, ptr %l470, !tbaa !24
  %t955 = sub i64 %t954, 1
  %t956 = load ptr, ptr %l467, !tbaa !29
  %t958 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t956, i64 %t955)
  store ptr %t958, ptr %l472
  br label %bb238
bb238:
  %t959 = load ptr, ptr %l472, !tbaa !29
  %t961 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %s39, ptr %t959, ptr %l48)
  store i1 %t961, ptr %l474
  br label %bb239
bb239:
  br label %bb240
bb240:
  %t962 = load ptr, ptr %l0, !tbaa !29
  %t964 = getelementptr %"compiler/free:walker", ptr %t962, i32 0, i32 10
  %t966 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t964)
  store i64 %t966, ptr %l477
  br label %bb241
bb241:
  %t967 = load i64, ptr %l477, !tbaa !24
  %t968 = icmp sgt i64 %t967, 0
  br i1 %t968, label %bb242, label %bb243
bb242:
  %t970 = load ptr, ptr %l0, !tbaa !29
  %t972 = getelementptr %"compiler/free:walker", ptr %t970, i32 0, i32 10
  store ptr %t972, ptr %l480, !tbaa !29
  %t973 = load ptr, ptr %l0, !tbaa !29
  %t975 = getelementptr %"compiler/free:walker", ptr %t973, i32 0, i32 10
  %t977 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t975)
  store i64 %t977, ptr %l483
  br label %bb244
bb243:
  br label %bb251
bb244:
  %t978 = load i64, ptr %l483, !tbaa !24
  %t979 = sub i64 %t978, 1
  %t980 = load ptr, ptr %l480, !tbaa !29
  %t982 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t980, i64 %t979)
  store i64 %t982, ptr %l485
  br label %bb245
bb245:
  %t983 = load i64, ptr %l485, !tbaa !24
  store i64 %t983, ptr %l49, !tbaa !24
  %t984 = load i64, ptr %l49, !tbaa !24
  %t986 = icmp sge i64 %t984, 0
  br i1 %t986, label %bb246, label %bb247
bb246:
  store %olang.scope zeroinitializer, ptr %s42
  %t988 = load ptr, ptr %l0, !tbaa !29
  %t989 = load i64, ptr %l49, !tbaa !24
  %t990 = load ptr, ptr %l47, !tbaa !29
  %t991 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %s39, ptr %s42, ptr %t988, i64 %t989, ptr %t990, ptr %l48, %"compiler/source:Span" %t991, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, i1 false)
  br label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s43
  %t997 = load ptr, ptr %l0, !tbaa !29
  %t998 = load %"compiler/source:Span", ptr %l46
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s39, ptr %s43, ptr %t997, ptr %l48, %"compiler/source:Span" %t998, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb249
bb248:
  call void @__olang_scope_close(ptr %s42)
  br label %bb250
bb249:
  call void @__olang_scope_close(ptr %s43)
  br label %bb250
bb250:
  br label %bb251
bb251:
  call void @__olang_scope_close(ptr %s39)
  br label %bb257
bb252:
  br i1 true, label %bb253, label %bb254
bb253:
  br label %bb255
bb254:
  br label %bb256
bb255:
  br label %bb257
bb256:
  call void @__olang_check_failed(ptr @olang_loc_99fb9e2ddedcc4fd_8483d8da78522e69)
  unreachable
bb257:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1004 = getelementptr %"compiler/free:walker", ptr %t1002, i32 0, i32 13
  %t1005 = load i64, ptr %l2, !tbaa !24
  %t1006 = load ptr, ptr %l0, !tbaa !29
  %t1008 = getelementptr %"compiler/free:walker", ptr %t1006, i32 0, i32 11
  %t1009 = load i64, ptr %t1008, !tbaa !24
  %t1011 = sub i64 %t1009, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1004, i64 %t1005, i64 %t1011)
  br label %bb258
bb258:
  %t1015 = load ptr, ptr %l0, !tbaa !29
  %t1016 = load i64, ptr %l3, !tbaa !24
  %t1019 = getelementptr %"compiler/free:walker", ptr %t1015, i32 0, i32 12
  store i64 %t1016, ptr %t1019, !tbaa !24
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1021 = load %"compiler/source:Span", ptr %l4
  %t1024 = getelementptr %"compiler/free:walker", ptr %t1020, i32 0, i32 33
  store %"compiler/source:Span" %t1021, ptr %t1024
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 false, i1 %a6)
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l38 = alloca { i64, ptr }
  %l42 = alloca i64
  %l45 = alloca i1
  %l48 = alloca i1
  %l50 = alloca i64
  %l54 = alloca i1
  %l56 = alloca i64
  %l59 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca %"compiler/source:Span"
  %l73 = alloca i1
  %l75 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca i64
  %l84 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca %"compiler/source:Span"
  %l89 = alloca i1
  %l91 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca i64
  %l125 = alloca i64
  %l127 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i1
  %l134 = alloca { i64, ptr }
  %l140 = alloca i64
  %l150 = alloca ptr
  %l155 = alloca i1
  %l158 = alloca i1
  %l163 = alloca ptr
  %l165 = alloca i1
  %l182 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l195 = alloca { i64, ptr }
  %l199 = alloca i64
  %l202 = alloca i1
  %l204 = alloca i64
  %l208 = alloca i1
  %l213 = alloca ptr
  %l215 = alloca i64
  %l216 = alloca i1
  %l223 = alloca { i64, ptr }
  %l225 = alloca i64
  %l229 = alloca ptr
  %l231 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l241 = alloca i32
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t9 = load i64, ptr %l10, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l29
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l28
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t17, ptr %l25, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l29, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2058a1f1b30311f1_26f3aef7996ef6dd)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb7:
  %t23 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t23, ptr %l11, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = load i64, ptr %l12, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t36, ptr %l38, !tbaa !27
  %t37 = load i64, ptr %l13, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i64, ptr %t40, i64 %t37
  %t42 = load i64, ptr %t41, !tbaa !34
  store i64 %t42, ptr %l14, !tbaa !24
  %t44 = load i64, ptr %l14, !tbaa !24
  %t46 = call i64 @compiler_2ffree_2eokind(i64 %t44)
  store i64 %t46, ptr %l42
  br label %bb12
bb12:
  %t47 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t48 = load i64, ptr %l42, !tbaa !24
  %t50 = icmp eq i64 %t48, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 2
  %t55 = load i1, ptr %t54, !tbaa !21
  store i1 %t55, ptr %l45, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l45, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load i64, ptr %l14, !tbaa !24
  %t60 = call i64 @compiler_2ffree_2eoval(i64 %t58)
  store i64 %t60, ptr %l50
  br label %bb18
bb17:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb19
bb18:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/free:walker", ptr %t61, i32 0, i32 31
  %t64 = load i64, ptr %t63, !tbaa !24
  %t65 = load i64, ptr %l50, !tbaa !24
  %t67 = icmp ne i64 %t65, %t64
  store i1 %t67, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l48, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l14, !tbaa !24
  %t72 = call i64 @compiler_2ffree_2eoval(i64 %t70)
  store i64 %t72, ptr %l56
  br label %bb22
bb21:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb23
bb22:
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load i64, ptr %l56, !tbaa !24
  %t76 = icmp ne i64 %t74, %t73
  store i1 %t76, ptr %l54, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l54, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l8, !tbaa !29
  store ptr %t79, ptr %l59, !tbaa !29
  %t80 = load i64, ptr %l14, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2eoval(i64 %t80)
  store i64 %t82, ptr %l61
  br label %bb26
bb25:
  br label %bb45
bb26:
  %t83 = load ptr, ptr %l59, !tbaa !29
  %t84 = load i64, ptr %l61, !tbaa !24
  %t85 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t83, i64 %t84)
  store i1 %t85, ptr %l62
  br label %bb27
bb27:
  %t86 = load i1, ptr %l62, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t87 = load ptr, ptr %l8, !tbaa !29
  store ptr %t87, ptr %l63, !tbaa !29
  %t88 = load i64, ptr %l14, !tbaa !24
  %t90 = call i64 @compiler_2ffree_2eoval(i64 %t88)
  store i64 %t90, ptr %l65
  br label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t91 = load ptr, ptr %l8, !tbaa !29
  store ptr %t91, ptr %l79, !tbaa !29
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = call i64 @compiler_2ffree_2eoval(i64 %t92)
  store i64 %t94, ptr %l81
  br label %bb37
bb30:
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t95, ptr %l66, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t96)
  store ptr %t98, ptr %l68
  br label %bb31
bb31:
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Body", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l70, !tbaa !24
  %t103 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t103, ptr %l71
  %t104 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s5, { i64, ptr } %t104, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) })
  store i1 %t106, ptr %l73
  br label %bb32
bb32:
  %t107 = load i1, ptr %l73, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t110 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t111 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t114 = extractvalue { i64, ptr } %t110, 1
  %t115 = extractvalue { i64, ptr } %t110, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = getelementptr i8, ptr %t120, i64 %t112
  call void @olang_textcopy(ptr %t121, ptr %t114, i64 %t115)
  %t122 = getelementptr i8, ptr %t121, i64 %t115
  call void @olang_textcopy(ptr %t122, ptr %t117, i64 %t118)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t120, 1
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t127 = extractvalue { i64, ptr } %t124, 1
  %t128 = mul i64 %t126, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t128)
  call void @llvm.memcpy.p0.p0.i64(ptr %t129, ptr %t127, i64 %t128, i1 false)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l75, !tbaa !27
  br label %bb35
bb34:
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l75, !tbaa !27
  br label %bb35
bb35:
  %t133 = load ptr, ptr %l63, !tbaa !29
  %t134 = load i64, ptr %l65, !tbaa !24
  %t135 = load i64, ptr %l66, !tbaa !24
  %t136 = load i64, ptr %l70, !tbaa !24
  %t137 = load %"compiler/source:Span", ptr %l71
  %t138 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s5, ptr %t133, i64 %t134, i64 %t135, i64 %t136, %"compiler/source:Span" %t137, { i64, ptr } %t138)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb37:
  %t139 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t139, ptr %l82, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t140)
  store ptr %t142, ptr %l84
  br label %bb38
bb38:
  %t143 = load ptr, ptr %l84, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 3
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l86, !tbaa !24
  %t147 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t147, ptr %l87
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s7, { i64, ptr } %t148, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t150, ptr %l89
  br label %bb39
bb39:
  %t151 = load i1, ptr %l89, !tbaa !21
  %t152 = xor i1 %t151, true
  br i1 %t152, label %bb40, label %bb41
bb40:
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t155 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t158 = extractvalue { i64, ptr } %t154, 1
  %t159 = extractvalue { i64, ptr } %t154, 0
  %t160 = add i64 %t156, %t159
  %t161 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t155, i64 %t156)
  %t165 = getelementptr i8, ptr %t164, i64 %t156
  call void @olang_textcopy(ptr %t165, ptr %t158, i64 %t159)
  %t166 = getelementptr i8, ptr %t165, i64 %t159
  call void @olang_textcopy(ptr %t166, ptr %t161, i64 %t162)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t164, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l91, !tbaa !27
  br label %bb42
bb41:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb42
bb42:
  %t177 = load ptr, ptr %l79, !tbaa !29
  %t178 = load i64, ptr %l81, !tbaa !24
  %t179 = load i64, ptr %l82, !tbaa !24
  %t180 = load i64, ptr %l86, !tbaa !24
  %t181 = load %"compiler/source:Span", ptr %l87
  %t182 = load { i64, ptr }, ptr %l91, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s7, ptr %t177, i64 %t178, i64 %t179, i64 %t180, %"compiler/source:Span" %t181, { i64, ptr } %t182)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s3)
  br label %bb46
bb46:
  %t183 = load i64, ptr %l13, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l13, !tbaa !24
  br label %bb8
bb47:
  %t187 = load i64, ptr %l10, !tbaa !24
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = add i64 %t187, %t188
  store i64 %t191, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  br label %bb1
bb49:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:walker", ptr %t193, i32 0, i32 2
  %t196 = load i1, ptr %t195, !tbaa !21
  br i1 %t196, label %bb50, label %bb51
bb50:
  %t198 = load ptr, ptr %l3, !tbaa !29
  store ptr %t198, ptr %l103, !tbaa !29
  %t199 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t200 = load i64, ptr %l1, !tbaa !24
  %t203 = call i64 @compiler_2ffree_2eorig(i64 %t199, i64 %t200)
  store i64 %t203, ptr %l106
  br label %bb52
bb51:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb54
bb52:
  %t204 = load ptr, ptr %l103, !tbaa !29
  %t205 = load i64, ptr %l106, !tbaa !24
  %t206 = call i1 @compiler_2ffree_2ehas(ptr %v2, ptr %t204, i64 %t205)
  store i1 %t206, ptr %l107
  br label %bb53
bb53:
  %t207 = load i1, ptr %l107, !tbaa !21
  store i1 %t207, ptr %l102, !tbaa !21
  br label %bb54
bb54:
  %t208 = load i1, ptr %l102, !tbaa !21
  br i1 %t208, label %bb55, label %bb56
bb55:
  %t209 = load i64, ptr %l1, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/free:walker", ptr %t210, i32 0, i32 31
  %t213 = load i64, ptr %t212, !tbaa !24
  %t216 = icmp ne i64 %t209, %t213
  store i1 %t216, ptr %l108, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb57
bb57:
  %t218 = load i1, ptr %l108, !tbaa !21
  br i1 %t218, label %bb58, label %bb59
bb58:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t223 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t219, ptr %t220)
  store i64 %t223, ptr %l116
  br label %bb60
bb59:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb61
bb60:
  %t224 = load i64, ptr %l116, !tbaa !24
  %t225 = icmp slt i64 %t224, 0
  store i1 %t225, ptr %l113, !tbaa !21
  br label %bb61
bb61:
  %t227 = load i1, ptr %l113, !tbaa !21
  br i1 %t227, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t230 = load ptr, ptr %l2, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l4
  %t232 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t228, i64 %t229, ptr %t230, %"compiler/source:Span" %t231, i1 %t232)
  br label %bb64
bb63:
  br label %bb71
bb64:
  %t238 = load ptr, ptr %l8, !tbaa !29
  store ptr %t238, ptr %l123, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  store i64 %t239, ptr %l124, !tbaa !24
  %t240 = load i64, ptr @G_2ecompiler_2ffree_2eRStore, !tbaa !24
  store i64 %t240, ptr %l125, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t241)
  store ptr %t243, ptr %l127
  br label %bb65
bb65:
  %t244 = load ptr, ptr %l127, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Body", ptr %t244, i32 0, i32 3
  %t247 = load i64, ptr %t246, !tbaa !24
  store i64 %t247, ptr %l129, !tbaa !24
  %t248 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t248, ptr %l130
  %t249 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v3, ptr %s10, { i64, ptr } %t249, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t251, ptr %l132
  br label %bb66
bb66:
  %t252 = load i1, ptr %l132, !tbaa !21
  %t253 = xor i1 %t252, true
  br i1 %t253, label %bb67, label %bb68
bb67:
  %t255 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t256 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t259 = extractvalue { i64, ptr } %t255, 1
  %t260 = extractvalue { i64, ptr } %t255, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t256, i64 %t257)
  %t266 = getelementptr i8, ptr %t265, i64 %t257
  call void @olang_textcopy(ptr %t266, ptr %t259, i64 %t260)
  %t267 = getelementptr i8, ptr %t266, i64 %t260
  call void @olang_textcopy(ptr %t267, ptr %t262, i64 %t263)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t265, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = extractvalue { i64, ptr } %t269, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  store { i64, ptr } %t276, ptr %l134, !tbaa !27
  br label %bb69
bb68:
  store { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %l134, !tbaa !27
  br label %bb69
bb69:
  %t278 = load ptr, ptr %l123, !tbaa !29
  %t279 = load i64, ptr %l124, !tbaa !24
  %t280 = load i64, ptr %l125, !tbaa !24
  %t281 = load i64, ptr %l129, !tbaa !24
  %t282 = load %"compiler/source:Span", ptr %l130
  %t283 = load { i64, ptr }, ptr %l134, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s10, ptr %t278, i64 %t279, i64 %t280, i64 %t281, %"compiler/source:Span" %t282, { i64, ptr } %t283)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb71:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l2, !tbaa !29
  %t288 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  store i64 %t288, ptr %l140
  br label %bb72
bb72:
  %t289 = load i64, ptr %l140, !tbaa !24
  store i64 %t289, ptr %l15, !tbaa !24
  %t290 = load i64, ptr %l15, !tbaa !24
  %t292 = icmp sge i64 %t290, 0
  br i1 %t292, label %bb73, label %bb74
bb73:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/free:walker", ptr %t294, i32 0, i32 2
  %t297 = load i1, ptr %t296, !tbaa !21
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb75, label %bb76
bb74:
  br label %bb94
bb75:
  %t301 = load ptr, ptr %l8, !tbaa !29
  %t303 = getelementptr %"compiler/free:Free", ptr %t301, i32 0, i32 21
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/free:walker", ptr %t304, i32 0, i32 1
  %t307 = load i64, ptr %t306, !tbaa !24
  %t310 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t303, i64 %t307)
  store ptr %t310, ptr %l150
  br label %bb77
bb76:
  br label %bb90
bb77:
  %t311 = load i64, ptr %l15, !tbaa !24
  %t313 = shl i64 %t311, 32
  %t314 = load i64, ptr %l1, !tbaa !24
  %t317 = or i64 %t313, %t314
  %t318 = load ptr, ptr %l150, !tbaa !29
  %t320 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t318, i64 %t317)
  store i1 %t320, ptr %l155
  br label %bb78
bb78:
  %t321 = load i1, ptr %l155, !tbaa !21
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t322 = load ptr, ptr %l8, !tbaa !29
  %t324 = getelementptr %"compiler/free:Free", ptr %t322, i32 0, i32 30
  store i1 true, ptr %t324, !tbaa !21
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t325 = load i1, ptr %l6, !tbaa !21
  br i1 %t325, label %bb82, label %bb83
bb82:
  %t327 = load ptr, ptr %l8, !tbaa !29
  %t329 = getelementptr %"compiler/free:Free", ptr %t327, i32 0, i32 23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/free:walker", ptr %t330, i32 0, i32 1
  %t333 = load i64, ptr %t332, !tbaa !24
  %t336 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t329, i64 %t333)
  store ptr %t336, ptr %l163
  br label %bb84
bb83:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb86
bb84:
  %t337 = load i64, ptr %l15, !tbaa !24
  %t338 = load ptr, ptr %l163, !tbaa !29
  %t340 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t338, i64 %t337)
  store i1 %t340, ptr %l165
  br label %bb85
bb85:
  %t341 = load i1, ptr %l165, !tbaa !21
  store i1 %t341, ptr %l158, !tbaa !21
  br label %bb86
bb86:
  %t342 = load i1, ptr %l158, !tbaa !21
  br i1 %t342, label %bb87, label %bb88
bb87:
  %t343 = load ptr, ptr %l8, !tbaa !29
  %t345 = getelementptr %"compiler/free:Free", ptr %t343, i32 0, i32 30
  store i1 true, ptr %t345, !tbaa !21
  br label %bb89
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/free:walker", ptr %t346, i32 0, i32 43
  %t349 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t348, i64 %t349)
  br label %bb91
bb91:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t354 = getelementptr %"compiler/free:walker", ptr %t352, i32 0, i32 44
  %t355 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t354, i64 %t355)
  br label %bb92
bb92:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/free:walker", ptr %t358, i32 0, i32 45
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/free:walker", ptr %t361, i32 0, i32 12
  %t364 = load i64, ptr %t363, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t360, i64 %t364)
  br label %bb93
bb93:
  br label %ret
bb94:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/free:walker", ptr %t367, i32 0, i32 2
  %t370 = load i1, ptr %t369, !tbaa !21
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb95, label %bb96
bb95:
  br i1 %a7, label %bb97, label %bb98
bb96:
  br label %bb142
bb97:
  br label %ret
bb98:
  br label %bb99
bb99:
  %t376 = load ptr, ptr %l3, !tbaa !29
  store ptr %t376, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s19
  %t378 = load ptr, ptr %l16, !tbaa !29
  %t379 = load i64, ptr %l17, !tbaa !24
  %t382 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t378, i64 %t379)
  %t383 = extractvalue { i32, { i64, ptr } } %t382, 1
  %t384 = extractvalue { i32, { i64, ptr } } %t382, 0
  store i32 %t384, ptr %l186
  %t385 = icmp ne i32 %t384, 0
  br i1 %t385, label %bb102, label %ok.386
ok.386:
  store { i64, ptr } %t383, ptr %l185
  br label %bb101
bb101:
  %t387 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t387, ptr %l182, !tbaa !27
  br label %bb106
bb102:
  %t388 = load i32, ptr %l186, !tbaa !23
  %t389 = ashr i32 %t388, 16
  %t391 = icmp eq i32 %t389, 1
  br i1 %t391, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_1d3454c606268de0_1a2b7fbff193742c)
  unreachable
bb105:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s19)
  br label %bb141
bb106:
  %t393 = load { i64, ptr }, ptr %l182, !tbaa !27
  store { i64, ptr } %t393, ptr %l18, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s20
  %t398 = load i64, ptr %l20, !tbaa !24
  %t399 = load i64, ptr %l19, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s20)
  br label %bb139
bb109:
  br label %bb110
bb110:
  %t406 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t406, ptr %l195, !tbaa !27
  %t407 = load i64, ptr %l20, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i64, ptr %t410, i64 %t407
  %t412 = load i64, ptr %t411, !tbaa !34
  store i64 %t412, ptr %l21, !tbaa !24
  %t414 = load i64, ptr %l21, !tbaa !24
  %t416 = call i64 @compiler_2ffree_2eokind(i64 %t414)
  store i64 %t416, ptr %l199
  br label %bb111
bb111:
  %t417 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t418 = load i64, ptr %l199, !tbaa !24
  %t420 = icmp eq i64 %t418, %t417
  br i1 %t420, label %bb112, label %bb113
bb112:
  %t422 = load i64, ptr %l21, !tbaa !24
  %t424 = call i64 @compiler_2ffree_2eoval(i64 %t422)
  store i64 %t424, ptr %l204
  br label %bb114
bb113:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb115
bb114:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/free:walker", ptr %t425, i32 0, i32 30
  %t428 = load i64, ptr %t427, !tbaa !24
  %t429 = load i64, ptr %l204, !tbaa !24
  %t431 = icmp ne i64 %t429, %t428
  store i1 %t431, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t433 = load i1, ptr %l202, !tbaa !21
  br i1 %t433, label %bb116, label %bb117
bb116:
  %t434 = load ptr, ptr %l8, !tbaa !29
  %t436 = getelementptr %"compiler/free:Free", ptr %t434, i32 0, i32 22
  %t437 = load ptr, ptr %l0, !tbaa !29
  %t439 = getelementptr %"compiler/free:walker", ptr %t437, i32 0, i32 1
  %t440 = load i64, ptr %t439, !tbaa !24
  %t443 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t436, i64 %t440)
  store ptr %t443, ptr %l213
  br label %bb118
bb117:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb121
bb118:
  %t444 = load i64, ptr %l21, !tbaa !24
  %t446 = call i64 @compiler_2ffree_2eoval(i64 %t444)
  store i64 %t446, ptr %l215
  br label %bb119
bb119:
  %t447 = load ptr, ptr %l213, !tbaa !29
  %t448 = load i64, ptr %l215, !tbaa !24
  %t449 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t447, i64 %t448)
  store i1 %t449, ptr %l216
  br label %bb120
bb120:
  %t450 = load i1, ptr %l216, !tbaa !21
  store i1 %t450, ptr %l208, !tbaa !21
  br label %bb121
bb121:
  %t451 = load i1, ptr %l208, !tbaa !21
  br i1 %t451, label %bb122, label %bb123
bb122:
  %t452 = load ptr, ptr %l8, !tbaa !29
  %t454 = getelementptr %"compiler/free:Free", ptr %t452, i32 0, i32 30
  store i1 true, ptr %t454, !tbaa !21
  %t455 = load ptr, ptr %l8, !tbaa !29
  %t457 = getelementptr %"compiler/free:Free", ptr %t455, i32 0, i32 68
  %t458 = load i1, ptr %t457, !tbaa !21
  br i1 %t458, label %bb124, label %bb125
bb123:
  br label %bb137
bb124:
  store %olang.scope zeroinitializer, ptr %s22
  %t460 = load ptr, ptr %l8, !tbaa !29
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t463 = getelementptr %"compiler/free:walker", ptr %t461, i32 0, i32 1
  %t464 = load i64, ptr %t463, !tbaa !24
  %t467 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s22, ptr %t460, i64 %t464)
  store { i64, ptr } %t467, ptr %l223
  br label %bb126
bb125:
  br label %bb136
bb126:
  %t468 = load i64, ptr %l21, !tbaa !24
  %t470 = call i64 @compiler_2ffree_2eoval(i64 %t468)
  store i64 %t470, ptr %l225
  br label %bb127
bb127:
  %t471 = load ptr, ptr %l8, !tbaa !29
  %t473 = getelementptr %"compiler/free:Free", ptr %t471, i32 0, i32 0
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/generic:Program", ptr %t474, i32 0, i32 0
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/load:Loader", ptr %t477, i32 0, i32 4
  %t480 = load ptr, ptr %t479, !tbaa !29
  store ptr %t480, ptr %l229, !tbaa !29
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t481)
  store ptr %t483, ptr %l231
  br label %bb128
bb128:
  %t484 = load ptr, ptr %l231, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Body", ptr %t484, i32 0, i32 3
  %t487 = load i64, ptr %t486, !tbaa !24
  %t488 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t489 = load i32, ptr %t488, !tbaa !23
  %t491 = sext i32 %t489 to i64
  %t492 = load ptr, ptr %l229, !tbaa !29
  %t495 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s22, ptr %t492, i64 %t487, i64 %t491)
  store { i64, ptr } %t495, ptr %l236
  br label %bb129
bb129:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/free:walker", ptr %t496, i32 0, i32 30
  %t499 = load i64, ptr %t498, !tbaa !24
  %t500 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t501 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t502 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = add i64 %t501, %t504
  %t506 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t508 = add i64 %t505, %t507
  %t509 = load i64, ptr %l225, !tbaa !24
  %t510 = call i64 @__olang_fmt_i64(ptr null, i64 %t509)
  %t511 = add i64 %t508, %t510
  %t512 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t514 = add i64 %t511, %t513
  %t515 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = add i64 %t514, %t517
  %t519 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t523 = call i64 @__olang_fmt_i64(ptr null, i64 %t499)
  %t524 = add i64 %t521, %t523
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t528 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t527)
  call void @olang_textcopy(ptr %t528, ptr %t500, i64 %t501)
  %t529 = getelementptr i8, ptr %t528, i64 %t501
  call void @olang_textcopy(ptr %t529, ptr %t503, i64 %t504)
  %t530 = getelementptr i8, ptr %t529, i64 %t504
  call void @olang_textcopy(ptr %t530, ptr %t506, i64 %t507)
  %t531 = getelementptr i8, ptr %t530, i64 %t507
  %t532 = call i64 @__olang_fmt_i64(ptr %t531, i64 %t509)
  %t533 = getelementptr i8, ptr %t531, i64 %t510
  call void @olang_textcopy(ptr %t533, ptr %t512, i64 %t513)
  %t534 = getelementptr i8, ptr %t533, i64 %t513
  call void @olang_textcopy(ptr %t534, ptr %t516, i64 %t517)
  %t535 = getelementptr i8, ptr %t534, i64 %t517
  call void @olang_textcopy(ptr %t535, ptr %t519, i64 %t520)
  %t536 = getelementptr i8, ptr %t535, i64 %t520
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t499)
  %t538 = getelementptr i8, ptr %t536, i64 %t523
  call void @olang_textcopy(ptr %t538, ptr %t525, i64 %t526)
  %t539 = insertvalue { i64, ptr } undef, i64 %t527, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t528, 1
  %t542 = extractvalue { i64, ptr } %t540, 0
  %t543 = extractvalue { i64, ptr } %t540, 1
  %t544 = mul i64 %t542, 1
  %t545 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t544)
  call void @llvm.memcpy.p0.p0.i64(ptr %t545, ptr %t543, i64 %t544, i1 false)
  %t546 = insertvalue { i64, ptr } undef, i64 %t542, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t545, 1
  %t549 = call i32 @std_2fio_2ePrintErr(ptr %s22, { i64, ptr } %t547)
  store i32 %t549, ptr %l241
  %t550 = icmp ne i32 %t549, 0
  br i1 %t550, label %bb131, label %ok.551
ok.551:
  br label %bb130
bb130:
  br label %bb135
bb131:
  %t552 = load i32, ptr %l241, !tbaa !23
  %t553 = ashr i32 %t552, 16
  %t555 = icmp eq i32 %t553, 1
  br i1 %t555, label %bb132, label %bb133
bb132:
  br label %bb134
bb133:
  call void @__olang_check_failed(ptr @olang_loc_c9e53ae0a52ca2db_3047dcba482a81a7)
  unreachable
bb134:
  call void @__olang_ert_req_clear()
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s22)
  br label %bb136
bb136:
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s20)
  br label %bb138
bb138:
  %t557 = load i64, ptr %l20, !tbaa !24
  %t559 = add i64 %t557, 1
  store i64 %t559, ptr %l20, !tbaa !24
  br label %bb107
bb139:
  %t561 = load i64, ptr %l17, !tbaa !24
  %t562 = load i64, ptr %l19, !tbaa !24
  %t565 = add i64 %t561, %t562
  store i64 %t565, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb140
bb140:
  br label %bb100
bb141:
  br label %ret
bb142:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load i64, ptr %l1, !tbaa !24
  %t569 = load ptr, ptr %l2, !tbaa !29
  %t570 = load %"compiler/source:Span", ptr %l4
  %t571 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t567, i64 %t568, ptr %t569, %"compiler/source:Span" %t570, i1 %t571)
  br label %bb143
bb143:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:leaf"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i64
  %l25 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i1
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i1
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %t6, ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t11, ptr %lp4
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  %t13 = load ptr, ptr %lp4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %t13
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t14, ptr %t15)
  store i64 %t18, ptr %l20
  br label %bb2
bb2:
  %t19 = load i64, ptr %l20, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load ptr, ptr %l3, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 18
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t29 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t22, i64 %t26)
  store i1 %t29, ptr %l25
  br label %bb3
bb3:
  %t30 = load i1, ptr %l25, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l6, !tbaa !21
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sge i64 %t33, 0
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t37 = load ptr, ptr %lp4
  store ptr %t37, ptr %l29, !tbaa !29
  %t38 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call i64 @compiler_2ffree_2eorig(i64 %t38, i64 %t39)
  store i64 %t42, ptr %l32
  br label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t43, i32 %a2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l40
  br label %bb12
bb6:
  %t48 = load ptr, ptr %l29, !tbaa !29
  %t49 = load i64, ptr %l32, !tbaa !24
  %t50 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t48, i64 %t49)
  store i1 %t50, ptr %l33
  br label %bb7
bb7:
  %t51 = load i1, ptr %l6, !tbaa !21
  br i1 %t51, label %bb8, label %bb9
bb8:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 37
  %t56 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t56, i1 true)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb34
bb12:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  %t60 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %t60
  store ptr %t60, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t62 = load ptr, ptr %l7, !tbaa !29
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t62, i64 %t63)
  %t67 = extractvalue { i32, { i64, ptr } } %t66, 1
  %t68 = extractvalue { i32, { i64, ptr } } %t66, 0
  store i32 %t68, ptr %l46
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb15, label %ok.70
ok.70:
  store { i64, ptr } %t67, ptr %l45
  br label %bb14
bb14:
  %t71 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  br label %bb19
bb15:
  %t72 = load i32, ptr %l46, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_edceb98f3409ca88_d08d3a6b63bb4fc4)
  unreachable
bb18:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb19:
  %t77 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t77, ptr %l9, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t90 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t90, ptr %l55, !tbaa !27
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr %"compiler/free:leaf", ptr %t94, i64 %t91
  %t96 = load %"compiler/free:leaf", ptr %t95
  store %"compiler/free:leaf" %t96, ptr %l12
  %t98 = load ptr, ptr %lp4
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t100 = getelementptr %"compiler/free:leaf", ptr %l12, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t104 = call i64 @compiler_2ffree_2eorig(i64 %t99, i64 %t101)
  store i64 %t104, ptr %l61
  br label %bb24
bb24:
  %t105 = load ptr, ptr %l58, !tbaa !29
  %t106 = load i64, ptr %l61, !tbaa !24
  %t107 = call i1 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t105, i64 %t106)
  store i1 %t107, ptr %l62
  br label %bb25
bb25:
  %t108 = load i1, ptr %l6, !tbaa !21
  br i1 %t108, label %bb26, label %bb27
bb26:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 37
  %t113 = getelementptr %"compiler/free:leaf", ptr %l12, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t112, i64 %t114, i1 true)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l11, !tbaa !24
  br label %bb20
bb31:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = add i64 %t121, %t122
  store i64 %t125, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  br label %bb13
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t127 = load ptr, ptr %lp4
  %t128 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t127
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l44 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l64 = alloca i64
  %l68 = alloca i64
  %l71 = alloca i64
  %l92 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i64
  %l101 = alloca i64
  %l104 = alloca i1
  %l108 = alloca i64
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l125 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca i64
  %l134 = alloca i1
  %l138 = alloca i64
  %l142 = alloca i64
  %l155 = alloca i1
  %l156 = alloca i1
  %l158 = alloca i64
  %l161 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 20
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l26
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l26, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t16, i64 %t17)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l35
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb7, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l34
  br label %bb6
bb6:
  %t25 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t25, ptr %l31, !tbaa !27
  br label %bb11
bb7:
  %t26 = load i32, ptr %l35, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_326195846d385025_6126b0727ca50ba9)
  unreachable
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb11:
  %t31 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l44, !tbaa !27
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 %t45
  %t50 = load i64, ptr %t49, !tbaa !34
  store i64 %t50, ptr %l9, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 25
  %t55 = load i64, ptr %l9, !tbaa !24
  %t58 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l50
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 13
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l54
  br label %bb17
bb17:
  %t66 = load i64, ptr %l50, !tbaa !24
  %t67 = load i64, ptr %l54, !tbaa !24
  %t68 = icmp sgt i64 %t66, %t67
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i64 %t70, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t72, 1
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb12
bb22:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = add i64 %t76, %t77
  store i64 %t80, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  br label %bb5
bb24:
  store i64 0, ptr %l10, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 14
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l64
  br label %bb25
bb25:
  %t87 = load i64, ptr %l64, !tbaa !24
  store i64 %t87, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t94 = load i64, ptr %l12, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb31
bb28:
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l12, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l71, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb30
bb30:
  %t114 = load i64, ptr %l71, !tbaa !24
  store i64 %t114, ptr %l68, !tbaa !24
  br label %bb31
bb31:
  %t115 = load i64, ptr %l68, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t116 = load i64, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb73
bb34:
  br label %bb35
bb35:
  %t124 = load i64, ptr %l10, !tbaa !24
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l15, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 14
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l92
  br label %bb36
bb36:
  %t141 = load i64, ptr %l92, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  %t142 = load i64, ptr %l16, !tbaa !24
  %t143 = load i64, ptr %l2, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  br i1 %t146, label %bb37, label %bb38
bb37:
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l97, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 15
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t151, i64 %t152)
  store i64 %t155, ptr %l101
  br label %bb39
bb38:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb40
bb39:
  %t156 = load i64, ptr %l97, !tbaa !24
  %t157 = load i64, ptr %l101, !tbaa !24
  %t158 = icmp sle i64 %t156, %t157
  store i1 %t158, ptr %l96, !tbaa !21
  br label %bb40
bb40:
  %t160 = load i1, ptr %l96, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb44
bb42:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/free:walker", ptr %t163, i32 0, i32 20
  %t166 = load i64, ptr %l1, !tbaa !24
  %t169 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l108
  br label %bb43
bb43:
  %t170 = load i64, ptr %l16, !tbaa !24
  %t171 = load i64, ptr %l108, !tbaa !24
  %t173 = icmp sgt i64 %t171, %t170
  store i1 %t173, ptr %l104, !tbaa !21
  br label %bb44
bb44:
  %t175 = load i1, ptr %l104, !tbaa !21
  br i1 %t175, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb46:
  br label %bb47
bb47:
  %t176 = load ptr, ptr %l3, !tbaa !29
  store ptr %t176, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s11
  %t178 = load ptr, ptr %l17, !tbaa !29
  %t179 = load i64, ptr %l18, !tbaa !24
  %t182 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t178, i64 %t179)
  %t183 = extractvalue { i32, { i64, ptr } } %t182, 1
  %t184 = extractvalue { i32, { i64, ptr } } %t182, 0
  store i32 %t184, ptr %l116
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb50, label %ok.186
ok.186:
  store { i64, ptr } %t183, ptr %l115
  br label %bb49
bb49:
  %t187 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t187, ptr %l112, !tbaa !27
  br label %bb54
bb50:
  %t188 = load i32, ptr %l116, !tbaa !23
  %t189 = ashr i32 %t188, 16
  %t191 = icmp eq i32 %t189, 1
  br i1 %t191, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_3a04b2d1a65935f4_f1e41c995d4c38d8)
  unreachable
bb53:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s11)
  br label %bb71
bb54:
  %t193 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t193, ptr %l19, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 0
  store i64 %t196, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t198 = load i64, ptr %l21, !tbaa !24
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = icmp slt i64 %t198, %t199
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb69
bb57:
  br label %bb58
bb58:
  %t206 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t206, ptr %l125, !tbaa !27
  %t207 = load i64, ptr %l21, !tbaa !24
  %t209 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i64, ptr %t210, i64 %t207
  %t212 = load i64, ptr %t211, !tbaa !34
  store i64 %t212, ptr %l22, !tbaa !24
  %t214 = load i64, ptr %l16, !tbaa !24
  store i64 %t214, ptr %l128, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 25
  %t218 = load i64, ptr %l22, !tbaa !24
  %t221 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t217, i64 %t218)
  store i64 %t221, ptr %l132
  br label %bb59
bb59:
  %t222 = load i64, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l132, !tbaa !24
  %t224 = icmp slt i64 %t222, %t223
  br i1 %t224, label %bb60, label %bb61
bb60:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 25
  %t229 = load i64, ptr %l22, !tbaa !24
  %t232 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l138
  br label %bb62
bb61:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb64
bb62:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/free:walker", ptr %t233, i32 0, i32 15
  %t236 = load i64, ptr %l15, !tbaa !24
  %t239 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t235, i64 %t236)
  store i64 %t239, ptr %l142
  br label %bb63
bb63:
  %t240 = load i64, ptr %l138, !tbaa !24
  %t241 = load i64, ptr %l142, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  store i1 %t242, ptr %l134, !tbaa !21
  br label %bb64
bb64:
  %t244 = load i1, ptr %l134, !tbaa !21
  br i1 %t244, label %bb65, label %bb66
bb65:
  %t245 = load i64, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  store i64 %t245, ptr %rv
  br label %ret
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb68:
  %t247 = load i64, ptr %l21, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l21, !tbaa !24
  br label %bb55
bb69:
  %t251 = load i64, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l20, !tbaa !24
  %t255 = add i64 %t251, %t252
  store i64 %t255, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb70
bb70:
  br label %bb48
bb71:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb72:
  %t257 = load i64, ptr %l14, !tbaa !24
  %t259 = add i64 %t257, 1
  store i64 %t259, ptr %l14, !tbaa !24
  br label %bb32
bb73:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/free:walker", ptr %t261, i32 0, i32 27
  %t264 = load i64, ptr %l1, !tbaa !24
  %t267 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t263, i64 %t264)
  store i1 %t267, ptr %l155
  br label %bb74
bb74:
  %t268 = load i1, ptr %l155, !tbaa !21
  br i1 %t268, label %bb75, label %bb76
bb75:
  %t269 = load ptr, ptr %l3, !tbaa !29
  %t271 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t269)
  store i64 %t271, ptr %l158
  br label %bb77
bb76:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb78
bb77:
  %t272 = load i64, ptr %l158, !tbaa !24
  %t273 = icmp sgt i64 %t272, 0
  store i1 %t273, ptr %l156, !tbaa !21
  br label %bb78
bb78:
  %t275 = load i1, ptr %l156, !tbaa !21
  br i1 %t275, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l3, !tbaa !29
  %t278 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t276, i64 0)
  store i64 %t278, ptr %l161
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load i64, ptr %l161, !tbaa !24
  store i64 %t279, ptr %rv
  br label %ret
bb82:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i64 @compiler_2ffree_2eorig(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 3
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i64 @compiler_2ffree_2eorig(i64 %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t31, ptr %l19
  br label %bb8
bb8:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l11, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewithinOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca i64
  %l17 = alloca i1
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ebaseOf(ptr %v1, ptr %a1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t22 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %t13, i64 %t17, ptr %t18)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr %l14, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  store i1 %t32, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i64, ptr %l3, !tbaa !24
  store i64 %t35, ptr %l21, !tbaa !24
  br label %bb11
bb10:
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t37 = load i64, ptr %l21, !tbaa !24
  store i64 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t16, i64 %t17)
  store ptr %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l14, !tbaa !29
  store ptr %t21, ptr %l5, !tbaa !29
  br label %bb31
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l23
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l23, !tbaa !29
  store ptr %t42, ptr %l5, !tbaa !29
  br label %bb31
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l25, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t65 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t61, i64 %t62)
  store ptr %t65, ptr %l33
  br label %bb20
bb20:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t67 = icmp eq ptr %t66, null
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Elem", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t74, i64 %t75)
  store ptr %t78, ptr %l40
  br label %bb23
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Elem", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t82, i64 %t83)
  store ptr %t86, ptr %l44
  br label %bb24
bb23:
  %t87 = load ptr, ptr %l40, !tbaa !29
  store ptr %t87, ptr %l36, !tbaa !29
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l44, !tbaa !29
  store ptr %t88, ptr %l36, !tbaa !29
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l36, !tbaa !29
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ee9887f5f58478ff_db34cc814b361eab)
  unreachable
bb31:
  %t90 = load ptr, ptr %l5, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l13
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l12
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l13, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_d465c21b871057ed_46a08b0f1b8ea721)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 %t32
  %t37 = load i64, ptr %t36, !tbaa !34
  %t43 = icmp eq i64 %t37, %a1
  br i1 %t43, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2emeet(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l0, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l0, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = shl i64 %a0, 40
  %t7 = or i64 %t3, %a1
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2eoval(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t2 = shl i64 1, 40
  %t4 = sub i64 %t2, 1
  %t7 = and i64 %a0, %t4
  store i64 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb35
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb23
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb12, label %bb13
bb12:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 0
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_11a48ff1e8d67007_90e1a85549f82d33)
  unreachable
bb22:
  %t34 = load i1, ptr %l14, !tbaa !21
  store i1 %t34, ptr %l3, !tbaa !21
  br label %bb35
bb23:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb24, label %bb25
bb24:
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb25
bb25:
  %t43 = load i1, ptr %l20, !tbaa !21
  br i1 %t43, label %bb26, label %bb27
bb26:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l26
  br label %bb29
bb29:
  %t53 = load i1, ptr %l26, !tbaa !21
  store i1 %t53, ptr %l3, !tbaa !21
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e0188cd4392210a6_c14318bc74dc83b2)
  unreachable
bb35:
  %t54 = load i1, ptr %l3, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %t12
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l20
  br label %bb10
bb10:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb41
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l29
  br label %bb17
bb17:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l11, !tbaa !21
  br label %bb41
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb24
bb24:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  br label %bb41
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb26, label %bb27
bb26:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 9
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb28, label %bb29
bb28:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83
  store i32 %t84, ptr %l5
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t88, i32 0, i32 4
  %t90 = load { i64, ptr }, ptr %t89
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t92 = load i32, ptr %l5
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %t92, { i64, ptr } %t93)
  store i1 %t96, ptr %l49
  br label %bb31
bb31:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l51, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 0
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l54
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t107 = load i1, ptr %l54, !tbaa !21
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l50, !tbaa !21
  store i1 %t108, ptr %l11, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_365b62d925fe4616_77c77337a4accaaa)
  unreachable
bb41:
  %t109 = load i1, ptr %l11, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l7 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t10, ptr %l5
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  %t11 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t11, ptr %rv
  br label %ret
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Call", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l7, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr ptr, ptr %t17, i64 0
  %t19 = load ptr, ptr %t18, !tbaa !39
  %t21 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t19)
  store %"compiler/source:Span" %t21, ptr %l9
  br label %bb5
bb5:
  %t22 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t22, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [1 x i64] }
  %l1 = alloca i1
  %rv = alloca i1
  store { i64, [1 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [1 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [1 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb7
bb2:
  %t6 = load { i64, [1 x i64] }, ptr %l0
  %t8 = extractvalue { i64, [1 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 2
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb7
bb4:
  %t11 = load { i64, [1 x i64] }, ptr %l0
  %t13 = extractvalue { i64, [1 x i64] } %t11, 0
  %t14 = icmp eq i64 %t13, 3
  br i1 %t14, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9c97567f05482d15_e6d42a2535d66e1)
  unreachable
bb13:
  %t16 = load i1, ptr %l1, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l64 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_b94c5fec836ee160_c106f176e2c66bb4)
  unreachable
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t39 = load ptr, ptr %l26, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l27, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l27, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t55, i32 0, i32 3
  %t57 = load i64, ptr %t56
  store i64 %t57, ptr %l5, !tbaa !24
  br label %bb21
bb20:
  br label %bb36
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t60 = load ptr, ptr %l34, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l35, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t76, i32 0, i32 3
  %t78 = load i64, ptr %t77
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb26
bb25:
  br label %bb31
bb26:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2ffree_2esamePurePlace(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l48
  br label %bb29
bb28:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb30
bb29:
  %t91 = load i1, ptr %l48, !tbaa !21
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb30
bb30:
  %t92 = load i1, ptr %l45, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_bc70ad18304b6571_160962e965f972e5)
  unreachable
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb37, label %bb38
bb37:
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb38
bb38:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb41
bb40:
  br label %bb53
bb41:
  %t109 = load ptr, ptr %l1, !tbaa !29
  store ptr %t109, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t110 = load ptr, ptr %l56, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 2
  store i1 %t116, ptr %l57, !tbaa !21
  br label %bb43
bb43:
  %t117 = load i1, ptr %l57, !tbaa !21
  br i1 %t117, label %bb44, label %bb45
bb44:
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t124 = load ptr, ptr %l8, !tbaa !29
  %t125 = load ptr, ptr %l9, !tbaa !29
  %t128 = call i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb47
bb47:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %rv
  br label %ret
bb48:
  br i1 true, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  call void @__olang_check_failed(ptr @olang_loc_6c7e0d9d91c4575a_bcb450b004b7d12e)
  unreachable
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_65fd46072274f65b_1273d4b3d3b84def)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l24 = alloca { i64, ptr }
  %l39 = alloca ptr
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 14
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Try", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Try", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  store i64 %t32, ptr %l4, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t42, ptr %l24, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr ptr, ptr %t46, i64 %t43
  %t48 = load ptr, ptr %t47, !tbaa !39
  %t52 = getelementptr %"compiler/typed:Clause", ptr %t48, i32 0, i32 4
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  store ptr %t59, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l3, !tbaa !24
  br label %bb9
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Try", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_497cb5294fb5d476_59996708b38ef322)
  unreachable
bb19:
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Try", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = call ptr @compiler_2ffree_2eunwrapped(ptr %v0, ptr %t75)
  store ptr %t77, ptr %l39
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l39, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @olang_loc_d76336629ed12804_de1ad14eaa737c40)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_3aFree_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca i64
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l63 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l112 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l114 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l115 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l116 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l118 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l119 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l120 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l121 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l122 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l123 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l124 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l125 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l127 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l128 = alloca %"compiler/free:Free"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, ptr %l4
  store ptr %a2, ptr %l5, !tbaa !29
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l75
  br label %bb1
bb1:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l76
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l8
  store ptr null, ptr %l9, !tbaa !29
  store i64 -1, ptr %l10, !tbaa !24
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l77
  br label %bb3
bb3:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l11
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l78
  br label %bb4
bb4:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l12
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l79
  br label %bb5
bb5:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l13
  %t17 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l80
  br label %bb6
bb6:
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l14
  %t19 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l81
  br label %bb7
bb7:
  %t20 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l15
  %t21 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l82
  br label %bb8
bb8:
  %t22 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l16
  %t23 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l83
  br label %bb9
bb9:
  %t24 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l17
  %t25 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_Hac9087a8ba6cac648ccbca7e31c711fc(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l84
  br label %bb10
bb10:
  %t26 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l18
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l85
  br label %bb11
bb11:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l19
  %t29 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l86
  br label %bb12
bb12:
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l86
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l20
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l87
  br label %bb13
bb13:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l21
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l88
  br label %bb14
bb14:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l22
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l89
  br label %bb15
bb15:
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l23
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l90
  br label %bb16
bb16:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l24
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l91
  br label %bb17
bb17:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l25
  %t41 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l92
  br label %bb18
bb18:
  %t42 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l26
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l93
  br label %bb19
bb19:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l27
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l94
  br label %bb20
bb20:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l28
  %t47 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l95
  br label %bb21
bb21:
  %t48 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l29
  %t49 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l96
  br label %bb22
bb22:
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l30
  %t51 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l97
  br label %bb23
bb23:
  %t52 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l31
  %t53 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l98
  br label %bb24
bb24:
  %t54 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l32
  store i1 false, ptr %l33, !tbaa !21
  store i1 false, ptr %l34, !tbaa !21
  store i1 false, ptr %l35, !tbaa !21
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l99
  br label %bb25
bb25:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l36
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l100
  br label %bb26
bb26:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l37
  %t59 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l101
  br label %bb27
bb27:
  %t60 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l38
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l102
  br label %bb28
bb28:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l39
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l103
  br label %bb29
bb29:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l40
  %t65 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l104
  br label %bb30
bb30:
  %t66 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l41
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l105
  br label %bb31
bb31:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l42
  %t69 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l106
  br label %bb32
bb32:
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l43
  %t71 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l107
  br label %bb33
bb33:
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l44
  store i64 -1, ptr %l45, !tbaa !24
  store i64 -1, ptr %l46, !tbaa !24
  %t73 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v3, i32 0, i32 0)
  store %"compiler/source:Span" %t73, ptr %l108
  br label %bb34
bb34:
  %t74 = load %"compiler/source:Span", ptr %l108
  store %"compiler/source:Span" %t74, ptr %l47
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l109
  br label %bb35
bb35:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l48
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l110
  br label %bb36
bb36:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l49
  %t79 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l111
  br label %bb37
bb37:
  %t80 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l50
  %t81 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l112
  br label %bb38
bb38:
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l112
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l51
  %t83 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l113
  br label %bb39
bb39:
  %t84 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l113
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l52
  %t85 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l114
  br label %bb40
bb40:
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l114
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l53
  %t87 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l115
  br label %bb41
bb41:
  %t88 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l54
  store i64 0, ptr %l55, !tbaa !24
  %t89 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v3)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %l116
  br label %bb42
bb42:
  %t90 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l116
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l56
  %t91 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l117
  br label %bb43
bb43:
  %t92 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l117
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %l57
  %t93 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l118
  br label %bb44
bb44:
  %t94 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l58
  %t95 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l119
  br label %bb45
bb45:
  %t96 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l119
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l59
  %t97 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l120
  br label %bb46
bb46:
  %t98 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l120
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l60
  %t99 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l121
  br label %bb47
bb47:
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l121
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %l61
  %t101 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %l122
  br label %bb48
bb48:
  %t102 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l122
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t102, ptr %l62
  %t103 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t103, ptr %l123
  br label %bb49
bb49:
  %t104 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l123
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %l63
  %t105 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t105, ptr %l124
  br label %bb50
bb50:
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l124
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l64
  %t107 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t107, ptr %l125
  br label %bb51
bb51:
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l125
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %l65
  %t109 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t109, ptr %l126
  br label %bb52
bb52:
  %t110 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l126
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %l66
  %t111 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %l127
  br label %bb53
bb53:
  %t112 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l127
  %t113 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 0
  %t114 = load ptr, ptr %l3, !tbaa !29
  store ptr %t114, ptr %t113, !tbaa !29
  %t115 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 1
  %t116 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 2
  %t118 = load ptr, ptr %l5, !tbaa !29
  store ptr %t118, ptr %t117, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 3
  %t120 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 4
  %t122 = load i64, ptr %l7, !tbaa !24
  store i64 %t122, ptr %t121, !tbaa !24
  %t123 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 5
  %t124 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t124, ptr %t123
  %t125 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 6
  %t126 = load ptr, ptr %l9, !tbaa !29
  store ptr %t126, ptr %t125, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 7
  %t128 = load i64, ptr %l10, !tbaa !24
  store i64 %t128, ptr %t127, !tbaa !24
  %t129 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 8
  %t130 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %t129
  %t131 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 9
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t131
  %t133 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 10
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t133
  %t135 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 11
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %t135
  %t137 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 12
  %t138 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 13
  %t140 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 14
  %t142 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 15
  %t144 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 16
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 17
  %t148 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t148, ptr %t147
  %t149 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 18
  %t150 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %t149
  %t151 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 19
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 20
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 21
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %t155
  %t157 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 22
  %t158 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %t157
  %t159 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 23
  %t160 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l26
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %t159
  %t161 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 24
  %t162 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %t161
  %t163 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 25
  %t164 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t164, ptr %t163
  %t165 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 26
  %t166 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %t165
  %t167 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 27
  %t168 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %t167
  %t169 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 28
  %t170 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %t169
  %t171 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 29
  %t172 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t172, ptr %t171
  %t173 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 30
  %t174 = load i1, ptr %l33, !tbaa !21
  store i1 %t174, ptr %t173, !tbaa !21
  %t175 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 31
  %t176 = load i1, ptr %l34, !tbaa !21
  store i1 %t176, ptr %t175, !tbaa !21
  %t177 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 32
  %t178 = load i1, ptr %l35, !tbaa !21
  store i1 %t178, ptr %t177, !tbaa !21
  %t179 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 33
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %t179
  %t181 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 34
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %t181
  %t183 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 35
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t183
  %t185 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 36
  %t186 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %t185
  %t187 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 37
  %t188 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %t187
  %t189 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 38
  %t190 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %t189
  %t191 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 39
  %t192 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %t191
  %t193 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 40
  %t194 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t193
  %t195 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 41
  %t196 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %t195
  %t197 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 42
  %t198 = load i64, ptr %l45, !tbaa !24
  store i64 %t198, ptr %t197, !tbaa !24
  %t199 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 43
  %t200 = load i64, ptr %l46, !tbaa !24
  store i64 %t200, ptr %t199, !tbaa !24
  %t201 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 44
  %t202 = load %"compiler/source:Span", ptr %l47
  store %"compiler/source:Span" %t202, ptr %t201
  %t203 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 45
  %t204 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t203
  %t205 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 46
  %t206 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %t205
  %t207 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 47
  %t208 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %t207
  %t209 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 48
  %t210 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t209
  %t211 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 49
  %t212 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %t211
  %t213 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 50
  %t214 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t213
  %t215 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 51
  %t216 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t216, ptr %t215
  %t217 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 52
  %t218 = load i64, ptr %l55, !tbaa !24
  store i64 %t218, ptr %t217, !tbaa !24
  %t219 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 53
  %t220 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %t219
  %t221 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 54
  %t222 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t222, ptr %t221
  %t223 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 55
  %t224 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t224, ptr %t223
  %t225 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 56
  %t226 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t226, ptr %t225
  %t227 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 57
  %t228 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l60
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, ptr %t227
  %t229 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 58
  %t230 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t230, ptr %t229
  %t231 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 59
  %t232 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l62
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %t231
  %t233 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 60
  %t234 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l63
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %t233
  %t235 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 61
  %t236 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %t235
  %t237 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 62
  %t238 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, ptr %t237
  %t239 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 63
  %t240 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %t239
  %t241 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t112, ptr %t241
  %t243 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 65
  store i64 -1, ptr %t243, !tbaa !24
  %t245 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 66
  store i1 true, ptr %t245, !tbaa !21
  %t247 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 67
  store i1 false, ptr %t247, !tbaa !21
  %t249 = getelementptr %"compiler/free:Free", ptr %l128, i32 0, i32 68
  store i1 false, ptr %t249, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l128, i64 520, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/free:leaf" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/free:leaf" %t6, i64 %a1, 1
  store %"compiler/free:leaf" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define dso_local %"compiler/free:orStore" @compiler_2ffree_3aorStore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/free:orStore"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/free:orStore" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/free:orStore" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/free:orStore" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/free:orStore" %t14, ptr %a3, 3
  store %"compiler/free:orStore" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:orStore", ptr %rv
  ret %"compiler/free:orStore" %rr
}

define dso_local %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/free:reason"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/free:reason" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/free:reason" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/free:reason" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/free:reason" %t14, { i64, ptr } %a3, 3
  store %"compiler/free:reason" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:reason", ptr %rv
  ret %"compiler/free:reason" %rr
}

define dso_local %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8) #0 {
entry:
  %rv = alloca %"compiler/free:store"
  br label %start
start:
  br label %bb0
bb0:
  %t20 = insertvalue %"compiler/free:store" undef, i64 %a0, 0
  %t22 = insertvalue %"compiler/free:store" %t20, i64 %a1, 1
  %t24 = insertvalue %"compiler/free:store" %t22, i64 %a2, 2
  %t26 = insertvalue %"compiler/free:store" %t24, %"compiler/source:Span" %a3, 3
  %t28 = insertvalue %"compiler/free:store" %t26, i64 %a4, 4
  %t30 = insertvalue %"compiler/free:store" %t28, i64 %a5, 5
  %t32 = insertvalue %"compiler/free:store" %t30, i64 %a6, 6
  %t34 = insertvalue %"compiler/free:store" %t32, ptr %a7, 7
  %t36 = insertvalue %"compiler/free:store" %t34, ptr %a8, 8
  store %"compiler/free:store" %t36, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:store", ptr %rv
  ret %"compiler/free:store" %rr
}

define dso_local void @olang_2einit_2ecompiler_2ffree() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2ffree_2eOPar_2einit()
  br label %bb1
bb1:
  call void @compiler_2ffree_2eOPl_2einit()
  br label %bb2
bb2:
  call void @compiler_2ffree_2eOMov_2einit()
  br label %bb3
bb3:
  call void @compiler_2ffree_2eONew_2einit()
  br label %bb4
bb4:
  call void @compiler_2ffree_2eOUnk_2einit()
  br label %bb5
bb5:
  call void @compiler_2ffree_2eMustTop_2einit()
  br label %bb6
bb6:
  call void @compiler_2ffree_2eMustNone_2einit()
  br label %bb7
bb7:
  call void @compiler_2ffree_2eMovBase_2einit()
  br label %bb8
bb8:
  call void @compiler_2ffree_2eRNone_2einit()
  br label %bb9
bb9:
  call void @compiler_2ffree_2eRStore_2einit()
  br label %bb10
bb10:
  call void @compiler_2ffree_2eRMade_2einit()
  br label %bb11
bb11:
  call void @compiler_2ffree_2eRView_2einit()
  br label %bb12
bb12:
  call void @compiler_2ffree_2eRTask_2einit()
  br label %bb13
bb13:
  call void @compiler_2ffree_2eRDtor_2einit()
  br label %bb14
bb14:
  call void @compiler_2ffree_2eSOk_2einit()
  br label %bb15
bb15:
  call void @compiler_2ffree_2eSFresh_2einit()
  br label %bb16
bb16:
  call void @compiler_2ffree_2eSMove_2einit()
  br label %bb17
bb17:
  call void @compiler_2ffree_2eSFail_2einit()
  br label %bb18
bb18:
  call void @compiler_2ffree_2eAnyPlace_2einit()
  br label %bb19
bb19:
  call void @compiler_2ffree_2eLAssign_2einit()
  br label %bb20
bb20:
  call void @compiler_2ffree_2eLLeaf_2einit()
  br label %bb21
bb21:
  call void @compiler_2ffree_2eLVacate_2einit()
  br label %bb22
bb22:
  call void @compiler_2ffree_2eLDrop_2einit()
  br label %bb23
bb23:
  call void @compiler_2ffree_2eLCall_2einit()
  br label %bb24
bb24:
  call void @compiler_2ffree_2eLDestroy_2einit()
  br label %bb25
bb25:
  call void @compiler_2ffree_2eLYield_2einit()
  br label %bb26
bb26:
  call void @compiler_2ffree_2eRemovalNames_2einit()
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pop" }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"TakeAt" }>, align 8
@.d2 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"RemoveAt" }>, align 8
@.d3 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"SwapRemove" }>, align 8
@.d4 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Remove" }>, align 8
@.d5 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clear" }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Truncate" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Take" }>, align 8
@.d8 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"SwapTake" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d10 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"removed elements of '" }>, align 8
@.d11 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' are kept until " }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" closes" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d14 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"' keeps what it lets go of until " }>, align 8
@.d15 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" closes" }>, align 8
@.d16 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"it lets go only in a module compiled on its own, where nothing is freed early" }>, align 8
@.d17 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c": note: " }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d20 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"memory: no place lets go of storage in code that runs again\0A" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" (above)" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"memory: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" place" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" let" }>, align 8
@.d34 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" go of storage in code that runs again - " }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" free" }>, align 8
@.d36 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" it at once, " }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" keep" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" it" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"T&" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d42 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"the function" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d48 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d49 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"the " }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d55 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'s scope" }>, align 8
@.d56 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"its scope" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d59 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"esc " }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d63 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" inside " }>, align 8
@.d64 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d67 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d68 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"it is handed here to what may keep it" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d71 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d72 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"a reference into it is kept here" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d83 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"its new value is built where the old one lives: '" }>, align 8
@.d84 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"' borrows its result from '" }>, align 8
@.d85 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"'; a built result ('" }>, align 8
@.d86 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"') frees the old " }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"its new value is not all new: '" }>, align 8
@.d89 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"' returns storage it was given" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"a reference to it is stored here, in '" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d97 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"it is handed here to a call that stores it" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d100 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d101 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"a reference into it is stored here, in '" }>, align 8
@.d104 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"'; store a copy, '$(...)'" }>, align 8
@.d105 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a reference into it is stored here; store a copy, '$(...)'" }>, align 8
@.d106 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"esc-store " }>, align 8
@.d107 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" par " }>, align 8
@.d108 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d109 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" within " }>, align 8
@.d110 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20s_Hac9087a8ba6cac648ccbca7e31c711fc(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aList_3_He58e4962dcc04e091d86d67e580ecc4e(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7b44f9c52fd18b13_e1efb1736ad37507 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erowBefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisContents(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/free:letGo" %a3)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_26303021143ae8be_4bef98a84a02e70a = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4cef24e7d17769b7_e2744f91577a9953 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyInLoop(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyUsedAfter(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestroyNotSole(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDestroyWhy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_947cc6b8bd079717_9e266d1a8b9c5cdb = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_708b3215abbdbba7_3cea2bd689d53e8b = external constant [0 x i8]
@olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eSetAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/free:reason" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H56aba43bb329356750417c3998c5c01b(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H1a2c153a44db96cb4cb83bb1fc8b3b35(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H760b547a4a2e251e7cfb0c9b0280f392(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f7ad8986a1f0ec72_6f5068ecfabe168e = external constant [0 x i8]
@olang_loc_990f3854282db1c_5d9957fc1d229790 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eLe_H729d11b3a9b9a6787781d29df4918101(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeVar_3e_2eAt_H9c4972d30d76581e4f8a183d5194d431(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bc9d64d7693be970_b83238a2b46aaa8c = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ffree_2eisVar({ i64, [1 x i64] } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7dd8bd34969f443_39b9f746f8dd52f7 = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_97a1f172ac127e68_91804f7c420b5df4 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__Hccd9659a44f570da1fa06b019882a84d(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f01b6368c240b0ef_955647351bed428b = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
@olang_loc_87d02dbc60271a1d_6e1627e36757d429 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_f3b0f19e5481d5e5_7f2cb84d865178e1 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_78dfe086e9f9163d_4fecfa12a5383061 = external constant [0 x i8]
@olang_loc_b4c0d703fa684531_272a8f4f39064c15 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_14962ab25e47b4fc_3749941476b1d040 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8d35557863f6e46b_2765f8f7d1e0ebdf = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_502532e2e95f04ea_fe436d8dc2f78aae = external constant [0 x i8]
@olang_loc_ba297c355e3740f1_9975a70d069e6a55 = external constant [0 x i8]
@olang_loc_bb85040a6a786cb8_20e886069e3b9c04 = external constant [0 x i8]
@olang_loc_be187497b97f18d7_9641cb8c9c409d3 = external constant [0 x i8]
@olang_loc_342e0c3fe78e7ee6_419d07e7c20dd892 = external constant [0 x i8]
@olang_loc_d5478abcfcd1a74_537f989617a8cff0 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7a954698926d7de_664d4c02e090fa22 = external constant [0 x i8]
@olang_loc_893474d063c17328_1c44af56cc3f848c = external constant [0 x i8]
declare i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_a532406d51285a24_27441d0f137c6648 = external constant [0 x i8]
@olang_loc_9be7a7b731d47dfc_cd79088c97deb358 = external constant [0 x i8]
@olang_loc_1777536395e8cd8b_97ff53b4c3030f1f = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eleaves(ptr %v0, ptr %a0)
@olang_loc_2fa77e012092fd19_7ffe9e1eddadbc5d = external constant [0 x i8]
declare i1 @compiler_2ffree_2eleavesFunction(ptr %v0, ptr %a0)
@olang_loc_59a6b24cdfdba848_73366ee735d239ac = external constant [0 x i8]
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ec84fe6443685676_e22a9bc60a48a0b2 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H514c3278d648f49337aafc4c9fcf3b34(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_Hfda32f46ad718b1ec245a2f2facf857a(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_d4fc5cdd71cd4f17_b1c92b5edf644a33 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_990ecb27a91b16dc_4f01b12db61c2318 = external constant [0 x i8]
declare i64 @compiler_2ffree_2eokind(i64 %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H12039caf93b9d99069d4e03abd3c3b80(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3_H1bfd72835118c4a69ac66e4bcdbec3db(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0)
@olang_loc_302fb708de33b00d_c45900720a6919e9 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_c391f8a5735a8ffa_e072efe91399830e = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@olang_loc_7230618287f0b47b_1190ffd62bcfb34f = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
@olang_loc_73260fd8b35b9100_131accabfa951114 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f51d6afa4bf67191_410ad0c8ce8b41c5 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_29274a8a17644d3e_88c903589875bd0a = external constant [0 x i8]
@olang_loc_9770790e28a8e96_84f72a57a788a45a = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_1928ae2b21411db7_7e7662c13839435b = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@olang_loc_5ca0c94719aba3bb_f8486f1b87c86b37 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_1d32823effd2173a_e896c8814911dc16 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_dc7e16ca98e3c304_3c9b7555f95fce88 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@olang_loc_c4f9ad7cc46c30d3_40011a8198a2fca7 = external constant [0 x i8]
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H082aedcd3ddb8fe82d6ff12d18e6e8d5(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
@olang_loc_fd3298abbcb5ff92_1a857839cb7bbff6 = external constant [0 x i8]
@olang_loc_5a2a443e2f2f03b9_3064adab7524445d = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_f2df24d87159f740_3aba0f93d819cd0c = external constant [0 x i8]
@olang_loc_e2fb89bbcc8912df_b34dca3bd4e44f7b = external constant [0 x i8]
@olang_loc_b9d8fe51bd9fb1ae_e9263c049ba8f2ba = external constant [0 x i8]
@olang_loc_67165cb650ae48c_1f30efdb88316bc8 = external constant [0 x i8]
@olang_loc_b6b576316e1b3293_3c9a5af727622297 = external constant [0 x i8]
@olang_loc_797639ecae530892_5422fc7df8fd29f6 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_fa71248d89b17b0b_39d265aac120d27f = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orCall" %a1)
declare ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ePush_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orStore" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eLe_H7b92c806358c31ec0113c885295670e0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eAt_H163e317dccec3ace9fb31d96922af4c2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_d8246f320a19bbf9_8add34a618744eed = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5d7536cc463ccac1_135a9313c745645 = external constant [0 x i8]
@olang_loc_c29efbd07efcecaa_a09dc8518182978e = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBlockInfo_3e_2eA_Hdb91c1ab6f912bb6141763aa02d0b766(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_407beb7582aa5744_e540dc6ed5e7bfd8 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ehandedToTask(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_2308fe183470e195_4baf259a414fa311 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %a0)
@olang_loc_99fb9e2ddedcc4fd_8483d8da78522e69 = external constant [0 x i8]
@olang_loc_2058a1f1b30311f1_26f3aef7996ef6dd = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
@olang_loc_1d3454c606268de0_1a2b7fbff193742c = external constant [0 x i8]
@olang_loc_c9e53ae0a52ca2db_3047dcba482a81a7 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_edceb98f3409ca88_d08d3a6b63bb4fc4 = external constant [0 x i8]
@olang_loc_326195846d385025_6126b0727ca50ba9 = external constant [0 x i8]
@olang_loc_3a04b2d1a65935f4_f1e41c995d4c38d8 = external constant [0 x i8]
declare ptr @compiler_2ffree_2ebaseOf(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ee9887f5f58478ff_db34cc814b361eab = external constant [0 x i8]
@olang_loc_d465c21b871057ed_46a08b0f1b8ea721 = external constant [0 x i8]
@olang_loc_11a48ff1e8d67007_90e1a85549f82d33 = external constant [0 x i8]
@olang_loc_e0188cd4392210a6_c14318bc74dc83b2 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_365b62d925fe4616_77c77337a4accaaa = external constant [0 x i8]
@olang_loc_9c97567f05482d15_e6d42a2535d66e1 = external constant [0 x i8]
@olang_loc_b94c5fec836ee160_c106f176e2c66bb4 = external constant [0 x i8]
@olang_loc_bc70ad18304b6571_160962e965f972e5 = external constant [0 x i8]
@olang_loc_6c7e0d9d91c4575a_bcb450b004b7d12e = external constant [0 x i8]
@olang_loc_65fd46072274f65b_1273d4b3d3b84def = external constant [0 x i8]
@olang_loc_497cb5294fb5d476_59996708b38ef322 = external constant [0 x i8]
@olang_loc_d76336629ed12804_de1ad14eaa737c40 = external constant [0 x i8]
declare void @compiler_2ffree_2eOPl_2einit()
declare void @compiler_2ffree_2eOMov_2einit()
declare void @compiler_2ffree_2eOUnk_2einit()
declare void @compiler_2ffree_2eMustTop_2einit()
declare void @compiler_2ffree_2eMustNone_2einit()
declare void @compiler_2ffree_2eMovBase_2einit()
declare void @compiler_2ffree_2eRStore_2einit()
declare void @compiler_2ffree_2eRView_2einit()
declare void @compiler_2ffree_2eRTask_2einit()
declare void @compiler_2ffree_2eRDtor_2einit()
declare void @compiler_2ffree_2eSOk_2einit()
declare void @compiler_2ffree_2eSFresh_2einit()
declare void @compiler_2ffree_2eAnyPlace_2einit()
declare void @compiler_2ffree_2eLAssign_2einit()
declare void @compiler_2ffree_2eLLeaf_2einit()
declare void @compiler_2ffree_2eLVacate_2einit()
declare void @compiler_2ffree_2eLDrop_2einit()
declare void @compiler_2ffree_2eLCall_2einit()
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2flist_3aList_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fprelude_2flist_3aList_3_He58e4962dcc04e091d86d67e580ecc4e(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cBool_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
