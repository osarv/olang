; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/definit:State" = type { i1, i1, i32, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/definit:Walker" = type { ptr, i32, i1, %"compiler/source:Span", i32, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2, %"compiler/definit:State" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l3 = alloca %"compiler/definit:State"
  %l4 = alloca %"compiler/definit:State"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l22 = alloca { i64, ptr }
  %l30 = alloca %"compiler/definit:State"
  %l39 = alloca { i64, ptr }
  %l47 = alloca %"compiler/definit:State"
  %l58 = alloca %"compiler/definit:State"
  %l63 = alloca %"compiler/definit:State"
  %l68 = alloca %"compiler/definit:State"
  %l69 = alloca %"compiler/definit:State"
  %l76 = alloca %"compiler/definit:State"
  %l77 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  store %"compiler/definit:State" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t1, ptr %l4
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/typed:Arm", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l22, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr ptr, ptr %t24, i64 %t21
  %t26 = load ptr, ptr %t25, !tbaa !39
  store ptr %t26, ptr %l8, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Alt", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = load %"compiler/definit:State", ptr %l4
  %t38 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t28, ptr %t32, %"compiler/definit:State" %t34)
  store %"compiler/definit:State" %t38, ptr %l30
  br label %bb5
bb5:
  %t39 = load %"compiler/definit:State", ptr %l30
  store %"compiler/definit:State" %t39, ptr %l4
  %t40 = load ptr, ptr %l8, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Alt", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l11, !tbaa !24
  br label %bb6
bb6:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t50 = load i64, ptr %l11, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t57, ptr %l39, !tbaa !27
  %t58 = load i64, ptr %l10, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Bind", ptr %t63, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = load %"compiler/definit:State", ptr %l4
  %t75 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t65, ptr %t69, %"compiler/definit:State" %t71)
  store %"compiler/definit:State" %t75, ptr %l47
  br label %bb10
bb10:
  %t76 = load %"compiler/definit:State", ptr %l47
  store %"compiler/definit:State" %t76, ptr %l4
  br label %bb11
bb11:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l10, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t82 = load i64, ptr %l6, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l6, !tbaa !24
  br label %bb1
bb14:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Arm", ptr %t88, i32 0, i32 2
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t92 = load %"compiler/definit:State", ptr %l4
  %t96 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91, %"compiler/definit:State" %t92)
  store %"compiler/definit:State" %t96, ptr %l58
  br label %bb15
bb15:
  %t97 = load %"compiler/definit:State", ptr %l58
  store %"compiler/definit:State" %t97, ptr %l4
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load %"compiler/definit:State", ptr %l4
  %t107 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t98, ptr %t102, %"compiler/definit:State" %t103)
  store %"compiler/definit:State" %t107, ptr %l63
  br label %bb16
bb16:
  %t108 = load %"compiler/definit:State", ptr %l63
  store %"compiler/definit:State" %t108, ptr %l4
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Arm", ptr %t110, i32 0, i32 4
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load %"compiler/definit:State", ptr %l4
  %t118 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t109, ptr %t113, %"compiler/definit:State" %t114)
  store %"compiler/definit:State" %t118, ptr %l68
  br label %bb17
bb17:
  %t119 = load %"compiler/definit:State", ptr %l68
  store %"compiler/definit:State" %t119, ptr %l4
  %t120 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t120, ptr %l69
  %t121 = load %"compiler/definit:State", ptr %l4
  %t122 = load %"compiler/definit:State", ptr %l2
  %t123 = load %"compiler/definit:State", ptr %l3
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Arm", ptr %t124, i32 0, i32 0
  %t127 = load %"compiler/source:Span", ptr %t126
  %t133 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t121, %"compiler/definit:State" %t122, %"compiler/definit:State" %t123, i32 4, %"compiler/source:Span" %t127)
  store %"compiler/definit:State" %t133, ptr %l76
  br label %bb18
bb18:
  %t134 = load %"compiler/definit:State", ptr %l69
  %t135 = load %"compiler/definit:State", ptr %l76
  %t136 = call %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %t134, %"compiler/definit:State" %t135)
  store %"compiler/definit:State" %t136, ptr %l77
  br label %bb19
bb19:
  %t137 = load %"compiler/definit:State", ptr %l77
  store %"compiler/definit:State" %t137, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblockSp(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/typed:BlockInfo"
  %l22 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/definit:Walker", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 8
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l13
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l13, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l8, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/definit:Walker", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 8
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t31, i64 %t32)
  store %"compiler/typed:BlockInfo" %t35, ptr %l20
  br label %bb7
bb6:
  %t36 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t36, ptr %l22
  br label %bb8
bb7:
  %t37 = getelementptr %"compiler/typed:BlockInfo", ptr %l20, i32 0, i32 2
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l15
  br label %bb9
bb8:
  %t40 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t40, ptr %l15
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/source:Span", ptr %l15
  store %"compiler/source:Span" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr1(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/definit:State"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/definit:State"
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca %"compiler/definit:State"
  %l17 = alloca %"compiler/definit:State"
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca %"compiler/definit:State"
  %l22 = alloca %"compiler/definit:State"
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/definit:State"
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca %"compiler/definit:State"
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca %"compiler/definit:State"
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca %"compiler/definit:State"
  %l88 = alloca ptr
  %l89 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l107 = alloca %"compiler/definit:State"
  %l112 = alloca %"compiler/definit:State"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l119 = alloca ptr
  %l121 = alloca ptr
  %l126 = alloca %"compiler/definit:State"
  %l127 = alloca %"compiler/definit:State"
  %l128 = alloca ptr
  %l129 = alloca i1
  %l138 = alloca %"compiler/definit:State"
  %l144 = alloca %"compiler/definit:State"
  %l146 = alloca ptr
  %l147 = alloca i1
  %l156 = alloca %"compiler/definit:State"
  %l161 = alloca %"compiler/definit:State"
  %l162 = alloca ptr
  %l163 = alloca i1
  %l168 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca ptr
  %l175 = alloca ptr
  %l180 = alloca %"compiler/definit:State"
  %l181 = alloca %"compiler/definit:State"
  %l182 = alloca %"compiler/definit:State"
  %l183 = alloca ptr
  %l184 = alloca i1
  %l194 = alloca %"compiler/definit:State"
  %l199 = alloca %"compiler/definit:State"
  %l205 = alloca %"compiler/definit:State"
  %l208 = alloca %"compiler/definit:State"
  %l209 = alloca ptr
  %l210 = alloca i1
  %l215 = alloca ptr
  %l217 = alloca ptr
  %l222 = alloca %"compiler/definit:State"
  %l223 = alloca %"compiler/definit:State"
  %l224 = alloca ptr
  %l225 = alloca i1
  %l234 = alloca %"compiler/definit:State"
  %l235 = alloca %"compiler/definit:State"
  %l244 = alloca { i64, ptr }
  %l251 = alloca %"compiler/definit:State"
  %l259 = alloca ptr
  %l267 = alloca %"compiler/definit:State"
  %l269 = alloca ptr
  %l270 = alloca i1
  %l279 = alloca %"compiler/definit:State"
  %l285 = alloca %"compiler/definit:State"
  %l286 = alloca ptr
  %l287 = alloca i1
  %l292 = alloca ptr
  %l293 = alloca i1
  %l306 = alloca { i64, ptr }
  %l314 = alloca %"compiler/definit:State"
  %l319 = alloca ptr
  %l320 = alloca i1
  %l329 = alloca %"compiler/definit:State"
  %l331 = alloca ptr
  %l332 = alloca i1
  %l346 = alloca { i64, ptr }
  %l349 = alloca ptr
  %l350 = alloca i1
  %l359 = alloca %"compiler/definit:State"
  %l364 = alloca ptr
  %l365 = alloca i1
  %l374 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t2 = load ptr, ptr %l45, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l45, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l46, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l46, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t11 = load ptr, ptr %l49, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l49, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l50, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l50, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t19 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t19, ptr %rv
  br label %ret
bb10:
  %t21 = load ptr, ptr %l1, !tbaa !29
  store ptr %t21, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t22 = load ptr, ptr %l54, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t25 = load ptr, ptr %l54, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 2
  store i1 %t28, ptr %l55, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l55, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t32, i32 0, i32 2
  %t34 = load ptr, ptr %t33
  store ptr %t34, ptr %l3, !tbaa !29
  br label %bb23
bb14:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t37 = load ptr, ptr %l60, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb15, label %bb16
bb15:
  %t40 = load ptr, ptr %l60, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 18}
  %t43 = icmp eq i64 %t41, 3
  store i1 %t43, ptr %l61, !tbaa !21
  br label %bb16
bb16:
  %t44 = load i1, ptr %l61, !tbaa !21
  br i1 %t44, label %bb17, label %bb18
bb17:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [5 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t47, i32 0, i32 2
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb23
bb18:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t52 = load ptr, ptr %l66, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load ptr, ptr %l66, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 18}
  %t58 = icmp eq i64 %t56, 4
  store i1 %t58, ptr %l67, !tbaa !21
  br label %bb20
bb20:
  %t59 = load i1, ptr %l67, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb21:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [5 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t68 = load %"compiler/definit:State", ptr %l2
  %t72 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t66, ptr %t67, %"compiler/definit:State" %t68)
  store %"compiler/definit:State" %t72, ptr %l75
  br label %bb24
bb24:
  %t73 = load %"compiler/definit:State", ptr %l75
  store %"compiler/definit:State" %t73, ptr %rv
  br label %ret
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t75 = load ptr, ptr %l76, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t78 = load ptr, ptr %l76, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 5
  store i1 %t81, ptr %l77, !tbaa !21
  br label %bb27
bb27:
  %t82 = load i1, ptr %l77, !tbaa !21
  br i1 %t82, label %bb28, label %bb29
bb28:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Promote", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = load %"compiler/definit:State", ptr %l2
  %t99 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93, %"compiler/definit:State" %t95)
  store %"compiler/definit:State" %t99, ptr %l87
  br label %bb31
bb31:
  %t100 = load %"compiler/definit:State", ptr %l87
  store %"compiler/definit:State" %t100, ptr %rv
  br label %ret
bb32:
  %t101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t101, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t102 = load ptr, ptr %l88, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb33, label %bb34
bb33:
  %t105 = load ptr, ptr %l88, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 18}
  %t108 = icmp eq i64 %t106, 6
  store i1 %t108, ptr %l89, !tbaa !21
  br label %bb34
bb34:
  %t109 = load i1, ptr %l89, !tbaa !21
  br i1 %t109, label %bb35, label %bb36
bb35:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb51
bb37:
  %t116 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t116, ptr %l6
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Call", ptr %t118, i32 0, i32 0
  %t121 = load ptr, ptr %t120, !tbaa !29
  store ptr %t121, ptr %l7, !tbaa !29
  %t123 = load ptr, ptr %l7, !tbaa !29
  store ptr %t123, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t124 = load ptr, ptr %l97, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb38, label %bb39
bb38:
  %t127 = load ptr, ptr %l97, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 5}
  %t130 = icmp eq i64 %t128, 2
  store i1 %t130, ptr %l98, !tbaa !21
  br label %bb39
bb39:
  %t131 = load i1, ptr %l98, !tbaa !21
  br i1 %t131, label %bb40, label %bb41
bb40:
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { ptr }, ptr %t134, i32 0, i32 0
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l8, !tbaa !29
  %t141 = load %"compiler/definit:State", ptr %l6
  %t145 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t138, ptr %t139, %"compiler/definit:State" %t141)
  store %"compiler/definit:State" %t145, ptr %l107
  br label %bb43
bb43:
  %t146 = load %"compiler/definit:State", ptr %l107
  store %"compiler/definit:State" %t146, ptr %l6
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_58a9ebc4913c6262_741c23f7607ff1de)
  unreachable
bb49:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l5, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Call", ptr %t148, i32 0, i32 1
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = load %"compiler/definit:State", ptr %l6
  %t156 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexprs(ptr %v0, ptr %v1, ptr %t147, { i64, ptr } %t151, %"compiler/definit:State" %t152)
  store %"compiler/definit:State" %t156, ptr %l112
  br label %bb50
bb50:
  %t157 = load %"compiler/definit:State", ptr %l112
  store %"compiler/definit:State" %t157, ptr %rv
  br label %ret
bb51:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t159 = load ptr, ptr %l113, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb52, label %bb53
bb52:
  %t162 = load ptr, ptr %l113, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 18}
  %t165 = icmp eq i64 %t163, 7
  store i1 %t165, ptr %l114, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l114, !tbaa !21
  br i1 %t166, label %bb54, label %bb55
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t169, i32 0, i32 2
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l9, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l119, !tbaa !29
  %t174 = load ptr, ptr %l9, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Make", ptr %t174, i32 0, i32 3
  %t177 = load ptr, ptr %t176, !tbaa !29
  store ptr %t177, ptr %l121, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l9, !tbaa !29
  %t181 = getelementptr %"compiler/typed:Make", ptr %t179, i32 0, i32 2
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load %"compiler/definit:State", ptr %l2
  %t187 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexprs(ptr %v0, ptr %v1, ptr %t178, { i64, ptr } %t182, %"compiler/definit:State" %t183)
  store %"compiler/definit:State" %t187, ptr %l126
  br label %bb57
bb57:
  %t188 = load ptr, ptr %l119, !tbaa !29
  %t189 = load ptr, ptr %l121, !tbaa !29
  %t190 = load %"compiler/definit:State", ptr %l126
  %t191 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t188, ptr %t189, %"compiler/definit:State" %t190)
  store %"compiler/definit:State" %t191, ptr %l127
  br label %bb58
bb58:
  %t192 = load %"compiler/definit:State", ptr %l127
  store %"compiler/definit:State" %t192, ptr %rv
  br label %ret
bb59:
  %t193 = load ptr, ptr %l1, !tbaa !29
  store ptr %t193, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t194 = load ptr, ptr %l128, !tbaa !29
  %t195 = icmp ne ptr %t194, null
  br i1 %t195, label %bb60, label %bb61
bb60:
  %t197 = load ptr, ptr %l128, !tbaa !29
  %t198 = load i64, ptr %t197, !range !{i64 0, i64 18}
  %t200 = icmp eq i64 %t198, 8
  store i1 %t200, ptr %l129, !tbaa !21
  br label %bb61
bb61:
  %t201 = load i1, ptr %l129, !tbaa !21
  br i1 %t201, label %bb62, label %bb63
bb62:
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr { i64, [5 x i64] }, ptr %t202, i32 0, i32 1
  %t205 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t204, i32 0, i32 2
  %t206 = load ptr, ptr %t205
  store ptr %t206, ptr %l10, !tbaa !29
  br label %bb64
bb63:
  br label %bb67
bb64:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l10, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Collect", ptr %t209, i32 0, i32 0
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load %"compiler/definit:State", ptr %l2
  %t217 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t208, ptr %t212, %"compiler/definit:State" %t213)
  store %"compiler/definit:State" %t217, ptr %l138
  br label %bb65
bb65:
  %t218 = load %"compiler/definit:State", ptr %l138
  store %"compiler/definit:State" %t218, ptr %l11
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l10, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Collect", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = load %"compiler/definit:State", ptr %l11
  %t229 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t219, ptr %t223, %"compiler/definit:State" %t225)
  store %"compiler/definit:State" %t229, ptr %l144
  br label %bb66
bb66:
  %t230 = load %"compiler/definit:State", ptr %l11
  store %"compiler/definit:State" %t230, ptr %rv
  br label %ret
bb67:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l146, !tbaa !29
  store i1 false, ptr %l147, !tbaa !21
  %t233 = load ptr, ptr %l146, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb68, label %bb69
bb68:
  %t236 = load ptr, ptr %l146, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 9
  store i1 %t239, ptr %l147, !tbaa !21
  br label %bb69
bb69:
  %t240 = load i1, ptr %l147, !tbaa !21
  br i1 %t240, label %bb70, label %bb71
bb70:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t243, i32 0, i32 2
  %t245 = load i32, ptr %t244, !range !{i32 0, i32 54}
  store i32 %t245, ptr %l12
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t247, i32 0, i32 1
  %t250 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t249, i32 0, i32 4
  %t251 = load { i64, ptr }, ptr %t250
  store { i64, ptr } %t251, ptr %l13, !tbaa !27
  br label %bb72
bb71:
  br label %bb77
bb72:
  %t253 = load i32, ptr %l12, !range !{i32 0, i32 54}
  %t255 = trunc i64 31 to i32
  %t256 = icmp eq i32 %t253, %t255
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t258 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t258, ptr %l156
  br label %bb76
bb74:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t262 = load %"compiler/definit:State", ptr %l2
  %t266 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexprs(ptr %v0, ptr %v1, ptr %t260, { i64, ptr } %t261, %"compiler/definit:State" %t262)
  store %"compiler/definit:State" %t266, ptr %l161
  br label %bb75
bb75:
  %t267 = load %"compiler/definit:State", ptr %l161
  store %"compiler/definit:State" %t267, ptr %l156
  br label %bb76
bb76:
  %t268 = load %"compiler/definit:State", ptr %l156
  store %"compiler/definit:State" %t268, ptr %rv
  br label %ret
bb77:
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t270 = load ptr, ptr %l162, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb78, label %bb79
bb78:
  %t273 = load ptr, ptr %l162, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 18}
  %t276 = icmp eq i64 %t274, 10
  store i1 %t276, ptr %l163, !tbaa !21
  br label %bb79
bb79:
  %t277 = load i1, ptr %l163, !tbaa !21
  br i1 %t277, label %bb80, label %bb81
bb80:
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l14, !tbaa !29
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l168, !tbaa !29
  %t285 = load ptr, ptr %l14, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Slice", ptr %t285, i32 0, i32 2
  %t288 = load ptr, ptr %t287, !tbaa !29
  store ptr %t288, ptr %l171, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l172, !tbaa !29
  %t291 = load ptr, ptr %l14, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Slice", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  store ptr %t294, ptr %l175, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l14, !tbaa !29
  %t299 = getelementptr %"compiler/typed:Slice", ptr %t297, i32 0, i32 0
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = load %"compiler/definit:State", ptr %l2
  %t305 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t296, ptr %t300, %"compiler/definit:State" %t301)
  store %"compiler/definit:State" %t305, ptr %l180
  br label %bb83
bb83:
  %t306 = load ptr, ptr %l172, !tbaa !29
  %t307 = load ptr, ptr %l175, !tbaa !29
  %t308 = load %"compiler/definit:State", ptr %l180
  %t309 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t306, ptr %t307, %"compiler/definit:State" %t308)
  store %"compiler/definit:State" %t309, ptr %l181
  br label %bb84
bb84:
  %t310 = load ptr, ptr %l168, !tbaa !29
  %t311 = load ptr, ptr %l171, !tbaa !29
  %t312 = load %"compiler/definit:State", ptr %l181
  %t313 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t310, ptr %t311, %"compiler/definit:State" %t312)
  store %"compiler/definit:State" %t313, ptr %l182
  br label %bb85
bb85:
  %t314 = load %"compiler/definit:State", ptr %l182
  store %"compiler/definit:State" %t314, ptr %rv
  br label %ret
bb86:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t316 = load ptr, ptr %l183, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb87, label %bb88
bb87:
  %t319 = load ptr, ptr %l183, !tbaa !29
  %t320 = load i64, ptr %t319, !range !{i64 0, i64 18}
  %t322 = icmp eq i64 %t320, 11
  store i1 %t322, ptr %l184, !tbaa !21
  br label %bb88
bb88:
  %t323 = load i1, ptr %l184, !tbaa !21
  br i1 %t323, label %bb89, label %bb90
bb89:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t326, i32 0, i32 2
  %t328 = load ptr, ptr %t327
  store ptr %t328, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb96
bb91:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l15, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Cond", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = load %"compiler/definit:State", ptr %l2
  %t340 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t330, ptr %t334, %"compiler/definit:State" %t336)
  store %"compiler/definit:State" %t340, ptr %l194
  br label %bb92
bb92:
  %t341 = load %"compiler/definit:State", ptr %l194
  store %"compiler/definit:State" %t341, ptr %l16
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load ptr, ptr %l15, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Cond", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load %"compiler/definit:State", ptr %l16
  %t351 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t342, ptr %t346, %"compiler/definit:State" %t347)
  store %"compiler/definit:State" %t351, ptr %l199
  br label %bb93
bb93:
  %t352 = load %"compiler/definit:State", ptr %l199
  store %"compiler/definit:State" %t352, ptr %l17
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l15, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Cond", ptr %t354, i32 0, i32 2
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t359 = load %"compiler/definit:State", ptr %l16
  %t363 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t353, ptr %t357, %"compiler/definit:State" %t359)
  store %"compiler/definit:State" %t363, ptr %l205
  br label %bb94
bb94:
  %t364 = load %"compiler/definit:State", ptr %l205
  %t365 = load %"compiler/definit:State", ptr %l17
  %t369 = call %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %t365, %"compiler/definit:State" %t364)
  store %"compiler/definit:State" %t369, ptr %l208
  br label %bb95
bb95:
  %t370 = load %"compiler/definit:State", ptr %l208
  store %"compiler/definit:State" %t370, ptr %rv
  br label %ret
bb96:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l209, !tbaa !29
  store i1 false, ptr %l210, !tbaa !21
  %t372 = load ptr, ptr %l209, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb97, label %bb98
bb97:
  %t375 = load ptr, ptr %l209, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 12
  store i1 %t378, ptr %l210, !tbaa !21
  br label %bb98
bb98:
  %t379 = load i1, ptr %l210, !tbaa !21
  br i1 %t379, label %bb99, label %bb100
bb99:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l19, !tbaa !29
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l215, !tbaa !29
  %t387 = load ptr, ptr %l19, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Seq", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  store ptr %t390, ptr %l217, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l19, !tbaa !29
  %t394 = getelementptr %"compiler/typed:Seq", ptr %t392, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  %t396 = load %"compiler/definit:State", ptr %l2
  %t400 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %v0, ptr %v1, ptr %t391, { i64, ptr } %t395, %"compiler/definit:State" %t396)
  store %"compiler/definit:State" %t400, ptr %l222
  br label %bb102
bb102:
  %t401 = load ptr, ptr %l215, !tbaa !29
  %t402 = load ptr, ptr %l217, !tbaa !29
  %t403 = load %"compiler/definit:State", ptr %l222
  %t404 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t401, ptr %t402, %"compiler/definit:State" %t403)
  store %"compiler/definit:State" %t404, ptr %l223
  br label %bb103
bb103:
  %t405 = load %"compiler/definit:State", ptr %l223
  store %"compiler/definit:State" %t405, ptr %rv
  br label %ret
bb104:
  %t406 = load ptr, ptr %l1, !tbaa !29
  store ptr %t406, ptr %l224, !tbaa !29
  store i1 false, ptr %l225, !tbaa !21
  %t407 = load ptr, ptr %l224, !tbaa !29
  %t408 = icmp ne ptr %t407, null
  br i1 %t408, label %bb105, label %bb106
bb105:
  %t410 = load ptr, ptr %l224, !tbaa !29
  %t411 = load i64, ptr %t410, !range !{i64 0, i64 18}
  %t413 = icmp eq i64 %t411, 13
  store i1 %t413, ptr %l225, !tbaa !21
  br label %bb106
bb106:
  %t414 = load i1, ptr %l225, !tbaa !21
  br i1 %t414, label %bb107, label %bb108
bb107:
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr { i64, [5 x i64] }, ptr %t415, i32 0, i32 1
  %t418 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t417, i32 0, i32 2
  %t419 = load ptr, ptr %t418
  store ptr %t419, ptr %l20, !tbaa !29
  br label %bb109
bb108:
  br label %bb126
bb109:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load ptr, ptr %l20, !tbaa !29
  %t424 = getelementptr %"compiler/typed:Match", ptr %t422, i32 0, i32 0
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t426 = load %"compiler/definit:State", ptr %l2
  %t430 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %v0, ptr %v1, ptr %t421, { i64, ptr } %t425, %"compiler/definit:State" %t426)
  store %"compiler/definit:State" %t430, ptr %l234
  br label %bb110
bb110:
  %t431 = load %"compiler/definit:State", ptr %l234
  store %"compiler/definit:State" %t431, ptr %l21
  %t432 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t432, ptr %l235
  br label %bb111
bb111:
  %t433 = load %"compiler/definit:State", ptr %l235
  store %"compiler/definit:State" %t433, ptr %l22
  %t434 = load ptr, ptr %l20, !tbaa !29
  %t436 = getelementptr %"compiler/typed:Match", ptr %t434, i32 0, i32 1
  %t437 = load { i64, ptr }, ptr %t436, !tbaa !27
  store { i64, ptr } %t437, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t439 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t439, 0
  store i64 %t441, ptr %l25, !tbaa !24
  br label %bb112
bb112:
  %t443 = load i64, ptr %l24, !tbaa !24
  %t444 = load i64, ptr %l25, !tbaa !24
  %t447 = icmp slt i64 %t443, %t444
  %t449 = xor i1 %t447, true
  br i1 %t449, label %bb113, label %bb114
bb113:
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t451 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t451, ptr %l244, !tbaa !27
  %t452 = load i64, ptr %l24, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr ptr, ptr %t455, i64 %t452
  %t457 = load ptr, ptr %t456, !tbaa !39
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = load %"compiler/definit:State", ptr %l21
  %t462 = load %"compiler/definit:State", ptr %l22
  %t467 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2earm(ptr %v0, ptr %v1, ptr %t459, ptr %t457, %"compiler/definit:State" %t461, %"compiler/definit:State" %t462)
  store %"compiler/definit:State" %t467, ptr %l251
  br label %bb116
bb116:
  %t468 = load %"compiler/definit:State", ptr %l251
  store %"compiler/definit:State" %t468, ptr %l22
  br label %bb117
bb117:
  %t469 = load i64, ptr %l24, !tbaa !24
  %t472 = add i64 %t469, 1
  store i64 %t472, ptr %l24, !tbaa !24
  br label %bb112
bb118:
  %t474 = load ptr, ptr %l20, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Match", ptr %t474, i32 0, i32 2
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = icmp eq ptr %t477, null
  %t481 = xor i1 %t479, true
  br i1 %t481, label %bb119, label %bb120
bb119:
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l259, !tbaa !29
  %t484 = load ptr, ptr %l20, !tbaa !29
  %t486 = getelementptr %"compiler/typed:Match", ptr %t484, i32 0, i32 2
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t489 = icmp eq ptr %t487, null
  br i1 %t489, label %bb121, label %bb122
bb120:
  br label %bb125
bb121:
  call void @__olang_check_failed(ptr @olang_loc_84c4d6ea62c85acc_37a8fef9eaee128)
  unreachable
bb122:
  br label %bb123
bb123:
  %t491 = load ptr, ptr %l20, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Match", ptr %t491, i32 0, i32 2
  %t494 = load ptr, ptr %t493, !tbaa !29
  %t495 = load %"compiler/definit:State", ptr %l21
  %t496 = load %"compiler/definit:State", ptr %l22
  %t497 = load ptr, ptr %l259, !tbaa !29
  %t501 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2earm(ptr %v0, ptr %v1, ptr %t497, ptr %t494, %"compiler/definit:State" %t495, %"compiler/definit:State" %t496)
  store %"compiler/definit:State" %t501, ptr %l267
  br label %bb124
bb124:
  %t502 = load %"compiler/definit:State", ptr %l267
  store %"compiler/definit:State" %t502, ptr %l22
  br label %bb125
bb125:
  %t503 = load %"compiler/definit:State", ptr %l22
  store %"compiler/definit:State" %t503, ptr %rv
  br label %ret
bb126:
  %t505 = load ptr, ptr %l1, !tbaa !29
  store ptr %t505, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t506 = load ptr, ptr %l269, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb127, label %bb128
bb127:
  %t509 = load ptr, ptr %l269, !tbaa !29
  %t510 = load i64, ptr %t509, !range !{i64 0, i64 18}
  %t512 = icmp eq i64 %t510, 14
  store i1 %t512, ptr %l270, !tbaa !21
  br label %bb128
bb128:
  %t513 = load i1, ptr %l270, !tbaa !21
  br i1 %t513, label %bb129, label %bb130
bb129:
  %t514 = load ptr, ptr %l1, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t516, i32 0, i32 2
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l27, !tbaa !29
  br label %bb131
bb130:
  br label %bb134
bb131:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t521 = load ptr, ptr %l27, !tbaa !29
  %t523 = getelementptr %"compiler/typed:Try", ptr %t521, i32 0, i32 0
  %t524 = load ptr, ptr %t523, !tbaa !29
  %t525 = load %"compiler/definit:State", ptr %l2
  %t529 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t520, ptr %t524, %"compiler/definit:State" %t525)
  store %"compiler/definit:State" %t529, ptr %l279
  br label %bb132
bb132:
  %t530 = load %"compiler/definit:State", ptr %l279
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load ptr, ptr %l27, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Try", ptr %t532, i32 0, i32 1
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  %t536 = load %"compiler/definit:State", ptr %l2
  %t542 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eclauses(ptr %v0, ptr %v1, ptr %t531, { i64, ptr } %t535, %"compiler/definit:State" %t536, %"compiler/definit:State" %t530)
  store %"compiler/definit:State" %t542, ptr %l285
  br label %bb133
bb133:
  %t543 = load %"compiler/definit:State", ptr %l285
  store %"compiler/definit:State" %t543, ptr %rv
  br label %ret
bb134:
  %t544 = load ptr, ptr %l1, !tbaa !29
  store ptr %t544, ptr %l286, !tbaa !29
  store i1 false, ptr %l287, !tbaa !21
  %t545 = load ptr, ptr %l286, !tbaa !29
  %t546 = icmp ne ptr %t545, null
  br i1 %t546, label %bb135, label %bb136
bb135:
  %t548 = load ptr, ptr %l286, !tbaa !29
  %t549 = load i64, ptr %t548, !range !{i64 0, i64 18}
  %t551 = icmp eq i64 %t549, 15
  store i1 %t551, ptr %l287, !tbaa !21
  br label %bb136
bb136:
  %t552 = load i1, ptr %l287, !tbaa !21
  br i1 %t552, label %bb137, label %bb138
bb137:
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t555 = getelementptr { i64, [5 x i64] }, ptr %t553, i32 0, i32 1
  %t556 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t555, i32 0, i32 2
  %t557 = load ptr, ptr %t556
  store ptr %t557, ptr %l29, !tbaa !29
  br label %bb139
bb138:
  br label %bb164
bb139:
  %t559 = load ptr, ptr %l29, !tbaa !29
  store ptr %t559, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t560 = load ptr, ptr %l292, !tbaa !29
  %t561 = icmp ne ptr %t560, null
  br i1 %t561, label %bb140, label %bb141
bb140:
  %t563 = load ptr, ptr %l292, !tbaa !29
  %t564 = load i64, ptr %t563, !range !{i64 0, i64 3}
  %t566 = icmp eq i64 %t564, 1
  store i1 %t566, ptr %l293, !tbaa !21
  br label %bb141
bb141:
  %t567 = load i1, ptr %l293, !tbaa !21
  br i1 %t567, label %bb142, label %bb143
bb142:
  %t568 = load ptr, ptr %l29, !tbaa !29
  %t570 = getelementptr { i64, [4 x i64] }, ptr %t568, i32 0, i32 1
  %t571 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t570, i32 0, i32 1
  %t572 = load { i64, ptr }, ptr %t571
  store { i64, ptr } %t572, ptr %l30, !tbaa !27
  br label %bb144
bb143:
  br label %bb152
bb144:
  %t574 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t574, ptr %l31
  %t576 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t576, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t578 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t578, 0
  store i64 %t580, ptr %l34, !tbaa !24
  br label %bb145
bb145:
  %t582 = load i64, ptr %l33, !tbaa !24
  %t583 = load i64, ptr %l34, !tbaa !24
  %t586 = icmp slt i64 %t582, %t583
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb146, label %bb147
bb146:
  br label %bb151
bb147:
  br label %bb148
bb148:
  %t590 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t590, ptr %l306, !tbaa !27
  %t591 = load i64, ptr %l33, !tbaa !24
  %t593 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t594 = load ptr, ptr %t593, !tbaa !27
  %t595 = getelementptr ptr, ptr %t594, i64 %t591
  %t596 = load ptr, ptr %t595, !tbaa !39
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/typed:Capture", ptr %t596, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = load %"compiler/definit:State", ptr %l31
  %t608 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t598, ptr %t602, %"compiler/definit:State" %t604)
  store %"compiler/definit:State" %t608, ptr %l314
  br label %bb149
bb149:
  %t609 = load %"compiler/definit:State", ptr %l314
  store %"compiler/definit:State" %t609, ptr %l31
  br label %bb150
bb150:
  %t610 = load i64, ptr %l33, !tbaa !24
  %t613 = add i64 %t610, 1
  store i64 %t613, ptr %l33, !tbaa !24
  br label %bb145
bb151:
  %t615 = load %"compiler/definit:State", ptr %l31
  store %"compiler/definit:State" %t615, ptr %rv
  br label %ret
bb152:
  %t617 = load ptr, ptr %l29, !tbaa !29
  store ptr %t617, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t618 = load ptr, ptr %l319, !tbaa !29
  %t619 = icmp ne ptr %t618, null
  br i1 %t619, label %bb153, label %bb154
bb153:
  %t621 = load ptr, ptr %l319, !tbaa !29
  %t622 = load i64, ptr %t621, !range !{i64 0, i64 3}
  %t624 = icmp eq i64 %t622, 2
  store i1 %t624, ptr %l320, !tbaa !21
  br label %bb154
bb154:
  %t625 = load i1, ptr %l320, !tbaa !21
  br i1 %t625, label %bb155, label %bb156
bb155:
  %t626 = load ptr, ptr %l29, !tbaa !29
  %t628 = getelementptr { i64, [4 x i64] }, ptr %t626, i32 0, i32 1
  %t629 = getelementptr { i32, ptr, i32 }, ptr %t628, i32 0, i32 1
  %t630 = load ptr, ptr %t629
  store ptr %t630, ptr %l36, !tbaa !29
  br label %bb157
bb156:
  br label %bb159
bb157:
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = load ptr, ptr %l36, !tbaa !29
  %t635 = load %"compiler/definit:State", ptr %l2
  %t639 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t632, ptr %t633, %"compiler/definit:State" %t635)
  store %"compiler/definit:State" %t639, ptr %l329
  br label %bb158
bb158:
  %t640 = load %"compiler/definit:State", ptr %l329
  store %"compiler/definit:State" %t640, ptr %rv
  br label %ret
bb159:
  br i1 true, label %bb160, label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb163
bb162:
  %t641 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t641, ptr %rv
  br label %ret
bb163:
  call void @__olang_check_failed(ptr @olang_loc_2666e55c871bfc88_11a50ffb28817424)
  unreachable
bb164:
  %t643 = load ptr, ptr %l1, !tbaa !29
  store ptr %t643, ptr %l331, !tbaa !29
  store i1 false, ptr %l332, !tbaa !21
  %t644 = load ptr, ptr %l331, !tbaa !29
  %t645 = icmp ne ptr %t644, null
  br i1 %t645, label %bb165, label %bb166
bb165:
  %t647 = load ptr, ptr %l331, !tbaa !29
  %t648 = load i64, ptr %t647, !range !{i64 0, i64 18}
  %t650 = icmp eq i64 %t648, 16
  store i1 %t650, ptr %l332, !tbaa !21
  br label %bb166
bb166:
  %t651 = load i1, ptr %l332, !tbaa !21
  br i1 %t651, label %bb167, label %bb168
bb167:
  %t652 = load ptr, ptr %l1, !tbaa !29
  %t654 = getelementptr { i64, [5 x i64] }, ptr %t652, i32 0, i32 1
  %t655 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t654, i32 0, i32 2
  %t656 = load ptr, ptr %t655
  store ptr %t656, ptr %l37, !tbaa !29
  br label %bb169
bb168:
  br label %bb182
bb169:
  %t658 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t658, ptr %l38
  %t660 = load ptr, ptr %l37, !tbaa !29
  %t662 = getelementptr %"compiler/typed:Text", ptr %t660, i32 0, i32 0
  %t663 = load { i64, ptr }, ptr %t662, !tbaa !27
  store { i64, ptr } %t663, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t665 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t665, 0
  store i64 %t667, ptr %l41, !tbaa !24
  br label %bb170
bb170:
  %t669 = load i64, ptr %l40, !tbaa !24
  %t670 = load i64, ptr %l41, !tbaa !24
  %t673 = icmp slt i64 %t669, %t670
  %t675 = xor i1 %t673, true
  br i1 %t675, label %bb171, label %bb172
bb171:
  br label %bb181
bb172:
  br label %bb173
bb173:
  %t677 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t677, ptr %l346, !tbaa !27
  %t678 = load i64, ptr %l40, !tbaa !24
  %t680 = getelementptr { i64, ptr }, ptr %l346, i32 0, i32 1
  %t681 = load ptr, ptr %t680, !tbaa !27
  %t682 = getelementptr ptr, ptr %t681, i64 %t678
  %t683 = load ptr, ptr %t682, !tbaa !39
  store ptr %t683, ptr %l42, !tbaa !29
  %t685 = load ptr, ptr %l42, !tbaa !29
  store ptr %t685, ptr %l349, !tbaa !29
  store i1 false, ptr %l350, !tbaa !21
  %t686 = load ptr, ptr %l349, !tbaa !29
  %t687 = icmp ne ptr %t686, null
  br i1 %t687, label %bb174, label %bb175
bb174:
  %t689 = load ptr, ptr %l349, !tbaa !29
  %t690 = load i64, ptr %t689, !range !{i64 0, i64 2}
  %t692 = icmp eq i64 %t690, 1
  store i1 %t692, ptr %l350, !tbaa !21
  br label %bb175
bb175:
  %t693 = load i1, ptr %l350, !tbaa !21
  br i1 %t693, label %bb176, label %bb177
bb176:
  %t694 = load ptr, ptr %l42, !tbaa !29
  %t696 = getelementptr { i64, [2 x i64] }, ptr %t694, i32 0, i32 1
  %t697 = getelementptr { ptr }, ptr %t696, i32 0, i32 0
  %t698 = load ptr, ptr %t697
  %t700 = load ptr, ptr %l0, !tbaa !29
  %t703 = load %"compiler/definit:State", ptr %l38
  %t707 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t700, ptr %t698, %"compiler/definit:State" %t703)
  store %"compiler/definit:State" %t707, ptr %l359
  br label %bb178
bb177:
  br label %bb179
bb178:
  %t708 = load %"compiler/definit:State", ptr %l359
  store %"compiler/definit:State" %t708, ptr %l38
  br label %bb179
bb179:
  br label %bb180
bb180:
  %t709 = load i64, ptr %l40, !tbaa !24
  %t712 = add i64 %t709, 1
  store i64 %t712, ptr %l40, !tbaa !24
  br label %bb170
bb181:
  %t714 = load %"compiler/definit:State", ptr %l38
  store %"compiler/definit:State" %t714, ptr %rv
  br label %ret
bb182:
  %t716 = load ptr, ptr %l1, !tbaa !29
  store ptr %t716, ptr %l364, !tbaa !29
  store i1 false, ptr %l365, !tbaa !21
  %t717 = load ptr, ptr %l364, !tbaa !29
  %t718 = icmp ne ptr %t717, null
  br i1 %t718, label %bb183, label %bb184
bb183:
  %t720 = load ptr, ptr %l364, !tbaa !29
  %t721 = load i64, ptr %t720, !range !{i64 0, i64 18}
  %t723 = icmp eq i64 %t721, 17
  store i1 %t723, ptr %l365, !tbaa !21
  br label %bb184
bb184:
  %t724 = load i1, ptr %l365, !tbaa !21
  br i1 %t724, label %bb185, label %bb186
bb185:
  %t725 = load ptr, ptr %l1, !tbaa !29
  %t727 = getelementptr { i64, [5 x i64] }, ptr %t725, i32 0, i32 1
  %t728 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t727, i32 0, i32 2
  %t729 = load ptr, ptr %t728
  store ptr %t729, ptr %l44, !tbaa !29
  br label %bb187
bb186:
  br label %bb189
bb187:
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t732 = load ptr, ptr %l44, !tbaa !29
  %t734 = load %"compiler/definit:State", ptr %l2
  %t738 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t731, ptr %t732, %"compiler/definit:State" %t734)
  store %"compiler/definit:State" %t738, ptr %l374
  br label %bb188
bb188:
  %t739 = load %"compiler/definit:State", ptr %l374
  store %"compiler/definit:State" %t739, ptr %rv
  br label %ret
bb189:
  call void @__olang_check_failed(ptr @olang_loc_156bf6b7f20d7659_5aae6743b02be315)
  unreachable
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"compiler/definit:State"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l20 = alloca { i64, ptr }
  %l27 = alloca %"compiler/definit:State"
  %rv = alloca %"compiler/definit:State"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/definit:State" %a2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t7 = icmp eq i64 %t5, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  %t36 = load %"compiler/definit:State", ptr %l3
  %t40 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t31, %"compiler/definit:State" %t36)
  store %"compiler/definit:State" %t40, ptr %l27
  br label %bb8
bb8:
  %t41 = load %"compiler/definit:State", ptr %l27
  store %"compiler/definit:State" %t41, ptr %l3
  br label %bb9
bb9:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  %t47 = load %"compiler/definit:State", ptr %l3
  store %"compiler/definit:State" %t47, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eisL(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = getelementptr %"compiler/definit:Walker", ptr %a0, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t23 = icmp eq i32 %t16, %t20
  store i1 %t23, ptr %l3, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_76be02bbb9c5cc0_603b59278fb7a8ac)
  unreachable
bb11:
  %t25 = load i1, ptr %l3, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/definit:State"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/definit:State"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca %"compiler/definit:State"
  %l11 = alloca %"compiler/definit:State"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/definit:State"
  %l16 = alloca i64
  %l17 = alloca %"compiler/definit:State"
  %l18 = alloca %"compiler/definit:State"
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/definit:State"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca %"compiler/definit:State"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca %"compiler/definit:State"
  %l33 = alloca ptr
  %l34 = alloca %"compiler/definit:State"
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i1
  %l59 = alloca %"compiler/definit:State"
  %l66 = alloca %"compiler/definit:State"
  %l68 = alloca ptr
  %l69 = alloca i1
  %l78 = alloca i1
  %l80 = alloca %"compiler/definit:State"
  %l85 = alloca %"compiler/definit:State"
  %l93 = alloca %"compiler/definit:State"
  %l94 = alloca i1
  %l97 = alloca i1
  %l98 = alloca i32
  %l100 = alloca i1
  %l104 = alloca %"compiler/definit:State"
  %l106 = alloca ptr
  %l107 = alloca i1
  %l116 = alloca %"compiler/definit:State"
  %l117 = alloca ptr
  %l118 = alloca i1
  %l130 = alloca %"compiler/definit:State"
  %l133 = alloca i64
  %l141 = alloca %"compiler/definit:State"
  %l148 = alloca %"compiler/definit:State"
  %l154 = alloca %"compiler/definit:State"
  %l158 = alloca %"compiler/definit:State"
  %l164 = alloca %"compiler/definit:State"
  %l165 = alloca %"compiler/definit:State"
  %l171 = alloca %"compiler/definit:State"
  %l172 = alloca %"compiler/definit:State"
  %l173 = alloca %"compiler/definit:State"
  %l174 = alloca %"compiler/definit:State"
  %l175 = alloca i32
  %l179 = alloca %"compiler/source:Span"
  %l180 = alloca %"compiler/definit:State"
  %l181 = alloca %"compiler/definit:State"
  %l182 = alloca %"compiler/definit:State"
  %l183 = alloca %"compiler/definit:State"
  %l184 = alloca i32
  %l185 = alloca ptr
  %l191 = alloca %"compiler/source:Span"
  %l192 = alloca %"compiler/definit:State"
  %l193 = alloca %"compiler/definit:State"
  %l194 = alloca ptr
  %l195 = alloca i1
  %l208 = alloca %"compiler/definit:State"
  %l212 = alloca %"compiler/definit:State"
  %l217 = alloca i1
  %l219 = alloca i1
  %l223 = alloca i1
  %l225 = alloca %"compiler/definit:State"
  %l227 = alloca i1
  %l234 = alloca %"compiler/definit:State"
  %l236 = alloca ptr
  %l237 = alloca i1
  %l240 = alloca %"compiler/definit:State"
  %l241 = alloca ptr
  %l242 = alloca i1
  %l250 = alloca %"compiler/definit:State"
  %l251 = alloca %"compiler/definit:State"
  %l252 = alloca ptr
  %l253 = alloca i1
  %l256 = alloca %"compiler/definit:State"
  %l257 = alloca ptr
  %l258 = alloca i1
  %l267 = alloca %"compiler/definit:State"
  %l268 = alloca %"compiler/definit:State"
  %l269 = alloca ptr
  %l270 = alloca i1
  %l278 = alloca %"compiler/definit:State"
  %l279 = alloca %"compiler/definit:State"
  %l280 = alloca ptr
  %l281 = alloca i1
  %l292 = alloca %"compiler/definit:State"
  %l296 = alloca %"compiler/definit:State"
  %l298 = alloca ptr
  %l299 = alloca i1
  %l308 = alloca %"compiler/definit:State"
  %l309 = alloca ptr
  %l310 = alloca i1
  %l319 = alloca %"compiler/definit:State"
  %l321 = alloca ptr
  %l322 = alloca i1
  %l332 = alloca %"compiler/definit:State"
  %l342 = alloca %"compiler/definit:State"
  %l343 = alloca ptr
  %l344 = alloca i1
  %l358 = alloca { i64, ptr }
  %l364 = alloca i1
  %l367 = alloca i1
  %l372 = alloca %"compiler/definit:State"
  %l381 = alloca %"compiler/definit:State"
  %l390 = alloca { i64, ptr }
  %l397 = alloca %"compiler/definit:State"
  %l402 = alloca ptr
  %l403 = alloca i1
  %l412 = alloca %"compiler/definit:State"
  %l413 = alloca ptr
  %l414 = alloca i1
  %l422 = alloca %"compiler/definit:State"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca %"compiler/definit:State"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/definit:State" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t2 = load ptr, ptr %l45, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l45, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l46, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l46, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = load %"compiler/definit:State", ptr %l2
  %t35 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t28, ptr %t29, %"compiler/definit:State" %t31)
  store %"compiler/definit:State" %t35, ptr %l59
  br label %bb6
bb6:
  %t36 = load %"compiler/definit:State", ptr %l59
  store %"compiler/definit:State" %t36, ptr %l6
  %t37 = load i32, ptr %l4, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/definit:Walker", ptr %t38, i32 0, i32 1
  %t41 = load i32, ptr %t40, !tbaa !23
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load %"compiler/source:Span", ptr %l3
  %t49 = call %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %s2, i1 true, i1 false, i32 0, %"compiler/source:Span" %t46)
  store %"compiler/definit:State" %t49, ptr %l66
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  %t50 = load %"compiler/definit:State", ptr %l66
  store %"compiler/definit:State" %t50, ptr %rv
  br label %ret
bb10:
  %t51 = load %"compiler/definit:State", ptr %l6
  store %"compiler/definit:State" %t51, ptr %rv
  br label %ret
bb11:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t54 = load ptr, ptr %l68, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l68, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l69, !tbaa !21
  br label %bb13
bb13:
  %t61 = load i1, ptr %l69, !tbaa !21
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l7, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l8, !tbaa !29
  br label %bb16
bb15:
  br label %bb35
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t78 = call i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eisL(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store i1 %t78, ptr %l78
  br label %bb17
bb17:
  %t79 = load i1, ptr %l78, !tbaa !21
  store i1 %t79, ptr %l9, !tbaa !21
  %t80 = load i1, ptr %l9, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  %t82 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t82, ptr %l80
  br label %bb21
bb19:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t86 = load %"compiler/definit:State", ptr %l2
  %t90 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t84, ptr %t85, %"compiler/definit:State" %t86)
  store %"compiler/definit:State" %t90, ptr %l85
  br label %bb20
bb20:
  %t91 = load %"compiler/definit:State", ptr %l85
  store %"compiler/definit:State" %t91, ptr %l80
  br label %bb21
bb21:
  %t92 = load %"compiler/definit:State", ptr %l80
  store %"compiler/definit:State" %t92, ptr %l10
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/definit:Walker", ptr %t93, i32 0, i32 6
  %t96 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t95, i1 %t96)
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t102 = load %"compiler/definit:State", ptr %l10
  %t106 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t100, %"compiler/definit:State" %t102)
  store %"compiler/definit:State" %t106, ptr %l93
  br label %bb23
bb23:
  %t107 = load %"compiler/definit:State", ptr %l93
  store %"compiler/definit:State" %t107, ptr %l11
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/definit:Walker", ptr %t108, i32 0, i32 6
  %t112 = call { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %t110)
  %t113 = extractvalue { i32, i1 } %t112, 1
  %t114 = extractvalue { i32, i1 } %t112, 0
  store i32 %t114, ptr %l98
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb25, label %ok.116, !prof !99
ok.116:
  store i1 %t113, ptr %l97
  br label %bb24
bb24:
  %t117 = load i1, ptr %l97, !tbaa !21
  store i1 %t117, ptr %l94, !tbaa !21
  br label %bb27
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t118 = load i1, ptr %l9, !tbaa !21
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = getelementptr %"compiler/definit:State", ptr %l11, i32 0, i32 0
  %t121 = load i1, ptr %t120, !tbaa !21
  store i1 %t121, ptr %l100, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb30
bb30:
  %t123 = load i1, ptr %l100, !tbaa !21
  br i1 %t123, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = getelementptr %"compiler/definit:State", ptr %l11, i32 0, i32 2
  %t125 = load i32, ptr %t124, !range !{i32 0, i32 6}
  %t126 = getelementptr %"compiler/definit:State", ptr %l11, i32 0, i32 3
  %t127 = load %"compiler/source:Span", ptr %t126
  %t130 = call %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %s5, i1 true, i1 true, i32 %t125, %"compiler/source:Span" %t127)
  store %"compiler/definit:State" %t130, ptr %l104
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s5)
  %t131 = load %"compiler/definit:State", ptr %l104
  store %"compiler/definit:State" %t131, ptr %rv
  br label %ret
bb34:
  %t132 = load %"compiler/definit:State", ptr %l11
  store %"compiler/definit:State" %t132, ptr %rv
  br label %ret
bb35:
  %t134 = load ptr, ptr %l1, !tbaa !29
  store ptr %t134, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t135 = load ptr, ptr %l106, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb36, label %bb37
bb36:
  %t138 = load ptr, ptr %l106, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 17}
  %t141 = icmp eq i64 %t139, 2
  store i1 %t141, ptr %l107, !tbaa !21
  br label %bb37
bb37:
  %t142 = load i1, ptr %l107, !tbaa !21
  br i1 %t142, label %bb38, label %bb39
bb38:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr }, ptr %t145, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l12, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l12, !tbaa !29
  %t152 = load %"compiler/definit:State", ptr %l2
  %t156 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t149, ptr %t150, %"compiler/definit:State" %t152)
  store %"compiler/definit:State" %t156, ptr %l116
  br label %bb41
bb41:
  %t157 = load %"compiler/definit:State", ptr %l116
  store %"compiler/definit:State" %t157, ptr %rv
  br label %ret
bb42:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t159 = load ptr, ptr %l117, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t162 = load ptr, ptr %l117, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 17}
  %t165 = icmp eq i64 %t163, 3
  store i1 %t165, ptr %l118, !tbaa !21
  br label %bb44
bb44:
  %t166 = load i1, ptr %l118, !tbaa !21
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr }, ptr %t169, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l13
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l14, !tbaa !29
  br label %bb47
bb46:
  br label %bb73
bb47:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l14, !tbaa !29
  %t182 = getelementptr %"compiler/typed:If", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = load %"compiler/definit:State", ptr %l2
  %t189 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t179, ptr %t183, %"compiler/definit:State" %t185)
  store %"compiler/definit:State" %t189, ptr %l130
  br label %bb48
bb48:
  %t190 = load %"compiler/definit:State", ptr %l130
  store %"compiler/definit:State" %t190, ptr %l15
  %t191 = load ptr, ptr %l14, !tbaa !29
  %t193 = getelementptr %"compiler/typed:If", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = call i64 @compiler_2fdefinit_2elitBool(ptr %v1, ptr %t194)
  store i64 %t196, ptr %l133
  br label %bb49
bb49:
  %t197 = load i64, ptr %l133, !tbaa !24
  store i64 %t197, ptr %l16, !tbaa !24
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = icmp eq i64 %t198, 1
  br i1 %t200, label %bb50, label %bb51
bb50:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l14, !tbaa !29
  %t205 = getelementptr %"compiler/typed:If", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = load %"compiler/definit:State", ptr %l15
  %t212 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t202, ptr %t206, %"compiler/definit:State" %t208)
  store %"compiler/definit:State" %t212, ptr %l141
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t213 = load %"compiler/definit:State", ptr %l141
  store %"compiler/definit:State" %t213, ptr %rv
  br label %ret
bb53:
  %t214 = load i64, ptr %l16, !tbaa !24
  %t216 = icmp eq i64 %t214, 0
  br i1 %t216, label %bb54, label %bb55
bb54:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l14, !tbaa !29
  %t221 = getelementptr %"compiler/typed:If", ptr %t219, i32 0, i32 2
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load %"compiler/definit:State", ptr %l15
  %t227 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t218, ptr %t222, %"compiler/definit:State" %t223)
  store %"compiler/definit:State" %t227, ptr %l148
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t228 = load %"compiler/definit:State", ptr %l148
  store %"compiler/definit:State" %t228, ptr %rv
  br label %ret
bb57:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l14, !tbaa !29
  %t232 = getelementptr %"compiler/typed:If", ptr %t230, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t235 = load %"compiler/definit:State", ptr %l15
  %t239 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t229, ptr %t233, %"compiler/definit:State" %t235)
  store %"compiler/definit:State" %t239, ptr %l154
  br label %bb58
bb58:
  %t240 = load %"compiler/definit:State", ptr %l154
  store %"compiler/definit:State" %t240, ptr %l17
  %t241 = load ptr, ptr %l14, !tbaa !29
  %t243 = getelementptr %"compiler/typed:If", ptr %t241, i32 0, i32 2
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = icmp eq ptr %t244, null
  br i1 %t246, label %bb59, label %bb60
bb59:
  %t248 = load %"compiler/definit:State", ptr %l17
  store %"compiler/definit:State" %t248, ptr %l158
  %t249 = load %"compiler/definit:State", ptr %l15
  %t250 = load %"compiler/definit:State", ptr %l15
  %t251 = load %"compiler/definit:State", ptr %l17
  %t252 = load %"compiler/source:Span", ptr %l13
  %t258 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t249, %"compiler/definit:State" %t250, %"compiler/definit:State" %t251, i32 1, %"compiler/source:Span" %t252)
  store %"compiler/definit:State" %t258, ptr %l164
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t259 = load %"compiler/definit:State", ptr %l158
  %t260 = load %"compiler/definit:State", ptr %l164
  %t261 = call %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %t259, %"compiler/definit:State" %t260)
  store %"compiler/definit:State" %t261, ptr %l165
  br label %bb62
bb62:
  %t262 = load %"compiler/definit:State", ptr %l165
  store %"compiler/definit:State" %t262, ptr %rv
  br label %ret
bb63:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load ptr, ptr %l14, !tbaa !29
  %t266 = getelementptr %"compiler/typed:If", ptr %t264, i32 0, i32 2
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = load %"compiler/definit:State", ptr %l15
  %t273 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t263, ptr %t267, %"compiler/definit:State" %t269)
  store %"compiler/definit:State" %t273, ptr %l171
  br label %bb64
bb64:
  %t274 = load %"compiler/definit:State", ptr %l171
  store %"compiler/definit:State" %t274, ptr %l18
  %t275 = load %"compiler/definit:State", ptr %l17
  store %"compiler/definit:State" %t275, ptr %l172
  %t276 = load %"compiler/definit:State", ptr %l15
  store %"compiler/definit:State" %t276, ptr %l173
  %t277 = load %"compiler/definit:State", ptr %l18
  store %"compiler/definit:State" %t277, ptr %l174
  store i32 2, ptr %l175
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l14, !tbaa !29
  %t281 = getelementptr %"compiler/typed:If", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t285 = call %"compiler/source:Span" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblockSp(ptr %v0, ptr %v1, ptr %t278, ptr %t282)
  store %"compiler/source:Span" %t285, ptr %l179
  br label %bb65
bb65:
  %t286 = load %"compiler/definit:State", ptr %l172
  %t287 = load %"compiler/definit:State", ptr %l173
  %t288 = load %"compiler/definit:State", ptr %l174
  %t289 = load i32, ptr %l175, !range !{i32 0, i32 6}
  %t290 = load %"compiler/source:Span", ptr %l179
  %t291 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t286, %"compiler/definit:State" %t287, %"compiler/definit:State" %t288, i32 %t289, %"compiler/source:Span" %t290)
  store %"compiler/definit:State" %t291, ptr %l180
  br label %bb66
bb66:
  %t292 = load %"compiler/definit:State", ptr %l18
  store %"compiler/definit:State" %t292, ptr %l181
  %t293 = load %"compiler/definit:State", ptr %l15
  store %"compiler/definit:State" %t293, ptr %l182
  %t294 = load %"compiler/definit:State", ptr %l17
  store %"compiler/definit:State" %t294, ptr %l183
  store i32 2, ptr %l184
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l185, !tbaa !29
  %t296 = load ptr, ptr %l14, !tbaa !29
  %t298 = getelementptr %"compiler/typed:If", ptr %t296, i32 0, i32 2
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  br i1 %t301, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_ac7b00276c8cb33f_f84bfacdca165d83)
  unreachable
bb68:
  br label %bb69
bb69:
  %t303 = load ptr, ptr %l14, !tbaa !29
  %t305 = getelementptr %"compiler/typed:If", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t307 = load ptr, ptr %l185, !tbaa !29
  %t309 = call %"compiler/source:Span" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblockSp(ptr %v0, ptr %v1, ptr %t307, ptr %t306)
  store %"compiler/source:Span" %t309, ptr %l191
  br label %bb70
bb70:
  %t310 = load %"compiler/definit:State", ptr %l181
  %t311 = load %"compiler/definit:State", ptr %l182
  %t312 = load %"compiler/definit:State", ptr %l183
  %t313 = load i32, ptr %l184, !range !{i32 0, i32 6}
  %t314 = load %"compiler/source:Span", ptr %l191
  %t315 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t310, %"compiler/definit:State" %t311, %"compiler/definit:State" %t312, i32 %t313, %"compiler/source:Span" %t314)
  store %"compiler/definit:State" %t315, ptr %l192
  br label %bb71
bb71:
  %t316 = load %"compiler/definit:State", ptr %l180
  %t317 = load %"compiler/definit:State", ptr %l192
  %t318 = call %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %t316, %"compiler/definit:State" %t317)
  store %"compiler/definit:State" %t318, ptr %l193
  br label %bb72
bb72:
  %t319 = load %"compiler/definit:State", ptr %l193
  store %"compiler/definit:State" %t319, ptr %rv
  br label %ret
bb73:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t321 = load ptr, ptr %l194, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb74, label %bb75
bb74:
  %t324 = load ptr, ptr %l194, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 17}
  %t327 = icmp eq i64 %t325, 4
  store i1 %t327, ptr %l195, !tbaa !21
  br label %bb75
bb75:
  %t328 = load i1, ptr %l195, !tbaa !21
  br i1 %t328, label %bb76, label %bb77
bb76:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t331, i32 0, i32 0
  %t333 = load %"compiler/source:Span", ptr %t332
  store %"compiler/source:Span" %t333, ptr %l19
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  %t338 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t337, i32 0, i32 1
  %t339 = load ptr, ptr %t338
  store ptr %t339, ptr %l20, !tbaa !29
  %t341 = load ptr, ptr %l1, !tbaa !29
  %t343 = getelementptr { i64, [3 x i64] }, ptr %t341, i32 0, i32 1
  %t344 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t343, i32 0, i32 2
  %t345 = load ptr, ptr %t344
  store ptr %t345, ptr %l21, !tbaa !29
  br label %bb78
bb77:
  br label %bb97
bb78:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load ptr, ptr %l20, !tbaa !29
  %t350 = load %"compiler/definit:State", ptr %l2
  %t354 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t347, ptr %t348, %"compiler/definit:State" %t350)
  store %"compiler/definit:State" %t354, ptr %l208
  br label %bb79
bb79:
  %t355 = load %"compiler/definit:State", ptr %l208
  store %"compiler/definit:State" %t355, ptr %l22
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = load ptr, ptr %l21, !tbaa !29
  %t358 = load %"compiler/definit:State", ptr %l2
  %t362 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t356, ptr %t357, %"compiler/definit:State" %t358)
  store %"compiler/definit:State" %t362, ptr %l212
  br label %bb80
bb80:
  %t363 = load ptr, ptr %l20, !tbaa !29
  %t365 = load ptr, ptr %l20, !tbaa !29
  %t367 = getelementptr %"compiler/typed:Block", ptr %t365, i32 0, i32 0
  %t368 = load i32, ptr %t367, !tbaa !23
  %t371 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v1, ptr %t363, i32 %t368)
  store i1 %t371, ptr %l217
  br label %bb81
bb81:
  %t372 = load i1, ptr %l217, !tbaa !21
  %t373 = xor i1 %t372, true
  br i1 %t373, label %bb82, label %bb83
bb82:
  %t375 = load ptr, ptr %l21, !tbaa !29
  %t376 = load ptr, ptr %l20, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Block", ptr %t376, i32 0, i32 0
  %t379 = load i32, ptr %t378, !tbaa !23
  %t382 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v1, ptr %t375, i32 %t379)
  store i1 %t382, ptr %l223
  br label %bb84
bb83:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb85
bb84:
  %t383 = load i1, ptr %l223, !tbaa !21
  %t384 = xor i1 %t383, true
  store i1 %t384, ptr %l219, !tbaa !21
  br label %bb85
bb85:
  %t386 = load i1, ptr %l219, !tbaa !21
  br i1 %t386, label %bb86, label %bb87
bb86:
  %t387 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t387, ptr %l225
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t388 = load %"compiler/definit:State", ptr %l225
  store %"compiler/definit:State" %t388, ptr %rv
  br label %ret
bb89:
  %t389 = getelementptr %"compiler/definit:State", ptr %l22, i32 0, i32 0
  %t390 = load i1, ptr %t389, !tbaa !21
  br i1 %t390, label %bb90, label %bb91
bb90:
  %t392 = getelementptr %"compiler/definit:State", ptr %l22, i32 0, i32 1
  %t393 = load i1, ptr %t392, !tbaa !21
  store i1 %t393, ptr %l227, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb92
bb92:
  %t395 = load i1, ptr %l227, !tbaa !21
  br i1 %t395, label %bb93, label %bb94
bb93:
  %t396 = load %"compiler/definit:State", ptr %l2
  %t397 = load %"compiler/definit:State", ptr %l2
  %t398 = load %"compiler/definit:State", ptr %l22
  %t399 = load %"compiler/source:Span", ptr %l19
  %t405 = call %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %t396, %"compiler/definit:State" %t397, %"compiler/definit:State" %t398, i32 3, %"compiler/source:Span" %t399)
  store %"compiler/definit:State" %t405, ptr %l234
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t406 = load %"compiler/definit:State", ptr %l234
  store %"compiler/definit:State" %t406, ptr %rv
  br label %ret
bb96:
  %t407 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t407, ptr %rv
  br label %ret
bb97:
  %t409 = load ptr, ptr %l1, !tbaa !29
  store ptr %t409, ptr %l236, !tbaa !29
  store i1 false, ptr %l237, !tbaa !21
  %t410 = load ptr, ptr %l236, !tbaa !29
  %t411 = icmp ne ptr %t410, null
  br i1 %t411, label %bb98, label %bb99
bb98:
  %t413 = load ptr, ptr %l236, !tbaa !29
  %t414 = load i64, ptr %t413, !range !{i64 0, i64 17}
  %t416 = icmp eq i64 %t414, 5
  store i1 %t416, ptr %l237, !tbaa !21
  br label %bb99
bb99:
  %t417 = load i1, ptr %l237, !tbaa !21
  br i1 %t417, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t418 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t418, ptr %l240
  br label %bb103
bb103:
  %t419 = load %"compiler/definit:State", ptr %l240
  store %"compiler/definit:State" %t419, ptr %rv
  br label %ret
bb104:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l241, !tbaa !29
  store i1 false, ptr %l242, !tbaa !21
  %t421 = load ptr, ptr %l241, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb105, label %bb106
bb105:
  %t424 = load ptr, ptr %l241, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 17}
  %t427 = icmp eq i64 %t425, 6
  store i1 %t427, ptr %l242, !tbaa !21
  br label %bb106
bb106:
  %t428 = load i1, ptr %l242, !tbaa !21
  br i1 %t428, label %bb107, label %bb108
bb107:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [3 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l23, !tbaa !29
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l23, !tbaa !29
  %t437 = load %"compiler/definit:State", ptr %l2
  %t441 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t435, ptr %t436, %"compiler/definit:State" %t437)
  store %"compiler/definit:State" %t441, ptr %l250
  br label %bb110
bb110:
  %t442 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t442, ptr %l251
  br label %bb111
bb111:
  %t443 = load %"compiler/definit:State", ptr %l251
  store %"compiler/definit:State" %t443, ptr %rv
  br label %ret
bb112:
  %t444 = load ptr, ptr %l1, !tbaa !29
  store ptr %t444, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t445 = load ptr, ptr %l252, !tbaa !29
  %t446 = icmp ne ptr %t445, null
  br i1 %t446, label %bb113, label %bb114
bb113:
  %t448 = load ptr, ptr %l252, !tbaa !29
  %t449 = load i64, ptr %t448, !range !{i64 0, i64 17}
  %t451 = icmp eq i64 %t449, 7
  store i1 %t451, ptr %l253, !tbaa !21
  br label %bb114
bb114:
  %t452 = load i1, ptr %l253, !tbaa !21
  br i1 %t452, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t453 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t453, ptr %l256
  br label %bb118
bb118:
  %t454 = load %"compiler/definit:State", ptr %l256
  store %"compiler/definit:State" %t454, ptr %rv
  br label %ret
bb119:
  %t455 = load ptr, ptr %l1, !tbaa !29
  store ptr %t455, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t456 = load ptr, ptr %l257, !tbaa !29
  %t457 = icmp ne ptr %t456, null
  br i1 %t457, label %bb120, label %bb121
bb120:
  %t459 = load ptr, ptr %l257, !tbaa !29
  %t460 = load i64, ptr %t459, !range !{i64 0, i64 17}
  %t462 = icmp eq i64 %t460, 8
  store i1 %t462, ptr %l258, !tbaa !21
  br label %bb121
bb121:
  %t463 = load i1, ptr %l258, !tbaa !21
  br i1 %t463, label %bb122, label %bb123
bb122:
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t466 = getelementptr { i64, [3 x i64] }, ptr %t464, i32 0, i32 1
  %t467 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t466, i32 0, i32 1
  %t468 = load ptr, ptr %t467
  store ptr %t468, ptr %l24, !tbaa !29
  br label %bb124
bb123:
  br label %bb127
bb124:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load ptr, ptr %l24, !tbaa !29
  %t473 = load %"compiler/definit:State", ptr %l2
  %t477 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t470, ptr %t471, %"compiler/definit:State" %t473)
  store %"compiler/definit:State" %t477, ptr %l267
  br label %bb125
bb125:
  %t478 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t478, ptr %l268
  br label %bb126
bb126:
  %t479 = load %"compiler/definit:State", ptr %l268
  store %"compiler/definit:State" %t479, ptr %rv
  br label %ret
bb127:
  %t480 = load ptr, ptr %l1, !tbaa !29
  store ptr %t480, ptr %l269, !tbaa !29
  store i1 false, ptr %l270, !tbaa !21
  %t481 = load ptr, ptr %l269, !tbaa !29
  %t482 = icmp ne ptr %t481, null
  br i1 %t482, label %bb128, label %bb129
bb128:
  %t484 = load ptr, ptr %l269, !tbaa !29
  %t485 = load i64, ptr %t484, !range !{i64 0, i64 17}
  %t487 = icmp eq i64 %t485, 9
  store i1 %t487, ptr %l270, !tbaa !21
  br label %bb129
bb129:
  %t488 = load i1, ptr %l270, !tbaa !21
  br i1 %t488, label %bb130, label %bb131
bb130:
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr { i64, [3 x i64] }, ptr %t489, i32 0, i32 1
  %t492 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t491, i32 0, i32 2
  %t493 = load ptr, ptr %t492
  store ptr %t493, ptr %l25, !tbaa !29
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load ptr, ptr %l25, !tbaa !29
  %t497 = load %"compiler/definit:State", ptr %l2
  %t501 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t495, ptr %t496, %"compiler/definit:State" %t497)
  store %"compiler/definit:State" %t501, ptr %l278
  br label %bb133
bb133:
  %t502 = call %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
  store %"compiler/definit:State" %t502, ptr %l279
  br label %bb134
bb134:
  %t503 = load %"compiler/definit:State", ptr %l279
  store %"compiler/definit:State" %t503, ptr %rv
  br label %ret
bb135:
  %t504 = load ptr, ptr %l1, !tbaa !29
  store ptr %t504, ptr %l280, !tbaa !29
  store i1 false, ptr %l281, !tbaa !21
  %t505 = load ptr, ptr %l280, !tbaa !29
  %t506 = icmp ne ptr %t505, null
  br i1 %t506, label %bb136, label %bb137
bb136:
  %t508 = load ptr, ptr %l280, !tbaa !29
  %t509 = load i64, ptr %t508, !range !{i64 0, i64 17}
  %t511 = icmp eq i64 %t509, 10
  store i1 %t511, ptr %l281, !tbaa !21
  br label %bb137
bb137:
  %t512 = load i1, ptr %l281, !tbaa !21
  br i1 %t512, label %bb138, label %bb139
bb138:
  %t513 = load ptr, ptr %l1, !tbaa !29
  %t515 = getelementptr { i64, [3 x i64] }, ptr %t513, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t515, i32 0, i32 1
  %t517 = load ptr, ptr %t516
  store ptr %t517, ptr %l26, !tbaa !29
  %t519 = load ptr, ptr %l1, !tbaa !29
  %t521 = getelementptr { i64, [3 x i64] }, ptr %t519, i32 0, i32 1
  %t522 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t521, i32 0, i32 2
  %t523 = load ptr, ptr %t522
  store ptr %t523, ptr %l27, !tbaa !29
  br label %bb140
bb139:
  br label %bb143
bb140:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load ptr, ptr %l26, !tbaa !29
  %t528 = load %"compiler/definit:State", ptr %l2
  %t532 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t525, ptr %t526, %"compiler/definit:State" %t528)
  store %"compiler/definit:State" %t532, ptr %l292
  br label %bb141
bb141:
  %t533 = load %"compiler/definit:State", ptr %l292
  store %"compiler/definit:State" %t533, ptr %l28
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load ptr, ptr %l27, !tbaa !29
  %t536 = load %"compiler/definit:State", ptr %l28
  %t540 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t534, ptr %t535, %"compiler/definit:State" %t536)
  store %"compiler/definit:State" %t540, ptr %l296
  br label %bb142
bb142:
  %t541 = load %"compiler/definit:State", ptr %l28
  store %"compiler/definit:State" %t541, ptr %rv
  br label %ret
bb143:
  %t543 = load ptr, ptr %l1, !tbaa !29
  store ptr %t543, ptr %l298, !tbaa !29
  store i1 false, ptr %l299, !tbaa !21
  %t544 = load ptr, ptr %l298, !tbaa !29
  %t545 = icmp ne ptr %t544, null
  br i1 %t545, label %bb144, label %bb145
bb144:
  %t547 = load ptr, ptr %l298, !tbaa !29
  %t548 = load i64, ptr %t547, !range !{i64 0, i64 17}
  %t550 = icmp eq i64 %t548, 11
  store i1 %t550, ptr %l299, !tbaa !21
  br label %bb145
bb145:
  %t551 = load i1, ptr %l299, !tbaa !21
  br i1 %t551, label %bb146, label %bb147
bb146:
  %t552 = load ptr, ptr %l1, !tbaa !29
  %t554 = getelementptr { i64, [3 x i64] }, ptr %t552, i32 0, i32 1
  %t555 = getelementptr { %"compiler/source:Span", ptr }, ptr %t554, i32 0, i32 1
  %t556 = load ptr, ptr %t555
  store ptr %t556, ptr %l29, !tbaa !29
  br label %bb148
bb147:
  br label %bb150
bb148:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load ptr, ptr %l29, !tbaa !29
  %t561 = load %"compiler/definit:State", ptr %l2
  %t565 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t558, ptr %t559, %"compiler/definit:State" %t561)
  store %"compiler/definit:State" %t565, ptr %l308
  br label %bb149
bb149:
  %t566 = load %"compiler/definit:State", ptr %l308
  store %"compiler/definit:State" %t566, ptr %rv
  br label %ret
bb150:
  %t567 = load ptr, ptr %l1, !tbaa !29
  store ptr %t567, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t568 = load ptr, ptr %l309, !tbaa !29
  %t569 = icmp ne ptr %t568, null
  br i1 %t569, label %bb151, label %bb152
bb151:
  %t571 = load ptr, ptr %l309, !tbaa !29
  %t572 = load i64, ptr %t571, !range !{i64 0, i64 17}
  %t574 = icmp eq i64 %t572, 12
  store i1 %t574, ptr %l310, !tbaa !21
  br label %bb152
bb152:
  %t575 = load i1, ptr %l310, !tbaa !21
  br i1 %t575, label %bb153, label %bb154
bb153:
  %t576 = load ptr, ptr %l1, !tbaa !29
  %t578 = getelementptr { i64, [3 x i64] }, ptr %t576, i32 0, i32 1
  %t579 = getelementptr { %"compiler/source:Span", ptr }, ptr %t578, i32 0, i32 1
  %t580 = load ptr, ptr %t579
  store ptr %t580, ptr %l30, !tbaa !29
  br label %bb155
bb154:
  br label %bb157
bb155:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t583 = load ptr, ptr %l30, !tbaa !29
  %t585 = load %"compiler/definit:State", ptr %l2
  %t589 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t582, ptr %t583, %"compiler/definit:State" %t585)
  store %"compiler/definit:State" %t589, ptr %l319
  br label %bb156
bb156:
  %t590 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t590, ptr %rv
  br label %ret
bb157:
  %t592 = load ptr, ptr %l1, !tbaa !29
  store ptr %t592, ptr %l321, !tbaa !29
  store i1 false, ptr %l322, !tbaa !21
  %t593 = load ptr, ptr %l321, !tbaa !29
  %t594 = icmp ne ptr %t593, null
  br i1 %t594, label %bb158, label %bb159
bb158:
  %t596 = load ptr, ptr %l321, !tbaa !29
  %t597 = load i64, ptr %t596, !range !{i64 0, i64 17}
  %t599 = icmp eq i64 %t597, 13
  store i1 %t599, ptr %l322, !tbaa !21
  br label %bb159
bb159:
  %t600 = load i1, ptr %l322, !tbaa !21
  br i1 %t600, label %bb160, label %bb161
bb160:
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t603 = getelementptr { i64, [3 x i64] }, ptr %t601, i32 0, i32 1
  %t604 = getelementptr { %"compiler/source:Span", ptr }, ptr %t603, i32 0, i32 1
  %t605 = load ptr, ptr %t604
  store ptr %t605, ptr %l31, !tbaa !29
  br label %bb162
bb161:
  br label %bb168
bb162:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t608 = load ptr, ptr %l31, !tbaa !29
  %t610 = getelementptr %"compiler/typed:Join", ptr %t608, i32 0, i32 0
  %t611 = load ptr, ptr %t610, !tbaa !29
  %t613 = load %"compiler/definit:State", ptr %l2
  %t617 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %t607, ptr %t611, %"compiler/definit:State" %t613)
  store %"compiler/definit:State" %t617, ptr %l332
  br label %bb163
bb163:
  %t618 = load %"compiler/definit:State", ptr %l332
  store %"compiler/definit:State" %t618, ptr %l32
  %t619 = load ptr, ptr %l31, !tbaa !29
  %t621 = getelementptr %"compiler/typed:Join", ptr %t619, i32 0, i32 1
  %t622 = load i1, ptr %t621, !tbaa !21
  %t624 = xor i1 %t622, true
  br i1 %t624, label %bb164, label %bb165
bb164:
  %t626 = load %"compiler/definit:State", ptr %l32
  store %"compiler/definit:State" %t626, ptr %rv
  br label %ret
bb165:
  br label %bb166
bb166:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load ptr, ptr %l31, !tbaa !29
  %t631 = getelementptr %"compiler/typed:Join", ptr %t629, i32 0, i32 2
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  %t633 = load %"compiler/definit:State", ptr %l2
  %t634 = load %"compiler/definit:State", ptr %l32
  %t639 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eclauses(ptr %v0, ptr %v1, ptr %t628, { i64, ptr } %t632, %"compiler/definit:State" %t633, %"compiler/definit:State" %t634)
  store %"compiler/definit:State" %t639, ptr %l342
  br label %bb167
bb167:
  %t640 = load %"compiler/definit:State", ptr %l342
  store %"compiler/definit:State" %t640, ptr %rv
  br label %ret
bb168:
  %t641 = load ptr, ptr %l1, !tbaa !29
  store ptr %t641, ptr %l343, !tbaa !29
  store i1 false, ptr %l344, !tbaa !21
  %t642 = load ptr, ptr %l343, !tbaa !29
  %t643 = icmp ne ptr %t642, null
  br i1 %t643, label %bb169, label %bb170
bb169:
  %t645 = load ptr, ptr %l343, !tbaa !29
  %t646 = load i64, ptr %t645, !range !{i64 0, i64 17}
  %t648 = icmp eq i64 %t646, 14
  store i1 %t648, ptr %l344, !tbaa !21
  br label %bb170
bb170:
  %t649 = load i1, ptr %l344, !tbaa !21
  br i1 %t649, label %bb171, label %bb172
bb171:
  %t650 = load ptr, ptr %l1, !tbaa !29
  %t652 = getelementptr { i64, [3 x i64] }, ptr %t650, i32 0, i32 1
  %t653 = getelementptr { %"compiler/source:Span", ptr }, ptr %t652, i32 0, i32 1
  %t654 = load ptr, ptr %t653
  store ptr %t654, ptr %l33, !tbaa !29
  br label %bb173
bb172:
  br label %bb196
bb173:
  %t656 = load %"compiler/definit:State", ptr %l2
  store %"compiler/definit:State" %t656, ptr %l34
  %t658 = load ptr, ptr %l33, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Spawn", ptr %t658, i32 0, i32 0
  %t661 = load { i64, ptr }, ptr %t660, !tbaa !27
  store { i64, ptr } %t661, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t663 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t663, 0
  store i64 %t665, ptr %l37, !tbaa !24
  br label %bb174
bb174:
  %t667 = load i64, ptr %l36, !tbaa !24
  %t668 = load i64, ptr %l37, !tbaa !24
  %t671 = icmp slt i64 %t667, %t668
  %t673 = xor i1 %t671, true
  br i1 %t673, label %bb175, label %bb176
bb175:
  br label %bb187
bb176:
  br label %bb177
bb177:
  %t675 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t675, ptr %l358, !tbaa !27
  %t676 = load i64, ptr %l36, !tbaa !24
  %t678 = getelementptr { i64, ptr }, ptr %l358, i32 0, i32 1
  %t679 = load ptr, ptr %t678, !tbaa !27
  %t680 = getelementptr ptr, ptr %t679, i64 %t676
  %t681 = load ptr, ptr %t680, !tbaa !39
  store ptr %t681, ptr %l38, !tbaa !29
  %t683 = load ptr, ptr %l38, !tbaa !29
  %t685 = icmp eq ptr %t683, null
  %t687 = xor i1 %t685, true
  br i1 %t687, label %bb178, label %bb179
bb178:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load ptr, ptr %l38, !tbaa !29
  %t693 = call i1 @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eisL(ptr %v0, ptr %v1, ptr %t689, ptr %t690)
  store i1 %t693, ptr %l367
  br label %bb180
bb179:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb181
bb180:
  %t694 = load i1, ptr %l367, !tbaa !21
  %t695 = xor i1 %t694, true
  store i1 %t695, ptr %l364, !tbaa !21
  br label %bb181
bb181:
  %t697 = load i1, ptr %l364, !tbaa !21
  br i1 %t697, label %bb182, label %bb183
bb182:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load ptr, ptr %l38, !tbaa !29
  %t700 = load %"compiler/definit:State", ptr %l34
  %t704 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %t698, ptr %t699, %"compiler/definit:State" %t700)
  store %"compiler/definit:State" %t704, ptr %l372
  br label %bb184
bb183:
  br label %bb185
bb184:
  %t705 = load %"compiler/definit:State", ptr %l372
  store %"compiler/definit:State" %t705, ptr %l34
  br label %bb185
bb185:
  br label %bb186
bb186:
  %t706 = load i64, ptr %l36, !tbaa !24
  %t709 = add i64 %t706, 1
  store i64 %t709, ptr %l36, !tbaa !24
  br label %bb174
bb187:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t712 = load ptr, ptr %l33, !tbaa !29
  %t714 = getelementptr %"compiler/typed:Spawn", ptr %t712, i32 0, i32 1
  %t715 = load ptr, ptr %t714, !tbaa !29
  %t717 = load %"compiler/definit:State", ptr %l34
  %t721 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t711, ptr %t715, %"compiler/definit:State" %t717)
  store %"compiler/definit:State" %t721, ptr %l381
  br label %bb188
bb188:
  %t722 = load %"compiler/definit:State", ptr %l381
  store %"compiler/definit:State" %t722, ptr %l34
  %t723 = load ptr, ptr %l33, !tbaa !29
  %t725 = getelementptr %"compiler/typed:Spawn", ptr %t723, i32 0, i32 2
  %t726 = load { i64, ptr }, ptr %t725, !tbaa !27
  store { i64, ptr } %t726, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t728 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t730 = extractvalue { i64, ptr } %t728, 0
  store i64 %t730, ptr %l41, !tbaa !24
  br label %bb189
bb189:
  %t732 = load i64, ptr %l40, !tbaa !24
  %t733 = load i64, ptr %l41, !tbaa !24
  %t736 = icmp slt i64 %t732, %t733
  %t738 = xor i1 %t736, true
  br i1 %t738, label %bb190, label %bb191
bb190:
  br label %bb195
bb191:
  br label %bb192
bb192:
  %t740 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t740, ptr %l390, !tbaa !27
  %t741 = load i64, ptr %l40, !tbaa !24
  %t743 = getelementptr { i64, ptr }, ptr %l390, i32 0, i32 1
  %t744 = load ptr, ptr %t743, !tbaa !27
  %t745 = getelementptr ptr, ptr %t744, i64 %t741
  %t746 = load ptr, ptr %t745, !tbaa !39
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t751 = getelementptr %"compiler/typed:TaskClause", ptr %t746, i32 0, i32 3
  %t752 = load ptr, ptr %t751, !tbaa !29
  %t753 = load %"compiler/definit:State", ptr %l34
  %t757 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t748, ptr %t752, %"compiler/definit:State" %t753)
  store %"compiler/definit:State" %t757, ptr %l397
  br label %bb193
bb193:
  br label %bb194
bb194:
  %t758 = load i64, ptr %l40, !tbaa !24
  %t761 = add i64 %t758, 1
  store i64 %t761, ptr %l40, !tbaa !24
  br label %bb189
bb195:
  %t763 = load %"compiler/definit:State", ptr %l34
  store %"compiler/definit:State" %t763, ptr %rv
  br label %ret
bb196:
  %t765 = load ptr, ptr %l1, !tbaa !29
  store ptr %t765, ptr %l402, !tbaa !29
  store i1 false, ptr %l403, !tbaa !21
  %t766 = load ptr, ptr %l402, !tbaa !29
  %t767 = icmp ne ptr %t766, null
  br i1 %t767, label %bb197, label %bb198
bb197:
  %t769 = load ptr, ptr %l402, !tbaa !29
  %t770 = load i64, ptr %t769, !range !{i64 0, i64 17}
  %t772 = icmp eq i64 %t770, 15
  store i1 %t772, ptr %l403, !tbaa !21
  br label %bb198
bb198:
  %t773 = load i1, ptr %l403, !tbaa !21
  br i1 %t773, label %bb199, label %bb200
bb199:
  %t774 = load ptr, ptr %l1, !tbaa !29
  %t776 = getelementptr { i64, [3 x i64] }, ptr %t774, i32 0, i32 1
  %t777 = getelementptr { %"compiler/source:Span", ptr }, ptr %t776, i32 0, i32 1
  %t778 = load ptr, ptr %t777
  store ptr %t778, ptr %l43, !tbaa !29
  br label %bb201
bb200:
  br label %bb203
bb201:
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load ptr, ptr %l43, !tbaa !29
  %t783 = load %"compiler/definit:State", ptr %l2
  %t787 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t780, ptr %t781, %"compiler/definit:State" %t783)
  store %"compiler/definit:State" %t787, ptr %l412
  br label %bb202
bb202:
  %t788 = load %"compiler/definit:State", ptr %l412
  store %"compiler/definit:State" %t788, ptr %rv
  br label %ret
bb203:
  %t789 = load ptr, ptr %l1, !tbaa !29
  store ptr %t789, ptr %l413, !tbaa !29
  store i1 false, ptr %l414, !tbaa !21
  %t790 = load ptr, ptr %l413, !tbaa !29
  %t791 = icmp ne ptr %t790, null
  br i1 %t791, label %bb204, label %bb205
bb204:
  %t793 = load ptr, ptr %l413, !tbaa !29
  %t794 = load i64, ptr %t793, !range !{i64 0, i64 17}
  %t796 = icmp eq i64 %t794, 16
  store i1 %t796, ptr %l414, !tbaa !21
  br label %bb205
bb205:
  %t797 = load i1, ptr %l414, !tbaa !21
  br i1 %t797, label %bb206, label %bb207
bb206:
  %t798 = load ptr, ptr %l1, !tbaa !29
  %t800 = getelementptr { i64, [3 x i64] }, ptr %t798, i32 0, i32 1
  %t801 = getelementptr { %"compiler/source:Span", ptr }, ptr %t800, i32 0, i32 1
  %t802 = load ptr, ptr %t801
  store ptr %t802, ptr %l44, !tbaa !29
  br label %bb208
bb207:
  br label %bb210
bb208:
  %t804 = load ptr, ptr %l0, !tbaa !29
  %t805 = load ptr, ptr %l44, !tbaa !29
  %t806 = load %"compiler/definit:State", ptr %l2
  %t810 = call %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %t804, ptr %t805, %"compiler/definit:State" %t806)
  store %"compiler/definit:State" %t810, ptr %l422
  br label %bb209
bb209:
  %t811 = load %"compiler/definit:State", ptr %l422
  store %"compiler/definit:State" %t811, ptr %rv
  br label %ret
bb210:
  call void @__olang_check_failed(ptr @olang_loc_86e100904f39c567_d61ce50e57b89f1b)
  unreachable
ret:
  %rr = load %"compiler/definit:State", ptr %rv
  ret %"compiler/definit:State" %rr
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l19 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l6, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30, i1 %t32)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Alt", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb6
bb6:
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t53, ptr %l35, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr ptr, ptr %t57, i64 %t54
  %t59 = load ptr, ptr %t58, !tbaa !39
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Bind", ptr %t59, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t61, ptr %t65, i1 %t67)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = add i64 %t76, 1
  store i64 %t79, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t81, ptr %t85, i1 %t86)
  br label %bb15
bb15:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 3
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t90, ptr %t94, i1 %t95)
  br label %bb16
bb16:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Arm", ptr %t100, i32 0, i32 4
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t104 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t103, i1 %t104)
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca ptr
  %l197 = alloca i1
  %l214 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l234 = alloca ptr
  %l235 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l254 = alloca ptr
  %l255 = alloca i1
  %l258 = alloca ptr
  %l259 = alloca i1
  %l271 = alloca { i64, ptr }
  %l281 = alloca ptr
  %l282 = alloca i1
  %l290 = alloca ptr
  %l291 = alloca i1
  %l304 = alloca { i64, ptr }
  %l307 = alloca ptr
  %l308 = alloca i1
  %l320 = alloca ptr
  %l321 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t6 = load ptr, ptr %l37, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l37, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l38, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t15 = load ptr, ptr %l41, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l41, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l42, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb194
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t24 = load ptr, ptr %l45, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l45, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l46, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l46, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t39 = load ptr, ptr %l51, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l51, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l52, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l52, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t54 = load ptr, ptr %l57, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l57, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l58, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l58, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69, i1 %t70)
  br label %bb27
bb27:
  br label %bb194
bb28:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t75 = load ptr, ptr %l66, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb29, label %bb30
bb29:
  %t78 = load ptr, ptr %l66, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 5
  store i1 %t81, ptr %l67, !tbaa !21
  br label %bb30
bb30:
  %t82 = load i1, ptr %l67, !tbaa !21
  br i1 %t82, label %bb31, label %bb32
bb31:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Promote", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93, i1 %t95)
  br label %bb34
bb34:
  br label %bb194
bb35:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t100 = load ptr, ptr %l77, !tbaa !29
  %t101 = icmp ne ptr %t100, null
  br i1 %t101, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t104 = load i64, ptr %t103, !range !{i64 0, i64 18}
  %t106 = icmp eq i64 %t104, 6
  store i1 %t106, ptr %l78, !tbaa !21
  br label %bb37
bb37:
  %t107 = load i1, ptr %l78, !tbaa !21
  br i1 %t107, label %bb38, label %bb39
bb38:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr { i64, [5 x i64] }, ptr %t108, i32 0, i32 1
  %t111 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t110, i32 0, i32 2
  %t112 = load ptr, ptr %t111
  store ptr %t112, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb54
bb40:
  %t114 = load ptr, ptr %l5, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Call", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l6, !tbaa !29
  %t119 = load ptr, ptr %l6, !tbaa !29
  store ptr %t119, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t120 = load ptr, ptr %l85, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb41, label %bb42
bb41:
  %t123 = load ptr, ptr %l85, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 5}
  %t126 = icmp eq i64 %t124, 2
  store i1 %t126, ptr %l86, !tbaa !21
  br label %bb42
bb42:
  %t127 = load i1, ptr %l86, !tbaa !21
  br i1 %t127, label %bb43, label %bb44
bb43:
  %t128 = load ptr, ptr %l6, !tbaa !29
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { ptr }, ptr %t130, i32 0, i32 0
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l7, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l7, !tbaa !29
  %t137 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t134, ptr %t135, i1 %t137)
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_8bde8b1b63ea70b6_e30ac43cb3954ed2)
  unreachable
bb52:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Call", ptr %t142, i32 0, i32 1
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t146 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %t141, { i64, ptr } %t145, i1 %t146)
  br label %bb53
bb53:
  br label %bb194
bb54:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t151 = load ptr, ptr %l99, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb55, label %bb56
bb55:
  %t154 = load ptr, ptr %l99, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 7
  store i1 %t157, ptr %l100, !tbaa !21
  br label %bb56
bb56:
  %t158 = load i1, ptr %l100, !tbaa !21
  br i1 %t158, label %bb57, label %bb58
bb57:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l8, !tbaa !29
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Make", ptr %t166, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t170 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %t165, { i64, ptr } %t169, i1 %t170)
  br label %bb60
bb60:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l8, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Make", ptr %t175, i32 0, i32 3
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t174, ptr %t178, i1 %t179)
  br label %bb61
bb61:
  br label %bb194
bb62:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t184 = load ptr, ptr %l113, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb63, label %bb64
bb63:
  %t187 = load ptr, ptr %l113, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 18}
  %t190 = icmp eq i64 %t188, 8
  store i1 %t190, ptr %l114, !tbaa !21
  br label %bb64
bb64:
  %t191 = load i1, ptr %l114, !tbaa !21
  br i1 %t191, label %bb65, label %bb66
bb65:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t194, i32 0, i32 2
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l9, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Collect", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t203 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t198, ptr %t202, i1 %t203)
  br label %bb68
bb68:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l9, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Collect", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t207, ptr %t211, i1 %t213)
  br label %bb69
bb69:
  br label %bb194
bb70:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t218 = load ptr, ptr %l128, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb71, label %bb72
bb71:
  %t221 = load ptr, ptr %l128, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 9
  store i1 %t224, ptr %l129, !tbaa !21
  br label %bb72
bb72:
  %t225 = load i1, ptr %l129, !tbaa !21
  br i1 %t225, label %bb73, label %bb74
bb73:
  %t226 = load ptr, ptr %l1, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t228, i32 0, i32 2
  %t230 = load i32, ptr %t229, !range !{i32 0, i32 54}
  store i32 %t230, ptr %l10
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr { i64, [5 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t234, i32 0, i32 4
  %t236 = load { i64, ptr }, ptr %t235
  store { i64, ptr } %t236, ptr %l11, !tbaa !27
  br label %bb75
bb74:
  br label %bb80
bb75:
  %t238 = load i32, ptr %l10, !range !{i32 0, i32 54}
  %t240 = trunc i64 31 to i32
  %t241 = icmp eq i32 %t238, %t240
  %t243 = xor i1 %t241, true
  br i1 %t243, label %bb76, label %bb77
bb76:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t247 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %t245, { i64, ptr } %t246, i1 %t247)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  br label %bb194
bb80:
  %t251 = load ptr, ptr %l1, !tbaa !29
  store ptr %t251, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t252 = load ptr, ptr %l142, !tbaa !29
  %t253 = icmp ne ptr %t252, null
  br i1 %t253, label %bb81, label %bb82
bb81:
  %t255 = load ptr, ptr %l142, !tbaa !29
  %t256 = load i64, ptr %t255, !range !{i64 0, i64 18}
  %t258 = icmp eq i64 %t256, 10
  store i1 %t258, ptr %l143, !tbaa !21
  br label %bb82
bb82:
  %t259 = load i1, ptr %l143, !tbaa !21
  br i1 %t259, label %bb83, label %bb84
bb83:
  %t260 = load ptr, ptr %l1, !tbaa !29
  %t262 = getelementptr { i64, [5 x i64] }, ptr %t260, i32 0, i32 1
  %t263 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t262, i32 0, i32 2
  %t264 = load ptr, ptr %t263
  store ptr %t264, ptr %l12, !tbaa !29
  br label %bb85
bb84:
  br label %bb89
bb85:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l12, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Slice", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t271 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t266, ptr %t270, i1 %t271)
  br label %bb86
bb86:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load ptr, ptr %l12, !tbaa !29
  %t278 = getelementptr %"compiler/typed:Slice", ptr %t276, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !29
  %t281 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t275, ptr %t279, i1 %t281)
  br label %bb87
bb87:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load ptr, ptr %l12, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Slice", ptr %t286, i32 0, i32 2
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t285, ptr %t289, i1 %t291)
  br label %bb88
bb88:
  br label %bb194
bb89:
  %t295 = load ptr, ptr %l1, !tbaa !29
  store ptr %t295, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t296 = load ptr, ptr %l162, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb90, label %bb91
bb90:
  %t299 = load ptr, ptr %l162, !tbaa !29
  %t300 = load i64, ptr %t299, !range !{i64 0, i64 18}
  %t302 = icmp eq i64 %t300, 11
  store i1 %t302, ptr %l163, !tbaa !21
  br label %bb91
bb91:
  %t303 = load i1, ptr %l163, !tbaa !21
  br i1 %t303, label %bb92, label %bb93
bb92:
  %t304 = load ptr, ptr %l1, !tbaa !29
  %t306 = getelementptr { i64, [5 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t306, i32 0, i32 2
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l13, !tbaa !29
  br label %bb94
bb93:
  br label %bb98
bb94:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l13, !tbaa !29
  %t313 = getelementptr %"compiler/typed:Cond", ptr %t311, i32 0, i32 0
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t310, ptr %t314, i1 %t316)
  br label %bb95
bb95:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load ptr, ptr %l13, !tbaa !29
  %t323 = getelementptr %"compiler/typed:Cond", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t325 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t320, ptr %t324, i1 %t325)
  br label %bb96
bb96:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load ptr, ptr %l13, !tbaa !29
  %t332 = getelementptr %"compiler/typed:Cond", ptr %t330, i32 0, i32 2
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t329, ptr %t333, i1 %t335)
  br label %bb97
bb97:
  br label %bb194
bb98:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t340 = load ptr, ptr %l182, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb99, label %bb100
bb99:
  %t343 = load ptr, ptr %l182, !tbaa !29
  %t344 = load i64, ptr %t343, !range !{i64 0, i64 18}
  %t346 = icmp eq i64 %t344, 12
  store i1 %t346, ptr %l183, !tbaa !21
  br label %bb100
bb100:
  %t347 = load i1, ptr %l183, !tbaa !21
  br i1 %t347, label %bb101, label %bb102
bb101:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t350, i32 0, i32 2
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l14, !tbaa !29
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load ptr, ptr %l14, !tbaa !29
  %t357 = getelementptr %"compiler/typed:Seq", ptr %t355, i32 0, i32 0
  %t358 = load { i64, ptr }, ptr %t357, !tbaa !27
  %t359 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmts(ptr %v0, ptr %v1, ptr %t354, { i64, ptr } %t358, i1 %t359)
  br label %bb104
bb104:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = load ptr, ptr %l14, !tbaa !29
  %t366 = getelementptr %"compiler/typed:Seq", ptr %t364, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t368 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t363, ptr %t367, i1 %t368)
  br label %bb105
bb105:
  br label %bb194
bb106:
  %t372 = load ptr, ptr %l1, !tbaa !29
  store ptr %t372, ptr %l196, !tbaa !29
  store i1 false, ptr %l197, !tbaa !21
  %t373 = load ptr, ptr %l196, !tbaa !29
  %t374 = icmp ne ptr %t373, null
  br i1 %t374, label %bb107, label %bb108
bb107:
  %t376 = load ptr, ptr %l196, !tbaa !29
  %t377 = load i64, ptr %t376, !range !{i64 0, i64 18}
  %t379 = icmp eq i64 %t377, 13
  store i1 %t379, ptr %l197, !tbaa !21
  br label %bb108
bb108:
  %t380 = load i1, ptr %l197, !tbaa !21
  br i1 %t380, label %bb109, label %bb110
bb109:
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = getelementptr { i64, [5 x i64] }, ptr %t381, i32 0, i32 1
  %t384 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t383, i32 0, i32 2
  %t385 = load ptr, ptr %t384
  store ptr %t385, ptr %l15, !tbaa !29
  br label %bb111
bb110:
  br label %bb127
bb111:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l15, !tbaa !29
  %t390 = getelementptr %"compiler/typed:Match", ptr %t388, i32 0, i32 0
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  %t392 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmts(ptr %v0, ptr %v1, ptr %t387, { i64, ptr } %t391, i1 %t392)
  br label %bb112
bb112:
  %t396 = load ptr, ptr %l15, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Match", ptr %t396, i32 0, i32 1
  %t399 = load { i64, ptr }, ptr %t398, !tbaa !27
  store { i64, ptr } %t399, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t401 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t401, 0
  store i64 %t403, ptr %l18, !tbaa !24
  br label %bb113
bb113:
  %t405 = load i64, ptr %l17, !tbaa !24
  %t406 = load i64, ptr %l18, !tbaa !24
  %t409 = icmp slt i64 %t405, %t406
  %t411 = xor i1 %t409, true
  br i1 %t411, label %bb114, label %bb115
bb114:
  br label %bb119
bb115:
  br label %bb116
bb116:
  %t413 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t413, ptr %l214, !tbaa !27
  %t414 = load i64, ptr %l17, !tbaa !24
  %t416 = getelementptr { i64, ptr }, ptr %l214, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr ptr, ptr %t417, i64 %t414
  %t419 = load ptr, ptr %t418, !tbaa !39
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2earm(ptr %v0, ptr %v1, ptr %t421, ptr %t419, i1 %t423)
  br label %bb117
bb117:
  br label %bb118
bb118:
  %t427 = load i64, ptr %l17, !tbaa !24
  %t430 = add i64 %t427, 1
  store i64 %t430, ptr %l17, !tbaa !24
  br label %bb113
bb119:
  %t432 = load ptr, ptr %l15, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Match", ptr %t432, i32 0, i32 2
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t437 = icmp eq ptr %t435, null
  %t439 = xor i1 %t437, true
  br i1 %t439, label %bb120, label %bb121
bb120:
  %t441 = load ptr, ptr %l0, !tbaa !29
  store ptr %t441, ptr %l227, !tbaa !29
  %t442 = load ptr, ptr %l15, !tbaa !29
  %t444 = getelementptr %"compiler/typed:Match", ptr %t442, i32 0, i32 2
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = icmp eq ptr %t445, null
  br i1 %t447, label %bb122, label %bb123
bb121:
  br label %bb126
bb122:
  call void @__olang_check_failed(ptr @olang_loc_5ce4535adcc78e10_11db37cbad505f3c)
  unreachable
bb123:
  br label %bb124
bb124:
  %t449 = load ptr, ptr %l15, !tbaa !29
  %t451 = getelementptr %"compiler/typed:Match", ptr %t449, i32 0, i32 2
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t453 = load i1, ptr %l2, !tbaa !21
  %t454 = load ptr, ptr %l227, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2earm(ptr %v0, ptr %v1, ptr %t454, ptr %t452, i1 %t453)
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb194
bb127:
  %t457 = load ptr, ptr %l1, !tbaa !29
  store ptr %t457, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t458 = load ptr, ptr %l234, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb128, label %bb129
bb128:
  %t461 = load ptr, ptr %l234, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 18}
  %t464 = icmp eq i64 %t462, 14
  store i1 %t464, ptr %l235, !tbaa !21
  br label %bb129
bb129:
  %t465 = load i1, ptr %l235, !tbaa !21
  br i1 %t465, label %bb130, label %bb131
bb130:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t468, i32 0, i32 2
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l20, !tbaa !29
  br label %bb132
bb131:
  br label %bb135
bb132:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load ptr, ptr %l20, !tbaa !29
  %t475 = getelementptr %"compiler/typed:Try", ptr %t473, i32 0, i32 0
  %t476 = load ptr, ptr %t475, !tbaa !29
  %t477 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t472, ptr %t476, i1 %t477)
  br label %bb133
bb133:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l20, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Try", ptr %t482, i32 0, i32 1
  %t485 = load { i64, ptr }, ptr %t484, !tbaa !27
  %t486 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eclauses(ptr %v0, ptr %v1, ptr %t481, { i64, ptr } %t485, i1 %t486)
  br label %bb134
bb134:
  br label %bb194
bb135:
  %t490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t490, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t491 = load ptr, ptr %l248, !tbaa !29
  %t492 = icmp ne ptr %t491, null
  br i1 %t492, label %bb136, label %bb137
bb136:
  %t494 = load ptr, ptr %l248, !tbaa !29
  %t495 = load i64, ptr %t494, !range !{i64 0, i64 18}
  %t497 = icmp eq i64 %t495, 15
  store i1 %t497, ptr %l249, !tbaa !21
  br label %bb137
bb137:
  %t498 = load i1, ptr %l249, !tbaa !21
  br i1 %t498, label %bb138, label %bb139
bb138:
  %t499 = load ptr, ptr %l1, !tbaa !29
  %t501 = getelementptr { i64, [5 x i64] }, ptr %t499, i32 0, i32 1
  %t502 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t501, i32 0, i32 2
  %t503 = load ptr, ptr %t502
  store ptr %t503, ptr %l21, !tbaa !29
  br label %bb140
bb139:
  br label %bb168
bb140:
  %t505 = load ptr, ptr %l21, !tbaa !29
  store ptr %t505, ptr %l254, !tbaa !29
  store i1 false, ptr %l255, !tbaa !21
  %t506 = load ptr, ptr %l254, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb141, label %bb142
bb141:
  %t509 = load ptr, ptr %l254, !tbaa !29
  %t510 = load i64, ptr %t509, !range !{i64 0, i64 3}
  %t512 = icmp eq i64 %t510, 0
  store i1 %t512, ptr %l255, !tbaa !21
  br label %bb142
bb142:
  %t513 = load i1, ptr %l255, !tbaa !21
  br i1 %t513, label %bb143, label %bb144
bb143:
  br label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb167
bb146:
  %t514 = load ptr, ptr %l21, !tbaa !29
  store ptr %t514, ptr %l258, !tbaa !29
  store i1 false, ptr %l259, !tbaa !21
  %t515 = load ptr, ptr %l258, !tbaa !29
  %t516 = icmp ne ptr %t515, null
  br i1 %t516, label %bb147, label %bb148
bb147:
  %t518 = load ptr, ptr %l258, !tbaa !29
  %t519 = load i64, ptr %t518, !range !{i64 0, i64 3}
  %t521 = icmp eq i64 %t519, 1
  store i1 %t521, ptr %l259, !tbaa !21
  br label %bb148
bb148:
  %t522 = load i1, ptr %l259, !tbaa !21
  br i1 %t522, label %bb149, label %bb150
bb149:
  %t523 = load ptr, ptr %l21, !tbaa !29
  %t525 = getelementptr { i64, [4 x i64] }, ptr %t523, i32 0, i32 1
  %t526 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t525, i32 0, i32 1
  %t527 = load { i64, ptr }, ptr %t526
  store { i64, ptr } %t527, ptr %l22, !tbaa !27
  br label %bb151
bb150:
  br label %bb159
bb151:
  %t529 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t529, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t531 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  store i64 %t533, ptr %l25, !tbaa !24
  br label %bb152
bb152:
  %t535 = load i64, ptr %l24, !tbaa !24
  %t536 = load i64, ptr %l25, !tbaa !24
  %t539 = icmp slt i64 %t535, %t536
  %t541 = xor i1 %t539, true
  br i1 %t541, label %bb153, label %bb154
bb153:
  br label %bb158
bb154:
  br label %bb155
bb155:
  %t543 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t543, ptr %l271, !tbaa !27
  %t544 = load i64, ptr %l24, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr ptr, ptr %t547, i64 %t544
  %t549 = load ptr, ptr %t548, !tbaa !39
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/typed:Capture", ptr %t549, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t551, ptr %t555, i1 false)
  br label %bb156
bb156:
  br label %bb157
bb157:
  %t559 = load i64, ptr %l24, !tbaa !24
  %t562 = add i64 %t559, 1
  store i64 %t562, ptr %l24, !tbaa !24
  br label %bb152
bb158:
  br label %bb167
bb159:
  %t564 = load ptr, ptr %l21, !tbaa !29
  store ptr %t564, ptr %l281, !tbaa !29
  store i1 false, ptr %l282, !tbaa !21
  %t565 = load ptr, ptr %l281, !tbaa !29
  %t566 = icmp ne ptr %t565, null
  br i1 %t566, label %bb160, label %bb161
bb160:
  %t568 = load ptr, ptr %l281, !tbaa !29
  %t569 = load i64, ptr %t568, !range !{i64 0, i64 3}
  %t571 = icmp eq i64 %t569, 2
  store i1 %t571, ptr %l282, !tbaa !21
  br label %bb161
bb161:
  %t572 = load i1, ptr %l282, !tbaa !21
  br i1 %t572, label %bb162, label %bb163
bb162:
  %t573 = load ptr, ptr %l21, !tbaa !29
  %t575 = getelementptr { i64, [4 x i64] }, ptr %t573, i32 0, i32 1
  %t576 = getelementptr { i32, ptr, i32 }, ptr %t575, i32 0, i32 1
  %t577 = load ptr, ptr %t576
  store ptr %t577, ptr %l27, !tbaa !29
  br label %bb164
bb163:
  br label %bb166
bb164:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t579, ptr %t580, i1 false)
  br label %bb165
bb165:
  br label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_2da6509b5a768f1c_defe08a34fad40b8)
  unreachable
bb167:
  br label %bb194
bb168:
  %t584 = load ptr, ptr %l1, !tbaa !29
  store ptr %t584, ptr %l290, !tbaa !29
  store i1 false, ptr %l291, !tbaa !21
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = icmp ne ptr %t585, null
  br i1 %t586, label %bb169, label %bb170
bb169:
  %t588 = load ptr, ptr %l290, !tbaa !29
  %t589 = load i64, ptr %t588, !range !{i64 0, i64 18}
  %t591 = icmp eq i64 %t589, 16
  store i1 %t591, ptr %l291, !tbaa !21
  br label %bb170
bb170:
  %t592 = load i1, ptr %l291, !tbaa !21
  br i1 %t592, label %bb171, label %bb172
bb171:
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t595 = getelementptr { i64, [5 x i64] }, ptr %t593, i32 0, i32 1
  %t596 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t595, i32 0, i32 2
  %t597 = load ptr, ptr %t596
  store ptr %t597, ptr %l28, !tbaa !29
  br label %bb173
bb172:
  br label %bb186
bb173:
  %t599 = load ptr, ptr %l28, !tbaa !29
  %t601 = getelementptr %"compiler/typed:Text", ptr %t599, i32 0, i32 0
  %t602 = load { i64, ptr }, ptr %t601, !tbaa !27
  store { i64, ptr } %t602, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t604 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t604, 0
  store i64 %t606, ptr %l31, !tbaa !24
  br label %bb174
bb174:
  %t608 = load i64, ptr %l30, !tbaa !24
  %t609 = load i64, ptr %l31, !tbaa !24
  %t612 = icmp slt i64 %t608, %t609
  %t614 = xor i1 %t612, true
  br i1 %t614, label %bb175, label %bb176
bb175:
  br label %bb185
bb176:
  br label %bb177
bb177:
  %t616 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t616, ptr %l304, !tbaa !27
  %t617 = load i64, ptr %l30, !tbaa !24
  %t619 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = getelementptr ptr, ptr %t620, i64 %t617
  %t622 = load ptr, ptr %t621, !tbaa !39
  store ptr %t622, ptr %l32, !tbaa !29
  %t624 = load ptr, ptr %l32, !tbaa !29
  store ptr %t624, ptr %l307, !tbaa !29
  store i1 false, ptr %l308, !tbaa !21
  %t625 = load ptr, ptr %l307, !tbaa !29
  %t626 = icmp ne ptr %t625, null
  br i1 %t626, label %bb178, label %bb179
bb178:
  %t628 = load ptr, ptr %l307, !tbaa !29
  %t629 = load i64, ptr %t628, !range !{i64 0, i64 2}
  %t631 = icmp eq i64 %t629, 1
  store i1 %t631, ptr %l308, !tbaa !21
  br label %bb179
bb179:
  %t632 = load i1, ptr %l308, !tbaa !21
  br i1 %t632, label %bb180, label %bb181
bb180:
  %t633 = load ptr, ptr %l32, !tbaa !29
  %t635 = getelementptr { i64, [2 x i64] }, ptr %t633, i32 0, i32 1
  %t636 = getelementptr { ptr }, ptr %t635, i32 0, i32 0
  %t637 = load ptr, ptr %t636
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t639, ptr %t637, i1 %t642)
  br label %bb182
bb181:
  br label %bb183
bb182:
  br label %bb183
bb183:
  br label %bb184
bb184:
  %t646 = load i64, ptr %l30, !tbaa !24
  %t649 = add i64 %t646, 1
  store i64 %t649, ptr %l30, !tbaa !24
  br label %bb174
bb185:
  br label %bb194
bb186:
  %t651 = load ptr, ptr %l1, !tbaa !29
  store ptr %t651, ptr %l320, !tbaa !29
  store i1 false, ptr %l321, !tbaa !21
  %t652 = load ptr, ptr %l320, !tbaa !29
  %t653 = icmp ne ptr %t652, null
  br i1 %t653, label %bb187, label %bb188
bb187:
  %t655 = load ptr, ptr %l320, !tbaa !29
  %t656 = load i64, ptr %t655, !range !{i64 0, i64 18}
  %t658 = icmp eq i64 %t656, 17
  store i1 %t658, ptr %l321, !tbaa !21
  br label %bb188
bb188:
  %t659 = load i1, ptr %l321, !tbaa !21
  br i1 %t659, label %bb189, label %bb190
bb189:
  %t660 = load ptr, ptr %l1, !tbaa !29
  %t662 = getelementptr { i64, [5 x i64] }, ptr %t660, i32 0, i32 1
  %t663 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t662, i32 0, i32 2
  %t664 = load ptr, ptr %t663
  store ptr %t664, ptr %l34, !tbaa !29
  br label %bb191
bb190:
  br label %bb193
bb191:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load ptr, ptr %l34, !tbaa !29
  %t669 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t666, ptr %t667, i1 %t669)
  br label %bb192
bb192:
  br label %bb194
bb193:
  call void @__olang_check_failed(ptr @olang_loc_de3894aecf8d774d_e482dac037566689)
  unreachable
bb194:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l158 = alloca ptr
  %l159 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca i1
  %l195 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t17 = load ptr, ptr %l28, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l28, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 17}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l29, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l29, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [3 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t32 = load ptr, ptr %l34, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l34, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 17}
  %t38 = icmp eq i64 %t36, 15
  store i1 %t38, ptr %l35, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l35, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t46, ptr %t47, i1 %t49)
  br label %bb14
bb14:
  br label %bb123
bb15:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t54 = load ptr, ptr %l44, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l44, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 1
  store i1 %t60, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t61 = load i1, ptr %l45, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [3 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t76 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t75, i1 %t76)
  br label %bb21
bb21:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t80, ptr %t81, i1 %t83)
  br label %bb22
bb22:
  br label %bb123
bb23:
  %t87 = load ptr, ptr %l1, !tbaa !29
  store ptr %t87, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t88 = load ptr, ptr %l59, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l59, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l60, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l60, !tbaa !21
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:If", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t102, ptr %t106, i1 %t108)
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = getelementptr %"compiler/typed:If", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t112, ptr %t116, i1 %t118)
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t125 = getelementptr %"compiler/typed:If", ptr %t123, i32 0, i32 2
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t122, ptr %t126, i1 %t127)
  br label %bb31
bb31:
  br label %bb123
bb32:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t132 = load ptr, ptr %l79, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb33, label %bb34
bb33:
  %t135 = load ptr, ptr %l79, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 17}
  %t138 = icmp eq i64 %t136, 4
  store i1 %t138, ptr %l80, !tbaa !21
  br label %bb34
bb34:
  %t139 = load i1, ptr %l80, !tbaa !21
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l1, !tbaa !29
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t140, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t142, i32 0, i32 1
  %t144 = load ptr, ptr %t143
  store ptr %t144, ptr %l7, !tbaa !29
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [3 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t148, i32 0, i32 2
  %t150 = load ptr, ptr %t149
  store ptr %t150, ptr %l8, !tbaa !29
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t152, ptr %t153, i1 false)
  br label %bb38
bb38:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t157, ptr %t158, i1 false)
  br label %bb39
bb39:
  br label %bb123
bb40:
  %t161 = load ptr, ptr %l1, !tbaa !29
  store ptr %t161, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t162 = load ptr, ptr %l92, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb41, label %bb42
bb41:
  %t165 = load ptr, ptr %l92, !tbaa !29
  %t166 = load i64, ptr %t165, !range !{i64 0, i64 17}
  %t168 = icmp eq i64 %t166, 12
  store i1 %t168, ptr %l93, !tbaa !21
  br label %bb42
bb42:
  %t169 = load i1, ptr %l93, !tbaa !21
  br i1 %t169, label %bb43, label %bb44
bb43:
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { %"compiler/source:Span", ptr }, ptr %t172, i32 0, i32 1
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l9, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t176, ptr %t177, i1 false)
  br label %bb46
bb46:
  br label %bb123
bb47:
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t182 = load ptr, ptr %l101, !tbaa !29
  %t183 = icmp ne ptr %t182, null
  br i1 %t183, label %bb48, label %bb49
bb48:
  %t185 = load ptr, ptr %l101, !tbaa !29
  %t186 = load i64, ptr %t185, !range !{i64 0, i64 17}
  %t188 = icmp eq i64 %t186, 6
  store i1 %t188, ptr %l102, !tbaa !21
  br label %bb49
bb49:
  %t189 = load i1, ptr %l102, !tbaa !21
  br i1 %t189, label %bb50, label %bb51
bb50:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr { i64, [3 x i64] }, ptr %t190, i32 0, i32 1
  %t193 = getelementptr { %"compiler/source:Span", ptr }, ptr %t192, i32 0, i32 1
  %t194 = load ptr, ptr %t193
  store ptr %t194, ptr %l10, !tbaa !29
  br label %bb56
bb51:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t197 = load ptr, ptr %l107, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb52, label %bb53
bb52:
  %t200 = load ptr, ptr %l107, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 17}
  %t203 = icmp eq i64 %t201, 16
  store i1 %t203, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t204 = load i1, ptr %l108, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr }, ptr %t207, i32 0, i32 1
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l10, !tbaa !29
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l10, !tbaa !29
  %t213 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t211, ptr %t212, i1 %t213)
  br label %bb57
bb57:
  br label %bb123
bb58:
  %t217 = load ptr, ptr %l1, !tbaa !29
  store ptr %t217, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t218 = load ptr, ptr %l116, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb59, label %bb60
bb59:
  %t221 = load ptr, ptr %l116, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 7
  store i1 %t224, ptr %l117, !tbaa !21
  br label %bb60
bb60:
  %t225 = load i1, ptr %l117, !tbaa !21
  br i1 %t225, label %bb61, label %bb62
bb61:
  br label %bb67
bb62:
  %t226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t226, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t228 = icmp ne ptr %t227, null
  br i1 %t228, label %bb63, label %bb64
bb63:
  %t230 = load ptr, ptr %l120, !tbaa !29
  %t231 = load i64, ptr %t230, !range !{i64 0, i64 17}
  %t233 = icmp eq i64 %t231, 5
  store i1 %t233, ptr %l121, !tbaa !21
  br label %bb64
bb64:
  %t234 = load i1, ptr %l121, !tbaa !21
  br i1 %t234, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb123
bb68:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t236 = load ptr, ptr %l124, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb69, label %bb70
bb69:
  %t239 = load ptr, ptr %l124, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 17}
  %t242 = icmp eq i64 %t240, 8
  store i1 %t242, ptr %l125, !tbaa !21
  br label %bb70
bb70:
  %t243 = load i1, ptr %l125, !tbaa !21
  br i1 %t243, label %bb71, label %bb72
bb71:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [3 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l11, !tbaa !29
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t250, ptr %t251, i1 %t253)
  br label %bb74
bb74:
  br label %bb123
bb75:
  %t257 = load ptr, ptr %l1, !tbaa !29
  store ptr %t257, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t258 = load ptr, ptr %l134, !tbaa !29
  %t259 = icmp ne ptr %t258, null
  br i1 %t259, label %bb76, label %bb77
bb76:
  %t261 = load ptr, ptr %l134, !tbaa !29
  %t262 = load i64, ptr %t261, !range !{i64 0, i64 17}
  %t264 = icmp eq i64 %t262, 9
  store i1 %t264, ptr %l135, !tbaa !21
  br label %bb77
bb77:
  %t265 = load i1, ptr %l135, !tbaa !21
  br i1 %t265, label %bb78, label %bb79
bb78:
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t268 = getelementptr { i64, [3 x i64] }, ptr %t266, i32 0, i32 1
  %t269 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t268, i32 0, i32 2
  %t270 = load ptr, ptr %t269
  store ptr %t270, ptr %l12, !tbaa !29
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load ptr, ptr %l12, !tbaa !29
  %t274 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t272, ptr %t273, i1 %t274)
  br label %bb81
bb81:
  br label %bb123
bb82:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t279 = load ptr, ptr %l143, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l143, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 17}
  %t285 = icmp eq i64 %t283, 10
  store i1 %t285, ptr %l144, !tbaa !21
  br label %bb84
bb84:
  %t286 = load i1, ptr %l144, !tbaa !21
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t289, i32 0, i32 1
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l13, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l14, !tbaa !29
  br label %bb87
bb86:
  br label %bb90
bb87:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load ptr, ptr %l13, !tbaa !29
  %t302 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t299, ptr %t300, i1 %t302)
  br label %bb88
bb88:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l14, !tbaa !29
  %t308 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t306, ptr %t307, i1 %t308)
  br label %bb89
bb89:
  br label %bb123
bb90:
  %t312 = load ptr, ptr %l1, !tbaa !29
  store ptr %t312, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t313 = load ptr, ptr %l158, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb91, label %bb92
bb91:
  %t316 = load ptr, ptr %l158, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 17}
  %t319 = icmp eq i64 %t317, 11
  store i1 %t319, ptr %l159, !tbaa !21
  br label %bb92
bb92:
  %t320 = load i1, ptr %l159, !tbaa !21
  br i1 %t320, label %bb93, label %bb94
bb93:
  %t321 = load ptr, ptr %l1, !tbaa !29
  %t323 = getelementptr { i64, [3 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr }, ptr %t323, i32 0, i32 1
  %t325 = load ptr, ptr %t324
  store ptr %t325, ptr %l15, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l15, !tbaa !29
  %t330 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t327, ptr %t328, i1 %t330)
  br label %bb96
bb96:
  br label %bb123
bb97:
  %t334 = load ptr, ptr %l1, !tbaa !29
  store ptr %t334, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t335 = load ptr, ptr %l168, !tbaa !29
  %t336 = icmp ne ptr %t335, null
  br i1 %t336, label %bb98, label %bb99
bb98:
  %t338 = load ptr, ptr %l168, !tbaa !29
  %t339 = load i64, ptr %t338, !range !{i64 0, i64 17}
  %t341 = icmp eq i64 %t339, 13
  store i1 %t341, ptr %l169, !tbaa !21
  br label %bb99
bb99:
  %t342 = load i1, ptr %l169, !tbaa !21
  br i1 %t342, label %bb100, label %bb101
bb100:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr { i64, [3 x i64] }, ptr %t343, i32 0, i32 1
  %t346 = getelementptr { %"compiler/source:Span", ptr }, ptr %t345, i32 0, i32 1
  %t347 = load ptr, ptr %t346
  store ptr %t347, ptr %l16, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load ptr, ptr %l16, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Join", ptr %t350, i32 0, i32 0
  %t353 = load ptr, ptr %t352, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %t349, ptr %t353, i1 false)
  br label %bb103
bb103:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load ptr, ptr %l16, !tbaa !29
  %t360 = getelementptr %"compiler/typed:Join", ptr %t358, i32 0, i32 2
  %t361 = load { i64, ptr }, ptr %t360, !tbaa !27
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eclauses(ptr %v0, ptr %v1, ptr %t357, { i64, ptr } %t361, i1 false)
  br label %bb104
bb104:
  br label %bb123
bb105:
  %t364 = load ptr, ptr %l1, !tbaa !29
  store ptr %t364, ptr %l181, !tbaa !29
  store i1 false, ptr %l182, !tbaa !21
  %t365 = load ptr, ptr %l181, !tbaa !29
  %t366 = icmp ne ptr %t365, null
  br i1 %t366, label %bb106, label %bb107
bb106:
  %t368 = load ptr, ptr %l181, !tbaa !29
  %t369 = load i64, ptr %t368, !range !{i64 0, i64 17}
  %t371 = icmp eq i64 %t369, 14
  store i1 %t371, ptr %l182, !tbaa !21
  br label %bb107
bb107:
  %t372 = load i1, ptr %l182, !tbaa !21
  br i1 %t372, label %bb108, label %bb109
bb108:
  %t373 = load ptr, ptr %l1, !tbaa !29
  %t375 = getelementptr { i64, [3 x i64] }, ptr %t373, i32 0, i32 1
  %t376 = getelementptr { %"compiler/source:Span", ptr }, ptr %t375, i32 0, i32 1
  %t377 = load ptr, ptr %t376
  store ptr %t377, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb122
bb110:
  %t379 = load ptr, ptr %l17, !tbaa !29
  %t381 = getelementptr %"compiler/typed:Spawn", ptr %t379, i32 0, i32 0
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t384 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t384, 0
  store i64 %t386, ptr %l20, !tbaa !24
  br label %bb111
bb111:
  %t388 = load i64, ptr %l19, !tbaa !24
  %t389 = load i64, ptr %l20, !tbaa !24
  %t392 = icmp slt i64 %t388, %t389
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb112, label %bb113
bb112:
  br label %bb120
bb113:
  br label %bb114
bb114:
  %t396 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t396, ptr %l195, !tbaa !27
  %t397 = load i64, ptr %l19, !tbaa !24
  %t399 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr ptr, ptr %t400, i64 %t397
  %t402 = load ptr, ptr %t401, !tbaa !39
  store ptr %t402, ptr %l21, !tbaa !29
  %t404 = load ptr, ptr %l21, !tbaa !29
  %t406 = icmp eq ptr %t404, null
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb115, label %bb116
bb115:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t411 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %t410, ptr %t411, i1 false)
  br label %bb117
bb116:
  br label %bb118
bb117:
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t414 = load i64, ptr %l19, !tbaa !24
  %t417 = add i64 %t414, 1
  store i64 %t417, ptr %l19, !tbaa !24
  br label %bb111
bb120:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load ptr, ptr %l17, !tbaa !29
  %t422 = getelementptr %"compiler/typed:Spawn", ptr %t420, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexpr(ptr %v0, ptr %v1, ptr %t419, ptr %t423, i1 false)
  br label %bb121
bb121:
  br label %bb123
bb122:
  call void @__olang_check_failed(ptr @olang_loc_5d8eb8e886e7da6d_dfab6a63e03eb449)
  unreachable
bb123:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l8 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  store ptr %a0, ptr %l6, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v1, ptr %s0, i32 -1, { i64, ptr } %t8)
  store %"compiler/typed:Block" %t10, ptr %l8
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %s0, ptr %t12, ptr %l8, i1 %a2)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdefinit_2elitBool(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l2, !tbaa !24
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t22 = load i32, ptr %l1, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t26 = icmp eq i32 %t22, %t23
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = icmp ne i64 %t28, 0
  br i1 %t30, label %bb8, label %bb9
bb7:
  store i64 -1, ptr %l15, !tbaa !24
  br label %bb11
bb8:
  store i64 1, ptr %l18, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t32 = load i64, ptr %l18, !tbaa !24
  store i64 %t32, ptr %l15, !tbaa !24
  br label %bb11
bb11:
  %t33 = load i64, ptr %l15, !tbaa !24
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_7935f23fc85db5b5_5a14f220007f8689)
  unreachable
bb17:
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2)
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2)
declare %"compiler/definit:State" @compiler_2fdefinit_2eretag(%"compiler/definit:State" %a0, %"compiler/definit:State" %a1, %"compiler/definit:State" %a2, i32 %a3, %"compiler/source:Span" %a4)
declare %"compiler/definit:State" @compiler_2fdefinit_2emeet(%"compiler/definit:State" %a0, %"compiler/definit:State" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/definit:State" %a2)
@olang_loc_58a9ebc4913c6262_741c23f7607ff1de = external constant [0 x i8]
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/definit:State" %a2)
declare %"compiler/definit:State" @compiler_2fdefinit_2eState_2edead()
@olang_loc_84c4d6ea62c85acc_37a8fef9eaee128 = external constant [0 x i8]
declare %"compiler/definit:State" @compiler_2fdefinit_2ecompiler_2fdefinit_3aWalker_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/definit:State" %a2, %"compiler/definit:State" %a3)
@olang_loc_2666e55c871bfc88_11a50ffb28817424 = external constant [0 x i8]
@olang_loc_156bf6b7f20d7659_5aae6743b02be315 = external constant [0 x i8]
@olang_loc_76be02bbb9c5cc0_603b59278fb7a8ac = external constant [0 x i8]
declare %"compiler/definit:State" @compiler_2fdefinit_3aState_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare { i32, i1 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePop_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_ac7b00276c8cb33f_f84bfacdca165d83 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_86e100904f39c567_d61ce50e57b89f1b = external constant [0 x i8]
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_8bde8b1b63ea70b6_e30ac43cb3954ed2 = external constant [0 x i8]
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_5ce4535adcc78e10_11db37cbad505f3c = external constant [0 x i8]
declare void @compiler_2fdefinit_2ecompiler_2fdefinit_3aheldWalker_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_2da6509b5a768f1c_defe08a34fad40b8 = external constant [0 x i8]
@olang_loc_de3894aecf8d774d_e482dac037566689 = external constant [0 x i8]
@olang_loc_5d8eb8e886e7da6d_dfab6a63e03eb449 = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@olang_loc_7935f23fc85db5b5_5a14f220007f8689 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
