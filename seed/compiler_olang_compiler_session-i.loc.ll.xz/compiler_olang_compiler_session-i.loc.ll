; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1188f31d2744d104_3fb83997fdf399f0 = weak_odr constant [41 x i8] c"std/prelude/map.olang:250: null reached\0A\00"
@olang_loc_33d3c487bbb10ff3_a882f6b43f240837 = weak_odr constant [55 x i8] c"std/prelude/list.olang:525: array length out of range\0A\00"
@olang_loc_3cc2ead55392206c_46185310ac052a58 = weak_odr constant [56 x i8] c"std/prelude/array.olang:234: slice bounds out of range\0A\00"
@olang_loc_5c1a1e00910b40be_9feda428d0143382 = weak_odr constant [55 x i8] c"std/prelude/list.olang:526: array length out of range\0A\00"
@olang_loc_8f60da452114a801_2b8ab977772dc995 = weak_odr constant [56 x i8] c"std/prelude/array.olang:229: array length out of range\0A\00"
@olang_loc_a2b0a9ce736ba8c3_b906682c154adce7 = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
@olang_loc_b3f8ddb32c59e4cd_d0cfc08fbec48b11 = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_c08f9e79b7d9f7b8_bc17d02fc6a9f16c = weak_odr constant [54 x i8] c"std/prelude/vec.olang:138: slice bounds out of range\0A\00"
@olang_loc_ee698580bd520ca0_be3586cf07850a04 = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
@olang_loc_fba12d362c0504ce_611a5f6edfc6a8f2 = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
