; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1188f31d2744d104_3fb83997fdf399f0 = weak_odr constant [41 x i8] c"std/prelude/map.olang:273: null reached\0A\00"
@olang_loc_4cfcdd7ee149883f_c1dcae9ea1c057fb = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_58e30339dc525c65_8ff29672c8905379 = weak_odr constant [56 x i8] c"std/prelude/array.olang:241: slice bounds out of range\0A\00"
@olang_loc_71b15b09f79ee26d_302669a3f0377e79 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:239: array length out of range\0A\00"
@olang_loc_c022e58ec96da978_ec8311c98a19dd54 = weak_odr constant [56 x i8] c"std/prelude/array.olang:236: array length out of range\0A\00"
@olang_loc_c08f9e79b7d9f7b8_bc17d02fc6a9f16c = weak_odr constant [54 x i8] c"std/prelude/vec.olang:147: slice bounds out of range\0A\00"
@olang_loc_c29104ce98cd7d40_f96243c7193eaec = weak_odr constant [54 x i8] c"std/prelude/vec.olang:240: array length out of range\0A\00"
@olang_loc_dc190d91cfba07b_c092ed77a04a119f = weak_odr constant [54 x i8] c"std/prelude/vec.olang:201: slice bounds out of range\0A\00"
