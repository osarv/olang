; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_32b4dd57063daccc_20299270f57c1810 = weak_odr constant [56 x i8] c"std/prelude/array.olang:275: array length out of range\0A\00"
@olang_loc_353cb9f815b03dbe_d78b28504d5fbc62 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_58e30339dc525c65_8ff29672c8905379 = weak_odr constant [56 x i8] c"std/prelude/array.olang:244: slice bounds out of range\0A\00"
@olang_loc_71b15b09f79ee26d_302669a3f0377e79 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
@olang_loc_b14bf40ea480b614_26de4cf54edeeb08 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_c022e58ec96da978_ec8311c98a19dd54 = weak_odr constant [56 x i8] c"std/prelude/array.olang:239: array length out of range\0A\00"
@olang_loc_c08f9e79b7d9f7b8_bc17d02fc6a9f16c = weak_odr constant [54 x i8] c"std/prelude/vec.olang:170: slice bounds out of range\0A\00"
@olang_loc_c29104ce98cd7d40_f96243c7193eaec = weak_odr constant [54 x i8] c"std/prelude/vec.olang:284: array length out of range\0A\00"
@olang_loc_dc190d91cfba07b_c092ed77a04a119f = weak_odr constant [54 x i8] c"std/prelude/vec.olang:231: slice bounds out of range\0A\00"
