; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:altsCovered" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" = type { { ptr, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/check:roOrigin" = type { ptr, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/check:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/check:inPlaceRead" = type { { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span" }
define dso_local i1 @compiler_2fcheck_2eassignsAll(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb34
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l19, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 11}
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [6 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %t45)
  store i32 %t47, ptr %l29
  br label %bb13
bb13:
  %t48 = load i32, ptr %l1, !tbaa !23
  %t49 = load i32, ptr %l29, !tbaa !23
  %t51 = icmp eq i32 %t49, %t48
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb32
bb17:
  %t54 = load ptr, ptr %l5, !tbaa !29
  store ptr %t54, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t55 = load ptr, ptr %l33, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l33, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 11}
  %t61 = icmp eq i64 %t59, 7
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l5, !tbaa !29
  %t65 = getelementptr { i64, [6 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t70 = load i32, ptr %l1, !tbaa !23
  %t73 = call i1 @compiler_2fcheck_2echainAssignsAll(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l41
  br label %bb23
bb23:
  %t74 = load i1, ptr %l41, !tbaa !21
  br i1 %t74, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_fcbb335a6871d594_96c5adf6eb865188)
  unreachable
bb32:
  br label %bb33
bb33:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb4
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 7
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l10
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 7
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t23, i64 -1, i64 %t27, i32 %t28, i32 0)
  store ptr %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 5
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l2, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 5
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t41, i32 %t42)
  store { i64, ptr } %t45, ptr %l25
  br label %bb10
bb10:
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i1, ptr %l2, !tbaa !21
  %t53 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 5
  store i1 %t50, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t54)
  br label %bb11
bb11:
  %t56 = load ptr, ptr %lp3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyScopesAgree(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l80 = alloca { i64, ptr }
  %l86 = alloca i64
  %l89 = alloca i64
  %l110 = alloca i64
  %l114 = alloca i64
  %l118 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l24, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l27
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l24, !tbaa !29
  %t15 = load i32, ptr %l27, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l28
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l29, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l32
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l29, !tbaa !29
  %t25 = load i32, ptr %l32, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l33
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t33 = extractvalue { i64, ptr } %t27, 0
  %t36 = icmp ne i64 %t30, %t33
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 1, ptr %l6, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb13
bb10:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l48, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l48, !tbaa !24
  store i64 %t69, ptr %l45, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l45, !tbaa !24
  store i64 %t70, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t90 = load i32, ptr %l1, !tbaa !23
  %t91 = load i64, ptr %l11, !tbaa !24
  %t95 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t89, i32 %t90, i64 %t91)
  store i64 %t95, ptr %l69
  br label %bb18
bb18:
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t97 = load i32, ptr %l2, !tbaa !23
  %t98 = load i64, ptr %l11, !tbaa !24
  %t102 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t96, i32 %t97, i64 %t98)
  store i64 %t102, ptr %l73
  br label %bb19
bb19:
  %t103 = load i64, ptr %l69, !tbaa !24
  %t104 = load i64, ptr %l73, !tbaa !24
  %t105 = icmp ne i64 %t103, %t104
  br i1 %t105, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb14
bb24:
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t113 = load i32, ptr %l1, !tbaa !23
  %t116 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t112, i32 %t113)
  store { i64, ptr } %t116, ptr %l80
  br label %bb25
bb25:
  %t117 = load { i64, ptr }, ptr %l80, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t120 = extractvalue { i64, ptr } %t117, 0
  store i64 %t120, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t122 = load i64, ptr %l14, !tbaa !24
  %t123 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp sgt i64 %t122, %t123
  br i1 %t126, label %bb26, label %bb27
bb26:
  %t128 = load i64, ptr %l15, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb31
bb28:
  %t132 = load i64, ptr %l14, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = sub i64 %t132, %t133
  %t137 = load i64, ptr %l15, !tbaa !24
  %t140 = add i64 %t136, %t137
  %t142 = sub i64 %t140, 1
  %t143 = load i64, ptr %l15, !tbaa !24
  %t146 = sdiv i64 %t142, %t143
  store i64 %t146, ptr %l89, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb30
bb30:
  %t148 = load i64, ptr %l89, !tbaa !24
  store i64 %t148, ptr %l86, !tbaa !24
  br label %bb31
bb31:
  %t149 = load i64, ptr %l86, !tbaa !24
  store i64 %t149, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb32
bb32:
  %t150 = load i64, ptr %l17, !tbaa !24
  %t151 = load i64, ptr %l16, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb33, label %bb34
bb33:
  br label %bb54
bb34:
  br label %bb35
bb35:
  %t158 = load i64, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l17, !tbaa !24
  %t160 = load i64, ptr %l15, !tbaa !24
  %t163 = mul i64 %t159, %t160
  %t166 = add i64 %t158, %t163
  store i64 %t166, ptr %l18, !tbaa !24
  %t168 = load ptr, ptr %l3, !tbaa !29
  %t169 = load i32, ptr %l1, !tbaa !23
  %t170 = load i64, ptr %l18, !tbaa !24
  %t174 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t168, i32 %t169, i64 %t170)
  store i64 %t174, ptr %l110
  br label %bb36
bb36:
  %t175 = load i64, ptr %l110, !tbaa !24
  store i64 %t175, ptr %l19, !tbaa !24
  %t176 = load ptr, ptr %l3, !tbaa !29
  %t177 = load i32, ptr %l2, !tbaa !23
  %t178 = load i64, ptr %l18, !tbaa !24
  %t182 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t176, i32 %t177, i64 %t178)
  store i64 %t182, ptr %l114
  br label %bb37
bb37:
  %t183 = load i64, ptr %l114, !tbaa !24
  store i64 %t183, ptr %l20, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l20, !tbaa !24
  %t188 = icmp ne i64 %t184, %t185
  br i1 %t188, label %bb38, label %bb39
bb38:
  %t190 = load i64, ptr %l19, !tbaa !24
  %t191 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t194 = icmp eq i64 %t190, %t191
  br i1 %t194, label %bb40, label %bb41
bb39:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb49
bb40:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb42
bb41:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t197 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t200 = icmp eq i64 %t196, %t197
  store i1 %t200, ptr %l122, !tbaa !21
  br label %bb42
bb42:
  %t202 = load i1, ptr %l122, !tbaa !21
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t203 = load i64, ptr %l20, !tbaa !24
  %t204 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t207 = icmp eq i64 %t203, %t204
  br i1 %t207, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb48
bb45:
  store i1 true, ptr %l130, !tbaa !21
  br label %bb47
bb46:
  %t209 = load i64, ptr %l20, !tbaa !24
  %t210 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t213 = icmp eq i64 %t209, %t210
  store i1 %t213, ptr %l130, !tbaa !21
  br label %bb47
bb47:
  %t215 = load i1, ptr %l130, !tbaa !21
  store i1 %t215, ptr %l126, !tbaa !21
  br label %bb48
bb48:
  %t216 = load i1, ptr %l126, !tbaa !21
  %t217 = xor i1 %t216, true
  store i1 %t217, ptr %l118, !tbaa !21
  br label %bb49
bb49:
  %t219 = load i1, ptr %l118, !tbaa !21
  br i1 %t219, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t221 = load i64, ptr %l17, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l17, !tbaa !24
  br label %bb32
bb54:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/check:b5aWalk", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 27
  store ptr %t8, ptr %l11, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = sext i32 %a3 to i64
  %t15 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t9, i64 %t12)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t15, ptr %l15
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l11, !tbaa !29
  %t17 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l15
  %t18 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t16, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t17)
  %t19 = extractvalue { i32, i64 } %t18, 1
  %t20 = extractvalue { i32, i64 } %t18, 0
  store i32 %t20, ptr %l17
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb6, label %ok.22, !prof !99
ok.22:
  store i64 %t19, ptr %l16
  br label %bb5
bb5:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l9, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t24 = load i64, ptr %l9, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  br label %bb11
bb11:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t30, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t36 = icmp eq i64 %t29, %t33
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/check:b5aWalk", ptr %t40, i32 0, i32 3
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t42, i64 %t38)
  store i1 %t46, ptr %l29
  br label %bb14
bb13:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i1, ptr %l29, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:b5aWalk", ptr %t51, i32 0, i32 3
  %t54 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t53, i64 %t54)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr %"compiler/check:b5aWalk", ptr %t57, i32 0, i32 4
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t59, i64 %t60)
  store i1 %t63, ptr %l37
  br label %bb20
bb20:
  %t64 = load i1, ptr %l37, !tbaa !21
  %t65 = xor i1 %t64, true
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t71 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %t67, i32 %a4, i64 0)
  store i1 %t71, ptr %l42
  br label %bb23
bb22:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb24
bb23:
  %t72 = load i1, ptr %l42, !tbaa !21
  store i1 %t72, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l39, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/check:b5aWalk", ptr %t74, i32 0, i32 4
  %t77 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t76, i64 %t77, i1 true)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/check:b5aWalk", ptr %t80, i32 0, i32 6
  store i1 true, ptr %t82, !tbaa !21
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t83, ptr %t84, i64 %t85)
  br label %bb28
bb28:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr %"compiler/check:b5aWalk", ptr %t89, i32 0, i32 6
  store i1 false, ptr %t91, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/load:Import"
  %l9 = alloca i1
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/load:Import"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v1, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v1, ptr %t7, i64 %t8, i1 true)
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 10
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t26 = getelementptr %"compiler/load:Module", ptr %t24, i32 0, i32 11
  store ptr %t26, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l5, !tbaa !24
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l22
  br label %bb8
bb8:
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/load:Import" %t42, ptr %l27
  br label %bb12
bb12:
  %t43 = load %"compiler/load:Import", ptr %l27
  store %"compiler/load:Import" %t43, ptr %l6
  %t44 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/load:Import", ptr %l6, i32 0, i32 5
  %t51 = load i64, ptr %t50, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %t49, i64 %t51, ptr %t52, ptr %t53)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t60 = add i64 %t58, 1
  store i64 %t60, ptr %l5, !tbaa !24
  br label %bb7
bb18:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t62, i64 %t63)
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64, i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l16
  br label %bb5
bb5:
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t28, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t34, ptr %l10, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_15d8d795344f0f34_d9e3bc129d8abb98)
  unreachable
bb11:
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l21, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t49, ptr %l10, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/check:b5aWalk", ptr %t3, i32 0, i32 2
  %t9 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v1, ptr %t5, i64 %t1)
  store i1 %t9, ptr %l8
  br label %bb1
bb1:
  %t10 = load i1, ptr %l8, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 2
  %t16 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t15, i64 %t16)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundBy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/generic:Origin"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l43 = alloca i1
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l57 = alloca %"compiler/generic:Origin"
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i64, ptr %l16, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 -1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 64, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t5 = load i64, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l6, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l23, !tbaa !24
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  store ptr %t60, ptr %l46, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t64, i64 %t65)
  store i32 %t68, ptr %l50
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l46, !tbaa !29
  %t70 = load i32, ptr %l50, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t69, i32 %t70)
  store { i64, ptr } %t71, ptr %l51
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l43, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load i64, ptr %l2, !tbaa !24
  %t85 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t81, i64 %t82)
  store %"compiler/generic:Origin" %t85, ptr %l57
  br label %bb20
bb20:
  %t86 = load %"compiler/generic:Origin", ptr %l57
  store %"compiler/generic:Origin" %t86, ptr %l10
  %t87 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 0
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = icmp slt i64 %t88, 0
  br i1 %t90, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l3, !tbaa !24
  %t94 = getelementptr %"compiler/generic:Origin", ptr %l10, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb24:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = add i64 %t97, 1
  store i64 %t99, ptr %l8, !tbaa !24
  br label %bb8
bb25:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp slt i64 %t101, 0
  br i1 %t103, label %bb26, label %bb27
bb26:
  store i64 -1, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  store ptr %t111, ptr %l69, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t116 = load i64, ptr %l3, !tbaa !24
  %t119 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t115, i64 %t116)
  store i32 %t119, ptr %l73
  br label %bb29
bb29:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i32, ptr %l73, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t120, i32 %t121)
  store { i64, ptr } %t122, ptr %l74
  br label %bb30
bb30:
  %t123 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t123, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb31
bb31:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb32, label %bb33
bb32:
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t136, ptr %l81, !tbaa !27
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  store ptr %t149, ptr %l86, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t154 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t150, i32 %t142)
  store i32 %t154, ptr %l89
  br label %bb35
bb35:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i32, ptr %l89, !tbaa !23
  %t159 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t156, i32 %t157, i32 %a1)
  store i1 %t159, ptr %l91
  br label %bb36
bb36:
  %t160 = load i1, ptr %l91, !tbaa !21
  br i1 %t160, label %bb37, label %bb38
bb37:
  %t161 = load i64, ptr %l3, !tbaa !24
  store i64 %t161, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t163 = load i64, ptr %l12, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l12, !tbaa !24
  br label %bb31
bb41:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t17 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l5
  store i32 %a2, ptr %l6, !tbaa !23
  store ptr %a3, ptr %l7, !tbaa !29
  store { i64, ptr } %a4, ptr %l8, !tbaa !27
  %t6 = load %"compiler/source:Span", ptr %l1
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %t6)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v1, ptr %v2, ptr %v3, ptr %t11, { i64, ptr } %t12, i32 %t13, i1 false, i1 false)
  store %"compiler/typed:Call" %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load %"compiler/typed:Call", ptr %l13
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Call" %t15, ptr %t16
  store { i64, [5 x i64] } zeroinitializer, ptr %t17
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 0
  store i64 6, ptr %t18
  %t19 = load %"compiler/source:Span", ptr %l5
  %t20 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t19, 0
  %t21 = load i32, ptr %l6, !tbaa !23
  %t22 = insertvalue { %"compiler/source:Span", i32, ptr } %t20, i32 %t21, 1
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } %t22, ptr %t16, 2
  %t25 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t24, ptr %t25
  %t26 = load { i64, [5 x i64] }, ptr %t17
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t26, ptr %t28
  store ptr %t28, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t9, i64 %t10)
  store ptr %t13, ptr %l8
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Func", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %t18, i32 %t17)
  store { i64, ptr } %t20, ptr %l11
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l14, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l13, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  %t36 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t36, ptr %rv
  br label %ret
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 23
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t44 = icmp ne i32 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 23
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t46, i32 %t50)
  store i1 %t53, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb8:
  %t54 = load i1, ptr %l23, !tbaa !21
  store i1 %t54, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t55 = load i1, ptr %l19, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l24, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l27, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 23
  %t72 = load i32, ptr %t71, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t68, i32 %t72)
  store i32 %t75, ptr %l33
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t76 = load ptr, ptr %l27, !tbaa !29
  %t77 = load i32, ptr %l33, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t78, ptr %l34
  br label %bb13
bb13:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load i32, ptr %l34, !tbaa !23
  %t81 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %t79, i32 %t80)
  store { i64, ptr } %t81, ptr %l35
  br label %bb14
bb14:
  %t82 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t82, ptr %l36, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l37, !tbaa !24
  %t85 = load i64, ptr %l37, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l38, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l37, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t96, ptr %l36, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb15:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l39, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t98, ptr %l40, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l41, !tbaa !24
  %t101 = load i64, ptr %l41, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l42, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l41, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t112, ptr %l40, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t113, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca %"compiler/names:Ref"
  %l30 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca %"compiler/names:Ref"
  %l44 = alloca i1
  %l51 = alloca { i64, ptr }
  %l56 = alloca i1
  %l63 = alloca i32
  %l68 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca %"compiler/msgs:Msg"
  %l88 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t24, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb46
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t35)
  store ptr %t37, ptr %l22
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 2
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t47 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t44, i64 %t41, i32 %t43)
  store %"compiler/names:Ref" %t47, ptr %l26
  br label %bb7
bb7:
  %t48 = load %"compiler/names:Ref", ptr %l26
  store %"compiler/names:Ref" %t48, ptr %l6
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp sgt i64 %t51, 1
  br i1 %t53, label %bb8, label %bb9
bb8:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t56 = load i32, ptr %t55, !range !{i32 0, i32 9}
  %t58 = trunc i64 0 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l35, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l37
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t72 = load ptr, ptr %l37, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t77 = load i32, ptr %t76, !tbaa !23
  %t78 = load ptr, ptr %l35, !tbaa !29
  %t81 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t78, i64 %t75, i32 %t77)
  store %"compiler/names:Ref" %t81, ptr %l41
  br label %bb14
bb14:
  %t82 = load %"compiler/names:Ref", ptr %l41
  store %"compiler/names:Ref" %t82, ptr %l6
  br label %bb15
bb15:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 9}
  %t86 = trunc i64 0 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb19, label %bb20
bb19:
  %t96 = load i1, ptr %l2, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb20:
  br label %bb25
bb21:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l3
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l51, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i32, ptr %t102, i64 0
  %t104 = load i32, ptr %t103, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t104)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  %t109 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t110 = load i32, ptr %t109, !range !{i32 0, i32 9}
  %t112 = trunc i64 4 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb26, label %bb27
bb26:
  %t115 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb28
bb28:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb29, label %bb30
bb29:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 2
  %t128 = load i64, ptr %t127, !tbaa !24
  %t132 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t124, i64 %t126, i64 %t128)
  store i32 %t132, ptr %l63
  br label %bb31
bb30:
  br label %bb45
bb31:
  %t133 = load i32, ptr %l63, !tbaa !23
  store i32 %t133, ptr %l7, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = load i32, ptr %l7, !tbaa !23
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t143 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t137, i32 %t138, { i64, ptr } %t139)
  store i1 %t143, ptr %l68
  br label %bb32
bb32:
  %t144 = load i1, ptr %l68, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb33, label %bb34
bb33:
  %t147 = load i1, ptr %l2, !tbaa !21
  br i1 %t147, label %bb35, label %bb36
bb34:
  br label %bb44
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l71, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t150)
  store %"compiler/source:Span" %t152, ptr %l73
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t154, ptr %l75, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = sub i64 %t157, 1
  %t161 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i32, ptr %t162, i64 %t159
  %t164 = load i32, ptr %t163, !tbaa !33
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t153, i32 %t164)
  store { i64, ptr } %t167, ptr %l80
  br label %bb38
bb38:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t175 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t171, i32 %t172)
  store i64 %t175, ptr %l84
  br label %bb39
bb39:
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t178 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t176)
  store i64 %t178, ptr %l86
  br label %bb40
bb40:
  %t179 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t180 = load i64, ptr %l84, !tbaa !24
  %t181 = load i64, ptr %l86, !tbaa !24
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s7, { i64, ptr } %t179, i64 %t180, i64 %t181)
  store %"compiler/msgs:Msg" %t182, ptr %l87
  br label %bb41
bb41:
  %t183 = load ptr, ptr %l71, !tbaa !29
  %t184 = load %"compiler/source:Span", ptr %l73
  %t185 = load %"compiler/msgs:Msg", ptr %l87
  %t186 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t183, %"compiler/source:Span" %t184, %"compiler/msgs:Msg" %t185)
  store i64 %t186, ptr %l88
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  store i1 true, ptr %rv
  br label %ret
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_cf2e89857dc93528_274c4670bc5b9eac)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca %"compiler/check:altsCovered"
  %l20 = alloca i1
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l34 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i32
  %l47 = alloca i32
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i32
  %l59 = alloca i1
  %l63 = alloca i64
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca i64
  %l92 = alloca i64
  %l111 = alloca { i64, ptr }
  %l115 = alloca i1
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca i64
  %l123 = alloca i1
  %l125 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/msgs:Msg"
  %l130 = alloca i64
  %l136 = alloca %"compiler/check:altsCovered"
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l151 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca i1
  %l160 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l162 = alloca i64
  %l164 = alloca i1
  %l167 = alloca i1
  %l173 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l175 = alloca i64
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l183 = alloca i64
  %l185 = alloca i1
  %l191 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/msgs:Msg"
  %l198 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i32, i1 }
  %t100 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l24, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l25, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Match", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l28
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l25, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l28
  %t14 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t12, %"compiler/source:Span" %t13)
  store { i64, ptr } %t14, ptr %l29
  br label %bb3
bb3:
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t17 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 true, ptr %l6, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Match", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t30, ptr %t34)
  store i32 %t37, ptr %l34
  br label %bb4
bb4:
  %t38 = load i32, ptr %l34, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l7, !tbaa !23
  %t41 = icmp ne i32 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l37, !tbaa !29
  %t44 = load i32, ptr %l7, !tbaa !23
  store i32 %t44, ptr %l38, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l41, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l45
  br label %bb7
bb6:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l67, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l70, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 61
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t64, i64 %t68)
  store i32 %t71, ptr %l74
  br label %bb25
bb7:
  %t72 = load ptr, ptr %l42, !tbaa !29
  %t73 = load i64, ptr %l45, !tbaa !24
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t74, ptr %l46
  br label %bb8
bb8:
  %t75 = load ptr, ptr %l41, !tbaa !29
  %t76 = load i32, ptr %l46, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l47
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l37, !tbaa !29
  %t79 = load i32, ptr %l38, !tbaa !23
  %t80 = load i32, ptr %l47, !tbaa !23
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %s0, ptr %t78, i32 %t79, i32 %t80)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l48
  br label %bb10
bb10:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l5
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l51
  br label %bb11
bb11:
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = icmp slt i64 %t88, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l54, !tbaa !29
  %t92 = load i32, ptr %l7, !tbaa !23
  store i32 %t92, ptr %l55, !tbaa !23
  %t93 = icmp sge i64 1, 0
  br i1 %t93, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb19
bb14:
  %t95 = icmp sle i64 1, 2305843009213693951
  br i1 %t95, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb16:
  %t97 = mul i64 1, 4
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  %t99 = load i32, ptr %l55, !tbaa !23
  store i64 0, ptr %t100
  br label %fill.101
fill.101:
  %t104 = load i64, ptr %t100
  %t105 = icmp slt i64 %t104, 1
  br i1 %t105, label %fillb.102, label %filld.103
fillb.102:
  %t106 = getelementptr i32, ptr %t98, i64 %t104
  store i32 %t99, ptr %t106
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %t100
  br label %fill.101
filld.103:
  %t108 = insertvalue { i64, ptr } undef, i64 1, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t98, 1
  %t110 = load ptr, ptr %l54, !tbaa !29
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s2, ptr %t110, { i64, ptr } %t109)
  store i1 %t112, ptr %l59
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb18:
  %t113 = load i1, ptr %l59, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t116 = load i1, ptr %l53, !tbaa !21
  store i1 %t116, ptr %l6, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t117, i32 %t118)
  store i64 %t121, ptr %l63
  br label %bb20
bb20:
  %t122 = load i64, ptr %l63, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb21, label %bb22
bb21:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t125, i32 %t126)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb25:
  %t129 = load ptr, ptr %l70, !tbaa !29
  %t130 = load i32, ptr %l74, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l75
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l67, !tbaa !29
  %t133 = load i32, ptr %l75, !tbaa !23
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t132, i32 %t133)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l76
  br label %bb27
bb27:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l5
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 62
  %t139 = load i1, ptr %t138, !tbaa !21
  %t141 = xor i1 %t139, true
  store i1 %t141, ptr %l6, !tbaa !21
  br label %bb28
bb28:
  %t143 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l80
  br label %bb29
bb29:
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %l8
  %t145 = load i1, ptr %l6, !tbaa !21
  %t147 = xor i1 %t145, true
  store i1 %t147, ptr %l9, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Match", ptr %t149, i32 0, i32 3
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb30, label %bb31
bb30:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb35
bb32:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l92, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb34
bb34:
  %t182 = load i64, ptr %l92, !tbaa !24
  store i64 %t182, ptr %l89, !tbaa !24
  br label %bb35
bb35:
  %t183 = load i64, ptr %l89, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb69
bb38:
  br label %bb39
bb39:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  %t202 = load ptr, ptr %l2, !tbaa !29
  %t204 = getelementptr %"compiler/ast:Match", ptr %t202, i32 0, i32 3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l111, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t200
  %t211 = load ptr, ptr %t210, !tbaa !39
  store ptr %t211, ptr %l18, !tbaa !29
  %t213 = load i1, ptr %l11, !tbaa !21
  br i1 %t213, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l115, !tbaa !21
  br label %bb47
bb41:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t219 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s6, ptr %t215, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t219, ptr %l119
  br label %bb42
bb42:
  %t221 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s6, ptr %l119)
  store i64 %t221, ptr %l121
  br label %bb43
bb43:
  %t222 = load i64, ptr %l121, !tbaa !24
  %t223 = icmp eq i64 %t222, 0
  br i1 %t223, label %bb44, label %bb45
bb44:
  %t225 = load i1, ptr %l9, !tbaa !21
  store i1 %t225, ptr %l123, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb46
bb46:
  %t227 = load i1, ptr %l123, !tbaa !21
  store i1 %t227, ptr %l115, !tbaa !21
  br label %bb47
bb47:
  %t228 = load i1, ptr %l115, !tbaa !21
  br i1 %t228, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l125, !tbaa !29
  %t230 = load ptr, ptr %l18, !tbaa !29
  %t232 = getelementptr %"compiler/ast:Case", ptr %t230, i32 0, i32 0
  %t233 = load %"compiler/source:Span", ptr %t232
  store %"compiler/source:Span" %t233, ptr %l127
  %t234 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t236 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %s0, ptr %s7, { i64, ptr } %t234)
  store %"compiler/msgs:Msg" %t236, ptr %l129
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t237 = load ptr, ptr %l125, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l127
  %t239 = load %"compiler/msgs:Msg", ptr %l129
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t237, %"compiler/source:Span" %t238, %"compiler/msgs:Msg" %t239)
  store i64 %t240, ptr %l130
  br label %bb51
bb51:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb68
bb52:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l18, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t244 = load i1, ptr %l6, !tbaa !21
  %t250 = call %"compiler/check:altsCovered" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtAlts(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %s6, ptr %t241, ptr %t242, { i64, ptr } %t243, ptr %l5, i1 %t244)
  store %"compiler/check:altsCovered" %t250, ptr %l136
  br label %bb53
bb53:
  %t251 = load %"compiler/check:altsCovered", ptr %l136
  store %"compiler/check:altsCovered" %t251, ptr %l19
  %t252 = getelementptr %"compiler/check:altsCovered", ptr %l19, i32 0, i32 2
  %t253 = load i1, ptr %t252, !tbaa !21
  br i1 %t253, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb56
bb55:
  br label %bb56
bb56:
  %t255 = getelementptr %"compiler/check:altsCovered", ptr %l19, i32 0, i32 3
  %t256 = load i1, ptr %t255, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  %t260 = load ptr, ptr %l18, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Case", ptr %t260, i32 0, i32 3
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = icmp eq ptr %t263, null
  br i1 %t265, label %bb60, label %bb61
bb60:
  %t267 = load ptr, ptr %l0, !tbaa !29
  store ptr %t267, ptr %l143, !tbaa !29
  %t268 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t270 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %t270
  store ptr %t270, ptr %l145, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:altsCovered", ptr %l19, i32 0, i32 0
  %t276 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s6, ptr %s0, ptr %s0, ptr %t271, ptr %t272, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %l149
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t277 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149
  %t278 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %t278
  %t279 = load ptr, ptr %l143, !tbaa !29
  %t280 = load ptr, ptr %l145, !tbaa !29
  %t282 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t279, ptr %t280, ptr %t278)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t282, ptr %l151
  br label %bb63
bb63:
  %t283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l151
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %l8
  %t284 = getelementptr %"compiler/check:altsCovered", ptr %l19, i32 0, i32 1
  %t285 = load i1, ptr %t284, !tbaa !21
  br i1 %t285, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb66
bb65:
  br label %bb66
bb66:
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s6)
  br label %bb68
bb68:
  %t287 = load i64, ptr %l16, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l16, !tbaa !24
  br label %bb36
bb69:
  %t291 = load i1, ptr %l11, !tbaa !21
  br i1 %t291, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb77
bb71:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t297 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t293, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t297, ptr %l160
  br label %bb72
bb72:
  %t299 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l160)
  store i64 %t299, ptr %l162
  br label %bb73
bb73:
  %t300 = load i64, ptr %l162, !tbaa !24
  %t301 = icmp eq i64 %t300, 0
  br i1 %t301, label %bb74, label %bb75
bb74:
  %t303 = load i1, ptr %l9, !tbaa !21
  store i1 %t303, ptr %l164, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb76
bb76:
  %t305 = load i1, ptr %l164, !tbaa !21
  store i1 %t305, ptr %l156, !tbaa !21
  br label %bb77
bb77:
  %t306 = load i1, ptr %l156, !tbaa !21
  store i1 %t306, ptr %l20, !tbaa !21
  %t307 = load i1, ptr %l10, !tbaa !21
  br i1 %t307, label %bb78, label %bb79
bb78:
  %t309 = load i1, ptr %l20, !tbaa !21
  %t311 = xor i1 %t309, true
  store i1 %t311, ptr %l167, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb80
bb80:
  %t313 = load i1, ptr %l167, !tbaa !21
  br i1 %t313, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t318 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s13, ptr %t314, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t318, ptr %l173
  br label %bb83
bb82:
  br label %bb99
bb83:
  %t319 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l173
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t319, ptr %l21
  %t321 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s13, ptr %l21)
  store i64 %t321, ptr %l175
  br label %bb84
bb84:
  %t322 = load i64, ptr %l175, !tbaa !24
  %t323 = icmp sgt i64 %t322, 0
  br i1 %t323, label %bb85, label %bb86
bb85:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s13, ptr %s13, ptr %t325, ptr %l21)
  store { i64, ptr } %t328, ptr %l180
  br label %bb87
bb86:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l177, !tbaa !27
  br label %bb88
bb87:
  %t329 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l177, !tbaa !27
  br label %bb88
bb88:
  %t337 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t337, ptr %l22, !tbaa !27
  %t339 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s13, ptr %l21)
  store i64 %t339, ptr %l183
  br label %bb89
bb89:
  %t340 = load i64, ptr %l183, !tbaa !24
  %t341 = icmp sgt i64 %t340, 0
  br i1 %t341, label %bb90, label %bb91
bb90:
  %t343 = load i1, ptr %l9, !tbaa !21
  %t345 = xor i1 %t343, true
  store i1 %t345, ptr %l185, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb92
bb92:
  %t347 = load i1, ptr %l185, !tbaa !21
  br i1 %t347, label %bb93, label %bb94
bb93:
  %t348 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = extractvalue { i64, ptr } %t348, 0
  %t352 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t355 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t354)
  call void @olang_textcopy(ptr %t355, ptr %t350, i64 %t351)
  %t356 = getelementptr i8, ptr %t355, i64 %t351
  call void @olang_textcopy(ptr %t356, ptr %t352, i64 %t353)
  %t357 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t355, 1
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } %t358, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  store { i64, ptr } %t365, ptr %l22, !tbaa !27
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l191, !tbaa !29
  %t368 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t369 = load i32, ptr %t368, !tbaa !23
  %t370 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t371 = load i32, ptr %t370, !tbaa !23
  %t373 = add i32 %t371, 5
  %t376 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 %t369, i32 %t373)
  store %"compiler/source:Span" %t376, ptr %l195
  br label %bb96
bb96:
  %t377 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t379 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %s13, ptr %s13, { i64, ptr } %t377)
  store %"compiler/msgs:Msg" %t379, ptr %l197
  br label %bb97
bb97:
  %t380 = load ptr, ptr %l191, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l195
  %t382 = load %"compiler/msgs:Msg", ptr %l197
  %t383 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t380, %"compiler/source:Span" %t381, %"compiler/msgs:Msg" %t382)
  store i64 %t383, ptr %l198
  br label %bb98
bb98:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb99
bb99:
  %t384 = load i1, ptr %l10, !tbaa !21
  %t386 = xor i1 %t384, true
  br i1 %t386, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s0)
  %t389 = insertvalue { i32, i1 } zeroinitializer, i32 65536, 0
  store { i32, i1 } %t389, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t390 = load i1, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t392 = insertvalue { i32, i1 } zeroinitializer, i1 %t390, 1
  store { i32, i1 } %t392, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i64
  %l26 = alloca %"compiler/check:errBind"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb20
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 16
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l15
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %l3, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 57
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l18
  br label %bb7
bb7:
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = sub i64 %t28, 1
  store i64 %t29, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 57
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t39, i64 %t40)
  store %"compiler/check:errBind" %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = getelementptr %"compiler/check:errBind", ptr %l26, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t49 = icmp eq i32 %t45, %a1
  br i1 %t49, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 58
  %t54 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t53, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = sub i64 %t57, 1
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb8
bb18:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 19
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l2, !tbaa !24
  br label %bb19
bb19:
  br label %bb2
bb20:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %lp26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l61 = alloca i32
  %l68 = alloca i32
  %l70 = alloca ptr
  %l73 = alloca i64
  %l86 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca %"compiler/generic:Context"
  %l100 = alloca %"compiler/generic:Context"
  %l105 = alloca ptr
  %l109 = alloca i32
  %l111 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l119 = alloca i64
  %l129 = alloca { i64, ptr }
  %l140 = alloca i1
  %l145 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l150 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l161 = alloca i32
  %l164 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l172 = alloca i32
  %l173 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l191 = alloca %"compiler/msgs:Msg"
  %l192 = alloca i64
  %l195 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i64
  %l223 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l232 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l241 = alloca %"compiler/source:Span"
  %l243 = alloca %"compiler/source:Span"
  %l244 = alloca i32
  %l248 = alloca %"compiler/typed:Make"
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"compiler/typed:Block"
  %l260 = alloca ptr
  %l265 = alloca i1
  %l268 = alloca i1
  %l270 = alloca ptr
  %l274 = alloca i1
  %l276 = alloca i1
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca %"compiler/msgs:Msg"
  %l282 = alloca i64
  %l284 = alloca ptr
  %l287 = alloca { i64, ptr }
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca i32
  %l297 = alloca i32
  %l298 = alloca { i64, ptr }
  %l303 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t99 = alloca { i64, [2 x i64] }, align 8
  %t144 = alloca %"compiler/generic:Context", align 8
  %t275 = alloca { i64, [3 x i64] }, align 8
  %t467 = alloca { i64, [5 x i64] }, align 8
  %t479 = alloca { i64, [3 x i64] }, align 8
  %t584 = alloca { i64, [4 x i64] }, align 8
  %t596 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Catch", ptr %t6, i32 0, i32 2
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l30, !tbaa !21
  store i1 %t15, ptr %l4, !tbaa !21
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/ast:Catch", ptr %t16, i32 0, i32 3
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t23 = icmp sgt i64 %t21, 0
  store i1 %t23, ptr %l5, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = load i1, ptr %l5, !tbaa !21
  %t31 = xor i1 %t29, true
  store i1 %t31, ptr %l41, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l41, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l44, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l44, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t40 = load i1, ptr %l5, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load i64, ptr %l3, !tbaa !24
  %t44 = icmp eq i64 %t42, 0
  store i1 %t44, ptr %l49, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l49, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %t48, ptr %t49)
  store %"compiler/source:Span" %t52, ptr %l55
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t53 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %s2)
  store %"compiler/msgs:Msg" %t53, ptr %l56
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l52, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l55
  %t56 = load %"compiler/msgs:Msg", ptr %l56
  %t57 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t54, %"compiler/source:Span" %t55, %"compiler/msgs:Msg" %t56)
  store i64 %t57, ptr %l57
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb21:
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load i32, ptr %l2, !tbaa !23
  store i32 %t63, ptr %l61, !tbaa !23
  br label %bb24
bb23:
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t65, ptr %l61, !tbaa !23
  br label %bb24
bb24:
  %t67 = load i32, ptr %l61, !tbaa !23
  store i32 %t67, ptr %l6, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load i32, ptr %l6, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t73, i32 0, i32 %t74, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t77, ptr %l68
  br label %bb25
bb25:
  %t78 = load i32, ptr %l68, !tbaa !23
  store i32 %t78, ptr %l7, !tbaa !23
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l70
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l70, !tbaa !29
  store ptr %t82, ptr %l8, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 16
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l73
  br label %bb27
bb27:
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = sub i64 %t88, 1
  store i64 %t89, ptr %l9, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 0
  store i64 4, ptr %t100
  %t102 = insertvalue { i32 } undef, i32 %t97, 0
  %t103 = getelementptr { i64, [2 x i64] }, ptr %t99, i32 0, i32 1
  store { i32 } %t102, ptr %t103
  %t104 = load { i64, [2 x i64] }, ptr %t99
  %t105 = load i32, ptr %l7, !tbaa !23
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = getelementptr %"compiler/check:frame", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Catch", ptr %t110, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t91, { i64, [2 x i64] } %t104, i32 %t105, i64 %t109, %"compiler/source:Span" %t113)
  store i64 %t119, ptr %l86
  br label %bb28
bb28:
  %t120 = load i64, ptr %l86, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 19
  %t124 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t123, i64 %t124, i64 1)
  br label %bb29
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load ptr, ptr %l8, !tbaa !29
  %t131 = getelementptr %"compiler/check:frame", ptr %t129, i32 0, i32 1
  %t132 = load i64, ptr %t131, !tbaa !24
  %t133 = load i32, ptr %l6, !tbaa !23
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t127, i64 %t128, i64 %t132, i32 %t133, i32 0)
  store ptr %t138, ptr %l95
  br label %bb30
bb30:
  %t139 = load ptr, ptr %l95, !tbaa !29
  store ptr %t139, ptr %l11, !tbaa !29
  %t140 = load ptr, ptr %l11, !tbaa !29
  store ptr %t140, ptr %l96, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l98, ptr %t143, i64 160, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t144, ptr %v0, ptr %l98)
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t144, i64 160, i1 false)
  br label %bb31
bb31:
  %t146 = load ptr, ptr %l96, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t146, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t147, ptr %l100, i64 160, i1 false)
  %t148 = load ptr, ptr %l11, !tbaa !29
  %t149 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 19
  store i64 %t149, ptr %t152, !tbaa !24
  %t153 = load ptr, ptr %l11, !tbaa !29
  %t155 = getelementptr %"compiler/check:frame", ptr %t153, i32 0, i32 32
  store i1 true, ptr %t155, !tbaa !21
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l105
  br label %bb32
bb32:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/ast:Catch", ptr %t159, i32 0, i32 0
  %t162 = load %"compiler/source:Span", ptr %t161
  %t163 = load ptr, ptr %l105, !tbaa !29
  %t166 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t163, i32 -1, i32 0, %"compiler/source:Span" %t162)
  store i32 %t166, ptr %l109
  br label %bb33
bb33:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l111
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load i32, ptr %l7, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l115
  br label %bb35
bb35:
  %t178 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 8
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l111, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t185, { i64, ptr } %t184)
  br label %bb36
bb36:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 37
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t189)
  store i64 %t191, ptr %l119
  br label %bb37
bb37:
  %t192 = load i64, ptr %l119, !tbaa !24
  store i64 %t192, ptr %l12, !tbaa !24
  %t193 = load i1, ptr %l4, !tbaa !21
  br i1 %t193, label %bb38, label %bb39
bb38:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/ast:Catch", ptr %t195, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t200 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t200, 0
  store i64 %t202, ptr %l15, !tbaa !24
  br label %bb40
bb39:
  br label %bb47
bb40:
  %t204 = load i64, ptr %l14, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  %t208 = icmp slt i64 %t204, %t205
  %t210 = xor i1 %t208, true
  br i1 %t210, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t212 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t212, ptr %l129, !tbaa !27
  %t213 = load i64, ptr %l14, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 %t213
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t220, ptr %t218)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t225 = load i64, ptr %l14, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l14, !tbaa !24
  br label %bb40
bb46:
  br label %bb47
bb47:
  %t229 = load i1, ptr %l5, !tbaa !21
  br i1 %t229, label %bb48, label %bb49
bb48:
  %t231 = load i64, ptr %l3, !tbaa !24
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb50, label %bb51
bb49:
  br label %bb91
bb50:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb52
bb51:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/ast:Catch", ptr %t235, i32 0, i32 3
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = icmp eq i64 %t240, 1
  store i1 %t242, ptr %l140, !tbaa !21
  br label %bb52
bb52:
  %t244 = load i1, ptr %l140, !tbaa !21
  br i1 %t244, label %bb53, label %bb54
bb53:
  %t245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t245, ptr %l145, !tbaa !29
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t248 = getelementptr %"compiler/ast:Catch", ptr %t246, i32 0, i32 0
  %t249 = load %"compiler/source:Span", ptr %t248
  store %"compiler/source:Span" %t249, ptr %l147
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr %"compiler/ast:Catch", ptr %t251, i32 0, i32 3
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l150, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr ptr, ptr %t256, i64 0
  %t258 = load ptr, ptr %t257, !tbaa !39
  %t259 = load i32, ptr %l2, !tbaa !23
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t250, ptr %t258, i32 %t259)
  store ptr %t263, ptr %l153
  br label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t264, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 2
  %t270 = load i32, ptr %l2, !tbaa !23
  %t273 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t269, i32 %t270)
  store i32 %t273, ptr %l161
  br label %bb57
bb55:
  %t274 = load ptr, ptr %l153, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 0
  store i64 6, ptr %t276
  %t277 = load %"compiler/source:Span", ptr %l147
  %t278 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t277, 0
  %t280 = insertvalue { %"compiler/source:Span", ptr } %t278, ptr %t274, 1
  %t281 = getelementptr { i64, [3 x i64] }, ptr %t275, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t280, ptr %t281
  %t282 = load { i64, [3 x i64] }, ptr %t275
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t282, ptr %t284
  %t285 = load ptr, ptr %l145, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t285, ptr %t284)
  br label %bb56
bb56:
  br label %bb90
bb57:
  %t287 = load i32, ptr %l161, !range !{i32 0, i32 33}
  %t289 = trunc i64 22 to i32
  %t290 = icmp eq i32 %t287, %t289
  br i1 %t290, label %bb58, label %bb59
bb58:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = getelementptr %"compiler/generic:Program", ptr %t295, i32 0, i32 2
  store ptr %t297, ptr %l167, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/check:Checker", ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t303 = getelementptr %"compiler/generic:Program", ptr %t301, i32 0, i32 2
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t303, i32 %t304)
  store i32 %t307, ptr %l172
  br label %bb60
bb59:
  %t308 = icmp sge i64 0, 0
  br i1 %t308, label %bb62, label %bb63
bb60:
  %t310 = load ptr, ptr %l167, !tbaa !29
  %t311 = load i32, ptr %l172, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s9, ptr %t310, i32 %t311)
  store { i64, ptr } %t312, ptr %l173
  br label %bb61
bb61:
  %t313 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t313, ptr %l164, !tbaa !27
  br label %bb66
bb62:
  %t314 = icmp sle i64 0, 2305843009213693951
  br i1 %t314, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb64:
  %t316 = mul i64 0, 4
  %t317 = insertvalue { i64, ptr } undef, i64 0, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t318, ptr %l164, !tbaa !27
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33)
  unreachable
bb66:
  %t320 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t320, ptr %l17, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr %"compiler/ast:Catch", ptr %t324, i32 0, i32 3
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t332 = icmp ne i64 %t323, %t329
  br i1 %t332, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s10
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l183, !tbaa !29
  %t335 = load ptr, ptr %l1, !tbaa !29
  %t337 = getelementptr %"compiler/ast:Catch", ptr %t335, i32 0, i32 0
  %t338 = load %"compiler/source:Span", ptr %t337
  store %"compiler/source:Span" %t338, ptr %l185
  %t339 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr %"compiler/ast:Catch", ptr %t342, i32 0, i32 3
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  %t350 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %s10, i64 %t341, i64 %t347)
  store %"compiler/msgs:Msg" %t350, ptr %l191
  br label %bb69
bb68:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 36
  %t355 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t353)
  store i64 %t355, ptr %l195
  br label %bb71
bb69:
  %t356 = load ptr, ptr %l183, !tbaa !29
  %t357 = load %"compiler/source:Span", ptr %l185
  %t358 = load %"compiler/msgs:Msg", ptr %l191
  %t359 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t356, %"compiler/source:Span" %t357, %"compiler/msgs:Msg" %t358)
  store i64 %t359, ptr %l192
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb71:
  %t360 = load i64, ptr %l195, !tbaa !24
  store i64 %t360, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t361 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  store i64 %t363, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l19, !tbaa !24
  %t369 = icmp sgt i64 %t365, %t366
  br i1 %t369, label %bb72, label %bb73
bb72:
  %t371 = load i64, ptr %l21, !tbaa !24
  %t373 = icmp sgt i64 %t371, 0
  br i1 %t373, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb77
bb74:
  %t375 = load i64, ptr %l20, !tbaa !24
  %t376 = load i64, ptr %l19, !tbaa !24
  %t379 = sub i64 %t375, %t376
  %t380 = load i64, ptr %l21, !tbaa !24
  %t383 = add i64 %t379, %t380
  %t385 = sub i64 %t383, 1
  %t386 = load i64, ptr %l21, !tbaa !24
  %t389 = sdiv i64 %t385, %t386
  store i64 %t389, ptr %l204, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb76
bb76:
  %t391 = load i64, ptr %l204, !tbaa !24
  store i64 %t391, ptr %l201, !tbaa !24
  br label %bb77
bb77:
  %t392 = load i64, ptr %l201, !tbaa !24
  store i64 %t392, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb78
bb78:
  %t393 = load i64, ptr %l23, !tbaa !24
  %t394 = load i64, ptr %l22, !tbaa !24
  %t397 = icmp slt i64 %t393, %t394
  %t399 = xor i1 %t397, true
  br i1 %t399, label %bb79, label %bb80
bb79:
  br label %bb85
bb80:
  br label %bb81
bb81:
  %t401 = load i64, ptr %l19, !tbaa !24
  %t402 = load i64, ptr %l23, !tbaa !24
  %t403 = load i64, ptr %l21, !tbaa !24
  %t406 = mul i64 %t402, %t403
  %t409 = add i64 %t401, %t406
  store i64 %t409, ptr %l24, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 36
  store ptr %t413, ptr %l223, !tbaa !29
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load ptr, ptr %l1, !tbaa !29
  %t417 = getelementptr %"compiler/ast:Catch", ptr %t415, i32 0, i32 3
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l226, !tbaa !27
  %t419 = load i64, ptr %l24, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr ptr, ptr %t422, i64 %t419
  %t424 = load ptr, ptr %t423, !tbaa !39
  %t425 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t425, ptr %l229, !tbaa !27
  %t426 = load i64, ptr %l24, !tbaa !24
  %t428 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t429 = load ptr, ptr %t428, !tbaa !27
  %t430 = getelementptr i32, ptr %t429, i64 %t426
  %t431 = load i32, ptr %t430, !tbaa !33
  %t435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v0, ptr %t414, ptr %t424, i32 %t431)
  store ptr %t435, ptr %l232
  br label %bb82
bb82:
  %t436 = load ptr, ptr %l223, !tbaa !29
  %t437 = load ptr, ptr %l232, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t436, ptr %t437)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t438 = load i64, ptr %l23, !tbaa !24
  %t440 = add i64 %t438, 1
  store i64 %t440, ptr %l23, !tbaa !24
  br label %bb78
bb85:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 36
  %t445 = load i64, ptr %l18, !tbaa !24
  %t448 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t444, i64 %t445)
  store { i64, ptr } %t448, ptr %l238
  br label %bb86
bb86:
  %t449 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l239, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr %"compiler/ast:Catch", ptr %t451, i32 0, i32 0
  %t454 = load %"compiler/source:Span", ptr %t453
  store %"compiler/source:Span" %t454, ptr %l241
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr %"compiler/ast:Catch", ptr %t455, i32 0, i32 0
  %t458 = load %"compiler/source:Span", ptr %t457
  store %"compiler/source:Span" %t458, ptr %l243
  %t459 = load i32, ptr %l2, !tbaa !23
  store i32 %t459, ptr %l244, !tbaa !23
  %t464 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t449, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t464, ptr %l248
  br label %bb87
bb87:
  %t465 = load %"compiler/typed:Make", ptr %l248
  %t466 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t465, ptr %t466
  store { i64, [5 x i64] } zeroinitializer, ptr %t467
  %t468 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 0
  store i64 7, ptr %t468
  %t469 = load %"compiler/source:Span", ptr %l243
  %t470 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t469, 0
  %t471 = load i32, ptr %l244, !tbaa !23
  %t472 = insertvalue { %"compiler/source:Span", i32, ptr } %t470, i32 %t471, 1
  %t474 = insertvalue { %"compiler/source:Span", i32, ptr } %t472, ptr %t466, 2
  %t475 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t474, ptr %t475
  %t476 = load { i64, [5 x i64] }, ptr %t467
  %t478 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t476, ptr %t478
  store { i64, [3 x i64] } zeroinitializer, ptr %t479
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 0
  store i64 6, ptr %t480
  %t481 = load %"compiler/source:Span", ptr %l241
  %t482 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t481, 0
  %t484 = insertvalue { %"compiler/source:Span", ptr } %t482, ptr %t478, 1
  %t485 = getelementptr { i64, [3 x i64] }, ptr %t479, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t484, ptr %t485
  %t486 = load { i64, [3 x i64] }, ptr %t479
  %t488 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t486, ptr %t488
  %t489 = load ptr, ptr %l239, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t489, ptr %t488)
  br label %bb88
bb88:
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s9)
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 37
  %t494 = load i64, ptr %l12, !tbaa !24
  %t497 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t493, i64 %t494)
  store { i64, ptr } %t497, ptr %l257
  br label %bb92
bb92:
  %t498 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t499 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t498)
  store %"compiler/typed:Block" %t499, ptr %l258
  br label %bb93
bb93:
  %t500 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t500, ptr %lp26
  %t501 = load %"compiler/typed:Block", ptr %l258
  %t502 = load ptr, ptr %lp26
  store %"compiler/typed:Block" %t501, ptr %t502
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t503)
  store ptr %t505, ptr %l260
  br label %bb94
bb94:
  %t506 = load ptr, ptr %l260, !tbaa !29
  %t507 = load ptr, ptr %lp26
  %t510 = getelementptr %"compiler/typed:Body", ptr %t506, i32 0, i32 11
  store ptr %t507, ptr %t510, !tbaa !29
  %t511 = load i64, ptr %l3, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb95, label %bb96
bb95:
  %t515 = load i1, ptr %l5, !tbaa !21
  %t517 = xor i1 %t515, true
  store i1 %t517, ptr %l265, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb97
bb97:
  %t519 = load i1, ptr %l265, !tbaa !21
  br i1 %t519, label %bb98, label %bb99
bb98:
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t520)
  store ptr %t522, ptr %l270
  br label %bb100
bb99:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb101
bb100:
  %t523 = load ptr, ptr %l270, !tbaa !29
  %t525 = getelementptr %"compiler/check:frame", ptr %t523, i32 0, i32 18
  %t526 = load i1, ptr %t525, !tbaa !21
  %t528 = xor i1 %t526, true
  store i1 %t528, ptr %l268, !tbaa !21
  br label %bb101
bb101:
  %t530 = load i1, ptr %l268, !tbaa !21
  br i1 %t530, label %bb102, label %bb103
bb102:
  %t531 = load ptr, ptr %lp26
  %t533 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t531)
  store i1 %t533, ptr %l276
  br label %bb104
bb103:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb105
bb104:
  %t534 = load i1, ptr %l276, !tbaa !21
  %t535 = xor i1 %t534, true
  store i1 %t535, ptr %l274, !tbaa !21
  br label %bb105
bb105:
  %t537 = load i1, ptr %l274, !tbaa !21
  br i1 %t537, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s15
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l278, !tbaa !29
  %t539 = load ptr, ptr %l1, !tbaa !29
  %t541 = getelementptr %"compiler/ast:Catch", ptr %t539, i32 0, i32 0
  %t542 = load %"compiler/source:Span", ptr %t541
  store %"compiler/source:Span" %t542, ptr %l280
  %t543 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %s15)
  store %"compiler/msgs:Msg" %t543, ptr %l281
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t544 = load ptr, ptr %l278, !tbaa !29
  %t545 = load %"compiler/source:Span", ptr %l280
  %t546 = load %"compiler/msgs:Msg", ptr %l281
  %t547 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t544, %"compiler/source:Span" %t545, %"compiler/msgs:Msg" %t546)
  store i64 %t547, ptr %l282
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb110:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t548)
  store ptr %t550, ptr %l284
  br label %bb111
bb111:
  %t551 = load ptr, ptr %l284, !tbaa !29
  %t553 = getelementptr %"compiler/check:frame", ptr %t551, i32 0, i32 30
  %t555 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v2, ptr %t553)
  store { i64, ptr } %t555, ptr %l287
  br label %bb112
bb112:
  %t556 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t556, ptr %l27, !tbaa !27
  %t557 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t557)
  br label %bb113
bb113:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 19
  %t562 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t561, i64 %t562, i64 2)
  br label %bb114
bb114:
  %t565 = load ptr, ptr %l1, !tbaa !29
  %t567 = getelementptr %"compiler/ast:Catch", ptr %t565, i32 0, i32 0
  %t568 = load %"compiler/source:Span", ptr %t567
  store %"compiler/source:Span" %t568, ptr %l293
  %t569 = load i32, ptr %l7, !tbaa !23
  store i32 %t569, ptr %l294, !tbaa !23
  %t570 = load i64, ptr %l10, !tbaa !24
  %t572 = trunc i64 %t570 to i32
  store i32 %t572, ptr %l297, !tbaa !23
  %t574 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t574, ptr %l298, !tbaa !27
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load ptr, ptr %l1, !tbaa !29
  %t578 = getelementptr %"compiler/ast:Catch", ptr %t576, i32 0, i32 0
  %t579 = load %"compiler/source:Span", ptr %t578
  %t583 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t575, i32 5, %"compiler/source:Span" %t579)
  store i32 %t583, ptr %l303
  br label %bb115
bb115:
  store { i64, [4 x i64] } zeroinitializer, ptr %t584
  %t585 = getelementptr { i64, [4 x i64] }, ptr %t584, i32 0, i32 0
  store i64 1, ptr %t585
  %t586 = load i32, ptr %l297, !tbaa !23
  %t587 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t586, 0
  %t588 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t589 = insertvalue { i32, { i64, ptr }, i32 } %t587, { i64, ptr } %t588, 1
  %t590 = load i32, ptr %l303, !tbaa !23
  %t591 = insertvalue { i32, { i64, ptr }, i32 } %t589, i32 %t590, 2
  %t592 = getelementptr { i64, [4 x i64] }, ptr %t584, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t591, ptr %t592
  %t593 = load { i64, [4 x i64] }, ptr %t584
  %t595 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t593, ptr %t595
  store { i64, [5 x i64] } zeroinitializer, ptr %t596
  %t597 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 0
  store i64 15, ptr %t597
  %t598 = load %"compiler/source:Span", ptr %l293
  %t599 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t598, 0
  %t600 = load i32, ptr %l294, !tbaa !23
  %t601 = insertvalue { %"compiler/source:Span", i32, ptr } %t599, i32 %t600, 1
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } %t601, ptr %t595, 2
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t596, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t603, ptr %t604
  %t605 = load { i64, [5 x i64] }, ptr %t596
  %t607 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t605, ptr %t607
  call void @__olang_scope_close(ptr %s0)
  store ptr %t607, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdReads(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l33 = alloca { i64, ptr }
  %l42 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l63 = alloca i1
  %l66 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l116 = alloca i1
  %rv = alloca i1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t10, i64 %a1)
  store { i64, ptr } %t14, ptr %l17
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t15, ptr %l18, !tbaa !27
  %t17 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  store i64 %t24, ptr %l22, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb2, label %bb3
bb2:
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb4:
  %t34 = load i64, ptr %l22, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb6:
  %t38 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l20, !tbaa !24
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  store i1 false, ptr %l7, !tbaa !21
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f259f6ca06e66809_b1ef05920a904ef5)
  unreachable
bb8:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = icmp slt i64 %t47, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  br label %bb63
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t57, ptr %l33, !tbaa !27
  %t58 = load i64, ptr %l6, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t67 = icmp eq i8 %t63, 34
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t69 = load i1, ptr %l7, !tbaa !21
  %t71 = xor i1 %t69, true
  store i1 %t71, ptr %l7, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t73 = load i1, ptr %l7, !tbaa !21
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb15, label %bb16
bb15:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t83 = add i64 %t77, %t80
  %t84 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t89 = icmp sle i64 %t83, %t86
  store i1 %t89, ptr %l42, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t91 = load i1, ptr %l42, !tbaa !21
  br i1 %t91, label %bb18, label %bb19
bb18:
  %t92 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t92, ptr %l51, !tbaa !27
  %t93 = load i64, ptr %l6, !tbaa !24
  store i64 %t93, ptr %l52, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t100 = add i64 %t94, %t97
  store i64 %t100, ptr %l56, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  store i64 %t102, ptr %l57, !tbaa !24
  %t103 = load i64, ptr %l52, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb27
bb20:
  %t106 = load i64, ptr %l52, !tbaa !24
  %t107 = load i64, ptr %l56, !tbaa !24
  %t108 = icmp sle i64 %t106, %t107
  br i1 %t108, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb22:
  %t110 = load i64, ptr %l56, !tbaa !24
  %t111 = load i64, ptr %l57, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb24:
  %t114 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = load i64, ptr %l56, !tbaa !24
  %t118 = getelementptr i8, ptr %t115, i64 %t116
  %t119 = sub i64 %t117, %t116
  %t120 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t121, { i64, ptr } %t122)
  store i1 %t125, ptr %l63
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798)
  unreachable
bb26:
  %t126 = load i1, ptr %l63, !tbaa !21
  store i1 %t126, ptr %l50, !tbaa !21
  br label %bb27
bb27:
  %t127 = load i1, ptr %l50, !tbaa !21
  br i1 %t127, label %bb28, label %bb29
bb28:
  %t128 = load i64, ptr %l6, !tbaa !24
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb30, label %bb31
bb29:
  br label %bb61
bb30:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb43
bb31:
  %t132 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t132, ptr %l67, !tbaa !27
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = sub i64 %t133, 1
  %t137 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t140)
  store i1 %t142, ptr %l71
  br label %bb32
bb32:
  %t143 = load i1, ptr %l71, !tbaa !21
  br i1 %t143, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb36
bb34:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l73, !tbaa !27
  %t145 = load i64, ptr %l6, !tbaa !24
  %t147 = sub i64 %t145, 1
  %t149 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i8, ptr %t150, i64 %t147
  %t152 = load i8, ptr %t151, !tbaa !32
  %t154 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t152)
  store i1 %t154, ptr %l77
  br label %bb35
bb35:
  %t155 = load i1, ptr %l77, !tbaa !21
  store i1 %t155, ptr %l72, !tbaa !21
  br label %bb36
bb36:
  %t156 = load i1, ptr %l72, !tbaa !21
  br i1 %t156, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb39
bb38:
  %t157 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t157, ptr %l79, !tbaa !27
  %t158 = load i64, ptr %l6, !tbaa !24
  %t160 = sub i64 %t158, 1
  %t162 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i8, ptr %t163, i64 %t160
  %t165 = load i8, ptr %t164, !tbaa !32
  %t167 = icmp eq i8 %t165, 95
  store i1 %t167, ptr %l78, !tbaa !21
  br label %bb39
bb39:
  %t169 = load i1, ptr %l78, !tbaa !21
  br i1 %t169, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb42
bb41:
  %t170 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t170, ptr %l85, !tbaa !27
  %t171 = load i64, ptr %l6, !tbaa !24
  %t173 = sub i64 %t171, 1
  %t175 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t173
  %t178 = load i8, ptr %t177, !tbaa !32
  %t180 = icmp eq i8 %t178, 46
  store i1 %t180, ptr %l84, !tbaa !21
  br label %bb42
bb42:
  %t182 = load i1, ptr %l84, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l66, !tbaa !21
  br label %bb43
bb43:
  %t185 = load i1, ptr %l66, !tbaa !21
  store i1 %t185, ptr %l9, !tbaa !21
  %t186 = load i64, ptr %l6, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t192 = add i64 %t186, %t189
  store i64 %t192, ptr %l10, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t195 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t200 = icmp sge i64 %t194, %t197
  br i1 %t200, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb54
bb45:
  %t202 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t202, ptr %l100, !tbaa !27
  %t203 = load i64, ptr %l10, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t208)
  store i1 %t210, ptr %l103
  br label %bb46
bb46:
  %t211 = load i1, ptr %l103, !tbaa !21
  br i1 %t211, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb50
bb48:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t212, ptr %l105, !tbaa !27
  %t213 = load i64, ptr %l10, !tbaa !24
  %t215 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr i8, ptr %t216, i64 %t213
  %t218 = load i8, ptr %t217, !tbaa !32
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t218)
  store i1 %t220, ptr %l108
  br label %bb49
bb49:
  %t221 = load i1, ptr %l108, !tbaa !21
  store i1 %t221, ptr %l104, !tbaa !21
  br label %bb50
bb50:
  %t222 = load i1, ptr %l104, !tbaa !21
  br i1 %t222, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb53
bb52:
  %t223 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t223, ptr %l110, !tbaa !27
  %t224 = load i64, ptr %l10, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i8, ptr %t227, i64 %t224
  %t229 = load i8, ptr %t228, !tbaa !32
  %t231 = icmp eq i8 %t229, 95
  store i1 %t231, ptr %l109, !tbaa !21
  br label %bb53
bb53:
  %t233 = load i1, ptr %l109, !tbaa !21
  %t234 = xor i1 %t233, true
  store i1 %t234, ptr %l99, !tbaa !21
  br label %bb54
bb54:
  %t236 = load i1, ptr %l99, !tbaa !21
  store i1 %t236, ptr %l11, !tbaa !21
  %t237 = load i1, ptr %l9, !tbaa !21
  br i1 %t237, label %bb55, label %bb56
bb55:
  %t239 = load i1, ptr %l11, !tbaa !21
  store i1 %t239, ptr %l116, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb57
bb57:
  %t241 = load i1, ptr %l116, !tbaa !21
  br i1 %t241, label %bb58, label %bb59
bb58:
  store i1 true, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t243 = load i64, ptr %l6, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l6, !tbaa !24
  br label %bb62
bb62:
  br label %bb8
bb63:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb6
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t5)
  store ptr %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/check:frame", ptr %t8, i32 0, i32 4
  %t11 = getelementptr %"compiler/generic:Context", ptr %t10, i32 0, i32 3
  %t13 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l8
  br label %bb5
bb5:
  %t14 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t14, 0
  store i1 %t15, ptr %l3, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l3, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l50 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i64
  %l90 = alloca i32
  %l93 = alloca ptr
  %l99 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i32
  %l111 = alloca i32
  %l116 = alloca i32
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca i32
  %l126 = alloca i32
  %l138 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l154 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca ptr
  %l159 = alloca %"compiler/generic:Context"
  %l163 = alloca ptr
  %l166 = alloca i32
  %l175 = alloca ptr
  %l182 = alloca i32
  %l189 = alloca %"compiler/source:Span"
  %l191 = alloca i32
  %l207 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca %"compiler/source:Span"
  %l221 = alloca i32
  %l230 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l239 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t223 = alloca { i64, [2 x i64] }, align 8
  %t285 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %s0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l27, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4d78ccd557b2cb07_4b61304073c9a48b)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l5, !tbaa !29
  store ptr %t11, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l33, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l38
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l33, !tbaa !29
  %t30 = load i32, ptr %l38, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l39
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t32, ptr %l7, !tbaa !27
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l40
  br label %bb7
bb7:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l8
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l41
  br label %bb8
bb8:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l9
  store i64 0, ptr %l10, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  store i64 %t39, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = load i64, ptr %l10, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l12, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb14
bb11:
  %t51 = load i64, ptr %l11, !tbaa !24
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l12, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l12, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l50, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l50, !tbaa !24
  store i64 %t67, ptr %l47, !tbaa !24
  br label %bb14
bb14:
  %t68 = load i64, ptr %l47, !tbaa !24
  store i64 %t68, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l14, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb16, label %bb17
bb16:
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l14, !tbaa !24
  %t79 = load i64, ptr %l12, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l15, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t87, ptr %l68, !tbaa !27
  %t88 = load i64, ptr %l15, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  store i32 %t93, ptr %l16, !tbaa !23
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l16, !tbaa !23
  %t99 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t95, i32 %t96)
  store i1 %t99, ptr %l73
  br label %bb19
bb19:
  %t100 = load i1, ptr %l73, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 2
  store ptr %t106, ptr %l76, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  %t113 = load i32, ptr %l16, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t112, i32 %t113)
  store i32 %t116, ptr %l81
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l16, !tbaa !23
  %t126 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t122, i32 %t123)
  store i64 %t126, ptr %l86
  br label %bb23
bb23:
  %t127 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t129 = xor i64 %t127, -1
  %t130 = load i64, ptr %l86, !tbaa !24
  %t132 = and i64 %t130, %t129
  %t133 = load ptr, ptr %l76, !tbaa !29
  %t134 = load i32, ptr %l81, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t133, i32 %t134, i64 %t132)
  store i32 %t136, ptr %l90
  br label %bb24
bb24:
  %t137 = load i32, ptr %l90, !tbaa !23
  store i32 %t137, ptr %l16, !tbaa !23
  br label %bb25
bb25:
  %t138 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i32 %t138)
  br label %bb26
bb26:
  store ptr %l9, ptr %l93, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr %l3, !tbaa !23
  %t148 = load i64, ptr %l15, !tbaa !24
  %t152 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t146, i32 %t147, i64 %t148)
  store i64 %t152, ptr %l99
  br label %bb27
bb27:
  %t153 = load ptr, ptr %l93, !tbaa !29
  %t154 = load i64, ptr %l99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t153, i64 %t154)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l14, !tbaa !24
  br label %bb15
bb30:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  store ptr %t164, ptr %l104, !tbaa !29
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 2
  store ptr %t170, ptr %l107, !tbaa !29
  %t172 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t172, ptr %l109
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l107, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t173, { i64, ptr } %t174)
  store i32 %t175, ptr %l110
  br label %bb32
bb32:
  %t176 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t176, ptr %l111, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l116
  br label %bb33
bb33:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 2
  store ptr %t192, ptr %l119, !tbaa !29
  %t193 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t193, ptr %l120, !tbaa !24
  %t195 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t195, ptr %l122
  br label %bb34
bb34:
  %t196 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t197 = mul i64 1, 8
  %t198 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 1, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  store { i64, ptr } %t200, ptr %l124, !tbaa !27
  %t202 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 0
  store i64 %t196, ptr %t204, !tbaa !34
  %t205 = load ptr, ptr %l119, !tbaa !29
  %t206 = load i64, ptr %l120, !tbaa !24
  %t207 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t209 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t205, i64 %t206, { i64, ptr } %t207, { i64, ptr } %t208)
  store i32 %t209, ptr %l125
  br label %bb35
bb35:
  %t210 = load ptr, ptr %l104, !tbaa !29
  %t211 = load i32, ptr %l110, !tbaa !23
  %t212 = load i32, ptr %l111, !tbaa !23
  %t213 = load i32, ptr %l116, !tbaa !23
  %t214 = load i32, ptr %l125, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t210, i32 %t211, i32 %t212, i32 %t213, i32 %t214, i64 0, i1 false, i32 0)
  store i32 %t215, ptr %l126
  br label %bb36
bb36:
  %t216 = load i32, ptr %l126, !tbaa !23
  store i32 %t216, ptr %l17, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load i64, ptr %l1, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 0
  store i64 8, ptr %t224
  %t226 = insertvalue { i32, i32, i64 } undef, i32 %t220, 0
  %t228 = insertvalue { i32, i32, i64 } %t226, i32 0, 1
  %t230 = insertvalue { i32, i32, i64 } %t228, i64 %a2, 2
  %t231 = getelementptr { i64, [2 x i64] }, ptr %t223, i32 0, i32 1
  store { i32, i32, i64 } %t230, ptr %t231
  %t232 = load { i64, [2 x i64] }, ptr %t223
  %t233 = load i32, ptr %l17, !tbaa !23
  %t234 = load ptr, ptr %l6, !tbaa !29
  %t236 = getelementptr %"compiler/check:ctSource", ptr %t234, i32 0, i32 3
  %t237 = load i64, ptr %t236, !tbaa !24
  %t238 = load %"compiler/source:Span", ptr %l4
  %t244 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t217, { i64, [2 x i64] } %t232, i32 %t233, i64 %t237, %"compiler/source:Span" %t238)
  store i64 %t244, ptr %l138
  br label %bb37
bb37:
  %t245 = load i64, ptr %l138, !tbaa !24
  store i64 %t245, ptr %l18, !tbaa !24
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t246, i32 0, i32 19
  %t249 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t248, i64 %t249, i64 1)
  br label %bb38
bb38:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 54
  %t255 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t254, i64 %t255, i1 true)
  br label %bb39
bb39:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l145, !tbaa !29
  %t259 = load i64, ptr %l18, !tbaa !24
  store i64 %t259, ptr %l146, !tbaa !24
  %t260 = load ptr, ptr %l6, !tbaa !29
  %t262 = getelementptr %"compiler/check:ctSource", ptr %t260, i32 0, i32 3
  %t263 = load i64, ptr %t262, !tbaa !24
  store i64 %t263, ptr %l148, !tbaa !24
  %t264 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t264, ptr %l149, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !29
  %t270 = getelementptr %"compiler/generic:Program", ptr %t268, i32 0, i32 2
  %t271 = load i32, ptr %l17, !tbaa !23
  %t274 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t270, i32 %t271)
  store i32 %t274, ptr %l154
  br label %bb40
bb40:
  %t275 = load ptr, ptr %l145, !tbaa !29
  %t276 = load i64, ptr %l146, !tbaa !24
  %t277 = load i64, ptr %l148, !tbaa !24
  %t278 = load i32, ptr %l149, !tbaa !23
  %t279 = load i32, ptr %l154, !tbaa !23
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t275, i64 %t276, i64 %t277, i32 %t278, i32 %t279)
  store ptr %t280, ptr %l155
  br label %bb41
bb41:
  %t281 = load ptr, ptr %l155, !tbaa !29
  store ptr %t281, ptr %l19, !tbaa !29
  %t282 = load ptr, ptr %l19, !tbaa !29
  store ptr %t282, ptr %l156, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %t285, ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  call void @llvm.memmove.p0.p0.i64(ptr %l159, ptr %t285, i64 160, i1 false)
  br label %bb42
bb42:
  %t288 = load ptr, ptr %l156, !tbaa !29
  %t289 = getelementptr %"compiler/check:frame", ptr %t288, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t289, ptr %l159, i64 160, i1 false)
  %t290 = load ptr, ptr %l19, !tbaa !29
  %t291 = load i64, ptr @G_2ecompiler_2fcheck_2eCtReq, !tbaa !24
  %t294 = getelementptr %"compiler/check:frame", ptr %t290, i32 0, i32 53
  store i64 %t291, ptr %t294, !tbaa !24
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t295)
  store ptr %t297, ptr %l163
  br label %bb43
bb43:
  %t298 = load %"compiler/source:Span", ptr %l4
  %t299 = load ptr, ptr %l163, !tbaa !29
  %t302 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t299, i32 -1, i32 0, %"compiler/source:Span" %t298)
  store i32 %t302, ptr %l166
  br label %bb44
bb44:
  store i64 0, ptr %l20, !tbaa !24
  %t303 = load ptr, ptr %l6, !tbaa !29
  %t305 = getelementptr %"compiler/check:ctSource", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = icmp eq ptr %t306, null
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb45, label %bb46
bb45:
  %t312 = load i64, ptr %l20, !tbaa !24
  %t313 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t313, 0
  %t318 = icmp slt i64 %t312, %t315
  br i1 %t318, label %bb47, label %bb48
bb46:
  br label %bb61
bb47:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l175, !tbaa !29
  %t321 = load ptr, ptr %l6, !tbaa !29
  %t323 = getelementptr %"compiler/check:ctSource", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = icmp eq ptr %t324, null
  br i1 %t326, label %bb49, label %bb50
bb48:
  br label %bb60
bb49:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb50:
  br label %bb51
bb51:
  %t328 = load ptr, ptr %l6, !tbaa !29
  %t330 = getelementptr %"compiler/check:ctSource", ptr %t328, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t334 = getelementptr %"compiler/ast:Param", ptr %t331, i32 0, i32 1
  %t335 = load i32, ptr %t334, !tbaa !23
  store i32 %t335, ptr %l182, !tbaa !23
  %t336 = load ptr, ptr %l6, !tbaa !29
  %t338 = getelementptr %"compiler/check:ctSource", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = icmp eq ptr %t339, null
  br i1 %t341, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb53:
  br label %bb54
bb54:
  %t343 = load ptr, ptr %l6, !tbaa !29
  %t345 = getelementptr %"compiler/check:ctSource", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t349 = getelementptr %"compiler/ast:Param", ptr %t346, i32 0, i32 0
  %t350 = load %"compiler/source:Span", ptr %t349
  store %"compiler/source:Span" %t350, ptr %l189
  %t352 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 0)
  store i32 %t352, ptr %l191
  br label %bb55
bb55:
  %t353 = load ptr, ptr %l6, !tbaa !29
  %t355 = getelementptr %"compiler/check:ctSource", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = icmp eq ptr %t356, null
  br i1 %t358, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb57:
  br label %bb58
bb58:
  %t360 = load ptr, ptr %l6, !tbaa !29
  %t362 = getelementptr %"compiler/check:ctSource", ptr %t360, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t366 = getelementptr %"compiler/ast:Param", ptr %t363, i32 0, i32 2
  %t367 = load ptr, ptr %t366, !tbaa !29
  %t368 = load ptr, ptr %l175, !tbaa !29
  %t369 = load i32, ptr %l182, !tbaa !23
  %t370 = load %"compiler/source:Span", ptr %l189
  %t371 = load i32, ptr %l191, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %s0, ptr %t368, i32 %t369, %"compiler/source:Span" %t370, i32 %t371, i64 0, ptr %t367)
  br label %bb59
bb59:
  br label %bb60
bb60:
  store i64 1, ptr %l20, !tbaa !24
  br label %bb61
bb61:
  %t373 = load ptr, ptr %l6, !tbaa !29
  %t375 = getelementptr %"compiler/check:ctSource", ptr %t373, i32 0, i32 2
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  store { i64, ptr } %t376, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t378 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t378, 0
  store i64 %t380, ptr %l23, !tbaa !24
  br label %bb62
bb62:
  %t382 = load i64, ptr %l22, !tbaa !24
  %t383 = load i64, ptr %l23, !tbaa !24
  %t386 = icmp slt i64 %t382, %t383
  %t388 = xor i1 %t386, true
  br i1 %t388, label %bb63, label %bb64
bb63:
  br label %bb72
bb64:
  br label %bb65
bb65:
  %t390 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t390, ptr %l207, !tbaa !27
  %t391 = load i64, ptr %l22, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr ptr, ptr %t394, i64 %t391
  %t396 = load ptr, ptr %t395, !tbaa !39
  store ptr %t396, ptr %l24, !tbaa !29
  %t398 = load i64, ptr %l20, !tbaa !24
  %t399 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t404 = icmp slt i64 %t398, %t401
  br i1 %t404, label %bb66, label %bb67
bb66:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l214, !tbaa !29
  %t407 = load ptr, ptr %l24, !tbaa !29
  %t409 = getelementptr %"compiler/ast:Param", ptr %t407, i32 0, i32 1
  %t410 = load i32, ptr %t409, !tbaa !23
  store i32 %t410, ptr %l216, !tbaa !23
  %t411 = load ptr, ptr %l24, !tbaa !29
  %t413 = getelementptr %"compiler/ast:Param", ptr %t411, i32 0, i32 0
  %t414 = load %"compiler/source:Span", ptr %t413
  store %"compiler/source:Span" %t414, ptr %l218
  %t415 = load i64, ptr %l20, !tbaa !24
  %t418 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l8, i64 %t415)
  store i32 %t418, ptr %l221
  br label %bb68
bb67:
  br label %bb70
bb68:
  %t419 = load i64, ptr %l20, !tbaa !24
  %t420 = load ptr, ptr %l24, !tbaa !29
  %t422 = getelementptr %"compiler/ast:Param", ptr %t420, i32 0, i32 2
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t424 = load ptr, ptr %l214, !tbaa !29
  %t425 = load i32, ptr %l216, !tbaa !23
  %t426 = load %"compiler/source:Span", ptr %l218
  %t427 = load i32, ptr %l221, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %s0, ptr %t424, i32 %t425, %"compiler/source:Span" %t426, i32 %t427, i64 %t419, ptr %t423)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t430 = load i64, ptr %l20, !tbaa !24
  %t432 = add i64 %t430, 1
  store i64 %t432, ptr %l20, !tbaa !24
  br label %bb71
bb71:
  %t434 = load i64, ptr %l22, !tbaa !24
  %t436 = add i64 %t434, 1
  store i64 %t436, ptr %l22, !tbaa !24
  br label %bb62
bb72:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t438)
  store ptr %t440, ptr %l230
  br label %bb73
bb73:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t445 = load i32, ptr %l17, !tbaa !23
  %t448 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t444, i32 %t445)
  store { i64, ptr } %t448, ptr %l234
  br label %bb74
bb74:
  %t449 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t449, 0
  %t451 = extractvalue { i64, ptr } %t449, 1
  %t452 = mul i64 %t450, 8
  %t453 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t452)
  call void @llvm.memcpy.p0.p0.i64(ptr %t453, ptr %t451, i64 %t452, i1 false)
  %t454 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  %t456 = load ptr, ptr %l230, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t456, { i64, ptr } %t455)
  br label %bb75
bb75:
  %t458 = load ptr, ptr %l19, !tbaa !29
  store ptr %t458, ptr %l236, !tbaa !29
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/check:Checker", ptr %t459, i32 0, i32 37
  %t463 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t461)
  store i64 %t463, ptr %l239
  br label %bb76
bb76:
  %t464 = load i64, ptr %l239, !tbaa !24
  %t465 = load ptr, ptr %l236, !tbaa !29
  %t466 = getelementptr %"compiler/check:frame", ptr %t465, i32 0, i32 56
  store i64 %t464, ptr %t466, !tbaa !24
  %t467 = load i64, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t467, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i1
  %l56 = alloca { i64, ptr }
  %l66 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca ptr
  %l92 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca %"compiler/generic:Context"
  %l108 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t181 = alloca %"compiler/generic:Context", align 8
  %t248 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i32, ptr %l5, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %t5, %"compiler/source:Span" %t6, i64 %t7, i32 %t8)
  store ptr %t13, ptr %l23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l23, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l27
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l27, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  br i1 %a4, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l7, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = sub i64 %t36, 1
  store i64 %t38, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  %t40 = load i64, ptr %l3, !tbaa !24
  store i64 %t40, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t42 = load i64, ptr %l34, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Sig", ptr %t46, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp eq i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l43, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t72 = icmp sge i64 %t60, %t69
  store i1 %t72, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l46, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Func", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Sig", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l56, !tbaa !27
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr ptr, ptr %t85, i64 %t82
  %t87 = load ptr, ptr %t86, !tbaa !39
  %t89 = getelementptr %"compiler/ast:Param", ptr %t87, i32 0, i32 3
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  store i1 %t92, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Sig", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Func", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Sig", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l66, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t117 = load i64, ptr %l66, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l71, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l72
  %t120 = load i64, ptr %l9, !tbaa !24
  store i64 %t120, ptr %l73, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp eq i64 %t121, 1
  br i1 %t123, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l76, !tbaa !27
  br label %bb28
bb28:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 %t126, { i64, ptr } %t127, i64 %t125)
  store %"compiler/msgs:Msg" %t129, ptr %l78
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l71, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l72
  %t132 = load %"compiler/msgs:Msg", ptr %l78
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l79
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l82
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t139 = load ptr, ptr %l82, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb32:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t144 = load i64, ptr %l2, !tbaa !24
  %t147 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t143, i64 %t144)
  store i64 %t147, ptr %l86
  br label %bb33
bb33:
  %t148 = load i64, ptr %l86, !tbaa !24
  store i64 %t148, ptr %l10, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t149)
  store ptr %t151, ptr %l88
  br label %bb34
bb34:
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 2
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l11, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t157)
  store ptr %t159, ptr %l92
  br label %bb35
bb35:
  %t160 = load ptr, ptr %l92, !tbaa !29
  store ptr %t160, ptr %l12, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t167 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t161, i64 %t165, i64 %t166, i32 %t167, i32 0)
  store ptr %t172, ptr %l98
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l98, !tbaa !29
  store ptr %t173, ptr %l13, !tbaa !29
  %t174 = load ptr, ptr %l13, !tbaa !29
  store ptr %t174, ptr %l99, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %t181, ptr %v0, ptr %v0, ptr %t178, i64 %t179, i32 %a6)
  call void @llvm.memmove.p0.p0.i64(ptr %l104, ptr %t181, i64 160, i1 false)
  br label %bb37
bb37:
  %t185 = load ptr, ptr %l99, !tbaa !29
  %t186 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %l104, i64 160, i1 false)
  %t187 = load ptr, ptr %l13, !tbaa !29
  %t188 = load ptr, ptr %l12, !tbaa !29
  %t190 = getelementptr %"compiler/check:frame", ptr %t188, i32 0, i32 7
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = getelementptr %"compiler/check:frame", ptr %t187, i32 0, i32 7
  store i64 %t191, ptr %t194, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l108, !tbaa !29
  %t196 = load ptr, ptr %l7, !tbaa !29
  %t198 = getelementptr %"compiler/ast:Func", ptr %t196, i32 0, i32 3
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/ast:Sig", ptr %t199, i32 0, i32 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  store { i64, ptr } %t202, ptr %l111, !tbaa !27
  %t203 = load i64, ptr %l8, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr ptr, ptr %t206, i64 %t203
  %t208 = load ptr, ptr %t207, !tbaa !39
  %t210 = getelementptr %"compiler/ast:Param", ptr %t208, i32 0, i32 3
  %t211 = load ptr, ptr %t210, !tbaa !29
  store ptr %t211, ptr %l14, !tbaa !29
  %t213 = load ptr, ptr %l14, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_573d6efe4eadca3f_fa49b5af8bd78213)
  unreachable
bb39:
  br label %bb40
bb40:
  %t217 = load ptr, ptr %l14, !tbaa !29
  %t218 = load i32, ptr %l5, !tbaa !23
  %t219 = load ptr, ptr %l108, !tbaa !29
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v1, ptr %t219, ptr %t217, i32 %t218)
  store ptr %t222, ptr %l119
  br label %bb41
bb41:
  %t223 = load ptr, ptr %l119, !tbaa !29
  store ptr %t223, ptr %l15, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %t224, ptr %t225)
  br label %bb42
bb42:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t229)
  store ptr %t231, ptr %l124
  br label %bb43
bb43:
  %t232 = load ptr, ptr %l124, !tbaa !29
  %t234 = getelementptr %"compiler/check:frame", ptr %t232, i32 0, i32 2
  %t235 = load i64, ptr %t234, !tbaa !24
  store i64 %t235, ptr %l16, !tbaa !24
  %t237 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t237)
  br label %bb44
bb44:
  %t239 = load i64, ptr %l16, !tbaa !24
  %t240 = load i64, ptr %l11, !tbaa !24
  %t243 = icmp ne i64 %t239, %t240
  br i1 %t243, label %bb45, label %bb46
bb45:
  %t245 = load %"compiler/source:Span", ptr %l1
  %t246 = load i64, ptr %l16, !tbaa !24
  %t247 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t248
  %t249 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 0
  store i64 17, ptr %t249
  %t251 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t245, 0
  %t253 = insertvalue { %"compiler/source:Span", i64, ptr } %t251, i64 %t246, 1
  %t255 = insertvalue { %"compiler/source:Span", i64, ptr } %t253, ptr %t247, 2
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t255, ptr %t256
  %t257 = load { i64, [5 x i64] }, ptr %t248
  %t259 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t257, ptr %t259
  store ptr %t259, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t261 = load ptr, ptr %l15, !tbaa !29
  store ptr %t261, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca ptr
  %l15 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t13)
  store ptr %t15, ptr %l15
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 1
  %t19 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t19, ptr %l2
  %t21 = load { i64, [2 x i64] }, ptr %l2
  %t23 = extractvalue { i64, [2 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t27 = getelementptr { i64 }, ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l26
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %l26, !tbaa !24
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t42, i64 %t43)
  store i1 %t44, ptr %l27
  br label %bb10
bb10:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb23
bb14:
  %t46 = load { i64, [2 x i64] }, ptr %l2
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6)
  unreachable
bb23:
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l30
  br label %bb24
bb24:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l4
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t53)
  store ptr %t55, ptr %l32
  br label %bb25
bb25:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb27
bb27:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l42
  br label %bb31
bb31:
  %t75 = load i32, ptr %l42, !tbaa !23
  %t78 = sext i32 %t75 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t78)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb26
bb34:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %s0, ptr %t85, i64 %t86, ptr %l4, i1 false)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %lp23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %lp37 = alloca ptr
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca { i64, ptr }
  %l51 = alloca %"compiler/msgs:Msg"
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i64
  %l92 = alloca ptr
  %l95 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca i32
  %l102 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l122 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l132 = alloca %"compiler/msgs:Msg"
  %l133 = alloca i64
  %l138 = alloca ptr
  %l142 = alloca ptr
  %l144 = alloca i32
  %l146 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l152 = alloca i32
  %l157 = alloca ptr
  %l160 = alloca i64
  %l165 = alloca i64
  %l168 = alloca i64
  %l187 = alloca ptr
  %l192 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l199 = alloca i32
  %l202 = alloca ptr
  %l204 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i32
  %l208 = alloca i32
  %l212 = alloca { i64, ptr }
  %l216 = alloca i32
  %l218 = alloca %"compiler/typed:Make"
  %l223 = alloca i64
  %l224 = alloca ptr
  %l225 = alloca %"compiler/source:Span"
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca i64
  %l230 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca i32
  %l245 = alloca ptr
  %l248 = alloca i64
  %l252 = alloca ptr
  %l253 = alloca %"compiler/source:Span"
  %l254 = alloca i32
  %l255 = alloca i32
  %l257 = alloca i64
  %l262 = alloca %"compiler/typed:Make"
  %l271 = alloca i64
  %l274 = alloca i64
  %l296 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l298 = alloca i32
  %l299 = alloca i32
  %l303 = alloca ptr
  %l304 = alloca ptr
  %l305 = alloca %"compiler/source:Span"
  %l307 = alloca i32
  %l309 = alloca ptr
  %l311 = alloca ptr
  %l312 = alloca %"compiler/source:Span"
  %l313 = alloca i32
  %l314 = alloca i32
  %l315 = alloca i64
  %l320 = alloca %"compiler/typed:Make"
  %l323 = alloca %"compiler/source:Span"
  %l324 = alloca i32
  %l328 = alloca %"compiler/typed:Cond"
  %l336 = alloca i64
  %l339 = alloca %"compiler/source:Span"
  %l340 = alloca i32
  %l344 = alloca { i64, ptr }
  %l347 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t371 = alloca { i64, [5 x i64] }, align 8
  %t480 = alloca { i64, [5 x i64] }, align 8
  %t598 = alloca { i64, [5 x i64] }, align 8
  %t622 = alloca { i64, [5 x i64] }, align 8
  %t665 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v2, ptr %t1, i32 %t2)
  store ptr %t5, ptr %l40
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l40, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t9 = getelementptr %"compiler/check:rawTable", ptr %t7, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l45, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t17, ptr %l46
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l49
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t23 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t31, ptr %l51
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l45, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l46
  %t34 = load %"compiler/msgs:Msg", ptr %l51
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33, %"compiler/msgs:Msg" %t34)
  store i64 %t35, ptr %l52
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l57
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l57, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %s0, ptr %t51, i32 %t52)
  store { i64, ptr } %t55, ptr %l62
  br label %bb10
bb10:
  %t56 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t56, ptr %l6, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb11, label %bb12
bb11:
  %t69 = load i64, ptr %l10, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb16
bb13:
  %t73 = load i64, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l8, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l72, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb15
bb15:
  %t89 = load i64, ptr %l72, !tbaa !24
  store i64 %t89, ptr %l69, !tbaa !24
  br label %bb16
bb16:
  %t90 = load i64, ptr %l69, !tbaa !24
  store i64 %t90, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb19:
  br label %bb20
bb20:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l13, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  store ptr %t114, ptr %l92, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  store ptr %t120, ptr %l95, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l3, !tbaa !23
  %t126 = load i64, ptr %l13, !tbaa !24
  %t130 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t124, i32 %t125, i64 %t126)
  store i32 %t130, ptr %l100
  br label %bb21
bb21:
  %t131 = load ptr, ptr %l95, !tbaa !29
  %t132 = load i32, ptr %l100, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t133, ptr %l101
  br label %bb22
bb22:
  %t134 = load ptr, ptr %l92, !tbaa !29
  %t135 = load i32, ptr %l101, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s3, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l102
  br label %bb23
bb23:
  %t137 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t140 = icmp sgt i64 %t138, 0
  br i1 %t140, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l105, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t143, ptr %l106
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l3, !tbaa !23
  %t148 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t144, i32 %t145)
  store { i64, ptr } %t148, ptr %l109
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t149 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l110, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t157, ptr %l112, !tbaa !27
  %t158 = load i64, ptr %l13, !tbaa !24
  %t160 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr i32, ptr %t161, i64 %t158
  %t163 = load i32, ptr %t162, !tbaa !33
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t156, i32 %t163)
  store { i64, ptr } %t166, ptr %l115
  br label %bb27
bb27:
  %t167 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t169 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromPayload(ptr %s4, ptr %v0, ptr %s4, { i64, ptr } %t167, { i64, ptr } %t168)
  store %"compiler/msgs:Msg" %t169, ptr %l116
  br label %bb28
bb28:
  %t170 = load ptr, ptr %l105, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l106
  %t172 = load %"compiler/msgs:Msg", ptr %l116
  %t173 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t170, %"compiler/source:Span" %t171, %"compiler/msgs:Msg" %t172)
  store i64 %t173, ptr %l117
  br label %bb29
bb29:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t174, { i64, ptr } %t175)
  br label %bb30
bb30:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l1
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t178, %"compiler/source:Span" %t179)
  store ptr %t182, ptr %l122
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t183 = load ptr, ptr %l122, !tbaa !29
  store ptr %t183, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l12, !tbaa !24
  br label %bb17
bb34:
  %t188 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t192 = icmp ne i64 %t190, 1
  br i1 %t192, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l128, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t195, ptr %l129
  %t196 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s6, ptr %s6, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, i64 %t198)
  store %"compiler/msgs:Msg" %t200, ptr %l132
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t201 = load ptr, ptr %l128, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l129
  %t203 = load %"compiler/msgs:Msg", ptr %l132
  %t204 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t201, %"compiler/source:Span" %t202, %"compiler/msgs:Msg" %t203)
  store i64 %t204, ptr %l133
  br label %bb38
bb38:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t205, { i64, ptr } %t206)
  br label %bb39
bb39:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t209, %"compiler/source:Span" %t210)
  store ptr %t213, ptr %l138
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l138, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
bb41:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  %t217 = load ptr, ptr %l5, !tbaa !29
  %t221 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v2, ptr %s0, ptr %t215, %"compiler/source:Span" %t216, ptr %t217, i64 0)
  store ptr %t221, ptr %l142
  br label %bb42
bb42:
  %t222 = load ptr, ptr %l142, !tbaa !29
  %t224 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t222)
  store i32 %t224, ptr %l144
  br label %bb43
bb43:
  %t225 = load i32, ptr %l144, !tbaa !23
  store i32 %t225, ptr %l14, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t227, ptr %l146, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr ptr, ptr %t229, i64 0
  %t231 = load ptr, ptr %t230, !tbaa !39
  %t232 = load i32, ptr %l14, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %t226, ptr %t231, i32 %t232)
  store ptr %t236, ptr %l149
  br label %bb44
bb44:
  %t237 = load ptr, ptr %l149, !tbaa !29
  store ptr %t237, ptr %l15, !tbaa !29
  %t238 = load ptr, ptr %l15, !tbaa !29
  %t241 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t238)
  store i32 %t241, ptr %l152
  br label %bb45
bb45:
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t243 = load i32, ptr %l152, !tbaa !23
  %t245 = icmp eq i32 %t243, %t242
  br i1 %t245, label %bb46, label %bb47
bb46:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l1
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t247, %"compiler/source:Span" %t248)
  store ptr %t251, ptr %l157
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t252 = load ptr, ptr %l157, !tbaa !29
  store ptr %t252, ptr %rv
  br label %ret
bb49:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 36
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t255)
  store i64 %t257, ptr %l160
  br label %bb50
bb50:
  %t258 = load i64, ptr %l160, !tbaa !24
  store i64 %t258, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t259 = load i64, ptr %l7, !tbaa !24
  store i64 %t259, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t261 = load i64, ptr %l18, !tbaa !24
  %t262 = load i64, ptr %l17, !tbaa !24
  %t265 = icmp sgt i64 %t261, %t262
  br i1 %t265, label %bb51, label %bb52
bb51:
  %t267 = load i64, ptr %l19, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l165, !tbaa !24
  br label %bb56
bb53:
  %t271 = load i64, ptr %l18, !tbaa !24
  %t272 = load i64, ptr %l17, !tbaa !24
  %t275 = sub i64 %t271, %t272
  %t276 = load i64, ptr %l19, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = sub i64 %t279, 1
  %t282 = load i64, ptr %l19, !tbaa !24
  %t285 = sdiv i64 %t281, %t282
  store i64 %t285, ptr %l168, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l168, !tbaa !24
  br label %bb55
bb55:
  %t287 = load i64, ptr %l168, !tbaa !24
  store i64 %t287, ptr %l165, !tbaa !24
  br label %bb56
bb56:
  %t288 = load i64, ptr %l165, !tbaa !24
  store i64 %t288, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb57
bb57:
  %t289 = load i64, ptr %l21, !tbaa !24
  %t290 = load i64, ptr %l20, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb58, label %bb59
bb58:
  br label %bb64
bb59:
  br label %bb60
bb60:
  %t297 = load i64, ptr %l17, !tbaa !24
  %t298 = load i64, ptr %l21, !tbaa !24
  %t299 = load i64, ptr %l19, !tbaa !24
  %t302 = mul i64 %t298, %t299
  %t305 = add i64 %t297, %t302
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 36
  store ptr %t309, ptr %l187, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load %"compiler/source:Span", ptr %l1
  %t312 = load ptr, ptr %l5, !tbaa !29
  %t318 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v2, ptr %v2, ptr %t310, %"compiler/source:Span" %t311, ptr %t312, i64 %t305)
  store ptr %t318, ptr %l192
  br label %bb61
bb61:
  %t319 = load ptr, ptr %l187, !tbaa !29
  %t320 = load ptr, ptr %l192, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t319, ptr %t320)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t321 = load i64, ptr %l21, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l21, !tbaa !24
  br label %bb57
bb64:
  %t325 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t325, ptr %l195
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !29
  %t331 = getelementptr %"compiler/generic:Program", ptr %t329, i32 0, i32 2
  store ptr %t331, ptr %l198, !tbaa !29
  %t332 = load i32, ptr %l14, !tbaa !23
  store i32 %t332, ptr %l199, !tbaa !23
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t335 = getelementptr %"compiler/check:Checker", ptr %t333, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = getelementptr %"compiler/generic:Program", ptr %t336, i32 0, i32 2
  store ptr %t338, ptr %l202, !tbaa !29
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t339)
  store i32 %t341, ptr %l204
  br label %bb65
bb65:
  %t342 = load i64, ptr %l7, !tbaa !24
  %t343 = load ptr, ptr %l202, !tbaa !29
  %t344 = load i32, ptr %l204, !tbaa !23
  %t346 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t343, i32 %t344, i64 %t342)
  store i32 %t346, ptr %l206
  br label %bb66
bb66:
  %t347 = load ptr, ptr %l198, !tbaa !29
  %t348 = load i32, ptr %l199, !tbaa !23
  %t349 = load i32, ptr %l206, !tbaa !23
  %t350 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t347, i32 %t348, i32 %t349)
  store i32 %t350, ptr %l207
  br label %bb67
bb67:
  store i32 2, ptr %l208
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 36
  %t354 = load i64, ptr %l16, !tbaa !24
  %t357 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t353, i64 %t354)
  store { i64, ptr } %t357, ptr %l212
  br label %bb68
bb68:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l1
  %t363 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t358, i32 1, %"compiler/source:Span" %t359)
  store i32 %t363, ptr %l216
  br label %bb69
bb69:
  %t364 = load i32, ptr %l208, !range !{i32 0, i32 5}
  %t365 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t366 = load i32, ptr %l216, !tbaa !23
  %t368 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v2, ptr %v2, i32 %t364, i64 0, { i64, ptr } %t365, ptr null, i32 %t366, i32 0, i1 false)
  store %"compiler/typed:Make" %t368, ptr %l218
  br label %bb70
bb70:
  %t369 = load %"compiler/typed:Make", ptr %l218
  %t370 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t369, ptr %t370
  store { i64, [5 x i64] } zeroinitializer, ptr %t371
  %t372 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 0
  store i64 7, ptr %t372
  %t373 = load %"compiler/source:Span", ptr %l195
  %t374 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t373, 0
  %t375 = load i32, ptr %l207, !tbaa !23
  %t376 = insertvalue { %"compiler/source:Span", i32, ptr } %t374, i32 %t375, 1
  %t378 = insertvalue { %"compiler/source:Span", i32, ptr } %t376, ptr %t370, 2
  %t379 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t378, ptr %t379
  %t380 = load { i64, [5 x i64] }, ptr %t371
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t381, ptr %lp23
  %t383 = load ptr, ptr %lp23
  store { i64, [5 x i64] } %t380, ptr %t383
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/check:Checker", ptr %t384, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %s0, ptr %s0, ptr %t387, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d9, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i64 %t389, ptr %l223
  br label %bb71
bb71:
  %t390 = load i64, ptr %l223, !tbaa !24
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l224, !tbaa !29
  %t392 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t392, ptr %l225
  %t393 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t393, ptr %l226
  store i64 %t390, ptr %l227, !tbaa !24
  %t395 = icmp sge i64 0, 0
  br i1 %t395, label %bb72, label %bb73
bb72:
  %t397 = icmp sle i64 0, 1152921504606846975
  br i1 %t397, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_2f076b8c12fc1f2b_72a0a04988c2c8b7)
  unreachable
bb74:
  %t399 = mul i64 0, 8
  %t400 = insertvalue { i64, ptr } undef, i64 0, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t401, ptr %l230, !tbaa !27
  %t402 = load ptr, ptr %l15, !tbaa !29
  %t403 = load ptr, ptr %lp23
  %t404 = mul i64 2, 8
  %t405 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t404)
  %t406 = insertvalue { i64, ptr } undef, i64 2, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  store { i64, ptr } %t407, ptr %l233, !tbaa !27
  %t409 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr ptr, ptr %t410, i64 0
  store ptr %t402, ptr %t411, !tbaa !39
  %t413 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr ptr, ptr %t414, i64 1
  store ptr %t403, ptr %t415, !tbaa !39
  %t416 = icmp sge i64 0, 0
  br i1 %t416, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_2f076b8c12fc1f2b_72a0a04988c2c8b7)
  unreachable
bb76:
  %t418 = icmp sle i64 0, 2305843009213693951
  br i1 %t418, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_8ce0cb83e6566f16_6a0b4dbe19b2f402)
  unreachable
bb78:
  %t420 = mul i64 0, 4
  %t421 = insertvalue { i64, ptr } undef, i64 0, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t423 = load ptr, ptr %l224, !tbaa !29
  %t424 = load %"compiler/source:Span", ptr %l225
  %t425 = load %"compiler/source:Span", ptr %l226
  %t426 = load i64, ptr %l227, !tbaa !24
  %t427 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t430 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %v2, ptr %t423, %"compiler/source:Span" %t424, %"compiler/source:Span" %t425, i64 %t426, ptr null, { i64, ptr } %t427, { i64, ptr } %t428, { i64, ptr } %t422)
  store ptr %t430, ptr %l237
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_8ce0cb83e6566f16_6a0b4dbe19b2f402)
  unreachable
bb80:
  %t431 = load ptr, ptr %l237, !tbaa !29
  store ptr %t431, ptr %l25, !tbaa !29
  %t432 = load ptr, ptr %l25, !tbaa !29
  %t435 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t432)
  store i32 %t435, ptr %l240
  br label %bb81
bb81:
  %t436 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t437 = load i32, ptr %l240, !tbaa !23
  %t439 = icmp eq i32 %t437, %t436
  br i1 %t439, label %bb82, label %bb83
bb82:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load %"compiler/source:Span", ptr %l1
  %t445 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t441, %"compiler/source:Span" %t442)
  store ptr %t445, ptr %l245
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_scope_close(ptr %s0)
  %t446 = load ptr, ptr %l245, !tbaa !29
  store ptr %t446, ptr %rv
  br label %ret
bb85:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 37
  %t451 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t449)
  store i64 %t451, ptr %l248
  br label %bb86
bb86:
  %t452 = load i64, ptr %l248, !tbaa !24
  store i64 %t452, ptr %l26, !tbaa !24
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load %"compiler/source:Span", ptr %l1
  %t455 = load ptr, ptr %l25, !tbaa !29
  %t459 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v2, ptr %v2, ptr %t453, %"compiler/source:Span" %t454, ptr %t455)
  store ptr %t459, ptr %l252
  br label %bb87
bb87:
  %t460 = load ptr, ptr %l252, !tbaa !29
  store ptr %t460, ptr %l27, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t461, ptr %l253
  %t462 = load i32, ptr %l3, !tbaa !23
  store i32 %t462, ptr %l254, !tbaa !23
  store i32 1, ptr %l255
  %t463 = load i64, ptr %l7, !tbaa !24
  %t465 = sub i64 %t463, 1
  store i64 %t465, ptr %l257, !tbaa !24
  %t466 = icmp sge i64 0, 0
  br i1 %t466, label %bb88, label %bb89
bb88:
  %t468 = icmp sle i64 0, 1152921504606846975
  br i1 %t468, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_83b919d2f60ab835_29fa8ffb2c40f121)
  unreachable
bb90:
  %t470 = mul i64 0, 8
  %t471 = insertvalue { i64, ptr } undef, i64 0, 0
  %t472 = insertvalue { i64, ptr } %t471, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t473 = load i32, ptr %l255, !range !{i32 0, i32 5}
  %t474 = load i64, ptr %l257, !tbaa !24
  %t477 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t473, i64 %t474, { i64, ptr } %t472, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t477, ptr %l262
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_83b919d2f60ab835_29fa8ffb2c40f121)
  unreachable
bb92:
  %t478 = load %"compiler/typed:Make", ptr %l262
  %t479 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t478, ptr %t479
  store { i64, [5 x i64] } zeroinitializer, ptr %t480
  %t481 = getelementptr { i64, [5 x i64] }, ptr %t480, i32 0, i32 0
  store i64 7, ptr %t481
  %t482 = load %"compiler/source:Span", ptr %l253
  %t483 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t482, 0
  %t484 = load i32, ptr %l254, !tbaa !23
  %t485 = insertvalue { %"compiler/source:Span", i32, ptr } %t483, i32 %t484, 1
  %t487 = insertvalue { %"compiler/source:Span", i32, ptr } %t485, ptr %t479, 2
  %t488 = getelementptr { i64, [5 x i64] }, ptr %t480, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t487, ptr %t488
  %t489 = load { i64, [5 x i64] }, ptr %t480
  %t491 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t489, ptr %t491
  store ptr %t491, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  %t493 = load i64, ptr %l7, !tbaa !24
  %t495 = sub i64 %t493, 1
  store i64 %t495, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t497 = load i64, ptr %l30, !tbaa !24
  %t498 = load i64, ptr %l29, !tbaa !24
  %t501 = icmp sgt i64 %t497, %t498
  br i1 %t501, label %bb93, label %bb94
bb93:
  %t503 = load i64, ptr %l31, !tbaa !24
  %t505 = icmp sgt i64 %t503, 0
  br i1 %t505, label %bb95, label %bb96
bb94:
  store i64 0, ptr %l271, !tbaa !24
  br label %bb98
bb95:
  %t507 = load i64, ptr %l30, !tbaa !24
  %t508 = load i64, ptr %l29, !tbaa !24
  %t511 = sub i64 %t507, %t508
  %t512 = load i64, ptr %l31, !tbaa !24
  %t515 = add i64 %t511, %t512
  %t517 = sub i64 %t515, 1
  %t518 = load i64, ptr %l31, !tbaa !24
  %t521 = sdiv i64 %t517, %t518
  store i64 %t521, ptr %l274, !tbaa !24
  br label %bb97
bb96:
  store i64 0, ptr %l274, !tbaa !24
  br label %bb97
bb97:
  %t523 = load i64, ptr %l274, !tbaa !24
  store i64 %t523, ptr %l271, !tbaa !24
  br label %bb98
bb98:
  %t524 = load i64, ptr %l271, !tbaa !24
  store i64 %t524, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb99
bb99:
  %t525 = load i64, ptr %l33, !tbaa !24
  %t526 = load i64, ptr %l32, !tbaa !24
  %t529 = icmp slt i64 %t525, %t526
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb100, label %bb101
bb100:
  br label %bb114
bb101:
  br label %bb102
bb102:
  %t533 = load i64, ptr %l29, !tbaa !24
  %t534 = load i64, ptr %l33, !tbaa !24
  %t535 = load i64, ptr %l31, !tbaa !24
  %t538 = mul i64 %t534, %t535
  %t541 = add i64 %t533, %t538
  %t543 = load i64, ptr %l7, !tbaa !24
  %t545 = sub i64 %t543, 2
  %t549 = sub i64 %t545, %t541
  store i64 %t549, ptr %l35, !tbaa !24
  %t551 = load ptr, ptr %l0, !tbaa !29
  store ptr %t551, ptr %l296, !tbaa !29
  %t552 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t552, ptr %l297
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t553, ptr %l298, !tbaa !23
  store i32 13, ptr %l299
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t555 = load %"compiler/source:Span", ptr %l1
  %t556 = load ptr, ptr %l27, !tbaa !29
  %t560 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v2, ptr %v2, ptr %t554, %"compiler/source:Span" %t555, ptr %t556)
  store ptr %t560, ptr %l303
  br label %bb103
bb103:
  %t561 = load ptr, ptr %l0, !tbaa !29
  store ptr %t561, ptr %l304, !tbaa !29
  %t562 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t562, ptr %l305
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t563)
  store i32 %t565, ptr %l307
  br label %bb104
bb104:
  %t566 = load i64, ptr %l35, !tbaa !24
  %t567 = load ptr, ptr %l304, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l305
  %t569 = load i32, ptr %l307, !tbaa !23
  %t571 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t567, %"compiler/source:Span" %t568, i32 %t569, i64 %t566)
  store ptr %t571, ptr %l309
  br label %bb105
bb105:
  %t572 = load ptr, ptr %l309, !tbaa !29
  %t573 = load ptr, ptr %l296, !tbaa !29
  %t574 = load %"compiler/source:Span", ptr %l297
  %t575 = load i32, ptr %l298, !tbaa !23
  %t576 = load i32, ptr %l299, !range !{i32 0, i32 44}
  %t577 = load ptr, ptr %l303, !tbaa !29
  %t579 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v2, ptr %v0, ptr %v2, ptr %t573, %"compiler/source:Span" %t574, i32 %t575, i32 %t576, ptr %t577, ptr %t572)
  store ptr %t579, ptr %l311
  br label %bb106
bb106:
  %t580 = load ptr, ptr %l311, !tbaa !29
  store ptr %t580, ptr %l36, !tbaa !29
  %t581 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t581, ptr %l312
  %t582 = load i32, ptr %l3, !tbaa !23
  store i32 %t582, ptr %l313, !tbaa !23
  store i32 1, ptr %l314
  %t583 = load i64, ptr %l35, !tbaa !24
  store i64 %t583, ptr %l315, !tbaa !24
  %t584 = icmp sge i64 0, 0
  br i1 %t584, label %bb107, label %bb108
bb107:
  %t586 = icmp sle i64 0, 1152921504606846975
  br i1 %t586, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_ace0e8d6a1b00ac8_e6e4f855bb613414)
  unreachable
bb109:
  %t588 = mul i64 0, 8
  %t589 = insertvalue { i64, ptr } undef, i64 0, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t591 = load i32, ptr %l314, !range !{i32 0, i32 5}
  %t592 = load i64, ptr %l315, !tbaa !24
  %t595 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v2, ptr %v2, ptr %v2, i32 %t591, i64 %t592, { i64, ptr } %t590, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t595, ptr %l320
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_ace0e8d6a1b00ac8_e6e4f855bb613414)
  unreachable
bb111:
  %t596 = load %"compiler/typed:Make", ptr %l320
  %t597 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 56, i64 8)
  store %"compiler/typed:Make" %t596, ptr %t597
  store { i64, [5 x i64] } zeroinitializer, ptr %t598
  %t599 = getelementptr { i64, [5 x i64] }, ptr %t598, i32 0, i32 0
  store i64 7, ptr %t599
  %t600 = load %"compiler/source:Span", ptr %l312
  %t601 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t600, 0
  %t602 = load i32, ptr %l313, !tbaa !23
  %t603 = insertvalue { %"compiler/source:Span", i32, ptr } %t601, i32 %t602, 1
  %t605 = insertvalue { %"compiler/source:Span", i32, ptr } %t603, ptr %t597, 2
  %t606 = getelementptr { i64, [5 x i64] }, ptr %t598, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t605, ptr %t606
  %t607 = load { i64, [5 x i64] }, ptr %t598
  %t608 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t608, ptr %lp37
  %t610 = load ptr, ptr %lp37
  store { i64, [5 x i64] } %t607, ptr %t610
  %t611 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t611, ptr %l323
  %t612 = load i32, ptr %l3, !tbaa !23
  store i32 %t612, ptr %l324, !tbaa !23
  %t613 = load ptr, ptr %l36, !tbaa !29
  %t614 = load ptr, ptr %lp37
  %t615 = load ptr, ptr %l28, !tbaa !29
  %t619 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %t613, ptr %t614, ptr %t615)
  store %"compiler/typed:Cond" %t619, ptr %l328
  br label %bb112
bb112:
  %t620 = load %"compiler/typed:Cond", ptr %l328
  %t621 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Cond" %t620, ptr %t621
  store { i64, [5 x i64] } zeroinitializer, ptr %t622
  %t623 = getelementptr { i64, [5 x i64] }, ptr %t622, i32 0, i32 0
  store i64 11, ptr %t623
  %t624 = load %"compiler/source:Span", ptr %l323
  %t625 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t624, 0
  %t626 = load i32, ptr %l324, !tbaa !23
  %t627 = insertvalue { %"compiler/source:Span", i32, ptr } %t625, i32 %t626, 1
  %t629 = insertvalue { %"compiler/source:Span", i32, ptr } %t627, ptr %t621, 2
  %t630 = getelementptr { i64, [5 x i64] }, ptr %t622, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t629, ptr %t630
  %t631 = load { i64, [5 x i64] }, ptr %t622
  %t633 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t631, ptr %t633
  store ptr %t633, ptr %l28, !tbaa !29
  br label %bb113
bb113:
  %t635 = load i64, ptr %l33, !tbaa !24
  %t637 = add i64 %t635, 1
  store i64 %t637, ptr %l33, !tbaa !24
  br label %bb99
bb114:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/check:Checker", ptr %t639, i32 0, i32 37
  %t643 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t641)
  store i64 %t643, ptr %l336
  br label %bb115
bb115:
  %t644 = load i64, ptr %l26, !tbaa !24
  %t645 = load i64, ptr %l336, !tbaa !24
  %t647 = icmp sgt i64 %t645, %t644
  br i1 %t647, label %bb116, label %bb117
bb116:
  %t649 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t649, ptr %l339
  %t650 = load i32, ptr %l3, !tbaa !23
  store i32 %t650, ptr %l340, !tbaa !23
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t653 = getelementptr %"compiler/check:Checker", ptr %t651, i32 0, i32 37
  %t654 = load i64, ptr %l26, !tbaa !24
  %t657 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t653, i64 %t654)
  store { i64, ptr } %t657, ptr %l344
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t658 = load ptr, ptr %l28, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t662 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v2, ptr %v2, { i64, ptr } %t660, ptr %t658, i1 false)
  store %"compiler/typed:Seq" %t662, ptr %l347
  br label %bb119
bb119:
  %t663 = load %"compiler/typed:Seq", ptr %l347
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Seq" %t663, ptr %t664
  store { i64, [5 x i64] } zeroinitializer, ptr %t665
  %t666 = getelementptr { i64, [5 x i64] }, ptr %t665, i32 0, i32 0
  store i64 12, ptr %t666
  %t667 = load %"compiler/source:Span", ptr %l339
  %t668 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t667, 0
  %t669 = load i32, ptr %l340, !tbaa !23
  %t670 = insertvalue { %"compiler/source:Span", i32, ptr } %t668, i32 %t669, 1
  %t672 = insertvalue { %"compiler/source:Span", i32, ptr } %t670, ptr %t664, 2
  %t673 = getelementptr { i64, [5 x i64] }, ptr %t665, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t672, ptr %t673
  %t674 = load { i64, [5 x i64] }, ptr %t665
  %t676 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t674, ptr %t676
  call void @__olang_scope_close(ptr %s0)
  store ptr %t676, ptr %rv
  br label %ret
bb120:
  %t678 = load ptr, ptr %l28, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t678, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i32
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load i64, ptr %t13
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp ne i64 %t16, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_e5613677a6448c92_7fd725fb7345b22e)
  unreachable
bb11:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l15
  br label %bb12
bb12:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  br i1 %t26, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i32 %t33, ptr %l20
  br label %bb16
bb16:
  %t34 = load i32, ptr %l20, !tbaa !23
  store i32 %t34, ptr %l4, !tbaa !23
  %t35 = load i32, ptr %l4, !tbaa !23
  %t37 = icmp ne i32 %t35, 0
  br i1 %t37, label %bb17, label %bb18
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l24, !tbaa !29
  %t40 = load i32, ptr %l4, !tbaa !23
  store i32 %t40, ptr %l25, !tbaa !23
  %t41 = icmp sge i64 1, 0
  br i1 %t41, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb24
bb19:
  %t43 = icmp sle i64 1, 2305843009213693951
  br i1 %t43, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ce46ad7b25b964bc_d75d3b27057ac3b0)
  unreachable
bb21:
  %t45 = mul i64 1, 4
  %t46 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t45)
  %t47 = load i32, ptr %l25, !tbaa !23
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, 1
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr i32, ptr %t46, i64 %t52
  store i32 %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 1, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  %t58 = load ptr, ptr %l24, !tbaa !29
  %t60 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s0, ptr %t58, { i64, ptr } %t57)
  store i1 %t60, ptr %l29
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ce46ad7b25b964bc_d75d3b27057ac3b0)
  unreachable
bb23:
  %t61 = load i1, ptr %l29, !tbaa !21
  store i1 %t61, ptr %l23, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load i1, ptr %l23, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrPinned(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l9 = alloca i32
  %l17 = alloca ptr
  %l20 = alloca i32
  %l29 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l49 = alloca %"compiler/source:Span"
  %l53 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l69 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  %t144 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/ast:Match", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t13, ptr %t17, i32 %t19)
  store ptr %t23, ptr %l17
  br label %bb5
bb5:
  %t24 = load ptr, ptr %l17, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t28 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t25)
  store i32 %t28, ptr %l20
  br label %bb6
bb6:
  %t29 = load i32, ptr %l20, !tbaa !23
  store i32 %t29, ptr %l3, !tbaa !23
  %t30 = load i32, ptr %l3, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l29
  br label %bb10
bb10:
  %t47 = load i1, ptr %l29, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Match", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t54)
  store %"compiler/source:Span" %t56, ptr %l34
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Match", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t61)
  store %"compiler/source:Span" %t63, ptr %l38
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l35, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l38
  %t66 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t64, %"compiler/source:Span" %t65)
  store { i64, ptr } %t66, ptr %l39
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t67, i32 %t68)
  store { i64, ptr } %t71, ptr %l42
  br label %bb16
bb16:
  %t72 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t81 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrMatchNotError(ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t79, { i64, ptr } %t78)
  store %"compiler/msgs:Msg" %t81, ptr %l44
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l31, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l34
  %t84 = load %"compiler/msgs:Msg", ptr %l44
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t82, %"compiler/source:Span" %t83, %"compiler/msgs:Msg" %t84)
  store i64 %t85, ptr %l45
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb19:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Match", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t90)
  store %"compiler/source:Span" %t92, ptr %l49
  br label %bb20
bb20:
  %t93 = load %"compiler/source:Span", ptr %l49
  store %"compiler/source:Span" %t93, ptr %l4
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load %"compiler/source:Span", ptr %l4
  %t96 = load i32, ptr %l3, !tbaa !23
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t94, %"compiler/source:Span" %t95, i32 %t96)
  store i64 %t100, ptr %l53
  br label %bb21
bb21:
  %t101 = load i64, ptr %l53, !tbaa !24
  store i64 %t101, ptr %l5, !tbaa !24
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t102)
  store ptr %t104, ptr %l55
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l55, !tbaa !29
  %t106 = load %"compiler/source:Span", ptr %l4
  %t109 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 60
  store %"compiler/source:Span" %t106, ptr %t109
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t110)
  store ptr %t112, ptr %l59
  br label %bb23
bb23:
  %t113 = load ptr, ptr %l59, !tbaa !29
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 61
  store i64 %t114, ptr %t117, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t118)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %l64, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/ast:Match", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t127 = load ptr, ptr %l2, !tbaa !29
  %t131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNonNull(ptr %v0, ptr %v1, ptr %v0, ptr %t122, ptr %t126, ptr %t127)
  store i1 %t131, ptr %l69
  br label %bb25
bb25:
  %t132 = load i1, ptr %l69, !tbaa !21
  %t133 = load ptr, ptr %l64, !tbaa !29
  %t134 = getelementptr %"compiler/check:frame", ptr %t133, i32 0, i32 62
  store i1 %t132, ptr %t134, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 37
  %t138 = load %"compiler/source:Span", ptr %l4
  %t139 = load i64, ptr %l5, !tbaa !24
  %t141 = trunc i64 %t139 to i32
  %t143 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t138, 0
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, i32 %t141, 1
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, ptr %t143, 2
  %t152 = getelementptr { i64, [3 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t151, ptr %t152
  %t153 = load { i64, [3 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t153, ptr %t155
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t137, ptr %t155)
  br label %bb26
bb26:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca %"compiler/msgs:Msg"
  %l41 = alloca i64
  %l44 = alloca ptr
  %l49 = alloca i1
  %l51 = alloca i1
  %l56 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l99 = alloca i32
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l109 = alloca ptr
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l119 = alloca i32
  %l125 = alloca ptr
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l6, !tbaa !23
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t6)
  store i32 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i32, ptr %l15, !tbaa !23
  store i32 %t10, ptr %l7, !tbaa !23
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t13 = trunc i64 78 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t20 = trunc i64 79 to i32
  %t21 = icmp eq i32 %t18, %t20
  %t23 = xor i1 %t21, true
  store i1 %t23, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l23, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t27, ptr %l24
  %t28 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t30 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s1, i32 %t28)
  store { i64, ptr } %t30, ptr %l26
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t31 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t32 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s1, ptr %s1, { i64, ptr } %t31)
  store { i64, ptr } %t32, ptr %l27
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  %t35 = extractvalue { i64, ptr } %t33, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l29, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l34
  br label %bb10
bb10:
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t52 = load i32, ptr %l6, !tbaa !23
  store i32 %t52, ptr %l35, !tbaa !23
  br label %bb13
bb12:
  %t54 = load i32, ptr %l7, !tbaa !23
  store i32 %t54, ptr %l35, !tbaa !23
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load i32, ptr %l35, !tbaa !23
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t56, i32 %t57)
  store { i64, ptr } %t58, ptr %l38
  br label %bb14
bb14:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t68 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t66, { i64, ptr } %t65)
  store %"compiler/msgs:Msg" %t68, ptr %l40
  br label %bb15
bb15:
  %t69 = load ptr, ptr %l23, !tbaa !29
  %t70 = load %"compiler/source:Span", ptr %l24
  %t71 = load %"compiler/msgs:Msg", ptr %l40
  %t72 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t69, %"compiler/source:Span" %t70, %"compiler/msgs:Msg" %t71)
  store i64 %t72, ptr %l41
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t73, %"compiler/source:Span" %t74)
  store ptr %t77, ptr %l44
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t78 = load ptr, ptr %l44, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb18:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l6, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l49
  br label %bb19
bb19:
  %t89 = load i1, ptr %l49, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb23
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %l7, !tbaa !23
  %t101 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l56
  br label %bb22
bb22:
  %t102 = load i1, ptr %l56, !tbaa !21
  %t103 = xor i1 %t102, true
  store i1 %t103, ptr %l51, !tbaa !21
  br label %bb23
bb23:
  %t105 = load i1, ptr %l51, !tbaa !21
  br i1 %t105, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s2
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 2
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l62
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t116 = load i1, ptr %l62, !tbaa !21
  br i1 %t116, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l4, !tbaa !29
  store ptr %t117, ptr %l63, !tbaa !29
  br label %bb29
bb28:
  %t119 = load ptr, ptr %l5, !tbaa !29
  store ptr %t119, ptr %l63, !tbaa !29
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l66, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l67
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l68, !tbaa !29
  %t126 = load ptr, ptr @__olang_prog_scope
  %t128 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %t126, ptr %t121)
  store %"compiler/source:Span" %t128, ptr %l70
  br label %bb30
bb30:
  %t129 = load ptr, ptr %l68, !tbaa !29
  %t130 = load %"compiler/source:Span", ptr %l70
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s2, ptr %t129, %"compiler/source:Span" %t130)
  store { i64, ptr } %t131, ptr %l71
  br label %bb31
bb31:
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t134 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t132, i64 %t133)
  %t142 = getelementptr i8, ptr %t141, i64 %t133
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  call void @olang_textcopy(ptr %t143, ptr %t138, i64 %t139)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t141, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = extractvalue { i64, ptr } %t145, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %s2, ptr %s2, { i64, ptr } %t152)
  store %"compiler/msgs:Msg" %t154, ptr %l74
  br label %bb32
bb32:
  %t155 = load ptr, ptr %l66, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l67
  %t157 = load %"compiler/msgs:Msg", ptr %l74
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l75
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t161 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t159, %"compiler/source:Span" %t160, i32 %t161, i64 0)
  store ptr %t165, ptr %l79
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  %t166 = load ptr, ptr %l79, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb35:
  %t167 = load i32, ptr %l6, !tbaa !23
  %t168 = load i32, ptr %l7, !tbaa !23
  %t171 = icmp ne i32 %t167, %t168
  br i1 %t171, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l84, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l85, !tbaa !29
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l86, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l6, !tbaa !23
  %t188 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t184, i32 %t185)
  store i32 %t188, ptr %l91
  br label %bb38
bb37:
  br label %bb47
bb38:
  %t189 = load ptr, ptr %l86, !tbaa !29
  %t190 = load i32, ptr %l91, !tbaa !23
  %t191 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t189, i32 %t190)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t191, ptr %l92
  br label %bb39
bb39:
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %t193
  store ptr %t193, ptr %l93, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l94, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/generic:Program", ptr %t198, i32 0, i32 2
  %t201 = load i32, ptr %l7, !tbaa !23
  %t204 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t200, i32 %t201)
  store i32 %t204, ptr %l99
  br label %bb40
bb40:
  %t205 = load ptr, ptr %l94, !tbaa !29
  %t206 = load i32, ptr %l99, !tbaa !23
  %t207 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s4, ptr %t205, i32 %t206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %l100
  br label %bb41
bb41:
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t209 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %t209
  %t210 = load ptr, ptr %l85, !tbaa !29
  %t211 = load ptr, ptr %l93, !tbaa !29
  %t213 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s4, ptr %s4, ptr %s4, ptr %t210, ptr %t211, ptr %t209)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l102
  br label %bb42
bb42:
  %t214 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  %t215 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %t215
  %t217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %s4, ptr %t215)
  store { i64, ptr } %t217, ptr %l104
  br label %bb43
bb43:
  %t218 = load ptr, ptr %l84, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t220 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %s4, ptr %t218, { i64, ptr } %t219)
  store i32 %t220, ptr %l105
  br label %bb44
bb44:
  %t221 = load i32, ptr %l105, !tbaa !23
  store i32 %t221, ptr %l9, !tbaa !23
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t224 = load i32, ptr %l9, !tbaa !23
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v1, ptr %t222, ptr %t223, i32 %t224)
  store ptr %t228, ptr %l109
  br label %bb45
bb45:
  %t229 = load ptr, ptr %l109, !tbaa !29
  store ptr %t229, ptr %l4, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l5, !tbaa !29
  %t232 = load i32, ptr %l9, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v2, ptr %v2, ptr %t230, ptr %t231, i32 %t232)
  store ptr %t236, ptr %l113
  br label %bb46
bb46:
  %t237 = load ptr, ptr %l113, !tbaa !29
  store ptr %t237, ptr %l5, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l114, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t239, ptr %l115
  %t240 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t240, ptr %l116, !tbaa !23
  %t241 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t243 = trunc i64 78 to i32
  %t244 = icmp eq i32 %t241, %t243
  br i1 %t244, label %bb48, label %bb49
bb48:
  store i32 13, ptr %l119
  br label %bb50
bb49:
  store i32 14, ptr %l119
  br label %bb50
bb50:
  %t248 = load ptr, ptr %l4, !tbaa !29
  %t249 = load ptr, ptr %l5, !tbaa !29
  %t251 = load ptr, ptr %l114, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l115
  %t253 = load i32, ptr %l116, !tbaa !23
  %t254 = load i32, ptr %l119, !range !{i32 0, i32 44}
  %t257 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t251, %"compiler/source:Span" %t252, i32 %t253, i32 %t254, ptr %t248, ptr %t249)
  store ptr %t257, ptr %l125
  br label %bb51
bb51:
  %t258 = load ptr, ptr %l125, !tbaa !29
  store ptr %t258, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14, !range !{i32 0, i32 33}
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l17, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l48 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l83 = alloca { i64, ptr }
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i32
  %l108 = alloca i1
  %l111 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l120 = alloca i1
  %l125 = alloca i32
  %l128 = alloca i1
  %l131 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i64
  %l152 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, [3 x i64] }
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l178 = alloca i32
  %l182 = alloca i1
  %l186 = alloca i1
  %l190 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/source:Span"
  %l217 = alloca i64
  %l220 = alloca { i64, ptr }
  %l227 = alloca %"compiler/source:Span"
  %l230 = alloca { i64, [3 x i64] }
  %l233 = alloca { i64, ptr }
  %l235 = alloca %"compiler/msgs:Msg"
  %l236 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t318 = alloca { i64, [3 x i64] }, align 8
  %t472 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l20, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l24, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l28
  br label %bb3
bb3:
  %t27 = load i32, ptr %l28, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l31, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l36
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t45 = load i32, ptr %l36, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l37
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l41
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t57, ptr %l42
  br label %bb7
bb7:
  %t58 = load i1, ptr %l42, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 10
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l48
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l48, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb9, label %bb10
bb9:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t114 = load i64, ptr %l58, !tbaa !24
  store i64 %t114, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb17:
  br label %bb18
bb18:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp sge i64 %t133, %t136
  br i1 %t139, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb20:
  br label %bb21
bb21:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l83, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l14, !tbaa !23
  %t149 = load i32, ptr %l14, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l92
  br label %bb24
bb24:
  %t160 = load i1, ptr %l92, !tbaa !21
  store i1 %t160, ptr %l89, !tbaa !21
  br label %bb25
bb25:
  %t161 = load i1, ptr %l89, !tbaa !21
  br i1 %t161, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb27:
  br label %bb28
bb28:
  %t162 = load i1, ptr %l6, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l98
  br label %bb31
bb30:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb32
bb31:
  %t171 = load i1, ptr %l98, !tbaa !21
  store i1 %t171, ptr %l95, !tbaa !21
  br label %bb32
bb32:
  %t172 = load i1, ptr %l95, !tbaa !21
  br i1 %t172, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t173 = load i1, ptr %l6, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l14, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l105
  br label %bb38
bb37:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t185 = load i32, ptr %l105, !range !{i32 0, i32 33}
  %t187 = trunc i64 21 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l100, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l111, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l14, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l116
  br label %bb42
bb41:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb44
bb42:
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = load i32, ptr %l116, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l117
  br label %bb43
bb43:
  %t210 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l108, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l125
  br label %bb47
bb46:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb48
bb47:
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t227 = load i32, ptr %l125, !tbaa !23
  %t229 = icmp eq i32 %t227, %t226
  store i1 %t229, ptr %l120, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l120, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l131, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l14, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l136
  br label %bb51
bb50:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb53
bb51:
  %t248 = load ptr, ptr %l131, !tbaa !29
  %t249 = load i32, ptr %l136, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s2, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l137
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l128, !tbaa !21
  br label %bb53
bb53:
  %t256 = load i1, ptr %l128, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 3
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Sig", ptr %t260, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l142, !tbaa !27
  %t264 = load i64, ptr %l13, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t271 = getelementptr %"compiler/ast:Param", ptr %t269, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l15
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l149, !tbaa !29
  %t284 = load i64, ptr %l7, !tbaa !24
  store i64 %t284, ptr %l150, !tbaa !24
  %t285 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t286 = load i32, ptr %t285, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l152, !tbaa !24
  %t289 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  store i64 %t292, ptr %l154, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Func", ptr %t294, i32 0, i32 3
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Sig", ptr %t297, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l158, !tbaa !27
  %t301 = load i64, ptr %l13, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t308 = getelementptr %"compiler/ast:Param", ptr %t306, i32 0, i32 1
  %t309 = load i32, ptr %t308, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t293, i32 %t309)
  store { i64, ptr } %t312, ptr %l162
  br label %bb57
bb57:
  %t313 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t315 = load i64, ptr %l154, !tbaa !24
  %t317 = add i64 %t315, %t314
  store { i64, [3 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 0
  store i64 3, ptr %t319
  %t320 = load i64, ptr %l150, !tbaa !24
  %t321 = insertvalue { i64, i64, i64 } undef, i64 %t320, 0
  %t322 = load i64, ptr %l152, !tbaa !24
  %t323 = insertvalue { i64, i64, i64 } %t321, i64 %t322, 1
  %t325 = insertvalue { i64, i64, i64 } %t323, i64 %t317, 2
  %t326 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  store { i64, i64, i64 } %t325, ptr %t326
  %t327 = load { i64, [3 x i64] }, ptr %t318
  store { i64, [3 x i64] } %t327, ptr %l165
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l14, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t328, i32 %t329)
  store { i64, ptr } %t332, ptr %l168
  br label %bb58
bb58:
  %t333 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  %t335 = extractvalue { i64, ptr } %t333, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  %t341 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %s2, ptr %s2, { i64, ptr } %t339)
  store %"compiler/msgs:Msg" %t341, ptr %l170
  br label %bb59
bb59:
  %t342 = load ptr, ptr %l149, !tbaa !29
  %t343 = load { i64, [3 x i64] }, ptr %l165
  %t344 = load %"compiler/msgs:Msg", ptr %l170
  %t345 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t342, { i64, [3 x i64] } %t343, %"compiler/msgs:Msg" %t344)
  store i64 %t345, ptr %l171
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t346 = load i64, ptr %l12, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l12, !tbaa !24
  br label %bb15
bb62:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = load i32, ptr %l4, !tbaa !23
  %t359 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t359, ptr %l178
  br label %bb63
bb63:
  %t360 = load i32, ptr %l178, !tbaa !23
  store i32 %t360, ptr %l16, !tbaa !23
  %t361 = load i32, ptr %l16, !tbaa !23
  %t362 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t365 = icmp eq i32 %t361, %t362
  br i1 %t365, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb66
bb65:
  %t367 = load i32, ptr %l16, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t371 = icmp eq i32 %t367, %t368
  store i1 %t371, ptr %l182, !tbaa !21
  br label %bb66
bb66:
  %t373 = load i1, ptr %l182, !tbaa !21
  br i1 %t373, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb69
bb68:
  %t374 = load i32, ptr %l16, !tbaa !23
  %t375 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t378 = icmp eq i32 %t374, %t375
  store i1 %t378, ptr %l186, !tbaa !21
  br label %bb69
bb69:
  %t380 = load i1, ptr %l186, !tbaa !21
  br i1 %t380, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb72
bb71:
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr %"compiler/ast:Func", ptr %t381, i32 0, i32 3
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/ast:Sig", ptr %t384, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t391 = icmp eq i64 %t389, 0
  store i1 %t391, ptr %l190, !tbaa !21
  br label %bb72
bb72:
  %t393 = load i1, ptr %l190, !tbaa !21
  br i1 %t393, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  br label %bb75
bb75:
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Func", ptr %t394, i32 0, i32 3
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t399 = getelementptr %"compiler/ast:Sig", ptr %t397, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t404 = icmp sgt i64 %t402, 1
  br i1 %t404, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb79
bb77:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l16, !tbaa !23
  %t410 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t406, i32 %t407)
  store i1 %t410, ptr %l204
  br label %bb78
bb78:
  %t411 = load i1, ptr %l204, !tbaa !21
  %t412 = xor i1 %t411, true
  store i1 %t412, ptr %l201, !tbaa !21
  br label %bb79
bb79:
  %t414 = load i1, ptr %l201, !tbaa !21
  br i1 %t414, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l209, !tbaa !29
  %t425 = load i64, ptr %l7, !tbaa !24
  store i64 %t425, ptr %l210, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t428 = getelementptr %"compiler/ast:Func", ptr %t426, i32 0, i32 3
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Sig", ptr %t429, i32 0, i32 1
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l213, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr ptr, ptr %t434, i64 0
  %t436 = load ptr, ptr %t435, !tbaa !39
  %t438 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t436)
  store %"compiler/source:Span" %t438, ptr %l215
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t439 = getelementptr %"compiler/source:Span", ptr %l215, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t442 = sext i32 %t440 to i64
  store i64 %t442, ptr %l217, !tbaa !24
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = getelementptr %"compiler/ast:Func", ptr %t443, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/ast:Sig", ptr %t446, i32 0, i32 1
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l220, !tbaa !27
  %t450 = load ptr, ptr %l2, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 3
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Sig", ptr %t453, i32 0, i32 1
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t460 = sub i64 %t458, 1
  %t462 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr ptr, ptr %t463, i64 %t460
  %t465 = load ptr, ptr %t464, !tbaa !39
  %t467 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t465)
  store %"compiler/source:Span" %t467, ptr %l227
  br label %bb83
bb83:
  %t468 = getelementptr %"compiler/source:Span", ptr %l227, i32 0, i32 1
  %t469 = load i32, ptr %t468, !tbaa !23
  %t471 = sext i32 %t469 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t472
  %t473 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 0
  store i64 3, ptr %t473
  %t474 = load i64, ptr %l210, !tbaa !24
  %t475 = insertvalue { i64, i64, i64 } undef, i64 %t474, 0
  %t476 = load i64, ptr %l217, !tbaa !24
  %t477 = insertvalue { i64, i64, i64 } %t475, i64 %t476, 1
  %t479 = insertvalue { i64, i64, i64 } %t477, i64 %t471, 2
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 1
  store { i64, i64, i64 } %t479, ptr %t480
  %t481 = load { i64, [3 x i64] }, ptr %t472
  store { i64, [3 x i64] } %t481, ptr %l230
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l16, !tbaa !23
  %t486 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t482, i32 %t483)
  store { i64, ptr } %t486, ptr %l233
  br label %bb84
bb84:
  %t487 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 0
  %t489 = extractvalue { i64, ptr } %t487, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t495 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %s9, ptr %s9, { i64, ptr } %t493)
  store %"compiler/msgs:Msg" %t495, ptr %l235
  br label %bb85
bb85:
  %t496 = load ptr, ptr %l209, !tbaa !29
  %t497 = load { i64, [3 x i64] }, ptr %l230
  %t498 = load %"compiler/msgs:Msg", ptr %l235
  %t499 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t496, { i64, [3 x i64] } %t497, %"compiler/msgs:Msg" %t498)
  store i64 %t499, ptr %l236
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca %"compiler/msgs:Msg"
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 16
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 16
  store i64 %t10, ptr %t13, !tbaa !24
  store { i64, ptr } %a1, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  store i32 %t34, ptr %l8, !tbaa !23
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t40 = icmp ne i32 %t36, %t37
  br i1 %t40, label %bb6, label %bb7
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l8, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t42, i32 %t43)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l34, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l35
  br i1 %a3, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t61 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %s5)
  store %"compiler/msgs:Msg" %t61, ptr %l38
  br label %bb16
bb15:
  %t62 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s5)
  store %"compiler/msgs:Msg" %t62, ptr %l39
  br label %bb17
bb16:
  %t63 = load %"compiler/msgs:Msg", ptr %l38
  store %"compiler/msgs:Msg" %t63, ptr %l37
  br label %bb18
bb17:
  %t64 = load %"compiler/msgs:Msg", ptr %l39
  store %"compiler/msgs:Msg" %t64, ptr %l37
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l34, !tbaa !29
  %t66 = load %"compiler/source:Span", ptr %l35
  %t67 = load %"compiler/msgs:Msg", ptr %l37
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t65, %"compiler/source:Span" %t66, %"compiler/msgs:Msg" %t67)
  store i64 %t68, ptr %l40
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb20:
  store i32 2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldDeclAt(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l17 = alloca i32
  %l20 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd"
  %l30 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i32
  %l35 = alloca i1
  %l44 = alloca { i64, ptr }
  %l55 = alloca { i64, [3 x i64] }
  %s2 = alloca %olang.scope
  %wh2 = alloca ptr
  %wc2 = alloca ptr
  %ws2 = alloca i32
  %rv = alloca { i64, [3 x i64] }
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t104 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v0, ptr %t12, i32 %t13)
  store ptr %t16, ptr %l20
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l20, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  br i1 %t20, label %bb3, label %bb4
bb3:
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 0, ptr %t23
  %t24 = load { i64, [3 x i64] }, ptr %t22
  store { i64, [3 x i64] } %t24, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb6
bb6:
  %t34 = load i64, ptr %l27, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = call %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %s2, ptr %t35)
  %t38 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, 0, 1
  %t39 = extractvalue %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, 0, 0
  store ptr %t38, ptr %wh2
  store ptr %t39, ptr %wc2
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t37, ptr %l29
  br label %bb7
bb7:
  %t40 = load %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd", ptr %l29
  store %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" %t40, ptr %l7
  br label %bb8
bb8:
  %t42 = call { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %s2, ptr %l7)
  %t43 = extractvalue { i32, ptr } %t42, 1
  %t44 = extractvalue { i32, ptr } %t42, 0
  store i32 %t44, ptr %l33
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store ptr %t43, ptr %l32
  br label %bb9
bb9:
  %t47 = load ptr, ptr %l32, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  br label %bb12
bb10:
  %t48 = load i32, ptr %l33, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  store i1 %t51, ptr %l35, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  br label %bb24
bb12:
  %t52 = load ptr, ptr %l30, !tbaa !29
  store ptr %t52, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  %t55 = getelementptr %"compiler/ast:VarDecl", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  store i64 %t60, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  %t62 = load i64, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l11, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb14, label %bb15
bb14:
  br label %bb22
bb15:
  br label %bb16
bb16:
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t70, ptr %l44, !tbaa !27
  %t71 = load i64, ptr %l10, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i32, ptr %t74, i64 %t71
  %t76 = load i32, ptr %t75, !tbaa !33
  store i32 %t76, ptr %l12, !tbaa !23
  %t78 = load i64, ptr %l6, !tbaa !24
  %t82 = icmp eq i64 %t78, %a2
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l8, !tbaa !29
  %t88 = load i32, ptr %l12, !tbaa !23
  %t94 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeWritten(ptr %v0, ptr %v0, ptr %v0, ptr %t84, i64 %t85, ptr %t86, ptr %t87, i32 %t88)
  store { i64, [3 x i64] } %t94, ptr %l55
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i32 0, ptr %ws2
  br label %wend2
wend2.c0:
  call void @__olang_scope_close(ptr %s2)
  %t95 = load { i64, [3 x i64] }, ptr %l55
  store { i64, [3 x i64] } %t95, ptr %rv
  br label %ret
bb20:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l6, !tbaa !24
  br label %bb21
bb21:
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l10, !tbaa !24
  br label %bb13
bb22:
  br label %bb23
bb23:
  br label %bb8
bb24:
  store i32 1, ptr %ws2
  br label %wend2
wend2.c1:
  call void @__olang_scope_close(ptr %s2)
  store { i64, [3 x i64] } zeroinitializer, ptr %t104
  %t105 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 0
  store i64 0, ptr %t105
  %t106 = load { i64, [3 x i64] }, ptr %t104
  store { i64, [3 x i64] } %t106, ptr %rv
  br label %ret
wend2:
  %t108 = load ptr, ptr %wh2
  %t109 = load ptr, ptr %wc2
  %t110 = call ptr @llvm.coro.promise(ptr %t108, i32 8, i1 false)
  %t111 = getelementptr { { i32, ptr }, i32 }, ptr %t110, i32 0, i32 1
  store i32 2, ptr %t111
  %t112 = call { i32, ptr } %t109(ptr %t108, ptr null)
  %t113 = load i32, ptr %ws2
  switch i32 %t113, label %wend2.c0 [ i32 1, label %wend2.c1 ]
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i1
  %l44 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l59 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t24 = trunc i64 21 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t30 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %a1)
  store i1 %t30, ptr %l21
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t31 = load i1, ptr %l21, !tbaa !21
  store i1 %t31, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t43 = load i32, ptr %l26, !tbaa !23
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l31
  br label %bb15
bb15:
  %t54 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t56 = trunc i64 19 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l39
  br label %bb18
bb17:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb18:
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = icmp ne i32 %t69, 0
  store i1 %t70, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v3, ptr %t73, ptr %a3)
  store i1 %t77, ptr %l44
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb23
bb22:
  %t78 = load i1, ptr %l44, !tbaa !21
  store i1 %t78, ptr %l41, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l41, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  store ptr %t85, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = load i32, ptr %l4, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l52
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = load i32, ptr %l52, !tbaa !23
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t96, i32 %t97, i32 0)
  store i32 %t98, ptr %l53
  br label %bb27
bb27:
  %t99 = load i32, ptr %l53, !tbaa !23
  store i32 %t99, ptr %l4, !tbaa !23
  br label %bb28
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load i32, ptr %l4, !tbaa !23
  %t104 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t100, i32 %t101)
  store i1 %t104, ptr %l56
  br label %bb29
bb29:
  %t105 = load i1, ptr %l56, !tbaa !21
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l4, !tbaa !23
  %t110 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t106, i32 %t107)
  store i32 %t110, ptr %l59
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t111 = load i32, ptr %l59, !tbaa !23
  store i32 %t111, ptr %l4, !tbaa !23
  br label %bb33
bb33:
  %t112 = load i32, ptr %l4, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/check:litv"
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l15 = alloca %"compiler/check:signMag"
  %l16 = alloca i1
  %l17 = alloca i128
  %l18 = alloca %"compiler/check:litv"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:litv"
  %l23 = alloca %"compiler/check:litv"
  %l24 = alloca double
  %l25 = alloca double
  %l26 = alloca %"compiler/check:signMag"
  %l27 = alloca i1
  %l28 = alloca i128
  %l29 = alloca %"compiler/check:signMag"
  %l30 = alloca i1
  %l31 = alloca i128
  %l32 = alloca i128
  %l33 = alloca i64
  %l34 = alloca %"compiler/check:litv"
  %l35 = alloca i128
  %l38 = alloca i128
  %l39 = alloca i64
  %l40 = alloca i64
  %l43 = alloca %"compiler/check:litv"
  %l44 = alloca ptr
  %l45 = alloca i1
  %l54 = alloca { i64, ptr }
  %l60 = alloca i1
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca i32
  %l86 = alloca i128
  %l88 = alloca i128
  %l89 = alloca i32
  %l90 = alloca %"compiler/check:litv"
  %l91 = alloca %"compiler/check:litv"
  %l94 = alloca %"compiler/check:litv"
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i32
  %l100 = alloca i64
  %l101 = alloca i32
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca i32
  %l106 = alloca i64
  %l107 = alloca i32
  %l108 = alloca i128
  %l110 = alloca i128
  %l111 = alloca i32
  %l112 = alloca %"compiler/check:litv"
  %l113 = alloca %"compiler/check:litv"
  %l116 = alloca %"compiler/check:litv"
  %l118 = alloca %"compiler/check:litv"
  %l123 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l129 = alloca double
  %l131 = alloca double
  %l132 = alloca i32
  %l133 = alloca %"compiler/check:litv"
  %l135 = alloca %"compiler/check:litv"
  %l136 = alloca %"compiler/check:litv"
  %l137 = alloca ptr
  %l138 = alloca i1
  %l146 = alloca %"compiler/check:litv"
  %l147 = alloca ptr
  %l148 = alloca i1
  %l158 = alloca %"compiler/check:litv"
  %l161 = alloca %"compiler/check:litv"
  %l167 = alloca %"compiler/check:litv"
  %l169 = alloca %"compiler/check:signMag"
  %l174 = alloca %"compiler/check:litv"
  %l178 = alloca %"compiler/check:litv"
  %l179 = alloca %"compiler/check:litv"
  %l182 = alloca i1
  %l185 = alloca i1
  %l190 = alloca %"compiler/check:litv"
  %l193 = alloca %"compiler/check:litv"
  %l194 = alloca ptr
  %l195 = alloca i1
  %l206 = alloca %"compiler/check:litv"
  %l209 = alloca %"compiler/check:litv"
  %l212 = alloca i1
  %l215 = alloca %"compiler/check:litv"
  %l217 = alloca i1
  %l220 = alloca i1
  %l222 = alloca %"compiler/check:litv"
  %l224 = alloca double
  %l229 = alloca double
  %l238 = alloca %"compiler/check:litv"
  %l244 = alloca %"compiler/check:litv"
  %l250 = alloca %"compiler/check:litv"
  %l256 = alloca %"compiler/check:litv"
  %l257 = alloca %"compiler/check:litv"
  %l259 = alloca %"compiler/check:signMag"
  %l263 = alloca %"compiler/check:signMag"
  %l272 = alloca %"compiler/check:litv"
  %l280 = alloca %"compiler/check:litv"
  %l285 = alloca i1
  %l291 = alloca %"compiler/check:litv"
  %l298 = alloca i1
  %l302 = alloca %"compiler/check:litv"
  %l305 = alloca i1
  %l308 = alloca i1
  %l312 = alloca i1
  %l317 = alloca %"compiler/check:litv"
  %l320 = alloca i64
  %l326 = alloca i64
  %l334 = alloca %"compiler/check:litv"
  %l336 = alloca i1
  %l338 = alloca i1
  %l342 = alloca %"compiler/check:litv"
  %l344 = alloca i1
  %l349 = alloca i1
  %l352 = alloca i1
  %l355 = alloca i1
  %l358 = alloca i1
  %l366 = alloca i1
  %l368 = alloca i1
  %l377 = alloca %"compiler/check:litv"
  %l379 = alloca i128
  %l382 = alloca i128
  %l386 = alloca %"compiler/check:litv"
  %l388 = alloca %"compiler/check:litv"
  %l390 = alloca i1
  %l392 = alloca i1
  %l398 = alloca i128
  %l400 = alloca %"compiler/check:litv"
  %l403 = alloca i128
  %l406 = alloca %"compiler/check:litv"
  %l408 = alloca i64
  %l410 = alloca %"compiler/check:litv"
  %l412 = alloca i1
  %l416 = alloca %"compiler/check:litv"
  %l425 = alloca %"compiler/check:litv"
  %l432 = alloca %"compiler/check:litv"
  %l433 = alloca %"compiler/check:litv"
  %l435 = alloca i1
  %l437 = alloca %"compiler/check:litv"
  %l442 = alloca i1
  %l445 = alloca i1
  %l449 = alloca i1
  %l456 = alloca %"compiler/check:litv"
  %l459 = alloca i1
  %l462 = alloca i1
  %l468 = alloca %"compiler/check:litv"
  %l469 = alloca %"compiler/check:litv"
  %l470 = alloca %"compiler/check:litv"
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t5, ptr %l43
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load %"compiler/check:litv", ptr %l43
  store %"compiler/check:litv" %t6, ptr %rv
  br label %ret
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t8 = load ptr, ptr %l44, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l44, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 30}
  %t14 = icmp eq i64 %t12, 1
  store i1 %t14, ptr %l45, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l45, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l2
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32 }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25, !range !{i32 0, i32 98}
  store i32 %t26, ptr %l3
  br label %bb9
bb8:
  br label %bb76
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l2
  %t32 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t28, %"compiler/source:Span" %t29)
  store { i64, ptr } %t32, ptr %l54
  br label %bb10
bb10:
  %t33 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t36 = trunc i64 2 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp sgt i64 %t41, 2
  br i1 %t43, label %bb13, label %bb14
bb12:
  br label %bb64
bb13:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l61, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i8, ptr %t47, i64 0
  %t49 = load i8, ptr %t48, !tbaa !32
  %t51 = icmp eq i8 %t49, 48
  store i1 %t51, ptr %l60, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l60, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l65, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 1
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 120
  br i1 %t60, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb27
bb18:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb20
bb19:
  %t62 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t62, ptr %l69, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i8, ptr %t64, i64 1
  %t66 = load i8, ptr %t65, !tbaa !32
  %t68 = icmp eq i8 %t66, 88
  store i1 %t68, ptr %l68, !tbaa !21
  br label %bb20
bb20:
  %t70 = load i1, ptr %l68, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb23
bb22:
  %t71 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t71, ptr %l73, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 1
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = icmp eq i8 %t75, 98
  store i1 %t77, ptr %l72, !tbaa !21
  br label %bb23
bb23:
  %t79 = load i1, ptr %l72, !tbaa !21
  br i1 %t79, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t80, ptr %l77, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr i8, ptr %t82, i64 1
  %t84 = load i8, ptr %t83, !tbaa !32
  %t86 = icmp eq i8 %t84, 66
  store i1 %t86, ptr %l76, !tbaa !21
  br label %bb26
bb26:
  %t88 = load i1, ptr %l76, !tbaa !21
  store i1 %t88, ptr %l64, !tbaa !21
  br label %bb27
bb27:
  %t89 = load i1, ptr %l64, !tbaa !21
  br i1 %t89, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l81, !tbaa !27
  %t91 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s4, i64 0)
  %t92 = extractvalue { i32, i64 } %t91, 1
  %t93 = extractvalue { i32, i64 } %t91, 0
  store i32 %t93, ptr %l83
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb31, label %ok.95, !prof !99
ok.95:
  store i64 %t92, ptr %l82
  br label %bb30
bb29:
  br label %bb43
bb30:
  %t96 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t97 = load i64, ptr %l82, !tbaa !24
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t96, i64 %t97)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l85
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb34, label %ok.102, !prof !99
ok.102:
  store i64 %t99, ptr %l84
  br label %bb33
bb31:
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t105 = call { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %t103)
  %t106 = extractvalue { i32, i128 } %t105, 1
  %t107 = extractvalue { i32, i128 } %t105, 0
  store i32 %t107, ptr %l89
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb36, label %ok.109, !prof !99
ok.109:
  store i128 %t106, ptr %l88
  br label %bb35
bb33:
  %t110 = load i64, ptr %l84, !tbaa !65
  store i64 %t110, ptr %l80, !tbaa !65
  br label %bb41
bb34:
  br label %bb32
bb35:
  %t111 = load i128, ptr %l88
  store i128 %t111, ptr %l86
  br label %bb39
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  %t112 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t112, ptr %l90
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t113 = load %"compiler/check:litv", ptr %l90
  store %"compiler/check:litv" %t113, ptr %rv
  br label %ret
bb39:
  %t114 = load i128, ptr %l86
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t114)
  store %"compiler/check:litv" %t115, ptr %l91
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  %t116 = load %"compiler/check:litv", ptr %l91
  store %"compiler/check:litv" %t116, ptr %rv
  br label %ret
bb41:
  %t117 = load i64, ptr %l80, !tbaa !65
  %t121 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t117)
  store %"compiler/check:litv" %t121, ptr %l94
  br label %bb42
bb42:
  %t122 = load %"compiler/check:litv", ptr %l94
  store %"compiler/check:litv" %t122, ptr %l6
  %t123 = getelementptr %"compiler/check:litv", ptr %l6, i32 0, i32 5
  store i1 true, ptr %t123, !tbaa !21
  %t124 = load %"compiler/check:litv", ptr %l6
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store %"compiler/check:litv" %t124, ptr %rv
  br label %ret
bb43:
  %t126 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t126, ptr %l97, !tbaa !27
  %t127 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s3, i64 0)
  %t128 = extractvalue { i32, i64 } %t127, 1
  %t129 = extractvalue { i32, i64 } %t127, 0
  store i32 %t129, ptr %l99
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb45, label %ok.131, !prof !99
ok.131:
  store i64 %t128, ptr %l98
  br label %bb44
bb44:
  %t132 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t133 = load i64, ptr %l98, !tbaa !24
  %t134 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t132, i64 %t133)
  %t135 = extractvalue { i32, i64 } %t134, 1
  %t136 = extractvalue { i32, i64 } %t134, 0
  store i32 %t136, ptr %l101
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb48, label %ok.138, !prof !99
ok.138:
  store i64 %t135, ptr %l100
  br label %bb47
bb45:
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t139, ptr %l103, !tbaa !27
  %t140 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s7, i64 0)
  %t141 = extractvalue { i32, i64 } %t140, 1
  %t142 = extractvalue { i32, i64 } %t140, 0
  store i32 %t142, ptr %l105
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb50, label %ok.144, !prof !99
ok.144:
  store i64 %t141, ptr %l104
  br label %bb49
bb47:
  %t145 = load i64, ptr %l100, !tbaa !24
  store i64 %t145, ptr %l96, !tbaa !24
  br label %bb62
bb48:
  br label %bb46
bb49:
  %t146 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t147 = load i64, ptr %l104, !tbaa !24
  %t148 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t146, i64 %t147)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l107
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb53, label %ok.152, !prof !99
ok.152:
  store i64 %t149, ptr %l106
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t155 = call { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %t153)
  %t156 = extractvalue { i32, i128 } %t155, 1
  %t157 = extractvalue { i32, i128 } %t155, 0
  store i32 %t157, ptr %l111
  %t158 = icmp ne i32 %t157, 0
  br i1 %t158, label %bb55, label %ok.159, !prof !99
ok.159:
  store i128 %t156, ptr %l110
  br label %bb54
bb52:
  %t160 = load i64, ptr %l106, !tbaa !65
  store i64 %t160, ptr %l102, !tbaa !65
  br label %bb60
bb53:
  br label %bb51
bb54:
  %t161 = load i128, ptr %l110
  store i128 %t161, ptr %l108
  br label %bb58
bb55:
  br label %bb56
bb56:
  call void @__olang_ert_req_clear()
  %t162 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t162, ptr %l112
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  %t163 = load %"compiler/check:litv", ptr %l112
  store %"compiler/check:litv" %t163, ptr %rv
  br label %ret
bb58:
  %t164 = load i128, ptr %l108
  %t165 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t164)
  store %"compiler/check:litv" %t165, ptr %l113
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  %t166 = load %"compiler/check:litv", ptr %l113
  store %"compiler/check:litv" %t166, ptr %rv
  br label %ret
bb60:
  %t167 = load i64, ptr %l102, !tbaa !65
  %t171 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s7, i1 true, i1 false, i1 true, i64 %t167, double 0x0000000000000000)
  store %"compiler/check:litv" %t171, ptr %l116
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s3)
  %t172 = load %"compiler/check:litv", ptr %l116
  store %"compiler/check:litv" %t172, ptr %rv
  br label %ret
bb62:
  %t173 = load i64, ptr %l96, !tbaa !24
  %t176 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t173)
  store %"compiler/check:litv" %t176, ptr %l118
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s3)
  %t177 = load %"compiler/check:litv", ptr %l118
  store %"compiler/check:litv" %t177, ptr %rv
  br label %ret
bb64:
  %t178 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t180 = trunc i64 3 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s10
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l123, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t188 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t183, { i64, ptr } %t186, { i64, ptr } %t187)
  store { i64, ptr } %t188, ptr %l125
  br label %bb67
bb66:
  br label %bb74
bb67:
  %t189 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  store i64 %t190, ptr %l126, !tbaa !24
  %t191 = load i64, ptr %l126, !tbaa !24
  %t192 = mul i64 %t191, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t192)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l127, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l126, !tbaa !24
  %t201 = mul i64 %t200, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t206 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %s10, { i64, ptr } %t202)
  %t207 = extractvalue { i32, double } %t206, 1
  %t208 = extractvalue { i32, double } %t206, 0
  store i32 %t208, ptr %l132
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb69, label %ok.210, !prof !99
ok.210:
  store double %t207, ptr %l131
  br label %bb68
bb68:
  %t211 = load double, ptr %l131, !tbaa !26
  store double %t211, ptr %l129, !tbaa !26
  br label %bb72
bb69:
  br label %bb70
bb70:
  call void @__olang_ert_req_clear()
  %t212 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t212, ptr %l133
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s10)
  %t213 = load %"compiler/check:litv", ptr %l133
  store %"compiler/check:litv" %t213, ptr %rv
  br label %ret
bb72:
  %t214 = load double, ptr %l129, !tbaa !26
  %t217 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t214)
  store %"compiler/check:litv" %t217, ptr %l135
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s10)
  %t218 = load %"compiler/check:litv", ptr %l135
  store %"compiler/check:litv" %t218, ptr %rv
  br label %ret
bb74:
  %t219 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t219, ptr %l136
  br label %bb75
bb75:
  %t220 = load %"compiler/check:litv", ptr %l136
  store %"compiler/check:litv" %t220, ptr %rv
  br label %ret
bb76:
  %t221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t221, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t222 = load ptr, ptr %l137, !tbaa !29
  %t223 = icmp ne ptr %t222, null
  br i1 %t223, label %bb77, label %bb78
bb77:
  %t225 = load ptr, ptr %l137, !tbaa !29
  %t226 = load i64, ptr %t225, !range !{i64 0, i64 30}
  %t228 = icmp eq i64 %t226, 2
  store i1 %t228, ptr %l138, !tbaa !21
  br label %bb78
bb78:
  %t229 = load i1, ptr %l138, !tbaa !21
  br i1 %t229, label %bb79, label %bb80
bb79:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr { i64, [4 x i64] }, ptr %t230, i32 0, i32 1
  %t233 = getelementptr { %"compiler/source:Span", ptr }, ptr %t232, i32 0, i32 1
  %t234 = load ptr, ptr %t233
  store ptr %t234, ptr %l11, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load ptr, ptr %l11, !tbaa !29
  %t241 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t236, ptr %t237)
  store %"compiler/check:litv" %t241, ptr %l146
  br label %bb82
bb82:
  %t242 = load %"compiler/check:litv", ptr %l146
  store %"compiler/check:litv" %t242, ptr %rv
  br label %ret
bb83:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t244 = load ptr, ptr %l147, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb84, label %bb85
bb84:
  %t247 = load ptr, ptr %l147, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 30}
  %t250 = icmp eq i64 %t248, 3
  store i1 %t250, ptr %l148, !tbaa !21
  br label %bb85
bb85:
  %t251 = load i1, ptr %l148, !tbaa !21
  br i1 %t251, label %bb86, label %bb87
bb86:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load i32, ptr %t255, !range !{i32 0, i32 98}
  store i32 %t256, ptr %l12
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l13, !tbaa !29
  br label %bb88
bb87:
  br label %bb118
bb88:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l13, !tbaa !29
  %t269 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t264, ptr %t265)
  store %"compiler/check:litv" %t269, ptr %l158
  br label %bb89
bb89:
  %t270 = load %"compiler/check:litv", ptr %l158
  store %"compiler/check:litv" %t270, ptr %l14
  %t271 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 0
  %t272 = load i1, ptr %t271, !tbaa !21
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb90, label %bb91
bb90:
  %t276 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t276, ptr %l161
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t277 = load %"compiler/check:litv", ptr %l161
  store %"compiler/check:litv" %t277, ptr %rv
  br label %ret
bb93:
  %t278 = load i32, ptr %l12, !range !{i32 0, i32 98}
  %t280 = trunc i64 53 to i32
  %t281 = icmp eq i32 %t278, %t280
  br i1 %t281, label %bb94, label %bb95
bb94:
  %t283 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t284 = load i1, ptr %t283, !tbaa !21
  br i1 %t284, label %bb96, label %bb97
bb95:
  br label %bb106
bb96:
  %t286 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 4
  %t287 = load double, ptr %t286, !tbaa !26
  %t289 = fneg double %t287
  %t291 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t289)
  store %"compiler/check:litv" %t291, ptr %l167
  br label %bb98
bb97:
  br label %bb99
bb98:
  %t292 = load %"compiler/check:litv", ptr %l167
  store %"compiler/check:litv" %t292, ptr %rv
  br label %ret
bb99:
  %t293 = load %"compiler/check:litv", ptr %l14
  %t295 = call %"compiler/check:signMag" @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t293)
  store %"compiler/check:signMag" %t295, ptr %l169
  br label %bb100
bb100:
  %t296 = load %"compiler/check:signMag", ptr %l169
  store %"compiler/check:signMag" %t296, ptr %l15
  %t297 = getelementptr %"compiler/check:signMag", ptr %l15, i32 0, i32 0
  %t298 = load i1, ptr %t297, !tbaa !21
  store i1 %t298, ptr %l16, !tbaa !21
  %t300 = getelementptr %"compiler/check:signMag", ptr %l15, i32 0, i32 1
  %t301 = load i128, ptr %t300
  store i128 %t301, ptr %l17
  %t303 = load i128, ptr %l17
  %t305 = icmp ne i128 %t303, 0
  br i1 %t305, label %bb101, label %bb102
bb101:
  %t307 = load i1, ptr %l16, !tbaa !21
  %t309 = xor i1 %t307, true
  %t310 = load i128, ptr %l17
  %t313 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t309, i128 %t310)
  store %"compiler/check:litv" %t313, ptr %l178
  br label %bb103
bb102:
  %t314 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 0)
  store %"compiler/check:litv" %t314, ptr %l179
  br label %bb104
bb103:
  %t315 = load %"compiler/check:litv", ptr %l178
  store %"compiler/check:litv" %t315, ptr %l174
  br label %bb105
bb104:
  %t316 = load %"compiler/check:litv", ptr %l179
  store %"compiler/check:litv" %t316, ptr %l174
  br label %bb105
bb105:
  %t317 = load %"compiler/check:litv", ptr %l174
  store %"compiler/check:litv" %t317, ptr %rv
  br label %ret
bb106:
  %t318 = load i32, ptr %l12, !range !{i32 0, i32 98}
  %t320 = trunc i64 88 to i32
  %t321 = icmp eq i32 %t318, %t320
  br i1 %t321, label %bb107, label %bb108
bb107:
  %t323 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 1
  %t324 = load i1, ptr %t323, !tbaa !21
  %t326 = xor i1 %t324, true
  store i1 %t326, ptr %l182, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb109
bb109:
  %t328 = load i1, ptr %l182, !tbaa !21
  br i1 %t328, label %bb110, label %bb111
bb110:
  %t329 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 2
  %t330 = load i1, ptr %t329, !tbaa !21
  %t332 = xor i1 %t330, true
  store i1 %t332, ptr %l185, !tbaa !21
  br label %bb112
bb111:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb112
bb112:
  %t334 = load i1, ptr %l185, !tbaa !21
  br i1 %t334, label %bb113, label %bb114
bb113:
  %t335 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 3
  %t336 = load i64, ptr %t335, !tbaa !24
  %t338 = xor i64 %t336, -1
  %t340 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t338)
  store %"compiler/check:litv" %t340, ptr %l190
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t341 = load %"compiler/check:litv", ptr %l190
  store %"compiler/check:litv" %t341, ptr %l18
  %t342 = getelementptr %"compiler/check:litv", ptr %l14, i32 0, i32 5
  %t343 = load i1, ptr %t342, !tbaa !21
  %t345 = getelementptr %"compiler/check:litv", ptr %l18, i32 0, i32 5
  store i1 %t343, ptr %t345, !tbaa !21
  %t346 = load %"compiler/check:litv", ptr %l18
  store %"compiler/check:litv" %t346, ptr %rv
  br label %ret
bb116:
  %t348 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t348, ptr %l193
  br label %bb117
bb117:
  %t349 = load %"compiler/check:litv", ptr %l193
  store %"compiler/check:litv" %t349, ptr %rv
  br label %ret
bb118:
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l194, !tbaa !29
  store i1 false, ptr %l195, !tbaa !21
  %t351 = load ptr, ptr %l194, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb119, label %bb120
bb119:
  %t354 = load ptr, ptr %l194, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 30}
  %t357 = icmp eq i64 %t355, 5
  store i1 %t357, ptr %l195, !tbaa !21
  br label %bb120
bb120:
  %t358 = load i1, ptr %l195, !tbaa !21
  br i1 %t358, label %bb121, label %bb122
bb121:
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 1
  %t362 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t361, i32 0, i32 1
  %t363 = load i32, ptr %t362, !range !{i32 0, i32 98}
  store i32 %t363, ptr %l19
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [4 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t367, i32 0, i32 2
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l20, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [4 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t373, i32 0, i32 3
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l21, !tbaa !29
  br label %bb123
bb122:
  br label %bb330
bb123:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load ptr, ptr %l20, !tbaa !29
  %t381 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t377, ptr %t378)
  store %"compiler/check:litv" %t381, ptr %l206
  br label %bb124
bb124:
  %t382 = load %"compiler/check:litv", ptr %l206
  store %"compiler/check:litv" %t382, ptr %l22
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load ptr, ptr %l21, !tbaa !29
  %t387 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %t383, ptr %t384)
  store %"compiler/check:litv" %t387, ptr %l209
  br label %bb125
bb125:
  %t388 = load %"compiler/check:litv", ptr %l209
  store %"compiler/check:litv" %t388, ptr %l23
  %t389 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 0
  %t390 = load i1, ptr %t389, !tbaa !21
  %t392 = xor i1 %t390, true
  br i1 %t392, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb128
bb127:
  %t394 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 0
  %t395 = load i1, ptr %t394, !tbaa !21
  %t397 = xor i1 %t395, true
  store i1 %t397, ptr %l212, !tbaa !21
  br label %bb128
bb128:
  %t399 = load i1, ptr %l212, !tbaa !21
  br i1 %t399, label %bb129, label %bb130
bb129:
  %t400 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t400, ptr %l215
  br label %bb131
bb130:
  br label %bb132
bb131:
  %t401 = load %"compiler/check:litv", ptr %l215
  store %"compiler/check:litv" %t401, ptr %rv
  br label %ret
bb132:
  %t402 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t403 = load i1, ptr %t402, !tbaa !21
  br i1 %t403, label %bb133, label %bb134
bb133:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb135
bb134:
  %t405 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t406 = load i1, ptr %t405, !tbaa !21
  store i1 %t406, ptr %l217, !tbaa !21
  br label %bb135
bb135:
  %t408 = load i1, ptr %l217, !tbaa !21
  br i1 %t408, label %bb136, label %bb137
bb136:
  %t409 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t410 = load i1, ptr %t409, !tbaa !21
  br i1 %t410, label %bb138, label %bb139
bb137:
  br label %bb168
bb138:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb140
bb139:
  %t412 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t413 = load i1, ptr %t412, !tbaa !21
  store i1 %t413, ptr %l220, !tbaa !21
  br label %bb140
bb140:
  %t415 = load i1, ptr %l220, !tbaa !21
  br i1 %t415, label %bb141, label %bb142
bb141:
  %t416 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t416, ptr %l222
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t417 = load %"compiler/check:litv", ptr %l222
  store %"compiler/check:litv" %t417, ptr %rv
  br label %ret
bb144:
  %t418 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 1
  %t419 = load i1, ptr %t418, !tbaa !21
  br i1 %t419, label %bb145, label %bb146
bb145:
  %t421 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 4
  %t422 = load double, ptr %t421, !tbaa !26
  store double %t422, ptr %l224, !tbaa !26
  br label %bb147
bb146:
  %t424 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t425 = load i64, ptr %t424, !tbaa !24
  %t427 = sitofp i64 %t425 to double
  store double %t427, ptr %l224, !tbaa !26
  br label %bb147
bb147:
  %t429 = load double, ptr %l224, !tbaa !26
  store double %t429, ptr %l24, !tbaa !26
  %t430 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 1
  %t431 = load i1, ptr %t430, !tbaa !21
  br i1 %t431, label %bb148, label %bb149
bb148:
  %t433 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 4
  %t434 = load double, ptr %t433, !tbaa !26
  store double %t434, ptr %l229, !tbaa !26
  br label %bb150
bb149:
  %t436 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t437 = load i64, ptr %t436, !tbaa !24
  %t439 = sitofp i64 %t437 to double
  store double %t439, ptr %l229, !tbaa !26
  br label %bb150
bb150:
  %t441 = load double, ptr %l229, !tbaa !26
  store double %t441, ptr %l25, !tbaa !26
  %t442 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t444 = trunc i64 52 to i32
  %t445 = icmp eq i32 %t442, %t444
  br i1 %t445, label %bb151, label %bb152
bb151:
  %t447 = load double, ptr %l24, !tbaa !26
  %t448 = load double, ptr %l25, !tbaa !26
  %t451 = fadd double %t447, %t448
  %t453 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t451)
  store %"compiler/check:litv" %t453, ptr %l238
  br label %bb153
bb152:
  br label %bb154
bb153:
  %t454 = load %"compiler/check:litv", ptr %l238
  store %"compiler/check:litv" %t454, ptr %rv
  br label %ret
bb154:
  %t455 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t457 = trunc i64 53 to i32
  %t458 = icmp eq i32 %t455, %t457
  br i1 %t458, label %bb155, label %bb156
bb155:
  %t460 = load double, ptr %l24, !tbaa !26
  %t461 = load double, ptr %l25, !tbaa !26
  %t464 = fsub double %t460, %t461
  %t466 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t464)
  store %"compiler/check:litv" %t466, ptr %l244
  br label %bb157
bb156:
  br label %bb158
bb157:
  %t467 = load %"compiler/check:litv", ptr %l244
  store %"compiler/check:litv" %t467, ptr %rv
  br label %ret
bb158:
  %t468 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t470 = trunc i64 54 to i32
  %t471 = icmp eq i32 %t468, %t470
  br i1 %t471, label %bb159, label %bb160
bb159:
  %t473 = load double, ptr %l24, !tbaa !26
  %t474 = load double, ptr %l25, !tbaa !26
  %t477 = fmul double %t473, %t474
  %t479 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t477)
  store %"compiler/check:litv" %t479, ptr %l250
  br label %bb161
bb160:
  br label %bb162
bb161:
  %t480 = load %"compiler/check:litv", ptr %l250
  store %"compiler/check:litv" %t480, ptr %rv
  br label %ret
bb162:
  %t481 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t483 = trunc i64 56 to i32
  %t484 = icmp eq i32 %t481, %t483
  br i1 %t484, label %bb163, label %bb164
bb163:
  %t486 = load double, ptr %l24, !tbaa !26
  %t487 = load double, ptr %l25, !tbaa !26
  %t490 = fdiv double %t486, %t487
  %t492 = call %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %t490)
  store %"compiler/check:litv" %t492, ptr %l256
  br label %bb165
bb164:
  br label %bb166
bb165:
  %t493 = load %"compiler/check:litv", ptr %l256
  store %"compiler/check:litv" %t493, ptr %rv
  br label %ret
bb166:
  %t494 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t494, ptr %l257
  br label %bb167
bb167:
  %t495 = load %"compiler/check:litv", ptr %l257
  store %"compiler/check:litv" %t495, ptr %rv
  br label %ret
bb168:
  %t496 = load %"compiler/check:litv", ptr %l22
  %t498 = call %"compiler/check:signMag" @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t496)
  store %"compiler/check:signMag" %t498, ptr %l259
  br label %bb169
bb169:
  %t499 = load %"compiler/check:signMag", ptr %l259
  store %"compiler/check:signMag" %t499, ptr %l26
  %t500 = getelementptr %"compiler/check:signMag", ptr %l26, i32 0, i32 0
  %t501 = load i1, ptr %t500, !tbaa !21
  store i1 %t501, ptr %l27, !tbaa !21
  %t503 = getelementptr %"compiler/check:signMag", ptr %l26, i32 0, i32 1
  %t504 = load i128, ptr %t503
  store i128 %t504, ptr %l28
  %t506 = load %"compiler/check:litv", ptr %l23
  %t508 = call %"compiler/check:signMag" @compiler_2fcheck_2emagOf(%"compiler/check:litv" %t506)
  store %"compiler/check:signMag" %t508, ptr %l263
  br label %bb170
bb170:
  %t509 = load %"compiler/check:signMag", ptr %l263
  store %"compiler/check:signMag" %t509, ptr %l29
  %t510 = getelementptr %"compiler/check:signMag", ptr %l29, i32 0, i32 0
  %t511 = load i1, ptr %t510, !tbaa !21
  store i1 %t511, ptr %l30, !tbaa !21
  %t513 = getelementptr %"compiler/check:signMag", ptr %l29, i32 0, i32 1
  %t514 = load i128, ptr %t513
  store i128 %t514, ptr %l31
  %t516 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t518 = trunc i64 52 to i32
  %t519 = icmp eq i32 %t516, %t518
  br i1 %t519, label %bb171, label %bb172
bb171:
  %t521 = load i1, ptr %l27, !tbaa !21
  %t522 = load i128, ptr %l28
  %t523 = load i1, ptr %l30, !tbaa !21
  %t524 = load i128, ptr %l31
  %t529 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t521, i128 %t522, i1 %t523, i128 %t524)
  store %"compiler/check:litv" %t529, ptr %l272
  br label %bb173
bb172:
  br label %bb174
bb173:
  %t530 = load %"compiler/check:litv", ptr %l272
  store %"compiler/check:litv" %t530, ptr %rv
  br label %ret
bb174:
  %t531 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t533 = trunc i64 53 to i32
  %t534 = icmp eq i32 %t531, %t533
  br i1 %t534, label %bb175, label %bb176
bb175:
  %t536 = load i1, ptr %l27, !tbaa !21
  %t537 = load i128, ptr %l28
  %t538 = load i1, ptr %l30, !tbaa !21
  %t540 = xor i1 %t538, true
  %t541 = load i128, ptr %l31
  %t546 = call %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %t536, i128 %t537, i1 %t540, i128 %t541)
  store %"compiler/check:litv" %t546, ptr %l280
  br label %bb177
bb176:
  br label %bb178
bb177:
  %t547 = load %"compiler/check:litv", ptr %l280
  store %"compiler/check:litv" %t547, ptr %rv
  br label %ret
bb178:
  %t548 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t550 = trunc i64 54 to i32
  %t551 = icmp eq i32 %t548, %t550
  br i1 %t551, label %bb179, label %bb180
bb179:
  %t553 = load i128, ptr %l28
  %t555 = icmp ne i128 %t553, 0
  br i1 %t555, label %bb181, label %bb182
bb180:
  br label %bb192
bb181:
  %t557 = load i128, ptr %l31
  %t558 = xor i128 0, -1
  %t559 = load i128, ptr %l28
  %t562 = udiv i128 %t558, %t559
  %t565 = icmp ugt i128 %t557, %t562
  store i1 %t565, ptr %l285, !tbaa !21
  br label %bb183
bb182:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb183
bb183:
  %t567 = load i1, ptr %l285, !tbaa !21
  br i1 %t567, label %bb184, label %bb185
bb184:
  %t568 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t568, ptr %l291
  br label %bb186
bb185:
  br label %bb187
bb186:
  %t569 = load %"compiler/check:litv", ptr %l291
  store %"compiler/check:litv" %t569, ptr %rv
  br label %ret
bb187:
  %t570 = load i128, ptr %l28
  %t571 = load i128, ptr %l31
  %t574 = mul i128 %t570, %t571
  store i128 %t574, ptr %l32
  %t576 = load i1, ptr %l27, !tbaa !21
  %t577 = load i1, ptr %l30, !tbaa !21
  %t580 = icmp ne i1 %t576, %t577
  br i1 %t580, label %bb188, label %bb189
bb188:
  %t582 = load i128, ptr %l32
  %t584 = icmp ne i128 %t582, 0
  store i1 %t584, ptr %l298, !tbaa !21
  br label %bb190
bb189:
  store i1 false, ptr %l298, !tbaa !21
  br label %bb190
bb190:
  %t586 = load i128, ptr %l32
  %t587 = load i1, ptr %l298, !tbaa !21
  %t589 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t587, i128 %t586)
  store %"compiler/check:litv" %t589, ptr %l302
  br label %bb191
bb191:
  %t590 = load %"compiler/check:litv", ptr %l302
  store %"compiler/check:litv" %t590, ptr %rv
  br label %ret
bb192:
  %t591 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t593 = trunc i64 85 to i32
  %t594 = icmp eq i32 %t591, %t593
  br i1 %t594, label %bb193, label %bb194
bb193:
  store i1 true, ptr %l305, !tbaa !21
  br label %bb195
bb194:
  %t596 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t598 = trunc i64 86 to i32
  %t599 = icmp eq i32 %t596, %t598
  store i1 %t599, ptr %l305, !tbaa !21
  br label %bb195
bb195:
  %t601 = load i1, ptr %l305, !tbaa !21
  br i1 %t601, label %bb196, label %bb197
bb196:
  store i1 true, ptr %l308, !tbaa !21
  br label %bb198
bb197:
  %t602 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t604 = trunc i64 87 to i32
  %t605 = icmp eq i32 %t602, %t604
  store i1 %t605, ptr %l308, !tbaa !21
  br label %bb198
bb198:
  %t607 = load i1, ptr %l308, !tbaa !21
  br i1 %t607, label %bb199, label %bb200
bb199:
  %t608 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 6
  %t609 = load i1, ptr %t608, !tbaa !21
  br i1 %t609, label %bb201, label %bb202
bb200:
  br label %bb228
bb201:
  store i1 true, ptr %l312, !tbaa !21
  br label %bb203
bb202:
  %t611 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 6
  %t612 = load i1, ptr %t611, !tbaa !21
  store i1 %t612, ptr %l312, !tbaa !21
  br label %bb203
bb203:
  %t614 = load i1, ptr %l312, !tbaa !21
  br i1 %t614, label %bb204, label %bb205
bb204:
  %t615 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t616 = load %"compiler/check:litv", ptr %l22
  %t617 = load %"compiler/check:litv", ptr %l23
  %t621 = call %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %t615, %"compiler/check:litv" %t616, %"compiler/check:litv" %t617)
  store %"compiler/check:litv" %t621, ptr %l317
  br label %bb206
bb205:
  br label %bb207
bb206:
  %t622 = load %"compiler/check:litv", ptr %l317
  store %"compiler/check:litv" %t622, ptr %rv
  br label %ret
bb207:
  %t623 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t625 = trunc i64 85 to i32
  %t626 = icmp eq i32 %t623, %t625
  br i1 %t626, label %bb208, label %bb209
bb208:
  %t628 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t629 = load i64, ptr %t628, !tbaa !24
  %t630 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t631 = load i64, ptr %t630, !tbaa !24
  %t634 = and i64 %t629, %t631
  store i64 %t634, ptr %l320, !tbaa !24
  br label %bb213
bb209:
  %t636 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t638 = trunc i64 86 to i32
  %t639 = icmp eq i32 %t636, %t638
  br i1 %t639, label %bb210, label %bb211
bb210:
  %t641 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t642 = load i64, ptr %t641, !tbaa !24
  %t643 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t644 = load i64, ptr %t643, !tbaa !24
  %t647 = or i64 %t642, %t644
  store i64 %t647, ptr %l326, !tbaa !24
  br label %bb212
bb211:
  %t649 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t650 = load i64, ptr %t649, !tbaa !24
  %t651 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t652 = load i64, ptr %t651, !tbaa !24
  %t655 = xor i64 %t650, %t652
  store i64 %t655, ptr %l326, !tbaa !24
  br label %bb212
bb212:
  %t657 = load i64, ptr %l326, !tbaa !24
  store i64 %t657, ptr %l320, !tbaa !24
  br label %bb213
bb213:
  %t658 = load i64, ptr %l320, !tbaa !24
  store i64 %t658, ptr %l33, !tbaa !24
  %t659 = load i64, ptr %l33, !tbaa !24
  %t661 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t659)
  store %"compiler/check:litv" %t661, ptr %l334
  br label %bb214
bb214:
  %t662 = load %"compiler/check:litv", ptr %l334
  store %"compiler/check:litv" %t662, ptr %l34
  %t663 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t664 = load i1, ptr %t663, !tbaa !21
  br i1 %t664, label %bb215, label %bb216
bb215:
  store i1 true, ptr %l336, !tbaa !21
  br label %bb217
bb216:
  %t666 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t667 = load i1, ptr %t666, !tbaa !21
  store i1 %t667, ptr %l336, !tbaa !21
  br label %bb217
bb217:
  %t669 = load i1, ptr %l336, !tbaa !21
  br i1 %t669, label %bb218, label %bb219
bb218:
  %t670 = load i64, ptr %l33, !tbaa !24
  %t672 = icmp slt i64 %t670, 0
  store i1 %t672, ptr %l338, !tbaa !21
  br label %bb220
bb219:
  store i1 false, ptr %l338, !tbaa !21
  br label %bb220
bb220:
  %t674 = load i1, ptr %l338, !tbaa !21
  br i1 %t674, label %bb221, label %bb222
bb221:
  store %olang.scope zeroinitializer, ptr %s32
  %t675 = load i64, ptr %l33, !tbaa !24
  %t677 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s32, i1 true, i1 false, i1 true, i64 %t675, double 0x0000000000000000)
  store %"compiler/check:litv" %t677, ptr %l342
  br label %bb223
bb222:
  br label %bb224
bb223:
  %t678 = load %"compiler/check:litv", ptr %l342
  store %"compiler/check:litv" %t678, ptr %l34
  call void @__olang_scope_close(ptr %s32)
  br label %bb224
bb224:
  %t679 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 5
  %t680 = load i1, ptr %t679, !tbaa !21
  br i1 %t680, label %bb225, label %bb226
bb225:
  store i1 true, ptr %l344, !tbaa !21
  br label %bb227
bb226:
  %t682 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 5
  %t683 = load i1, ptr %t682, !tbaa !21
  store i1 %t683, ptr %l344, !tbaa !21
  br label %bb227
bb227:
  %t685 = load i1, ptr %l344, !tbaa !21
  %t686 = getelementptr %"compiler/check:litv", ptr %l34, i32 0, i32 5
  store i1 %t685, ptr %t686, !tbaa !21
  %t687 = load %"compiler/check:litv", ptr %l34
  store %"compiler/check:litv" %t687, ptr %rv
  br label %ret
bb228:
  %t689 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t691 = trunc i64 90 to i32
  %t692 = icmp eq i32 %t689, %t691
  br i1 %t692, label %bb229, label %bb230
bb229:
  store i1 true, ptr %l349, !tbaa !21
  br label %bb231
bb230:
  %t694 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t696 = trunc i64 91 to i32
  %t697 = icmp eq i32 %t694, %t696
  store i1 %t697, ptr %l349, !tbaa !21
  br label %bb231
bb231:
  %t699 = load i1, ptr %l349, !tbaa !21
  br i1 %t699, label %bb232, label %bb233
bb232:
  %t700 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t701 = load i1, ptr %t700, !tbaa !21
  %t703 = xor i1 %t701, true
  store i1 %t703, ptr %l352, !tbaa !21
  br label %bb234
bb233:
  store i1 false, ptr %l352, !tbaa !21
  br label %bb234
bb234:
  %t705 = load i1, ptr %l352, !tbaa !21
  br i1 %t705, label %bb235, label %bb236
bb235:
  %t706 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t707 = load i64, ptr %t706, !tbaa !24
  %t709 = icmp sge i64 %t707, 0
  store i1 %t709, ptr %l355, !tbaa !21
  br label %bb237
bb236:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb237
bb237:
  %t711 = load i1, ptr %l355, !tbaa !21
  br i1 %t711, label %bb238, label %bb239
bb238:
  %t712 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t713 = load i64, ptr %t712, !tbaa !24
  %t715 = icmp slt i64 %t713, 128
  store i1 %t715, ptr %l358, !tbaa !21
  br label %bb240
bb239:
  store i1 false, ptr %l358, !tbaa !21
  br label %bb240
bb240:
  %t717 = load i1, ptr %l358, !tbaa !21
  br i1 %t717, label %bb241, label %bb242
bb241:
  %t718 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t719 = load i64, ptr %t718, !tbaa !24
  %t721 = sext i64 %t719 to i128
  store i128 %t721, ptr %l35
  %t723 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t725 = trunc i64 90 to i32
  %t726 = icmp eq i32 %t723, %t725
  br i1 %t726, label %bb243, label %bb244
bb242:
  br label %bb279
bb243:
  %t728 = load i1, ptr %l27, !tbaa !21
  br i1 %t728, label %bb245, label %bb246
bb244:
  br label %bb263
bb245:
  %t730 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 5
  %t731 = load i1, ptr %t730, !tbaa !21
  store i1 %t731, ptr %l366, !tbaa !21
  br label %bb247
bb246:
  store i1 false, ptr %l366, !tbaa !21
  br label %bb247
bb247:
  %t733 = load i1, ptr %l366, !tbaa !21
  br i1 %t733, label %bb248, label %bb249
bb248:
  %t734 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 6
  %t735 = load i1, ptr %t734, !tbaa !21
  %t737 = xor i1 %t735, true
  store i1 %t737, ptr %l368, !tbaa !21
  br label %bb250
bb249:
  store i1 false, ptr %l368, !tbaa !21
  br label %bb250
bb250:
  %t739 = load i1, ptr %l368, !tbaa !21
  br i1 %t739, label %bb251, label %bb252
bb251:
  %t740 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t741 = load i64, ptr %t740, !tbaa !24
  %t744 = zext i64 %t741 to i128
  store i1 false, ptr %l27, !tbaa !21
  store i128 %t744, ptr %l28
  br label %bb253
bb252:
  br label %bb253
bb253:
  %t750 = load i1, ptr %l27, !tbaa !21
  br i1 %t750, label %bb254, label %bb255
bb254:
  %t752 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t752, ptr %l377
  br label %bb256
bb255:
  br label %bb257
bb256:
  %t753 = load %"compiler/check:litv", ptr %l377
  store %"compiler/check:litv" %t753, ptr %rv
  br label %ret
bb257:
  %t754 = load i128, ptr %l28
  %t755 = load i128, ptr %l35
  store i128 %t755, ptr %l379
  %t757 = load i128, ptr %l379
  %t758 = load i128, ptr %l379
  %t759 = shl i128 %t754, %t758
  store i128 %t759, ptr %l38
  %t761 = load i128, ptr %l38
  %t762 = load i128, ptr %l35
  store i128 %t762, ptr %l382
  %t764 = load i128, ptr %l382
  %t765 = load i128, ptr %l382
  %t766 = lshr i128 %t761, %t765
  %t767 = load i128, ptr %l28
  %t770 = icmp ne i128 %t766, %t767
  br i1 %t770, label %bb258, label %bb259
bb258:
  %t772 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t772, ptr %l386
  br label %bb260
bb259:
  br label %bb261
bb260:
  %t773 = load %"compiler/check:litv", ptr %l386
  store %"compiler/check:litv" %t773, ptr %rv
  br label %ret
bb261:
  %t774 = load i128, ptr %l38
  %t776 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t774)
  store %"compiler/check:litv" %t776, ptr %l388
  br label %bb262
bb262:
  %t777 = load %"compiler/check:litv", ptr %l388
  store %"compiler/check:litv" %t777, ptr %rv
  br label %ret
bb263:
  %t778 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 6
  %t779 = load i1, ptr %t778, !tbaa !21
  br i1 %t779, label %bb264, label %bb265
bb264:
  store i1 true, ptr %l390, !tbaa !21
  br label %bb266
bb265:
  %t781 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t782 = load i1, ptr %t781, !tbaa !21
  store i1 %t782, ptr %l390, !tbaa !21
  br label %bb266
bb266:
  %t784 = load i1, ptr %l390, !tbaa !21
  br i1 %t784, label %bb267, label %bb268
bb267:
  store i1 true, ptr %l392, !tbaa !21
  br label %bb269
bb268:
  %t785 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t786 = load i64, ptr %t785, !tbaa !24
  %t788 = icmp sge i64 %t786, 64
  store i1 %t788, ptr %l392, !tbaa !21
  br label %bb269
bb269:
  %t790 = load i1, ptr %l392, !tbaa !21
  br i1 %t790, label %bb270, label %bb271
bb270:
  %t791 = load i1, ptr %l27, !tbaa !21
  %t793 = xor i1 %t791, true
  br i1 %t793, label %bb272, label %bb273
bb271:
  br label %bb277
bb272:
  %t795 = load i128, ptr %l28
  %t796 = load i128, ptr %l35
  store i128 %t796, ptr %l398
  %t798 = load i128, ptr %l398
  %t799 = load i128, ptr %l398
  %t800 = lshr i128 %t795, %t799
  %t802 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t800)
  store %"compiler/check:litv" %t802, ptr %l400
  br label %bb274
bb273:
  br label %bb275
bb274:
  %t803 = load %"compiler/check:litv", ptr %l400
  store %"compiler/check:litv" %t803, ptr %rv
  br label %ret
bb275:
  %t804 = load i128, ptr %l28
  %t806 = sub i128 %t804, 1
  %t807 = load i128, ptr %l35
  store i128 %t807, ptr %l403
  %t809 = load i128, ptr %l403
  %t810 = load i128, ptr %l403
  %t811 = lshr i128 %t806, %t810
  %t813 = add i128 %t811, 1
  %t815 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 true, i128 %t813)
  store %"compiler/check:litv" %t815, ptr %l406
  br label %bb276
bb276:
  %t816 = load %"compiler/check:litv", ptr %l406
  store %"compiler/check:litv" %t816, ptr %rv
  br label %ret
bb277:
  %t817 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t818 = load i64, ptr %t817, !tbaa !24
  %t819 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t820 = load i64, ptr %t819, !tbaa !24
  store i64 %t820, ptr %l408, !tbaa !24
  %t822 = load i64, ptr %l408, !tbaa !24
  %t823 = load i64, ptr %l408, !tbaa !24
  %t824 = ashr i64 %t818, %t823
  %t826 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t824)
  store %"compiler/check:litv" %t826, ptr %l410
  br label %bb278
bb278:
  %t827 = load %"compiler/check:litv", ptr %l410
  store %"compiler/check:litv" %t827, ptr %rv
  br label %ret
bb279:
  %t828 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 6
  %t829 = load i1, ptr %t828, !tbaa !21
  br i1 %t829, label %bb280, label %bb281
bb280:
  store i1 true, ptr %l412, !tbaa !21
  br label %bb282
bb281:
  %t831 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 6
  %t832 = load i1, ptr %t831, !tbaa !21
  store i1 %t832, ptr %l412, !tbaa !21
  br label %bb282
bb282:
  %t834 = load i1, ptr %l412, !tbaa !21
  br i1 %t834, label %bb283, label %bb284
bb283:
  %t835 = load i128, ptr %l31
  %t837 = icmp eq i128 %t835, 0
  br i1 %t837, label %bb285, label %bb286
bb284:
  br label %bb298
bb285:
  %t839 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t839, ptr %l416
  br label %bb287
bb286:
  br label %bb288
bb287:
  %t840 = load %"compiler/check:litv", ptr %l416
  store %"compiler/check:litv" %t840, ptr %rv
  br label %ret
bb288:
  %t841 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t843 = trunc i64 56 to i32
  %t844 = icmp eq i32 %t841, %t843
  br i1 %t844, label %bb289, label %bb290
bb289:
  %t846 = load i1, ptr %l27, !tbaa !21
  %t847 = load i1, ptr %l30, !tbaa !21
  %t850 = icmp ne i1 %t846, %t847
  %t851 = load i128, ptr %l28
  %t852 = load i128, ptr %l31
  %t855 = udiv i128 %t851, %t852
  %t858 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t850, i128 %t855)
  store %"compiler/check:litv" %t858, ptr %l425
  br label %bb291
bb290:
  br label %bb292
bb291:
  %t859 = load %"compiler/check:litv", ptr %l425
  store %"compiler/check:litv" %t859, ptr %rv
  br label %ret
bb292:
  %t860 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t862 = trunc i64 57 to i32
  %t863 = icmp eq i32 %t860, %t862
  br i1 %t863, label %bb293, label %bb294
bb293:
  %t865 = load i1, ptr %l27, !tbaa !21
  %t866 = load i128, ptr %l28
  %t867 = load i128, ptr %l31
  %t870 = urem i128 %t866, %t867
  %t873 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t865, i128 %t870)
  store %"compiler/check:litv" %t873, ptr %l432
  br label %bb295
bb294:
  br label %bb296
bb295:
  %t874 = load %"compiler/check:litv", ptr %l432
  store %"compiler/check:litv" %t874, ptr %rv
  br label %ret
bb296:
  %t875 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t875, ptr %l433
  br label %bb297
bb297:
  %t876 = load %"compiler/check:litv", ptr %l433
  store %"compiler/check:litv" %t876, ptr %rv
  br label %ret
bb298:
  %t877 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 2
  %t878 = load i1, ptr %t877, !tbaa !21
  br i1 %t878, label %bb299, label %bb300
bb299:
  store i1 true, ptr %l435, !tbaa !21
  br label %bb301
bb300:
  %t880 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 2
  %t881 = load i1, ptr %t880, !tbaa !21
  store i1 %t881, ptr %l435, !tbaa !21
  br label %bb301
bb301:
  %t883 = load i1, ptr %l435, !tbaa !21
  br i1 %t883, label %bb302, label %bb303
bb302:
  %t884 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t884, ptr %l437
  br label %bb304
bb303:
  br label %bb305
bb304:
  %t885 = load %"compiler/check:litv", ptr %l437
  store %"compiler/check:litv" %t885, ptr %rv
  br label %ret
bb305:
  %t886 = getelementptr %"compiler/check:litv", ptr %l22, i32 0, i32 3
  %t887 = load i64, ptr %t886, !tbaa !24
  store i64 %t887, ptr %l39, !tbaa !24
  %t889 = getelementptr %"compiler/check:litv", ptr %l23, i32 0, i32 3
  %t890 = load i64, ptr %t889, !tbaa !24
  store i64 %t890, ptr %l40, !tbaa !24
  %t892 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t894 = trunc i64 56 to i32
  %t895 = icmp eq i32 %t892, %t894
  br i1 %t895, label %bb306, label %bb307
bb306:
  %t897 = load i64, ptr %l40, !tbaa !24
  %t899 = icmp ne i64 %t897, 0
  store i1 %t899, ptr %l442, !tbaa !21
  br label %bb308
bb307:
  store i1 false, ptr %l442, !tbaa !21
  br label %bb308
bb308:
  %t901 = load i1, ptr %l442, !tbaa !21
  br i1 %t901, label %bb309, label %bb310
bb309:
  %t902 = load i64, ptr %l39, !tbaa !24
  %t903 = sub i64 -9223372036854775807, 1
  %t906 = icmp eq i64 %t902, %t903
  br i1 %t906, label %bb311, label %bb312
bb310:
  store i1 false, ptr %l445, !tbaa !21
  br label %bb314
bb311:
  %t908 = load i64, ptr %l40, !tbaa !24
  %t910 = icmp eq i64 %t908, -1
  store i1 %t910, ptr %l449, !tbaa !21
  br label %bb313
bb312:
  store i1 false, ptr %l449, !tbaa !21
  br label %bb313
bb313:
  %t912 = load i1, ptr %l449, !tbaa !21
  %t913 = xor i1 %t912, true
  store i1 %t913, ptr %l445, !tbaa !21
  br label %bb314
bb314:
  %t915 = load i1, ptr %l445, !tbaa !21
  br i1 %t915, label %bb315, label %bb316
bb315:
  %t916 = load i64, ptr %l39, !tbaa !24
  %t917 = load i64, ptr %l40, !tbaa !24
  %t920 = sdiv i64 %t916, %t917
  %t922 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t920)
  store %"compiler/check:litv" %t922, ptr %l456
  br label %bb317
bb316:
  br label %bb318
bb317:
  %t923 = load %"compiler/check:litv", ptr %l456
  store %"compiler/check:litv" %t923, ptr %rv
  br label %ret
bb318:
  %t924 = load i32, ptr %l19, !range !{i32 0, i32 98}
  %t926 = trunc i64 57 to i32
  %t927 = icmp eq i32 %t924, %t926
  br i1 %t927, label %bb319, label %bb320
bb319:
  %t929 = load i64, ptr %l40, !tbaa !24
  %t931 = icmp ne i64 %t929, 0
  store i1 %t931, ptr %l459, !tbaa !21
  br label %bb321
bb320:
  store i1 false, ptr %l459, !tbaa !21
  br label %bb321
bb321:
  %t933 = load i1, ptr %l459, !tbaa !21
  br i1 %t933, label %bb322, label %bb323
bb322:
  %t934 = load i64, ptr %l40, !tbaa !24
  %t936 = icmp ne i64 %t934, -1
  store i1 %t936, ptr %l462, !tbaa !21
  br label %bb324
bb323:
  store i1 false, ptr %l462, !tbaa !21
  br label %bb324
bb324:
  %t938 = load i1, ptr %l462, !tbaa !21
  br i1 %t938, label %bb325, label %bb326
bb325:
  %t939 = load i64, ptr %l39, !tbaa !24
  %t940 = load i64, ptr %l40, !tbaa !24
  %t943 = srem i64 %t939, %t940
  %t945 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t943)
  store %"compiler/check:litv" %t945, ptr %l468
  br label %bb327
bb326:
  br label %bb328
bb327:
  %t946 = load %"compiler/check:litv", ptr %l468
  store %"compiler/check:litv" %t946, ptr %rv
  br label %ret
bb328:
  %t947 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t947, ptr %l469
  br label %bb329
bb329:
  %t948 = load %"compiler/check:litv", ptr %l469
  store %"compiler/check:litv" %t948, ptr %rv
  br label %ret
bb330:
  br i1 true, label %bb331, label %bb332
bb331:
  br label %bb333
bb332:
  br label %bb335
bb333:
  %t949 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t949, ptr %l470
  br label %bb334
bb334:
  %t950 = load %"compiler/check:litv", ptr %l470
  store %"compiler/check:litv" %t950, ptr %rv
  br label %ret
bb335:
  call void @__olang_check_failed(ptr @olang_loc_18ec9fb825b0f3da_76c21f303b4292b6)
  unreachable
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca ptr
  %l26 = alloca i64
  %lp27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca i64
  %l51 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i32
  %l68 = alloca i32
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l74 = alloca %"compiler/generic:Context"
  %l79 = alloca ptr
  %l82 = alloca ptr
  %l85 = alloca i32
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l91 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l98 = alloca i64
  %l103 = alloca ptr
  %l109 = alloca %"compiler/typed:Local"
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l120 = alloca %"compiler/typed:Local"
  %l121 = alloca i32
  %l124 = alloca ptr
  %l127 = alloca i32
  %l137 = alloca ptr
  %l138 = alloca %"compiler/typed:Capture"
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l156 = alloca i64
  %l158 = alloca i64
  %l163 = alloca i32
  %l170 = alloca %"compiler/typed:Local"
  %l173 = alloca i1
  %l176 = alloca { i64, ptr }
  %l177 = alloca i1
  %l178 = alloca ptr
  %l181 = alloca i64
  %l185 = alloca i64
  %l191 = alloca ptr
  %l194 = alloca i32
  %l195 = alloca i1
  %l197 = alloca ptr
  %l206 = alloca i32
  %l210 = alloca ptr
  %l214 = alloca i1
  %l217 = alloca i1
  %l218 = alloca i1
  %l221 = alloca i1
  %l230 = alloca ptr
  %l233 = alloca i1
  %l234 = alloca i1
  %l239 = alloca i1
  %l240 = alloca { i64, [1 x i64] }
  %l249 = alloca i64
  %l265 = alloca i1
  %l274 = alloca { i64, ptr }
  %l276 = alloca ptr
  %l289 = alloca { i64, ptr }
  %l290 = alloca %"compiler/typed:Block"
  %l292 = alloca i1
  %l301 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l310 = alloca ptr
  %l314 = alloca %"compiler/source:Span"
  %l315 = alloca ptr
  %l319 = alloca { i64, ptr }
  %l320 = alloca %"compiler/typed:Block"
  %l322 = alloca ptr
  %l326 = alloca ptr
  %l329 = alloca { i64, ptr }
  %l334 = alloca %"compiler/source:Span"
  %l335 = alloca i32
  %l338 = alloca i32
  %l339 = alloca { i64, ptr }
  %l343 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca ptr
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t88 = alloca %"compiler/generic:Context", align 8
  %t182 = alloca { i64, [1 x i64] }, align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  %t241 = alloca { i64, [1 x i64] }, align 8
  %t417 = alloca { i64, [4 x i64] }, align 8
  %t454 = alloca { i64, [1 x i64] }, align 8
  %t458 = alloca { i64, [1 x i64] }, align 8
  %t487 = alloca { i64, [3 x i64] }, align 8
  %t676 = alloca { i64, [4 x i64] }, align 8
  %t688 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 0
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l36
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l36, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 16
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l39
  br label %bb2
bb2:
  %t15 = load i64, ptr %l39, !tbaa !24
  %t16 = sub i64 %t15, 1
  store i64 %t16, ptr %l7, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l6, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = trunc i64 %t22 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 4, ptr %t27
  %t29 = insertvalue { i32 } undef, i32 %t24, 0
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  store { i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t26
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l6, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load %"compiler/source:Span", ptr %l5
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t18, { i64, [2 x i64] } %t31, i32 %t32, i64 %t36, %"compiler/source:Span" %t37)
  store i64 %t43, ptr %l51
  br label %bb3
bb3:
  %t44 = load i64, ptr %l51, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 19
  %t48 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t47, i64 %t48, i64 1)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l55, !tbaa !29
  %t52 = load i64, ptr %l8, !tbaa !24
  store i64 %t52, ptr %l56, !tbaa !24
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l58, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l63
  br label %bb5
bb5:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l68
  br label %bb6
bb6:
  %t77 = load ptr, ptr %l55, !tbaa !29
  %t78 = load i64, ptr %l56, !tbaa !24
  %t79 = load i64, ptr %l58, !tbaa !24
  %t80 = load i32, ptr %l63, !tbaa !23
  %t81 = load i32, ptr %l68, !tbaa !23
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t77, i64 %t78, i64 %t79, i32 %t80, i32 %t81)
  store ptr %t82, ptr %l69
  br label %bb7
bb7:
  %t83 = load ptr, ptr %l69, !tbaa !29
  store ptr %t83, ptr %l9, !tbaa !29
  %t84 = load ptr, ptr %l9, !tbaa !29
  store ptr %t84, ptr %l70, !tbaa !29
  %t85 = load ptr, ptr %l6, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t87, i64 160, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t88, ptr %v0, ptr %l72)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t88, i64 160, i1 false)
  br label %bb8
bb8:
  %t90 = load ptr, ptr %l70, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %l74, i64 160, i1 false)
  %t92 = load ptr, ptr %l9, !tbaa !29
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 19
  store i64 %t93, ptr %t96, !tbaa !24
  %t97 = load ptr, ptr %l9, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 20
  store i1 true, ptr %t99, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t100)
  store ptr %t102, ptr %l79
  br label %bb9
bb9:
  %t103 = load ptr, ptr %l79, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 14
  store i1 true, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t106)
  store ptr %t108, ptr %l82
  br label %bb10
bb10:
  %t109 = load %"compiler/source:Span", ptr %l5
  %t110 = load ptr, ptr %l82, !tbaa !29
  %t113 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t110, i32 -1, i32 0, %"compiler/source:Span" %t109)
  store i32 %t113, ptr %l85
  br label %bb11
bb11:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t114)
  store ptr %t116, ptr %l87
  br label %bb12
bb12:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  store ptr %t120, ptr %l89, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t121)
  store ptr %t123, ptr %l91
  br label %bb13
bb13:
  %t124 = load ptr, ptr %l91, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %t126, !tbaa !23
  %t128 = load ptr, ptr %l89, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t128, i32 %t127)
  store { i64, ptr } %t130, ptr %l94
  br label %bb14
bb14:
  %t131 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 8
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t138 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t138, { i64, ptr } %t137)
  br label %bb15
bb15:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 37
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t142)
  store i64 %t144, ptr %l98
  br label %bb16
bb16:
  %t145 = load i64, ptr %l98, !tbaa !24
  store i64 %t145, ptr %l10, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 14
  %t149 = load ptr, ptr %l6, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t155 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t148, i64 %t152)
  store ptr %t155, ptr %l103
  br label %bb17
bb17:
  %t156 = load ptr, ptr %l103, !tbaa !29
  store ptr %t156, ptr %l11, !tbaa !29
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = icmp sge i64 %t157, 0
  br i1 %t159, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s1
  %t161 = load ptr, ptr %l11, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 7
  %t164 = load i64, ptr %l4, !tbaa !24
  %t167 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t163, i64 %t164)
  store %"compiler/typed:Local" %t167, ptr %l109
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t168 = getelementptr %"compiler/typed:Local", ptr %l109, i32 0, i32 2
  %t169 = load i32, ptr %t168, !tbaa !23
  store i32 %t169, ptr %l12, !tbaa !23
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 14
  %t174 = load i64, ptr %l8, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l114
  br label %bb21
bb21:
  %t178 = load ptr, ptr %l114, !tbaa !29
  store ptr %t178, ptr %l13, !tbaa !29
  %t179 = load ptr, ptr %l13, !tbaa !29
  store ptr %t179, ptr %l115, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l5
  %t181 = load i32, ptr %l12, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [1 x i64] }, ptr %t182, i32 0, i32 0
  store i64 4, ptr %t183
  %t184 = load { i64, [1 x i64] }, ptr %t182
  %t189 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s1, i32 0, %"compiler/source:Span" %t180, i32 %t181, i32 0, i32 5, { i64, [1 x i64] } %t184)
  store %"compiler/typed:Local" %t189, ptr %l120
  br label %bb22
bb22:
  %t190 = load ptr, ptr %l115, !tbaa !29
  %t191 = load %"compiler/typed:Local", ptr %l120
  %t192 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t190, %"compiler/typed:Local" %t191)
  store i32 %t192, ptr %l121
  br label %bb23
bb23:
  %t193 = load i32, ptr %l121, !tbaa !23
  %t194 = sext i32 %t193 to i64
  store i64 %t194, ptr %l14, !tbaa !24
  %t196 = load ptr, ptr %l9, !tbaa !29
  %t198 = getelementptr %"compiler/check:frame", ptr %t196, i32 0, i32 30
  store ptr %t198, ptr %l124, !tbaa !29
  %t199 = load i64, ptr %l14, !tbaa !24
  %t201 = trunc i64 %t199 to i32
  store i32 %t201, ptr %l127, !tbaa !23
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load %"compiler/source:Span", ptr %l5
  %t205 = load %"compiler/source:Span", ptr %l5
  %t206 = load i32, ptr %l12, !tbaa !23
  %t207 = load i64, ptr %l4, !tbaa !24
  %t209 = trunc i64 %t207 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 0, ptr %t212
  %t214 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t205, 0
  %t216 = insertvalue { %"compiler/source:Span", i32, i32 } %t214, i32 %t206, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, i32 } %t216, i32 %t209, 2
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t218, ptr %t219
  %t220 = load { i64, [4 x i64] }, ptr %t211
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t220, ptr %t222
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t203, %"compiler/source:Span" %t204, ptr %t222)
  store ptr %t226, ptr %l137
  br label %bb24
bb24:
  %t227 = load i32, ptr %l127, !tbaa !23
  %t228 = load ptr, ptr %l137, !tbaa !29
  %t229 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t227, ptr %t228)
  store %"compiler/typed:Capture" %t229, ptr %l138
  br label %bb25
bb25:
  %t230 = load %"compiler/typed:Capture", ptr %l138
  %t231 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t230, ptr %t231
  %t232 = load ptr, ptr %l124, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t232, ptr %t231)
  br label %bb26
bb26:
  %t234 = load ptr, ptr %l13, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Body", ptr %t234, i32 0, i32 6
  %t237 = load i64, ptr %l14, !tbaa !24
  %t239 = trunc i64 %t237 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [1 x i64] }, ptr %t241, i32 0, i32 0
  store i64 4, ptr %t242
  %t244 = insertvalue { i32 } undef, i32 %t239, 0
  %t245 = getelementptr { i64, [1 x i64] }, ptr %t241, i32 0, i32 1
  store { i32 } %t244, ptr %t245
  %t246 = load { i64, [1 x i64] }, ptr %t241
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t236, { i64, [1 x i64] } %t246)
  br label %bb27
bb27:
  %t249 = load ptr, ptr %l13, !tbaa !29
  %t250 = load i64, ptr %l14, !tbaa !24
  %t252 = trunc i64 %t250 to i32
  %t256 = getelementptr %"compiler/typed:Body", ptr %t249, i32 0, i32 15
  store i32 %t252, ptr %t256, !tbaa !23
  %t257 = load ptr, ptr %l13, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Body", ptr %t257, i32 0, i32 16
  store i1 true, ptr %t259, !tbaa !21
  %t260 = load ptr, ptr %l9, !tbaa !29
  %t261 = load i64, ptr %l14, !tbaa !24
  %t264 = getelementptr %"compiler/check:frame", ptr %t260, i32 0, i32 21
  store i64 %t261, ptr %t264, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb28
bb28:
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l153
  br label %bb29
bb29:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %l15
  store i1 true, ptr %l16, !tbaa !21
  store i64 -1, ptr %l17, !tbaa !24
  %t267 = load ptr, ptr %l11, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 5
  store ptr %t269, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t271 = load i64, ptr %l19, !tbaa !24
  store i64 %t271, ptr %l156, !tbaa !24
  %t272 = load ptr, ptr %l18, !tbaa !29
  %t274 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t272)
  store i64 %t274, ptr %l158
  br label %bb31
bb31:
  %t275 = load i64, ptr %l156, !tbaa !24
  %t276 = load i64, ptr %l158, !tbaa !24
  %t277 = icmp slt i64 %t275, %t276
  %t279 = xor i1 %t277, true
  br i1 %t279, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb86
bb33:
  br label %bb34
bb34:
  %t281 = load ptr, ptr %l18, !tbaa !29
  %t282 = load i64, ptr %l19, !tbaa !24
  %t285 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t281, i64 %t282)
  store i32 %t285, ptr %l163
  br label %bb35
bb35:
  %t286 = load i32, ptr %l163, !tbaa !23
  %t287 = load i64, ptr %l17, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l17, !tbaa !24
  %t291 = load ptr, ptr %l11, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Body", ptr %t291, i32 0, i32 7
  %t296 = sext i32 %t286 to i64
  %t299 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t293, i64 %t296)
  store %"compiler/typed:Local" %t299, ptr %l170
  br label %bb36
bb36:
  %t300 = load %"compiler/typed:Local", ptr %l170
  store %"compiler/typed:Local" %t300, ptr %l21
  %t301 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t302 = load i32, ptr %t301, !tbaa !23
  %t304 = icmp eq i32 %t302, 0
  br i1 %t304, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb41
bb38:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t308 = load i32, ptr %t307, !tbaa !23
  %t311 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t306, i32 %t308)
  store { i64, ptr } %t311, ptr %l176
  br label %bb39
bb39:
  %t312 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t313 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t312, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t313, ptr %l177
  br label %bb40
bb40:
  %t314 = load i1, ptr %l177, !tbaa !21
  store i1 %t314, ptr %l173, !tbaa !21
  br label %bb41
bb41:
  %t315 = load i1, ptr %l173, !tbaa !21
  br i1 %t315, label %bb42, label %bb43
bb42:
  store i1 false, ptr %l16, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb85
bb43:
  br label %bb44
bb44:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l178, !tbaa !29
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 16
  %t321 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %t319)
  store i64 %t321, ptr %l181
  br label %bb45
bb45:
  %t322 = load i64, ptr %l181, !tbaa !24
  %t323 = sub i64 %t322, 1
  %t324 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t325 = load i32, ptr %t324, !tbaa !23
  %t326 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t327 = load %"compiler/source:Span", ptr %t326
  %t328 = load ptr, ptr %l178, !tbaa !29
  %t332 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t328, i64 %t323, i32 %t325, %"compiler/source:Span" %t327)
  store i64 %t332, ptr %l185
  br label %bb46
bb46:
  %t333 = load i64, ptr %l185, !tbaa !24
  store i64 %t333, ptr %l22, !tbaa !24
  %t334 = load i64, ptr %l22, !tbaa !24
  %t336 = icmp slt i64 %t334, 0
  br i1 %t336, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb85
bb48:
  br label %bb49
bb49:
  %t338 = load i64, ptr %l17, !tbaa !24
  %t342 = icmp eq i64 %t338, %a3
  br i1 %t342, label %bb50, label %bb51
bb50:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l191, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l22, !tbaa !24
  %t349 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t345, i64 %t346)
  store i32 %t349, ptr %l194
  br label %bb52
bb51:
  br label %bb59
bb52:
  %t350 = load ptr, ptr %l191, !tbaa !29
  %t351 = load i32, ptr %l194, !tbaa !23
  %t352 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t350, i32 %t351)
  store i1 %t352, ptr %l195
  br label %bb53
bb53:
  %t353 = load i1, ptr %l195, !tbaa !21
  br i1 %t353, label %bb54, label %bb55
bb54:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t354)
  store ptr %t356, ptr %l197
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t359 = load %"compiler/source:Span", ptr %t358
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s8, ptr %t357, %"compiler/source:Span" %t359, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb57
bb56:
  %t362 = load ptr, ptr %l197, !tbaa !29
  %t363 = load i64, ptr %l22, !tbaa !24
  %t365 = trunc i64 %t363 to i32
  %t369 = getelementptr %"compiler/typed:Body", ptr %t362, i32 0, i32 15
  store i32 %t365, ptr %t369, !tbaa !23
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i64, ptr %l22, !tbaa !24
  %t374 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t370, i64 %t371)
  store i32 %t374, ptr %l206
  br label %bb60
bb60:
  %t375 = load i32, ptr %l206, !tbaa !23
  store i32 %t375, ptr %l23, !tbaa !23
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t378 = load %"compiler/source:Span", ptr %t377
  %t379 = load i64, ptr %l22, !tbaa !24
  %t383 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t376, %"compiler/source:Span" %t378, i64 %t379)
  store ptr %t383, ptr %l210
  br label %bb61
bb61:
  %t384 = load ptr, ptr %l210, !tbaa !29
  store ptr %t384, ptr %l24, !tbaa !29
  %t385 = load i32, ptr %l23, !tbaa !23
  %t386 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t387 = load i32, ptr %t386, !tbaa !23
  %t390 = icmp ne i32 %t385, %t387
  br i1 %t390, label %bb62, label %bb63
bb62:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load i32, ptr %l23, !tbaa !23
  %t396 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t392, i32 %t393)
  store i1 %t396, ptr %l217
  br label %bb64
bb63:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb65
bb64:
  %t397 = load i1, ptr %l217, !tbaa !21
  store i1 %t397, ptr %l214, !tbaa !21
  br label %bb65
bb65:
  %t398 = load i1, ptr %l214, !tbaa !21
  br i1 %t398, label %bb66, label %bb67
bb66:
  %t399 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t401 = load i32, ptr %t400, !tbaa !23
  %t404 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t399, i32 %t401)
  store i1 %t404, ptr %l221
  br label %bb68
bb67:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb69
bb68:
  %t405 = load i1, ptr %l221, !tbaa !21
  %t406 = xor i1 %t405, true
  store i1 %t406, ptr %l218, !tbaa !21
  br label %bb69
bb69:
  %t408 = load i1, ptr %l218, !tbaa !21
  br i1 %t408, label %bb70, label %bb71
bb70:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t411 = load %"compiler/source:Span", ptr %t410
  %t412 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t413 = load %"compiler/source:Span", ptr %t412
  %t414 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t415 = load i32, ptr %t414, !tbaa !23
  %t416 = load ptr, ptr %l24, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t417
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 0
  store i64 2, ptr %t418
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t413, 0
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, i32 %t415, 1
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr } %t422, ptr %t416, 2
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t424, ptr %t425
  %t426 = load { i64, [4 x i64] }, ptr %t417
  %t428 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t426, ptr %t428
  %t432 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v0, ptr %v0, ptr %t409, %"compiler/source:Span" %t411, ptr %t428)
  store ptr %t432, ptr %l230
  br label %bb72
bb71:
  br label %bb73
bb72:
  %t433 = load ptr, ptr %l230, !tbaa !29
  store ptr %t433, ptr %l24, !tbaa !29
  br label %bb73
bb73:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t436 = load i32, ptr %t435, !tbaa !23
  %t439 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t434, i32 %t436)
  store i1 %t439, ptr %l233
  br label %bb74
bb74:
  %t440 = load i1, ptr %l233, !tbaa !21
  br i1 %t440, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l234, !tbaa !21
  br label %bb78
bb76:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t443 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !29
  %t446 = getelementptr %"compiler/generic:Program", ptr %t444, i32 0, i32 2
  %t447 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t448 = load i32, ptr %t447, !tbaa !23
  %t451 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t446, i32 %t448)
  store i1 %t451, ptr %l239
  br label %bb77
bb77:
  %t452 = load i1, ptr %l239, !tbaa !21
  store i1 %t452, ptr %l234, !tbaa !21
  br label %bb78
bb78:
  %t453 = load i1, ptr %l234, !tbaa !21
  br i1 %t453, label %bb79, label %bb80
bb79:
  store { i64, [1 x i64] } zeroinitializer, ptr %t454
  %t455 = getelementptr { i64, [1 x i64] }, ptr %t454, i32 0, i32 0
  store i64 4, ptr %t455
  %t456 = load { i64, [1 x i64] }, ptr %t454
  store { i64, [1 x i64] } %t456, ptr %l240
  br label %bb81
bb80:
  store { i64, [1 x i64] } zeroinitializer, ptr %t458
  %t459 = getelementptr { i64, [1 x i64] }, ptr %t458, i32 0, i32 0
  store i64 0, ptr %t459
  %t460 = load { i64, [1 x i64] }, ptr %t458
  store { i64, [1 x i64] } %t460, ptr %l240
  br label %bb81
bb81:
  %t462 = load { i64, [1 x i64] }, ptr %l240
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 0
  %t465 = load i32, ptr %t464, !tbaa !23
  %t466 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t467 = load %"compiler/source:Span", ptr %t466
  %t468 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 2
  %t469 = load i32, ptr %t468, !tbaa !23
  %t477 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t463, i32 %t465, %"compiler/source:Span" %t467, i32 %t469, i32 1, { i64, [1 x i64] } %t462)
  store i64 %t477, ptr %l249
  br label %bb82
bb82:
  %t478 = load i64, ptr %l249, !tbaa !24
  store i64 %t478, ptr %l26, !tbaa !24
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/typed:Local", ptr %l21, i32 0, i32 1
  %t481 = load %"compiler/source:Span", ptr %t480
  %t482 = load i64, ptr %l26, !tbaa !24
  %t484 = trunc i64 %t482 to i32
  %t486 = load ptr, ptr %l24, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t487
  %t488 = getelementptr { i64, [3 x i64] }, ptr %t487, i32 0, i32 0
  store i64 0, ptr %t488
  %t490 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t481, 0
  %t492 = insertvalue { %"compiler/source:Span", i32, ptr } %t490, i32 %t484, 1
  %t494 = insertvalue { %"compiler/source:Span", i32, ptr } %t492, ptr %t486, 2
  %t495 = getelementptr { i64, [3 x i64] }, ptr %t487, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t494, ptr %t495
  %t496 = load { i64, [3 x i64] }, ptr %t487
  %t498 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t496, ptr %t498
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t479, ptr %t498)
  br label %bb83
bb83:
  %t501 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l15, i64 %t501)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s3)
  br label %bb85
bb85:
  %t504 = load i64, ptr %l19, !tbaa !24
  %t506 = add i64 %t504, 1
  store i64 %t506, ptr %l19, !tbaa !24
  br label %bb30
bb86:
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load ptr, ptr %l6, !tbaa !29
  %t511 = getelementptr %"compiler/check:frame", ptr %t509, i32 0, i32 0
  %t512 = load i64, ptr %t511, !tbaa !24
  %t515 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t508, i64 %t512)
  store i1 %t515, ptr %l265
  br label %bb87
bb87:
  %t516 = load i1, ptr %l265, !tbaa !21
  br i1 %t516, label %bb88, label %bb89
bb88:
  %t517 = load i1, ptr %l16, !tbaa !21
  br i1 %t517, label %bb90, label %bb91
bb89:
  br label %bb95
bb90:
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %l6, !tbaa !29
  %t522 = getelementptr %"compiler/check:frame", ptr %t520, i32 0, i32 0
  %t523 = load i64, ptr %t522, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %s0, ptr %t519, i64 %t523, ptr %l15, i1 true)
  br label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s13
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s13, ptr %t527, %"compiler/source:Span" %t528, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s13)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t531 = load ptr, ptr %l1, !tbaa !29
  %t533 = getelementptr %"compiler/ast:Func", ptr %t531, i32 0, i32 4
  %t534 = load { i64, ptr }, ptr %t533, !tbaa !27
  store { i64, ptr } %t534, ptr %l274, !tbaa !27
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t535)
  store ptr %t537, ptr %l276
  br label %bb96
bb96:
  %t538 = load ptr, ptr %l276, !tbaa !29
  %t540 = getelementptr %"compiler/check:frame", ptr %t538, i32 0, i32 43
  %t541 = load { i64, ptr }, ptr %l274, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t541, ptr %t540)
  br label %bb97
bb97:
  %t543 = load ptr, ptr %l1, !tbaa !29
  %t545 = getelementptr %"compiler/ast:Func", ptr %t543, i32 0, i32 4
  %t546 = load { i64, ptr }, ptr %t545, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t550 = icmp sgt i64 %t548, 0
  br i1 %t550, label %bb98, label %bb99
bb98:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load ptr, ptr %l1, !tbaa !29
  %t555 = getelementptr %"compiler/ast:Func", ptr %t553, i32 0, i32 4
  %t556 = load { i64, ptr }, ptr %t555, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t552, { i64, ptr } %t556)
  br label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb101
bb101:
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 37
  %t562 = load i64, ptr %l10, !tbaa !24
  %t565 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t561, i64 %t562)
  store { i64, ptr } %t565, ptr %l289
  br label %bb102
bb102:
  %t566 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t567 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t566)
  store %"compiler/typed:Block" %t567, ptr %l290
  br label %bb103
bb103:
  %t568 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t568, ptr %lp27
  %t569 = load %"compiler/typed:Block", ptr %l290
  %t570 = load ptr, ptr %lp27
  store %"compiler/typed:Block" %t569, ptr %t570
  %t571 = load ptr, ptr %lp27
  %t573 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t571)
  store i1 %t573, ptr %l292
  br label %bb104
bb104:
  %t574 = load i1, ptr %l292, !tbaa !21
  %t575 = xor i1 %t574, true
  br i1 %t575, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s15
  %t577 = load ptr, ptr %lp27
  %t578 = getelementptr %"compiler/typed:Block", ptr %t577, i32 0, i32 1
  %t579 = load { i64, ptr }, ptr %t578, !tbaa !27
  store { i64, ptr } %t579, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t581 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t583 = extractvalue { i64, ptr } %t581, 0
  store i64 %t583, ptr %l30, !tbaa !24
  br label %bb107
bb106:
  br label %bb119
bb107:
  %t585 = load i64, ptr %l29, !tbaa !24
  %t586 = load i64, ptr %l30, !tbaa !24
  %t589 = icmp slt i64 %t585, %t586
  %t591 = xor i1 %t589, true
  br i1 %t591, label %bb108, label %bb109
bb108:
  br label %bb113
bb109:
  br label %bb110
bb110:
  %t593 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t593, ptr %l301, !tbaa !27
  %t594 = load i64, ptr %l29, !tbaa !24
  %t596 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr ptr, ptr %t597, i64 %t594
  %t599 = load ptr, ptr %t598, !tbaa !39
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t603 = getelementptr %"compiler/check:Checker", ptr %t601, i32 0, i32 37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t603, ptr %t599)
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t607 = load i64, ptr %l29, !tbaa !24
  %t609 = add i64 %t607, 1
  store i64 %t609, ptr %l29, !tbaa !24
  br label %bb107
bb113:
  %t611 = load ptr, ptr %l0, !tbaa !29
  store ptr %t611, ptr %l309, !tbaa !29
  %t612 = load ptr, ptr %l0, !tbaa !29
  store ptr %t612, ptr %l310, !tbaa !29
  %t613 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t614 = load i32, ptr %t613, !tbaa !23
  %t616 = sub i32 %t614, 1
  %t617 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t618 = load i32, ptr %t617, !tbaa !23
  %t621 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s15, i32 %t616, i32 %t618)
  store %"compiler/source:Span" %t621, ptr %l314
  br label %bb114
bb114:
  %t622 = load ptr, ptr %l310, !tbaa !29
  %t623 = load %"compiler/source:Span", ptr %l314
  %t624 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v0, ptr %t622, %"compiler/source:Span" %t623)
  store ptr %t624, ptr %l315
  br label %bb115
bb115:
  %t625 = load ptr, ptr %l309, !tbaa !29
  %t626 = load ptr, ptr %l315, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t625, ptr %t626)
  br label %bb116
bb116:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t629 = getelementptr %"compiler/check:Checker", ptr %t627, i32 0, i32 37
  %t630 = load i64, ptr %l10, !tbaa !24
  %t633 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t629, i64 %t630)
  store { i64, ptr } %t633, ptr %l319
  br label %bb117
bb117:
  %t634 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t635 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t634)
  store %"compiler/typed:Block" %t635, ptr %l320
  br label %bb118
bb118:
  %t636 = load %"compiler/typed:Block", ptr %l320
  %t637 = load ptr, ptr %lp27
  store %"compiler/typed:Block" %t636, ptr %t637
  call void @__olang_scope_close(ptr %s15)
  br label %bb119
bb119:
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t640 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t638)
  store ptr %t640, ptr %l322
  br label %bb120
bb120:
  %t641 = load ptr, ptr %l322, !tbaa !29
  %t642 = load ptr, ptr %lp27
  %t645 = getelementptr %"compiler/typed:Body", ptr %t641, i32 0, i32 11
  store ptr %t642, ptr %t645, !tbaa !29
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t646)
  store ptr %t648, ptr %l326
  br label %bb121
bb121:
  %t649 = load ptr, ptr %l326, !tbaa !29
  %t651 = getelementptr %"compiler/check:frame", ptr %t649, i32 0, i32 30
  %t653 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v2, ptr %t651)
  store { i64, ptr } %t653, ptr %l329
  br label %bb122
bb122:
  %t654 = load { i64, ptr }, ptr %l329, !tbaa !27
  store { i64, ptr } %t654, ptr %l32, !tbaa !27
  %t655 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t655)
  br label %bb123
bb123:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/check:Checker", ptr %t657, i32 0, i32 19
  %t660 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t659, i64 %t660, i64 2)
  br label %bb124
bb124:
  %t663 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t663, ptr %l334
  %t664 = load i32, ptr %l2, !tbaa !23
  store i32 %t664, ptr %l335, !tbaa !23
  %t665 = load i64, ptr %l8, !tbaa !24
  %t667 = trunc i64 %t665 to i32
  store i32 %t667, ptr %l338, !tbaa !23
  %t669 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t669, ptr %l339, !tbaa !27
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t671 = load %"compiler/source:Span", ptr %l5
  %t675 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t670, i32 5, %"compiler/source:Span" %t671)
  store i32 %t675, ptr %l343
  br label %bb125
bb125:
  store { i64, [4 x i64] } zeroinitializer, ptr %t676
  %t677 = getelementptr { i64, [4 x i64] }, ptr %t676, i32 0, i32 0
  store i64 1, ptr %t677
  %t678 = load i32, ptr %l338, !tbaa !23
  %t679 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t678, 0
  %t680 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t681 = insertvalue { i32, { i64, ptr }, i32 } %t679, { i64, ptr } %t680, 1
  %t682 = load i32, ptr %l343, !tbaa !23
  %t683 = insertvalue { i32, { i64, ptr }, i32 } %t681, i32 %t682, 2
  %t684 = getelementptr { i64, [4 x i64] }, ptr %t676, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t683, ptr %t684
  %t685 = load { i64, [4 x i64] }, ptr %t676
  %t687 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t685, ptr %t687
  store { i64, [5 x i64] } zeroinitializer, ptr %t688
  %t689 = getelementptr { i64, [5 x i64] }, ptr %t688, i32 0, i32 0
  store i64 15, ptr %t689
  %t690 = load %"compiler/source:Span", ptr %l334
  %t691 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t690, 0
  %t692 = load i32, ptr %l335, !tbaa !23
  %t693 = insertvalue { %"compiler/source:Span", i32, ptr } %t691, i32 %t692, 1
  %t695 = insertvalue { %"compiler/source:Span", i32, ptr } %t693, ptr %t687, 2
  %t696 = getelementptr { i64, [5 x i64] }, ptr %t688, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t695, ptr %t696
  %t697 = load { i64, [5 x i64] }, ptr %t688
  %t699 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t697, ptr %t699
  call void @__olang_scope_close(ptr %s0)
  store ptr %t699, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l41 = alloca i64
  %l44 = alloca i64
  %l63 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l77 = alloca { i64, [2 x i64] }
  %l82 = alloca i32
  %l85 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t133 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l16
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 27
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store ptr %t37, ptr %l30
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l30, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t39, ptr %l31
  br label %bb10
bb10:
  %t40 = load %"compiler/source:Span", ptr %l31
  store %"compiler/source:Span" %t40, ptr %l6
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb11, label %bb12
bb11:
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr %"compiler/ast:VarDecl", ptr %t47, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = icmp sgt i64 %t54, %t55
  br i1 %t58, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp sgt i64 %t60, 0
  br i1 %t62, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb15:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t68 = sub i64 %t64, %t65
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = add i64 %t68, %t69
  %t74 = sub i64 %t72, 1
  %t75 = load i64, ptr %l9, !tbaa !24
  %t78 = sdiv i64 %t74, %t75
  store i64 %t78, ptr %l44, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb17
bb17:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t81 = load i64, ptr %l41, !tbaa !24
  store i64 %t81, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t82 = load i64, ptr %l11, !tbaa !24
  %t83 = load i64, ptr %l10, !tbaa !24
  %t86 = icmp slt i64 %t82, %t83
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb20, label %bb21
bb20:
  br label %bb27
bb21:
  br label %bb22
bb22:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = mul i64 %t91, %t92
  %t98 = add i64 %t90, %t95
  store i64 %t98, ptr %l12, !tbaa !24
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t102 = getelementptr %"compiler/ast:VarDecl", ptr %t100, i32 0, i32 0
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l63, !tbaa !27
  %t104 = load i64, ptr %l12, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = icmp eq i32 %t109, %t110
  br i1 %t113, label %bb23, label %bb24
bb23:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr %"compiler/ast:VarDecl", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l69, !tbaa !27
  %t119 = load i64, ptr %l12, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/source:Span", ptr %t122, i64 %t119
  %t124 = load %"compiler/source:Span", ptr %t123
  store %"compiler/source:Span" %t124, ptr %l6
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l11, !tbaa !24
  br label %bb19
bb27:
  br label %bb28
bb28:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l74, !tbaa !29
  %t131 = load i64, ptr %l1, !tbaa !24
  %t132 = load i32, ptr %l2, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t133
  %t134 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 0
  store i64 6, ptr %t134
  %t136 = insertvalue { i64, i32 } undef, i64 %t131, 0
  %t138 = insertvalue { i64, i32 } %t136, i32 %t132, 1
  %t139 = getelementptr { i64, [2 x i64] }, ptr %t133, i32 0, i32 1
  store { i64, i32 } %t138, ptr %t139
  %t140 = load { i64, [2 x i64] }, ptr %t133
  store { i64, [2 x i64] } %t140, ptr %l77
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  %t147 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t146, i32 0, i32 %t147, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t150, ptr %l82
  br label %bb29
bb29:
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load %"compiler/source:Span", ptr %l6
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load { i64, [2 x i64] }, ptr %l77
  %t155 = load i32, ptr %l82, !tbaa !23
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t153, { i64, [2 x i64] } %t154, i32 %t155, i64 %t151, %"compiler/source:Span" %t152)
  store i64 %t158, ptr %l85
  br label %bb30
bb30:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l4, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 27
  %t163 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t164 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t162, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t163, i64 %t164)
  br label %bb31
bb31:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %t168, i64 %t169)
  br label %bb32
bb32:
  %t172 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t172, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l11 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l24 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/generic:Context"
  %l39 = alloca i32
  %l45 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca i1
  %l57 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i32
  %l70 = alloca i32
  %l71 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  %t59 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i32, ptr %l2, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t7 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t1, i64 %t4)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l3
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 28
  %t12 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t15 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t11, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t12)
  %t16 = extractvalue { i32, i32 } %t15, 1
  %t17 = extractvalue { i32, i32 } %t15, 0
  store i32 %t17, ptr %l16
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t20 = load i32, ptr %l15, !tbaa !23
  store i32 %t20, ptr %l11, !tbaa !23
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l11, !tbaa !23
  br label %bb5
bb5:
  %t21 = load i32, ptr %l11, !tbaa !23
  store i32 %t21, ptr %l4, !tbaa !23
  %t22 = load i32, ptr %l4, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t26, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i32, ptr %l2, !tbaa !23
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v0, ptr %t31, i64 %t32, i32 %t33)
  store ptr %t37, ptr %l24
  br label %bb9
bb9:
  %t38 = load ptr, ptr %l24, !tbaa !29
  store ptr %t38, ptr %l5, !tbaa !29
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb10, label %bb11
bb10:
  %t43 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t43, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l5, !tbaa !29
  %t47 = getelementptr %"compiler/ast:VarDecl", ptr %t45, i32 0, i32 2
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t59, ptr %s3, i64 %t58, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t59, i64 160, i1 false)
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t61 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 160, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %l35, i64 160, i1 false)
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t63 = load i32, ptr %l2, !tbaa !23
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t68 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s3, ptr %v0, ptr %t64, ptr %t61, ptr %t62, i32 %t63)
  store i32 %t68, ptr %l39
  br label %bb16
bb16:
  %t69 = load i32, ptr %l39, !tbaa !23
  store i32 %t69, ptr %l4, !tbaa !23
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 28
  %t73 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t74 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %t72, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t73, i32 %t74)
  br label %bb17
bb17:
  %t78 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t78, ptr %rv
  br label %ret
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 27
  %t83 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t86 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t82, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t83)
  %t87 = extractvalue { i32, i64 } %t86, 1
  %t88 = extractvalue { i32, i64 } %t86, 0
  store i32 %t88, ptr %l50
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb20, label %ok.90, !prof !99
ok.90:
  store i64 %t87, ptr %l49
  br label %bb19
bb19:
  %t91 = load i64, ptr %l49, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb22
bb22:
  %t92 = load i64, ptr %l45, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sge i64 %t93, 0
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 19
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100)
  store i64 %t103, ptr %l57
  br label %bb25
bb24:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb26
bb25:
  %t104 = load i64, ptr %l57, !tbaa !24
  %t105 = icmp eq i64 %t104, 1
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb26
bb26:
  %t107 = load i1, ptr %l53, !tbaa !21
  br i1 %t107, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCycle(ptr %v0, ptr %t108, i64 %t109)
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t112 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb30:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i64, ptr %l1, !tbaa !24
  %t116 = load i32, ptr %l2, !tbaa !23
  %t120 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %t114, i64 %t115, i32 %t116)
  store i64 %t120, ptr %l65
  br label %bb31
bb31:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 28
  %t124 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t127 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %t123, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t124)
  %t128 = extractvalue { i32, i32 } %t127, 1
  %t129 = extractvalue { i32, i32 } %t127, 0
  store i32 %t129, ptr %l71
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb33, label %ok.131, !prof !99
ok.131:
  store i32 %t128, ptr %l70
  br label %bb32
bb32:
  %t132 = load i32, ptr %l70, !tbaa !23
  store i32 %t132, ptr %l66, !tbaa !23
  br label %bb35
bb33:
  br label %bb34
bb34:
  call void @__olang_ert_req_clear()
  %t133 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t133, ptr %l66, !tbaa !23
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t135 = load i32, ptr %l66, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l17 = alloca i32
  %l24 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca i32
  %l90 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l17
  br label %bb7
bb7:
  %t23 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t40, %t39
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l31
  br label %bb15
bb15:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i32, ptr %l36, !range !{i32 0, i32 6}
  store i32 %t62, ptr %l5
  %t63 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t65 = trunc i64 0 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t81, i32 %t82, i32 %t79, i64 %t80)
  store i1 %t85, ptr %l47
  br label %bb23
bb23:
  %t86 = load i1, ptr %l47, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t89 = trunc i64 1 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l55
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t103 = load i32, ptr %l2, !tbaa !23
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l55, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t105, i32 %t106, i32 %t103, i64 %t104)
  store i1 %t109, ptr %l58
  br label %bb28
bb28:
  %t110 = load i1, ptr %l58, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb29:
  %t111 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t113 = trunc i64 4 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l66
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t127 = load i32, ptr %l2, !tbaa !23
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = add i64 %t128, 1
  %t131 = load ptr, ptr %l61, !tbaa !29
  %t132 = load i32, ptr %l66, !tbaa !23
  %t135 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t131, i32 %t132, i32 %t127, i64 %t130)
  store i1 %t135, ptr %l70
  br label %bb33
bb33:
  %t136 = load i1, ptr %l70, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  %t138 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t140 = trunc i64 19 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l78
  br label %bb39
bb39:
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = icmp eq i32 %t153, 0
  br i1 %t154, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i32, ptr %l2, !tbaa !23
  %t169 = load i64, ptr %l3, !tbaa !24
  %t171 = add i64 %t169, 1
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = load i32, ptr %l86, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t172, i32 %t173, i32 %t168, i64 %t171)
  store i1 %t176, ptr %l90
  br label %bb44
bb44:
  %t177 = load i1, ptr %l90, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb45:
  %t178 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t180 = trunc i64 22 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t183 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t185 = trunc i64 23 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l95, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l100
  br label %bb51
bb51:
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load i32, ptr %l100, !tbaa !23
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t201, i32 %t202, i32 %t199, i64 %t200)
  store i1 %t205, ptr %l103
  br label %bb52
bb52:
  %t206 = load i1, ptr %l103, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_4d3e518c37f06fac_dc2de6c574f30d28)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %v0, ptr %t1, %"compiler/source:Span" %a1, ptr %t3)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t9, ptr %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:If", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:If", ptr %t20, i32 0, i32 2
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  %t27 = xor i1 %t25, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 17}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb23
bb13:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = getelementptr %"compiler/typed:If", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %t48)
  store i1 %t51, ptr %l28
  br label %bb14
bb14:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/ast:If", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb17, label %bb18
bb16:
  br label %bb22
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bb0c9585cb5cd0e5_782fa8d07097a5f1)
  unreachable
bb18:
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l2, !tbaa !29
  %t63 = getelementptr %"compiler/ast:If", ptr %t61, i32 0, i32 0
  %t64 = load ptr, ptr %t63, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t65)
  store ptr %t67, ptr %l36
  br label %bb20
bb20:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t70 = getelementptr %"compiler/check:frame", ptr %t68, i32 0, i32 7
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = load ptr, ptr %l29, !tbaa !29
  %t73 = load ptr, ptr %l34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %t72, ptr %t73, i1 false, i64 %t71)
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_78bdf75b8d9b61cd_a447015cda228549)
  unreachable
bb28:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp ne i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t30 = load ptr, ptr %l24, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 30}
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t44 = load i32, ptr %l6, !tbaa !23
  store i32 %t44, ptr %l23, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cf50a113ac2177e6_e3cc5936e852a452)
  unreachable
bb19:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %l7, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 30}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [4 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32 }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l9, !tbaa !23
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t68 = load i32, ptr %l9, !tbaa !23
  store i32 %t68, ptr %l33, !tbaa !23
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_baddfb655e016c47_d17e78f9e01d2853)
  unreachable
bb30:
  %t70 = load i32, ptr %l33, !tbaa !23
  store i32 %t70, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp eq i32 %t71, %a2
  br i1 %t75, label %bb31, label %bb32
bb31:
  %t77 = load i32, ptr %l10, !tbaa !23
  %t81 = icmp eq i32 %t77, %a3
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t83 = load i1, ptr %l44, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3e69957d7270204c_dfbf9d9d846a9638)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp eq i64 %t23, 1
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l9 = alloca i64
  %l15 = alloca %"compiler/check:laneNode"
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 39
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t19, i64 %t20)
  store %"compiler/check:laneNode" %t23, ptr %l15
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t24 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t25 = load i32, ptr %t24, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t27)
  store i32 %t30, ptr %l19
  br label %bb9
bb9:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb10
bb10:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l26
  br label %bb13
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  store i32 %t43, ptr %l23, !tbaa !23
  br label %bb14
bb13:
  %t45 = load i32, ptr %l26, !tbaa !23
  store i32 %t45, ptr %l23, !tbaa !23
  br label %bb14
bb14:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSay(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:laneVals"
  %l7 = alloca i64
  %l11 = alloca %"compiler/check:laneVals"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l27 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t9 = load i64, ptr %l2, !tbaa !24
  %t13 = call %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %s0, ptr %t7, %"compiler/source:Span" %t8, i64 %t9)
  store %"compiler/check:laneVals" %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load %"compiler/check:laneVals", ptr %l11
  store %"compiler/check:laneVals" %t14, ptr %l4
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l12, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t16, ptr %l13
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l14, !tbaa !24
  store ptr %l4, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l16, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t19, ptr %l17
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t20)
  store i32 %t22, ptr %l19
  br label %bb3
bb3:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l17
  %t25 = load i32, ptr %l19, !tbaa !23
  %t26 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t23, %"compiler/source:Span" %t24, i32 %t25, i64 0)
  store ptr %t26, ptr %l20
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l13
  %t29 = load i64, ptr %l14, !tbaa !24
  %t30 = load ptr, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l20, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %s0, ptr %v0, ptr %v0, ptr %t27, %"compiler/source:Span" %t28, i64 %t29, ptr %t30, ptr %t31)
  store ptr %t32, ptr %l21
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 37
  %t36 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %t35, i64 %t36)
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %t39, %"compiler/source:Span" %t40)
  store ptr %t43, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load ptr, ptr %l27, !tbaa !29
  store ptr %t44, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:laneVals" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneSetup(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca %"compiler/check:laneVals"
  %rv = alloca %"compiler/check:laneVals"
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v1)
  store %"compiler/check:laneVals" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 80, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"compiler/check:laneVals", ptr %l4
  %t4 = load ptr, ptr %lp3
  store %"compiler/check:laneVals" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %t5, i64 %t6, ptr %t7)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLength(ptr %v0, ptr %v1, ptr %t11, %"compiler/source:Span" %a1, i64 %t13, ptr %t14)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %lp3
  %t20 = load %"compiler/check:laneVals", ptr %t19
  store %"compiler/check:laneVals" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:laneVals", ptr %rv
  ret %"compiler/check:laneVals" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l13 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l37 = alloca i32
  %l41 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i32
  %l53 = alloca i1
  %l54 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t11 = trunc i64 48 to i32
  %t12 = icmp eq i32 %t9, %t11
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i32, ptr %l2, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t20, ptr %l13, !tbaa !23
  br label %bb8
bb7:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t22, ptr %l13, !tbaa !23
  br label %bb8
bb8:
  %t24 = load i32, ptr %l13, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l22
  br label %bb13
bb12:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb18
bb13:
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t44, ptr %l27
  br label %bb16
bb15:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb17
bb16:
  %t45 = load i1, ptr %l27, !tbaa !21
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t46 = load i1, ptr %l23, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t49 = load i1, ptr %l19, !tbaa !21
  br i1 %t49, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load i32, ptr %l2, !tbaa !23
  store i32 %t51, ptr %l30, !tbaa !23
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t54 = trunc i64 53 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb21, label %bb22
bb20:
  br label %bb29
bb21:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb22:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l33, !tbaa !27
  br label %bb23
bb23:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i32, ptr %l30, !tbaa !23
  %t59 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s3, ptr %t57, i32 %t58, { i64, ptr } %t59, i64 0)
  store i64 %t60, ptr %l34
  br label %bb24
bb24:
  %t61 = load i64, ptr %l34, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sge i64 %t62, 0
  br i1 %t64, label %bb25, label %bb26
bb25:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %t66, i64 %t67, i32 %t68)
  store i32 %t72, ptr %l41
  br label %bb27
bb26:
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t73, ptr %l37, !tbaa !23
  br label %bb28
bb27:
  %t75 = load i32, ptr %l41, !tbaa !23
  store i32 %t75, ptr %l37, !tbaa !23
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t76 = load i32, ptr %l37, !tbaa !23
  store i32 %t76, ptr %rv
  br label %ret
bb29:
  %t77 = load i32, ptr %l1, !range !{i32 0, i32 98}
  %t79 = trunc i64 53 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l2, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t82, i32 %t83)
  store i1 %t86, ptr %l47
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t87 = load i1, ptr %l47, !tbaa !21
  br i1 %t87, label %bb33, label %bb34
bb33:
  %t88 = load i32, ptr %l2, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  br label %bb35
bb34:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t90, ptr %l48, !tbaa !23
  br label %bb35
bb35:
  %t92 = load i32, ptr %l48, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb36:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l53
  br label %bb37
bb37:
  %t98 = load i1, ptr %l53, !tbaa !21
  br i1 %t98, label %bb38, label %bb39
bb38:
  %t99 = load i32, ptr %l2, !tbaa !23
  store i32 %t99, ptr %l54, !tbaa !23
  br label %bb40
bb39:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t101, ptr %l54, !tbaa !23
  br label %bb40
bb40:
  %t103 = load i32, ptr %l54, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l3 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i32
  %l32 = alloca double
  %l33 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i1, ptr %l11, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 1
  %t22 = load i1, ptr %t21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l19
  br label %bb8
bb7:
  br label %bb13
bb8:
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 4
  %t37 = load double, ptr %t36, !tbaa !26
  %t40 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t35, double %t37)
  store i1 %t40, ptr %l23
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t41 = load i1, ptr %l23, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t44 = load i1, ptr %l20, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load i1, ptr %l29, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = load i32, ptr %l3, !tbaa !23
  store i32 %t56, ptr %l30, !tbaa !23
  %t57 = load %"compiler/check:litv", ptr %l1
  %t59 = call double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %t57)
  store double %t59, ptr %l32
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t60 = load i32, ptr %l30, !tbaa !23
  %t61 = load double, ptr %l32, !tbaa !26
  %t62 = call i1 @compiler_2fcheck_2efloatOverflows(i32 %t60, double %t61)
  store i1 %t62, ptr %l33
  br label %bb18
bb18:
  %t63 = load i1, ptr %l33, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %rv
  br label %ret
bb19:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load %"compiler/check:litv", ptr %l1
  %t73 = load i32, ptr %l3, !tbaa !23
  %t77 = call i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %t71, %"compiler/check:litv" %t72, i32 %t73)
  store i1 %t77, ptr %l40
  br label %bb20
bb20:
  %t78 = load i1, ptr %l40, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l68 = alloca { i64, ptr }
  %l75 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 2
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l4, !tbaa !29
  br label %bb8
bb7:
  br label %bb34
bb8:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 8}
  %t34 = icmp eq i64 %t32, 0
  store i1 %t34, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t38, i32 0, i32 2
  %t40 = load i32, ptr %t39
  store i32 %t40, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t42)
  store ptr %t44, ptr %l31
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l31, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 0
  %t48 = load i64, ptr %t47, !tbaa !24
  %t49 = load i32, ptr %l5, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t54 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t48, i64 %t51)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t54, ptr %l36
  br label %bb15
bb15:
  %t55 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l36
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t55, ptr %l6
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l3, !tbaa !23
  %t63 = load i32, ptr %l2, !tbaa !23
  %t67 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t61, i32 %t62, i32 %t63)
  store i1 %t67, ptr %l42
  br label %bb16
bb16:
  %t68 = load i1, ptr %l42, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 31
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t75, ptr %l47
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb19:
  %t76 = load i1, ptr %l47, !tbaa !21
  br i1 %t76, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb23
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 33
  %t80 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l6
  %t83 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t79, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t80)
  store i1 %t83, ptr %l52
  br label %bb22
bb22:
  %t84 = load i1, ptr %l52, !tbaa !21
  store i1 %t84, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t85 = load i1, ptr %l48, !tbaa !21
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l43, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load i32, ptr %l5, !tbaa !23
  %t89 = sext i32 %t87 to i64
  call void @__olang_scope_close(ptr %s3)
  store i64 %t89, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_1a03149f0250e548_14220af7ccd85b74)
  unreachable
bb33:
  br label %bb55
bb34:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t92 = load ptr, ptr %l55, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb35, label %bb36
bb35:
  %t95 = load ptr, ptr %l55, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 18}
  %t98 = icmp eq i64 %t96, 9
  store i1 %t98, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t99 = load i1, ptr %l56, !tbaa !21
  br i1 %t99, label %bb37, label %bb38
bb37:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t102, i32 0, i32 4
  %t104 = load { i64, ptr }, ptr %t103
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  br label %bb39
bb38:
  br label %bb50
bb39:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t106, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l10, !tbaa !24
  br label %bb40
bb40:
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb41, label %bb42
bb41:
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t120 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t120, ptr %l68, !tbaa !27
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l2, !tbaa !23
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralLocalIn(ptr %v0, ptr %v1, ptr %t128, ptr %t126, i32 %t131)
  store i64 %t135, ptr %l75
  br label %bb44
bb44:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp sge i64 %t137, 0
  br i1 %t139, label %bb45, label %bb46
bb45:
  %t141 = load i64, ptr %l12, !tbaa !24
  store i64 %t141, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l9, !tbaa !24
  br label %bb40
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_f003e05343083a19_c7eedaa93b775a5)
  unreachable
bb55:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca %"compiler/typed:Local"
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t10 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6, i64 %a1)
  store %"compiler/typed:Local" %t10, ptr %l7
  br label %bb2
bb2:
  %t11 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t12 = load i32, ptr %t11, !tbaa !23
  store i32 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1, ptr %a1, i32 %t3)
  store %"compiler/source:Span" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t8, ptr %l3
  %t9 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t15, ptr %l11
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %s1, ptr %s1, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l16
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = load %"compiler/msgs:Msg", ptr %l16
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, %"compiler/msgs:Msg" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/generic:Origin"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/generic:Origin"
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l46 = alloca { i64, [3 x i64] }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca i64
  %l58 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l64 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i64
  %l81 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t78 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t6 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i32, ptr %l14, !tbaa !23
  %t9 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundBy(ptr %v0, ptr %t7, i32 %t8)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l1
  %t21 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v2, ptr %t15, %"compiler/source:Span" %t16, %"compiler/msgs:Msg" %a4)
  store i64 %t21, ptr %l21
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %t26, i64 %t27)
  store %"compiler/generic:Origin" %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load %"compiler/generic:Origin", ptr %l25
  store %"compiler/generic:Origin" %t31, ptr %l6
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l26, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l32
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t45, i64 %t46)
  store ptr %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t50 = getelementptr %"compiler/ast:Func", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t52, i32 %t51)
  store { i64, ptr } %t54, ptr %l36
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t55, ptr %l7, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/load:Loader", ptr %t62, i32 0, i32 4
  %t65 = load ptr, ptr %t64, !tbaa !29
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 1
  %t69 = getelementptr %"compiler/source:Span", ptr %t68, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t73 = getelementptr %"compiler/generic:Origin", ptr %l6, i32 0, i32 1
  %t74 = getelementptr %"compiler/source:Span", ptr %t73, i32 0, i32 1
  %t75 = load i32, ptr %t74, !tbaa !23
  %t77 = sext i32 %t75 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 0
  store i64 3, ptr %t79
  %t81 = insertvalue { i64, i64, i64 } undef, i64 %t67, 0
  %t83 = insertvalue { i64, i64, i64 } %t81, i64 %t72, 1
  %t85 = insertvalue { i64, i64, i64 } %t83, i64 %t77, 2
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t78, i32 0, i32 1
  store { i64, i64, i64 } %t85, ptr %t86
  %t87 = load { i64, [3 x i64] }, ptr %t78
  store { i64, [3 x i64] } %t87, ptr %l46
  %t88 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t88, ptr %l47, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l49, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t91, i32 %t92)
  store i32 %t95, ptr %l52
  br label %bb11
bb11:
  %t96 = load ptr, ptr %l49, !tbaa !29
  %t97 = load i32, ptr %l52, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t96, i32 %t97)
  store { i64, ptr } %t98, ptr %l53
  br label %bb12
bb12:
  %t99 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t109 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t106, { i64, ptr } %t107, { i64, ptr } %t105)
  store %"compiler/msgs:Msg" %t109, ptr %l55
  br label %bb13
bb13:
  %t110 = load ptr, ptr %l40, !tbaa !29
  %t111 = load { i64, [3 x i64] }, ptr %l46
  %t112 = load %"compiler/msgs:Msg", ptr %l55
  %t113 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %s0, ptr %t110, { i64, [3 x i64] } %t111, %"compiler/msgs:Msg" %t112)
  store i64 %t113, ptr %l56
  br label %bb14
bb14:
  %t114 = load i64, ptr %l56, !tbaa !24
  store i64 %t114, ptr %l8, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l58
  br label %bb15
bb15:
  %t118 = load i64, ptr %l58, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t121 = icmp sge i64 %t119, 0
  br i1 %t121, label %bb16, label %bb17
bb16:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l62, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  store ptr %t127, ptr %l64, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l9, !tbaa !24
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l68
  br label %bb18
bb17:
  %t136 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t136, ptr %l61, !tbaa !27
  br label %bb21
bb18:
  %t138 = load ptr, ptr %l64, !tbaa !29
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t138, i64 %t139)
  store ptr %t140, ptr %l69
  br label %bb19
bb19:
  %t141 = load ptr, ptr %l69, !tbaa !29
  %t143 = getelementptr %"compiler/ast:Func", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load ptr, ptr %l62, !tbaa !29
  %t147 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t145, i32 %t144)
  store { i64, ptr } %t147, ptr %l72
  br label %bb20
bb20:
  %t148 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t148, ptr %l61, !tbaa !27
  br label %bb21
bb21:
  %t149 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t149, ptr %l10, !tbaa !27
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = getelementptr %"compiler/load:Loader", ptr %t156, i32 0, i32 4
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l77, !tbaa !29
  %t160 = load i64, ptr %l8, !tbaa !24
  store i64 %t160, ptr %l78, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l1
  %t165 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t161, %"compiler/source:Span" %t162)
  store { i64, [3 x i64] } %t165, ptr %l81
  br label %bb22
bb22:
  %t166 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t170 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %s0, { i64, ptr } %t166, { i64, ptr } %t167)
  store %"compiler/msgs:Msg" %t170, ptr %l84
  br label %bb23
bb23:
  %t171 = load ptr, ptr %l77, !tbaa !29
  %t172 = load i64, ptr %l78, !tbaa !24
  %t173 = load { i64, [3 x i64] }, ptr %l81
  %t174 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t171, i64 %t172, { i64, [3 x i64] } %t173, %"compiler/msgs:Msg" %t174)
  br label %bb24
bb24:
  %t175 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t175, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoClearMade(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 7
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Make", ptr %t21, i32 0, i32 6
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l6, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_929b44a27af4e606_c6f0275d053ca0d2)
  unreachable
bb14:
  %t26 = load i1, ptr %l6, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t311 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l26, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l27, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l33
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l27, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l34
  br label %bb9
bb9:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l39, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l45
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t63 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l47
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i64 %t76, ptr %l48
  br label %bb14
bb14:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l61
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l61, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l62, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = icmp sge i64 %t116, %t117
  store i1 %t120, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb33
bb29:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp eq i64 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l80, !tbaa !27
  br label %bb32
bb31:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t138)
  %t146 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l80, !tbaa !27
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t157, ptr %l77, !tbaa !27
  br label %bb33
bb33:
  %t158 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t158, ptr %l9, !tbaa !27
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb36
bb35:
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = icmp eq i64 %t179, 0
  br i1 %t181, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb42
bb38:
  %t183 = load i1, ptr %l6, !tbaa !21
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t189 = extractvalue { i64, ptr } %t185, 1
  %t190 = extractvalue { i64, ptr } %t185, 0
  %t191 = add i64 %t187, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t186, i64 %t187)
  %t193 = getelementptr i8, ptr %t192, i64 %t187
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  br label %bb41
bb40:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t204, ptr %l94, !tbaa !27
  br label %bb41
bb41:
  %t206 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  br label %bb42
bb42:
  %t207 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l100
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l103
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l105, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load i64, ptr %l7, !tbaa !24
  %t230 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l105, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t235, i32 %t234)
  store { i64, ptr } %t237, ptr %l112
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %s0, ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %a4, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t246, ptr %l116
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l99, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l100
  %t249 = load %"compiler/msgs:Msg", ptr %l116
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t247, %"compiler/source:Span" %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l117
  br label %bb47
bb47:
  %t251 = load i64, ptr %l117, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  %t259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l121
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l121, !tbaa !29
  store ptr %t260, ptr %l13, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 10
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t277 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l129
  br label %bb49
bb49:
  %t278 = load ptr, ptr %l125, !tbaa !29
  %t279 = load i64, ptr %l129, !tbaa !24
  %t280 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t280, ptr %l130
  br label %bb50
bb50:
  %t281 = load ptr, ptr %l130, !tbaa !29
  %t283 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 4
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = load ptr, ptr %l13, !tbaa !29
  %t288 = getelementptr %"compiler/ast:Func", ptr %t286, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l15
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 4
  %t300 = load ptr, ptr %t299, !tbaa !29
  store ptr %t300, ptr %l138, !tbaa !29
  %t301 = load i64, ptr %l12, !tbaa !24
  store i64 %t301, ptr %l139, !tbaa !24
  %t303 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t307 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 1
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = sext i32 %t308 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 0
  store i64 3, ptr %t312
  %t314 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t316 = insertvalue { i64, i64, i64 } %t314, i64 %t306, 1
  %t318 = insertvalue { i64, i64, i64 } %t316, i64 %t310, 2
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  store { i64, i64, i64 } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t311
  store { i64, [3 x i64] } %t320, ptr %l145
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l13, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l149
  br label %bb51
bb51:
  %t329 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l151
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  %t340 = load { i64, [3 x i64] }, ptr %l145
  %t341 = load %"compiler/msgs:Msg", ptr %l151
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t338, i64 %t339, { i64, [3 x i64] } %t340, %"compiler/msgs:Msg" %t341)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca %"compiler/generic:Binding"
  %l42 = alloca i1
  %l47 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca i32
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l19, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l23
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l19, !tbaa !29
  %t22 = load i32, ptr %l23, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l24
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i32, ptr %l24, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l25
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l27, !tbaa !24
  %t31 = load i64, ptr %l27, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sle i64 %t34, 2305843009213693951
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb6:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = mul i64 %t37, 4
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t42, ptr %lp4
  %t44 = load ptr, ptr %lp4
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t45)
  store i64 %t47, ptr %l32
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb8:
  %t48 = load i64, ptr %l32, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l36
  br label %bb9
bb9:
  %t57 = load i64, ptr %l36, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t58, i64 %t59)
  store %"compiler/generic:Binding" %t62, ptr %l39
  br label %bb10
bb10:
  %t63 = load %"compiler/generic:Binding", ptr %l39
  store %"compiler/generic:Binding" %t63, ptr %l7
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp sgt i64 %t70, 0
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 0
  %t80 = load i32, ptr %t79, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t75, i32 %t80, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l59, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t117 = load i64, ptr %l56, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l77, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb28, label %bb29
bb28:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load i64, ptr %l13, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t141, i32 %t148)
  store i32 %t151, ptr %l85
  br label %bb30
bb29:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t154 = load i64, ptr %l13, !tbaa !24
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s0, ptr %t152, { i64, ptr } %t153, i64 %t154, ptr %l7)
  store i32 %t159, ptr %l90
  br label %bb31
bb30:
  %t160 = load i32, ptr %l85, !tbaa !23
  store i32 %t160, ptr %l80, !tbaa !23
  br label %bb32
bb31:
  %t161 = load i32, ptr %l90, !tbaa !23
  store i32 %t161, ptr %l80, !tbaa !23
  br label %bb32
bb32:
  %t162 = load i32, ptr %l80, !tbaa !23
  %t163 = load ptr, ptr %lp4
  %t164 = load i64, ptr %l77, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i32, ptr %t166, i64 %t164
  store i32 %t162, ptr %t167, !tbaa !33
  br label %bb33
bb33:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l12, !tbaa !24
  br label %bb24
bb34:
  %t172 = load ptr, ptr %lp4
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflDecide(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca %"compiler/check:reflVal"
  %l13 = alloca %"compiler/check:reflVal"
  %l20 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 135
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l2, !tbaa !21
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 135
  store i1 false, ptr %t13, !tbaa !21
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t18 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %s0, ptr %t14, ptr %t15)
  store %"compiler/check:reflVal" %t18, ptr %l13
  br label %bb4
bb4:
  %t19 = load %"compiler/check:reflVal", ptr %l13
  store %"compiler/check:reflVal" %t19, ptr %l3
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 135
  %t23 = load i1, ptr %t22, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i1, ptr %l2, !tbaa !21
  %t29 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 135
  store i1 %t26, ptr %t29, !tbaa !21
  %t32 = xor i1 %t23, true
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t34 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 0
  %t35 = load i1, ptr %t34, !tbaa !21
  %t37 = xor i1 %t35, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  %t40 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2fcheck_2eRvBool, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t49 = getelementptr %"compiler/check:reflVal", ptr %l3, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i32, { i64, ptr } }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i32
  %l64 = alloca { i32, { i64, ptr } }
  %l68 = alloca i1
  %l70 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l81 = alloca %"compiler/msgs:Msg"
  %l82 = alloca i64
  %l85 = alloca ptr
  %l86 = alloca i1
  %l93 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l112 = alloca ptr
  %l114 = alloca ptr
  %l118 = alloca %"compiler/names:Ref"
  %l122 = alloca { i64, ptr }
  %l126 = alloca i1
  %l129 = alloca i1
  %l132 = alloca i32
  %l144 = alloca i32
  %l147 = alloca i32
  %l152 = alloca i1
  %l154 = alloca ptr
  %l158 = alloca %"compiler/source:Span"
  %l159 = alloca { i64, ptr }
  %l161 = alloca %"compiler/source:Span"
  %l164 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l173 = alloca i64
  %l175 = alloca i64
  %l176 = alloca %"compiler/msgs:Msg"
  %l177 = alloca i64
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l187 = alloca i32
  %l191 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i1
  %l201 = alloca i1
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  %t268 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 30}
  %t20 = icmp eq i64 %t18, 14
  store i1 %t20, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l3
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb39
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l38
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t46)
  store i1 %t48, ptr %l40
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  store i32 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  store i32 -1, ptr %l7, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t55, ptr %l44
  br label %bb15
bb15:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i32 %t61, ptr %l47
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load i32, ptr %l47, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb19
bb19:
  %t63 = load i32, ptr %l7, !tbaa !23
  %t65 = icmp slt i32 %t63, 0
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i32 %t71, ptr %l52
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i32, ptr %l52, !tbaa !23
  store i32 %t72, ptr %l7, !tbaa !23
  br label %bb23
bb23:
  %t73 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp slt i32 %t73, 0
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t77, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  br i1 %t83, label %bb27, label %bb28
bb27:
  %t85 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t85, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l7, !tbaa !23
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v0, ptr %s2, ptr %t90, i32 %t91, { i64, ptr } %t92)
  store { i32, { i64, ptr } } %t96, ptr %l64
  br label %bb30
bb30:
  %t97 = load { i32, { i64, ptr } }, ptr %l64
  store { i32, { i64, ptr } } %t97, ptr %l8
  %t98 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t101 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l10, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t104, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t106, ptr %l68
  br label %bb31
bb31:
  %t107 = load i1, ptr %l68, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l70, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l3
  %t112 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t111, i64 %t114)
  store %"compiler/source:Span" %t117, ptr %l74
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t118, ptr %l75, !tbaa !27
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l7, !tbaa !23
  %t123 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t119, i32 %t120)
  store { i64, ptr } %t123, ptr %l78
  br label %bb35
bb35:
  %t124 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t126 = extractvalue { i64, ptr } %t124, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  %t131 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t135 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %s8, ptr %s2, ptr %s8, { i64, ptr } %t132, { i64, ptr } %t130, { i64, ptr } %t131)
  store %"compiler/msgs:Msg" %t135, ptr %l81
  br label %bb36
bb36:
  %t136 = load ptr, ptr %l70, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l74
  %t138 = load %"compiler/msgs:Msg", ptr %l81
  %t139 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t136, %"compiler/source:Span" %t137, %"compiler/msgs:Msg" %t138)
  store i64 %t139, ptr %l82
  br label %bb37
bb37:
  %t140 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t140, ptr %rv
  br label %ret
bb38:
  %t142 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t142, ptr %rv
  br label %ret
bb39:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb40, label %bb41
bb40:
  %t148 = load ptr, ptr %l85, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 30}
  %t151 = icmp eq i64 %t149, 2
  store i1 %t151, ptr %l86, !tbaa !21
  br label %bb41
bb41:
  %t152 = load i1, ptr %l86, !tbaa !21
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", ptr }, ptr %t155, i32 0, i32 1
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l11, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t159, ptr %t160)
  store i32 %t163, ptr %l93
  br label %bb45
bb45:
  %t164 = load i32, ptr %l93, !tbaa !23
  store i32 %t164, ptr %rv
  br label %ret
bb46:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t166 = load ptr, ptr %l94, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb47, label %bb48
bb47:
  %t169 = load ptr, ptr %l94, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 30}
  %t172 = icmp eq i64 %t170, 13
  store i1 %t172, ptr %l95, !tbaa !21
  br label %bb48
bb48:
  %t173 = load i1, ptr %l95, !tbaa !21
  br i1 %t173, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l12
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l13, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [4 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t188, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189
  store { i64, ptr } %t190, ptr %l14, !tbaa !27
  br label %bb51
bb50:
  br label %bb107
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 false, ptr %l15, !tbaa !21
  %t192 = load ptr, ptr %l13, !tbaa !29
  store ptr %t192, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t193 = load ptr, ptr %l104, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb52, label %bb53
bb52:
  %t196 = load ptr, ptr %l104, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 30}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t200 = load i1, ptr %l105, !tbaa !21
  br i1 %t200, label %bb54, label %bb55
bb54:
  %t201 = load ptr, ptr %l13, !tbaa !29
  %t203 = getelementptr { i64, [4 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", i32 }, ptr %t203, i32 0, i32 0
  %t205 = load %"compiler/source:Span", ptr %t204
  store %"compiler/source:Span" %t205, ptr %l16
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = getelementptr %"compiler/generic:Program", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  store ptr %t213, ptr %l112, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t214)
  store ptr %t216, ptr %l114
  br label %bb57
bb57:
  %t217 = load ptr, ptr %l114, !tbaa !29
  %t219 = getelementptr %"compiler/check:frame", ptr %t217, i32 0, i32 2
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t222 = load i32, ptr %t221, !tbaa !23
  %t223 = load ptr, ptr %l112, !tbaa !29
  %t226 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t223, i64 %t220, i32 %t222)
  store %"compiler/names:Ref" %t226, ptr %l118
  br label %bb58
bb58:
  %t227 = getelementptr %"compiler/names:Ref", ptr %l118, i32 0, i32 0
  %t228 = load i32, ptr %t227, !range !{i32 0, i32 9}
  %t230 = trunc i64 7 to i32
  %t231 = icmp eq i32 %t228, %t230
  store i1 %t231, ptr %l15, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_492feac3979049da_7a1ccb679ec95f6e)
  unreachable
bb64:
  %t233 = load ptr, ptr %l13, !tbaa !29
  %t235 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %s10, ptr %t233)
  store { i64, ptr } %t235, ptr %l122
  br label %bb65
bb65:
  %t236 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t236, ptr %l17, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t237, 0
  %t241 = icmp eq i64 %t239, 0
  br i1 %t241, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l126, !tbaa !21
  br label %bb72
bb67:
  %t243 = load i1, ptr %l15, !tbaa !21
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb68, label %bb69
bb68:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l13, !tbaa !29
  %t251 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t247, ptr %t248)
  store i32 %t251, ptr %l132
  br label %bb70
bb69:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb71
bb70:
  %t252 = load i32, ptr %l132, !tbaa !23
  %t253 = icmp slt i32 %t252, 0
  store i1 %t253, ptr %l129, !tbaa !21
  br label %bb71
bb71:
  %t255 = load i1, ptr %l129, !tbaa !21
  store i1 %t255, ptr %l126, !tbaa !21
  br label %bb72
bb72:
  %t256 = load i1, ptr %l126, !tbaa !21
  br i1 %t256, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s10)
  store i32 -1, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t258 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t262 = icmp eq i64 %t260, 1
  br i1 %t262, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s14
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l12
  %t266 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 0
  store i64 0, ptr %t269
  %t271 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t265, 0
  %t273 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t271, { i64, ptr } %t266, 1
  %t275 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t273, { i64, ptr } %t267, 2
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t268, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t275, ptr %t276
  %t277 = load { i64, [5 x i64] }, ptr %t268
  %t279 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 48, i64 8)
  store { i64, [5 x i64] } %t277, ptr %t279
  %t282 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %s14, ptr %t264, ptr %t279)
  store i32 %t282, ptr %l144
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s10)
  %t283 = load i32, ptr %l144, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
bb79:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load ptr, ptr %l13, !tbaa !29
  %t288 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t284, ptr %t285)
  store i32 %t288, ptr %l147
  br label %bb80
bb80:
  %t289 = load i32, ptr %l147, !tbaa !23
  store i32 %t289, ptr %l18, !tbaa !23
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t294 = load i32, ptr %l18, !tbaa !23
  %t295 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t299 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t293, i32 %t294, { i64, ptr } %t295)
  store i1 %t299, ptr %l152
  br label %bb81
bb81:
  %t300 = load i1, ptr %l152, !tbaa !21
  %t301 = xor i1 %t300, true
  br i1 %t301, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l154, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t308 = icmp sgt i64 %t306, 0
  br i1 %t308, label %bb84, label %bb85
bb83:
  br label %bb93
bb84:
  %t310 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t310, ptr %l159, !tbaa !27
  %t311 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr ptr, ptr %t312, i64 0
  %t314 = load ptr, ptr %t313, !tbaa !39
  %t316 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t314)
  store %"compiler/source:Span" %t316, ptr %l161
  br label %bb86
bb85:
  %t317 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t317, ptr %l158
  br label %bb87
bb86:
  %t319 = load %"compiler/source:Span", ptr %l161
  store %"compiler/source:Span" %t319, ptr %l158
  br label %bb87
bb87:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t321, ptr %l164, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t326 = sub i64 %t324, 1
  %t328 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr i32, ptr %t329, i64 %t326
  %t331 = load i32, ptr %t330, !tbaa !33
  %t334 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t320, i32 %t331)
  store { i64, ptr } %t334, ptr %l169
  br label %bb88
bb88:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !29
  %t339 = load i32, ptr %l18, !tbaa !23
  %t342 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t338, i32 %t339)
  store i64 %t342, ptr %l173
  br label %bb89
bb89:
  %t343 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t345 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t343)
  store i64 %t345, ptr %l175
  br label %bb90
bb90:
  %t346 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t347 = load i64, ptr %l173, !tbaa !24
  %t348 = load i64, ptr %l175, !tbaa !24
  %t349 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s15, { i64, ptr } %t346, i64 %t347, i64 %t348)
  store %"compiler/msgs:Msg" %t349, ptr %l176
  br label %bb91
bb91:
  %t350 = load ptr, ptr %l154, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l158
  %t352 = load %"compiler/msgs:Msg", ptr %l176
  %t353 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t350, %"compiler/source:Span" %t351, %"compiler/msgs:Msg" %t352)
  store i64 %t353, ptr %l177
  br label %bb92
bb92:
  %t354 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s10)
  store i32 %t354, ptr %rv
  br label %ret
bb93:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/check:Checker", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  store ptr %t359, ptr %l180, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t360)
  store ptr %t362, ptr %l182
  br label %bb94
bb94:
  %t363 = load ptr, ptr %l182, !tbaa !29
  %t365 = getelementptr %"compiler/check:frame", ptr %t363, i32 0, i32 4
  %t366 = load i32, ptr %l18, !tbaa !23
  %t367 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t368 = load ptr, ptr %l180, !tbaa !29
  %t372 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v1, ptr %t368, ptr %t365, i32 %t366, { i64, ptr } %t367)
  store i32 %t372, ptr %l187
  br label %bb95
bb95:
  %t373 = load i32, ptr %l187, !tbaa !23
  store i32 %t373, ptr %l19, !tbaa !23
  %t374 = load i32, ptr %l19, !tbaa !23
  %t375 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t378 = icmp eq i32 %t374, %t375
  br i1 %t378, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb99
bb97:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = load i32, ptr %l19, !tbaa !23
  %t382 = load %"compiler/source:Span", ptr %l12
  %t386 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t380, i32 %t381, %"compiler/source:Span" %t382)
  store i1 %t386, ptr %l195
  br label %bb98
bb98:
  %t387 = load i1, ptr %l195, !tbaa !21
  %t388 = xor i1 %t387, true
  store i1 %t388, ptr %l191, !tbaa !21
  br label %bb99
bb99:
  %t390 = load i1, ptr %l191, !tbaa !21
  br i1 %t390, label %bb100, label %bb101
bb100:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb103
bb101:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/check:Checker", ptr %t391, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !29
  %t395 = load i32, ptr %l19, !tbaa !23
  %t398 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t394, i32 %t395)
  store i1 %t398, ptr %l201
  br label %bb102
bb102:
  %t399 = load i1, ptr %l201, !tbaa !21
  %t400 = xor i1 %t399, true
  store i1 %t400, ptr %l197, !tbaa !21
  br label %bb103
bb103:
  %t402 = load i1, ptr %l197, !tbaa !21
  br i1 %t402, label %bb104, label %bb105
bb104:
  %t403 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t403, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  %t405 = load i32, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  store i32 %t405, ptr %rv
  br label %ret
bb107:
  br i1 true, label %bb108, label %bb109
bb108:
  br label %bb110
bb109:
  br label %bb111
bb110:
  store i32 -1, ptr %rv
  br label %ret
bb111:
  call void @__olang_check_failed(ptr @olang_loc_42af232d2840e8db_efcef566740b002f)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i1
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca i32
  %l48 = alloca i32
  %l55 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l69 = alloca i32
  %l78 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/msgs:Msg"
  %l88 = alloca i64
  %l93 = alloca i32
  %l96 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l113 = alloca %"compiler/msgs:Msg"
  %l114 = alloca i64
  %l118 = alloca i64
  %l120 = alloca i64
  %l125 = alloca i32
  %l130 = alloca ptr
  %l131 = alloca %"compiler/source:Span"
  %l132 = alloca ptr
  %l135 = alloca ptr
  %l138 = alloca i32
  %l139 = alloca i32
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t267 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l18, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  store ptr %t11, ptr %l22, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t12)
  store i32 %t15, ptr %l25
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l22, !tbaa !29
  %t17 = load i32, ptr %l25, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t18, ptr %l26
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l19, !tbaa !29
  %t20 = load i32, ptr %l26, !tbaa !23
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t19, i32 %t20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l27
  br label %bb4
bb4:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l4
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/check:frame", ptr %t23, i32 0, i32 26
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/check:frame", ptr %t30, i32 0, i32 12
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t37 = load i1, ptr %l31, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb8:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb9:
  br label %bb47
bb10:
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l36, !tbaa !24
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t40)
  store i64 %t42, ptr %l38
  br label %bb11
bb11:
  %t43 = load i64, ptr %l36, !tbaa !24
  %t44 = load i64, ptr %l38, !tbaa !24
  %t45 = icmp slt i64 %t43, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  br label %bb46
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t49, i64 %t50)
  store i32 %t53, ptr %l43
  br label %bb15
bb15:
  %t54 = load i32, ptr %l43, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l7, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l48
  br label %bb16
bb16:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l8, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t66, ptr %l9, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:frame", ptr %t74, i32 0, i32 6
  %t77 = load i32, ptr %t76, !tbaa !23
  %t80 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t73, i32 %t77)
  store { i64, ptr } %t80, ptr %l55
  br label %bb17
bb17:
  %t81 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t81, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  store i64 %t84, ptr %l12, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l11, !tbaa !24
  %t87 = load i64, ptr %l12, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb19, label %bb20
bb19:
  br label %bb27
bb20:
  br label %bb21
bb21:
  %t94 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t94, ptr %l62, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  store i32 %t100, ptr %l13, !tbaa !23
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l13, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l69
  br label %bb22
bb22:
  %t112 = load i32, ptr %l8, !tbaa !23
  %t113 = load i32, ptr %l69, !tbaa !23
  %t115 = icmp eq i32 %t113, %t112
  br i1 %t115, label %bb23, label %bb24
bb23:
  %t117 = load i32, ptr %l13, !tbaa !23
  store i32 %t117, ptr %l9, !tbaa !23
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t119 = load i64, ptr %l11, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l11, !tbaa !24
  br label %bb18
bb27:
  %t123 = load i32, ptr %l9, !tbaa !23
  %t124 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t127 = icmp eq i32 %t123, %t124
  br i1 %t127, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l78, !tbaa !29
  %t130 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t131 = load i32, ptr %t130, !tbaa !23
  %t132 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t133 = load i32, ptr %t132, !tbaa !23
  %t135 = add i32 %t133, 5
  %t138 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 %t131, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l82
  br label %bb30
bb29:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = getelementptr %"compiler/check:frame", ptr %t140, i32 0, i32 6
  %t143 = load i32, ptr %t142, !tbaa !23
  %t144 = load i32, ptr %l7, !tbaa !23
  %t148 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t139, i32 %t143, i32 %t144)
  store i32 %t148, ptr %l93
  br label %bb34
bb30:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l7, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l85
  br label %bb31
bb31:
  %t154 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseUndeclared(ptr %s8, ptr %s8, { i64, ptr } %t160)
  store %"compiler/msgs:Msg" %t162, ptr %l87
  br label %bb32
bb32:
  %t163 = load ptr, ptr %l78, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l82
  %t165 = load %"compiler/msgs:Msg", ptr %l87
  %t166 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t163, %"compiler/source:Span" %t164, %"compiler/msgs:Msg" %t165)
  store i64 %t166, ptr %l88
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb34:
  %t167 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t168 = load i32, ptr %l93, !tbaa !23
  %t170 = icmp ne i32 %t168, %t167
  br i1 %t170, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l96, !tbaa !29
  %t173 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t175 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = add i32 %t176, 5
  %t181 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 %t174, i32 %t178)
  store %"compiler/source:Span" %t181, ptr %l100
  br label %bb37
bb36:
  br label %bb43
bb37:
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l101, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l3, !tbaa !29
  %t186 = getelementptr %"compiler/check:frame", ptr %t184, i32 0, i32 6
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = load i32, ptr %l7, !tbaa !23
  %t192 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t183, i32 %t187, i32 %t188)
  store i32 %t192, ptr %l106
  br label %bb38
bb38:
  %t193 = load ptr, ptr %l101, !tbaa !29
  %t194 = load i32, ptr %l106, !tbaa !23
  %t195 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t193, i32 %t194)
  store { i64, ptr } %t195, ptr %l107
  br label %bb39
bb39:
  %t196 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  %t198 = extractvalue { i64, ptr } %t196, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l108, !tbaa !27
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l9, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t203, i32 %t204)
  store { i64, ptr } %t207, ptr %l111
  br label %bb40
bb40:
  %t208 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  %t210 = extractvalue { i64, ptr } %t208, 1
  %t211 = mul i64 %t209, 1
  %t212 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t211)
  call void @llvm.memcpy.p0.p0.i64(ptr %t212, ptr %t210, i64 %t211, i1 false)
  %t213 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t212, 1
  %t215 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t217 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseWordNotInSet(ptr %s10, ptr %s10, ptr %s10, { i64, ptr } %t215, { i64, ptr } %t214)
  store %"compiler/msgs:Msg" %t217, ptr %l113
  br label %bb41
bb41:
  %t218 = load ptr, ptr %l96, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l100
  %t220 = load %"compiler/msgs:Msg", ptr %l113
  %t221 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t218, %"compiler/source:Span" %t219, %"compiler/msgs:Msg" %t220)
  store i64 %t221, ptr %l114
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb43:
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t222 = load i64, ptr %l6, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l6, !tbaa !24
  br label %bb10
bb46:
  br label %bb47
bb47:
  store ptr %l4, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb48
bb48:
  %t227 = load i64, ptr %l15, !tbaa !24
  store i64 %t227, ptr %l118, !tbaa !24
  %t228 = load ptr, ptr %l14, !tbaa !29
  %t230 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t228)
  store i64 %t230, ptr %l120
  br label %bb49
bb49:
  %t231 = load i64, ptr %l118, !tbaa !24
  %t232 = load i64, ptr %l120, !tbaa !24
  %t233 = icmp slt i64 %t231, %t232
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb50, label %bb51
bb50:
  br label %bb56
bb51:
  br label %bb52
bb52:
  %t237 = load ptr, ptr %l14, !tbaa !29
  %t238 = load i64, ptr %l15, !tbaa !24
  %t241 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t237, i64 %t238)
  store i32 %t241, ptr %l125
  br label %bb53
bb53:
  %t242 = load i32, ptr %l125, !tbaa !23
  %t243 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t243, i32 %t242)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t247 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t247, 1
  store i64 %t249, ptr %l15, !tbaa !24
  br label %bb48
bb56:
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l130, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t252, ptr %l131
  %t253 = load ptr, ptr %l2, !tbaa !29
  store ptr %t253, ptr %l132, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t254, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t259 = getelementptr %"compiler/generic:Program", ptr %t257, i32 0, i32 2
  store ptr %t259, ptr %l135, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t263 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t260)
  store i32 %t263, ptr %l138
  br label %bb57
bb57:
  %t264 = load ptr, ptr %l135, !tbaa !29
  %t265 = load i32, ptr %l138, !tbaa !23
  %t266 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t264, i32 %t265)
  store i32 %t266, ptr %l139
  br label %bb58
bb58:
  store { i64, [3 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 0
  store i64 8, ptr %t268
  %t269 = load %"compiler/source:Span", ptr %l131
  %t270 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t269, 0
  %t271 = load ptr, ptr %l132, !tbaa !29
  %t272 = insertvalue { %"compiler/source:Span", ptr, i32 } %t270, ptr %t271, 1
  %t273 = load i32, ptr %l139, !tbaa !23
  %t274 = insertvalue { %"compiler/source:Span", ptr, i32 } %t272, i32 %t273, 2
  %t275 = getelementptr { i64, [3 x i64] }, ptr %t267, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t274, ptr %t275
  %t276 = load { i64, [3 x i64] }, ptr %t267
  %t278 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t276, ptr %t278
  %t279 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t279, ptr %t278)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erestAt(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l38 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb22
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = call i1 @compiler_2fcheck_2eisRest(ptr %v1, ptr %t57)
  store i1 %t59, ptr %l38
  br label %bb11
bb11:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t63 = load i64, ptr %l2, !tbaa !24
  %t65 = icmp sge i64 %t63, 0
  br i1 %t65, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a0, ptr %l42, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l43, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l46
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t77 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRestTwice(ptr %s4)
  store %"compiler/msgs:Msg" %t77, ptr %l47
  br label %bb18
bb18:
  %t78 = load ptr, ptr %l42, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l46
  %t80 = load %"compiler/msgs:Msg", ptr %l47
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t78, %"compiler/source:Span" %t79, %"compiler/msgs:Msg" %t80)
  store i64 %t81, ptr %l48
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s4)
  store i64 -2, ptr %rv
  br label %ret
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  store i64 %t83, ptr %l2, !tbaa !24
  br label %bb21
bb21:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb7
bb22:
  %t89 = load i64, ptr %l2, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 81
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t5)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 19
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp ne i64 %t29, 2
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRefResult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l10 = alloca i1
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 82
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l15
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t33 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t29, ptr %t30)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t33, ptr %l19
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v0, ptr %t34, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t35)
  br label %bb11
bb11:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/check:roOrigin"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca %"compiler/check:roOrigin"
  %l16 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l26 = alloca %"compiler/check:roOrigin"
  %l28 = alloca ptr
  %l32 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l33 = alloca %"compiler/check:roOrigin"
  %l34 = alloca i32
  %l35 = alloca %"compiler/check:roOrigin"
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l83 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca ptr
  %l98 = alloca ptr
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca %"compiler/check:roOrigin"
  %l119 = alloca ptr
  %l123 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l124 = alloca %"compiler/check:roOrigin"
  %l125 = alloca i32
  %l126 = alloca %"compiler/check:roOrigin"
  %l130 = alloca i1
  %l136 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  store i1 %t7, ptr %l16, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb22
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 75
  store ptr %t28, ptr %l28, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = sext i32 %t30 to i64
  %t35 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t29, i64 %t32)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l32
  br label %bb12
bb12:
  %t36 = load ptr, ptr %l28, !tbaa !29
  %t37 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l32
  %t38 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t36, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t37)
  %t39 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 1
  %t40 = extractvalue { i32, %"compiler/check:roOrigin" } %t38, 0
  store i32 %t40, ptr %l34
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb14, label %ok.42, !prof !99
ok.42:
  store %"compiler/check:roOrigin" %t39, ptr %l33
  br label %bb13
bb13:
  %t43 = load %"compiler/check:roOrigin", ptr %l33
  store %"compiler/check:roOrigin" %t43, ptr %l26
  br label %bb17
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t44 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t44, ptr %l35
  br label %bb16
bb16:
  %t45 = load %"compiler/check:roOrigin", ptr %l35
  store %"compiler/check:roOrigin" %t45, ptr %l26
  br label %bb17
bb17:
  %t46 = load %"compiler/check:roOrigin", ptr %l26
  store %"compiler/check:roOrigin" %t46, ptr %l4
  %t47 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:roOrigin", ptr %l4, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t63 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t54, ptr %t56, i64 %t59)
  store i64 %t63, ptr %l43
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t64 = load i64, ptr %l43, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb21:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t67 = sext i32 %t65 to i64
  store i64 %t67, ptr %rv
  br label %ret
bb22:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t70 = load ptr, ptr %l46, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = load ptr, ptr %l46, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 8}
  %t76 = icmp eq i64 %t74, 3
  store i1 %t76, ptr %l47, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l47, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l5, !tbaa !29
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = add i64 %t87, 1
  %t93 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t84, ptr %t85, i64 %t89)
  store i64 %t93, ptr %l57
  br label %bb28
bb28:
  %t94 = load i64, ptr %l57, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
bb29:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t99 = load ptr, ptr %l58, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 8}
  %t102 = icmp eq i64 %t100, 4
  store i1 %t102, ptr %l59, !tbaa !21
  br label %bb31
bb31:
  %t103 = load i1, ptr %l59, !tbaa !21
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Elem", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = load i64, ptr %l2, !tbaa !24
  %t118 = add i64 %t116, 1
  %t122 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t110, ptr %t114, i64 %t118)
  store i64 %t122, ptr %l70
  br label %bb35
bb35:
  %t123 = load i64, ptr %l70, !tbaa !24
  store i64 %t123, ptr %rv
  br label %ret
bb36:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb37, label %bb38
bb37:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 8}
  %t131 = icmp eq i64 %t129, 5
  store i1 %t131, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb39, label %bb40
bb39:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [4 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t135, i32 0, i32 2
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load ptr, ptr %l7, !tbaa !29
  %t142 = getelementptr %"compiler/typed:Payload", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = load i64, ptr %l2, !tbaa !24
  %t147 = add i64 %t145, 1
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t139, ptr %t143, i64 %t147)
  store i64 %t151, ptr %l83
  br label %bb42
bb42:
  %t152 = load i64, ptr %l83, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb43:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t154 = load ptr, ptr %l84, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t157 = load ptr, ptr %l84, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 8}
  %t160 = icmp eq i64 %t158, 6
  store i1 %t160, ptr %l85, !tbaa !21
  br label %bb45
bb45:
  %t161 = load i1, ptr %l85, !tbaa !21
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t164, i32 0, i32 2
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l8, !tbaa !29
  br label %bb48
bb47:
  br label %bb55
bb48:
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %v1, ptr %t168)
  store ptr %t170, ptr %l91
  br label %bb49
bb49:
  %t171 = load ptr, ptr %l91, !tbaa !29
  store ptr %t171, ptr %l9, !tbaa !29
  %t172 = load ptr, ptr %l9, !tbaa !29
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t176 = icmp eq ptr %t172, %t173
  br i1 %t176, label %bb50, label %bb51
bb50:
  store i64 -1, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l96, !tbaa !29
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t182 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t180)
  store ptr %t182, ptr %l98
  br label %bb53
bb53:
  %t183 = load i64, ptr %l2, !tbaa !24
  %t185 = add i64 %t183, 1
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v1, ptr %t186, ptr %t187, i64 %t185)
  store i64 %t189, ptr %l101
  br label %bb54
bb54:
  %t190 = load i64, ptr %l101, !tbaa !24
  store i64 %t190, ptr %rv
  br label %ret
bb55:
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t192 = load ptr, ptr %l102, !tbaa !29
  %t193 = icmp ne ptr %t192, null
  br i1 %t193, label %bb56, label %bb57
bb56:
  %t195 = load ptr, ptr %l102, !tbaa !29
  %t196 = load i64, ptr %t195, !range !{i64 0, i64 8}
  %t198 = icmp eq i64 %t196, 2
  store i1 %t198, ptr %l103, !tbaa !21
  br label %bb57
bb57:
  %t199 = load i1, ptr %l103, !tbaa !21
  br i1 %t199, label %bb58, label %bb59
bb58:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l10, !tbaa !29
  br label %bb60
bb59:
  br label %bb87
bb60:
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t208 = call ptr @compiler_2fcheck_2eunwrapped(ptr %v1, ptr %v1, ptr %t206)
  store ptr %t208, ptr %l109
  br label %bb61
bb61:
  %t209 = load ptr, ptr %l109, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t209)
  store ptr %t210, ptr %l110
  br label %bb62
bb62:
  %t211 = load ptr, ptr %l110, !tbaa !29
  store ptr %t211, ptr %l11, !tbaa !29
  %t212 = load ptr, ptr %l11, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb63, label %bb64
bb63:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 8}
  %t219 = icmp eq i64 %t217, 0
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb64
bb64:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb65, label %bb66
bb65:
  %t221 = load ptr, ptr %l11, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t223, i32 0, i32 2
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l12, !tbaa !23
  br label %bb67
bb66:
  br label %bb81
bb67:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 75
  store ptr %t229, ptr %l119, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l12, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t236 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t230, i64 %t233)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t236, ptr %l123
  br label %bb68
bb68:
  %t237 = load ptr, ptr %l119, !tbaa !29
  %t238 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l123
  %t239 = call { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v0, ptr %t237, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t238)
  %t240 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 1
  %t241 = extractvalue { i32, %"compiler/check:roOrigin" } %t239, 0
  store i32 %t241, ptr %l125
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb70, label %ok.243, !prof !99
ok.243:
  store %"compiler/check:roOrigin" %t240, ptr %l124
  br label %bb69
bb69:
  %t244 = load %"compiler/check:roOrigin", ptr %l124
  store %"compiler/check:roOrigin" %t244, ptr %l117
  br label %bb73
bb70:
  br label %bb71
bb71:
  call void @__olang_ert_req_clear()
  %t245 = call %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v0, ptr null, i1 false)
  store %"compiler/check:roOrigin" %t245, ptr %l126
  br label %bb72
bb72:
  %t246 = load %"compiler/check:roOrigin", ptr %l126
  store %"compiler/check:roOrigin" %t246, ptr %l117
  br label %bb73
bb73:
  %t247 = load %"compiler/check:roOrigin", ptr %l117
  store %"compiler/check:roOrigin" %t247, ptr %l13
  %t248 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb74, label %bb75
bb74:
  %t255 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 1
  %t256 = load i1, ptr %t255, !tbaa !21
  store i1 %t256, ptr %l130, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb76
bb76:
  %t258 = load i1, ptr %l130, !tbaa !21
  br i1 %t258, label %bb77, label %bb78
bb77:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:roOrigin", ptr %l13, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t262 = load i64, ptr %l2, !tbaa !24
  %t264 = add i64 %t262, 1
  %t268 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootIn(ptr %v0, ptr %v0, ptr %t259, ptr %t261, i64 %t264)
  store i64 %t268, ptr %l136
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t269 = load i64, ptr %l136, !tbaa !24
  store i64 %t269, ptr %rv
  br label %ret
bb80:
  br label %bb86
bb81:
  br i1 true, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_86e950cd41bc9656_5dbe90d10bea6a92)
  unreachable
bb86:
  store i64 -1, ptr %rv
  br label %ret
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  store i64 -1, ptr %rv
  br label %ret
bb91:
  call void @__olang_check_failed(ptr @olang_loc_67c0878bde4afa77_9afdcd15cbb29493)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l56 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca i1
  %l84 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l103 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l122 = alloca i1
  %l128 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l143 = alloca ptr
  %l145 = alloca ptr
  %l149 = alloca i1
  %l153 = alloca i1
  %l157 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l21, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l22, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l22, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t17 = load ptr, ptr %l27, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l27, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l28, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l28, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l3, !tbaa !23
  %t32 = load i32, ptr %l4, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_e181575e6035f202_99a6d5836a9bf6a6)
  unreachable
bb16:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t39 = load ptr, ptr %l37, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t42 = load ptr, ptr %l37, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 1
  store i1 %t45, ptr %l38, !tbaa !21
  br label %bb18
bb18:
  %t46 = load i1, ptr %l38, !tbaa !21
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t49, i32 0, i32 2
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l5, !tbaa !24
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [4 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t55, i32 0, i32 3
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb35
bb21:
  %t59 = load ptr, ptr %l2, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l45, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 1
  store i1 %t66, ptr %l46, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l46, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l7, !tbaa !24
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t76, i32 0, i32 3
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l8, !tbaa !23
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t86 = load i32, ptr %l6, !tbaa !23
  %t87 = load i32, ptr %l8, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  store i1 %t90, ptr %l56, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb29
bb29:
  %t92 = load i1, ptr %l56, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_a5d3444dbde3a383_cb32d8a11a505607)
  unreachable
bb35:
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t95 = load ptr, ptr %l61, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb36, label %bb37
bb36:
  %t98 = load ptr, ptr %l61, !tbaa !29
  %t99 = load i64, ptr %t98, !range !{i64 0, i64 8}
  %t101 = icmp eq i64 %t99, 3
  store i1 %t101, ptr %l62, !tbaa !21
  br label %bb37
bb37:
  %t102 = load i1, ptr %l62, !tbaa !21
  br i1 %t102, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr { i64, [4 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l9, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t111, i32 0, i32 3
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l10, !tbaa !24
  br label %bb40
bb39:
  br label %bb55
bb40:
  %t115 = load ptr, ptr %l2, !tbaa !29
  store ptr %t115, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t116 = load ptr, ptr %l69, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l69, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 8}
  %t122 = icmp eq i64 %t120, 3
  store i1 %t122, ptr %l70, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l70, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t126, i32 0, i32 2
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l11, !tbaa !29
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t132, i32 0, i32 3
  %t134 = load i64, ptr %t133
  store i64 %t134, ptr %l12, !tbaa !24
  br label %bb45
bb44:
  br label %bb50
bb45:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp eq i64 %t136, %t137
  br i1 %t140, label %bb46, label %bb47
bb46:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l9, !tbaa !29
  %t144 = load ptr, ptr %l11, !tbaa !29
  %t148 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t142, ptr %t143, ptr %t144)
  store i1 %t148, ptr %l84
  br label %bb48
bb47:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb49
bb48:
  %t149 = load i1, ptr %l84, !tbaa !21
  store i1 %t149, ptr %l80, !tbaa !21
  br label %bb49
bb49:
  %t150 = load i1, ptr %l80, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i1 false, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_664096f84a6143a8_9c45533022ca790c)
  unreachable
bb55:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb56, label %bb57
bb56:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 4
  store i1 %t159, ptr %l87, !tbaa !21
  br label %bb57
bb57:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb58, label %bb59
bb58:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l13, !tbaa !29
  br label %bb60
bb59:
  br label %bb72
bb60:
  %t167 = load ptr, ptr %l2, !tbaa !29
  store ptr %t167, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t168 = load ptr, ptr %l92, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb61, label %bb62
bb61:
  %t171 = load ptr, ptr %l92, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 8}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l93, !tbaa !21
  br label %bb62
bb62:
  %t175 = load i1, ptr %l93, !tbaa !21
  br i1 %t175, label %bb63, label %bb64
bb63:
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l14, !tbaa !29
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Elem", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Elem", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t194 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t182, ptr %t186, ptr %t190)
  store i1 %t194, ptr %l103
  br label %bb66
bb66:
  %t195 = load i1, ptr %l103, !tbaa !21
  store i1 %t195, ptr %rv
  br label %ret
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 false, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_5f0b92ad49630279_51f88f4b15ed303d)
  unreachable
bb72:
  %t197 = load ptr, ptr %l1, !tbaa !29
  store ptr %t197, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t198 = load ptr, ptr %l105, !tbaa !29
  %t199 = icmp ne ptr %t198, null
  br i1 %t199, label %bb73, label %bb74
bb73:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i64, ptr %t201, !range !{i64 0, i64 8}
  %t204 = icmp eq i64 %t202, 5
  store i1 %t204, ptr %l106, !tbaa !21
  br label %bb74
bb74:
  %t205 = load i1, ptr %l106, !tbaa !21
  br i1 %t205, label %bb75, label %bb76
bb75:
  %t206 = load ptr, ptr %l1, !tbaa !29
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t206, i32 0, i32 1
  %t209 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t208, i32 0, i32 2
  %t210 = load ptr, ptr %t209
  store ptr %t210, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb92
bb77:
  %t212 = load ptr, ptr %l2, !tbaa !29
  store ptr %t212, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t213 = load ptr, ptr %l111, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb78, label %bb79
bb78:
  %t216 = load ptr, ptr %l111, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 8}
  %t219 = icmp eq i64 %t217, 5
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb79
bb79:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb80, label %bb81
bb80:
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l16, !tbaa !29
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t227 = load ptr, ptr %l15, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Payload", ptr %t227, i32 0, i32 1
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load ptr, ptr %l16, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Payload", ptr %t231, i32 0, i32 1
  %t234 = load i64, ptr %t233, !tbaa !24
  %t237 = icmp eq i64 %t230, %t234
  br i1 %t237, label %bb83, label %bb84
bb83:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Payload", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l16, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Payload", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  %t251 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t239, ptr %t243, ptr %t247)
  store i1 %t251, ptr %l128
  br label %bb85
bb84:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb86
bb85:
  %t252 = load i1, ptr %l128, !tbaa !21
  store i1 %t252, ptr %l122, !tbaa !21
  br label %bb86
bb86:
  %t253 = load i1, ptr %l122, !tbaa !21
  store i1 %t253, ptr %rv
  br label %ret
bb87:
  br i1 true, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  store i1 false, ptr %rv
  br label %ret
bb91:
  call void @__olang_check_failed(ptr @olang_loc_265c788dd5eed9e_866edb98fc8c38ea)
  unreachable
bb92:
  %t255 = load ptr, ptr %l1, !tbaa !29
  store ptr %t255, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t256 = load ptr, ptr %l130, !tbaa !29
  %t257 = icmp ne ptr %t256, null
  br i1 %t257, label %bb93, label %bb94
bb93:
  %t259 = load ptr, ptr %l130, !tbaa !29
  %t260 = load i64, ptr %t259, !range !{i64 0, i64 8}
  %t262 = icmp eq i64 %t260, 2
  store i1 %t262, ptr %l131, !tbaa !21
  br label %bb94
bb94:
  %t263 = load i1, ptr %l131, !tbaa !21
  br i1 %t263, label %bb95, label %bb96
bb95:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr { i64, [4 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t266, i32 0, i32 2
  %t268 = load ptr, ptr %t267
  store ptr %t268, ptr %l17, !tbaa !29
  br label %bb97
bb96:
  br label %bb117
bb97:
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t271 = load ptr, ptr %l136, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb98, label %bb99
bb98:
  %t274 = load ptr, ptr %l136, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 8}
  %t277 = icmp eq i64 %t275, 2
  store i1 %t277, ptr %l137, !tbaa !21
  br label %bb99
bb99:
  %t278 = load i1, ptr %l137, !tbaa !21
  br i1 %t278, label %bb100, label %bb101
bb100:
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t281 = getelementptr { i64, [4 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t281, i32 0, i32 2
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l18, !tbaa !29
  br label %bb102
bb101:
  br label %bb112
bb102:
  %t285 = load ptr, ptr %l17, !tbaa !29
  %t287 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v1, ptr %t285)
  store ptr %t287, ptr %l143
  br label %bb103
bb103:
  %t288 = load ptr, ptr %l143, !tbaa !29
  store ptr %t288, ptr %l19, !tbaa !29
  %t289 = load ptr, ptr %l18, !tbaa !29
  %t291 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v2, ptr %v2, ptr %t289)
  store ptr %t291, ptr %l145
  br label %bb104
bb104:
  %t292 = load ptr, ptr %l145, !tbaa !29
  store ptr %t292, ptr %l20, !tbaa !29
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t295 = icmp eq ptr %t293, null
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb105, label %bb106
bb105:
  %t299 = load ptr, ptr %l20, !tbaa !29
  %t301 = icmp eq ptr %t299, null
  %t303 = xor i1 %t301, true
  store i1 %t303, ptr %l149, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb107
bb107:
  %t305 = load i1, ptr %l149, !tbaa !21
  br i1 %t305, label %bb108, label %bb109
bb108:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l19, !tbaa !29
  %t308 = load ptr, ptr %l20, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esamePlace(ptr %v0, ptr %v1, ptr %v2, ptr %t306, ptr %t307, ptr %t308)
  store i1 %t312, ptr %l157
  br label %bb110
bb109:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb111
bb110:
  %t313 = load i1, ptr %l157, !tbaa !21
  store i1 %t313, ptr %l153, !tbaa !21
  br label %bb111
bb111:
  %t314 = load i1, ptr %l153, !tbaa !21
  store i1 %t314, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  store i1 false, ptr %rv
  br label %ret
bb116:
  call void @__olang_check_failed(ptr @olang_loc_6ac4c8202b0b581f_2f15107fd7d9b5ab)
  unreachable
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store i1 false, ptr %rv
  br label %ret
bb121:
  call void @__olang_check_failed(ptr @olang_loc_8bfef52d6d2c65e4_ce3ff42f583fc170)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca i32
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t34)
  store i32 %t37, ptr %l29
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t38 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t40 = trunc i64 30 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t55 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t49, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t62 = load i32, ptr %l40, !tbaa !23
  %t63 = icmp eq i32 %t62, 0
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  store i1 %t79, ptr %l5, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 4
  store i1 true, ptr %t83, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t112 = load i64, ptr %l57, !tbaa !24
  store i64 %t112, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t144)
  store i32 %t147, ptr %l81
  br label %bb27
bb27:
  %t148 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t150 = trunc i64 30 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb30, label %bb31
bb29:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb34, label %bb35
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb32:
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t162, { i64, ptr } %t163)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t168, ptr %l93, !tbaa !27
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t166, ptr %t167, i32 %t174, i1 false)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l10, !tbaa !24
  br label %bb23
bb41:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 4
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t187, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i64
  %l11 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l29 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l37 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l48 = alloca %"compiler/generic:Context"
  %l50 = alloca ptr
  %l53 = alloca i32
  %l56 = alloca i64
  %l60 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/typed:Block"
  %l95 = alloca i64
  %l98 = alloca i1
  %l101 = alloca i64
  %l104 = alloca i1
  %l112 = alloca ptr
  %rv = alloca i64
  %t35 = alloca { i64, [2 x i64] }, align 8
  %t80 = alloca %"compiler/generic:Context", align 8
  %t134 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l4, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l18
  br label %bb1
bb1:
  %t15 = load i64, ptr %l18, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 15
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l21
  br label %bb2
bb2:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 125
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l7, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t27)
  store %"compiler/source:Span" %t29, ptr %l25
  br label %bb3
bb3:
  %t30 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t30, ptr %l8
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t34 = load i32, ptr %t33, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t35
  %t36 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 0
  store i64 7, ptr %t36
  %t38 = insertvalue { i64, i32 } undef, i64 %t32, 0
  %t40 = insertvalue { i64, i32 } %t38, i32 %t34, 1
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t35, i32 0, i32 1
  store { i64, i32 } %t40, ptr %t41
  %t42 = load { i64, [2 x i64] }, ptr %t35
  store { i64, [2 x i64] } %t42, ptr %l29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l3, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t48, i32 0, i32 %t49, i32 0, i32 0, i64 0, i1 false, i32 0)
  store i32 %t52, ptr %l34
  br label %bb4
bb4:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = load %"compiler/source:Span", ptr %l8
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load { i64, [2 x i64] }, ptr %l29
  %t57 = load i32, ptr %l34, !tbaa !23
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t55, { i64, [2 x i64] } %t56, i32 %t57, i64 %t53, %"compiler/source:Span" %t54)
  store i64 %t60, ptr %l37
  br label %bb5
bb5:
  %t61 = load i64, ptr %l37, !tbaa !24
  store i64 %t61, ptr %l9, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 19
  %t65 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t64, i64 %t65, i64 1)
  br label %bb6
bb6:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  %t71 = load i32, ptr %l3, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t68, i64 %t69, i64 %t70, i32 %t71, i32 0)
  store ptr %t76, ptr %l45
  br label %bb7
bb7:
  %t77 = load ptr, ptr %l45, !tbaa !29
  store ptr %t77, ptr %l46, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fgeneric_3aContext_2ector(ptr %t80, ptr %v0, i64 %t79, i64 -1)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t80, i64 160, i1 false)
  br label %bb8
bb8:
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t82, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %t83, ptr %l48, i64 160, i1 false)
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t84)
  store ptr %t86, ptr %l50
  br label %bb9
bb9:
  %t87 = load %"compiler/source:Span", ptr %l8
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t91 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t88, i32 -1, i32 0, %"compiler/source:Span" %t87)
  store i32 %t91, ptr %l53
  br label %bb10
bb10:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 37
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t94)
  store i64 %t96, ptr %l56
  br label %bb11
bb11:
  %t97 = load i64, ptr %l56, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  %t98 = load i32, ptr %l3, !tbaa !23
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t102 = icmp eq i32 %t98, %t99
  br i1 %t102, label %bb12, label %bb13
bb12:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v0, ptr %t104, ptr %t105)
  store ptr %t108, ptr %l63
  br label %bb14
bb13:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l64, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t110, ptr %t111, i32 %t113)
  store ptr %t117, ptr %l69
  br label %bb15
bb14:
  %t118 = load ptr, ptr %l63, !tbaa !29
  store ptr %t118, ptr %l60, !tbaa !29
  br label %bb17
bb15:
  %t119 = load i32, ptr %l3, !tbaa !23
  %t120 = load %"compiler/source:Span", ptr %l8
  %t121 = load ptr, ptr %l64, !tbaa !29
  %t122 = load ptr, ptr %l69, !tbaa !29
  %t125 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t121, ptr %t122, i32 %t119, %"compiler/source:Span" %t120)
  store ptr %t125, ptr %l72
  br label %bb16
bb16:
  %t126 = load ptr, ptr %l72, !tbaa !29
  store ptr %t126, ptr %l60, !tbaa !29
  br label %bb17
bb17:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 37
  %t131 = load %"compiler/source:Span", ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 0
  store i64 6, ptr %t135
  %t137 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t131, 0
  %t139 = insertvalue { %"compiler/source:Span", ptr } %t137, ptr %t127, 1
  %t140 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t139, ptr %t140
  %t141 = load { i64, [3 x i64] }, ptr %t134
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t141, ptr %t143
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t130, ptr %t143)
  br label %bb18
bb18:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t146)
  store ptr %t148, ptr %l81
  br label %bb19
bb19:
  %t149 = load ptr, ptr %l81, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 37
  %t153 = load i64, ptr %l11, !tbaa !24
  %t156 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t152, i64 %t153)
  store { i64, ptr } %t156, ptr %l86
  br label %bb20
bb20:
  %t157 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t158 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t157)
  store %"compiler/typed:Block" %t158, ptr %l87
  br label %bb21
bb21:
  %t159 = load %"compiler/typed:Block", ptr %l87
  %t160 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t159, ptr %t160
  %t162 = load ptr, ptr %l82, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 11
  store ptr %t160, ptr %t163, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t164)
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 19
  %t169 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t168, i64 %t169, i64 2)
  br label %bb23
bb23:
  %t172 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t172)
  br label %bb24
bb24:
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l95
  br label %bb25
bb25:
  %t177 = load i64, ptr %l5, !tbaa !24
  %t178 = load i64, ptr %l95, !tbaa !24
  %t180 = icmp sgt i64 %t178, %t177
  br i1 %t180, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb29
bb27:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 15
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l101
  br label %bb28
bb28:
  %t187 = load i64, ptr %l6, !tbaa !24
  %t188 = load i64, ptr %l101, !tbaa !24
  %t190 = icmp sgt i64 %t188, %t187
  store i1 %t190, ptr %l98, !tbaa !21
  br label %bb29
bb29:
  %t192 = load i1, ptr %l98, !tbaa !21
  br i1 %t192, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb32
bb31:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 125
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i64, ptr %l7, !tbaa !24
  %t200 = icmp sgt i64 %t196, %t197
  store i1 %t200, ptr %l104, !tbaa !21
  br label %bb32
bb32:
  %t202 = load i1, ptr %l104, !tbaa !21
  br i1 %t202, label %bb33, label %bb34
bb33:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 14
  %t206 = load i64, ptr %l9, !tbaa !24
  %t209 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t205, i64 %t206)
  store ptr %t209, ptr %l112
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t210 = load ptr, ptr %l112, !tbaa !29
  %t212 = getelementptr %"compiler/typed:Body", ptr %t210, i32 0, i32 11
  store ptr null, ptr %t212, !tbaa !29
  store i64 -1, ptr %rv
  br label %ret
bb36:
  %t214 = load i64, ptr %l9, !tbaa !24
  store i64 %t214, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/generic:AnySlot"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/generic:AnySlot" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t4 = icmp slt i64 %t2, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l9, !tbaa !29
  %t23 = load i32, ptr %l14, !tbaa !23
  %t24 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t22, i32 %t23)
  store ptr %t24, ptr %l15
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l15, !tbaa !29
  store ptr %t25, ptr %l2, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:TypeDecl", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/ast:TypeDecl", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 5}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr { i64, [6 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t55, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56
  store { i64, ptr } %t57, ptr %l4, !tbaa !27
  br label %bb16
bb15:
  br label %bb20
bb16:
  %t59 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t66 = icmp slt i64 %t60, %t63
  br i1 %t66, label %bb17, label %bb18
bb17:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  %t69 = getelementptr %"compiler/generic:AnySlot", ptr %l1, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %t75, ptr %l35, !tbaa !29
  br label %bb19
bb18:
  store ptr null, ptr %l35, !tbaa !29
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l35, !tbaa !29
  store ptr %t78, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store ptr null, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b6a47344f78098a_9e5fbaf70b0ac586)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca %"compiler/names:Ref"
  %l27 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 10
  %t35 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t31, i64 %a1)
  store ptr %t35, ptr %l19
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t38 = getelementptr %"compiler/load:Module", ptr %t36, i32 0, i32 4
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l13, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l23
  br label %bb7
bb7:
  %t46 = load %"compiler/names:Ref", ptr %l23
  store %"compiler/names:Ref" %t46, ptr %l4
  %t47 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t48 = load i32, ptr %t47, !range !{i32 0, i32 9}
  %t50 = trunc i64 4 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t55 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t56 = load i64, ptr %t55, !tbaa !24
  %t58 = icmp slt i64 %t56, 0
  store i1 %t58, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t60 = load i1, ptr %l27, !tbaa !21
  br i1 %t60, label %bb11, label %bb12
bb11:
  %t61 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 9}
  %t64 = trunc i64 7 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  store ptr %t74, ptr %l35, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t86 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t78, i64 %t80, i64 %t82)
  store i32 %t86, ptr %l40
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l35, !tbaa !29
  %t88 = load i32, ptr %l40, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t89, ptr %l41
  br label %bb15
bb15:
  %t90 = load i32, ptr %l41, !range !{i32 0, i32 6}
  %t92 = trunc i64 3 to i32
  %t93 = icmp eq i32 %t90, %t92
  store i1 %t93, ptr %rv
  br label %ret
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_763b8bf7b0207b18_a2106654b6caec64)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l26 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l40 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i32
  %l50 = alloca i32
  %l54 = alloca { i64, ptr }
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l17, !tbaa !29
  %t23 = load i64, ptr %t22, !range !{i64 0, i64 5}
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l18, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  br label %bb11
bb10:
  br label %bb30
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v0, ptr %t33, i64 -1, i64 %a1, i32 %t35, i32 0)
  store ptr %t39, ptr %l26
  br label %bb12
bb12:
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  store i64 %t44, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb28
bb15:
  br label %bb16
bb16:
  %t54 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t54, ptr %l34, !tbaa !27
  %t55 = load i64, ptr %l6, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr ptr, ptr %t58, i64 %t55
  %t60 = load ptr, ptr %t59, !tbaa !39
  store ptr %t60, ptr %l8, !tbaa !29
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Func", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Sig", ptr %t65, i32 0, i32 2
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l8, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Func", ptr %t70, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Sig", ptr %t73, i32 0, i32 3
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  %t80 = icmp eq i64 %t78, 0
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l40, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Func", ptr %t84, i32 0, i32 0
  %t87 = getelementptr %"compiler/source:Span", ptr %t86, i32 0, i32 0
  %t88 = load i32, ptr %t87, !tbaa !23
  store i32 %t88, ptr %l48, !tbaa !23
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = getelementptr %"compiler/ast:Func", ptr %t89, i32 0, i32 0
  %t92 = getelementptr %"compiler/source:Span", ptr %t91, i32 0, i32 0
  %t93 = load i32, ptr %t92, !tbaa !23
  store i32 %t93, ptr %l50, !tbaa !23
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l8, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s5, ptr %t94, i32 %t98)
  store { i64, ptr } %t101, ptr %l54
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t102 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t105 = trunc i64 %t103 to i32
  %t106 = load i32, ptr %l50, !tbaa !23
  %t108 = add i32 %t106, %t105
  %t109 = load i32, ptr %l48, !tbaa !23
  %t111 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t109, i32 %t108)
  store %"compiler/source:Span" %t111, ptr %l58
  br label %bb23
bb23:
  %t112 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %s5)
  store %"compiler/msgs:Msg" %t112, ptr %l59
  br label %bb24
bb24:
  %t113 = load ptr, ptr %l46, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l58
  %t115 = load %"compiler/msgs:Msg", ptr %l59
  %t116 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t113, %"compiler/source:Span" %t114, %"compiler/msgs:Msg" %t115)
  store i64 %t116, ptr %l60
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t117 = load i64, ptr %l6, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l6, !tbaa !24
  br label %bb13
bb28:
  %t121 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t121)
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_cc3b7a6e318210b6_464c855cb4a991aa)
  unreachable
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca ptr
  %l17 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca ptr
  %l32 = alloca %"compiler/names:Ref"
  %l37 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i32
  %l57 = alloca i1
  %l60 = alloca i32
  %l62 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i32
  %l79 = alloca i1
  %l84 = alloca i32
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca %"compiler/names:Ref"
  %l106 = alloca i1
  %l109 = alloca ptr
  %l114 = alloca i32
  %l115 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca i1
  %l128 = alloca i32
  %l131 = alloca i1
  %l136 = alloca i32
  %l142 = alloca { i64, ptr }
  %l156 = alloca i32
  %l160 = alloca i32
  %l166 = alloca i1
  %l168 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l178 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l187 = alloca i64
  %l189 = alloca i64
  %l190 = alloca %"compiler/msgs:Msg"
  %l191 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca ptr
  %l201 = alloca i32
  %l205 = alloca i1
  %l209 = alloca i1
  %l211 = alloca i1
  %l215 = alloca i1
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  %t307 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l26, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l28
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l32
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l32
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 9}
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l37
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp ne i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l5, !tbaa !23
  store i32 %t61, ptr %l41, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l41, !tbaa !23
  br label %bb13
bb13:
  %t63 = load i32, ptr %l41, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb14:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t65 = load i32, ptr %t64, !range !{i32 0, i32 9}
  %t67 = trunc i64 4 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  store i1 %t73, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l45, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i32 %t88, ptr %l53
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t89 = load ptr, ptr %l48, !tbaa !29
  %t90 = load i32, ptr %l53, !tbaa !23
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l54
  br label %bb21
bb21:
  %t92 = load i32, ptr %l54, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb22:
  %t93 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93, !range !{i32 0, i32 9}
  %t96 = trunc i64 8 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb25
bb24:
  %t99 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t100 = load i32, ptr %t99, !range !{i32 0, i32 9}
  %t102 = trunc i64 0 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t106)
  store ptr %t108, ptr %l62
  br label %bb28
bb27:
  br label %bb44
bb28:
  %t109 = load ptr, ptr %l62, !tbaa !29
  %t111 = getelementptr %"compiler/check:frame", ptr %t109, i32 0, i32 4
  %t112 = getelementptr %"compiler/generic:Context", ptr %t111, i32 0, i32 2
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t112, i32 %t113)
  %t117 = extractvalue { i32, i32 } %t116, 1
  %t118 = extractvalue { i32, i32 } %t116, 0
  store i32 %t118, ptr %l67
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb30, label %ok.120, !prof !99
ok.120:
  store i32 %t117, ptr %l66
  br label %bb29
bb29:
  %t121 = load i32, ptr %l66, !tbaa !23
  store i32 %t121, ptr %l60, !tbaa !23
  br label %bb32
bb30:
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l60, !tbaa !23
  br label %bb32
bb32:
  %t122 = load i32, ptr %l60, !tbaa !23
  store i32 %t122, ptr %l6, !tbaa !23
  %t123 = load i32, ptr %l6, !tbaa !23
  %t125 = icmp sge i32 %t123, 0
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l6, !tbaa !23
  %t136 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t136, ptr %l75
  br label %bb35
bb34:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb36
bb35:
  %t137 = load i32, ptr %l75, !range !{i32 0, i32 33}
  %t139 = trunc i64 26 to i32
  %t140 = icmp eq i32 %t137, %t139
  %t142 = xor i1 %t140, true
  store i1 %t142, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l6, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t150, i32 %t151)
  store i32 %t154, ptr %l84
  br label %bb39
bb38:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t155 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t157 = trunc i64 27 to i32
  %t158 = icmp eq i32 %t155, %t157
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t162 = load i1, ptr %l79, !tbaa !21
  br i1 %t162, label %bb41, label %bb42
bb41:
  %t163 = load i32, ptr %l6, !tbaa !23
  store i32 %t163, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb117
bb45:
  %t165 = load ptr, ptr %l1, !tbaa !29
  store ptr %t165, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t166 = load ptr, ptr %l89, !tbaa !29
  %t167 = icmp ne ptr %t166, null
  br i1 %t167, label %bb46, label %bb47
bb46:
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = load i64, ptr %t169, !range !{i64 0, i64 30}
  %t172 = icmp eq i64 %t170, 14
  store i1 %t172, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t173 = load i1, ptr %l90, !tbaa !21
  br i1 %t173, label %bb48, label %bb49
bb48:
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr { i64, [4 x i64] }, ptr %t174, i32 0, i32 1
  %t177 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load %"compiler/source:Span", ptr %t177
  store %"compiler/source:Span" %t178, ptr %l7
  br label %bb50
bb49:
  br label %bb61
bb50:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  store ptr %t186, ptr %l97, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t187)
  store ptr %t189, ptr %l99
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l99, !tbaa !29
  %t192 = getelementptr %"compiler/check:frame", ptr %t190, i32 0, i32 2
  %t193 = load i64, ptr %t192, !tbaa !24
  %t194 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t195 = load i32, ptr %t194, !tbaa !23
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t199 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t196, i64 %t193, i32 %t195)
  store %"compiler/names:Ref" %t199, ptr %l103
  br label %bb52
bb52:
  %t200 = load %"compiler/names:Ref", ptr %l103
  store %"compiler/names:Ref" %t200, ptr %l8
  %t201 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t202 = load i32, ptr %t201, !range !{i32 0, i32 9}
  %t204 = trunc i64 4 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb53, label %bb54
bb53:
  %t207 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t208 = load i64, ptr %t207, !tbaa !24
  %t210 = icmp sge i64 %t208, 0
  store i1 %t210, ptr %l106, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb55
bb55:
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb56, label %bb57
bb56:
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l109, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t221 = load i64, ptr %t220, !tbaa !24
  %t225 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t217, i64 %t219, i64 %t221)
  store i32 %t225, ptr %l114
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t226 = load ptr, ptr %l109, !tbaa !29
  %t227 = load i32, ptr %l114, !tbaa !23
  %t228 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l115
  br label %bb59
bb59:
  %t229 = load i32, ptr %l115, !tbaa !23
  store i32 %t229, ptr %rv
  br label %ret
bb60:
  br label %bb117
bb61:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t231 = load ptr, ptr %l116, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l116, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 30}
  %t237 = icmp eq i64 %t235, 13
  store i1 %t237, ptr %l117, !tbaa !21
  br label %bb63
bb63:
  %t238 = load i1, ptr %l117, !tbaa !21
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t241, i32 0, i32 0
  %t243 = load %"compiler/source:Span", ptr %t242
  store %"compiler/source:Span" %t243, ptr %l9
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [4 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t247, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l10, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t253, i32 0, i32 2
  %t255 = load { i64, ptr }, ptr %t254
  store { i64, ptr } %t255, ptr %l11, !tbaa !27
  br label %bb66
bb65:
  br label %bb112
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l10, !tbaa !29
  %t261 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i32 %t261, ptr %l128
  br label %bb67
bb67:
  %t262 = load i32, ptr %l128, !tbaa !23
  store i32 %t262, ptr %l12, !tbaa !23
  %t263 = load i32, ptr %l12, !tbaa !23
  %t265 = icmp slt i32 %t263, 0
  br i1 %t265, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb71
bb69:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/generic:Program", ptr %t270, i32 0, i32 2
  %t273 = load i32, ptr %l12, !tbaa !23
  %t276 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t272, i32 %t273)
  store i32 %t276, ptr %l136
  br label %bb70
bb70:
  %t277 = load i32, ptr %l136, !range !{i32 0, i32 6}
  %t279 = trunc i64 1 to i32
  %t280 = icmp eq i32 %t277, %t279
  %t282 = xor i1 %t280, true
  store i1 %t282, ptr %l131, !tbaa !21
  br label %bb71
bb71:
  %t284 = load i1, ptr %l131, !tbaa !21
  br i1 %t284, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t286 = load ptr, ptr %l10, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %s8, ptr %t286)
  store { i64, ptr } %t288, ptr %l142
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  %t294 = icmp eq i64 %t292, 0
  br i1 %t294, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  %t297 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  %t301 = icmp eq i64 %t299, 1
  br i1 %t301, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l9
  %t305 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t307
  %t308 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 0
  store i64 0, ptr %t308
  %t310 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t304, 0
  %t312 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t310, { i64, ptr } %t305, 1
  %t314 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t312, { i64, ptr } %t306, 2
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t314, ptr %t315
  %t316 = load { i64, [5 x i64] }, ptr %t307
  %t318 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 48, i64 8)
  store { i64, [5 x i64] } %t316, ptr %t318
  %t321 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %s11, ptr %t303, ptr %t318)
  store i32 %t321, ptr %l156
  br label %bb81
bb80:
  br label %bb85
bb81:
  %t322 = load i32, ptr %l156, !tbaa !23
  store i32 %t322, ptr %l14, !tbaa !23
  %t323 = load i32, ptr %l14, !tbaa !23
  %t324 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t327 = icmp ne i32 %t323, %t324
  br i1 %t327, label %bb82, label %bb83
bb82:
  %t329 = load i32, ptr %l14, !tbaa !23
  store i32 %t329, ptr %l160, !tbaa !23
  br label %bb84
bb83:
  store i32 -1, ptr %l160, !tbaa !23
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s8)
  %t331 = load i32, ptr %l160, !tbaa !23
  store i32 %t331, ptr %rv
  br label %ret
bb85:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/check:Checker", ptr %t332, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !29
  %t336 = load i32, ptr %l12, !tbaa !23
  %t337 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t341 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t335, i32 %t336, { i64, ptr } %t337)
  store i1 %t341, ptr %l166
  br label %bb86
bb86:
  %t342 = load i1, ptr %l166, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s12
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l168, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb89, label %bb90
bb88:
  br label %bb98
bb89:
  %t352 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t352, ptr %l173, !tbaa !27
  %t353 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 0
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t356)
  store %"compiler/source:Span" %t358, ptr %l175
  br label %bb91
bb90:
  %t359 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t359, ptr %l172
  br label %bb92
bb91:
  %t361 = load %"compiler/source:Span", ptr %l175
  store %"compiler/source:Span" %t361, ptr %l172
  br label %bb92
bb92:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t363, ptr %l178, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  %t368 = sub i64 %t366, 1
  %t370 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr i32, ptr %t371, i64 %t368
  %t373 = load i32, ptr %t372, !tbaa !33
  %t376 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t362, i32 %t373)
  store { i64, ptr } %t376, ptr %l183
  br label %bb93
bb93:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t381 = load i32, ptr %l12, !tbaa !23
  %t384 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t380, i32 %t381)
  store i64 %t384, ptr %l187
  br label %bb94
bb94:
  %t385 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t387 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t385)
  store i64 %t387, ptr %l189
  br label %bb95
bb95:
  %t388 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t389 = load i64, ptr %l187, !tbaa !24
  %t390 = load i64, ptr %l189, !tbaa !24
  %t391 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s12, { i64, ptr } %t388, i64 %t389, i64 %t390)
  store %"compiler/msgs:Msg" %t391, ptr %l190
  br label %bb96
bb96:
  %t392 = load ptr, ptr %l168, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l172
  %t394 = load %"compiler/msgs:Msg", ptr %l190
  %t395 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t392, %"compiler/source:Span" %t393, %"compiler/msgs:Msg" %t394)
  store i64 %t395, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb98:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  store ptr %t400, ptr %l194, !tbaa !29
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t401)
  store ptr %t403, ptr %l196
  br label %bb99
bb99:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t406 = getelementptr %"compiler/check:frame", ptr %t404, i32 0, i32 4
  %t407 = load i32, ptr %l12, !tbaa !23
  %t408 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t409 = load ptr, ptr %l194, !tbaa !29
  %t413 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v1, ptr %t409, ptr %t406, i32 %t407, { i64, ptr } %t408)
  store i32 %t413, ptr %l201
  br label %bb100
bb100:
  %t414 = load i32, ptr %l201, !tbaa !23
  store i32 %t414, ptr %l15, !tbaa !23
  %t415 = load i32, ptr %l15, !tbaa !23
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t419 = icmp eq i32 %t415, %t416
  br i1 %t419, label %bb101, label %bb102
bb101:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb104
bb102:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i32, ptr %l15, !tbaa !23
  %t423 = load %"compiler/source:Span", ptr %l9
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t421, i32 %t422, %"compiler/source:Span" %t423)
  store i1 %t427, ptr %l209
  br label %bb103
bb103:
  %t428 = load i1, ptr %l209, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l205, !tbaa !21
  br label %bb104
bb104:
  %t431 = load i1, ptr %l205, !tbaa !21
  br i1 %t431, label %bb105, label %bb106
bb105:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb108
bb106:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  %t436 = load i32, ptr %l15, !tbaa !23
  %t439 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t435, i32 %t436)
  store i1 %t439, ptr %l215
  br label %bb107
bb107:
  %t440 = load i1, ptr %l215, !tbaa !21
  %t441 = xor i1 %t440, true
  store i1 %t441, ptr %l211, !tbaa !21
  br label %bb108
bb108:
  %t443 = load i1, ptr %l211, !tbaa !21
  br i1 %t443, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s8)
  store i32 -1, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t445 = load i32, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  store i32 %t445, ptr %rv
  br label %ret
bb112:
  br i1 true, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_check_failed(ptr @olang_loc_8b8738bb0f25fa76_719b7d77c23398a)
  unreachable
bb117:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %lp7 = alloca ptr
  %l13 = alloca ptr
  %l21 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l45 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca i1
  %l55 = alloca i32
  %l58 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca ptr
  %l64 = alloca i32
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/msgs:Msg"
  %l68 = alloca i64
  %l72 = alloca ptr
  %l76 = alloca i1
  %l80 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i32
  %l98 = alloca i1
  %l103 = alloca ptr
  %l109 = alloca ptr
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca %"compiler/source:Span"
  %l121 = alloca i32
  %l123 = alloca { i64, ptr }
  %l127 = alloca i32
  %l128 = alloca %"compiler/typed:Text"
  %l136 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  %t238 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t3 = trunc i64 18 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %v2, ptr %t6, %"compiler/source:Span" %t7, ptr %t8)
  store ptr %t12, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t13 = load ptr, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t13, ptr %rv
  br label %ret
bb4:
  %t15 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t17 = trunc i64 51 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %t20, %"compiler/source:Span" %t21, ptr %t22, i32 %t23)
  store ptr %t28, ptr %l21
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t29 = load ptr, ptr %l21, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t29, ptr %rv
  br label %ret
bb8:
  %t31 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t33 = trunc i64 48 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 40
  store i1 true, ptr %t38, !tbaa !21
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t39, ptr %t40, i32 %t42)
  store ptr %t46, ptr %l30
  br label %bb11
bb10:
  br label %bb36
bb11:
  %t47 = load ptr, ptr %l30, !tbaa !29
  store ptr %t47, ptr %l5, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t52 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v2, ptr %t48, ptr %t49)
  store i64 %t52, ptr %l33
  br label %bb12
bb12:
  %t53 = load i64, ptr %l33, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  br i1 %t54, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb17
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t57)
  store i32 %t60, ptr %l39
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i32, ptr %l39, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t61, i32 %t62)
  store i1 %t63, ptr %l40
  br label %bb16
bb16:
  %t64 = load i1, ptr %l40, !tbaa !21
  store i1 %t64, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l35, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v2, ptr %v2, ptr %t66, %"compiler/source:Span" %t67, i32 %t68, ptr %t69)
  store ptr %t74, ptr %l45
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t75 = load ptr, ptr %l45, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t75, ptr %rv
  br label %ret
bb21:
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t80 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t77)
  store i32 %t80, ptr %l49
  br label %bb22
bb22:
  %t81 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t82 = load i32, ptr %l49, !tbaa !23
  %t84 = icmp ne i32 %t82, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t89 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t86)
  store i32 %t89, ptr %l55
  br label %bb25
bb24:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb26
bb25:
  %t90 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t91 = load i32, ptr %l55, !tbaa !23
  %t93 = icmp ne i32 %t91, %t90
  store i1 %t93, ptr %l52, !tbaa !21
  br label %bb26
bb26:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l58, !tbaa !29
  %t97 = load ptr, ptr %l3, !tbaa !29
  %t99 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t97)
  store %"compiler/source:Span" %t99, ptr %l60
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l61, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t101)
  store i32 %t104, ptr %l64
  br label %bb30
bb30:
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l64, !tbaa !23
  %t107 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t105, i32 %t106)
  store { i64, ptr } %t107, ptr %l65
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } %t114)
  store %"compiler/msgs:Msg" %t116, ptr %l67
  br label %bb32
bb32:
  %t117 = load ptr, ptr %l58, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/msgs:Msg", ptr %l67
  %t120 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t117, %"compiler/source:Span" %t118, %"compiler/msgs:Msg" %t119)
  store i64 %t120, ptr %l68
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l1
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v2, ptr %v2, ptr %t121, %"compiler/source:Span" %t122, ptr %t123)
  store ptr %t127, ptr %l72
  br label %bb35
bb35:
  %t128 = load ptr, ptr %l72, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t128, ptr %rv
  br label %ret
bb36:
  %t130 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t132 = trunc i64 53 to i32
  %t133 = icmp eq i32 %t130, %t132
  br i1 %t133, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb39
bb38:
  %t135 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t137 = trunc i64 88 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l76, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t141, i32 0, i32 40
  store i1 true, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = load i32, ptr %l4, !tbaa !23
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t145, ptr %t146, i32 %t148)
  store ptr %t152, ptr %l85
  br label %bb42
bb41:
  br label %bb56
bb42:
  %t153 = load ptr, ptr %l3, !tbaa !29
  %t155 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t153)
  store %"compiler/source:Span" %t155, ptr %l87
  br label %bb43
bb43:
  %t156 = load ptr, ptr %l80, !tbaa !29
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l87
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v0, ptr %v2, ptr %t156, ptr %t157, %"compiler/source:Span" %t158)
  store ptr %t159, ptr %l88
  br label %bb44
bb44:
  %t160 = load ptr, ptr %l88, !tbaa !29
  store ptr %t160, ptr %l6, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l6, !tbaa !29
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v2, ptr %t161, ptr %t162)
  store i64 %t165, ptr %l91
  br label %bb45
bb45:
  %t166 = load i64, ptr %l91, !tbaa !24
  %t167 = icmp sge i64 %t166, 0
  br i1 %t167, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb50
bb47:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l94, !tbaa !29
  %t170 = load ptr, ptr %l6, !tbaa !29
  %t173 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t170)
  store i32 %t173, ptr %l97
  br label %bb48
bb48:
  %t174 = load ptr, ptr %l94, !tbaa !29
  %t175 = load i32, ptr %l97, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t174, i32 %t175)
  store i1 %t176, ptr %l98
  br label %bb49
bb49:
  %t177 = load i1, ptr %l98, !tbaa !21
  store i1 %t177, ptr %l93, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l93, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l1
  %t181 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t182 = load ptr, ptr %l6, !tbaa !29
  %t187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v2, ptr %v2, ptr %t179, %"compiler/source:Span" %t180, i32 %t181, ptr %t182)
  store ptr %t187, ptr %l103
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t188 = load ptr, ptr %l103, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t188, ptr %rv
  br label %ret
bb54:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t193 = load ptr, ptr %l6, !tbaa !29
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v2, ptr %v2, ptr %t190, %"compiler/source:Span" %t191, i32 %t192, ptr %t193)
  store ptr %t198, ptr %l109
  br label %bb55
bb55:
  %t199 = load ptr, ptr %l109, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t199, ptr %rv
  br label %ret
bb56:
  %t201 = load i32, ptr %l2, !range !{i32 0, i32 98}
  %t203 = trunc i64 89 to i32
  %t204 = icmp eq i32 %t201, %t203
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t206 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l113
  br label %bb59
bb58:
  br label %bb66
bb59:
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t207, ptr %lp7
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113
  %t209 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %t209
  %t210 = load ptr, ptr %lp7
  store ptr %t210, ptr %l114, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/source:Span", ptr %l1
  %t213 = load ptr, ptr %l3, !tbaa !29
  %t217 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %v0, ptr %t211, %"compiler/source:Span" %t212, ptr %t213)
  store ptr %t217, ptr %l118
  br label %bb60
bb60:
  %t218 = load ptr, ptr %l114, !tbaa !29
  %t219 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v2, ptr %v0, ptr %t218, ptr %t219)
  br label %bb61
bb61:
  %t220 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t220, ptr %l119
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t221)
  store i32 %t223, ptr %l121
  br label %bb62
bb62:
  %t224 = load ptr, ptr %lp7
  %t226 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v2, ptr %v2, ptr %t224)
  store { i64, ptr } %t226, ptr %l123
  br label %bb63
bb63:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t232 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t227, i32 4, %"compiler/source:Span" %t228)
  store i32 %t232, ptr %l127
  br label %bb64
bb64:
  %t233 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t234 = load i32, ptr %l127, !tbaa !23
  %t235 = call %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v2, ptr %v2, { i64, ptr } %t233, i32 %t234)
  store %"compiler/typed:Text" %t235, ptr %l128
  br label %bb65
bb65:
  %t236 = load %"compiler/typed:Text", ptr %l128
  %t237 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Text" %t236, ptr %t237
  store { i64, [5 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 0
  store i64 16, ptr %t239
  %t240 = load %"compiler/source:Span", ptr %l119
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t240, 0
  %t242 = load i32, ptr %l121, !tbaa !23
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } %t241, i32 %t242, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, ptr %t237, 2
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t245, ptr %t246
  %t247 = load { i64, [5 x i64] }, ptr %t238
  %t249 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t247, ptr %t249
  call void @__olang_scope_close(ptr %s0)
  store ptr %t249, ptr %rv
  br label %ret
bb66:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t251, %"compiler/source:Span" %t252, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d34, i32 0, i32 1) })
  br label %bb67
bb67:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t255, %"compiler/source:Span" %t256)
  store ptr %t259, ptr %l136
  br label %bb68
bb68:
  %t260 = load ptr, ptr %l136, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t260, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunspreadAll(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l44 = alloca i64
  %l48 = alloca { i64, ptr }
  %l51 = alloca i32
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 0
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l14, !tbaa !24
  %t16 = icmp sle i64 %t15, 2305843009213693951
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_b692ddd8e2182d13_c763079e5a61942f)
  unreachable
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = mul i64 %t18, 4
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t23, ptr %lp2
  %t25 = load ptr, ptr %lp2
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b692ddd8e2182d13_c763079e5a61942f)
  unreachable
bb8:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l26, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l23, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l23, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  br label %bb20
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t79 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l48, !tbaa !27
  %t84 = load i64, ptr %l8, !tbaa !24
  %t86 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr i32, ptr %t87, i64 %t84
  %t89 = load i32, ptr %t88, !tbaa !33
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %t82, i32 %t89)
  store i32 %t92, ptr %l51
  br label %bb18
bb18:
  %t93 = load i32, ptr %l51, !tbaa !23
  %t94 = load ptr, ptr %lp2
  %t95 = load i64, ptr %l44, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t95
  store i32 %t93, ptr %t98, !tbaa !33
  br label %bb19
bb19:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb14
bb20:
  %t103 = load ptr, ptr %lp2
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l171 = alloca i1
  %l176 = alloca i32
  %l178 = alloca i1
  %l181 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i64
  %l212 = alloca ptr
  %l221 = alloca i32
  %l226 = alloca i32
  %l230 = alloca ptr
  %l235 = alloca i32
  %l236 = alloca { i64, ptr }
  %l242 = alloca i64
  %l245 = alloca i64
  %l264 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l268 = alloca i1
  %l269 = alloca i1
  %l272 = alloca ptr
  %l276 = alloca { i64, ptr }
  %l279 = alloca i32
  %l280 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l297 = alloca %"compiler/source:Span"
  %l300 = alloca { i64, ptr }
  %l302 = alloca %"compiler/msgs:Msg"
  %l303 = alloca i64
  %l308 = alloca i64
  %l312 = alloca i64
  %l315 = alloca i1
  %l318 = alloca i1
  %l322 = alloca i1
  %l346 = alloca i64
  %l349 = alloca ptr
  %l350 = alloca %"compiler/source:Span"
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca i64
  %l356 = alloca ptr
  %l359 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l368 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i32
  %l373 = alloca i64
  %l376 = alloca ptr
  %l379 = alloca %"compiler/source:Span"
  %l392 = alloca i64
  %l395 = alloca i64
  %l398 = alloca i1
  %l401 = alloca ptr
  %l404 = alloca ptr
  %l408 = alloca i32
  %l409 = alloca i32
  %l410 = alloca { i64, ptr }
  %l414 = alloca ptr
  %l415 = alloca ptr
  %l420 = alloca i1
  %l435 = alloca i1
  %l437 = alloca ptr
  %l440 = alloca %"compiler/source:Span"
  %l441 = alloca i32
  %l444 = alloca { i64, ptr }
  %l446 = alloca %"compiler/msgs:Msg"
  %l447 = alloca i64
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  %t196 = alloca { i64, [3 x i64] }, align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 30}
  %t13 = icmp eq i64 %t11, 24
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %v3, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l44
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l44, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68)
  unreachable
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l48, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb16
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t52, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l57
  br label %bb17
bb17:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/ast:ForIn", ptr %t64, i32 0, i32 3
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l61
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t72 = load ptr, ptr %l61, !tbaa !29
  store ptr %t72, ptr %l62, !tbaa !29
  %t73 = load ptr, ptr %l62, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 15
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 15
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l67
  br label %bb22
bb22:
  %t85 = load i32, ptr %l67, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  br i1 %t90, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l74
  br label %bb26
bb26:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l9, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb27, label %bb28
bb27:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l80
  br label %bb29
bb28:
  br label %bb75
bb29:
  %t110 = load i1, ptr %l80, !tbaa !21
  br i1 %t110, label %bb30, label %bb31
bb30:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l81, !tbaa !23
  br label %bb33
bb31:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t118, i32 %t119, i64 %t120)
  store i32 %t124, ptr %l88
  br label %bb32
bb32:
  %t125 = load i32, ptr %l88, !tbaa !23
  store i32 %t125, ptr %l81, !tbaa !23
  br label %bb33
bb33:
  %t126 = load i32, ptr %l81, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l10, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129)
  store i64 %t133, ptr %l92
  br label %bb34
bb34:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 74
  store ptr %t137, ptr %l94, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t138, i64 %t139)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t142, ptr %l97
  br label %bb35
bb35:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l100
  br label %bb36
bb36:
  %t148 = load i1, ptr %l100, !tbaa !21
  br i1 %t148, label %bb37, label %bb38
bb37:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t149, ptr %t150)
  store i1 %t154, ptr %l105
  br label %bb39
bb38:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l106, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l108
  br label %bb40
bb39:
  %t159 = load i1, ptr %l105, !tbaa !21
  store i1 %t159, ptr %l101, !tbaa !21
  br label %bb42
bb40:
  %t160 = load ptr, ptr %l106, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t160, ptr %t161)
  store i1 %t162, ptr %l109
  br label %bb41
bb41:
  %t163 = load i1, ptr %l109, !tbaa !21
  store i1 %t163, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t164 = load ptr, ptr %l94, !tbaa !29
  %t165 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l97
  %t166 = load i1, ptr %l101, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t164, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t165, i1 %t166)
  br label %bb43
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l110, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %l111, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l112, !tbaa !23
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:ForIn", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l115
  br label %bb44
bb44:
  %t176 = load ptr, ptr %l110, !tbaa !29
  %t177 = load ptr, ptr %l111, !tbaa !29
  %t178 = load i32, ptr %l112, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr %l115
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v0, ptr %v0, ptr %t176, ptr %t177, i32 %t178, %"compiler/source:Span" %t179)
  store ptr %t180, ptr %l116
  br label %bb45
bb45:
  %t181 = load ptr, ptr %l116, !tbaa !29
  store ptr %t181, ptr %l12, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t182, i64 %t183, ptr %t184)
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  %t195 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t193, 1
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t195, 2
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [3 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t205, ptr %t207
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t189, ptr %t207)
  br label %bb47
bb47:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l129, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l130
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l132
  br label %bb48
bb48:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l130
  %t217 = load i32, ptr %l132, !tbaa !23
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217)
  store i64 %t218, ptr %l133
  br label %bb49
bb49:
  %t219 = load i64, ptr %l133, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l135
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store i32 %t224, ptr %l138, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l139, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t227, ptr %l140
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t228)
  store i32 %t230, ptr %l142
  br label %bb50
bb50:
  %t231 = load ptr, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l140
  %t233 = load i32, ptr %l142, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t231, %"compiler/source:Span" %t232, i32 %t233, i64 0)
  store ptr %t234, ptr %l143
  br label %bb51
bb51:
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load %"compiler/source:Span", ptr %l135
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t237, 0
  %t239 = load i32, ptr %l138, !tbaa !23
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } %t238, i32 %t239, 1
  %t241 = load ptr, ptr %l143, !tbaa !29
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, ptr %t241, 2
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t242, ptr %t243
  %t244 = load { i64, [3 x i64] }, ptr %t235
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t247, ptr %t246)
  br label %bb52
bb52:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t250, ptr %l147
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l149
  br label %bb53
bb53:
  %t254 = load ptr, ptr %l146, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l147
  %t256 = load i32, ptr %l149, !tbaa !23
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256)
  store i64 %t257, ptr %l150
  br label %bb54
bb54:
  %t258 = load i64, ptr %l150, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l151, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l152
  %t261 = load i64, ptr %l14, !tbaa !24
  %t263 = trunc i64 %t261 to i32
  store i32 %t263, ptr %l155, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l156, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l157
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t267)
  store i32 %t269, ptr %l159
  br label %bb55
bb55:
  store i32 22, ptr %l160
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l11, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l164
  br label %bb56
bb56:
  %t277 = load ptr, ptr %l156, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l157
  %t279 = load i32, ptr %l159, !tbaa !23
  %t280 = load i32, ptr %l160, !range !{i32 0, i32 44}
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, i32 %t280, ptr %t281, ptr null)
  store ptr %t282, ptr %l165
  br label %bb57
bb57:
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 0, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l152
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t285, 0
  %t287 = load i32, ptr %l155, !tbaa !23
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } %t286, i32 %t287, 1
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, ptr %t289, 2
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t290, ptr %t291
  %t292 = load { i64, [3 x i64] }, ptr %t283
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t292, ptr %t294
  %t295 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t295, ptr %t294)
  br label %bb58
bb58:
  %t297 = load ptr, ptr %l3, !tbaa !29
  %t299 = icmp eq ptr %t297, null
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb59, label %bb60
bb59:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = getelementptr %"compiler/generic:Program", ptr %t306, i32 0, i32 2
  %t309 = load i32, ptr %l9, !tbaa !23
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t308, i32 %t309)
  store i32 %t312, ptr %l176
  br label %bb61
bb60:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb62
bb61:
  %t313 = load i32, ptr %l176, !tbaa !23
  %t314 = icmp ne i32 %t313, 0
  store i1 %t314, ptr %l171, !tbaa !21
  br label %bb62
bb62:
  %t316 = load i1, ptr %l171, !tbaa !21
  br i1 %t316, label %bb63, label %bb64
bb63:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = getelementptr %"compiler/check:Checker", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = getelementptr %"compiler/generic:Program", ptr %t320, i32 0, i32 2
  store ptr %t322, ptr %l181, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/check:Checker", ptr %t323, i32 0, i32 1
  %t326 = load ptr, ptr %t325, !tbaa !29
  %t328 = getelementptr %"compiler/generic:Program", ptr %t326, i32 0, i32 2
  %t329 = load i32, ptr %l9, !tbaa !23
  %t332 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t328, i32 %t329)
  store i32 %t332, ptr %l186
  br label %bb65
bb64:
  store i1 false, ptr %l178, !tbaa !21
  br label %bb67
bb65:
  %t333 = load ptr, ptr %l181, !tbaa !29
  %t334 = load i32, ptr %l186, !tbaa !23
  %t335 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t333, i32 %t334)
  store i32 %t335, ptr %l187
  br label %bb66
bb66:
  %t336 = load i32, ptr %l187, !range !{i32 0, i32 33}
  %t338 = trunc i64 26 to i32
  %t339 = icmp eq i32 %t336, %t338
  store i1 %t339, ptr %l178, !tbaa !21
  br label %bb67
bb67:
  %t341 = load i1, ptr %l178, !tbaa !21
  br i1 %t341, label %bb68, label %bb69
bb68:
  %t342 = load ptr, ptr %l0, !tbaa !29
  store ptr %t342, ptr %l190, !tbaa !29
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t348 = getelementptr %"compiler/generic:Program", ptr %t346, i32 0, i32 2
  store ptr %t348, ptr %l193, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l9, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l198
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = load i32, ptr %l198, !tbaa !23
  %t361 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t359, i32 %t360)
  store i64 %t361, ptr %l199
  br label %bb71
bb71:
  %t362 = load i64, ptr %l199, !tbaa !24
  %t363 = load ptr, ptr %l190, !tbaa !29
  %t364 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 113
  store i64 %t362, ptr %t364, !tbaa !24
  br label %bb72
bb72:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t367 = load ptr, ptr %l2, !tbaa !29
  %t368 = load i64, ptr %l13, !tbaa !24
  %t369 = load i64, ptr %l14, !tbaa !24
  %t370 = load i64, ptr %l11, !tbaa !24
  %t371 = load i32, ptr %l9, !tbaa !23
  %t372 = load ptr, ptr %l3, !tbaa !29
  %t373 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t365, %"compiler/source:Span" %t366, ptr %t367, i64 %t368, i64 %t369, i64 %t370, i32 %t371, i64 -1, i64 -1, ptr %t372, i32 %t373)
  br label %bb73
bb73:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  %t385 = load i64, ptr %l14, !tbaa !24
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t383, %"compiler/source:Span" %t384, i64 %t385)
  store ptr %t389, ptr %l212
  br label %bb74
bb74:
  %t390 = load ptr, ptr %l212, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t390, ptr %rv
  br label %ret
bb75:
  %t392 = load ptr, ptr %l3, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb76, label %bb77
bb76:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %t398, %"compiler/source:Span" %t399)
  br label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb79
bb79:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l8, !tbaa !23
  %t406 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t406, ptr %l221
  br label %bb80
bb80:
  %t407 = load i32, ptr %l221, !tbaa !23
  store i32 %t407, ptr %l15, !tbaa !23
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/check:Checker", ptr %t408, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t413 = getelementptr %"compiler/generic:Program", ptr %t411, i32 0, i32 2
  %t414 = load i32, ptr %l15, !tbaa !23
  %t417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t413, i32 %t414)
  store i32 %t417, ptr %l226
  br label %bb81
bb81:
  %t418 = load i32, ptr %l226, !range !{i32 0, i32 33}
  %t420 = trunc i64 29 to i32
  %t421 = icmp eq i32 %t418, %t420
  br i1 %t421, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s9
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/check:Checker", ptr %t423, i32 0, i32 1
  %t426 = load ptr, ptr %t425, !tbaa !29
  store ptr %t426, ptr %l230, !tbaa !29
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/check:Checker", ptr %t427, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t432 = getelementptr %"compiler/generic:Program", ptr %t430, i32 0, i32 2
  %t433 = load i32, ptr %l15, !tbaa !23
  %t436 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t432, i32 %t433)
  store i32 %t436, ptr %l235
  br label %bb84
bb83:
  br label %bb113
bb84:
  %t437 = load ptr, ptr %l230, !tbaa !29
  %t438 = load i32, ptr %l235, !tbaa !23
  %t439 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t437, i32 %t438)
  store { i64, ptr } %t439, ptr %l236
  br label %bb85
bb85:
  %t440 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t440, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t441 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  store i64 %t443, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t445 = load i64, ptr %l18, !tbaa !24
  %t446 = load i64, ptr %l17, !tbaa !24
  %t449 = icmp sgt i64 %t445, %t446
  br i1 %t449, label %bb86, label %bb87
bb86:
  %t451 = load i64, ptr %l19, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  br i1 %t453, label %bb88, label %bb89
bb87:
  store i64 0, ptr %l242, !tbaa !24
  br label %bb91
bb88:
  %t455 = load i64, ptr %l18, !tbaa !24
  %t456 = load i64, ptr %l17, !tbaa !24
  %t459 = sub i64 %t455, %t456
  %t460 = load i64, ptr %l19, !tbaa !24
  %t463 = add i64 %t459, %t460
  %t465 = sub i64 %t463, 1
  %t466 = load i64, ptr %l19, !tbaa !24
  %t469 = sdiv i64 %t465, %t466
  store i64 %t469, ptr %l245, !tbaa !24
  br label %bb90
bb89:
  store i64 0, ptr %l245, !tbaa !24
  br label %bb90
bb90:
  %t471 = load i64, ptr %l245, !tbaa !24
  store i64 %t471, ptr %l242, !tbaa !24
  br label %bb91
bb91:
  %t472 = load i64, ptr %l242, !tbaa !24
  store i64 %t472, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s11
  %t473 = load i64, ptr %l21, !tbaa !24
  %t474 = load i64, ptr %l20, !tbaa !24
  %t477 = icmp slt i64 %t473, %t474
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s11)
  br label %bb108
bb94:
  br label %bb95
bb95:
  %t481 = load i64, ptr %l17, !tbaa !24
  %t482 = load i64, ptr %l21, !tbaa !24
  %t483 = load i64, ptr %l19, !tbaa !24
  %t486 = mul i64 %t482, %t483
  %t489 = add i64 %t481, %t486
  store i64 %t489, ptr %l22, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t492, ptr %l264, !tbaa !27
  %t493 = load i64, ptr %l22, !tbaa !24
  %t495 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t496 = load ptr, ptr %t495, !tbaa !27
  %t497 = getelementptr %"compiler/generic:AnySlot", ptr %t496, i64 %t493
  %t498 = getelementptr %"compiler/generic:AnySlot", ptr %t497, i32 0, i32 0
  %t499 = load i32, ptr %t498, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t491, i32 %t499)
  store { i64, ptr } %t502, ptr %l267
  br label %bb96
bb96:
  %t503 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t504 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s11, { i64, ptr } %t503, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t504, ptr %l268
  br label %bb97
bb97:
  %t505 = load i1, ptr %l268, !tbaa !21
  br i1 %t505, label %bb98, label %bb99
bb98:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/check:Checker", ptr %t506, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t511 = getelementptr %"compiler/generic:Program", ptr %t509, i32 0, i32 2
  store ptr %t511, ptr %l272, !tbaa !29
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/check:Checker", ptr %t512, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = getelementptr %"compiler/generic:Program", ptr %t515, i32 0, i32 2
  %t518 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t518, ptr %l276, !tbaa !27
  %t519 = load i64, ptr %l22, !tbaa !24
  %t521 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t522 = load ptr, ptr %t521, !tbaa !27
  %t523 = getelementptr %"compiler/generic:AnySlot", ptr %t522, i64 %t519
  %t524 = getelementptr %"compiler/generic:AnySlot", ptr %t523, i32 0, i32 5
  %t525 = load i32, ptr %t524, !tbaa !23
  %t528 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t517, i32 %t525)
  store i32 %t528, ptr %l279
  br label %bb100
bb99:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb102
bb100:
  %t529 = load ptr, ptr %l272, !tbaa !29
  %t530 = load i32, ptr %l279, !tbaa !23
  %t531 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s11, ptr %t529, i32 %t530)
  store { i64, ptr } %t531, ptr %l280
  br label %bb101
bb101:
  %t532 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t532, 0
  %t535 = icmp eq i64 %t533, 1
  store i1 %t535, ptr %l269, !tbaa !21
  br label %bb102
bb102:
  %t537 = load i1, ptr %l269, !tbaa !21
  br i1 %t537, label %bb103, label %bb104
bb103:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l1
  %t540 = load ptr, ptr %l2, !tbaa !29
  %t541 = load ptr, ptr %l7, !tbaa !29
  %t542 = load i64, ptr %l22, !tbaa !24
  %t544 = sub i64 -2, %t542
  %t545 = load ptr, ptr %l3, !tbaa !29
  %t546 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t538, %"compiler/source:Span" %t539, ptr %t540, ptr %t541, i64 %t544, ptr %t545, i32 %t546)
  br label %bb105
bb104:
  br label %bb106
bb105:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb106:
  call void @__olang_scope_close(ptr %s11)
  br label %bb107
bb107:
  %t555 = load i64, ptr %l21, !tbaa !24
  %t557 = add i64 %t555, 1
  store i64 %t557, ptr %l21, !tbaa !24
  br label %bb92
bb108:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l294, !tbaa !29
  %t560 = load ptr, ptr %l2, !tbaa !29
  %t562 = getelementptr %"compiler/ast:ForIn", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t565 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t563)
  store %"compiler/source:Span" %t565, ptr %l297
  br label %bb109
bb109:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load i32, ptr %l8, !tbaa !23
  %t570 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t566, i32 %t567)
  store { i64, ptr } %t570, ptr %l300
  br label %bb110
bb110:
  %t571 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t572 = extractvalue { i64, ptr } %t571, 0
  %t573 = extractvalue { i64, ptr } %t571, 1
  %t574 = mul i64 %t572, 1
  %t575 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t574)
  call void @llvm.memcpy.p0.p0.i64(ptr %t575, ptr %t573, i64 %t574, i1 false)
  %t576 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t577 = insertvalue { i64, ptr } %t576, ptr %t575, 1
  %t579 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s9, ptr %s9, { i64, ptr } %t577)
  store %"compiler/msgs:Msg" %t579, ptr %l302
  br label %bb111
bb111:
  %t580 = load ptr, ptr %l294, !tbaa !29
  %t581 = load %"compiler/source:Span", ptr %l297
  %t582 = load %"compiler/msgs:Msg", ptr %l302
  %t583 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t580, %"compiler/source:Span" %t581, %"compiler/msgs:Msg" %t582)
  store i64 %t583, ptr %l303
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb113:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load i32, ptr %l15, !tbaa !23
  %t587 = load %"compiler/source:Span", ptr %l1
  %t591 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t585, i32 %t586, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d36, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t587, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i64 %t591, ptr %l308
  br label %bb114
bb114:
  %t592 = load i64, ptr %l308, !tbaa !24
  store i64 %t592, ptr %l23, !tbaa !24
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load i32, ptr %l15, !tbaa !23
  %t595 = load %"compiler/source:Span", ptr %l1
  %t599 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t593, i32 %t594, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t595, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i64 %t599, ptr %l312
  br label %bb115
bb115:
  %t600 = load i64, ptr %l312, !tbaa !24
  store i64 %t600, ptr %l24, !tbaa !24
  %t601 = load i64, ptr %l24, !tbaa !24
  %t603 = icmp sge i64 %t601, 0
  br i1 %t603, label %bb116, label %bb117
bb116:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t606 = load i64, ptr %l24, !tbaa !24
  %t609 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t605, i64 %t606)
  store i1 %t609, ptr %l318
  br label %bb118
bb117:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb119
bb118:
  %t610 = load i1, ptr %l318, !tbaa !21
  %t611 = xor i1 %t610, true
  store i1 %t611, ptr %l315, !tbaa !21
  br label %bb119
bb119:
  %t613 = load i1, ptr %l315, !tbaa !21
  br i1 %t613, label %bb120, label %bb121
bb120:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb122
bb121:
  br label %bb122
bb122:
  %t614 = load i64, ptr %l23, !tbaa !24
  %t616 = icmp sge i64 %t614, 0
  br i1 %t616, label %bb123, label %bb124
bb123:
  %t618 = load i64, ptr %l24, !tbaa !24
  %t620 = icmp slt i64 %t618, 0
  store i1 %t620, ptr %l322, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb125
bb125:
  %t622 = load i1, ptr %l322, !tbaa !21
  br i1 %t622, label %bb126, label %bb127
bb126:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l1
  %t625 = load ptr, ptr %l2, !tbaa !29
  %t626 = load ptr, ptr %l7, !tbaa !29
  %t627 = load i64, ptr %l23, !tbaa !24
  %t628 = load ptr, ptr %l3, !tbaa !29
  %t629 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t623, %"compiler/source:Span" %t624, ptr %t625, ptr %t626, i64 %t627, ptr %t628, i32 %t629)
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb129:
  %t638 = load i64, ptr %l24, !tbaa !24
  %t640 = icmp sge i64 %t638, 0
  br i1 %t640, label %bb130, label %bb131
bb130:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load %"compiler/source:Span", ptr %l1
  %t644 = load ptr, ptr %l2, !tbaa !29
  %t645 = load ptr, ptr %l7, !tbaa !29
  %t646 = load i64, ptr %l24, !tbaa !24
  %t647 = load ptr, ptr %l3, !tbaa !29
  %t648 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t642, %"compiler/source:Span" %t643, ptr %t644, ptr %t645, i64 %t646, ptr %t647, i32 %t648)
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb133:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load i32, ptr %l15, !tbaa !23
  %t659 = load %"compiler/source:Span", ptr %l1
  %t663 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t657, i32 %t658, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) }, i64 0, %"compiler/source:Span" %t659, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i64 %t663, ptr %l346
  br label %bb134
bb134:
  %t664 = load i64, ptr %l346, !tbaa !24
  store i64 %t664, ptr %l25, !tbaa !24
  %t665 = load i64, ptr %l25, !tbaa !24
  %t667 = icmp sge i64 %t665, 0
  br i1 %t667, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s17
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l349, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l350
  %t671 = load ptr, ptr %l2, !tbaa !29
  %t673 = getelementptr %"compiler/ast:ForIn", ptr %t671, i32 0, i32 2
  %t674 = load ptr, ptr %t673, !tbaa !29
  %t676 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t674)
  store %"compiler/source:Span" %t676, ptr %l353
  br label %bb137
bb136:
  br label %bb160
bb137:
  %t677 = load i64, ptr %l25, !tbaa !24
  store i64 %t677, ptr %l354, !tbaa !24
  %t678 = load ptr, ptr %l7, !tbaa !29
  store ptr %t678, ptr %l356, !tbaa !29
  %t680 = icmp sge i64 0, 0
  br i1 %t680, label %bb138, label %bb139
bb138:
  %t682 = icmp sle i64 0, 1152921504606846975
  br i1 %t682, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb140:
  %t684 = mul i64 0, 8
  %t685 = insertvalue { i64, ptr } undef, i64 0, 0
  %t686 = insertvalue { i64, ptr } %t685, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t686, ptr %l359, !tbaa !27
  %t687 = icmp sge i64 0, 0
  br i1 %t687, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb142:
  %t689 = icmp sle i64 0, 1152921504606846975
  br i1 %t689, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb144:
  %t691 = mul i64 0, 8
  %t692 = insertvalue { i64, ptr } undef, i64 0, 0
  %t693 = insertvalue { i64, ptr } %t692, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t693, ptr %l362, !tbaa !27
  %t694 = icmp sge i64 0, 0
  br i1 %t694, label %bb146, label %bb147
bb145:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb146:
  %t696 = icmp sle i64 0, 2305843009213693951
  br i1 %t696, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb148:
  %t698 = mul i64 0, 4
  %t699 = insertvalue { i64, ptr } undef, i64 0, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t701 = load ptr, ptr %l349, !tbaa !29
  %t702 = load %"compiler/source:Span", ptr %l350
  %t703 = load %"compiler/source:Span", ptr %l353
  %t704 = load i64, ptr %l354, !tbaa !24
  %t705 = load ptr, ptr %l356, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l359, !tbaa !27
  %t707 = load { i64, ptr }, ptr %l362, !tbaa !27
  %t709 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t701, %"compiler/source:Span" %t702, %"compiler/source:Span" %t703, i64 %t704, ptr %t705, { i64, ptr } %t706, { i64, ptr } %t707, { i64, ptr } %t700)
  store ptr %t709, ptr %l366
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a734531b29123b5_def2307fb88201b9)
  unreachable
bb150:
  %t710 = load ptr, ptr %l366, !tbaa !29
  store ptr %t710, ptr %l26, !tbaa !29
  %t711 = load ptr, ptr %l0, !tbaa !29
  store ptr %t711, ptr %l367, !tbaa !29
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l368, !tbaa !29
  %t713 = load ptr, ptr %l26, !tbaa !29
  %t716 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t713)
  store i32 %t716, ptr %l371
  br label %bb151
bb151:
  %t717 = load ptr, ptr %l368, !tbaa !29
  %t718 = load i32, ptr %l371, !tbaa !23
  %t719 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t717, i32 %t718)
  store i32 %t719, ptr %l372
  br label %bb152
bb152:
  %t720 = load ptr, ptr %l367, !tbaa !29
  %t721 = load i32, ptr %l372, !tbaa !23
  %t722 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s17, ptr %t720, i32 %t721, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, i64 0)
  store i64 %t722, ptr %l373
  br label %bb153
bb153:
  %t723 = load i64, ptr %l373, !tbaa !24
  store i64 %t723, ptr %l27, !tbaa !24
  %t724 = load i64, ptr %l27, !tbaa !24
  %t726 = icmp slt i64 %t724, 0
  br i1 %t726, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s18
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l376, !tbaa !29
  %t729 = load ptr, ptr %l2, !tbaa !29
  %t731 = getelementptr %"compiler/ast:ForIn", ptr %t729, i32 0, i32 2
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t732)
  store %"compiler/source:Span" %t734, ptr %l379
  br label %bb156
bb155:
  br label %bb158
bb156:
  %t735 = load ptr, ptr %l376, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l379
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s18, ptr %t735, %"compiler/source:Span" %t736, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb158:
  %t738 = load ptr, ptr %l0, !tbaa !29
  %t739 = load %"compiler/source:Span", ptr %l1
  %t740 = load ptr, ptr %l2, !tbaa !29
  %t741 = load ptr, ptr %l26, !tbaa !29
  %t742 = load i64, ptr %l27, !tbaa !24
  %t743 = load ptr, ptr %l3, !tbaa !29
  %t744 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t738, %"compiler/source:Span" %t739, ptr %t740, ptr %t741, i64 %t742, ptr %t743, i32 %t744)
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb160:
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t754 = load i32, ptr %l15, !tbaa !23
  %t755 = load %"compiler/source:Span", ptr %l1
  %t759 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t753, i32 %t754, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, i64 1, %"compiler/source:Span" %t755, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i64 %t759, ptr %l392
  br label %bb161
bb161:
  %t760 = load i64, ptr %l392, !tbaa !24
  store i64 %t760, ptr %l28, !tbaa !24
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t762 = load i32, ptr %l15, !tbaa !23
  %t765 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t761, i32 %t762, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 0)
  store i64 %t765, ptr %l395
  br label %bb162
bb162:
  %t766 = load i64, ptr %l395, !tbaa !24
  store i64 %t766, ptr %l29, !tbaa !24
  %t767 = load i64, ptr %l28, !tbaa !24
  %t769 = icmp sge i64 %t767, 0
  br i1 %t769, label %bb163, label %bb164
bb163:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/check:Checker", ptr %t771, i32 0, i32 1
  %t774 = load ptr, ptr %t773, !tbaa !29
  %t776 = getelementptr %"compiler/generic:Program", ptr %t774, i32 0, i32 2
  store ptr %t776, ptr %l401, !tbaa !29
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = getelementptr %"compiler/check:Checker", ptr %t777, i32 0, i32 1
  %t780 = load ptr, ptr %t779, !tbaa !29
  %t782 = getelementptr %"compiler/generic:Program", ptr %t780, i32 0, i32 2
  store ptr %t782, ptr %l404, !tbaa !29
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  %t787 = load i64, ptr %l28, !tbaa !24
  %t790 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t786, i64 %t787)
  store i32 %t790, ptr %l408
  br label %bb165
bb164:
  store i1 false, ptr %l398, !tbaa !21
  br label %bb168
bb165:
  %t791 = load ptr, ptr %l404, !tbaa !29
  %t792 = load i32, ptr %l408, !tbaa !23
  %t793 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t791, i32 %t792)
  store i32 %t793, ptr %l409
  br label %bb166
bb166:
  %t794 = load ptr, ptr %l401, !tbaa !29
  %t795 = load i32, ptr %l409, !tbaa !23
  %t796 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t794, i32 %t795)
  store { i64, ptr } %t796, ptr %l410
  br label %bb167
bb167:
  %t797 = load { i64, ptr }, ptr %l410, !tbaa !27
  %t798 = extractvalue { i64, ptr } %t797, 0
  %t800 = icmp sgt i64 %t798, 0
  store i1 %t800, ptr %l398, !tbaa !21
  br label %bb168
bb168:
  %t802 = load i1, ptr %l398, !tbaa !21
  br i1 %t802, label %bb169, label %bb170
bb169:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t803)
  store ptr %t805, ptr %l414
  br label %bb171
bb170:
  br label %bb172
bb171:
  %t806 = load ptr, ptr %l414, !tbaa !29
  store ptr %t806, ptr %l415, !tbaa !29
  %t807 = load ptr, ptr %l415, !tbaa !29
  %t808 = getelementptr %"compiler/check:frame", ptr %t807, i32 0, i32 17
  %t809 = load i64, ptr %t808, !tbaa !24
  %t811 = add i64 %t809, 1
  %t813 = load ptr, ptr %l415, !tbaa !29
  %t814 = getelementptr %"compiler/check:frame", ptr %t813, i32 0, i32 17
  store i64 %t811, ptr %t814, !tbaa !24
  br label %bb172
bb172:
  %t815 = load i64, ptr %l28, !tbaa !24
  %t817 = icmp sge i64 %t815, 0
  br i1 %t817, label %bb173, label %bb174
bb173:
  %t819 = load i64, ptr %l29, !tbaa !24
  %t821 = icmp sge i64 %t819, 0
  store i1 %t821, ptr %l420, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l420, !tbaa !21
  br label %bb175
bb175:
  %t823 = load i1, ptr %l420, !tbaa !21
  br i1 %t823, label %bb176, label %bb177
bb176:
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t825 = load %"compiler/source:Span", ptr %l1
  %t826 = load ptr, ptr %l2, !tbaa !29
  %t827 = load ptr, ptr %l7, !tbaa !29
  %t828 = load i64, ptr %l28, !tbaa !24
  %t829 = load i64, ptr %l29, !tbaa !24
  %t830 = load ptr, ptr %l3, !tbaa !29
  %t831 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t824, %"compiler/source:Span" %t825, ptr %t826, ptr %t827, i64 %t828, i64 %t829, ptr %t830, i32 %t831)
  br label %bb178
bb177:
  br label %bb179
bb178:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb179:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t842 = load i32, ptr %l15, !tbaa !23
  %t843 = load %"compiler/source:Span", ptr %l1
  %t847 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t841, i32 %t842, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, %"compiler/source:Span" %t843, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) }, i64 0, i1 false)
  store i1 %t847, ptr %l435
  br label %bb180
bb180:
  %t848 = load i1, ptr %l435, !tbaa !21
  br i1 %t848, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb182:
  br label %bb183
bb183:
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l437, !tbaa !29
  %t851 = load ptr, ptr %l2, !tbaa !29
  %t853 = getelementptr %"compiler/ast:ForIn", ptr %t851, i32 0, i32 2
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t854)
  store %"compiler/source:Span" %t856, ptr %l440
  br label %bb184
bb184:
  %t857 = load i32, ptr %l8, !tbaa !23
  store i32 %t857, ptr %l441, !tbaa !23
  %t858 = load ptr, ptr %l0, !tbaa !29
  %t859 = load i32, ptr %l8, !tbaa !23
  %t862 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t858, i32 %t859)
  store { i64, ptr } %t862, ptr %l444
  br label %bb185
bb185:
  %t863 = load { i64, ptr }, ptr %l444, !tbaa !27
  %t864 = extractvalue { i64, ptr } %t863, 0
  %t865 = extractvalue { i64, ptr } %t863, 1
  %t866 = mul i64 %t864, 1
  %t867 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t866)
  call void @llvm.memcpy.p0.p0.i64(ptr %t867, ptr %t865, i64 %t866, i1 false)
  %t868 = insertvalue { i64, ptr } undef, i64 %t864, 0
  %t869 = insertvalue { i64, ptr } %t868, ptr %t867, 1
  %t871 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %s0, { i64, ptr } %t869)
  store %"compiler/msgs:Msg" %t871, ptr %l446
  br label %bb186
bb186:
  %t872 = load ptr, ptr %l437, !tbaa !29
  %t873 = load %"compiler/source:Span", ptr %l440
  %t874 = load i32, ptr %l441, !tbaa !23
  %t875 = load %"compiler/msgs:Msg", ptr %l446
  %t876 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eneedErr(ptr %v0, ptr %s0, ptr %s0, ptr %t872, %"compiler/source:Span" %t873, i32 %t874, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d49, i32 0, i32 1) }, %"compiler/msgs:Msg" %t875)
  store i64 %t876, ptr %l447
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i32
  %l18 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i1, ptr %l9, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l14
  br label %bb8
bb8:
  %t21 = load i32, ptr %l14, !range !{i32 0, i32 6}
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb12
bb12:
  %t37 = load i1, ptr %l22, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l28
  br label %bb17
bb17:
  %t50 = load i32, ptr %l28, !tbaa !23
  store i32 %t50, ptr %l2, !tbaa !23
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l35, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t79 = icmp eq i64 %t77, 1
  store i1 %t79, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l32, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %l37 = alloca ptr
  %l41 = alloca i64
  %l43 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l12
  br label %bb6
bb6:
  %t19 = load i64, ptr %l12, !tbaa !24
  store i64 %t19, ptr %rv
  br label %ret
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 6
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/typed:Call", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Call", ptr %t44, i32 0, i32 1
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l25, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  %t53 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t51)
  store i64 %t53, ptr %l27
  br label %bb15
bb14:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb16
bb15:
  %t54 = load i64, ptr %l27, !tbaa !24
  store i64 %t54, ptr %l23, !tbaa !24
  br label %bb16
bb16:
  %t55 = load i64, ptr %l23, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
bb17:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb19
bb19:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb20, label %bb21
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l3, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = call i64 @compiler_2fcheck_2ehandleRef(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb23
bb23:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %rv
  br label %ret
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8)
  unreachable
bb29:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v0, ptr %t75)
  store ptr %t77, ptr %l37
  br label %bb30
bb30:
  %t78 = load ptr, ptr %l37, !tbaa !29
  store ptr %t78, ptr %l4, !tbaa !29
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = icmp eq ptr %t79, null
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l43
  br label %bb33
bb32:
  store i64 -1, ptr %l41, !tbaa !24
  br label %bb34
bb33:
  %t88 = load i64, ptr %l43, !tbaa !24
  store i64 %t88, ptr %l41, !tbaa !24
  br label %bb34
bb34:
  %t89 = load i64, ptr %l41, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ehasNamed(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb17
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l15, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 30}
  %t30 = icmp eq i64 %t28, 26
  store i1 %t30, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_563ec608ec426d3c_d7d09179516a0f40)
  unreachable
bb15:
  br label %bb16
bb16:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l2, !tbaa !24
  br label %bb1
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i128
  %l5 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i128
  %l29 = alloca i128
  %l32 = alloca i1
  %l41 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i64
  %l76 = alloca i64
  %l82 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 6
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sle i64 %t10, 64
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb20
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l15
  br label %bb7
bb7:
  %t20 = load i1, ptr %l15, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  %t21 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb10, label %bb11
bb9:
  br label %bb16
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = icmp eq i64 %t26, 128
  br i1 %t28, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb15
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t30 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 8
  %t31 = load i128, ptr %t30
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = sext i64 %t32 to i128
  store i128 %t34, ptr %l24
  %t35 = load i128, ptr %l24
  %t36 = load i128, ptr %l24
  %t37 = shl i128 1, %t36
  %t40 = icmp ult i128 %t31, %t37
  store i1 %t40, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l18, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb16:
  %t44 = load i64, ptr %l3, !tbaa !24
  %t46 = sub i64 %t44, 1
  %t48 = sext i64 %t46 to i128
  store i128 %t48, ptr %l29
  %t49 = load i128, ptr %l29
  %t50 = load i128, ptr %l29
  %t51 = shl i128 1, %t50
  store i128 %t51, ptr %l4
  %t53 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 7
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t56 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 8
  %t57 = load i128, ptr %t56
  %t58 = load i128, ptr %l4
  %t61 = icmp ule i128 %t57, %t58
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  %t63 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 8
  %t64 = load i128, ptr %t63
  %t65 = load i128, ptr %l4
  %t68 = icmp ult i128 %t64, %t65
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t70 = load i1, ptr %l32, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb20:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t75 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t71, i32 %t72)
  store i1 %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t77 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t78 = load i1, ptr %t77, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb23:
  br label %bb45
bb24:
  %t80 = load i64, ptr %l3, !tbaa !24
  %t82 = icmp sge i64 %t80, 64
  store i1 %t82, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t84 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb27, label %bb28
bb27:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t89 = icmp sge i64 %t87, 64
  br i1 %t89, label %bb29, label %bb30
bb28:
  br label %bb38
bb29:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb37
bb30:
  %t91 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = icmp sge i64 %t92, 0
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t98 = icmp eq i64 %t96, 63
  br i1 %t98, label %bb33, label %bb34
bb32:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb36
bb33:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb35
bb34:
  %t100 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load i64, ptr %l3, !tbaa !24
  store i64 %t102, ptr %l56, !tbaa !24
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = load i64, ptr %l56, !tbaa !24
  %t105 = shl i64 1, %t104
  %t108 = icmp slt i64 %t101, %t105
  store i1 %t108, ptr %l54, !tbaa !21
  br label %bb35
bb35:
  %t110 = load i1, ptr %l54, !tbaa !21
  store i1 %t110, ptr %l51, !tbaa !21
  br label %bb36
bb36:
  %t111 = load i1, ptr %l51, !tbaa !21
  store i1 %t111, ptr %l48, !tbaa !21
  br label %bb37
bb37:
  %t112 = load i1, ptr %l48, !tbaa !21
  store i1 %t112, ptr %rv
  br label %ret
bb38:
  %t113 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t114 = load i64, ptr %t113, !tbaa !24
  %t116 = icmp slt i64 %t114, 0
  br i1 %t116, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = icmp sge i64 %t119, 63
  br i1 %t121, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb44
bb43:
  %t123 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t124 = load i64, ptr %t123, !tbaa !24
  %t125 = load i64, ptr %l3, !tbaa !24
  store i64 %t125, ptr %l66, !tbaa !24
  %t126 = load i64, ptr %l66, !tbaa !24
  %t127 = load i64, ptr %l66, !tbaa !24
  %t128 = shl i64 1, %t127
  %t131 = icmp slt i64 %t124, %t128
  store i1 %t131, ptr %l64, !tbaa !21
  br label %bb44
bb44:
  %t133 = load i1, ptr %l64, !tbaa !21
  store i1 %t133, ptr %rv
  br label %ret
bb45:
  %t134 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t135 = load i1, ptr %t134, !tbaa !21
  br i1 %t135, label %bb46, label %bb47
bb46:
  %t137 = load i64, ptr %l3, !tbaa !24
  %t139 = icmp sgt i64 %t137, 64
  store i1 %t139, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t141 = load i64, ptr %l3, !tbaa !24
  %t143 = icmp sge i64 %t141, 64
  br i1 %t143, label %bb49, label %bb50
bb49:
  store i1 true, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t146 = load i64, ptr %l3, !tbaa !24
  %t148 = sub i64 %t146, 1
  store i64 %t148, ptr %l76, !tbaa !24
  %t149 = load i64, ptr %l76, !tbaa !24
  %t150 = load i64, ptr %l76, !tbaa !24
  %t151 = shl i64 1, %t150
  store i64 %t151, ptr %l5, !tbaa !24
  %t153 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t154 = load i64, ptr %t153, !tbaa !24
  %t155 = load i64, ptr %l5, !tbaa !24
  %t157 = sub i64 0, %t155
  %t160 = icmp sge i64 %t154, %t157
  br i1 %t160, label %bb52, label %bb53
bb52:
  %t162 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t163 = load i64, ptr %t162, !tbaa !24
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  store i1 %t167, ptr %l82, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb54
bb54:
  %t169 = load i1, ptr %l82, !tbaa !21
  store i1 %t169, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisCallExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f1e8a29f5ea9d646_79fa5e0b2b57ed62)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2enoList() #0 {
entry:
  %l1 = alloca %"compiler/check:reflList"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s0, i1 false, i32 %t1, i64 0, i64 -1)
  store %"compiler/check:reflList" %t3, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:reflList", ptr %l1
  store %"compiler/check:reflList" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eopNeed(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t1)
  store { i64, ptr } %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t11 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t9)
  store { i64, ptr } %t11, ptr %l8
  br label %bb5
bb4:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t15 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t13)
  store { i64, ptr } %t15, ptr %l13
  br label %bb7
bb5:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t16)
  store { i64, ptr } %t17, ptr %l9
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  br label %bb9
bb7:
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t26 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t25)
  store { i64, ptr } %t26, ptr %l14
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t28, i64 %t29)
  %t41 = getelementptr i8, ptr %t40, i64 %t29
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = getelementptr i8, ptr %t41, i64 %t31
  call void @olang_textcopy(ptr %t42, ptr %t34, i64 %t35)
  %t43 = getelementptr i8, ptr %t42, i64 %t35
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fcheck_2eprotocolArity(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i64 @compiler_2fcheck_2eopShapeOf(ptr %v0, { i64, ptr } %t1)
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i64, ptr %l3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = getelementptr [23 x %"compiler/check:opShape"], ptr @G_2ecompiler_2fcheck_2eOpShapes, i64 0, i64 %t9
  %t12 = getelementptr %"compiler/check:opShape", ptr %t11, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t17, ptr %l9
  br label %bb5
bb5:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb9
bb7:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t21, ptr %l12
  br label %bb8
bb8:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l10, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb13
bb11:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t26 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t26, ptr %l15
  br label %bb12
bb12:
  %t27 = load i1, ptr %l15, !tbaa !21
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb13
bb13:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t30, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t32, ptr %l18
  br label %bb17
bb17:
  %t33 = load i1, ptr %l18, !tbaa !21
  br i1 %t33, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb21
bb19:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb20
bb20:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb21
bb21:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb25
bb23:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t41, ptr %l24
  br label %bb24
bb24:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb25
bb25:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  store i64 1, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t47, ptr %l27
  br label %bb29
bb29:
  %t48 = load i1, ptr %l27, !tbaa !21
  br i1 %t48, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8d3b159055c7af2c_5997e8ea93888888)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_c8609edc258484d8_b7e66af2ba2e899c)
  unreachable
bb11:
  %t10 = load i1, ptr %l1, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ewordAt(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l57 = alloca i1
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l63 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l13, !tbaa !27
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t12
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp ne i8 %t17, 123
  store i1 %t19, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l12, !tbaa !21
  %t22 = xor i1 %t21, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t24, 1
  store i64 %t26, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t34 = icmp slt i64 %t28, %t31
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  %t44 = icmp ne i8 %t42, 125
  store i1 %t44, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t46 = load i1, ptr %l24, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  br label %bb68
bb15:
  br label %bb16
bb16:
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l30, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 35
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb28
bb19:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = icmp slt i64 %t59, %t62
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t67 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t67, ptr %l39, !tbaa !27
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr i8, ptr %t71, i64 %t68
  %t73 = load i8, ptr %t72, !tbaa !32
  %t75 = icmp ne i8 %t73, 10
  store i1 %t75, ptr %l38, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb22
bb22:
  %t77 = load i1, ptr %l38, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb26
bb26:
  br label %bb19
bb27:
  br label %bb67
bb28:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l46, !tbaa !27
  %t85 = load i64, ptr %l4, !tbaa !24
  store i64 %t85, ptr %l47, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t86, 0
  store i64 %t89, ptr %l50, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load i64, ptr %l47, !tbaa !24
  %t96 = load i64, ptr %l50, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  br i1 %t97, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_66d223ad553101b7_96dec8e341e5a1bb)
  unreachable
bb31:
  %t99 = load i64, ptr %l50, !tbaa !24
  %t100 = load i64, ptr %l51, !tbaa !24
  %t101 = icmp sle i64 %t99, %t100
  br i1 %t101, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_66d223ad553101b7_96dec8e341e5a1bb)
  unreachable
bb33:
  %t103 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l47, !tbaa !24
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = getelementptr i8, ptr %t104, i64 %t105
  %t108 = sub i64 %t106, %t105
  %t109 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t107, 1
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %t110, { i64, ptr } %t111)
  store i1 %t114, ptr %l57
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_66d223ad553101b7_96dec8e341e5a1bb)
  unreachable
bb35:
  %t115 = load i1, ptr %l57, !tbaa !21
  br i1 %t115, label %bb36, label %bb37
bb36:
  %t116 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t116, ptr %l59, !tbaa !27
  %t117 = load i64, ptr %l4, !tbaa !24
  %t119 = sub i64 %t117, 1
  %t121 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr i8, ptr %t122, i64 %t119
  %t124 = load i8, ptr %t123, !tbaa !32
  %t126 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t124)
  store i1 %t126, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb39
bb38:
  %t127 = load i1, ptr %l63, !tbaa !21
  %t128 = xor i1 %t127, true
  store i1 %t128, ptr %l58, !tbaa !21
  br label %bb39
bb39:
  %t130 = load i1, ptr %l58, !tbaa !21
  br i1 %t130, label %bb40, label %bb41
bb40:
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t131, ptr %l66, !tbaa !27
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = sub i64 %t132, 1
  %t136 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t139)
  store i1 %t141, ptr %l70
  br label %bb42
bb41:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb43
bb42:
  %t142 = load i1, ptr %l70, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t145 = load i1, ptr %l65, !tbaa !21
  br i1 %t145, label %bb44, label %bb45
bb44:
  %t146 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t146, ptr %l73, !tbaa !27
  %t147 = load i64, ptr %l4, !tbaa !24
  %t149 = sub i64 %t147, 1
  %t151 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i8, ptr %t152, i64 %t149
  %t154 = load i8, ptr %t153, !tbaa !32
  %t156 = icmp ne i8 %t154, 95
  store i1 %t156, ptr %l72, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb46
bb46:
  %t158 = load i1, ptr %l72, !tbaa !21
  br i1 %t158, label %bb47, label %bb48
bb47:
  %t159 = load i64, ptr %l4, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t165 = add i64 %t159, %t162
  store i64 %t165, ptr %l6, !tbaa !24
  %t167 = load i64, ptr %l6, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t173 = icmp sge i64 %t167, %t170
  br i1 %t173, label %bb49, label %bb50
bb48:
  br label %bb66
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb59
bb50:
  %t175 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t175, ptr %l87, !tbaa !27
  %t176 = load i64, ptr %l6, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i8, ptr %t179, i64 %t176
  %t181 = load i8, ptr %t180, !tbaa !32
  %t183 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t181)
  store i1 %t183, ptr %l90
  br label %bb51
bb51:
  %t184 = load i1, ptr %l90, !tbaa !21
  br i1 %t184, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb55
bb53:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t185, ptr %l92, !tbaa !27
  %t186 = load i64, ptr %l6, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i8, ptr %t189, i64 %t186
  %t191 = load i8, ptr %t190, !tbaa !32
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t191)
  store i1 %t193, ptr %l95
  br label %bb54
bb54:
  %t194 = load i1, ptr %l95, !tbaa !21
  store i1 %t194, ptr %l91, !tbaa !21
  br label %bb55
bb55:
  %t195 = load i1, ptr %l91, !tbaa !21
  br i1 %t195, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb58
bb57:
  %t196 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t196, ptr %l97, !tbaa !27
  %t197 = load i64, ptr %l6, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i8, ptr %t200, i64 %t197
  %t202 = load i8, ptr %t201, !tbaa !32
  %t204 = icmp eq i8 %t202, 95
  store i1 %t204, ptr %l96, !tbaa !21
  br label %bb58
bb58:
  %t206 = load i1, ptr %l96, !tbaa !21
  %t207 = xor i1 %t206, true
  store i1 %t207, ptr %l86, !tbaa !21
  br label %bb59
bb59:
  %t209 = load i1, ptr %l86, !tbaa !21
  br i1 %t209, label %bb60, label %bb61
bb60:
  %t210 = load i64, ptr %l5, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l5, !tbaa !24
  %t214 = load i64, ptr %l5, !tbaa !24
  %t218 = icmp eq i64 %t214, %a3
  br i1 %t218, label %bb62, label %bb63
bb61:
  br label %bb65
bb62:
  %t220 = load i64, ptr %l4, !tbaa !24
  store i64 %t220, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t222 = load i64, ptr %l4, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l4, !tbaa !24
  br label %bb67
bb67:
  br label %bb10
bb68:
  %t226 = load i64, ptr %l1, !tbaa !24
  store i64 %t226, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/check:Gap" @compiler_2fcheck_3aGap_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/check:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:Gap" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:Gap" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/check:Gap" %t10, { i64, ptr } %a2, 2
  store %"compiler/check:Gap" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:Gap", ptr %rv
  ret %"compiler/check:Gap" %rr
}

define dso_local %"compiler/check:altsCovered" @compiler_2fcheck_3aaltsCovered_2ector(ptr %v0, ptr %v1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, i1 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:altsCovered"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:altsCovered" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a0, 0
  %t12 = insertvalue %"compiler/check:altsCovered" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/check:altsCovered" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:altsCovered" %t14, i1 %a3, 3
  store %"compiler/check:altsCovered" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:altsCovered", ptr %rv
  ret %"compiler/check:altsCovered" %rr
}

define dso_local %"compiler/check:errNarrow" @compiler_2fcheck_3aerrNarrow_2ector(ptr %v0, i32 %a0, i32 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:errNarrow"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:errNarrow" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:errNarrow" %t10, i32 %a1, 1
  %t14 = insertvalue %"compiler/check:errNarrow" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:errNarrow" %t14, i1 %a3, 3
  store %"compiler/check:errNarrow" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errNarrow", ptr %rv
  ret %"compiler/check:errNarrow" %rr
}

define dso_local %"compiler/check:inPlaceRead" @compiler_2fcheck_3ainPlaceRead_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:inPlaceRead"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:inPlaceRead" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:inPlaceRead" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t14 = insertvalue %"compiler/check:inPlaceRead" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:inPlaceRead" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:inPlaceRead" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:inPlaceRead", ptr %rv
  ret %"compiler/check:inPlaceRead" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"this constructor" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d3 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" and null" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"From" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/enums" }>, align 8
@.d10 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"caseIndex" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d12 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
declare ptr @llvm.coro.promise(ptr, i32, i1)
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d16 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"a generator borrowing its elements from a parameter held by value" }>, align 8
@.d17 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"a generator with a contract and an unnamed parameter" }>, align 8
@.d18 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d20 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no parameters" }>, align 8
@.d21 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"one parameter" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d22 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" parameters" }>, align 8
@.d23 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"one" }>, align 8
@.d24 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"at least " }>, align 8
@.d26 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d29 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d34 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"this prefix operator" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d36 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d37 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d43 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"an Iter() whose result is no iterator (S9c)" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'for'" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d48 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"'for ... in'" }>, align 8
@.d49 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a walk ('for ... in': Next, Iter, or At and Len)" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d57 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Contains" }>, align 8
@.d58 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare i32 @compiler_2fcheck_2esetName(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2echainAssignsAll(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fcbb335a6871d594_96c5adf6eb865188 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_H2251bc8fca359ca0394d0bb11af7ba0a(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsFixed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aHoldsFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_15d8d795344f0f34_d9e3bc129d8abb98 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedInst(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Origin" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceOrigin(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
@olang_loc_cf2e89857dc93528_274c4670bc5b9eac = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc394d3abb705b3d_774ad654d23301b9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/check:altsCovered" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtAlts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i1 %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/check:errBind" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskDefaultInStatement(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5, i1 %a6, i32 %a7)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etaskDefault(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b7a62f2efaadd4af_1b278ceebf7ddf33 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDestructCount(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseNeedsDefault(ptr %v0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2eToA_H65e94094dadf75016f6073f244c91f3b(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f259f6ca06e66809_b1ef05920a904ef5 = external constant [0 x i8]
@olang_loc_67410fc9d6566a9c_b1c73ab5a8b03798 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_4d78ccd557b2cb07_4b61304073c9a48b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eToArray_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleFn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eCtReq = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_82a7c94587506de8_24388316e0066d9c = external constant [0 x i8]
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_573d6efe4eadca3f_fa49b5af8bd78213 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFromPayload(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeFn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_2f076b8c12fc1f2b_72a0a04988c2c8b7 = external constant [0 x i8]
@olang_loc_8ce0cb83e6566f16_6a0b4dbe19b2f402 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_83b919d2f60ab835_29fa8ffb2c40f121 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
@olang_loc_ace0e8d6a1b00ac8_e6e4f855bb613414 = external constant [0 x i8]
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
@olang_loc_e5613677a6448c92_7fd725fb7345b22e = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ce46ad7b25b964bc_d75d3b27057ac3b0 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrMatchNotError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrValueNoOp(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrValOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrRecode(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAsCanFail(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estructBody(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/iterator:ViewGenerator.00c7c71992d6e1815cd052c47b979cdd" @compiler_2fgeneric_2eFieldDecls.walk(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fiterator_2estd_2fprelude_2fiterator_3aViewGenerator_3ccompiler_2fast_3aV_Hf179e857cb72c72900f4614cd5df5a25(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, i32 %a4)
declare i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i128 } @compiler_2fcheck_2ewideDigits(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0)
declare %"compiler/check:signMag" @compiler_2fcheck_2emagOf(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i128 %a1, i1 %a2, i128 %a3)
declare %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2)
@olang_loc_18ec9fb825b0f3da_76c21f303b4292b6 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeck(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H3cc70d507a7fc767d013b59b12ee0a99(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fgeneric_3aContext_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCycle(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d3e518c37f06fac_dc2de6c574f30d28 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eifOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eskipsRest(ptr %v0, ptr %a0)
@olang_loc_bb0c9585cb5cd0e5_782fa8d07097a5f1 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushFacts(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
@olang_loc_78bdf75b8d9b61cd_a447015cda228549 = external constant [0 x i8]
@olang_loc_cf50a113ac2177e6_e3cc5936e852a452 = external constant [0 x i8]
@olang_loc_baddfb655e016c47_d17e78f9e01d2853 = external constant [0 x i8]
@olang_loc_3e69957d7270204c_dfbf9d9d846a9638 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eTrunca_Hc8531d0d5535cc9766a27157f9c0b07c(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHoldLeaves(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLength(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneResult(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2efloatOverflows(i32 %a0, double %a1)
declare double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_1a03149f0250e548_14220af7ccd85b74 = external constant [0 x i8]
@olang_loc_f003e05343083a19_c7eedaa93b775a5 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorBare(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteGenericNeeds(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
@olang_loc_929b44a27af4e606_c6f0275d053ca0d2 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_aac959024b9d6f15_55461456e770b1d1 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_492feac3979049da_7a1ccb679ec95f6e = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolveNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_42af232d2840e8db_efcef566740b002f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReraiseWordNotInSet(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eisRest(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRestTwice(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20compiler__H316d0dfdbceeb7b188a6719f0ad8fbbe(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/check:roOrigin" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hfc56ff01c357e6bb827daf7012f18a86(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"compiler/check:roOrigin" @compiler_2fcheck_3aroOrigin_2ector(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare ptr @compiler_2fcheck_2eunwrapped(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_86e950cd41bc9656_5dbe90d10bea6a92 = external constant [0 x i8]
@olang_loc_67c0878bde4afa77_9afdcd15cbb29493 = external constant [0 x i8]
@olang_loc_e181575e6035f202_99a6d5836a9bf6a6 = external constant [0 x i8]
@olang_loc_a5d3444dbde3a383_cb32d8a11a505607 = external constant [0 x i8]
@olang_loc_664096f84a6143a8_9c45533022ca790c = external constant [0 x i8]
@olang_loc_5f0b92ad49630279_51f88f4b15ed303d = external constant [0 x i8]
@olang_loc_265c788dd5eed9e_866edb98fc8c38ea = external constant [0 x i8]
@olang_loc_6ac4c8202b0b581f_2f15107fd7d9b5ab = external constant [0 x i8]
@olang_loc_8bfef52d6d2c65e4_ce3ff42f583fc170 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aGap_3e_2eLen_3ccompiler_2fcheck_3aGap_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_b6a47344f78098a_9e5fbaf70b0ac586 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_763b8bf7b0207b18_a2106654b6caec64 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitErrsUnwritten(ptr %v0)
@olang_loc_cc3b7a6e318210b6_464c855cb4a991aa = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8b8738bb0f25fa76_719b7d77c23398a = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eembed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptime(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperandNotBool(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2ePush_3ccompiler_2ftyped_3aPiece_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPiece_26_3e_2eToArr_H1b89f7fcc263bba924ca04e7c3aa48c7(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Text" @compiler_2ftyped_3aText_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1)
@olang_loc_b692ddd8e2182d13_c763079e5a61942f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnspread(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
@olang_loc_1c0ab263f2e4f7dc_3e069dbdc7ae0b68 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprOpen(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
@olang_loc_a734531b29123b5_def2307fb88201b9 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ehandleRoot(ptr %v0, ptr %a0)
@olang_loc_cf73afff9a9afd3c_75ef637926e6ccb8 = external constant [0 x i8]
@olang_loc_563ec608ec426d3c_d7d09179516a0f40 = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f62b02ebb614301c_75e9b5b90c5bfe48 = external constant [0 x i8]
@olang_loc_f1e8a29f5ea9d646_79fa5e0b2b57ed62 = external constant [0 x i8]
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare i64 @compiler_2fcheck_2eopShapeOf(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
@olang_loc_8d3b159055c7af2c_5997e8ea93888888 = external constant [0 x i8]
@olang_loc_c8609edc258484d8_b7e66af2ba2e899c = external constant [0 x i8]
@olang_loc_66d223ad553101b7_96dec8e341e5a1bb = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
