; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:tailAsk" = type { i64, i64, %"compiler/source:Span", i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, i1 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] }, i1 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/check:UnrollAsk" = type { { i64, ptr }, { i64, ptr }, i64, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:fixedInit" = type { ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/generic:Unmet" = type { i64, i32, i32, i1, i1, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
define dso_local void @compiler_2fcheck_2eLaneBin_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 0, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb5:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb7:
  %t15 = mul i64 0, 4
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t21, i64 %t22, i64 -1, { i64, ptr } %t23, { i64, ptr } %t18, ptr %a2, i32 %a3)
  store i64 %t27, ptr %l14
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTextType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l18 = alloca { i64, ptr }
  %l25 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t37 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t28, ptr %a2)
  store i1 %t37, ptr %l25
  br label %bb8
bb8:
  %t38 = load i1, ptr %l25, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb4
bb13:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, [2 x i64] }
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l82 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l88 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca i64
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l134 = alloca i1
  %l136 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l140 = alloca %"compiler/msgs:Msg"
  %l141 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l157 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca ptr
  %l167 = alloca ptr
  %l170 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l175 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca i1
  %l192 = alloca ptr
  %l199 = alloca ptr
  %l203 = alloca i64
  %l204 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l213 = alloca i64
  %l215 = alloca i64
  %l216 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca i64
  %l226 = alloca i64
  %l227 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l231 = alloca i64
  %l233 = alloca i64
  %l234 = alloca { i64, ptr }
  %l235 = alloca ptr
  %l236 = alloca i1
  %l239 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l242 = alloca i64
  %l244 = alloca i64
  %l245 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l247 = alloca i1
  %l250 = alloca { i64, ptr }
  %l251 = alloca { i64, ptr }
  %l253 = alloca i64
  %l255 = alloca i64
  %l256 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l258 = alloca i1
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l264 = alloca i64
  %l266 = alloca i64
  %l267 = alloca { i64, ptr }
  %l268 = alloca ptr
  %l269 = alloca i1
  %l272 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l275 = alloca i64
  %l277 = alloca i64
  %l278 = alloca { i64, ptr }
  %l281 = alloca i32
  %l286 = alloca ptr
  %l288 = alloca %"compiler/source:Span"
  %l290 = alloca %"compiler/msgs:Msg"
  %l291 = alloca i64
  %l299 = alloca ptr
  %l305 = alloca i1
  %l307 = alloca ptr
  %l310 = alloca %"compiler/source:Span"
  %l313 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l317 = alloca { i64, ptr }
  %l319 = alloca %"compiler/msgs:Msg"
  %l320 = alloca i64
  %l327 = alloca i1
  %l328 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l332 = alloca %"compiler/msgs:Msg"
  %l333 = alloca i64
  %l339 = alloca ptr
  %l346 = alloca %"compiler/check:tailAsk"
  %l347 = alloca ptr
  %l348 = alloca i1
  %l357 = alloca ptr
  %l358 = alloca %"compiler/source:Span"
  %l359 = alloca %"compiler/source:Span"
  %l360 = alloca i32
  %l371 = alloca %"compiler/typed:Call"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t36 = alloca { i64, [3 x i64] }, align 8
  %t259 = alloca { i64, [3 x i64] }, align 8
  %t314 = alloca { i64, [3 x i64] }, align 8
  %t346 = alloca { i64, [3 x i64] }, align 8
  %t784 = alloca { i64, [3 x i64] }, align 8
  %t856 = alloca { i64, [3 x i64] }, align 8
  %t886 = alloca { i64, [3 x i64] }, align 8
  %t976 = alloca { i64, [5 x i64] }, align 8
  %t988 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t7 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t10 = add i32 %t8, 6
  %t13 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t6, i32 %t10)
  store %"compiler/source:Span" %t13, ptr %l27
  br label %bb2
bb2:
  %t14 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t14, ptr %l4
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeWhere(ptr %v0, ptr %s0, ptr %t15)
  store { i64, ptr } %t17, ptr %l29
  br label %bb3
bb3:
  %t18 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t19, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t21, ptr %l31
  br label %bb4
bb4:
  %t22 = load i1, ptr %l31, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l33, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t26, ptr %l34
  %t27 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeOutside(ptr %s0, ptr %s1, { i64, ptr } %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l36
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t30 = load ptr, ptr %l33, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l34
  %t32 = load %"compiler/msgs:Msg", ptr %l36
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l37
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 0
  store i64 6, ptr %t37
  %t39 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t35, 0
  %t40 = insertvalue { %"compiler/source:Span", ptr } %t39, ptr null, 1
  %t41 = getelementptr { i64, [3 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t40, ptr %t41
  %t42 = load { i64, [3 x i64] }, ptr %t36
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t42, ptr %t44
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t34, ptr %t44)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t47, ptr %l43, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l44, !tbaa !24
  %t50 = load i64, ptr %l44, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t51)
  %t53 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  store { i64, ptr } %t54, ptr %l45, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l44, !tbaa !24
  %t60 = mul i64 %t59, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  %t61 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t61, ptr %l6, !tbaa !27
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 32
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  br i1 %t67, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t69, ptr %l50, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l52, !tbaa !24
  %t75 = load i64, ptr %l52, !tbaa !24
  %t76 = icmp eq i64 %t71, %t75
  br i1 %t76, label %bb13, label %bb14
bb12:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 33
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = icmp sge i64 %t81, 0
  br i1 %t83, label %bb16, label %bb17
bb13:
  %t85 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l52, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  br label %bb15
bb14:
  %t91 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l54, !tbaa !24
  %t93 = load i64, ptr %l54, !tbaa !24
  %t94 = mul i64 %t93, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l55, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l54, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  %t104 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t104, ptr %l6, !tbaa !27
  br label %bb15
bb15:
  br label %bb42
bb16:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t105, ptr %l60, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  %t108 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l62, !tbaa !24
  %t111 = load i64, ptr %l62, !tbaa !24
  %t112 = icmp eq i64 %t107, %t111
  br i1 %t112, label %bb18, label %bb19
bb17:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = getelementptr %"compiler/check:frame", ptr %t114, i32 0, i32 30
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb21, label %bb22
bb18:
  %t119 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l62, !tbaa !24
  %t124 = mul i64 %t123, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t120, ptr %t122, i64 %t124, i1 false)
  br label %bb20
bb19:
  %t125 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l64, !tbaa !24
  %t127 = load i64, ptr %l64, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l65, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l64, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t138, ptr %l6, !tbaa !27
  br label %bb20
bb20:
  br label %bb41
bb21:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l68, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t139, ptr %l69, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l71, !tbaa !24
  %t145 = load i64, ptr %l71, !tbaa !24
  %t146 = icmp eq i64 %t141, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 36
  %t152 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t150)
  store i64 %t152, ptr %l77
  br label %bb26
bb23:
  %t153 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l71, !tbaa !24
  %t158 = mul i64 %t157, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t154, ptr %t156, i64 %t158, i1 false)
  br label %bb25
bb24:
  %t159 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l73, !tbaa !24
  %t161 = load i64, ptr %l73, !tbaa !24
  %t162 = mul i64 %t161, 1
  %t163 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  store { i64, ptr } %t165, ptr %l74, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l73, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  %t172 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t172, ptr %l6, !tbaa !27
  br label %bb25
bb25:
  br label %bb40
bb26:
  %t173 = load i64, ptr %l77, !tbaa !24
  %t174 = icmp sgt i64 %t173, 0
  br i1 %t174, label %bb27, label %bb28
bb27:
  store { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t176, ptr %l80, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l82, !tbaa !24
  %t182 = load i64, ptr %l82, !tbaa !24
  %t183 = icmp eq i64 %t178, %t182
  br i1 %t183, label %bb29, label %bb30
bb28:
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t185, i32 0, i32 22
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t187)
  store i64 %t189, ptr %l88
  br label %bb32
bb29:
  %t190 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l82, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  br label %bb31
bb30:
  %t196 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  store i64 %t197, ptr %l84, !tbaa !24
  %t198 = load i64, ptr %l84, !tbaa !24
  %t199 = mul i64 %t198, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  %t201 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l85, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l84, !tbaa !24
  %t208 = mul i64 %t207, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t204, ptr %t206, i64 %t208, i1 false)
  %t209 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t209, ptr %l6, !tbaa !27
  br label %bb31
bb31:
  br label %bb39
bb32:
  %t210 = load i64, ptr %l88, !tbaa !24
  %t211 = icmp sgt i64 %t210, 0
  br i1 %t211, label %bb33, label %bb34
bb33:
  store { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t213, ptr %l91, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t214, 0
  %t216 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  store i64 %t217, ptr %l93, !tbaa !24
  %t219 = load i64, ptr %l93, !tbaa !24
  %t220 = icmp eq i64 %t215, %t219
  br i1 %t220, label %bb35, label %bb36
bb34:
  br label %bb38
bb35:
  %t222 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l93, !tbaa !24
  %t227 = mul i64 %t226, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t223, ptr %t225, i64 %t227, i1 false)
  br label %bb37
bb36:
  %t228 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l95, !tbaa !24
  %t230 = load i64, ptr %l95, !tbaa !24
  %t231 = mul i64 %t230, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t231)
  %t233 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  store { i64, ptr } %t234, ptr %l96, !tbaa !27
  %t235 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l95, !tbaa !24
  %t240 = mul i64 %t239, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t236, ptr %t238, i64 %t240, i1 false)
  %t241 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t241, ptr %l6, !tbaa !27
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t242 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t244 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t242, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t244, ptr %l98
  br label %bb43
bb43:
  %t245 = load i1, ptr %l98, !tbaa !21
  %t246 = xor i1 %t245, true
  br i1 %t246, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l100, !tbaa !29
  %t249 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t249, ptr %l101
  %t250 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t252 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeInside(ptr %s0, ptr %s11, { i64, ptr } %t250)
  store %"compiler/msgs:Msg" %t252, ptr %l103
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t253 = load ptr, ptr %l100, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l101
  %t255 = load %"compiler/msgs:Msg", ptr %l103
  %t256 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t253, %"compiler/source:Span" %t254, %"compiler/msgs:Msg" %t255)
  store i64 %t256, ptr %l104
  br label %bb47
bb47:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t259
  %t260 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 0
  store i64 6, ptr %t260
  %t262 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t258, 0
  %t263 = insertvalue { %"compiler/source:Span", ptr } %t262, ptr null, 1
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t263, ptr %t264
  %t265 = load { i64, [3 x i64] }, ptr %t259
  %t267 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t265, ptr %t267
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t257, ptr %t267)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  %t270 = load ptr, ptr %l2, !tbaa !29
  store ptr %t270, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t271 = load ptr, ptr %l110, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb50, label %bb51
bb50:
  %t274 = load ptr, ptr %l110, !tbaa !29
  %t275 = load i64, ptr %t274
  %t277 = icmp eq i64 %t275, 12
  store i1 %t277, ptr %l111, !tbaa !21
  br label %bb51
bb51:
  %t278 = load i1, ptr %l111, !tbaa !21
  br i1 %t278, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb72
bb55:
  %t279 = load ptr, ptr %l2, !tbaa !29
  store ptr %t279, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t280 = load ptr, ptr %l114, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb56, label %bb57
bb56:
  %t283 = load ptr, ptr %l114, !tbaa !29
  %t284 = load i64, ptr %t283
  %t286 = icmp eq i64 %t284, 22
  store i1 %t286, ptr %l115, !tbaa !21
  br label %bb57
bb57:
  %t287 = load i1, ptr %l115, !tbaa !21
  br i1 %t287, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb72
bb61:
  %t288 = load ptr, ptr %l2, !tbaa !29
  store ptr %t288, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t289 = load ptr, ptr %l118, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb62, label %bb63
bb62:
  %t292 = load ptr, ptr %l118, !tbaa !29
  %t293 = load i64, ptr %t292
  %t295 = icmp eq i64 %t293, 13
  store i1 %t295, ptr %l119, !tbaa !21
  br label %bb63
bb63:
  %t296 = load i1, ptr %l119, !tbaa !21
  br i1 %t296, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb72
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l109, !tbaa !27
  br label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_e034fcd8e283054e_7f246e4998f63322)
  unreachable
bb72:
  %t297 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t297, ptr %l7, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t299 = load ptr, ptr @__olang_prog_scope
  %t301 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t299, ptr %s0, { i64, ptr } %t298, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t301, ptr %l123
  br label %bb73
bb73:
  %t302 = load i1, ptr %l123, !tbaa !21
  br i1 %t302, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t303 = load ptr, ptr %l0, !tbaa !29
  store ptr %t303, ptr %l124, !tbaa !29
  %t304 = load ptr, ptr %l2, !tbaa !29
  %t306 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t304)
  store %"compiler/source:Span" %t306, ptr %l126
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t307 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeTry(ptr %s16)
  store %"compiler/msgs:Msg" %t307, ptr %l127
  br label %bb77
bb77:
  %t308 = load ptr, ptr %l124, !tbaa !29
  %t309 = load %"compiler/source:Span", ptr %l126
  %t310 = load %"compiler/msgs:Msg", ptr %l127
  %t311 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t308, %"compiler/source:Span" %t309, %"compiler/msgs:Msg" %t310)
  store i64 %t311, ptr %l128
  br label %bb78
bb78:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t314
  %t315 = getelementptr { i64, [3 x i64] }, ptr %t314, i32 0, i32 0
  store i64 6, ptr %t315
  %t317 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t313, 0
  %t318 = insertvalue { %"compiler/source:Span", ptr } %t317, ptr null, 1
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t314, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t314
  %t322 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t320, ptr %t322
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t312, ptr %t322)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb80:
  %t325 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t326 = load ptr, ptr @__olang_prog_scope
  %t328 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t326, ptr %s0, { i64, ptr } %t325, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t328, ptr %l134
  br label %bb81
bb81:
  %t329 = load i1, ptr %l134, !tbaa !21
  %t330 = xor i1 %t329, true
  br i1 %t330, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s17
  %t332 = load ptr, ptr %l0, !tbaa !29
  store ptr %t332, ptr %l136, !tbaa !29
  %t333 = load ptr, ptr %l2, !tbaa !29
  %t335 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t333)
  store %"compiler/source:Span" %t335, ptr %l138
  br label %bb84
bb83:
  br label %bb88
bb84:
  %t336 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t337 = load ptr, ptr @__olang_prog_scope
  %t339 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeNotCall(ptr %t337, ptr %s17, { i64, ptr } %t336)
  store %"compiler/msgs:Msg" %t339, ptr %l140
  br label %bb85
bb85:
  %t340 = load ptr, ptr %l136, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l138
  %t342 = load %"compiler/msgs:Msg", ptr %l140
  %t343 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t340, %"compiler/source:Span" %t341, %"compiler/msgs:Msg" %t342)
  store i64 %t343, ptr %l141
  br label %bb86
bb86:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t346
  %t347 = getelementptr { i64, [3 x i64] }, ptr %t346, i32 0, i32 0
  store i64 6, ptr %t347
  %t349 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t345, 0
  %t350 = insertvalue { %"compiler/source:Span", ptr } %t349, ptr null, 1
  %t351 = getelementptr { i64, [3 x i64] }, ptr %t346, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t350, ptr %t351
  %t352 = load { i64, [3 x i64] }, ptr %t346
  %t354 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t352, ptr %t354
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t344, ptr %t354)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb88:
  %t357 = load ptr, ptr %l3, !tbaa !29
  %t359 = getelementptr %"compiler/check:frame", ptr %t357, i32 0, i32 5
  %t360 = load i32, ptr %t359, !tbaa !23
  store i32 %t360, ptr %l8, !tbaa !23
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t362)
  store ptr %t364, ptr %l149
  br label %bb89
bb89:
  %t365 = load ptr, ptr %l149, !tbaa !29
  store ptr %t365, ptr %l150, !tbaa !29
  %t366 = load ptr, ptr %l150, !tbaa !29
  %t367 = getelementptr %"compiler/check:frame", ptr %t366, i32 0, i32 15
  %t368 = load i64, ptr %t367, !tbaa !24
  %t370 = add i64 %t368, 1
  %t372 = load ptr, ptr %l150, !tbaa !29
  %t373 = getelementptr %"compiler/check:frame", ptr %t372, i32 0, i32 15
  store i64 %t370, ptr %t373, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load ptr, ptr %l2, !tbaa !29
  %t377 = load i32, ptr %l8, !tbaa !23
  %t381 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t374, ptr %t375, i32 %t377)
  store ptr %t381, ptr %l157
  br label %bb90
bb90:
  %t382 = load ptr, ptr %l157, !tbaa !29
  store ptr %t382, ptr %l9, !tbaa !29
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t383)
  store ptr %t385, ptr %l159
  br label %bb91
bb91:
  %t386 = load ptr, ptr %l159, !tbaa !29
  store ptr %t386, ptr %l160, !tbaa !29
  %t387 = load ptr, ptr %l160, !tbaa !29
  %t388 = getelementptr %"compiler/check:frame", ptr %t387, i32 0, i32 15
  %t389 = load i64, ptr %t388, !tbaa !24
  %t391 = sub i64 %t389, 1
  %t393 = load ptr, ptr %l160, !tbaa !29
  %t394 = getelementptr %"compiler/check:frame", ptr %t393, i32 0, i32 15
  store i64 %t391, ptr %t394, !tbaa !24
  store i64 -1, ptr %l10, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"compiler/check:Checker", ptr %t395, i32 0, i32 12
  %t398 = load ptr, ptr %l3, !tbaa !29
  %t400 = getelementptr %"compiler/check:frame", ptr %t398, i32 0, i32 0
  %t401 = load i64, ptr %t400, !tbaa !24
  %t404 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t397, i64 %t401)
  store ptr %t404, ptr %l167
  br label %bb92
bb92:
  %t405 = load ptr, ptr %l167, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Body", ptr %t405, i32 0, i32 2
  %t408 = load i32, ptr %t407, !tbaa !23
  store i32 %t408, ptr %l11, !tbaa !23
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l170, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t410, ptr %l171, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t411, 0
  store i64 %t412, ptr %l172, !tbaa !24
  %t413 = load i64, ptr %l172, !tbaa !24
  %t414 = mul i64 %t413, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t414)
  %t416 = insertvalue { i64, ptr } undef, i64 %t413, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  store { i64, ptr } %t417, ptr %l173, !tbaa !27
  %t418 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t419 = load ptr, ptr %t418, !tbaa !27
  %t420 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !27
  %t422 = load i64, ptr %l172, !tbaa !24
  %t423 = mul i64 %t422, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t419, ptr %t421, i64 %t423, i1 false)
  %t424 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t424, ptr %l12, !tbaa !27
  %t425 = load ptr, ptr %l9, !tbaa !29
  store ptr %t425, ptr %l174, !tbaa !29
  store i1 false, ptr %l175, !tbaa !21
  %t426 = load ptr, ptr %l174, !tbaa !29
  %t427 = icmp ne ptr %t426, null
  br i1 %t427, label %bb93, label %bb94
bb93:
  %t429 = load ptr, ptr %l174, !tbaa !29
  %t430 = load i64, ptr %t429
  %t432 = icmp eq i64 %t430, 6
  store i1 %t432, ptr %l175, !tbaa !21
  br label %bb94
bb94:
  %t433 = load i1, ptr %l175, !tbaa !21
  br i1 %t433, label %bb95, label %bb96
bb95:
  %t434 = load ptr, ptr %l9, !tbaa !29
  %t436 = getelementptr { i64, [5 x i64] }, ptr %t434, i32 0, i32 1
  %t437 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t436, i32 0, i32 2
  %t438 = load ptr, ptr %t437
  store ptr %t438, ptr %l13, !tbaa !29
  br label %bb97
bb96:
  br label %bb171
bb97:
  %t440 = load ptr, ptr %l13, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Call", ptr %t440, i32 0, i32 0
  %t443 = load ptr, ptr %t442, !tbaa !29
  store ptr %t443, ptr %l14, !tbaa !29
  %t445 = load ptr, ptr %l14, !tbaa !29
  store ptr %t445, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t446 = load ptr, ptr %l182, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb98, label %bb99
bb98:
  %t449 = load ptr, ptr %l182, !tbaa !29
  %t450 = load i64, ptr %t449
  %t452 = icmp eq i64 %t450, 0
  store i1 %t452, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t453 = load i1, ptr %l183, !tbaa !21
  br i1 %t453, label %bb100, label %bb101
bb100:
  %t454 = load ptr, ptr %l14, !tbaa !29
  %t456 = getelementptr { i64, [3 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { i32 }, ptr %t456, i32 0, i32 0
  %t458 = load i32, ptr %t457
  store i32 %t458, ptr %l15, !tbaa !23
  br label %bb102
bb101:
  br label %bb133
bb102:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/check:Checker", ptr %t460, i32 0, i32 12
  %t463 = load i32, ptr %l15, !tbaa !23
  %t465 = sext i32 %t463 to i64
  %t468 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t462, i64 %t465)
  store ptr %t468, ptr %l192
  br label %bb103
bb103:
  %t469 = load ptr, ptr %l192, !tbaa !29
  %t471 = getelementptr %"compiler/typed:Body", ptr %t469, i32 0, i32 1
  %t472 = load { i64, [2 x i64] }, ptr %t471
  store { i64, [2 x i64] } %t472, ptr %l16
  %t474 = load { i64, [2 x i64] }, ptr %l16
  %t476 = extractvalue { i64, [2 x i64] } %t474, 0
  %t477 = icmp eq i64 %t476, 0
  br i1 %t477, label %bb104, label %bb105
bb104:
  %t479 = getelementptr { i64, [2 x i64] }, ptr %l16, i32 0, i32 1
  %t480 = getelementptr { i64 }, ptr %t479, i32 0, i32 0
  %t481 = load i64, ptr %t480
  store i64 %t481, ptr %l17, !tbaa !24
  br label %bb106
bb105:
  br label %bb115
bb106:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/check:Checker", ptr %t483, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !29
  store ptr %t486, ptr %l199, !tbaa !29
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/check:Checker", ptr %t487, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !29
  %t491 = load i64, ptr %l17, !tbaa !24
  %t494 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t490, i64 %t491)
  store i64 %t494, ptr %l203
  br label %bb107
bb107:
  %t495 = load ptr, ptr %l199, !tbaa !29
  %t496 = load i64, ptr %l203, !tbaa !24
  %t497 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t495, i64 %t496)
  store ptr %t497, ptr %l204
  br label %bb108
bb108:
  %t498 = load ptr, ptr %l204, !tbaa !29
  %t500 = getelementptr %"compiler/ast:Func", ptr %t498, i32 0, i32 7
  %t501 = load i1, ptr %t500, !tbaa !21
  %t503 = xor i1 %t501, true
  br i1 %t503, label %bb109, label %bb110
bb109:
  %t505 = load i32, ptr %l15, !tbaa !23
  %t507 = sext i32 %t505 to i64
  store i64 %t507, ptr %l10, !tbaa !24
  br label %bb114
bb110:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l210, !tbaa !27
  %t509 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t509, ptr %l211, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t510, 0
  %t512 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t513 = extractvalue { i64, ptr } %t512, 0
  store i64 %t513, ptr %l213, !tbaa !24
  %t515 = load i64, ptr %l213, !tbaa !24
  %t516 = icmp eq i64 %t511, %t515
  br i1 %t516, label %bb111, label %bb112
bb111:
  %t518 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !27
  %t520 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t521 = load ptr, ptr %t520, !tbaa !27
  %t522 = load i64, ptr %l213, !tbaa !24
  %t523 = mul i64 %t522, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t519, ptr %t521, i64 %t523, i1 false)
  br label %bb113
bb112:
  %t524 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t524, 0
  store i64 %t525, ptr %l215, !tbaa !24
  %t526 = load i64, ptr %l215, !tbaa !24
  %t527 = mul i64 %t526, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t527)
  %t529 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l216, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t532 = load ptr, ptr %t531, !tbaa !27
  %t533 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = load i64, ptr %l215, !tbaa !24
  %t536 = mul i64 %t535, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t532, ptr %t534, i64 %t536, i1 false)
  %t537 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t537, ptr %l12, !tbaa !27
  br label %bb113
bb113:
  br label %bb114
bb114:
  br label %bb132
bb115:
  %t538 = load { i64, [2 x i64] }, ptr %l16
  %t540 = extractvalue { i64, [2 x i64] } %t538, 0
  %t541 = icmp eq i64 %t540, 1
  br i1 %t541, label %bb116, label %bb117
bb116:
  br label %bb120
bb117:
  %t543 = load { i64, [2 x i64] }, ptr %l16
  %t545 = extractvalue { i64, [2 x i64] } %t543, 0
  %t546 = icmp eq i64 %t545, 2
  br i1 %t546, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb124
bb120:
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l221, !tbaa !27
  %t548 = load { i64, ptr }, ptr %l221, !tbaa !27
  store { i64, ptr } %t548, ptr %l222, !tbaa !27
  %t549 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t550 = extractvalue { i64, ptr } %t549, 0
  %t551 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t552 = extractvalue { i64, ptr } %t551, 0
  store i64 %t552, ptr %l224, !tbaa !24
  %t554 = load i64, ptr %l224, !tbaa !24
  %t555 = icmp eq i64 %t550, %t554
  br i1 %t555, label %bb121, label %bb122
bb121:
  %t557 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = load i64, ptr %l224, !tbaa !24
  %t562 = mul i64 %t561, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t558, ptr %t560, i64 %t562, i1 false)
  br label %bb123
bb122:
  %t563 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  store i64 %t564, ptr %l226, !tbaa !24
  %t565 = load i64, ptr %l226, !tbaa !24
  %t566 = mul i64 %t565, 1
  %t567 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t566)
  %t568 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  store { i64, ptr } %t569, ptr %l227, !tbaa !27
  %t570 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t571 = load ptr, ptr %t570, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = load i64, ptr %l226, !tbaa !24
  %t575 = mul i64 %t574, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t571, ptr %t573, i64 %t575, i1 false)
  %t576 = load { i64, ptr }, ptr %l227, !tbaa !27
  store { i64, ptr } %t576, ptr %l12, !tbaa !27
  br label %bb123
bb123:
  br label %bb132
bb124:
  br i1 true, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb131
bb127:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l228, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l228, !tbaa !27
  store { i64, ptr } %t577, ptr %l229, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 0
  %t580 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t581 = extractvalue { i64, ptr } %t580, 0
  store i64 %t581, ptr %l231, !tbaa !24
  %t583 = load i64, ptr %l231, !tbaa !24
  %t584 = icmp eq i64 %t579, %t583
  br i1 %t584, label %bb128, label %bb129
bb128:
  %t586 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t589 = load ptr, ptr %t588, !tbaa !27
  %t590 = load i64, ptr %l231, !tbaa !24
  %t591 = mul i64 %t590, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t587, ptr %t589, i64 %t591, i1 false)
  br label %bb130
bb129:
  %t592 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t593 = extractvalue { i64, ptr } %t592, 0
  store i64 %t593, ptr %l233, !tbaa !24
  %t594 = load i64, ptr %l233, !tbaa !24
  %t595 = mul i64 %t594, 1
  %t596 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t595)
  %t597 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t596, 1
  store { i64, ptr } %t598, ptr %l234, !tbaa !27
  %t599 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !27
  %t603 = load i64, ptr %l233, !tbaa !24
  %t604 = mul i64 %t603, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t600, ptr %t602, i64 %t604, i1 false)
  %t605 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t605, ptr %l12, !tbaa !27
  br label %bb130
bb130:
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_17e85edd6251e98f_328e7bc733525423)
  unreachable
bb132:
  br label %bb170
bb133:
  %t606 = load ptr, ptr %l14, !tbaa !29
  store ptr %t606, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t607 = load ptr, ptr %l235, !tbaa !29
  %t608 = icmp ne ptr %t607, null
  br i1 %t608, label %bb134, label %bb135
bb134:
  %t610 = load ptr, ptr %l235, !tbaa !29
  %t611 = load i64, ptr %t610
  %t613 = icmp eq i64 %t611, 1
  store i1 %t613, ptr %l236, !tbaa !21
  br label %bb135
bb135:
  %t614 = load i1, ptr %l236, !tbaa !21
  br i1 %t614, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  br label %bb142
bb138:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l239, !tbaa !27
  %t615 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t615, ptr %l240, !tbaa !27
  %t616 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t617 = extractvalue { i64, ptr } %t616, 0
  %t618 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t619 = extractvalue { i64, ptr } %t618, 0
  store i64 %t619, ptr %l242, !tbaa !24
  %t621 = load i64, ptr %l242, !tbaa !24
  %t622 = icmp eq i64 %t617, %t621
  br i1 %t622, label %bb139, label %bb140
bb139:
  %t624 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t625 = load ptr, ptr %t624, !tbaa !27
  %t626 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t627 = load ptr, ptr %t626, !tbaa !27
  %t628 = load i64, ptr %l242, !tbaa !24
  %t629 = mul i64 %t628, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t625, ptr %t627, i64 %t629, i1 false)
  br label %bb141
bb140:
  %t630 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t630, 0
  store i64 %t631, ptr %l244, !tbaa !24
  %t632 = load i64, ptr %l244, !tbaa !24
  %t633 = mul i64 %t632, 1
  %t634 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t633)
  %t635 = insertvalue { i64, ptr } undef, i64 %t632, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  store { i64, ptr } %t636, ptr %l245, !tbaa !27
  %t637 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !27
  %t639 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t640 = load ptr, ptr %t639, !tbaa !27
  %t641 = load i64, ptr %l244, !tbaa !24
  %t642 = mul i64 %t641, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t638, ptr %t640, i64 %t642, i1 false)
  %t643 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t643, ptr %l12, !tbaa !27
  br label %bb141
bb141:
  br label %bb170
bb142:
  %t644 = load ptr, ptr %l14, !tbaa !29
  store ptr %t644, ptr %l246, !tbaa !29
  store i1 false, ptr %l247, !tbaa !21
  %t645 = load ptr, ptr %l246, !tbaa !29
  %t646 = icmp ne ptr %t645, null
  br i1 %t646, label %bb143, label %bb144
bb143:
  %t648 = load ptr, ptr %l246, !tbaa !29
  %t649 = load i64, ptr %t648
  %t651 = icmp eq i64 %t649, 2
  store i1 %t651, ptr %l247, !tbaa !21
  br label %bb144
bb144:
  %t652 = load i1, ptr %l247, !tbaa !21
  br i1 %t652, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb151
bb147:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l250, !tbaa !27
  %t653 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t653, ptr %l251, !tbaa !27
  %t654 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t655 = extractvalue { i64, ptr } %t654, 0
  %t656 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t656, 0
  store i64 %t657, ptr %l253, !tbaa !24
  %t659 = load i64, ptr %l253, !tbaa !24
  %t660 = icmp eq i64 %t655, %t659
  br i1 %t660, label %bb148, label %bb149
bb148:
  %t662 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = load i64, ptr %l253, !tbaa !24
  %t667 = mul i64 %t666, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t663, ptr %t665, i64 %t667, i1 false)
  br label %bb150
bb149:
  %t668 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t669 = extractvalue { i64, ptr } %t668, 0
  store i64 %t669, ptr %l255, !tbaa !24
  %t670 = load i64, ptr %l255, !tbaa !24
  %t671 = mul i64 %t670, 1
  %t672 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t671)
  %t673 = insertvalue { i64, ptr } undef, i64 %t670, 0
  %t674 = insertvalue { i64, ptr } %t673, ptr %t672, 1
  store { i64, ptr } %t674, ptr %l256, !tbaa !27
  %t675 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !27
  %t679 = load i64, ptr %l255, !tbaa !24
  %t680 = mul i64 %t679, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t676, ptr %t678, i64 %t680, i1 false)
  %t681 = load { i64, ptr }, ptr %l256, !tbaa !27
  store { i64, ptr } %t681, ptr %l12, !tbaa !27
  br label %bb150
bb150:
  br label %bb170
bb151:
  %t682 = load ptr, ptr %l14, !tbaa !29
  store ptr %t682, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t683 = load ptr, ptr %l257, !tbaa !29
  %t684 = icmp ne ptr %t683, null
  br i1 %t684, label %bb152, label %bb153
bb152:
  %t686 = load ptr, ptr %l257, !tbaa !29
  %t687 = load i64, ptr %t686
  %t689 = icmp eq i64 %t687, 3
  store i1 %t689, ptr %l258, !tbaa !21
  br label %bb153
bb153:
  %t690 = load i1, ptr %l258, !tbaa !21
  br i1 %t690, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb160
bb156:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l261, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t691, ptr %l262, !tbaa !27
  %t692 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  %t694 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t695 = extractvalue { i64, ptr } %t694, 0
  store i64 %t695, ptr %l264, !tbaa !24
  %t697 = load i64, ptr %l264, !tbaa !24
  %t698 = icmp eq i64 %t693, %t697
  br i1 %t698, label %bb157, label %bb158
bb157:
  %t700 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !27
  %t702 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !27
  %t704 = load i64, ptr %l264, !tbaa !24
  %t705 = mul i64 %t704, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t701, ptr %t703, i64 %t705, i1 false)
  br label %bb159
bb158:
  %t706 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t707 = extractvalue { i64, ptr } %t706, 0
  store i64 %t707, ptr %l266, !tbaa !24
  %t708 = load i64, ptr %l266, !tbaa !24
  %t709 = mul i64 %t708, 1
  %t710 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t709)
  %t711 = insertvalue { i64, ptr } undef, i64 %t708, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t710, 1
  store { i64, ptr } %t712, ptr %l267, !tbaa !27
  %t713 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !27
  %t717 = load i64, ptr %l266, !tbaa !24
  %t718 = mul i64 %t717, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t714, ptr %t716, i64 %t718, i1 false)
  %t719 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t719, ptr %l12, !tbaa !27
  br label %bb159
bb159:
  br label %bb170
bb160:
  %t720 = load ptr, ptr %l14, !tbaa !29
  store ptr %t720, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t721 = load ptr, ptr %l268, !tbaa !29
  %t722 = icmp ne ptr %t721, null
  br i1 %t722, label %bb161, label %bb162
bb161:
  %t724 = load ptr, ptr %l268, !tbaa !29
  %t725 = load i64, ptr %t724
  %t727 = icmp eq i64 %t725, 4
  store i1 %t727, ptr %l269, !tbaa !21
  br label %bb162
bb162:
  %t728 = load i1, ptr %l269, !tbaa !21
  br i1 %t728, label %bb163, label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb169
bb165:
  store { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l272, !tbaa !27
  %t729 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t729, ptr %l273, !tbaa !27
  %t730 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t730, 0
  %t732 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t733 = extractvalue { i64, ptr } %t732, 0
  store i64 %t733, ptr %l275, !tbaa !24
  %t735 = load i64, ptr %l275, !tbaa !24
  %t736 = icmp eq i64 %t731, %t735
  br i1 %t736, label %bb166, label %bb167
bb166:
  %t738 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t739 = load ptr, ptr %t738, !tbaa !27
  %t740 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !27
  %t742 = load i64, ptr %l275, !tbaa !24
  %t743 = mul i64 %t742, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t739, ptr %t741, i64 %t743, i1 false)
  br label %bb168
bb167:
  %t744 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t744, 0
  store i64 %t745, ptr %l277, !tbaa !24
  %t746 = load i64, ptr %l277, !tbaa !24
  %t747 = mul i64 %t746, 1
  %t748 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t747)
  %t749 = insertvalue { i64, ptr } undef, i64 %t746, 0
  %t750 = insertvalue { i64, ptr } %t749, ptr %t748, 1
  store { i64, ptr } %t750, ptr %l278, !tbaa !27
  %t751 = getelementptr { i64, ptr }, ptr %l278, i32 0, i32 1
  %t752 = load ptr, ptr %t751, !tbaa !27
  %t753 = getelementptr { i64, ptr }, ptr %l273, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = load i64, ptr %l277, !tbaa !24
  %t756 = mul i64 %t755, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t752, ptr %t754, i64 %t756, i1 false)
  %t757 = load { i64, ptr }, ptr %l278, !tbaa !27
  store { i64, ptr } %t757, ptr %l12, !tbaa !27
  br label %bb168
bb168:
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_7d1c92b0dd6ac454_401b3f55cbe19f48)
  unreachable
bb170:
  br label %bb176
bb171:
  br i1 true, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_fcd7713830295b05_161c0b0a0c98f419)
  unreachable
bb176:
  %t758 = load ptr, ptr %l9, !tbaa !29
  %t761 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t758)
  store i32 %t761, ptr %l281
  br label %bb177
bb177:
  %t762 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t763 = load i32, ptr %l281, !tbaa !23
  %t765 = icmp eq i32 %t763, %t762
  br i1 %t765, label %bb178, label %bb179
bb178:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb179:
  br label %bb180
bb180:
  %t767 = load i64, ptr %l10, !tbaa !24
  %t769 = icmp slt i64 %t767, 0
  br i1 %t769, label %bb181, label %bb182
bb181:
  store %olang.scope zeroinitializer, ptr %s31
  %t771 = load ptr, ptr %l0, !tbaa !29
  store ptr %t771, ptr %l286, !tbaa !29
  %t772 = load ptr, ptr %l2, !tbaa !29
  %t774 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t772)
  store %"compiler/source:Span" %t774, ptr %l288
  br label %bb183
bb182:
  br label %bb187
bb183:
  %t775 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t777 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeNotCall(ptr %s0, ptr %s31, { i64, ptr } %t775)
  store %"compiler/msgs:Msg" %t777, ptr %l290
  br label %bb184
bb184:
  %t778 = load ptr, ptr %l286, !tbaa !29
  %t779 = load %"compiler/source:Span", ptr %l288
  %t780 = load %"compiler/msgs:Msg", ptr %l290
  %t781 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s31, ptr %t778, %"compiler/source:Span" %t779, %"compiler/msgs:Msg" %t780)
  store i64 %t781, ptr %l291
  br label %bb185
bb185:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t784
  %t785 = getelementptr { i64, [3 x i64] }, ptr %t784, i32 0, i32 0
  store i64 6, ptr %t785
  %t787 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t783, 0
  %t788 = insertvalue { %"compiler/source:Span", ptr } %t787, ptr null, 1
  %t789 = getelementptr { i64, [3 x i64] }, ptr %t784, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t788, ptr %t789
  %t790 = load { i64, [3 x i64] }, ptr %t784
  %t792 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t790, ptr %t792
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t782, ptr %t792)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s31)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb187:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/check:Checker", ptr %t795, i32 0, i32 12
  %t798 = load i64, ptr %l10, !tbaa !24
  %t801 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t797, i64 %t798)
  store ptr %t801, ptr %l299
  br label %bb188
bb188:
  %t802 = load ptr, ptr %l299, !tbaa !29
  %t804 = getelementptr %"compiler/typed:Body", ptr %t802, i32 0, i32 2
  %t805 = load i32, ptr %t804, !tbaa !23
  store i32 %t805, ptr %l18, !tbaa !23
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t808 = load i32, ptr %l11, !tbaa !23
  %t809 = load i32, ptr %l18, !tbaa !23
  %t813 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameJump(ptr %v0, ptr %t807, i32 %t808, i32 %t809)
  store i1 %t813, ptr %l305
  br label %bb189
bb189:
  %t814 = load i1, ptr %l305, !tbaa !21
  %t815 = xor i1 %t814, true
  br i1 %t815, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s32
  %t817 = load ptr, ptr %l0, !tbaa !29
  store ptr %t817, ptr %l307, !tbaa !29
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load ptr, ptr %l2, !tbaa !29
  %t822 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t818, ptr %t819)
  store %"compiler/source:Span" %t822, ptr %l310
  br label %bb192
bb191:
  br label %bb198
bb192:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load i32, ptr %l11, !tbaa !23
  %t827 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejumpText(ptr %v0, ptr %s32, ptr %t823, i32 %t824)
  store { i64, ptr } %t827, ptr %l313
  br label %bb193
bb193:
  %t828 = load { i64, ptr }, ptr %l313, !tbaa !27
  %t829 = extractvalue { i64, ptr } %t828, 0
  %t830 = extractvalue { i64, ptr } %t828, 1
  %t831 = mul i64 %t829, 1
  %t832 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t831)
  call void @llvm.memcpy.p0.p0.i64(ptr %t832, ptr %t830, i64 %t831, i1 false)
  %t833 = insertvalue { i64, ptr } undef, i64 %t829, 0
  %t834 = insertvalue { i64, ptr } %t833, ptr %t832, 1
  store { i64, ptr } %t834, ptr %l314, !tbaa !27
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load i32, ptr %l18, !tbaa !23
  %t839 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejumpText(ptr %v0, ptr %s32, ptr %t835, i32 %t836)
  store { i64, ptr } %t839, ptr %l317
  br label %bb194
bb194:
  %t840 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t841 = extractvalue { i64, ptr } %t840, 0
  %t842 = extractvalue { i64, ptr } %t840, 1
  %t843 = mul i64 %t841, 1
  %t844 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t843)
  call void @llvm.memcpy.p0.p0.i64(ptr %t844, ptr %t842, i64 %t843, i1 false)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t844, 1
  %t847 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t849 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeSignature(ptr %s32, ptr %s32, ptr %s32, { i64, ptr } %t847, { i64, ptr } %t846)
  store %"compiler/msgs:Msg" %t849, ptr %l319
  br label %bb195
bb195:
  %t850 = load ptr, ptr %l307, !tbaa !29
  %t851 = load %"compiler/source:Span", ptr %l310
  %t852 = load %"compiler/msgs:Msg", ptr %l319
  %t853 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t850, %"compiler/source:Span" %t851, %"compiler/msgs:Msg" %t852)
  store i64 %t853, ptr %l320
  br label %bb196
bb196:
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t856
  %t857 = getelementptr { i64, [3 x i64] }, ptr %t856, i32 0, i32 0
  store i64 6, ptr %t857
  %t859 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t855, 0
  %t860 = insertvalue { %"compiler/source:Span", ptr } %t859, ptr null, 1
  %t861 = getelementptr { i64, [3 x i64] }, ptr %t856, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t860, ptr %t861
  %t862 = load { i64, [3 x i64] }, ptr %t856
  %t864 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t862, ptr %t864
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t854, ptr %t864)
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb198:
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t868 = load i32, ptr %l11, !tbaa !23
  %t871 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaMemoryJump(ptr %v0, ptr %t867, i32 %t868)
  store i1 %t871, ptr %l327
  br label %bb199
bb199:
  %t872 = load i1, ptr %l327, !tbaa !21
  br i1 %t872, label %bb200, label %bb201
bb200:
  store %olang.scope zeroinitializer, ptr %s33
  %t873 = load ptr, ptr %l0, !tbaa !29
  store ptr %t873, ptr %l328, !tbaa !29
  %t874 = load ptr, ptr %l0, !tbaa !29
  %t875 = load ptr, ptr %l2, !tbaa !29
  %t878 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t874, ptr %t875)
  store %"compiler/source:Span" %t878, ptr %l331
  br label %bb202
bb201:
  br label %bb206
bb202:
  %t879 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeMemory(ptr %s33)
  store %"compiler/msgs:Msg" %t879, ptr %l332
  br label %bb203
bb203:
  %t880 = load ptr, ptr %l328, !tbaa !29
  %t881 = load %"compiler/source:Span", ptr %l331
  %t882 = load %"compiler/msgs:Msg", ptr %l332
  %t883 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t880, %"compiler/source:Span" %t881, %"compiler/msgs:Msg" %t882)
  store i64 %t883, ptr %l333
  br label %bb204
bb204:
  %t884 = load ptr, ptr %l0, !tbaa !29
  %t885 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t886
  %t887 = getelementptr { i64, [3 x i64] }, ptr %t886, i32 0, i32 0
  store i64 6, ptr %t887
  %t889 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t885, 0
  %t890 = insertvalue { %"compiler/source:Span", ptr } %t889, ptr null, 1
  %t891 = getelementptr { i64, [3 x i64] }, ptr %t886, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t890, ptr %t891
  %t892 = load { i64, [3 x i64] }, ptr %t886
  %t894 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t892, ptr %t894
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t884, ptr %t894)
  br label %bb205
bb205:
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb206:
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/check:Checker", ptr %t897, i32 0, i32 84
  store ptr %t899, ptr %l339, !tbaa !29
  %t900 = load ptr, ptr %l3, !tbaa !29
  %t902 = getelementptr %"compiler/check:frame", ptr %t900, i32 0, i32 0
  %t903 = load i64, ptr %t902, !tbaa !24
  %t904 = load i64, ptr %l10, !tbaa !24
  %t905 = load %"compiler/source:Span", ptr %l1
  %t906 = load ptr, ptr %l3, !tbaa !29
  %t908 = getelementptr %"compiler/check:frame", ptr %t906, i32 0, i32 1
  %t909 = load i64, ptr %t908, !tbaa !24
  %t914 = call %"compiler/check:tailAsk" @compiler_2fcheck_3atailAsk_2ector(ptr %s0, i64 %t903, i64 %t904, %"compiler/source:Span" %t905, i64 %t909)
  store %"compiler/check:tailAsk" %t914, ptr %l346
  br label %bb207
bb207:
  %t915 = load ptr, ptr %l339, !tbaa !29
  %t916 = load %"compiler/check:tailAsk", ptr %l346
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2ePush_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %t915, %"compiler/check:tailAsk" %t916)
  br label %bb208
bb208:
  %t917 = load ptr, ptr %l9, !tbaa !29
  store ptr %t917, ptr %l347, !tbaa !29
  store i1 false, ptr %l348, !tbaa !21
  %t918 = load ptr, ptr %l347, !tbaa !29
  %t919 = icmp ne ptr %t918, null
  br i1 %t919, label %bb209, label %bb210
bb209:
  %t921 = load ptr, ptr %l347, !tbaa !29
  %t922 = load i64, ptr %t921
  %t924 = icmp eq i64 %t922, 6
  store i1 %t924, ptr %l348, !tbaa !21
  br label %bb210
bb210:
  %t925 = load i1, ptr %l348, !tbaa !21
  br i1 %t925, label %bb211, label %bb212
bb211:
  %t926 = load ptr, ptr %l9, !tbaa !29
  %t928 = getelementptr { i64, [5 x i64] }, ptr %t926, i32 0, i32 1
  %t929 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t928, i32 0, i32 0
  %t930 = load %"compiler/source:Span", ptr %t929
  store %"compiler/source:Span" %t930, ptr %l19
  %t932 = load ptr, ptr %l9, !tbaa !29
  %t934 = getelementptr { i64, [5 x i64] }, ptr %t932, i32 0, i32 1
  %t935 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t934, i32 0, i32 1
  %t936 = load i32, ptr %t935
  store i32 %t936, ptr %l20, !tbaa !23
  %t938 = load ptr, ptr %l9, !tbaa !29
  %t940 = getelementptr { i64, [5 x i64] }, ptr %t938, i32 0, i32 1
  %t941 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t940, i32 0, i32 2
  %t942 = load ptr, ptr %t941
  store ptr %t942, ptr %l21, !tbaa !29
  br label %bb213
bb212:
  br label %bb216
bb213:
  %t944 = load ptr, ptr %l0, !tbaa !29
  store ptr %t944, ptr %l357, !tbaa !29
  %t945 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t945, ptr %l358
  %t946 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t946, ptr %l359
  %t947 = load i32, ptr %l20, !tbaa !23
  store i32 %t947, ptr %l360, !tbaa !23
  %t948 = load ptr, ptr %l21, !tbaa !29
  %t950 = getelementptr %"compiler/typed:Call", ptr %t948, i32 0, i32 0
  %t951 = load ptr, ptr %t950, !tbaa !29
  %t952 = load ptr, ptr %l21, !tbaa !29
  %t954 = getelementptr %"compiler/typed:Call", ptr %t952, i32 0, i32 1
  %t955 = load { i64, ptr }, ptr %t954, !tbaa !27
  %t956 = load ptr, ptr %l21, !tbaa !29
  %t958 = getelementptr %"compiler/typed:Call", ptr %t956, i32 0, i32 2
  %t959 = load { i64, [2 x i64] }, ptr %t958
  %t960 = load ptr, ptr %l21, !tbaa !29
  %t962 = getelementptr %"compiler/typed:Call", ptr %t960, i32 0, i32 3
  %t963 = load i32, ptr %t962, !tbaa !23
  %t964 = load ptr, ptr %l21, !tbaa !29
  %t966 = getelementptr %"compiler/typed:Call", ptr %t964, i32 0, i32 4
  %t967 = load i1, ptr %t966, !tbaa !21
  %t973 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t951, { i64, ptr } %t955, { i64, [2 x i64] } %t959, i32 %t963, i1 %t967, i1 true)
  store %"compiler/typed:Call" %t973, ptr %l371
  br label %bb214
bb214:
  %t974 = load %"compiler/typed:Call", ptr %l371
  %t975 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t974, ptr %t975
  store { i64, [5 x i64] } zeroinitializer, ptr %t976
  %t977 = getelementptr { i64, [5 x i64] }, ptr %t976, i32 0, i32 0
  store i64 6, ptr %t977
  %t978 = load %"compiler/source:Span", ptr %l359
  %t979 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t978, 0
  %t980 = load i32, ptr %l360, !tbaa !23
  %t981 = insertvalue { %"compiler/source:Span", i32, ptr } %t979, i32 %t980, 1
  %t983 = insertvalue { %"compiler/source:Span", i32, ptr } %t981, ptr %t975, 2
  %t984 = getelementptr { i64, [5 x i64] }, ptr %t976, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t983, ptr %t984
  %t985 = load { i64, [5 x i64] }, ptr %t976
  %t987 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t985, ptr %t987
  store { i64, [3 x i64] } zeroinitializer, ptr %t988
  %t989 = getelementptr { i64, [3 x i64] }, ptr %t988, i32 0, i32 0
  store i64 6, ptr %t989
  %t990 = load %"compiler/source:Span", ptr %l358
  %t991 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t990, 0
  %t993 = insertvalue { %"compiler/source:Span", ptr } %t991, ptr %t987, 1
  %t994 = getelementptr { i64, [3 x i64] }, ptr %t988, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t993, ptr %t994
  %t995 = load { i64, [3 x i64] }, ptr %t988
  %t997 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t995, ptr %t997
  %t998 = load ptr, ptr %l357, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t998, ptr %t997)
  br label %bb215
bb215:
  br label %bb221
bb216:
  br i1 true, label %bb217, label %bb218
bb217:
  br label %bb219
bb218:
  br label %bb220
bb219:
  br label %bb221
bb220:
  call void @__olang_check_failed(ptr @olang_loc_b092c7cdf5a0a7f2_b1af981e10a9543e)
  unreachable
bb221:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i32
  %l48 = alloca ptr
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l59 = alloca i32
  %l61 = alloca ptr
  %l64 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i32
  %l66 = alloca i32
  %l68 = alloca ptr
  %l69 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 2
  %t11 = load i32, ptr %t10, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 53
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t15, i64 %t16)
  %t20 = extractvalue { i32, i1 } %t19, 1
  %t21 = extractvalue { i32, i1 } %t19, 0
  store i32 %t21, ptr %l16
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb3, label %ok.23, !prof !99
ok.23:
  store i1 %t20, ptr %l15
  br label %bb2
bb2:
  %t24 = load i1, ptr %l15, !tbaa !21
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l22, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 17
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l26
  br label %bb10
bb10:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t49, i64 %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 17
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l33
  br label %bb15
bb15:
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = icmp eq i64 %t60, 2
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 54
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %t65, i64 %t66)
  %t70 = extractvalue { i32, i32 } %t69, 1
  %t71 = extractvalue { i32, i32 } %t69, 0
  store i32 %t71, ptr %l40
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb19, label %ok.73, !prof !99
ok.73:
  store i32 %t70, ptr %l39
  br label %bb18
bb17:
  br label %bb33
bb18:
  %t74 = load i32, ptr %l39, !tbaa !23
  store i32 %t74, ptr %l35, !tbaa !23
  br label %bb21
bb19:
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l35, !tbaa !23
  br label %bb21
bb21:
  %t75 = load i32, ptr %l35, !tbaa !23
  store i32 %t75, ptr %l3, !tbaa !23
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 56
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t79)
  %t83 = extractvalue { i32, i1 } %t82, 1
  %t84 = extractvalue { i32, i1 } %t82, 0
  store i32 %t84, ptr %l46
  %t85 = icmp ne i32 %t84, 0
  br i1 %t85, label %bb23, label %ok.86, !prof !99
ok.86:
  store i1 %t83, ptr %l45
  br label %bb22
bb22:
  %t87 = load i1, ptr %l45, !tbaa !21
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb25
bb23:
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l41, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 55
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load i64, ptr %l1, !tbaa !24
  store i64 %t92, ptr %l49, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t98, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  %t105 = load i64, ptr %l49, !tbaa !24
  %t107 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t105, i64 %t104)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t107, ptr %l56
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t108, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t109)
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t110)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 57
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t121 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %t117, i64 %t118)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t121, ptr %l64
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l61, !tbaa !29
  %t123 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l64
  %t124 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %t122, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t123)
  %t125 = extractvalue { i32, i32 } %t124, 1
  %t126 = extractvalue { i32, i32 } %t124, 0
  store i32 %t126, ptr %l66
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb36, label %ok.128, !prof !99
ok.128:
  store i32 %t125, ptr %l65
  br label %bb35
bb35:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %l59, !tbaa !23
  br label %bb38
bb36:
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l59, !tbaa !23
  br label %bb38
bb38:
  %t130 = load i32, ptr %l59, !tbaa !23
  store i32 %t130, ptr %l4, !tbaa !23
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 55
  store ptr %t133, ptr %l68, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  store i64 %t134, ptr %l69, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/generic:Program", ptr %t138, i32 0, i32 2
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l74
  br label %bb39
bb39:
  %t145 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = load i64, ptr %l69, !tbaa !24
  %t149 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t147, i64 %t146)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t149, ptr %l76
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l68, !tbaa !29
  %t151 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l76
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t150, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t151)
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %t152)
  br label %bb42
bb42:
  %t154 = load i32, ptr %l4, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t154, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Branch", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/load:Loader", ptr %t14, i32 0, i32 4
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Branch", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t17, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Branch", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/ast:Branch", ptr %t29, i32 0, i32 0
  %t32 = load %"compiler/source:Span", ptr %t31
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %t24, { i64, ptr } %t28, i32 1, %"compiler/source:Span" %t32)
  store ptr %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l18, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Branch", ptr %t39, i32 0, i32 2
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = icmp sge i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 4
  %t55 = load ptr, ptr %t54, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i64 %a4, i64 %a5, i1 %a6, i32 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l28 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 24
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  store i1 %t6, ptr %l8, !tbaa !21
  %t8 = load i1, ptr %l8, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l14, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l16
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l16, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 24
  store i64 %t17, ptr %t20, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 25
  store %"compiler/source:Span" %a1, ptr %t25
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %t26, %"compiler/source:Span" %a2, ptr %a3, i64 %a4, i64 %a5, i1 %a6, i32 %a7)
  store ptr %t40, ptr %l28
  br label %bb5
bb5:
  %t41 = load ptr, ptr %l28, !tbaa !29
  store ptr %t41, ptr %l9, !tbaa !29
  %t42 = load i1, ptr %l8, !tbaa !21
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 24
  store i64 -1, ptr %t46, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t47 = load ptr, ptr %l9, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l23 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca %"compiler/msgs:Msg"
  %l46 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb32
bb5:
  %t16 = load ptr, ptr %l3, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb26
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 12
  %t34 = load i32, ptr %l4, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t33, i64 %t36)
  store ptr %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 1
  %t43 = load { i64, [2 x i64] }, ptr %t42
  store { i64, [2 x i64] } %t43, ptr %l5
  %t45 = load { i64, [2 x i64] }, ptr %l5
  %t47 = extractvalue { i64, [2 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 0
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t50 = getelementptr { i64, [2 x i64] }, ptr %l5, i32 0, i32 1
  %t51 = getelementptr { i64 }, ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l6, !tbaa !24
  br label %bb14
bb13:
  br label %bb20
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l30, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l34
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load i64, ptr %l34, !tbaa !24
  %t68 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t66, i64 %t67)
  store ptr %t68, ptr %l35
  br label %bb16
bb16:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Func", ptr %t69, i32 0, i32 7
  %t72 = load i1, ptr %t71, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_15dc8e5e4dc9449e_12f0342e5abdcdfa)
  unreachable
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_7e3b8ef59b75af1f_c18e9d0b6f53f27b)
  unreachable
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_9f75bc02dd96bce4_c2844b619abecf00)
  unreachable
bb37:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t77 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t74)
  store i32 %t77, ptr %l40
  br label %bb38
bb38:
  %t78 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t79 = load i32, ptr %l40, !tbaa !23
  %t81 = icmp eq i32 %t79, %t78
  br i1 %t81, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb40:
  br label %bb41
bb41:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l43, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l44
  %t85 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallbackNotExport(ptr %s0)
  store %"compiler/msgs:Msg" %t85, ptr %l45
  br label %bb42
bb42:
  %t86 = load ptr, ptr %l43, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l44
  %t88 = load %"compiler/msgs:Msg", ptr %l45
  %t89 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t86, %"compiler/source:Span" %t87, %"compiler/msgs:Msg" %t88)
  store i64 %t89, ptr %l46
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l24
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp sgt i64 %t38, 0
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t63, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb19
bb19:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb22:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t107, i32 %t108, i64 0)
  store i1 %t109, ptr %l60
  br label %bb23
bb23:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l53, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l49, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb12
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t130 = load i32, ptr %l69, !tbaa !23
  store i32 %t130, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l6, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l76
  br label %bb34
bb34:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l25 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/typed:Local"
  %l64 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l72 = alloca i1
  %l81 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l103 = alloca %"compiler/typed:Local"
  %l104 = alloca i32
  %l111 = alloca ptr
  %l114 = alloca i32
  %l118 = alloca %"compiler/typed:Capture"
  %l122 = alloca i1
  %l123 = alloca i1
  %l128 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t147 = alloca { i64, [5 x i64] }, align 8
  %t165 = alloca { i64, [5 x i64] }, align 8
  %t193 = alloca { i64, [2 x i64] }, align 8
  %t260 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 8
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t11, i32 %t12)
  %t16 = extractvalue { i32, i64 } %t15, 1
  %t17 = extractvalue { i32, i64 } %t15, 0
  store i32 %t17, ptr %l22
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb3, label %ok.19, !prof !99
ok.19:
  store i64 %t16, ptr %l21
  br label %bb2
bb2:
  %t20 = load i64, ptr %l21, !tbaa !24
  store i64 %t20, ptr %l17, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l17, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 19
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load i64, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 19
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load %"compiler/source:Span", ptr %l3
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t40, i32 %t41, %"compiler/source:Span" %t42)
  store i64 %t47, ptr %l35
  br label %bb12
bb12:
  %t48 = load i64, ptr %l35, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 12
  store ptr %t56, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 14
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 19
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v0, ptr %t59, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l40, !tbaa !29
  %t73 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t71, i64 %t70)
  store ptr %t73, ptr %l48
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l48, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 7
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/typed:Local" %t80, ptr %l52
  br label %bb18
bb18:
  %t81 = getelementptr %"compiler/typed:Local", ptr %l52, i32 0, i32 2
  %t82 = load i32, ptr %t81, !tbaa !23
  store i32 %t82, ptr %l7, !tbaa !23
  %t84 = load %"compiler/source:Span", ptr %l3
  %t85 = load i32, ptr %l7, !tbaa !23
  %t86 = load i64, ptr %l6, !tbaa !24
  %t88 = trunc i64 %t86 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 0, ptr %t91
  %t93 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t84, 0
  %t95 = insertvalue { %"compiler/source:Span", i32, i32 } %t93, i32 %t85, 1
  %t97 = insertvalue { %"compiler/source:Span", i32, i32 } %t95, i32 %t88, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l8, !tbaa !29
  %t103 = load i32, ptr %l7, !tbaa !23
  store i32 %t103, ptr %l9, !tbaa !23
  store ptr null, ptr %l10, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l7, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l64
  br label %bb19
bb19:
  %t110 = load i1, ptr %l64, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l7, !tbaa !23
  %t117 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l69
  br label %bb22
bb21:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t118 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t119 = load i32, ptr %l69, !tbaa !23
  %t121 = icmp ne i32 %t119, %t118
  store i1 %t121, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t123 = load i1, ptr %l66, !tbaa !21
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 20
  %t127 = load i1, ptr %t126, !tbaa !21
  %t129 = xor i1 %t127, true
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb26
bb26:
  %t131 = load i1, ptr %l72, !tbaa !21
  br i1 %t131, label %bb27, label %bb28
bb27:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %l7, !tbaa !23
  %t139 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t137, i32 %t138, i64 %t139)
  store i32 %t143, ptr %l81
  br label %bb29
bb28:
  %t144 = load %"compiler/source:Span", ptr %l3
  %t145 = load i32, ptr %l7, !tbaa !23
  %t146 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 0
  store i64 2, ptr %t148
  %t150 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t144, 0
  %t152 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t150, i32 %t145, 1
  %t154 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t152, ptr %t146, 2
  %t155 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t154, i32 -1, 3
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t155, ptr %t156
  %t157 = load { i64, [5 x i64] }, ptr %t147
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t157, ptr %t159
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb30
bb29:
  %t161 = load i32, ptr %l81, !tbaa !23
  store i32 %t161, ptr %l9, !tbaa !23
  %t162 = load %"compiler/source:Span", ptr %l3
  %t163 = load i32, ptr %l9, !tbaa !23
  %t164 = load ptr, ptr %l8, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 0
  store i64 3, ptr %t166
  %t168 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t162, 0
  %t170 = insertvalue { %"compiler/source:Span", i32, ptr } %t168, i32 %t163, 1
  %t172 = insertvalue { %"compiler/source:Span", i32, ptr } %t170, ptr %t164, 2
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t165, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t172, ptr %t173
  %t174 = load { i64, [5 x i64] }, ptr %t165
  %t176 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t174, ptr %t176
  store ptr %t176, ptr %l10, !tbaa !29
  br label %bb30
bb30:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 12
  %t181 = load ptr, ptr %l4, !tbaa !29
  %t183 = getelementptr %"compiler/check:frame", ptr %t181, i32 0, i32 0
  %t184 = load i64, ptr %t183, !tbaa !24
  %t187 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t180, i64 %t184)
  store ptr %t187, ptr %l96
  br label %bb31
bb31:
  %t188 = load ptr, ptr %l96, !tbaa !29
  store ptr %t188, ptr %l11, !tbaa !29
  %t189 = load ptr, ptr %l11, !tbaa !29
  store ptr %t189, ptr %l97, !tbaa !29
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load %"compiler/source:Span", ptr %l3
  %t192 = load i32, ptr %l9, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t193
  %t194 = getelementptr { i64, [2 x i64] }, ptr %t193, i32 0, i32 0
  store i64 5, ptr %t194
  %t195 = load { i64, [2 x i64] }, ptr %t193
  %t201 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t190, %"compiler/source:Span" %t191, i32 %t192, i32 0, i32 5, { i64, [2 x i64] } %t195)
  store %"compiler/typed:Local" %t201, ptr %l103
  br label %bb32
bb32:
  %t202 = load ptr, ptr %l97, !tbaa !29
  %t203 = load %"compiler/typed:Local", ptr %l103
  %t204 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t202, %"compiler/typed:Local" %t203)
  store i32 %t204, ptr %l104
  br label %bb33
bb33:
  %t205 = load i32, ptr %l104, !tbaa !23
  %t206 = sext i32 %t205 to i64
  store i64 %t206, ptr %l12, !tbaa !24
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t210 = getelementptr %"compiler/check:frame", ptr %t208, i32 0, i32 8
  %t211 = load i32, ptr %l2, !tbaa !23
  %t212 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t210, i32 %t211, i64 %t212)
  br label %bb34
bb34:
  %t216 = load ptr, ptr %l4, !tbaa !29
  %t218 = getelementptr %"compiler/check:frame", ptr %t216, i32 0, i32 28
  store ptr %t218, ptr %l111, !tbaa !29
  %t219 = load i64, ptr %l12, !tbaa !24
  %t221 = trunc i64 %t219 to i32
  store i32 %t221, ptr %l114, !tbaa !23
  %t223 = load ptr, ptr %l10, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af)
  unreachable
bb36:
  br label %bb37
bb37:
  %t227 = load ptr, ptr %l10, !tbaa !29
  %t228 = load i32, ptr %l114, !tbaa !23
  %t230 = call %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v0, i32 %t228, ptr %t227)
  store %"compiler/typed:Capture" %t230, ptr %l118
  br label %bb38
bb38:
  %t231 = load %"compiler/typed:Capture", ptr %l118
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Capture" %t231, ptr %t232
  %t233 = load ptr, ptr %l111, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v0, ptr %t233, ptr %t232)
  br label %bb39
bb39:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l9, !tbaa !23
  %t239 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t235, i32 %t236)
  store i1 %t239, ptr %l122
  br label %bb40
bb40:
  %t240 = load i1, ptr %l122, !tbaa !21
  br i1 %t240, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb44
bb42:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  %t247 = load i32, ptr %l9, !tbaa !23
  %t250 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t246, i32 %t247)
  store i1 %t250, ptr %l128
  br label %bb43
bb43:
  %t251 = load i1, ptr %l128, !tbaa !21
  store i1 %t251, ptr %l123, !tbaa !21
  br label %bb44
bb44:
  %t252 = load i1, ptr %l123, !tbaa !21
  br i1 %t252, label %bb45, label %bb46
bb45:
  %t253 = load ptr, ptr %l11, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Body", ptr %t253, i32 0, i32 6
  %t256 = load i64, ptr %l12, !tbaa !24
  %t258 = trunc i64 %t256 to i32
  store { i64, [1 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [1 x i64] }, ptr %t260, i32 0, i32 0
  store i64 4, ptr %t261
  %t263 = insertvalue { i32 } undef, i32 %t258, 0
  %t264 = getelementptr { i64, [1 x i64] }, ptr %t260, i32 0, i32 1
  store { i32 } %t263, ptr %t264
  %t265 = load { i64, [1 x i64] }, ptr %t260
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %t255, { i64, [1 x i64] } %t265)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t268 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t268, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l54 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb45
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l4
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb14
bb13:
  br label %bb39
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t59)
  store ptr %t61, ptr %l31
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l29, !tbaa !29
  %t71 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t68, i64 %t65, i32 %t67)
  store %"compiler/names:Ref" %t71, ptr %l35
  br label %bb16
bb16:
  %t72 = load %"compiler/names:Ref", ptr %l35
  store %"compiler/names:Ref" %t72, ptr %l6
  %t73 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t80, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l42
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %s3, ptr %s3, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t94, ptr %l44
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l38, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l39
  %t97 = load %"compiler/msgs:Msg", ptr %l44
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l45
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 75
  store ptr %t101, ptr %l47, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t102)
  store ptr %t104, ptr %l49
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i32, ptr %l5, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t108, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l54
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l47, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb25:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  store i1 %t126, ptr %l58, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l58, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l5, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t133, ptr %l64
  br label %bb31
bb30:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb32
bb31:
  %t134 = load i64, ptr %l2, !tbaa !24
  %t135 = load i64, ptr %l64, !tbaa !24
  %t137 = icmp eq i64 %t135, %t134
  store i1 %t137, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l61, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l67, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l68
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l5, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l71
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %s4, ptr %s4, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t155, ptr %l73
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l68
  %t158 = load %"compiler/msgs:Msg", ptr %l73
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t156, %"compiler/source:Span" %t157, %"compiler/msgs:Msg" %t158)
  store i64 %t159, ptr %l74
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_3cf4b7359f29899a_630bdcef83a186)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_7977da1af626a39b_b4b859805bc3ac67)
  unreachable
bb50:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca { i64, ptr }
  %l43 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i32
  %l56 = alloca i32
  %l57 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l60 = alloca i64
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca i1
  %l72 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca i64
  %l101 = alloca i64
  %l120 = alloca { i64, ptr }
  %l124 = alloca i1
  %l128 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l130 = alloca i64
  %l132 = alloca i1
  %l134 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l138 = alloca %"compiler/msgs:Msg"
  %l139 = alloca i64
  %l140 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l149 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l153 = alloca i1
  %l163 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l164 = alloca ptr
  %l165 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l177 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l184 = alloca %"compiler/msgs:Msg"
  %l185 = alloca i64
  %l188 = alloca { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l193 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/msgs:Msg"
  %l197 = alloca i64
  %l201 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l203 = alloca i64
  %l205 = alloca ptr
  %l207 = alloca %"compiler/source:Span"
  %l208 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l217 = alloca %"compiler/msgs:Msg"
  %l218 = alloca i64
  %l223 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l224 = alloca ptr
  %l226 = alloca %"compiler/source:Span"
  %l227 = alloca %"compiler/msgs:Msg"
  %l228 = alloca i64
  %l234 = alloca ptr
  %l236 = alloca ptr
  %l240 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l242 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l247 = alloca i1
  %l251 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l253 = alloca i64
  %l255 = alloca i1
  %l258 = alloca i1
  %l264 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l266 = alloca i64
  %l268 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l274 = alloca i64
  %l276 = alloca i1
  %l282 = alloca ptr
  %l286 = alloca %"compiler/source:Span"
  %l288 = alloca %"compiler/msgs:Msg"
  %l289 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i1, i1 }
  %t100 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l33
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l33, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l34, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"compiler/ast:Match", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l37
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l34, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l37
  %t14 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t12, %"compiler/source:Span" %t13)
  store { i64, ptr } %t14, ptr %l38
  br label %bb3
bb3:
  %t15 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t17 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t15, i64 %t16)
  %t25 = getelementptr i8, ptr %t24, i64 %t16
  call void @olang_textcopy(ptr %t25, ptr %t18, i64 %t19)
  %t26 = getelementptr i8, ptr %t25, i64 %t19
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t24, 1
  store { i64, ptr } %t28, ptr %l4, !tbaa !27
  store i1 true, ptr %l6, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Match", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t30, ptr %t34)
  store i32 %t37, ptr %l43
  br label %bb4
bb4:
  %t38 = load i32, ptr %l43, !tbaa !23
  store i32 %t38, ptr %l7, !tbaa !23
  %t39 = load i32, ptr %l7, !tbaa !23
  %t41 = icmp ne i32 %t39, 0
  br i1 %t41, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l46, !tbaa !29
  %t44 = load i32, ptr %l7, !tbaa !23
  store i32 %t44, ptr %l47, !tbaa !23
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  store ptr %t50, ptr %l50, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l51, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l7, !tbaa !23
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l54
  br label %bb7
bb6:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l76, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  store ptr %t63, ptr %l79, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 58
  %t68 = load i64, ptr %t67, !tbaa !24
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t64, i64 %t68)
  store i32 %t71, ptr %l83
  br label %bb25
bb7:
  %t72 = load ptr, ptr %l51, !tbaa !29
  %t73 = load i64, ptr %l54, !tbaa !24
  %t74 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t72, i64 %t73)
  store i32 %t74, ptr %l55
  br label %bb8
bb8:
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = load i32, ptr %l55, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l56
  br label %bb9
bb9:
  %t78 = load ptr, ptr %l46, !tbaa !29
  %t79 = load i32, ptr %l47, !tbaa !23
  %t80 = load i32, ptr %l56, !tbaa !23
  %t81 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %s0, ptr %t78, i32 %t79, i32 %t80)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l57
  br label %bb10
bb10:
  %t82 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l5
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t83, i32 %t84)
  store i64 %t87, ptr %l60
  br label %bb11
bb11:
  %t88 = load i64, ptr %l60, !tbaa !24
  %t89 = icmp slt i64 %t88, 0
  br i1 %t89, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l63, !tbaa !29
  %t92 = load i32, ptr %l7, !tbaa !23
  store i32 %t92, ptr %l64, !tbaa !23
  %t93 = icmp sge i64 1, 0
  br i1 %t93, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb19
bb14:
  %t95 = icmp sle i64 1, 2305843009213693951
  br i1 %t95, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb16:
  %t97 = mul i64 1, 4
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  %t99 = load i32, ptr %l64, !tbaa !23
  store i64 0, ptr %t100
  br label %fill.101
fill.101:
  %t104 = load i64, ptr %t100
  %t105 = icmp slt i64 %t104, 1
  br i1 %t105, label %fillb.102, label %filld.103
fillb.102:
  %t106 = getelementptr i32, ptr %t98, i64 %t104
  store i32 %t99, ptr %t106
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %t100
  br label %fill.101
filld.103:
  %t108 = insertvalue { i64, ptr } undef, i64 1, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t98, 1
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %s2, ptr %t110, { i64, ptr } %t109)
  store i1 %t112, ptr %l68
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_fc394d3abb705b3d_774ad654d23301b9)
  unreachable
bb18:
  %t113 = load i1, ptr %l68, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l62, !tbaa !21
  br label %bb19
bb19:
  %t116 = load i1, ptr %l62, !tbaa !21
  store i1 %t116, ptr %l6, !tbaa !21
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l7, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t117, i32 %t118)
  store i64 %t121, ptr %l72
  br label %bb20
bb20:
  %t122 = load i64, ptr %l72, !tbaa !24
  %t123 = icmp sge i64 %t122, 0
  br i1 %t123, label %bb21, label %bb22
bb21:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t125, i32 %t126)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb25:
  %t129 = load ptr, ptr %l79, !tbaa !29
  %t130 = load i32, ptr %l83, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l84
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l76, !tbaa !29
  %t133 = load i32, ptr %l84, !tbaa !23
  %t134 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t132, i32 %t133)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %l85
  br label %bb27
bb27:
  %t135 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l5
  %t136 = load ptr, ptr %l3, !tbaa !29
  %t138 = getelementptr %"compiler/check:frame", ptr %t136, i32 0, i32 59
  %t139 = load i1, ptr %t138, !tbaa !21
  %t141 = xor i1 %t139, true
  store i1 %t141, ptr %l6, !tbaa !21
  br label %bb28
bb28:
  %t143 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %l89
  br label %bb29
bb29:
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l8
  %t145 = load i1, ptr %l6, !tbaa !21
  %t147 = xor i1 %t145, true
  store i1 %t147, ptr %l9, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Match", ptr %t149, i32 0, i32 3
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  store i64 %t154, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb30, label %bb31
bb30:
  %t162 = load i64, ptr %l14, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb35
bb32:
  %t166 = load i64, ptr %l13, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l14, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l101, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb34
bb34:
  %t182 = load i64, ptr %l101, !tbaa !24
  store i64 %t182, ptr %l98, !tbaa !24
  br label %bb35
bb35:
  %t183 = load i64, ptr %l98, !tbaa !24
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb125
bb38:
  br label %bb39
bb39:
  %t192 = load i64, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l16, !tbaa !24
  %t194 = load i64, ptr %l14, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  %t202 = load ptr, ptr %l2, !tbaa !29
  %t204 = getelementptr %"compiler/ast:Match", ptr %t202, i32 0, i32 3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l120, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t200
  %t211 = load ptr, ptr %t210, !tbaa !39
  store ptr %t211, ptr %l18, !tbaa !29
  %t213 = load i1, ptr %l11, !tbaa !21
  br i1 %t213, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb47
bb41:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t219 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s6, ptr %t215, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t219, ptr %l128
  br label %bb42
bb42:
  %t220 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l128
  %t221 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t220, ptr %t221
  %t223 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s6, ptr %t221)
  store i64 %t223, ptr %l130
  br label %bb43
bb43:
  %t224 = load i64, ptr %l130, !tbaa !24
  %t225 = icmp eq i64 %t224, 0
  br i1 %t225, label %bb44, label %bb45
bb44:
  %t227 = load i1, ptr %l9, !tbaa !21
  store i1 %t227, ptr %l132, !tbaa !21
  br label %bb46
bb45:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb46
bb46:
  %t229 = load i1, ptr %l132, !tbaa !21
  store i1 %t229, ptr %l124, !tbaa !21
  br label %bb47
bb47:
  %t230 = load i1, ptr %l124, !tbaa !21
  br i1 %t230, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l134, !tbaa !29
  %t232 = load ptr, ptr %l18, !tbaa !29
  %t234 = getelementptr %"compiler/ast:Case", ptr %t232, i32 0, i32 0
  %t235 = load %"compiler/source:Span", ptr %t234
  store %"compiler/source:Span" %t235, ptr %l136
  %t236 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t238 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %s0, ptr %s7, { i64, ptr } %t236)
  store %"compiler/msgs:Msg" %t238, ptr %l138
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t239 = load ptr, ptr %l134, !tbaa !29
  %t240 = load %"compiler/source:Span", ptr %l136
  %t241 = load %"compiler/msgs:Msg", ptr %l138
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t239, %"compiler/source:Span" %t240, %"compiler/msgs:Msg" %t241)
  store i64 %t242, ptr %l139
  br label %bb51
bb51:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb124
bb52:
  %t243 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t243, ptr %l140
  br label %bb53
bb53:
  %t244 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l140
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t244, ptr %l19
  store i1 false, ptr %l20, !tbaa !21
  %t245 = load ptr, ptr %l18, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Case", ptr %t245, i32 0, i32 1
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  store i64 %t252, ptr %l23, !tbaa !24
  br label %bb54
bb54:
  %t254 = load i64, ptr %l22, !tbaa !24
  %t255 = load i64, ptr %l23, !tbaa !24
  %t258 = icmp slt i64 %t254, %t255
  %t260 = xor i1 %t258, true
  br i1 %t260, label %bb55, label %bb56
bb55:
  br label %bb115
bb56:
  br label %bb57
bb57:
  %t262 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t262, ptr %l149, !tbaa !27
  %t263 = load i64, ptr %l22, !tbaa !24
  %t265 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr ptr, ptr %t266, i64 %t263
  %t268 = load ptr, ptr %t267, !tbaa !39
  store ptr %t268, ptr %l24, !tbaa !29
  %t270 = load ptr, ptr %l24, !tbaa !29
  store ptr %t270, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t271 = load ptr, ptr %l152, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb58, label %bb59
bb58:
  %t274 = load ptr, ptr %l152, !tbaa !29
  %t275 = load i64, ptr %t274
  %t277 = icmp eq i64 %t275, 0
  store i1 %t277, ptr %l153, !tbaa !21
  br label %bb59
bb59:
  %t278 = load i1, ptr %l153, !tbaa !21
  br i1 %t278, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t279 = load ptr, ptr %l18, !tbaa !29
  %t281 = getelementptr %"compiler/ast:Case", ptr %t279, i32 0, i32 3
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t284 = icmp eq ptr %t282, null
  br i1 %t284, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb65
bb64:
  br label %bb65
bb65:
  store i1 true, ptr %l20, !tbaa !21
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t289 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t287, ptr %t289
  %t293 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s6, ptr %s0, ptr %s6, ptr %t286, ptr %t289, ptr %l5)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t293, ptr %l163
  br label %bb66
bb66:
  %t294 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l163
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t294, ptr %l19
  br label %bb113
bb67:
  %t295 = load ptr, ptr %l24, !tbaa !29
  store ptr %t295, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t296 = load ptr, ptr %l164, !tbaa !29
  %t297 = icmp ne ptr %t296, null
  br i1 %t297, label %bb68, label %bb69
bb68:
  %t299 = load ptr, ptr %l164, !tbaa !29
  %t300 = load i64, ptr %t299
  %t302 = icmp eq i64 %t300, 1
  store i1 %t302, ptr %l165, !tbaa !21
  br label %bb69
bb69:
  %t303 = load i1, ptr %l165, !tbaa !21
  br i1 %t303, label %bb70, label %bb71
bb70:
  %t304 = load ptr, ptr %l24, !tbaa !29
  %t306 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 1
  %t307 = getelementptr { %"compiler/source:Span", ptr }, ptr %t306, i32 0, i32 1
  %t308 = load ptr, ptr %t307
  store ptr %t308, ptr %l25, !tbaa !29
  br label %bb76
bb71:
  %t310 = load ptr, ptr %l24, !tbaa !29
  store ptr %t310, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t311 = load ptr, ptr %l170, !tbaa !29
  %t312 = icmp ne ptr %t311, null
  br i1 %t312, label %bb72, label %bb73
bb72:
  %t314 = load ptr, ptr %l170, !tbaa !29
  %t315 = load i64, ptr %t314
  %t317 = icmp eq i64 %t315, 4
  store i1 %t317, ptr %l171, !tbaa !21
  br label %bb73
bb73:
  %t318 = load i1, ptr %l171, !tbaa !21
  br i1 %t318, label %bb74, label %bb75
bb74:
  %t319 = load ptr, ptr %l24, !tbaa !29
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr }, ptr %t321, i32 0, i32 1
  %t323 = load ptr, ptr %t322
  store ptr %t323, ptr %l25, !tbaa !29
  br label %bb76
bb75:
  br label %bb105
bb76:
  store %olang.scope zeroinitializer, ptr %s12
  %t325 = load ptr, ptr %l25, !tbaa !29
  %t327 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t325)
  store i1 %t327, ptr %l177
  br label %bb77
bb77:
  %t328 = load i1, ptr %l177, !tbaa !21
  br i1 %t328, label %bb78, label %bb79
bb78:
  %t329 = load i1, ptr %l6, !tbaa !21
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb80, label %bb81
bb79:
  br label %bb86
bb80:
  store %olang.scope zeroinitializer, ptr %s14
  %t333 = load ptr, ptr %l0, !tbaa !29
  store ptr %t333, ptr %l180, !tbaa !29
  %t334 = load ptr, ptr %l24, !tbaa !29
  %t336 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t334)
  store %"compiler/source:Span" %t336, ptr %l182
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t337 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t339 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %s0, ptr %s14, { i64, ptr } %t337)
  store %"compiler/msgs:Msg" %t339, ptr %l184
  br label %bb83
bb83:
  %t340 = load ptr, ptr %l180, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l182
  %t342 = load %"compiler/msgs:Msg", ptr %l184
  %t343 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t340, %"compiler/source:Span" %t341, %"compiler/msgs:Msg" %t342)
  store i64 %t343, ptr %l185
  br label %bb84
bb84:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  store i1 true, ptr %l20, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb86:
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l25, !tbaa !29
  %t348 = call { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %s12, ptr %t344, ptr %t345)
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t348, ptr %l188
  br label %bb87
bb87:
  %t349 = load { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l188
  store { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t349, ptr %l26
  %t350 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l26, i32 0, i32 0
  %t351 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t350
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t351, ptr %l27
  %t353 = getelementptr { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l26, i32 0, i32 1
  %t354 = load i1, ptr %t353, !tbaa !21
  %t358 = xor i1 %t354, true
  br i1 %t358, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l193, !tbaa !29
  %t361 = load ptr, ptr %l24, !tbaa !29
  %t363 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t361)
  store %"compiler/source:Span" %t363, ptr %l195
  br label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s16
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t368 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s12, ptr %s16, ptr %t364, ptr %l5, ptr %l27)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t368, ptr %l201
  br label %bb93
bb90:
  %t369 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s15)
  store %"compiler/msgs:Msg" %t369, ptr %l196
  br label %bb91
bb91:
  %t370 = load ptr, ptr %l193, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l195
  %t372 = load %"compiler/msgs:Msg", ptr %l196
  %t373 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t370, %"compiler/source:Span" %t371, %"compiler/msgs:Msg" %t372)
  store i64 %t373, ptr %l197
  br label %bb92
bb92:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb104
bb93:
  %t374 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l201
  %t375 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t374, ptr %t375
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s16, ptr %t375)
  store i64 %t377, ptr %l203
  br label %bb94
bb94:
  %t378 = load i64, ptr %l203, !tbaa !24
  %t379 = icmp eq i64 %t378, 0
  br i1 %t379, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s17
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l205, !tbaa !29
  %t382 = load ptr, ptr %l24, !tbaa !29
  %t384 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t382)
  store %"compiler/source:Span" %t384, ptr %l207
  br label %bb97
bb96:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t388 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t386, ptr %t388
  %t392 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s6, ptr %s12, ptr %s6, ptr %t385, ptr %t388, ptr %l27)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t392, ptr %l223
  br label %bb102
bb97:
  %t393 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t393, ptr %l208, !tbaa !27
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t397 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s12, ptr %s17, ptr %t394, ptr %l27)
  store { i64, ptr } %t397, ptr %l211
  br label %bb98
bb98:
  %t398 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t398, 0
  %t400 = extractvalue { i64, ptr } %t398, 1
  %t401 = mul i64 %t399, 1
  %t402 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t401)
  call void @llvm.memcpy.p0.p0.i64(ptr %t402, ptr %t400, i64 %t401, i1 false)
  %t403 = insertvalue { i64, ptr } undef, i64 %t399, 0
  %t404 = insertvalue { i64, ptr } %t403, ptr %t402, 1
  store { i64, ptr } %t404, ptr %l212, !tbaa !27
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t408 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s17, ptr %t405, ptr %l5)
  store { i64, ptr } %t408, ptr %l215
  br label %bb99
bb99:
  %t409 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t409, 0
  %t411 = extractvalue { i64, ptr } %t409, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  %t416 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t417 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t419 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s0, ptr %s17, ptr %s17, ptr %s17, { i64, ptr } %t416, { i64, ptr } %t417, { i64, ptr } %t415)
  store %"compiler/msgs:Msg" %t419, ptr %l217
  br label %bb100
bb100:
  %t420 = load ptr, ptr %l205, !tbaa !29
  %t421 = load %"compiler/source:Span", ptr %l207
  %t422 = load %"compiler/msgs:Msg", ptr %l217
  %t423 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s17, ptr %t420, %"compiler/source:Span" %t421, %"compiler/msgs:Msg" %t422)
  store i64 %t423, ptr %l218
  br label %bb101
bb101:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb102:
  %t424 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l223
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t424, ptr %l19
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s16)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb112
bb108:
  store %olang.scope zeroinitializer, ptr %s19
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l224, !tbaa !29
  %t426 = load ptr, ptr %l24, !tbaa !29
  %t428 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t426)
  store %"compiler/source:Span" %t428, ptr %l226
  br label %bb109
bb109:
  %t429 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %s19)
  store %"compiler/msgs:Msg" %t429, ptr %l227
  br label %bb110
bb110:
  %t430 = load ptr, ptr %l224, !tbaa !29
  %t431 = load %"compiler/source:Span", ptr %l226
  %t432 = load %"compiler/msgs:Msg", ptr %l227
  %t433 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t430, %"compiler/source:Span" %t431, %"compiler/msgs:Msg" %t432)
  store i64 %t433, ptr %l228
  br label %bb111
bb111:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s19)
  br label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_259a476ccf69be4f_4dd02f382a72243)
  unreachable
bb113:
  br label %bb114
bb114:
  %t434 = load i64, ptr %l22, !tbaa !24
  %t436 = add i64 %t434, 1
  store i64 %t436, ptr %l22, !tbaa !24
  br label %bb54
bb115:
  %t438 = load ptr, ptr %l18, !tbaa !29
  %t440 = getelementptr %"compiler/ast:Case", ptr %t438, i32 0, i32 3
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb116, label %bb117
bb116:
  %t445 = load ptr, ptr %l0, !tbaa !29
  store ptr %t445, ptr %l234, !tbaa !29
  %t446 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t448 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t446, ptr %t448
  store ptr %t448, ptr %l236, !tbaa !29
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t453 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s6, ptr %s0, ptr %s0, ptr %t449, ptr %l19, ptr %l5)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t453, ptr %l240
  br label %bb118
bb117:
  br label %bb123
bb118:
  %t454 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l240
  %t455 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t454, ptr %t455
  %t456 = load ptr, ptr %l234, !tbaa !29
  %t457 = load ptr, ptr %l236, !tbaa !29
  %t459 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t456, ptr %t457, ptr %t455)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t459, ptr %l242
  br label %bb119
bb119:
  %t460 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l242
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t460, ptr %l8
  %t461 = load i1, ptr %l20, !tbaa !21
  br i1 %t461, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb122
bb121:
  br label %bb122
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s6)
  br label %bb124
bb124:
  %t463 = load i64, ptr %l16, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l16, !tbaa !24
  br label %bb36
bb125:
  %t467 = load i1, ptr %l11, !tbaa !21
  br i1 %t467, label %bb126, label %bb127
bb126:
  store i1 true, ptr %l247, !tbaa !21
  br label %bb133
bb127:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t473 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t469, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t473, ptr %l251
  br label %bb128
bb128:
  %t474 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l251
  %t475 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t474, ptr %t475
  %t477 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t475)
  store i64 %t477, ptr %l253
  br label %bb129
bb129:
  %t478 = load i64, ptr %l253, !tbaa !24
  %t479 = icmp eq i64 %t478, 0
  br i1 %t479, label %bb130, label %bb131
bb130:
  %t481 = load i1, ptr %l9, !tbaa !21
  store i1 %t481, ptr %l255, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb132
bb132:
  %t483 = load i1, ptr %l255, !tbaa !21
  store i1 %t483, ptr %l247, !tbaa !21
  br label %bb133
bb133:
  %t484 = load i1, ptr %l247, !tbaa !21
  store i1 %t484, ptr %l29, !tbaa !21
  %t485 = load i1, ptr %l10, !tbaa !21
  br i1 %t485, label %bb134, label %bb135
bb134:
  %t487 = load i1, ptr %l29, !tbaa !21
  %t489 = xor i1 %t487, true
  store i1 %t489, ptr %l258, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb136
bb136:
  %t491 = load i1, ptr %l258, !tbaa !21
  br i1 %t491, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s24
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t496 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %s0, ptr %s0, ptr %s24, ptr %t492, ptr %l5, ptr %l8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t496, ptr %l264
  br label %bb139
bb138:
  br label %bb155
bb139:
  %t497 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l264
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t497, ptr %l30
  %t499 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s24, ptr %l30)
  store i64 %t499, ptr %l266
  br label %bb140
bb140:
  %t500 = load i64, ptr %l266, !tbaa !24
  %t501 = icmp sgt i64 %t500, 0
  br i1 %t501, label %bb141, label %bb142
bb141:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t506 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s24, ptr %s24, ptr %t503, ptr %l30)
  store { i64, ptr } %t506, ptr %l271
  br label %bb143
bb142:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l268, !tbaa !27
  br label %bb144
bb143:
  %t507 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 0
  %t509 = extractvalue { i64, ptr } %t507, 1
  %t510 = mul i64 %t508, 1
  %t511 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t510)
  call void @llvm.memcpy.p0.p0.i64(ptr %t511, ptr %t509, i64 %t510, i1 false)
  %t512 = insertvalue { i64, ptr } undef, i64 %t508, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  store { i64, ptr } %t513, ptr %l268, !tbaa !27
  br label %bb144
bb144:
  %t515 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t515, ptr %l31, !tbaa !27
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s24, ptr %l30)
  store i64 %t517, ptr %l274
  br label %bb145
bb145:
  %t518 = load i64, ptr %l274, !tbaa !24
  %t519 = icmp sgt i64 %t518, 0
  br i1 %t519, label %bb146, label %bb147
bb146:
  %t521 = load i1, ptr %l9, !tbaa !21
  %t523 = xor i1 %t521, true
  store i1 %t523, ptr %l276, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l276, !tbaa !21
  br label %bb148
bb148:
  %t525 = load i1, ptr %l276, !tbaa !21
  br i1 %t525, label %bb149, label %bb150
bb149:
  %t526 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 1
  %t529 = extractvalue { i64, ptr } %t526, 0
  %t530 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t531 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t532 = add i64 %t529, %t531
  %t533 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t532)
  call void @olang_textcopy(ptr %t533, ptr %t528, i64 %t529)
  %t534 = getelementptr i8, ptr %t533, i64 %t529
  call void @olang_textcopy(ptr %t534, ptr %t530, i64 %t531)
  %t535 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t533, 1
  %t538 = extractvalue { i64, ptr } %t536, 0
  %t539 = extractvalue { i64, ptr } %t536, 1
  %t540 = mul i64 %t538, 1
  %t541 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t540)
  call void @llvm.memcpy.p0.p0.i64(ptr %t541, ptr %t539, i64 %t540, i1 false)
  %t542 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t541, 1
  store { i64, ptr } %t543, ptr %l31, !tbaa !27
  br label %bb151
bb150:
  br label %bb151
bb151:
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l282, !tbaa !29
  %t546 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t547 = load i32, ptr %t546, !tbaa !23
  %t548 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t549 = load i32, ptr %t548, !tbaa !23
  %t551 = add i32 %t549, 5
  %t554 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s24, i32 %t547, i32 %t551)
  store %"compiler/source:Span" %t554, ptr %l286
  br label %bb152
bb152:
  %t555 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t557 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %s24, ptr %s24, { i64, ptr } %t555)
  store %"compiler/msgs:Msg" %t557, ptr %l288
  br label %bb153
bb153:
  %t558 = load ptr, ptr %l282, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l286
  %t560 = load %"compiler/msgs:Msg", ptr %l288
  %t561 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t558, %"compiler/source:Span" %t559, %"compiler/msgs:Msg" %t560)
  store i64 %t561, ptr %l289
  br label %bb154
bb154:
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s24)
  br label %bb155
bb155:
  %t562 = load i1, ptr %l10, !tbaa !21
  %t563 = load i1, ptr %l29, !tbaa !21
  %t565 = insertvalue { i1, i1 } undef, i1 %t562, 0
  %t567 = insertvalue { i1, i1 } %t565, i1 %t563, 1
  call void @__olang_scope_close(ptr %s0)
  store { i1, i1 } %t567, ptr %rv
  br label %ret
ret:
  %rr = load { i1, i1 }, ptr %rv
  ret { i1, i1 } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca %"compiler/check:litv"
  %l84 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l112 = alloca i64
  %l115 = alloca { i64, ptr }
  %l118 = alloca i1
  %l122 = alloca ptr
  %l125 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca %"compiler/source:Span"
  %l142 = alloca ptr
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i1
  %l180 = alloca i64
  %l183 = alloca i64
  %l205 = alloca i1
  %l219 = alloca i1
  %l231 = alloca { i64, ptr }
  %l237 = alloca ptr
  %l240 = alloca i64
  %l241 = alloca ptr
  %l246 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca ptr
  %l255 = alloca ptr
  %l257 = alloca i32
  %l260 = alloca i1
  %l261 = alloca i32
  %l264 = alloca i32
  %l269 = alloca i1
  %l270 = alloca ptr
  %l271 = alloca ptr
  %l273 = alloca ptr
  %l275 = alloca i32
  %l278 = alloca ptr
  %l280 = alloca %"compiler/source:Span"
  %l281 = alloca ptr
  %l285 = alloca i64
  %l290 = alloca ptr
  %l291 = alloca ptr
  %l293 = alloca { i64, ptr }
  %l296 = alloca %"compiler/source:Span"
  %l298 = alloca { i64, ptr }
  %l302 = alloca %"compiler/source:Span"
  %l304 = alloca { i64, ptr }
  %l307 = alloca { i64, ptr }
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i32
  %l313 = alloca i32
  %l314 = alloca i1
  %l323 = alloca ptr
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca ptr
  %l326 = alloca i64
  %l327 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l333 = alloca ptr
  %l335 = alloca ptr
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 36
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load i64, ptr %l41, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:Chain", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %l45, !tbaa !24
  %t15 = load i64, ptr %l45, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l45, !tbaa !24
  %t19 = mul i64 %t18, 1
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t23, ptr %lp5
  %t25 = load ptr, ptr %lp5
  store { i64, ptr } %t22, ptr %t25, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t28, %t29
  br i1 %t32, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_514ceade83978a4d_1843f44cd2570191)
  unreachable
bb4:
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb9
bb6:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = sub i64 %t38, %t39
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = add i64 %t42, %t43
  %t48 = sub i64 %t46, 1
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = sdiv i64 %t48, %t49
  store i64 %t52, ptr %l55, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb8
bb8:
  %t54 = load i64, ptr %l55, !tbaa !24
  store i64 %t54, ptr %l52, !tbaa !24
  br label %bb9
bb9:
  %t55 = load i64, ptr %l52, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  %t56 = load i64, ptr %l10, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = icmp slt i64 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb11, label %bb12
bb11:
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = mul i64 %t65, %t66
  %t72 = add i64 %t64, %t69
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  store i64 %t74, ptr %l73, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:Chain", ptr %t76, i32 0, i32 1
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l76, !tbaa !27
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 %t80
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t89 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t75, ptr %t85)
  store %"compiler/check:litv" %t89, ptr %l80
  br label %bb14
bb14:
  %t90 = getelementptr %"compiler/check:litv", ptr %l80, i32 0, i32 0
  %t91 = load i1, ptr %t90, !tbaa !21
  %t93 = load ptr, ptr %lp5
  %t94 = load i64, ptr %l73, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i1, ptr %t96, i64 %t94
  store i1 %t91, ptr %t97, !tbaa !31
  br label %bb15
bb15:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t102 = load i64, ptr %l4, !tbaa !24
  store i64 %t102, ptr %l84, !tbaa !24
  %t103 = load i64, ptr %l84, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb17, label %bb18
bb17:
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l4, !tbaa !24
  store i64 %t112, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = icmp sgt i64 %t114, %t115
  br i1 %t118, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8bbd92ac148fb220_5a9ba8c1b178084)
  unreachable
bb19:
  %t120 = load i64, ptr %l15, !tbaa !24
  %t122 = icmp sgt i64 %t120, 0
  br i1 %t122, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l91, !tbaa !24
  br label %bb24
bb21:
  %t124 = load i64, ptr %l14, !tbaa !24
  %t125 = load i64, ptr %l13, !tbaa !24
  %t128 = sub i64 %t124, %t125
  %t129 = load i64, ptr %l15, !tbaa !24
  %t132 = add i64 %t128, %t129
  %t134 = sub i64 %t132, 1
  %t135 = load i64, ptr %l15, !tbaa !24
  %t138 = sdiv i64 %t134, %t135
  store i64 %t138, ptr %l94, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb23
bb23:
  %t140 = load i64, ptr %l94, !tbaa !24
  store i64 %t140, ptr %l91, !tbaa !24
  br label %bb24
bb24:
  %t141 = load i64, ptr %l91, !tbaa !24
  store i64 %t141, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l17, !tbaa !24
  %t143 = load i64, ptr %l16, !tbaa !24
  %t146 = icmp slt i64 %t142, %t143
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb26, label %bb27
bb26:
  br label %bb40
bb27:
  br label %bb28
bb28:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = mul i64 %t151, %t152
  %t158 = add i64 %t150, %t155
  store i64 %t158, ptr %l18, !tbaa !24
  %t160 = load i64, ptr %l18, !tbaa !24
  store i64 %t160, ptr %l112, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/ast:Chain", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l115, !tbaa !27
  %t166 = load i64, ptr %l18, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr ptr, ptr %t169, i64 %t166
  %t171 = load ptr, ptr %t170, !tbaa !39
  %t174 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t161, ptr %t171)
  store i1 %t174, ptr %l118
  br label %bb29
bb29:
  %t175 = load i1, ptr %l118, !tbaa !21
  %t176 = load i64, ptr %l112, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i1, ptr %t178, i64 %t176
  store i1 %t175, ptr %t179, !tbaa !31
  %t180 = load i64, ptr %l18, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i1, ptr %t183, i64 %t180
  %t185 = load i1, ptr %t184, !tbaa !31
  br i1 %t185, label %bb30, label %bb31
bb30:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 36
  store ptr %t189, ptr %l122, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l125
  br label %bb32
bb31:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 36
  store ptr %t197, ptr %l127, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l128, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Chain", ptr %t200, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l131, !tbaa !27
  %t204 = load i64, ptr %l18, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 %t204
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t199, ptr %t209, i32 %t211)
  store ptr %t215, ptr %l136
  br label %bb34
bb32:
  %t216 = load ptr, ptr %l122, !tbaa !29
  %t217 = load ptr, ptr %l125, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t216, ptr %t217)
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t218 = load ptr, ptr %l2, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Chain", ptr %t218, i32 0, i32 1
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l138, !tbaa !27
  %t222 = load i64, ptr %l18, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr ptr, ptr %t225, i64 %t222
  %t227 = load ptr, ptr %t226, !tbaa !39
  %t229 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t227)
  store %"compiler/source:Span" %t229, ptr %l141
  br label %bb35
bb35:
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = load ptr, ptr %l136, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l141
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t230, ptr %t231, %"compiler/source:Span" %t232)
  store ptr %t233, ptr %l142
  br label %bb36
bb36:
  %t234 = load ptr, ptr %l127, !tbaa !29
  %t235 = load ptr, ptr %l142, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t234, ptr %t235)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t236 = load i64, ptr %l17, !tbaa !24
  %t238 = add i64 %t236, 1
  store i64 %t238, ptr %l17, !tbaa !24
  br label %bb25
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l4, !tbaa !24
  store i64 %t240, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t242 = load i64, ptr %l20, !tbaa !24
  %t243 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp sgt i64 %t242, %t243
  br i1 %t246, label %bb41, label %bb42
bb41:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t250 = icmp sgt i64 %t248, 0
  br i1 %t250, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb46
bb43:
  %t252 = load i64, ptr %l20, !tbaa !24
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = sub i64 %t252, %t253
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = add i64 %t256, %t257
  %t262 = sub i64 %t260, 1
  %t263 = load i64, ptr %l21, !tbaa !24
  %t266 = sdiv i64 %t262, %t263
  store i64 %t266, ptr %l152, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb45
bb45:
  %t268 = load i64, ptr %l152, !tbaa !24
  store i64 %t268, ptr %l149, !tbaa !24
  br label %bb46
bb46:
  %t269 = load i64, ptr %l149, !tbaa !24
  store i64 %t269, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l22, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb116
bb49:
  br label %bb50
bb50:
  %t278 = load i64, ptr %l19, !tbaa !24
  %t279 = load i64, ptr %l23, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = mul i64 %t279, %t280
  %t286 = add i64 %t278, %t283
  store i64 %t286, ptr %l24, !tbaa !24
  %t288 = load i64, ptr %l24, !tbaa !24
  %t290 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr i1, ptr %t291, i64 %t288
  %t293 = load i1, ptr %t292, !tbaa !31
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb53
bb52:
  %t297 = load i64, ptr %l24, !tbaa !24
  %t298 = load ptr, ptr %lp5
  %t300 = getelementptr { i64, ptr }, ptr %t298, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr i1, ptr %t301, i64 %t297
  %t303 = load i1, ptr %t302, !tbaa !31
  store i1 %t303, ptr %l173, !tbaa !21
  br label %bb53
bb53:
  %t305 = load i1, ptr %l173, !tbaa !21
  br i1 %t305, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb55:
  br label %bb56
bb56:
  store i64 -1, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t306 = load i64, ptr %l4, !tbaa !24
  store i64 %t306, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  %t309 = load i64, ptr %l26, !tbaa !24
  %t312 = icmp sgt i64 %t308, %t309
  br i1 %t312, label %bb57, label %bb58
bb57:
  %t314 = load i64, ptr %l28, !tbaa !24
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb59, label %bb60
bb58:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb62
bb59:
  %t318 = load i64, ptr %l27, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t322 = sub i64 %t318, %t319
  %t323 = load i64, ptr %l28, !tbaa !24
  %t326 = add i64 %t322, %t323
  %t328 = sub i64 %t326, 1
  %t329 = load i64, ptr %l28, !tbaa !24
  %t332 = sdiv i64 %t328, %t329
  store i64 %t332, ptr %l183, !tbaa !24
  br label %bb61
bb60:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb61
bb61:
  %t334 = load i64, ptr %l183, !tbaa !24
  store i64 %t334, ptr %l180, !tbaa !24
  br label %bb62
bb62:
  %t335 = load i64, ptr %l180, !tbaa !24
  store i64 %t335, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  br label %bb63
bb63:
  %t336 = load i64, ptr %l30, !tbaa !24
  %t337 = load i64, ptr %l29, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb64, label %bb65
bb64:
  br label %bb80
bb65:
  br label %bb66
bb66:
  %t344 = load i64, ptr %l26, !tbaa !24
  %t345 = load i64, ptr %l30, !tbaa !24
  %t346 = load i64, ptr %l28, !tbaa !24
  %t349 = mul i64 %t345, %t346
  %t352 = add i64 %t344, %t349
  store i64 %t352, ptr %l31, !tbaa !24
  %t354 = load i64, ptr %l24, !tbaa !24
  %t355 = load i64, ptr %l31, !tbaa !24
  %t358 = sub i64 %t354, %t355
  %t360 = icmp sge i64 %t358, 0
  br i1 %t360, label %bb67, label %bb68
bb67:
  %t362 = load i64, ptr %l24, !tbaa !24
  %t363 = load i64, ptr %l31, !tbaa !24
  %t366 = sub i64 %t362, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i1, ptr %t369, i64 %t366
  %t371 = load i1, ptr %t370, !tbaa !31
  %t373 = xor i1 %t371, true
  store i1 %t373, ptr %l205, !tbaa !21
  br label %bb69
bb68:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb69
bb69:
  %t375 = load i1, ptr %l205, !tbaa !21
  br i1 %t375, label %bb70, label %bb71
bb70:
  %t376 = load i64, ptr %l24, !tbaa !24
  %t377 = load i64, ptr %l31, !tbaa !24
  %t380 = sub i64 %t376, %t377
  store i64 %t380, ptr %l25, !tbaa !24
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t382 = load i64, ptr %l24, !tbaa !24
  %t383 = load i64, ptr %l31, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t387 = load i64, ptr %l4, !tbaa !24
  %t390 = icmp slt i64 %t386, %t387
  br i1 %t390, label %bb73, label %bb74
bb73:
  %t392 = load i64, ptr %l24, !tbaa !24
  %t393 = load i64, ptr %l31, !tbaa !24
  %t396 = add i64 %t392, %t393
  %t398 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i1, ptr %t399, i64 %t396
  %t401 = load i1, ptr %t400, !tbaa !31
  %t403 = xor i1 %t401, true
  store i1 %t403, ptr %l219, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb75
bb75:
  %t405 = load i1, ptr %l219, !tbaa !21
  br i1 %t405, label %bb76, label %bb77
bb76:
  %t406 = load i64, ptr %l24, !tbaa !24
  %t407 = load i64, ptr %l31, !tbaa !24
  %t410 = add i64 %t406, %t407
  store i64 %t410, ptr %l25, !tbaa !24
  br label %bb80
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t412 = load i64, ptr %l30, !tbaa !24
  %t414 = add i64 %t412, 1
  store i64 %t414, ptr %l30, !tbaa !24
  br label %bb63
bb80:
  %t416 = load ptr, ptr %l2, !tbaa !29
  %t418 = getelementptr %"compiler/ast:Chain", ptr %t416, i32 0, i32 1
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l231, !tbaa !27
  %t420 = load i64, ptr %l24, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr ptr, ptr %t423, i64 %t420
  %t425 = load ptr, ptr %t424, !tbaa !39
  store ptr %t425, ptr %l32, !tbaa !29
  %t427 = load i64, ptr %l25, !tbaa !24
  %t429 = icmp slt i64 %t427, 0
  br i1 %t429, label %bb81, label %bb82
bb81:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"compiler/check:Checker", ptr %t431, i32 0, i32 36
  store ptr %t433, ptr %l237, !tbaa !29
  %t434 = load i64, ptr %l3, !tbaa !24
  %t435 = load i64, ptr %l24, !tbaa !24
  %t438 = add i64 %t434, %t435
  store i64 %t438, ptr %l240, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  store ptr %t439, ptr %l241, !tbaa !29
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l32, !tbaa !29
  %t443 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t440, ptr %t441, i32 %t443)
  store ptr %t447, ptr %l246
  br label %bb83
bb82:
  br label %bb87
bb83:
  %t448 = load ptr, ptr %l32, !tbaa !29
  %t450 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t448)
  store %"compiler/source:Span" %t450, ptr %l248
  br label %bb84
bb84:
  %t451 = load ptr, ptr %l241, !tbaa !29
  %t452 = load ptr, ptr %l246, !tbaa !29
  %t453 = load %"compiler/source:Span", ptr %l248
  %t454 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t451, ptr %t452, %"compiler/source:Span" %t453)
  store ptr %t454, ptr %l249
  br label %bb85
bb85:
  %t455 = load ptr, ptr %l237, !tbaa !29
  %t456 = load i64, ptr %l240, !tbaa !24
  %t457 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t455, i64 %t456, ptr %t457)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb87:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 36
  %t461 = load i64, ptr %l3, !tbaa !24
  %t462 = load i64, ptr %l25, !tbaa !24
  %t465 = add i64 %t461, %t462
  %t468 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s10, ptr %t460, i64 %t465)
  store ptr %t468, ptr %l255
  br label %bb88
bb88:
  %t469 = load ptr, ptr %l255, !tbaa !29
  %t471 = call i32 @compiler_2fcheck_2etypeOf(ptr %s10, ptr %t469)
  store i32 %t471, ptr %l257
  br label %bb89
bb89:
  %t472 = load i32, ptr %l257, !tbaa !23
  store i32 %t472, ptr %l33, !tbaa !23
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load i32, ptr %l33, !tbaa !23
  %t477 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t473, i32 %t474)
  store i1 %t477, ptr %l260
  br label %bb90
bb90:
  %t478 = load i1, ptr %l260, !tbaa !21
  br i1 %t478, label %bb91, label %bb92
bb91:
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l33, !tbaa !23
  %t483 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t479, i32 %t480)
  store i32 %t483, ptr %l264
  br label %bb93
bb92:
  %t484 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t484, ptr %l261, !tbaa !23
  br label %bb94
bb93:
  %t486 = load i32, ptr %l264, !tbaa !23
  store i32 %t486, ptr %l261, !tbaa !23
  br label %bb94
bb94:
  %t487 = load i32, ptr %l261, !tbaa !23
  store i32 %t487, ptr %l34, !tbaa !23
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l32, !tbaa !29
  %t490 = load i32, ptr %l34, !tbaa !23
  %t494 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t488, ptr %t489, i32 %t490)
  store i1 %t494, ptr %l269
  br label %bb95
bb95:
  %t495 = load i1, ptr %l269, !tbaa !21
  store i1 %t495, ptr %l35, !tbaa !21
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l270, !tbaa !29
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l271, !tbaa !29
  %t498 = load ptr, ptr %l32, !tbaa !29
  store ptr %t498, ptr %l273, !tbaa !29
  %t500 = load i1, ptr %l35, !tbaa !21
  br i1 %t500, label %bb96, label %bb97
bb96:
  %t502 = load i32, ptr %l34, !tbaa !23
  store i32 %t502, ptr %l275, !tbaa !23
  br label %bb98
bb97:
  %t504 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t504, ptr %l275, !tbaa !23
  br label %bb98
bb98:
  %t506 = load ptr, ptr %l271, !tbaa !29
  %t507 = load ptr, ptr %l273, !tbaa !29
  %t508 = load i32, ptr %l275, !tbaa !23
  %t509 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t506, ptr %t507, i32 %t508)
  store ptr %t509, ptr %l278
  br label %bb99
bb99:
  %t510 = load ptr, ptr %l32, !tbaa !29
  %t512 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t510)
  store %"compiler/source:Span" %t512, ptr %l280
  br label %bb100
bb100:
  %t513 = load ptr, ptr %l270, !tbaa !29
  %t514 = load ptr, ptr %l278, !tbaa !29
  %t515 = load %"compiler/source:Span", ptr %l280
  %t516 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t513, ptr %t514, %"compiler/source:Span" %t515)
  store ptr %t516, ptr %l281
  br label %bb101
bb101:
  %t517 = load ptr, ptr %l281, !tbaa !29
  store ptr %t517, ptr %l36, !tbaa !29
  %t518 = load i64, ptr %l24, !tbaa !24
  %t519 = load i64, ptr %l25, !tbaa !24
  %t522 = icmp slt i64 %t518, %t519
  br i1 %t522, label %bb102, label %bb103
bb102:
  %t524 = load i64, ptr %l24, !tbaa !24
  store i64 %t524, ptr %l285, !tbaa !24
  br label %bb104
bb103:
  %t526 = load i64, ptr %l25, !tbaa !24
  store i64 %t526, ptr %l285, !tbaa !24
  br label %bb104
bb104:
  %t528 = load i64, ptr %l285, !tbaa !24
  store i64 %t528, ptr %l37, !tbaa !24
  %t529 = load i1, ptr %l35, !tbaa !21
  %t531 = xor i1 %t529, true
  br i1 %t531, label %bb105, label %bb106
bb105:
  store %olang.scope zeroinitializer, ptr %s18
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l290, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l291, !tbaa !29
  %t535 = load ptr, ptr %l2, !tbaa !29
  %t537 = getelementptr %"compiler/ast:Chain", ptr %t535, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l293, !tbaa !27
  %t539 = load i64, ptr %l37, !tbaa !24
  %t541 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr ptr, ptr %t542, i64 %t539
  %t544 = load ptr, ptr %t543, !tbaa !39
  %t546 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t544)
  store %"compiler/source:Span" %t546, ptr %l296
  br label %bb107
bb106:
  br label %bb113
bb107:
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t549 = getelementptr %"compiler/ast:Chain", ptr %t547, i32 0, i32 1
  %t550 = load { i64, ptr }, ptr %t549, !tbaa !27
  store { i64, ptr } %t550, ptr %l298, !tbaa !27
  %t551 = load i64, ptr %l37, !tbaa !24
  %t553 = add i64 %t551, 1
  %t555 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr ptr, ptr %t556, i64 %t553
  %t558 = load ptr, ptr %t557, !tbaa !39
  %t560 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t558)
  store %"compiler/source:Span" %t560, ptr %l302
  br label %bb108
bb108:
  %t561 = load ptr, ptr %l2, !tbaa !29
  %t563 = getelementptr %"compiler/ast:Chain", ptr %t561, i32 0, i32 0
  %t564 = load { i64, ptr }, ptr %t563, !tbaa !27
  store { i64, ptr } %t564, ptr %l304, !tbaa !27
  %t565 = load i64, ptr %l37, !tbaa !24
  %t567 = getelementptr { i64, ptr }, ptr %l304, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = getelementptr i32, ptr %t568, i64 %t565
  %t570 = load i32, ptr %t569
  %t572 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s18, i32 %t570)
  store { i64, ptr } %t572, ptr %l307
  br label %bb109
bb109:
  %t573 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = load ptr, ptr %l291, !tbaa !29
  %t576 = load %"compiler/source:Span", ptr %l296
  %t577 = load %"compiler/source:Span", ptr %l302
  %t579 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t575, %"compiler/source:Span" %t576, %"compiler/source:Span" %t577, i64 %t574)
  store %"compiler/source:Span" %t579, ptr %l309
  br label %bb110
bb110:
  %t580 = load i32, ptr %l33, !tbaa !23
  store i32 %t580, ptr %l310, !tbaa !23
  %t581 = load ptr, ptr %l36, !tbaa !29
  %t584 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t581)
  store i32 %t584, ptr %l313
  br label %bb111
bb111:
  %t585 = load ptr, ptr %l290, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l309
  %t587 = load i32, ptr %l310, !tbaa !23
  %t588 = load i32, ptr %l313, !tbaa !23
  %t589 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t585, %"compiler/source:Span" %t586, i32 %t587, i32 %t588)
  store i1 %t589, ptr %l314
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s18)
  br label %bb113
bb113:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t592 = getelementptr %"compiler/check:Checker", ptr %t590, i32 0, i32 36
  %t593 = load i64, ptr %l3, !tbaa !24
  %t594 = load i64, ptr %l24, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t598 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t592, i64 %t597, ptr %t598)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s10)
  br label %bb115
bb115:
  %t602 = load i64, ptr %l23, !tbaa !24
  %t604 = add i64 %t602, 1
  store i64 %t604, ptr %l23, !tbaa !24
  br label %bb47
bb116:
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l323, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t607, ptr %l324
  %t608 = load ptr, ptr %l2, !tbaa !29
  store ptr %t608, ptr %l325, !tbaa !29
  %t609 = load i64, ptr %l3, !tbaa !24
  store i64 %t609, ptr %l326, !tbaa !24
  %t610 = load ptr, ptr %lp5
  %t611 = load { i64, ptr }, ptr %t610, !tbaa !27
  store { i64, ptr } %t611, ptr %l327, !tbaa !27
  %t612 = load ptr, ptr %lp5
  %t613 = getelementptr { i64, ptr }, ptr %t612, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i1, ptr %t614, i64 0
  %t616 = load i1, ptr %t615, !tbaa !31
  br i1 %t616, label %bb117, label %bb118
bb117:
  store ptr null, ptr %l329, !tbaa !29
  br label %bb120
bb118:
  %t618 = load ptr, ptr %l0, !tbaa !29
  %t620 = getelementptr %"compiler/check:Checker", ptr %t618, i32 0, i32 36
  %t621 = load i64, ptr %l3, !tbaa !24
  %t624 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t620, i64 %t621)
  store ptr %t624, ptr %l333
  br label %bb119
bb119:
  %t625 = load ptr, ptr %l333, !tbaa !29
  store ptr %t625, ptr %l329, !tbaa !29
  br label %bb120
bb120:
  %t627 = load ptr, ptr %l323, !tbaa !29
  %t628 = load %"compiler/source:Span", ptr %l324
  %t629 = load ptr, ptr %l325, !tbaa !29
  %t630 = load i64, ptr %l326, !tbaa !24
  %t631 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t632 = load ptr, ptr %l329, !tbaa !29
  %t633 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v0, ptr %t627, %"compiler/source:Span" %t628, ptr %t629, i64 %t630, { i64, ptr } %t631, i64 0, ptr %t632)
  store ptr %t633, ptr %l335
  br label %bb121
bb121:
  %t634 = load ptr, ptr %l335, !tbaa !29
  store ptr %t634, ptr %l38, !tbaa !29
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/check:Checker", ptr %t635, i32 0, i32 36
  %t638 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eTrunca_Hdac151ce4e73ec212dc55b02b0b7e7d0(ptr %v0, ptr %t637, i64 %t638)
  br label %bb122
bb122:
  %t641 = load ptr, ptr %l38, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t641, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca %"compiler/check:litv"
  %l59 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca ptr
  %l72 = alloca ptr
  %l74 = alloca %"compiler/source:Span"
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca %"compiler/check:litv"
  %l89 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca i32
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr ptr, ptr %t8, i64 %t5
  %t10 = load ptr, ptr %t9, !tbaa !39
  store ptr %t10, ptr %l6, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr %"compiler/ast:Chain", ptr %t12, i32 0, i32 1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = add i64 %t16, 1
  %t20 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr ptr, ptr %t21, i64 %t18
  %t23 = load ptr, ptr %t22, !tbaa !39
  store ptr %t23, ptr %l7, !tbaa !29
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr %"compiler/ast:Chain", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l8
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb1, label %bb2
bb1:
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb3
bb3:
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb4, label %bb5
bb4:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l1
  %t47 = load i32, ptr %l8
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t45, %"compiler/source:Span" %t46, i32 %t47, ptr %t48, ptr %t49, i32 %t50)
  store ptr %t57, ptr %l36
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load ptr, ptr %l36, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb7:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l37, !tbaa !29
  %t60 = load ptr, ptr %l6, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l39
  br label %bb8
bb8:
  %t63 = load ptr, ptr %l7, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l41
  br label %bb9
bb9:
  %t66 = load i32, ptr %l8
  %t68 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t66)
  store { i64, ptr } %t68, ptr %l43
  br label %bb10
bb10:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load %"compiler/source:Span", ptr %l39
  %t73 = load %"compiler/source:Span", ptr %l41
  %t75 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t71, %"compiler/source:Span" %t72, %"compiler/source:Span" %t73, i64 %t70)
  store %"compiler/source:Span" %t75, ptr %l45
  br label %bb11
bb11:
  %t76 = load %"compiler/source:Span", ptr %l45
  store %"compiler/source:Span" %t76, ptr %l9
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l48, !tbaa !29
  %t82 = load ptr, ptr %l6, !tbaa !29
  store ptr %t82, ptr %l49, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l6, !tbaa !29
  %t88 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store %"compiler/check:litv" %t88, ptr %l53
  br label %bb14
bb13:
  br label %bb29
bb14:
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_854899d5724a103b_e7dfb19072d83fa7)
  unreachable
bb16:
  br label %bb17
bb17:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t94 = load i32, ptr %l8
  %t95 = load %"compiler/source:Span", ptr %l9
  %t96 = load ptr, ptr %l48, !tbaa !29
  %t97 = load ptr, ptr %l49, !tbaa !29
  %t98 = load %"compiler/check:litv", ptr %l53
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t96, ptr %t97, %"compiler/check:litv" %t98, ptr %t93, i32 %t94, %"compiler/source:Span" %t95, i1 false)
  store ptr %t102, ptr %l59
  br label %bb18
bb18:
  %t103 = load ptr, ptr %l59, !tbaa !29
  store ptr %t103, ptr %l10, !tbaa !29
  %t104 = load ptr, ptr %l10, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t108, %"compiler/source:Span" %t109)
  store ptr %t112, ptr %l64
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t113 = load ptr, ptr %l64, !tbaa !29
  store ptr %t113, ptr %rv
  br label %ret
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t114, ptr %l65, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t115, ptr %l66
  %t116 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t116, ptr %l67
  %t117 = load i32, ptr %l8
  store i32 %t117, ptr %l68
  %t118 = load ptr, ptr %l10, !tbaa !29
  store ptr %t118, ptr %l69, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_852b58c2eb82b3cc_e47a0c64d3951188)
  unreachable
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l5, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t124)
  store %"compiler/source:Span" %t126, ptr %l74
  br label %bb26
bb26:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t129 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t127)
  store %"compiler/source:Span" %t129, ptr %l76
  br label %bb27
bb27:
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l66
  %t132 = load %"compiler/source:Span", ptr %l67
  %t133 = load i32, ptr %l68
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l72, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l74
  %t137 = load %"compiler/source:Span", ptr %l76
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t130, %"compiler/source:Span" %t131, %"compiler/source:Span" %t132, i32 %t133, ptr %t134, ptr %t135, %"compiler/source:Span" %t136, %"compiler/source:Span" %t137)
  store ptr %t138, ptr %l77
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l5, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb30, label %bb31
bb30:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l80, !tbaa !29
  %t145 = load ptr, ptr %l7, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t151 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t146, ptr %t147)
  store %"compiler/check:litv" %t151, ptr %l85
  br label %bb32
bb31:
  br label %bb41
bb32:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i32, ptr %l8
  %t154 = load %"compiler/source:Span", ptr %l9
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load %"compiler/check:litv", ptr %l85
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t155, ptr %t156, %"compiler/check:litv" %t157, ptr %t152, i32 %t153, %"compiler/source:Span" %t154, i1 true)
  store ptr %t161, ptr %l89
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l89, !tbaa !29
  store ptr %t162, ptr %l11, !tbaa !29
  %t163 = load ptr, ptr %l11, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  br i1 %t165, label %bb34, label %bb35
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load %"compiler/source:Span", ptr %l1
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t167, %"compiler/source:Span" %t168)
  store ptr %t171, ptr %l94
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t172 = load ptr, ptr %l94, !tbaa !29
  store ptr %t172, ptr %rv
  br label %ret
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l95, !tbaa !29
  %t174 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t174, ptr %l96
  %t175 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t175, ptr %l97
  %t176 = load i32, ptr %l8
  store i32 %t176, ptr %l98
  %t177 = load ptr, ptr %l4, !tbaa !29
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  store ptr %t178, ptr %l100, !tbaa !29
  %t179 = load ptr, ptr %l6, !tbaa !29
  %t181 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t179)
  store %"compiler/source:Span" %t181, ptr %l102
  br label %bb38
bb38:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t182)
  store %"compiler/source:Span" %t184, ptr %l104
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l95, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l96
  %t187 = load %"compiler/source:Span", ptr %l97
  %t188 = load i32, ptr %l98
  %t189 = load ptr, ptr %l99, !tbaa !29
  %t190 = load ptr, ptr %l100, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l104
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t185, %"compiler/source:Span" %t186, %"compiler/source:Span" %t187, i32 %t188, ptr %t189, ptr %t190, %"compiler/source:Span" %t191, %"compiler/source:Span" %t192)
  store ptr %t193, ptr %l105
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load ptr, ptr %l105, !tbaa !29
  store ptr %t194, ptr %rv
  br label %ret
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l106, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l107
  %t197 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t197, ptr %l108
  %t198 = load i32, ptr %l8
  store i32 %t198, ptr %l109
  %t199 = load ptr, ptr %l4, !tbaa !29
  store ptr %t199, ptr %l110, !tbaa !29
  %t200 = load ptr, ptr %l5, !tbaa !29
  store ptr %t200, ptr %l111, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t201)
  store %"compiler/source:Span" %t203, ptr %l113
  br label %bb42
bb42:
  %t204 = load ptr, ptr %l7, !tbaa !29
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t204)
  store %"compiler/source:Span" %t206, ptr %l115
  br label %bb43
bb43:
  %t207 = load ptr, ptr %l106, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l107
  %t209 = load %"compiler/source:Span", ptr %l108
  %t210 = load i32, ptr %l109
  %t211 = load ptr, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l111, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l113
  %t214 = load %"compiler/source:Span", ptr %l115
  %t215 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t207, %"compiler/source:Span" %t208, %"compiler/source:Span" %t209, i32 %t210, ptr %t211, ptr %t212, %"compiler/source:Span" %t213, %"compiler/source:Span" %t214)
  store ptr %t215, ptr %l116
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t216 = load ptr, ptr %l116, !tbaa !29
  store ptr %t216, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeFor(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l61 = alloca i64
  %l64 = alloca i32
  %l69 = alloca i32
  %l72 = alloca i1
  %l73 = alloca i1
  %l81 = alloca ptr
  %l83 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l106 = alloca %"compiler/msgs:Msg"
  %l107 = alloca i64
  %l111 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"compiler/check:UnrollAsk"
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = add i32 %t4, 8
  %t9 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t2, i32 %t6)
  store %"compiler/source:Span" %t9, ptr %l18
  br label %bb1
bb1:
  %t10 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t10, ptr %l3
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/ast:ForIn", ptr %t11, i32 0, i32 3
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTry(ptr %s1)
  store %"compiler/msgs:Msg" %t18, ptr %l23
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t19 = load ptr, ptr %l21, !tbaa !29
  %t20 = load %"compiler/source:Span", ptr %l22
  %t21 = load %"compiler/msgs:Msg", ptr %l23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t19, %"compiler/source:Span" %t20, %"compiler/msgs:Msg" %t21)
  store i64 %t22, ptr %l24
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  %t25 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t23, %"compiler/source:Span" %t24, ptr %t25)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t29 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l28
  br label %bb8
bb8:
  %t30 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l4
  store i64 -1, ptr %l5, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l30
  br label %bb9
bb9:
  %t34 = load i32, ptr %l30, !tbaa !23
  store i32 %t34, ptr %l6, !tbaa !23
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  %t40 = load ptr, ptr %l7, !tbaa !29
  store ptr %t40, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t41 = load ptr, ptr %l33, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb10, label %bb11
bb10:
  %t44 = load ptr, ptr %l33, !tbaa !29
  %t45 = load i64, ptr %t44
  %t47 = icmp eq i64 %t45, 25
  store i1 %t47, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l34, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l7, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t51, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  br label %bb14
bb13:
  br label %bb24
bb14:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb16, label %bb17
bb16:
  br label %bb23
bb17:
  br label %bb18
bb18:
  %t69 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load i64, ptr %l10, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 %t70
  %t75 = load ptr, ptr %t74, !tbaa !39
  store ptr %l4, ptr %l49, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  store ptr %t75, ptr %l51, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l53
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l50, !tbaa !29
  %t83 = load ptr, ptr %l51, !tbaa !29
  %t84 = load i32, ptr %l53, !tbaa !23
  %t85 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %t82, ptr %t83, i32 %t84)
  store i64 %t85, ptr %l54
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l49, !tbaa !29
  %t87 = load i64, ptr %l54, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t86, i64 %t87)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l10, !tbaa !24
  br label %bb15
bb23:
  br label %bb34
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/ast:ForIn", ptr %t93, i32 0, i32 2
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %t92, ptr %t96, i32 %t97)
  store i64 %t101, ptr %l61
  br label %bb28
bb28:
  %t102 = load i64, ptr %l61, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = icmp sge i64 %t103, 0
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t110 = getelementptr %"compiler/ast:ForIn", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l5, !tbaa !24
  %t116 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %t107, ptr %t111, i64 %t112)
  store i32 %t116, ptr %l69
  br label %bb31
bb30:
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t117, ptr %l64, !tbaa !23
  br label %bb32
bb31:
  %t119 = load i32, ptr %l69, !tbaa !23
  store i32 %t119, ptr %l64, !tbaa !23
  br label %bb32
bb32:
  %t120 = load i32, ptr %l64, !tbaa !23
  store i32 %t120, ptr %l6, !tbaa !23
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_d826e759488f41a6_3ea05b0e10c73972)
  unreachable
bb34:
  %t122 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l4, i64 -1)
  store i1 %t122, ptr %l72
  br label %bb35
bb35:
  %t123 = load i1, ptr %l72, !tbaa !21
  br i1 %t123, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb38
bb37:
  %t124 = load i32, ptr %l6, !tbaa !23
  %t125 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t128 = icmp eq i32 %t124, %t125
  store i1 %t128, ptr %l73, !tbaa !21
  br label %bb38
bb38:
  %t130 = load i1, ptr %l73, !tbaa !21
  br i1 %t130, label %bb39, label %bb40
bb39:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load %"compiler/source:Span", ptr %l1
  %t133 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t131, %"compiler/source:Span" %t132, ptr %t133)
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb42:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  store ptr %t140, ptr %l81, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t141)
  store ptr %t143, ptr %l83
  br label %bb43
bb43:
  %t144 = load ptr, ptr %l83, !tbaa !29
  %t146 = getelementptr %"compiler/check:frame", ptr %t144, i32 0, i32 4
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/ast:ForIn", ptr %t147, i32 0, i32 2
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t151 = load ptr, ptr %l81, !tbaa !29
  %t154 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v0, ptr %v1, ptr %s0, ptr %t151, ptr %t146, ptr %t150)
  store { i64, ptr } %t154, ptr %l88
  br label %bb44
bb44:
  %t155 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t157 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t155, i64 %t156)
  %t162 = getelementptr i8, ptr %t161, i64 %t156
  call void @olang_textcopy(ptr %t162, ptr %t158, i64 %t159)
  %t163 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  store { i64, ptr } %t164, ptr %l13, !tbaa !27
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/generic:Program", ptr %t169, i32 0, i32 44
  %t172 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t175 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %s0, ptr %t171, { i64, ptr } %t172)
  store i1 %t175, ptr %l94
  br label %bb45
bb45:
  %t176 = load i1, ptr %l94, !tbaa !21
  br i1 %t176, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l95, !tbaa !29
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t180 = getelementptr %"compiler/ast:ForIn", ptr %t178, i32 0, i32 2
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t181)
  store %"compiler/source:Span" %t183, ptr %l98
  br label %bb48
bb47:
  br label %bb56
bb48:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 44
  %t190 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t193 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t189, { i64, ptr } %t190)
  %t194 = extractvalue { i32, { i64, ptr } } %t193, 1
  %t195 = extractvalue { i32, { i64, ptr } } %t193, 0
  store i32 %t195, ptr %l105
  %t196 = icmp ne i32 %t195, 0
  br i1 %t196, label %bb50, label %ok.197, !prof !99
ok.197:
  store { i64, ptr } %t194, ptr %l104
  br label %bb49
bb49:
  %t198 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t198, ptr %l99, !tbaa !27
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb52
bb52:
  %t199 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t200 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForUnknown(ptr %v0, ptr %s9, { i64, ptr } %t199)
  store %"compiler/msgs:Msg" %t200, ptr %l106
  br label %bb53
bb53:
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l98
  %t203 = load %"compiler/msgs:Msg", ptr %l106
  %t204 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t201, %"compiler/source:Span" %t202, %"compiler/msgs:Msg" %t203)
  store i64 %t204, ptr %l107
  br label %bb54
bb54:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  %t207 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t205, %"compiler/source:Span" %t206, ptr %t207)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 43
  %t217 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t220 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H09835701baa5b197f16fe6901ed0f7b4(ptr %v0, ptr %s0, ptr %v0, ptr %t216, { i64, ptr } %t217)
  %t221 = extractvalue { i32, { i64, ptr } } %t220, 1
  %t222 = extractvalue { i32, { i64, ptr } } %t220, 0
  store i32 %t222, ptr %l117
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb58, label %ok.224, !prof !99
ok.224:
  store { i64, ptr } %t221, ptr %l116
  br label %bb57
bb57:
  %t225 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t225, ptr %l111, !tbaa !27
  br label %bb63
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/check:Checker", ptr %t226, i32 0, i32 107
  store ptr %t228, ptr %l119, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = extractvalue { i64, ptr } %t229, 0
  %t233 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t231, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = extractvalue { i64, ptr } %t235, 1
  %t239 = mul i64 %t237, 1
  %t240 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t238, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l122, !tbaa !27
  %t244 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %v0, ptr %l4)
  store { i64, ptr } %t244, ptr %l124
  br label %bb60
bb60:
  %t245 = load i64, ptr %l5, !tbaa !24
  %t246 = load i32, ptr %l6, !tbaa !23
  %t247 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t251 = call %"compiler/check:UnrollAsk" @compiler_2fcheck_3aUnrollAsk_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t247, { i64, ptr } %t248, i64 %t245, i32 %t246)
  store %"compiler/check:UnrollAsk" %t251, ptr %l127
  br label %bb61
bb61:
  %t252 = load ptr, ptr %l119, !tbaa !29
  %t253 = load %"compiler/check:UnrollAsk", ptr %l127
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ePush_He90a5e781e5223c39ec692b3f1e8f929(ptr %v0, ptr %v0, ptr %t252, %"compiler/check:UnrollAsk" %t253)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb63:
  %t254 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t254, ptr %l14, !tbaa !27
  %t255 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = load i64, ptr @G_2ecompiler_2fcheck_2eMaxUnroll, !tbaa !24
  %t261 = icmp sgt i64 %t257, %t258
  br i1 %t261, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l132, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t264, ptr %l133
  %t265 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = load i64, ptr @G_2ecompiler_2fcheck_2eMaxUnroll, !tbaa !24
  %t271 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTooMany(ptr %s12, i64 %t267, i64 %t268)
  store %"compiler/msgs:Msg" %t271, ptr %l137
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t272 = load ptr, ptr %l132, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l133
  %t274 = load %"compiler/msgs:Msg", ptr %l137
  %t275 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t272, %"compiler/source:Span" %t273, %"compiler/msgs:Msg" %t274)
  store i64 %t275, ptr %l138
  br label %bb67
bb67:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  %t278 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %t276, %"compiler/source:Span" %t277, ptr %t278)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb69:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l1
  %t284 = load ptr, ptr %l2, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t286 = load i32, ptr %l6, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v0, ptr %t282, %"compiler/source:Span" %t283, ptr %t284, { i64, ptr } %t285, i32 %t286)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l52 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l60 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l64 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i1
  %l96 = alloca ptr
  %l97 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l148 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i64
  %l163 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca i64
  %l173 = alloca %"compiler/source:Span"
  %l175 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca i1
  %l185 = alloca ptr
  %l186 = alloca i1
  %l200 = alloca ptr
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb93
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l35, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load ptr, ptr %l7, !tbaa !29
  store ptr %t23, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t24 = load ptr, ptr %l38, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l38, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l39, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l39, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l52, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l12, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 29
  store ptr %t65, ptr %l56, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load i32, ptr %l12, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t66, i64 %t69)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, ptr %l60
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l56, !tbaa !29
  %t74 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l60
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %t73, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t74)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load i32, ptr %l12, !tbaa !23
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %t75, i64 %t76, i32 %t77)
  store i64 %t81, ptr %l64
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  br label %bb91
bb19:
  %t86 = load ptr, ptr %l7, !tbaa !29
  store ptr %t86, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t87 = load ptr, ptr %l67, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load ptr, ptr %l67, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l68, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l68, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr { i64, [6 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l13
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = getelementptr { i64, [6 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t103, i32 0, i32 1
  %t105 = load %"compiler/source:Span", ptr %t104
  store %"compiler/source:Span" %t105, ptr %l14
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr { i64, [6 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t109, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110
  store { i64, ptr } %t111, ptr %l15, !tbaa !27
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr { i64, [6 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t115, i32 0, i32 3
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l16, !tbaa !29
  br label %bb24
bb23:
  br label %bb30
bb24:
  %t119 = load i64, ptr %l1, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 0
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/load:Loader", ptr %t126, i32 0, i32 7
  %t129 = load i64, ptr %t128, !tbaa !24
  %t132 = icmp eq i64 %t119, %t129
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load %"compiler/source:Span", ptr %l14
  %t137 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestTarget(ptr %v0, ptr %v1, ptr %t134, i64 %t135, %"compiler/source:Span" %t136, ptr %t137)
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load %"compiler/source:Span", ptr %l13
  %t145 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t146 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %t142, i64 %t143, %"compiler/source:Span" %t144, { i64, ptr } %t145, i64 %t146)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t152 = load i64, ptr %l3, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l3, !tbaa !24
  br label %bb91
bb30:
  %t156 = load ptr, ptr %l7, !tbaa !29
  store ptr %t156, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t157 = load ptr, ptr %l96, !tbaa !29
  %t158 = icmp ne ptr %t157, null
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t160 = load ptr, ptr %l96, !tbaa !29
  %t161 = load i64, ptr %t160
  %t163 = icmp eq i64 %t161, 2
  store i1 %t163, ptr %l97, !tbaa !21
  br label %bb32
bb32:
  %t164 = load i1, ptr %l97, !tbaa !21
  br i1 %t164, label %bb33, label %bb34
bb33:
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t167 = getelementptr { i64, [6 x i64] }, ptr %t165, i32 0, i32 1
  %t168 = getelementptr { %"compiler/source:Span", ptr }, ptr %t167, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l17
  %t171 = load ptr, ptr %l7, !tbaa !29
  %t173 = getelementptr { i64, [6 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr }, ptr %t173, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l18, !tbaa !29
  br label %bb35
bb34:
  br label %bb42
bb35:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t179 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %t177, i64 %t178, ptr %t179)
  br label %bb36
bb36:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i64, ptr %l1, !tbaa !24
  %t185 = load %"compiler/source:Span", ptr %l17
  %t186 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %t183, i64 %t184, %"compiler/source:Span" %t185, ptr %t186)
  br label %bb37
bb37:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  %t194 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %t192, i64 %t193, ptr %t194)
  br label %bb38
bb38:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t201 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %t199, i64 %t200, ptr %t201)
  br label %bb39
bb39:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load i64, ptr %l1, !tbaa !24
  %t208 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %t206, i64 %t207, ptr %t208)
  br label %bb40
bb40:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load i64, ptr %l1, !tbaa !24
  %t215 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %t213, i64 %t214, ptr %t215)
  br label %bb41
bb41:
  br label %bb91
bb42:
  %t220 = load ptr, ptr %l7, !tbaa !29
  store ptr %t220, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t221 = load ptr, ptr %l128, !tbaa !29
  %t222 = icmp ne ptr %t221, null
  br i1 %t222, label %bb43, label %bb44
bb43:
  %t224 = load ptr, ptr %l128, !tbaa !29
  %t225 = load i64, ptr %t224
  %t227 = icmp eq i64 %t225, 0
  store i1 %t227, ptr %l129, !tbaa !21
  br label %bb44
bb44:
  %t228 = load i1, ptr %l129, !tbaa !21
  br i1 %t228, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i64, ptr %l1, !tbaa !24
  %t231 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %t229, i64 %t230, ptr %t231)
  br label %bb48
bb48:
  br label %bb91
bb49:
  %t235 = load ptr, ptr %l7, !tbaa !29
  store ptr %t235, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t236 = load ptr, ptr %l135, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb50, label %bb51
bb50:
  %t239 = load ptr, ptr %l135, !tbaa !29
  %t240 = load i64, ptr %t239
  %t242 = icmp eq i64 %t240, 9
  store i1 %t242, ptr %l136, !tbaa !21
  br label %bb51
bb51:
  %t243 = load i1, ptr %l136, !tbaa !21
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t244 = load ptr, ptr %l7, !tbaa !29
  %t246 = getelementptr { i64, [6 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t246, i32 0, i32 0
  %t248 = load %"compiler/source:Span", ptr %t247
  store %"compiler/source:Span" %t248, ptr %l19
  %t250 = load ptr, ptr %l7, !tbaa !29
  %t252 = getelementptr { i64, [6 x i64] }, ptr %t250, i32 0, i32 1
  %t253 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t252, i32 0, i32 1
  %t254 = load ptr, ptr %t253
  store ptr %t254, ptr %l20, !tbaa !29
  %t256 = load ptr, ptr %l7, !tbaa !29
  %t258 = getelementptr { i64, [6 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t258, i32 0, i32 2
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l21, !tbaa !29
  br label %bb54
bb53:
  br label %bb58
bb54:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i64, ptr %l1, !tbaa !24
  %t264 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t262, i64 -1, i64 %t263, i32 %t264, i32 0)
  store ptr %t268, ptr %l148
  br label %bb55
bb55:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l1, !tbaa !24
  %t271 = load %"compiler/source:Span", ptr %l19
  %t272 = load ptr, ptr %l20, !tbaa !29
  %t273 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v1, ptr %t269, i64 %t270, %"compiler/source:Span" %t271, ptr %t272, ptr %t273)
  br label %bb56
bb56:
  %t279 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t279)
  br label %bb57
bb57:
  br label %bb91
bb58:
  %t281 = load ptr, ptr %l7, !tbaa !29
  store ptr %t281, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t282 = load ptr, ptr %l155, !tbaa !29
  %t283 = icmp ne ptr %t282, null
  br i1 %t283, label %bb59, label %bb60
bb59:
  %t285 = load ptr, ptr %l155, !tbaa !29
  %t286 = load i64, ptr %t285
  %t288 = icmp eq i64 %t286, 7
  store i1 %t288, ptr %l156, !tbaa !21
  br label %bb60
bb60:
  %t289 = load i1, ptr %l156, !tbaa !21
  br i1 %t289, label %bb61, label %bb62
bb61:
  %t290 = load ptr, ptr %l7, !tbaa !29
  %t292 = getelementptr { i64, [6 x i64] }, ptr %t290, i32 0, i32 1
  %t293 = getelementptr { %"compiler/source:Span", ptr }, ptr %t292, i32 0, i32 1
  %t294 = load ptr, ptr %t293
  store ptr %t294, ptr %l22, !tbaa !29
  br label %bb63
bb62:
  br label %bb70
bb63:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l161, !tbaa !29
  %t297 = load i64, ptr %l1, !tbaa !24
  store i64 %t297, ptr %l162, !tbaa !24
  %t298 = load ptr, ptr %l22, !tbaa !29
  store ptr %t298, ptr %l163, !tbaa !29
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = getelementptr %"compiler/generic:Program", ptr %t302, i32 0, i32 0
  %t305 = load ptr, ptr %t304, !tbaa !29
  store ptr %t305, ptr %l166, !tbaa !29
  %t306 = load i64, ptr %l1, !tbaa !24
  store i64 %t306, ptr %l167, !tbaa !24
  %t307 = load ptr, ptr %l22, !tbaa !29
  %t309 = getelementptr %"compiler/ast:TopIf", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = icmp eq ptr %t310, null
  br i1 %t312, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f)
  unreachable
bb65:
  br label %bb66
bb66:
  %t314 = load ptr, ptr %l22, !tbaa !29
  %t316 = getelementptr %"compiler/ast:TopIf", ptr %t314, i32 0, i32 0
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l173
  br label %bb67
bb67:
  %t320 = getelementptr %"compiler/source:Span", ptr %l173, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  %t322 = load ptr, ptr %l166, !tbaa !29
  %t323 = load i64, ptr %l167, !tbaa !24
  %t325 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t322, i64 %t323, i32 %t321)
  store i64 %t325, ptr %l175
  br label %bb68
bb68:
  %t326 = load ptr, ptr %l161, !tbaa !29
  %t327 = load i64, ptr %l162, !tbaa !24
  %t328 = load ptr, ptr %l163, !tbaa !29
  %t329 = load i64, ptr %l175, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t326, i64 %t327, ptr %t328, i64 %t329, i64 0)
  br label %bb69
bb69:
  br label %bb91
bb70:
  %t330 = load ptr, ptr %l7, !tbaa !29
  store ptr %t330, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t331 = load ptr, ptr %l176, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb71, label %bb72
bb71:
  %t334 = load ptr, ptr %l176, !tbaa !29
  %t335 = load i64, ptr %t334
  %t337 = icmp eq i64 %t335, 10
  store i1 %t337, ptr %l177, !tbaa !21
  br label %bb72
bb72:
  %t338 = load i1, ptr %l177, !tbaa !21
  br i1 %t338, label %bb73, label %bb74
bb73:
  %t339 = load ptr, ptr %l7, !tbaa !29
  %t341 = getelementptr { i64, [6 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t341, i32 0, i32 2
  %t343 = load { i64, ptr }, ptr %t342
  store { i64, ptr } %t343, ptr %l23, !tbaa !27
  br label %bb75
bb74:
  br label %bb77
bb75:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l1, !tbaa !24
  %t347 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t345, i64 %t346, { i64, ptr } %t347)
  br label %bb76
bb76:
  br label %bb91
bb77:
  %t351 = load ptr, ptr %l7, !tbaa !29
  store ptr %t351, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t352 = load ptr, ptr %l185, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb78, label %bb79
bb78:
  %t355 = load ptr, ptr %l185, !tbaa !29
  %t356 = load i64, ptr %t355
  %t358 = icmp eq i64 %t356, 5
  store i1 %t358, ptr %l186, !tbaa !21
  br label %bb79
bb79:
  %t359 = load i1, ptr %l186, !tbaa !21
  br i1 %t359, label %bb80, label %bb81
bb80:
  %t360 = load ptr, ptr %l7, !tbaa !29
  %t362 = getelementptr { i64, [6 x i64] }, ptr %t360, i32 0, i32 1
  %t363 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t362, i32 0, i32 0
  %t364 = load %"compiler/source:Span", ptr %t363
  store %"compiler/source:Span" %t364, ptr %l24
  %t366 = load ptr, ptr %l7, !tbaa !29
  %t368 = getelementptr { i64, [6 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t368, i32 0, i32 1
  %t370 = load i32, ptr %t369
  store i32 %t370, ptr %l25, !tbaa !23
  %t372 = load ptr, ptr %l7, !tbaa !29
  %t374 = getelementptr { i64, [6 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t374, i32 0, i32 2
  %t376 = load { i64, ptr }, ptr %t375
  store { i64, ptr } %t376, ptr %l26, !tbaa !27
  %t378 = load ptr, ptr %l7, !tbaa !29
  %t380 = getelementptr { i64, [6 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t380, i32 0, i32 3
  %t382 = load { i64, ptr }, ptr %t381
  store { i64, ptr } %t382, ptr %l27, !tbaa !27
  br label %bb82
bb81:
  br label %bb86
bb82:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i64, ptr %l1, !tbaa !24
  %t386 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t384, i64 -1, i64 %t385, i32 %t386, i32 0)
  store ptr %t390, ptr %l200
  br label %bb83
bb83:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load i64, ptr %l1, !tbaa !24
  %t393 = load %"compiler/source:Span", ptr %l24
  %t394 = load i32, ptr %l25, !tbaa !23
  %t395 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorDeclRules(ptr %v0, ptr %v1, ptr %v1, ptr %t391, i64 %t392, %"compiler/source:Span" %t393, i32 %t394, { i64, ptr } %t395, { i64, ptr } %t396)
  br label %bb84
bb84:
  %t403 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t403)
  br label %bb85
bb85:
  br label %bb91
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_575e4285282f1c6b_a969c68061cd7c57)
  unreachable
bb91:
  br label %bb92
bb92:
  %t405 = load i64, ptr %l5, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l5, !tbaa !24
  br label %bb1
bb93:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edispatchChecks(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4, i32 %a5, %"compiler/typed:ContractInfo" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca %"compiler/typed:ContractInfo"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %lp33 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l51 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l63 = alloca i64
  %l64 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l79 = alloca i32
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l111 = alloca i64
  %l112 = alloca i32
  %l113 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l117 = alloca ptr
  %l120 = alloca i32
  %l125 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l136 = alloca ptr
  %l140 = alloca %"compiler/typed:Try"
  %l149 = alloca ptr
  %l154 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i32
  %l167 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l178 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l191 = alloca i64
  %l197 = alloca i64
  %l200 = alloca i64
  %l219 = alloca ptr
  %l224 = alloca ptr
  %l227 = alloca %"compiler/source:Span"
  %l228 = alloca i32
  %l229 = alloca ptr
  %l233 = alloca { i64, ptr }
  %l236 = alloca %"compiler/typed:Call"
  %l242 = alloca i1
  %l251 = alloca %"compiler/source:Span"
  %l252 = alloca i32
  %l256 = alloca { i64, ptr }
  %l257 = alloca %"compiler/typed:Seq"
  %l261 = alloca %"compiler/source:Span"
  %l262 = alloca i32
  %l266 = alloca { i64, ptr }
  %l268 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t53 = alloca { i64, [2 x i64] }, align 8
  %t72 = alloca { i64, [3 x i64] }, align 8
  %t224 = alloca { i64, [5 x i64] }, align 8
  %t279 = alloca { i64, [5 x i64] }, align 8
  %t295 = alloca { i64, [3 x i64] }, align 8
  %t441 = alloca { i64, [2 x i64] }, align 8
  %t452 = alloca { i64, [5 x i64] }, align 8
  %t481 = alloca { i64, [3 x i64] }, align 8
  %t506 = alloca { i64, [5 x i64] }, align 8
  %t534 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store %"compiler/typed:ContractInfo" %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l35
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l35, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 37
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l38
  br label %bb2
bb2:
  %t10 = load i64, ptr %l38, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l39
  br label %bb3
bb3:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l9
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  store i64 %t17, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb5, label %bb6
bb5:
  br label %bb27
bb6:
  br label %bb7
bb7:
  %t27 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t27, ptr %l47, !tbaa !27
  %t28 = load i64, ptr %l11, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  store ptr %t33, ptr %l13, !tbaa !29
  %t35 = load ptr, ptr %l13, !tbaa !29
  store ptr %t35, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t36 = load ptr, ptr %l50, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb8, label %bb9
bb8:
  %t39 = load ptr, ptr %l50, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 0
  store i1 %t42, ptr %l51, !tbaa !21
  br label %bb9
bb9:
  %t43 = load i1, ptr %l51, !tbaa !21
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb14
bb12:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 -1)
  br label %bb13
bb13:
  br label %bb25
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l55, !tbaa !29
  %t46 = load ptr, ptr %l13, !tbaa !29
  %t48 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t46)
  store %"compiler/source:Span" %t48, ptr %l57
  br label %bb18
bb18:
  %t49 = load ptr, ptr %l13, !tbaa !29
  %t52 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t49)
  store i32 %t52, ptr %l60
  br label %bb19
bb19:
  store { i64, [2 x i64] } zeroinitializer, ptr %t53
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t53, i32 0, i32 0
  store i64 0, ptr %t54
  %t55 = load { i64, [2 x i64] }, ptr %t53
  %t56 = load ptr, ptr %l55, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l57
  %t58 = load i32, ptr %l60, !tbaa !23
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t56, i32 0, %"compiler/source:Span" %t57, i32 %t58, i32 2, { i64, [2 x i64] } %t55)
  store i64 %t61, ptr %l63
  br label %bb20
bb20:
  %t62 = load i64, ptr %l63, !tbaa !24
  store i64 %t62, ptr %l14, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l64, !tbaa !29
  %t64 = load ptr, ptr %l13, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t64)
  store %"compiler/source:Span" %t66, ptr %l66
  br label %bb21
bb21:
  %t67 = load i64, ptr %l14, !tbaa !24
  %t69 = trunc i64 %t67 to i32
  %t71 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 0
  store i64 0, ptr %t73
  %t74 = load %"compiler/source:Span", ptr %l66
  %t75 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t74, 0
  %t77 = insertvalue { %"compiler/source:Span", i32, ptr } %t75, i32 %t69, 1
  %t79 = insertvalue { %"compiler/source:Span", i32, ptr } %t77, ptr %t71, 2
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t72, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t79, ptr %t80
  %t81 = load { i64, [3 x i64] }, ptr %t72
  %t83 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t81, ptr %t83
  %t84 = load ptr, ptr %l64, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t84, ptr %t83)
  br label %bb22
bb22:
  %t86 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t86)
  br label %bb23
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_27e3ab5b7d984c5a_74f0959f23b09f6e)
  unreachable
bb25:
  br label %bb26
bb26:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l11, !tbaa !24
  br label %bb4
bb27:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t96, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i32 %t98, ptr %l79
  br label %bb28
bb28:
  %t99 = load i32, ptr %l79, !tbaa !23
  store i32 %t99, ptr %l15, !tbaa !23
  store i64 0, ptr %l16, !tbaa !24
  %t100 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t102 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t100)
  store i64 %t102, ptr %l81
  br label %bb29
bb29:
  %t103 = load i64, ptr %l81, !tbaa !24
  store i64 %t103, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t104 = load i64, ptr %l17, !tbaa !24
  %t105 = load i64, ptr %l16, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t110 = load i64, ptr %l18, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb35
bb32:
  %t114 = load i64, ptr %l17, !tbaa !24
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l18, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l18, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l88, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l88, !tbaa !24
  br label %bb34
bb34:
  %t130 = load i64, ptr %l88, !tbaa !24
  store i64 %t130, ptr %l85, !tbaa !24
  br label %bb35
bb35:
  %t131 = load i64, ptr %l85, !tbaa !24
  store i64 %t131, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l20, !tbaa !24
  %t133 = load i64, ptr %l19, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb68
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l16, !tbaa !24
  %t141 = load i64, ptr %l20, !tbaa !24
  %t142 = load i64, ptr %l18, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  store i64 %t148, ptr %l21, !tbaa !24
  %t150 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 2
  %t151 = load i64, ptr %l21, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l108
  br label %bb40
bb40:
  %t155 = load i64, ptr %l108, !tbaa !24
  store i64 %t155, ptr %l22, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l109, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l110
  %t158 = load i64, ptr %l22, !tbaa !24
  store i64 %t158, ptr %l111, !tbaa !24
  %t159 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t159, ptr %l112, !tbaa !23
  %t160 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t160, ptr %l113, !tbaa !27
  store ptr %l9, ptr %l114, !tbaa !29
  %t161 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t161, ptr %l115
  br label %bb41
bb41:
  %t162 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l115
  %t163 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %t163
  %t164 = load ptr, ptr %l109, !tbaa !29
  %t165 = load %"compiler/source:Span", ptr %l110
  %t166 = load i64, ptr %l111, !tbaa !24
  %t167 = load i32, ptr %l112, !tbaa !23
  %t168 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t169 = load ptr, ptr %l114, !tbaa !29
  %t171 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %s0, ptr %s7, ptr %t164, %"compiler/source:Span" %t165, i64 %t166, i32 %t167, { i64, ptr } %t168, ptr %t169, ptr %t163)
  store ptr %t171, ptr %l117
  br label %bb42
bb42:
  %t172 = load ptr, ptr %l117, !tbaa !29
  store ptr %t172, ptr %l23, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l22, !tbaa !24
  %t177 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %t173, i64 %t174)
  store i32 %t177, ptr %l120
  br label %bb43
bb43:
  %t178 = load i32, ptr %l120, !tbaa !23
  store i32 %t178, ptr %l24, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l24, !tbaa !23
  %t188 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t184, i32 %t185)
  store { i64, ptr } %t188, ptr %l125
  br label %bb44
bb44:
  %t189 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t192 = icmp sgt i64 %t190, 0
  br i1 %t192, label %bb45, label %bb46
bb45:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load i32, ptr %l24, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t194, i32 %t195)
  br label %bb47
bb46:
  br label %bb53
bb47:
  %t198 = load ptr, ptr %l7, !tbaa !29
  store ptr %t198, ptr %l130, !tbaa !29
  %t199 = load ptr, ptr %l130, !tbaa !29
  %t200 = getelementptr %"compiler/check:frame", ptr %t199, i32 0, i32 16
  %t201 = load i64, ptr %t200, !tbaa !24
  %t203 = add i64 %t201, 1
  %t205 = load ptr, ptr %l130, !tbaa !29
  %t206 = getelementptr %"compiler/check:frame", ptr %t205, i32 0, i32 16
  store i64 %t203, ptr %t206, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t207, ptr %l133
  %t208 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t208, ptr %l134, !tbaa !23
  %t209 = load ptr, ptr %l23, !tbaa !29
  store ptr %t209, ptr %l136, !tbaa !29
  %t211 = icmp sge i64 0, 0
  br i1 %t211, label %bb48, label %bb49
bb48:
  %t213 = icmp sle i64 0, 1152921504606846975
  br i1 %t213, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770)
  unreachable
bb50:
  %t215 = mul i64 0, 8
  %t216 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 0, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t219 = load ptr, ptr %l136, !tbaa !29
  %t221 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t219, { i64, ptr } %t218, i1 false, i1 false, i1 true)
  store %"compiler/typed:Try" %t221, ptr %l140
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770)
  unreachable
bb52:
  %t222 = load %"compiler/typed:Try", ptr %l140
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t222, ptr %t223
  store { i64, [5 x i64] } zeroinitializer, ptr %t224
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 0
  store i64 14, ptr %t225
  %t226 = load %"compiler/source:Span", ptr %l133
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t226, 0
  %t228 = load i32, ptr %l134, !tbaa !23
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, i32 %t228, 1
  %t231 = insertvalue { %"compiler/source:Span", i32, ptr } %t229, ptr %t223, 2
  %t232 = getelementptr { i64, [5 x i64] }, ptr %t224, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t231, ptr %t232
  %t233 = load { i64, [5 x i64] }, ptr %t224
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t233, ptr %t235
  store ptr %t235, ptr %l23, !tbaa !29
  br label %bb53
bb53:
  %t237 = load i32, ptr %l15, !tbaa !23
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t241 = icmp ne i32 %t237, %t238
  br i1 %t241, label %bb54, label %bb55
bb54:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t243, i32 %t244)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t247 = load ptr, ptr %l7, !tbaa !29
  store ptr %t247, ptr %l149, !tbaa !29
  %t248 = load ptr, ptr %l149, !tbaa !29
  %t249 = getelementptr %"compiler/check:frame", ptr %t248, i32 0, i32 16
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = add i64 %t250, 1
  %t254 = load ptr, ptr %l149, !tbaa !29
  %t255 = getelementptr %"compiler/check:frame", ptr %t254, i32 0, i32 16
  store i64 %t252, ptr %t255, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 36
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t258)
  store i64 %t260, ptr %l154
  br label %bb58
bb58:
  %t261 = load i64, ptr %l154, !tbaa !24
  store i64 %t261, ptr %l25, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/check:Checker", ptr %t262, i32 0, i32 36
  %t265 = load ptr, ptr %l23, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t264, ptr %t265)
  br label %bb59
bb59:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l158, !tbaa !29
  %t269 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t269, ptr %l159
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l160
  %t271 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t271, ptr %l161, !tbaa !23
  store i32 37, ptr %l162
  store i32 2, ptr %l163
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 36
  %t275 = load i64, ptr %l25, !tbaa !24
  %t278 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t274, i64 %t275)
  store { i64, ptr } %t278, ptr %l167
  br label %bb60
bb60:
  store { i64, [5 x i64] } zeroinitializer, ptr %t279
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 0
  store i64 9, ptr %t280
  %t281 = load %"compiler/source:Span", ptr %l160
  %t282 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t281, 0
  %t283 = load i32, ptr %l161, !tbaa !23
  %t284 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t282, i32 %t283, 1
  %t285 = load i32, ptr %l162
  %t286 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t284, i32 %t285, 2
  %t287 = load i32, ptr %l163
  %t288 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t286, i32 %t287, 3
  %t289 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t290 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t288, { i64, ptr } %t289, 4
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t279, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t290, ptr %t291
  %t292 = load { i64, [5 x i64] }, ptr %t279
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t292, ptr %t294
  store { i64, [3 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 0
  store i64 2, ptr %t296
  %t297 = load %"compiler/source:Span", ptr %l159
  %t298 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t297, 0
  %t300 = insertvalue { %"compiler/source:Span", ptr } %t298, ptr %t294, 1
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t295, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t300, ptr %t301
  %t302 = load { i64, [3 x i64] }, ptr %t295
  %t304 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t302, ptr %t304
  %t305 = load ptr, ptr %l158, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t305, ptr %t304)
  br label %bb61
bb61:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t307)
  store ptr %t309, ptr %l173
  br label %bb62
bb62:
  %t310 = load ptr, ptr %l173, !tbaa !29
  %t312 = getelementptr %"compiler/typed:Body", ptr %t310, i32 0, i32 13
  %t313 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t314 = load i32, ptr %t313, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t312, i32 %t314)
  br label %bb63
bb63:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t317)
  store ptr %t319, ptr %l178
  br label %bb64
bb64:
  %t320 = load ptr, ptr %l178, !tbaa !29
  %t322 = getelementptr %"compiler/typed:Body", ptr %t320, i32 0, i32 14
  store ptr %t322, ptr %l180, !tbaa !29
  %t323 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  store { i64, ptr } %t324, ptr %l181, !tbaa !27
  %t325 = getelementptr %"compiler/typed:ContractInfo", ptr %l6, i32 0, i32 4
  %t326 = load i64, ptr %l21, !tbaa !24
  %t329 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s7, ptr %t325, i64 %t326)
  store { i64, ptr } %t329, ptr %l184
  br label %bb65
bb65:
  %t330 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t334 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t335 = add i64 %t332, %t334
  %t336 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t339)
  call void @olang_textcopy(ptr %t340, ptr %t331, i64 %t332)
  %t341 = getelementptr i8, ptr %t340, i64 %t332
  call void @olang_textcopy(ptr %t341, ptr %t333, i64 %t334)
  %t342 = getelementptr i8, ptr %t341, i64 %t334
  call void @olang_textcopy(ptr %t342, ptr %t337, i64 %t338)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t340, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = extractvalue { i64, ptr } %t344, 1
  %t348 = mul i64 %t346, 1
  %t349 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t348)
  call void @llvm.memcpy.p0.p0.i64(ptr %t349, ptr %t347, i64 %t348, i1 false)
  %t350 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t351 = insertvalue { i64, ptr } %t350, ptr %t349, 1
  %t352 = load ptr, ptr %l180, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t352, { i64, ptr } %t351)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s7)
  br label %bb67
bb67:
  %t354 = load i64, ptr %l20, !tbaa !24
  %t356 = add i64 %t354, 1
  store i64 %t356, ptr %l20, !tbaa !24
  br label %bb36
bb68:
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = getelementptr %"compiler/check:Checker", ptr %t358, i32 0, i32 36
  %t362 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t360)
  store i64 %t362, ptr %l191
  br label %bb69
bb69:
  %t363 = load i64, ptr %l191, !tbaa !24
  store i64 %t363, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  %t364 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t364, 0
  store i64 %t366, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t368 = load i64, ptr %l28, !tbaa !24
  %t369 = load i64, ptr %l27, !tbaa !24
  %t372 = icmp sgt i64 %t368, %t369
  br i1 %t372, label %bb70, label %bb71
bb70:
  %t374 = load i64, ptr %l29, !tbaa !24
  %t376 = icmp sgt i64 %t374, 0
  br i1 %t376, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb75
bb72:
  %t378 = load i64, ptr %l28, !tbaa !24
  %t379 = load i64, ptr %l27, !tbaa !24
  %t382 = sub i64 %t378, %t379
  %t383 = load i64, ptr %l29, !tbaa !24
  %t386 = add i64 %t382, %t383
  %t388 = sub i64 %t386, 1
  %t389 = load i64, ptr %l29, !tbaa !24
  %t392 = sdiv i64 %t388, %t389
  store i64 %t392, ptr %l200, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb74
bb74:
  %t394 = load i64, ptr %l200, !tbaa !24
  store i64 %t394, ptr %l197, !tbaa !24
  br label %bb75
bb75:
  %t395 = load i64, ptr %l197, !tbaa !24
  store i64 %t395, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb76
bb76:
  %t396 = load i64, ptr %l31, !tbaa !24
  %t397 = load i64, ptr %l30, !tbaa !24
  %t400 = icmp slt i64 %t396, %t397
  %t402 = xor i1 %t400, true
  br i1 %t402, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  br label %bb79
bb79:
  %t404 = load i64, ptr %l27, !tbaa !24
  %t405 = load i64, ptr %l31, !tbaa !24
  %t406 = load i64, ptr %l29, !tbaa !24
  %t409 = mul i64 %t405, %t406
  %t412 = add i64 %t404, %t409
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t416 = getelementptr %"compiler/check:Checker", ptr %t414, i32 0, i32 36
  store ptr %t416, ptr %l219, !tbaa !29
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t424 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %s0, ptr %t417, { i64, ptr } %t418, ptr %l9, i64 %t412)
  store ptr %t424, ptr %l224
  br label %bb80
bb80:
  %t425 = load ptr, ptr %l219, !tbaa !29
  %t426 = load ptr, ptr %l224, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t425, ptr %t426)
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t427 = load i64, ptr %l31, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l31, !tbaa !24
  br label %bb76
bb83:
  %t431 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t431, ptr %l227
  %t432 = load i32, ptr %l2, !tbaa !23
  store i32 %t432, ptr %l228, !tbaa !23
  store ptr %a3, ptr %l229, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t434, i32 0, i32 36
  %t437 = load i64, ptr %l26, !tbaa !24
  %t440 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t436, i64 %t437)
  store { i64, ptr } %t440, ptr %l233
  br label %bb84
bb84:
  store { i64, [2 x i64] } zeroinitializer, ptr %t441
  %t442 = getelementptr { i64, [2 x i64] }, ptr %t441, i32 0, i32 0
  store i64 0, ptr %t442
  %t443 = load { i64, [2 x i64] }, ptr %t441
  %t445 = load ptr, ptr %l229, !tbaa !29
  %t446 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t449 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t445, { i64, ptr } %t446, { i64, [2 x i64] } %t443, i32 %a5, i1 false, i1 false)
  store %"compiler/typed:Call" %t449, ptr %l236
  br label %bb85
bb85:
  %t450 = load %"compiler/typed:Call", ptr %l236
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t450, ptr %t451
  store { i64, [5 x i64] } zeroinitializer, ptr %t452
  %t453 = getelementptr { i64, [5 x i64] }, ptr %t452, i32 0, i32 0
  store i64 6, ptr %t453
  %t454 = load %"compiler/source:Span", ptr %l227
  %t455 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t454, 0
  %t456 = load i32, ptr %l228, !tbaa !23
  %t457 = insertvalue { %"compiler/source:Span", i32, ptr } %t455, i32 %t456, 1
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr } %t457, ptr %t451, 2
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t452, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t459, ptr %t460
  %t461 = load { i64, [5 x i64] }, ptr %t452
  %t462 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t462, ptr %lp33
  %t464 = load ptr, ptr %lp33
  store { i64, [5 x i64] } %t461, ptr %t464
  %t465 = load i32, ptr %l2, !tbaa !23
  %t466 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t469 = icmp eq i32 %t465, %t466
  br i1 %t469, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l242, !tbaa !21
  br label %bb88
bb87:
  %t471 = load i32, ptr %l2, !tbaa !23
  %t472 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t475 = icmp eq i32 %t471, %t472
  store i1 %t475, ptr %l242, !tbaa !21
  br label %bb88
bb88:
  %t477 = load i1, ptr %l242, !tbaa !21
  br i1 %t477, label %bb89, label %bb90
bb89:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l1
  %t480 = load ptr, ptr %lp33
  store { i64, [3 x i64] } zeroinitializer, ptr %t481
  %t482 = getelementptr { i64, [3 x i64] }, ptr %t481, i32 0, i32 0
  store i64 2, ptr %t482
  %t484 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t479, 0
  %t486 = insertvalue { %"compiler/source:Span", ptr } %t484, ptr %t480, 1
  %t487 = getelementptr { i64, [3 x i64] }, ptr %t481, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t486, ptr %t487
  %t488 = load { i64, [3 x i64] }, ptr %t481
  %t490 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t488, ptr %t490
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t478, ptr %t490)
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t493 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t493, ptr %l251
  %t494 = load i32, ptr %l2, !tbaa !23
  store i32 %t494, ptr %l252, !tbaa !23
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 37
  %t498 = load i64, ptr %l8, !tbaa !24
  %t501 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t497, i64 %t498)
  store { i64, ptr } %t501, ptr %l256
  br label %bb92
bb92:
  %t502 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t503 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t502, ptr null)
  store %"compiler/typed:Seq" %t503, ptr %l257
  br label %bb93
bb93:
  %t504 = load %"compiler/typed:Seq", ptr %l257
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t504, ptr %t505
  store { i64, [5 x i64] } zeroinitializer, ptr %t506
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 0
  store i64 12, ptr %t507
  %t508 = load %"compiler/source:Span", ptr %l251
  %t509 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t508, 0
  %t510 = load i32, ptr %l252, !tbaa !23
  %t511 = insertvalue { %"compiler/source:Span", i32, ptr } %t509, i32 %t510, 1
  %t513 = insertvalue { %"compiler/source:Span", i32, ptr } %t511, ptr %t505, 2
  %t514 = getelementptr { i64, [5 x i64] }, ptr %t506, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t513, ptr %t514
  %t515 = load { i64, [5 x i64] }, ptr %t506
  %t517 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t515, ptr %t517
  call void @__olang_scope_close(ptr %s0)
  store ptr %t517, ptr %rv
  br label %ret
bb94:
  %t519 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t519, ptr %l261
  %t520 = load i32, ptr %l2, !tbaa !23
  store i32 %t520, ptr %l262, !tbaa !23
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t523 = getelementptr %"compiler/check:Checker", ptr %t521, i32 0, i32 37
  %t524 = load i64, ptr %l8, !tbaa !24
  %t527 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t523, i64 %t524)
  store { i64, ptr } %t527, ptr %l266
  br label %bb95
bb95:
  %t528 = load ptr, ptr %lp33
  %t529 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t531 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t529, ptr %t528)
  store %"compiler/typed:Seq" %t531, ptr %l268
  br label %bb96
bb96:
  %t532 = load %"compiler/typed:Seq", ptr %l268
  %t533 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t532, ptr %t533
  store { i64, [5 x i64] } zeroinitializer, ptr %t534
  %t535 = getelementptr { i64, [5 x i64] }, ptr %t534, i32 0, i32 0
  store i64 12, ptr %t535
  %t536 = load %"compiler/source:Span", ptr %l261
  %t537 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t536, 0
  %t538 = load i32, ptr %l262, !tbaa !23
  %t539 = insertvalue { %"compiler/source:Span", i32, ptr } %t537, i32 %t538, 1
  %t541 = insertvalue { %"compiler/source:Span", i32, ptr } %t539, ptr %t533, 2
  %t542 = getelementptr { i64, [5 x i64] }, ptr %t534, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t541, ptr %t542
  %t543 = load { i64, [5 x i64] }, ptr %t534
  %t545 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t543, ptr %t545
  call void @__olang_scope_close(ptr %s0)
  store ptr %t545, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffB(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %t10, ptr %a2)
  store i1 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i1, ptr %l10, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryChecks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca ptr
  %l15 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i1
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i64
  %l42 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 0
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t13)
  store ptr %t15, ptr %l15
  br label %bb5
bb5:
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 1
  %t19 = load { i64, [2 x i64] }, ptr %t18
  store { i64, [2 x i64] } %t19, ptr %l2
  %t21 = load { i64, [2 x i64] }, ptr %l2
  %t23 = extractvalue { i64, [2 x i64] } %t21, 0
  %t24 = icmp eq i64 %t23, 0
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t27 = getelementptr { i64 }, ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb14
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l26
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %l26, !tbaa !24
  %t44 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t42, i64 %t43)
  store i1 %t44, ptr %l27
  br label %bb10
bb10:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb23
bb14:
  %t46 = load { i64, [2 x i64] }, ptr %l2
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb23
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6)
  unreachable
bb23:
  %t51 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t51, ptr %l30
  br label %bb24
bb24:
  %t52 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l4
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l32
  br label %bb25
bb25:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 5
  store ptr %t58, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb26
bb26:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l37
  br label %bb27
bb27:
  %t64 = load i64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb28, label %bb29
bb28:
  br label %bb34
bb29:
  br label %bb30
bb30:
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t70, i64 %t71)
  store i32 %t74, ptr %l42
  br label %bb31
bb31:
  %t75 = load i32, ptr %l42, !tbaa !23
  %t78 = sext i32 %t75 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t78)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb26
bb34:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %s0, ptr %t85, i64 %t86, ptr %l4, i1 false)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrsText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca i64
  %l31 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t18, ptr %l19, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l20, !tbaa !24
  %t31 = mul i64 %t30, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t35, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb11
bb8:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l6, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb10
bb10:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb11
bb11:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l6, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l9, !tbaa !24
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l52, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t92, ptr %l54, !tbaa !27
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t91, i32 %t98)
  store { i64, ptr } %t101, ptr %l57
  br label %bb20
bb20:
  %t102 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  %t104 = extractvalue { i64, ptr } %t102, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load ptr, ptr %l52, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t109, { i64, ptr } %t108)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t111, 1
  store i64 %t113, ptr %l8, !tbaa !24
  br label %bb12
bb23:
  %t116 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t116, ptr %l62
  br label %bb24
bb24:
  %t117 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l64, !tbaa !24
  %t120 = load i64, ptr %l64, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l65, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l64, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t131, ptr %l63, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t132, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca i64
  %l31 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, [3 x i64] }
  %l56 = alloca %"compiler/msgs:Msg"
  %l57 = alloca i64
  %l62 = alloca i1
  %l64 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l80 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, [3 x i64] }
  %l87 = alloca { i64, ptr }
  %l89 = alloca %"compiler/msgs:Msg"
  %l90 = alloca i64
  %l94 = alloca i32
  %l97 = alloca ptr
  %l102 = alloca i32
  %l103 = alloca { i64, ptr }
  %l111 = alloca i64
  %l114 = alloca i64
  %l136 = alloca { i64, ptr }
  %l142 = alloca i1
  %l145 = alloca i1
  %l148 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i64
  %l158 = alloca i64
  %l160 = alloca i64
  %l164 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l171 = alloca { i64, [3 x i64] }
  %l174 = alloca { i64, ptr }
  %l176 = alloca %"compiler/msgs:Msg"
  %l177 = alloca i64
  %l184 = alloca i32
  %l188 = alloca i1
  %l192 = alloca i1
  %l203 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i64
  %l219 = alloca { i64, ptr }
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l233 = alloca %"compiler/source:Span"
  %l236 = alloca { i64, [3 x i64] }
  %l239 = alloca { i64, ptr }
  %l241 = alloca %"compiler/msgs:Msg"
  %l242 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %t63 = alloca { i64, [3 x i64] }, align 8
  %t349 = alloca { i64, [3 x i64] }, align 8
  %t503 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l21
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l21, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l25
  br label %bb2
bb2:
  %t18 = load i64, ptr %l25, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/load:Loader", ptr %t25, i32 0, i32 5
  %t31 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t27, i64 %t18)
  store ptr %t31, ptr %l31
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Module", ptr %t32, i32 0, i32 4
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Func", ptr %t38, i32 0, i32 2
  %t41 = load i32, ptr %t40, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t37, i32 %t41)
  store { i64, ptr } %t44, ptr %l37
  br label %bb4
bb4:
  %t45 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t46 = load i64, ptr %l4, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:Func", ptr %t47, i32 0, i32 0
  %t50 = getelementptr %"compiler/source:Span", ptr %t49, i32 0, i32 0
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Func", ptr %t54, i32 0, i32 0
  %t57 = getelementptr %"compiler/source:Span", ptr %t56, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t60 = sext i32 %t58 to i64
  %t62 = add i64 %t60, 6
  store { i64, [3 x i64] } zeroinitializer, ptr %t63
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 0
  store i64 3, ptr %t64
  %t66 = insertvalue { i64, i64, i64 } undef, i64 %t46, 0
  %t68 = insertvalue { i64, i64, i64 } %t66, i64 %t53, 1
  %t70 = insertvalue { i64, i64, i64 } %t68, i64 %t62, 2
  %t71 = getelementptr { i64, [3 x i64] }, ptr %t63, i32 0, i32 1
  store { i64, i64, i64 } %t70, ptr %t71
  %t72 = load { i64, [3 x i64] }, ptr %t63
  store { i64, [3 x i64] } %t72, ptr %l6
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/ast:Func", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = icmp eq ptr %t77, null
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 4
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l54, !tbaa !29
  %t93 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t93, ptr %l55
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportMethod(ptr %s1)
  store %"compiler/msgs:Msg" %t94, ptr %l56
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load { i64, [3 x i64] }, ptr %l55
  %t97 = load %"compiler/msgs:Msg", ptr %l56
  %t98 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s1, ptr %t95, { i64, [3 x i64] } %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l57
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  %t99 = load ptr, ptr %l2, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Func", ptr %t99, i32 0, i32 5
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb14
bb11:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  store ptr %t111, ptr %l64, !tbaa !29
  %t112 = load i64, ptr %l1, !tbaa !24
  %t114 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t112)
  store i64 %t114, ptr %l66
  br label %bb12
bb12:
  %t115 = load ptr, ptr %l64, !tbaa !29
  %t116 = load i64, ptr %l66, !tbaa !24
  %t117 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t115, i64 %t116)
  store i64 %t117, ptr %l67
  br label %bb13
bb13:
  %t118 = load i64, ptr %l67, !tbaa !24
  %t119 = icmp sgt i64 %t118, 0
  store i1 %t119, ptr %l62, !tbaa !21
  br label %bb14
bb14:
  %t121 = load i1, ptr %l62, !tbaa !21
  br i1 %t121, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 0
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/load:Loader", ptr %t128, i32 0, i32 4
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l72, !tbaa !29
  %t132 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t132, ptr %l73
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportGeneric(ptr %s2)
  store %"compiler/msgs:Msg" %t133, ptr %l74
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t134 = load ptr, ptr %l72, !tbaa !29
  %t135 = load { i64, [3 x i64] }, ptr %l73
  %t136 = load %"compiler/msgs:Msg", ptr %l74
  %t137 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t134, { i64, [3 x i64] } %t135, %"compiler/msgs:Msg" %t136)
  store i64 %t137, ptr %l75
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  %t138 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t140 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t138, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t140, ptr %l77
  br label %bb20
bb20:
  %t141 = load i1, ptr %l77, !tbaa !21
  br i1 %t141, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb24
bb22:
  %t142 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t144 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t142, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t144, ptr %l80
  br label %bb23
bb23:
  %t145 = load i1, ptr %l80, !tbaa !21
  store i1 %t145, ptr %l78, !tbaa !21
  br label %bb24
bb24:
  %t146 = load i1, ptr %l78, !tbaa !21
  br i1 %t146, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 0
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/load:Loader", ptr %t153, i32 0, i32 4
  %t156 = load ptr, ptr %t155, !tbaa !29
  store ptr %t156, ptr %l84, !tbaa !29
  %t157 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t157, ptr %l85
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s3, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l87
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t161 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  %t169 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportName(ptr %s3, ptr %s3, { i64, ptr } %t167)
  store %"compiler/msgs:Msg" %t169, ptr %l89
  br label %bb28
bb28:
  %t170 = load ptr, ptr %l84, !tbaa !29
  %t171 = load { i64, [3 x i64] }, ptr %l85
  %t172 = load %"compiler/msgs:Msg", ptr %l89
  %t173 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s3, ptr %t170, { i64, [3 x i64] } %t171, %"compiler/msgs:Msg" %t172)
  store i64 %t173, ptr %l90
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = load i64, ptr %l1, !tbaa !24
  %t181 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t177, i64 %t178)
  store i32 %t181, ptr %l94
  br label %bb31
bb31:
  %t182 = load i32, ptr %l94, !tbaa !23
  store i32 %t182, ptr %l7, !tbaa !23
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 2
  store ptr %t188, ptr %l97, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l7, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l102
  br label %bb32
bb32:
  %t199 = load ptr, ptr %l97, !tbaa !29
  %t200 = load i32, ptr %l102, !tbaa !23
  %t201 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t199, i32 %t200)
  store { i64, ptr } %t201, ptr %l103
  br label %bb33
bb33:
  %t202 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t202, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Func", ptr %t203, i32 0, i32 3
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/ast:Sig", ptr %t206, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t213 = load i64, ptr %l10, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp sgt i64 %t213, %t214
  br i1 %t217, label %bb34, label %bb35
bb34:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = icmp sgt i64 %t219, 0
  br i1 %t221, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb39
bb36:
  %t223 = load i64, ptr %l10, !tbaa !24
  %t224 = load i64, ptr %l9, !tbaa !24
  %t227 = sub i64 %t223, %t224
  %t228 = load i64, ptr %l11, !tbaa !24
  %t231 = add i64 %t227, %t228
  %t233 = sub i64 %t231, 1
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = sdiv i64 %t233, %t234
  store i64 %t237, ptr %l114, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb38
bb38:
  %t239 = load i64, ptr %l114, !tbaa !24
  store i64 %t239, ptr %l111, !tbaa !24
  br label %bb39
bb39:
  %t240 = load i64, ptr %l111, !tbaa !24
  store i64 %t240, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s5
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb42:
  br label %bb43
bb43:
  %t249 = load i64, ptr %l9, !tbaa !24
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l11, !tbaa !24
  %t254 = mul i64 %t250, %t251
  %t257 = add i64 %t249, %t254
  store i64 %t257, ptr %l14, !tbaa !24
  %t259 = load i64, ptr %l14, !tbaa !24
  %t260 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t265 = icmp sge i64 %t259, %t262
  br i1 %t265, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t267 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t267, ptr %l136, !tbaa !27
  %t268 = load i64, ptr %l14, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i32, ptr %t271, i64 %t268
  %t273 = load i32, ptr %t272, !tbaa !33
  store i32 %t273, ptr %l15, !tbaa !23
  %t275 = load i32, ptr %l15, !tbaa !23
  %t276 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t279 = icmp eq i32 %t275, %t276
  br i1 %t279, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb50
bb48:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l15, !tbaa !23
  %t285 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %t281, i32 %t282)
  store i1 %t285, ptr %l145
  br label %bb49
bb49:
  %t286 = load i1, ptr %l145, !tbaa !21
  store i1 %t286, ptr %l142, !tbaa !21
  br label %bb50
bb50:
  %t287 = load i1, ptr %l142, !tbaa !21
  br i1 %t287, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb52:
  br label %bb53
bb53:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr %"compiler/ast:Func", ptr %t288, i32 0, i32 3
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = getelementptr %"compiler/ast:Sig", ptr %t291, i32 0, i32 0
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l148, !tbaa !27
  %t295 = load i64, ptr %l14, !tbaa !24
  %t297 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr ptr, ptr %t298, i64 %t295
  %t300 = load ptr, ptr %t299, !tbaa !39
  %t302 = getelementptr %"compiler/ast:Param", ptr %t300, i32 0, i32 0
  %t303 = load %"compiler/source:Span", ptr %t302
  store %"compiler/source:Span" %t303, ptr %l16
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t305, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/load:Loader", ptr %t311, i32 0, i32 4
  %t314 = load ptr, ptr %t313, !tbaa !29
  store ptr %t314, ptr %l155, !tbaa !29
  %t315 = load i64, ptr %l4, !tbaa !24
  store i64 %t315, ptr %l156, !tbaa !24
  %t316 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t317 = load i32, ptr %t316, !tbaa !23
  %t319 = sext i32 %t317 to i64
  store i64 %t319, ptr %l158, !tbaa !24
  %t320 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t321 = load i32, ptr %t320, !tbaa !23
  %t323 = sext i32 %t321 to i64
  store i64 %t323, ptr %l160, !tbaa !24
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load ptr, ptr %l2, !tbaa !29
  %t327 = getelementptr %"compiler/ast:Func", ptr %t325, i32 0, i32 3
  %t328 = load ptr, ptr %t327, !tbaa !29
  %t330 = getelementptr %"compiler/ast:Sig", ptr %t328, i32 0, i32 0
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l164, !tbaa !27
  %t332 = load i64, ptr %l14, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr ptr, ptr %t335, i64 %t332
  %t337 = load ptr, ptr %t336, !tbaa !39
  %t339 = getelementptr %"compiler/ast:Param", ptr %t337, i32 0, i32 1
  %t340 = load i32, ptr %t339, !tbaa !23
  %t343 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t324, i32 %t340)
  store { i64, ptr } %t343, ptr %l168
  br label %bb54
bb54:
  %t344 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 0
  %t346 = load i64, ptr %l160, !tbaa !24
  %t348 = add i64 %t346, %t345
  store { i64, [3 x i64] } zeroinitializer, ptr %t349
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 0
  store i64 3, ptr %t350
  %t351 = load i64, ptr %l156, !tbaa !24
  %t352 = insertvalue { i64, i64, i64 } undef, i64 %t351, 0
  %t353 = load i64, ptr %l158, !tbaa !24
  %t354 = insertvalue { i64, i64, i64 } %t352, i64 %t353, 1
  %t356 = insertvalue { i64, i64, i64 } %t354, i64 %t348, 2
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  store { i64, i64, i64 } %t356, ptr %t357
  %t358 = load { i64, [3 x i64] }, ptr %t349
  store { i64, [3 x i64] } %t358, ptr %l171
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l15, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t359, i32 %t360)
  store { i64, ptr } %t363, ptr %l174
  br label %bb55
bb55:
  %t364 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportType(ptr %s5, ptr %s5, { i64, ptr } %t370)
  store %"compiler/msgs:Msg" %t372, ptr %l176
  br label %bb56
bb56:
  %t373 = load ptr, ptr %l155, !tbaa !29
  %t374 = load { i64, [3 x i64] }, ptr %l171
  %t375 = load %"compiler/msgs:Msg", ptr %l176
  %t376 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s5, ptr %t373, { i64, [3 x i64] } %t374, %"compiler/msgs:Msg" %t375)
  store i64 %t376, ptr %l177
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb58
bb58:
  %t377 = load i64, ptr %l13, !tbaa !24
  %t379 = add i64 %t377, 1
  store i64 %t379, ptr %l13, !tbaa !24
  br label %bb40
bb59:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 2
  %t387 = load i32, ptr %l7, !tbaa !23
  %t390 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t386, i32 %t387)
  store i32 %t390, ptr %l184
  br label %bb60
bb60:
  %t391 = load i32, ptr %l184, !tbaa !23
  store i32 %t391, ptr %l17, !tbaa !23
  %t392 = load i32, ptr %l17, !tbaa !23
  %t393 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t396 = icmp eq i32 %t392, %t393
  br i1 %t396, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb63
bb62:
  %t398 = load i32, ptr %l17, !tbaa !23
  %t399 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t402 = icmp eq i32 %t398, %t399
  store i1 %t402, ptr %l188, !tbaa !21
  br label %bb63
bb63:
  %t404 = load i1, ptr %l188, !tbaa !21
  br i1 %t404, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb66
bb65:
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t407 = getelementptr %"compiler/ast:Func", ptr %t405, i32 0, i32 3
  %t408 = load ptr, ptr %t407, !tbaa !29
  %t410 = getelementptr %"compiler/ast:Sig", ptr %t408, i32 0, i32 1
  %t411 = load { i64, ptr }, ptr %t410, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t411, 0
  %t415 = icmp eq i64 %t413, 0
  store i1 %t415, ptr %l192, !tbaa !21
  br label %bb66
bb66:
  %t417 = load i1, ptr %l192, !tbaa !21
  br i1 %t417, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  br label %bb69
bb69:
  %t418 = load ptr, ptr %l2, !tbaa !29
  %t420 = getelementptr %"compiler/ast:Func", ptr %t418, i32 0, i32 3
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Sig", ptr %t421, i32 0, i32 1
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t428 = icmp sgt i64 %t426, 1
  br i1 %t428, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l203, !tbaa !21
  br label %bb77
bb71:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l17, !tbaa !23
  %t434 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t430, i32 %t431)
  store i1 %t434, ptr %l206
  br label %bb72
bb72:
  %t435 = load i1, ptr %l206, !tbaa !21
  br i1 %t435, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb76
bb74:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load i32, ptr %l17, !tbaa !23
  %t440 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %t436, i32 %t437)
  store i1 %t440, ptr %l210
  br label %bb75
bb75:
  %t441 = load i1, ptr %l210, !tbaa !21
  store i1 %t441, ptr %l207, !tbaa !21
  br label %bb76
bb76:
  %t442 = load i1, ptr %l207, !tbaa !21
  %t443 = xor i1 %t442, true
  store i1 %t443, ptr %l203, !tbaa !21
  br label %bb77
bb77:
  %t445 = load i1, ptr %l203, !tbaa !21
  br i1 %t445, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s10
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t446, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t451 = getelementptr %"compiler/generic:Program", ptr %t449, i32 0, i32 0
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/load:Loader", ptr %t452, i32 0, i32 4
  %t455 = load ptr, ptr %t454, !tbaa !29
  store ptr %t455, ptr %l215, !tbaa !29
  %t456 = load i64, ptr %l4, !tbaa !24
  store i64 %t456, ptr %l216, !tbaa !24
  %t457 = load ptr, ptr %l2, !tbaa !29
  %t459 = getelementptr %"compiler/ast:Func", ptr %t457, i32 0, i32 3
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/ast:Sig", ptr %t460, i32 0, i32 1
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l219, !tbaa !27
  %t464 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !27
  %t466 = getelementptr ptr, ptr %t465, i64 0
  %t467 = load ptr, ptr %t466, !tbaa !39
  %t469 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t467)
  store %"compiler/source:Span" %t469, ptr %l221
  br label %bb80
bb79:
  br label %bb85
bb80:
  %t470 = getelementptr %"compiler/source:Span", ptr %l221, i32 0, i32 0
  %t471 = load i32, ptr %t470, !tbaa !23
  %t473 = sext i32 %t471 to i64
  store i64 %t473, ptr %l223, !tbaa !24
  %t474 = load ptr, ptr %l2, !tbaa !29
  %t476 = getelementptr %"compiler/ast:Func", ptr %t474, i32 0, i32 3
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = getelementptr %"compiler/ast:Sig", ptr %t477, i32 0, i32 1
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  store { i64, ptr } %t480, ptr %l226, !tbaa !27
  %t481 = load ptr, ptr %l2, !tbaa !29
  %t483 = getelementptr %"compiler/ast:Func", ptr %t481, i32 0, i32 3
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t486 = getelementptr %"compiler/ast:Sig", ptr %t484, i32 0, i32 1
  %t487 = load { i64, ptr }, ptr %t486, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t487, 0
  %t491 = sub i64 %t489, 1
  %t493 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = getelementptr ptr, ptr %t494, i64 %t491
  %t496 = load ptr, ptr %t495, !tbaa !39
  %t498 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t496)
  store %"compiler/source:Span" %t498, ptr %l233
  br label %bb81
bb81:
  %t499 = getelementptr %"compiler/source:Span", ptr %l233, i32 0, i32 1
  %t500 = load i32, ptr %t499, !tbaa !23
  %t502 = sext i32 %t500 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t503
  %t504 = getelementptr { i64, [3 x i64] }, ptr %t503, i32 0, i32 0
  store i64 3, ptr %t504
  %t505 = load i64, ptr %l216, !tbaa !24
  %t506 = insertvalue { i64, i64, i64 } undef, i64 %t505, 0
  %t507 = load i64, ptr %l223, !tbaa !24
  %t508 = insertvalue { i64, i64, i64 } %t506, i64 %t507, 1
  %t510 = insertvalue { i64, i64, i64 } %t508, i64 %t502, 2
  %t511 = getelementptr { i64, [3 x i64] }, ptr %t503, i32 0, i32 1
  store { i64, i64, i64 } %t510, ptr %t511
  %t512 = load { i64, [3 x i64] }, ptr %t503
  store { i64, [3 x i64] } %t512, ptr %l236
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load i32, ptr %l17, !tbaa !23
  %t517 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t513, i32 %t514)
  store { i64, ptr } %t517, ptr %l239
  br label %bb82
bb82:
  %t518 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t519 = extractvalue { i64, ptr } %t518, 0
  %t520 = extractvalue { i64, ptr } %t518, 1
  %t521 = mul i64 %t519, 1
  %t522 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t521)
  call void @llvm.memcpy.p0.p0.i64(ptr %t522, ptr %t520, i64 %t521, i1 false)
  %t523 = insertvalue { i64, ptr } undef, i64 %t519, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  %t526 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportResult(ptr %s10, ptr %s10, { i64, ptr } %t524)
  store %"compiler/msgs:Msg" %t526, ptr %l241
  br label %bb83
bb83:
  %t527 = load ptr, ptr %l215, !tbaa !29
  %t528 = load { i64, [3 x i64] }, ptr %l236
  %t529 = load %"compiler/msgs:Msg", ptr %l241
  %t530 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s10, ptr %t527, { i64, [3 x i64] } %t528, %"compiler/msgs:Msg" %t529)
  store i64 %t530, ptr %l242
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l20 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i32
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l48 = alloca ptr
  %l58 = alloca i64
  %l61 = alloca i64
  %l83 = alloca { i64, ptr }
  %l89 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %l98 = alloca i1
  %l100 = alloca i1
  %l105 = alloca i32
  %l108 = alloca i1
  %l111 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l120 = alloca i1
  %l125 = alloca i32
  %l128 = alloca i1
  %l131 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i64
  %l152 = alloca i64
  %l154 = alloca i64
  %l158 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, [3 x i64] }
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l178 = alloca i32
  %l182 = alloca i1
  %l186 = alloca i1
  %l190 = alloca i1
  %l201 = alloca i1
  %l204 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l213 = alloca { i64, ptr }
  %l215 = alloca %"compiler/source:Span"
  %l217 = alloca i64
  %l220 = alloca { i64, ptr }
  %l227 = alloca %"compiler/source:Span"
  %l230 = alloca { i64, [3 x i64] }
  %l233 = alloca { i64, ptr }
  %l235 = alloca %"compiler/msgs:Msg"
  %l236 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %t318 = alloca { i64, [3 x i64] }, align 8
  %t472 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l20
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l20, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l24
  br label %bb2
bb2:
  %t18 = load i64, ptr %l24, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t22, i64 %t23)
  store i32 %t26, ptr %l28
  br label %bb3
bb3:
  %t27 = load i32, ptr %l28, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  store ptr %t33, ptr %l31, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l4, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l36
  br label %bb4
bb4:
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t45 = load i32, ptr %l36, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l37
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t47, ptr %l5, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %t51, !tbaa !23
  %t55 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t48, i32 %t52)
  store { i64, ptr } %t55, ptr %l41
  br label %bb6
bb6:
  %t56 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t56, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t57, ptr %l42
  br label %bb7
bb7:
  %t58 = load i1, ptr %l42, !tbaa !21
  store i1 %t58, ptr %l6, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/load:Loader", ptr %t65, i32 0, i32 5
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store ptr %t71, ptr %l48
  br label %bb8
bb8:
  %t72 = load ptr, ptr %l48, !tbaa !29
  %t74 = getelementptr %"compiler/load:Module", ptr %t72, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr %"compiler/ast:Func", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Sig", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t87, %t88
  br i1 %t91, label %bb9, label %bb10
bb9:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp sgt i64 %t93, 0
  br i1 %t95, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb14
bb11:
  %t97 = load i64, ptr %l9, !tbaa !24
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = sub i64 %t97, %t98
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = add i64 %t101, %t102
  %t107 = sub i64 %t105, 1
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sdiv i64 %t107, %t108
  store i64 %t111, ptr %l61, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb13
bb13:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l58, !tbaa !24
  br label %bb14
bb14:
  %t114 = load i64, ptr %l58, !tbaa !24
  store i64 %t114, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t115 = load i64, ptr %l12, !tbaa !24
  %t116 = load i64, ptr %l11, !tbaa !24
  %t119 = icmp slt i64 %t115, %t116
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb17:
  br label %bb18
bb18:
  %t123 = load i64, ptr %l8, !tbaa !24
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l10, !tbaa !24
  %t128 = mul i64 %t124, %t125
  %t131 = add i64 %t123, %t128
  store i64 %t131, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l13, !tbaa !24
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t139 = icmp sge i64 %t133, %t136
  br i1 %t139, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb20:
  br label %bb21
bb21:
  %t141 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t141, ptr %l83, !tbaa !27
  %t142 = load i64, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr i32, ptr %t145, i64 %t142
  %t147 = load i32, ptr %t146, !tbaa !33
  store i32 %t147, ptr %l14, !tbaa !23
  %t149 = load i32, ptr %l14, !tbaa !23
  %t150 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t153 = icmp eq i32 %t149, %t150
  br i1 %t153, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb25
bb23:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i32, ptr %l14, !tbaa !23
  %t159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l92
  br label %bb24
bb24:
  %t160 = load i1, ptr %l92, !tbaa !21
  store i1 %t160, ptr %l89, !tbaa !21
  br label %bb25
bb25:
  %t161 = load i1, ptr %l89, !tbaa !21
  br i1 %t161, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb27:
  br label %bb28
bb28:
  %t162 = load i1, ptr %l6, !tbaa !21
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb29, label %bb30
bb29:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l98
  br label %bb31
bb30:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb32
bb31:
  %t171 = load i1, ptr %l98, !tbaa !21
  store i1 %t171, ptr %l95, !tbaa !21
  br label %bb32
bb32:
  %t172 = load i1, ptr %l95, !tbaa !21
  br i1 %t172, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb34:
  br label %bb35
bb35:
  %t173 = load i1, ptr %l6, !tbaa !21
  br i1 %t173, label %bb36, label %bb37
bb36:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  %t181 = load i32, ptr %l14, !tbaa !23
  %t184 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t180, i32 %t181)
  store i32 %t184, ptr %l105
  br label %bb38
bb37:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb39
bb38:
  %t185 = load i32, ptr %l105
  %t187 = trunc i64 21 to i32
  %t188 = icmp eq i32 %t185, %t187
  store i1 %t188, ptr %l100, !tbaa !21
  br label %bb39
bb39:
  %t190 = load i1, ptr %l100, !tbaa !21
  br i1 %t190, label %bb40, label %bb41
bb40:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 2
  store ptr %t196, ptr %l111, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  %t203 = load i32, ptr %l14, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t202, i32 %t203)
  store i32 %t206, ptr %l116
  br label %bb42
bb41:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb44
bb42:
  %t207 = load ptr, ptr %l111, !tbaa !29
  %t208 = load i32, ptr %l116, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t207, i32 %t208)
  store { i64, ptr } %t209, ptr %l117
  br label %bb43
bb43:
  %t210 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t213 = icmp eq i64 %t211, 0
  store i1 %t213, ptr %l108, !tbaa !21
  br label %bb44
bb44:
  %t215 = load i1, ptr %l108, !tbaa !21
  br i1 %t215, label %bb45, label %bb46
bb45:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/check:Checker", ptr %t216, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t221 = getelementptr %"compiler/generic:Program", ptr %t219, i32 0, i32 2
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l125
  br label %bb47
bb46:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb48
bb47:
  %t226 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t227 = load i32, ptr %l125, !tbaa !23
  %t229 = icmp eq i32 %t227, %t226
  store i1 %t229, ptr %l120, !tbaa !21
  br label %bb48
bb48:
  %t231 = load i1, ptr %l120, !tbaa !21
  br i1 %t231, label %bb49, label %bb50
bb49:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 2
  store ptr %t237, ptr %l131, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l14, !tbaa !23
  %t247 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t243, i32 %t244)
  store i32 %t247, ptr %l136
  br label %bb51
bb50:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb53
bb51:
  %t248 = load ptr, ptr %l131, !tbaa !29
  %t249 = load i32, ptr %l136, !tbaa !23
  %t250 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t248, i32 %t249)
  store { i64, ptr } %t250, ptr %l137
  br label %bb52
bb52:
  %t251 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t254 = icmp eq i64 %t252, 0
  store i1 %t254, ptr %l128, !tbaa !21
  br label %bb53
bb53:
  %t256 = load i1, ptr %l128, !tbaa !21
  br i1 %t256, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb55:
  br label %bb56
bb56:
  %t257 = load ptr, ptr %l2, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 3
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Sig", ptr %t260, i32 0, i32 0
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l142, !tbaa !27
  %t264 = load i64, ptr %l13, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr ptr, ptr %t267, i64 %t264
  %t269 = load ptr, ptr %t268, !tbaa !39
  %t271 = getelementptr %"compiler/ast:Param", ptr %t269, i32 0, i32 0
  %t272 = load %"compiler/source:Span", ptr %t271
  store %"compiler/source:Span" %t272, ptr %l15
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 0
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = getelementptr %"compiler/load:Loader", ptr %t280, i32 0, i32 4
  %t283 = load ptr, ptr %t282, !tbaa !29
  store ptr %t283, ptr %l149, !tbaa !29
  %t284 = load i64, ptr %l7, !tbaa !24
  store i64 %t284, ptr %l150, !tbaa !24
  %t285 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t286 = load i32, ptr %t285, !tbaa !23
  %t288 = sext i32 %t286 to i64
  store i64 %t288, ptr %l152, !tbaa !24
  %t289 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = sext i32 %t290 to i64
  store i64 %t292, ptr %l154, !tbaa !24
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = getelementptr %"compiler/ast:Func", ptr %t294, i32 0, i32 3
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/ast:Sig", ptr %t297, i32 0, i32 0
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l158, !tbaa !27
  %t301 = load i64, ptr %l13, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t308 = getelementptr %"compiler/ast:Param", ptr %t306, i32 0, i32 1
  %t309 = load i32, ptr %t308, !tbaa !23
  %t312 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t293, i32 %t309)
  store { i64, ptr } %t312, ptr %l162
  br label %bb57
bb57:
  %t313 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 0
  %t315 = load i64, ptr %l154, !tbaa !24
  %t317 = add i64 %t315, %t314
  store { i64, [3 x i64] } zeroinitializer, ptr %t318
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 0
  store i64 3, ptr %t319
  %t320 = load i64, ptr %l150, !tbaa !24
  %t321 = insertvalue { i64, i64, i64 } undef, i64 %t320, 0
  %t322 = load i64, ptr %l152, !tbaa !24
  %t323 = insertvalue { i64, i64, i64 } %t321, i64 %t322, 1
  %t325 = insertvalue { i64, i64, i64 } %t323, i64 %t317, 2
  %t326 = getelementptr { i64, [3 x i64] }, ptr %t318, i32 0, i32 1
  store { i64, i64, i64 } %t325, ptr %t326
  %t327 = load { i64, [3 x i64] }, ptr %t318
  store { i64, [3 x i64] } %t327, ptr %l165
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i32, ptr %l14, !tbaa !23
  %t332 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t328, i32 %t329)
  store { i64, ptr } %t332, ptr %l168
  br label %bb58
bb58:
  %t333 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  %t335 = extractvalue { i64, ptr } %t333, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  %t341 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %s2, ptr %s2, { i64, ptr } %t339)
  store %"compiler/msgs:Msg" %t341, ptr %l170
  br label %bb59
bb59:
  %t342 = load ptr, ptr %l149, !tbaa !29
  %t343 = load { i64, [3 x i64] }, ptr %l165
  %t344 = load %"compiler/msgs:Msg", ptr %l170
  %t345 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s2, ptr %t342, { i64, [3 x i64] } %t343, %"compiler/msgs:Msg" %t344)
  store i64 %t345, ptr %l171
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s2)
  br label %bb61
bb61:
  %t346 = load i64, ptr %l12, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l12, !tbaa !24
  br label %bb15
bb62:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = load i32, ptr %l4, !tbaa !23
  %t359 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t359, ptr %l178
  br label %bb63
bb63:
  %t360 = load i32, ptr %l178, !tbaa !23
  store i32 %t360, ptr %l16, !tbaa !23
  %t361 = load i32, ptr %l16, !tbaa !23
  %t362 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t365 = icmp eq i32 %t361, %t362
  br i1 %t365, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb66
bb65:
  %t367 = load i32, ptr %l16, !tbaa !23
  %t368 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t371 = icmp eq i32 %t367, %t368
  store i1 %t371, ptr %l182, !tbaa !21
  br label %bb66
bb66:
  %t373 = load i1, ptr %l182, !tbaa !21
  br i1 %t373, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb69
bb68:
  %t374 = load i32, ptr %l16, !tbaa !23
  %t375 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t378 = icmp eq i32 %t374, %t375
  store i1 %t378, ptr %l186, !tbaa !21
  br label %bb69
bb69:
  %t380 = load i1, ptr %l186, !tbaa !21
  br i1 %t380, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb72
bb71:
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr %"compiler/ast:Func", ptr %t381, i32 0, i32 3
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/ast:Sig", ptr %t384, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t391 = icmp eq i64 %t389, 0
  store i1 %t391, ptr %l190, !tbaa !21
  br label %bb72
bb72:
  %t393 = load i1, ptr %l190, !tbaa !21
  br i1 %t393, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb74:
  br label %bb75
bb75:
  %t394 = load ptr, ptr %l2, !tbaa !29
  %t396 = getelementptr %"compiler/ast:Func", ptr %t394, i32 0, i32 3
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t399 = getelementptr %"compiler/ast:Sig", ptr %t397, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t404 = icmp sgt i64 %t402, 1
  br i1 %t404, label %bb76, label %bb77
bb76:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb79
bb77:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l16, !tbaa !23
  %t410 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t406, i32 %t407)
  store i1 %t410, ptr %l204
  br label %bb78
bb78:
  %t411 = load i1, ptr %l204, !tbaa !21
  %t412 = xor i1 %t411, true
  store i1 %t412, ptr %l201, !tbaa !21
  br label %bb79
bb79:
  %t414 = load i1, ptr %l201, !tbaa !21
  br i1 %t414, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s9
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t420 = getelementptr %"compiler/generic:Program", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/load:Loader", ptr %t421, i32 0, i32 4
  %t424 = load ptr, ptr %t423, !tbaa !29
  store ptr %t424, ptr %l209, !tbaa !29
  %t425 = load i64, ptr %l7, !tbaa !24
  store i64 %t425, ptr %l210, !tbaa !24
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t428 = getelementptr %"compiler/ast:Func", ptr %t426, i32 0, i32 3
  %t429 = load ptr, ptr %t428, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Sig", ptr %t429, i32 0, i32 1
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  store { i64, ptr } %t432, ptr %l213, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = getelementptr ptr, ptr %t434, i64 0
  %t436 = load ptr, ptr %t435, !tbaa !39
  %t438 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t436)
  store %"compiler/source:Span" %t438, ptr %l215
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t439 = getelementptr %"compiler/source:Span", ptr %l215, i32 0, i32 0
  %t440 = load i32, ptr %t439, !tbaa !23
  %t442 = sext i32 %t440 to i64
  store i64 %t442, ptr %l217, !tbaa !24
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = getelementptr %"compiler/ast:Func", ptr %t443, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/ast:Sig", ptr %t446, i32 0, i32 1
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !27
  store { i64, ptr } %t449, ptr %l220, !tbaa !27
  %t450 = load ptr, ptr %l2, !tbaa !29
  %t452 = getelementptr %"compiler/ast:Func", ptr %t450, i32 0, i32 3
  %t453 = load ptr, ptr %t452, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Sig", ptr %t453, i32 0, i32 1
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t460 = sub i64 %t458, 1
  %t462 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr ptr, ptr %t463, i64 %t460
  %t465 = load ptr, ptr %t464, !tbaa !39
  %t467 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %t465)
  store %"compiler/source:Span" %t467, ptr %l227
  br label %bb83
bb83:
  %t468 = getelementptr %"compiler/source:Span", ptr %l227, i32 0, i32 1
  %t469 = load i32, ptr %t468, !tbaa !23
  %t471 = sext i32 %t469 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t472
  %t473 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 0
  store i64 3, ptr %t473
  %t474 = load i64, ptr %l210, !tbaa !24
  %t475 = insertvalue { i64, i64, i64 } undef, i64 %t474, 0
  %t476 = load i64, ptr %l217, !tbaa !24
  %t477 = insertvalue { i64, i64, i64 } %t475, i64 %t476, 1
  %t479 = insertvalue { i64, i64, i64 } %t477, i64 %t471, 2
  %t480 = getelementptr { i64, [3 x i64] }, ptr %t472, i32 0, i32 1
  store { i64, i64, i64 } %t479, ptr %t480
  %t481 = load { i64, [3 x i64] }, ptr %t472
  store { i64, [3 x i64] } %t481, ptr %l230
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l16, !tbaa !23
  %t486 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t482, i32 %t483)
  store { i64, ptr } %t486, ptr %l233
  br label %bb84
bb84:
  %t487 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t488 = extractvalue { i64, ptr } %t487, 0
  %t489 = extractvalue { i64, ptr } %t487, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  %t495 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %s9, ptr %s9, { i64, ptr } %t493)
  store %"compiler/msgs:Msg" %t495, ptr %l235
  br label %bb85
bb85:
  %t496 = load ptr, ptr %l209, !tbaa !29
  %t497 = load { i64, [3 x i64] }, ptr %l230
  %t498 = load %"compiler/msgs:Msg", ptr %l235
  %t499 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s9, ptr %t496, { i64, [3 x i64] } %t497, %"compiler/msgs:Msg" %t498)
  store i64 %t499, ptr %l236
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efirstValueType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i32
  %l23 = alloca i32
  %l26 = alloca i1
  %l31 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i1
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l51 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a2)
  store i32 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i32, ptr %l7, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l4, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i1, ptr %l10, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t14 = call i1 @compiler_2fcheck_2enullValue(ptr %v1, ptr %a1)
  store i1 %t14, ptr %l13
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb6
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l18
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t27 = load i32, ptr %l18, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l23
  br label %bb11
bb11:
  %t38 = load i32, ptr %l23
  %t40 = trunc i64 19 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l4, !tbaa !23
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l31
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb15
bb14:
  %t53 = load i32, ptr %l31, !tbaa !23
  %t54 = icmp ne i32 %t53, 0
  store i1 %t54, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l26, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v3, ptr %t57, ptr %a3)
  store i1 %t61, ptr %l36
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t63 = load i1, ptr %l33, !tbaa !21
  br i1 %t63, label %bb20, label %bb21
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  store ptr %t69, ptr %l39, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %l4, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t80 = load ptr, ptr %l39, !tbaa !29
  %t81 = load i32, ptr %l44, !tbaa !23
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t80, i32 %t81, i32 0)
  store i32 %t82, ptr %l45
  br label %bb23
bb23:
  %t83 = load i32, ptr %l45, !tbaa !23
  store i32 %t83, ptr %l4, !tbaa !23
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l4, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb25
bb25:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l4, !tbaa !23
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l51
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t95 = load i32, ptr %l51, !tbaa !23
  store i32 %t95, ptr %l4, !tbaa !23
  br label %bb29
bb29:
  %t96 = load i32, ptr %l4, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca ptr
  %rv = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t2 = load i64, ptr %l3, !tbaa !24
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = icmp slt i64 %t6, 0
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l8, !tbaa !27
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr ptr, ptr %t13, i64 %t10
  %t15 = load ptr, ptr %t14, !tbaa !39
  store ptr %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr %a0, ptr %l11, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t24)
  store %"compiler/source:Span" %t26, ptr %l15
  br label %bb5
bb5:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t27, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l11, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = load i64, ptr %l18, !tbaa !24
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t32, %"compiler/source:Span" %t33, i64 %t34)
  store ptr %t35, ptr %l19
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l19, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/load:Import"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/names:Entry"
  %l8 = alloca { i64, ptr }
  %l11 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca %"compiler/load:Import"
  %l43 = alloca ptr
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/names:Entry"
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l68 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @compiler_2fload_2ePublic(ptr %v1, { i64, ptr } %t1)
  store i1 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i1, ptr %l11, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t7, ptr %l14, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l15, !tbaa !24
  %t10 = load i64, ptr %l15, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l16, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t21, ptr %l14, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/load:Loader", ptr %t29, i32 0, i32 5
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t39, i64 %t38)
  store ptr %t41, ptr %l25
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 11
  store ptr %t44, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l3, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load i64, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l30, !tbaa !24
  %t52 = icmp slt i64 %t50, %t51
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb47
bb10:
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t57 = load i64, ptr %l3, !tbaa !24
  %t60 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t56, i64 %t57)
  store %"compiler/load:Import" %t60, ptr %l35
  br label %bb12
bb12:
  %t61 = load %"compiler/load:Import", ptr %l35
  store %"compiler/load:Import" %t61, ptr %l4
  %t62 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp slt i64 %t63, 0
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb46
bb14:
  br label %bb15
bb15:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/names:Resolver", ptr %t73, i32 0, i32 1
  %t76 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 5
  %t77 = load i64, ptr %t76, !tbaa !24
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t75, i64 %t77)
  store ptr %t80, ptr %l43
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t83 = getelementptr %"compiler/names:Table", ptr %t81, i32 0, i32 0
  store ptr %t83, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l6, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l48
  br label %bb18
bb18:
  %t89 = load i64, ptr %l46, !tbaa !24
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb19, label %bb20
bb19:
  br label %bb45
bb20:
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/names:Entry" %t99, ptr %l53
  br label %bb22
bb22:
  %t100 = load %"compiler/names:Entry", ptr %l53
  store %"compiler/names:Entry" %t100, ptr %l7
  %t101 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 2
  %t102 = load i32, ptr %t101
  %t104 = trunc i64 4 to i32
  %t105 = icmp eq i32 %t102, %t104
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb27
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/names:Entry", ptr %l7, i32 0, i32 0
  %t111 = load i32, ptr %t110, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t109, i32 %t111)
  store { i64, ptr } %t114, ptr %l60
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t116, { i64, ptr } %t115)
  store i1 %t118, ptr %l62
  br label %bb26
bb26:
  %t119 = load i1, ptr %l62, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t122 = load i1, ptr %l57, !tbaa !21
  br i1 %t122, label %bb28, label %bb29
bb28:
  br label %bb44
bb29:
  br label %bb30
bb30:
  %t123 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l8, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  %t132 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s8, { i64, ptr } %t133, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  %t136 = extractvalue { i32, i64 } %t135, 1
  %t137 = extractvalue { i32, i64 } %t135, 0
  store i32 %t137, ptr %l71
  %t138 = icmp ne i32 %t137, 0
  br i1 %t138, label %bb34, label %ok.139, !prof !99
ok.139:
  store i64 %t136, ptr %l70
  br label %bb33
bb32:
  br label %bb43
bb33:
  %t140 = load i64, ptr %l70, !tbaa !24
  store i64 %t140, ptr %l68, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l68, !tbaa !24
  br label %bb36
bb36:
  %t141 = load i64, ptr %l68, !tbaa !24
  %t142 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  store { i64, ptr } %t143, ptr %l72, !tbaa !27
  %t146 = add i64 %t141, 1
  store i64 %t146, ptr %l74, !tbaa !24
  %t147 = getelementptr %"compiler/load:Import", ptr %l4, i32 0, i32 3
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t148, 0
  store i64 %t151, ptr %l77, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  store i64 %t153, ptr %l78, !tbaa !24
  %t154 = load i64, ptr %l74, !tbaa !24
  %t155 = icmp sge i64 %t154, 0
  br i1 %t155, label %bb37, label %bb38
bb37:
  %t157 = load i64, ptr %l74, !tbaa !24
  %t158 = load i64, ptr %l77, !tbaa !24
  %t159 = icmp sle i64 %t157, %t158
  br i1 %t159, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb39:
  %t161 = load i64, ptr %l77, !tbaa !24
  %t162 = load i64, ptr %l78, !tbaa !24
  %t163 = icmp sle i64 %t161, %t162
  br i1 %t163, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb41:
  %t165 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = load i64, ptr %l74, !tbaa !24
  %t168 = load i64, ptr %l77, !tbaa !24
  %t169 = getelementptr i8, ptr %t166, i64 %t167
  %t170 = sub i64 %t168, %t167
  %t171 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t169, 1
  store { i64, ptr } %t172, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1)
  unreachable
bb43:
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t174, 1
  %t178 = extractvalue { i64, ptr } %t174, 0
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t181 = add i64 %t178, %t180
  %t183 = extractvalue { i64, ptr } %t175, 1
  %t184 = extractvalue { i64, ptr } %t175, 0
  %t185 = add i64 %t181, %t184
  %t186 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t185)
  call void @olang_textcopy(ptr %t186, ptr %t177, i64 %t178)
  %t187 = getelementptr i8, ptr %t186, i64 %t178
  call void @olang_textcopy(ptr %t187, ptr %t179, i64 %t180)
  %t188 = getelementptr i8, ptr %t187, i64 %t180
  call void @olang_textcopy(ptr %t188, ptr %t183, i64 %t184)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t186, 1
  store { i64, ptr } %t190, ptr %rv
  br label %ret
bb44:
  %t192 = load i64, ptr %l6, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l6, !tbaa !24
  br label %bb17
bb45:
  br label %bb46
bb46:
  %t196 = load i64, ptr %l3, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l3, !tbaa !24
  br label %bb7
bb47:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l90, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t200, ptr %l91, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 0
  store i64 %t202, ptr %l92, !tbaa !24
  %t203 = load i64, ptr %l92, !tbaa !24
  %t204 = mul i64 %t203, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t204)
  %t206 = insertvalue { i64, ptr } undef, i64 %t203, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  store { i64, ptr } %t207, ptr %l93, !tbaa !27
  %t208 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l92, !tbaa !24
  %t213 = mul i64 %t212, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t209, ptr %t211, i64 %t213, i1 false)
  %t214 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t214, ptr %l91, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t215, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca i32
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca { i64, ptr }
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 16
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp ne i64 %t24, 1
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l4, !tbaa !29
  store ptr %t29, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t30 = load ptr, ptr %l24, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 0
  store i1 %t36, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l25, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t44 = load i32, ptr %l6, !tbaa !23
  store i32 %t44, ptr %l23, !tbaa !23
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 0, ptr %l23, !tbaa !23
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_cf50a113ac2177e6_e3cc5936e852a452)
  unreachable
bb19:
  %t46 = load i32, ptr %l23, !tbaa !23
  store i32 %t46, ptr %l7, !tbaa !23
  %t47 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr ptr, ptr %t49, i64 0
  %t51 = load ptr, ptr %t50, !tbaa !39
  store ptr %t51, ptr %l8, !tbaa !29
  %t53 = load ptr, ptr %l8, !tbaa !29
  store ptr %t53, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t54 = load ptr, ptr %l34, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t57 = load ptr, ptr %l34, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l8, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32 }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l9, !tbaa !23
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t68 = load i32, ptr %l9, !tbaa !23
  store i32 %t68, ptr %l33, !tbaa !23
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i32 0, ptr %l33, !tbaa !23
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_baddfb655e016c47_d17e78f9e01d2853)
  unreachable
bb30:
  %t70 = load i32, ptr %l33, !tbaa !23
  store i32 %t70, ptr %l10, !tbaa !23
  %t71 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp eq i32 %t71, %a2
  br i1 %t75, label %bb31, label %bb32
bb31:
  %t77 = load i32, ptr %l10, !tbaa !23
  %t81 = icmp eq i32 %t77, %a3
  store i1 %t81, ptr %l44, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb33
bb33:
  %t83 = load i1, ptr %l44, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3e69957d7270204c_dfbf9d9d846a9638)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v2, ptr %t12, %"compiler/source:Span" %a1, ptr %t14, { i64, ptr } %a3, i32 0)
  store ptr %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l16, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 12
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  store { i64, [2 x i64] } %t27, ptr %l2
  %t29 = load { i64, [2 x i64] }, ptr %l2
  %t31 = extractvalue { i64, [2 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t35 = getelementptr { i64 }, ptr %t34, i32 0, i32 0
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t47, i64 %t48)
  store i32 %t51, ptr %l29
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l30
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t58 = icmp sgt i64 %t56, 0
  store i1 %t58, ptr %l19, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9109cadfb541186e_2a46ab96c2b41f0a)
  unreachable
bb19:
  %t60 = load i1, ptr %l19, !tbaa !21
  store i1 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a1)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t14, ptr %l8
  br label %bb2
bb2:
  %t15 = load i1, ptr %l8, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejumpText(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Program", ptr %t5, i32 0, i32 2
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l10
  br label %bb1
bb1:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l15
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i32, ptr %l10, !tbaa !23
  %t30 = load i32, ptr %l15, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t28, i32 %t29, i32 %t30, i32 0, i32 0, i64 0)
  store i32 %t31, ptr %l16
  br label %bb3
bb3:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l16, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t32, i32 %t33)
  store { i64, ptr } %t34, ptr %l17
  br label %bb4
bb4:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambdaErrs(ptr %v0, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca ptr
  %l51 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l68 = alloca ptr
  %l73 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l84 = alloca i32
  %l89 = alloca i64
  %l90 = alloca i32
  %rv = alloca ptr
  %t191 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 15
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb6, label %bb7
bb6:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l3
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 1
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l5, !tbaa !29
  br label %bb8
bb7:
  br label %bb33
bb8:
  %t34 = load ptr, ptr %l5, !tbaa !29
  store ptr %t34, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t45, i32 0, i32 0
  %t47 = load i32, ptr %t46
  store i32 %t47, ptr %l6, !tbaa !23
  br label %bb13
bb12:
  br label %bb28
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Program", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l32
  br label %bb14
bb14:
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load i32, ptr %l32, !tbaa !23
  %t62 = icmp eq i32 %t60, %t59
  br i1 %t62, label %bb15, label %bb16
bb15:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 12
  %t70 = load i32, ptr %l6, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t69, i64 %t72)
  store ptr %t75, ptr %l41
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l41, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l45, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load ptr, ptr %l7, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Body", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t89, i32 %t93)
  store i32 %t96, ptr %l51
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load ptr, ptr %l7, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 2
  %t106 = load i32, ptr %t105, !tbaa !23
  %t109 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t102, i32 %t106)
  store i32 %t109, ptr %l57
  br label %bb20
bb20:
  %t110 = load i32, ptr %l2, !tbaa !23
  store i32 %t110, ptr %l58, !tbaa !23
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/check:Checker", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/generic:Program", ptr %t114, i32 0, i32 2
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t116, i32 %t120)
  store i32 %t123, ptr %l64
  br label %bb21
bb21:
  %t124 = load ptr, ptr %l45, !tbaa !29
  %t125 = load i32, ptr %l51, !tbaa !23
  %t126 = load i32, ptr %l57, !tbaa !23
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = load i32, ptr %l64, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t124, i32 %t125, i32 %t126, i32 %t127, i32 %t128, i64 0)
  store i32 %t129, ptr %l65
  br label %bb22
bb22:
  %t130 = load i32, ptr %l65, !tbaa !23
  %t131 = load ptr, ptr %l42, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  store i32 %t130, ptr %t132, !tbaa !23
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  store ptr %t138, ptr %l68, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l4, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l73
  br label %bb23
bb23:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l4, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l78
  br label %bb24
bb24:
  %t159 = load i32, ptr %l2, !tbaa !23
  store i32 %t159, ptr %l79, !tbaa !23
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = getelementptr %"compiler/generic:Program", ptr %t163, i32 0, i32 2
  %t166 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l84
  br label %bb25
bb25:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/generic:Program", ptr %t173, i32 0, i32 2
  %t176 = load i32, ptr %l4, !tbaa !23
  %t179 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t175, i32 %t176)
  store i64 %t179, ptr %l89
  br label %bb26
bb26:
  %t180 = load ptr, ptr %l68, !tbaa !29
  %t181 = load i32, ptr %l73, !tbaa !23
  %t182 = load i32, ptr %l78, !tbaa !23
  %t183 = load i32, ptr %l79, !tbaa !23
  %t184 = load i32, ptr %l84, !tbaa !23
  %t185 = load i64, ptr %l89, !tbaa !24
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t180, i32 %t181, i32 %t182, i32 %t183, i32 %t184, i64 %t185)
  store i32 %t186, ptr %l90
  br label %bb27
bb27:
  %t187 = load i32, ptr %l90, !tbaa !23
  %t188 = load %"compiler/source:Span", ptr %l3
  %t190 = load ptr, ptr %l5, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t191
  %t192 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 0
  store i64 15, ptr %t192
  %t194 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t188, 0
  %t196 = insertvalue { %"compiler/source:Span", i32, ptr } %t194, i32 %t187, 1
  %t198 = insertvalue { %"compiler/source:Span", i32, ptr } %t196, ptr %t190, 2
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t191
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  store ptr %t202, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t204 = load ptr, ptr %l1, !tbaa !29
  store ptr %t204, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_24473ecab934ff5a_e5063e673d38f936)
  unreachable
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t207 = load ptr, ptr %l1, !tbaa !29
  store ptr %t207, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ePush_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %t3, %"compiler/check:laneNode" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 39
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAssign(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/check:laneVals"
  %l11 = alloca i32
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca %"compiler/check:laneVals"
  %l23 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l6, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %t5, %"compiler/source:Span" %t6, ptr %t7)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  store ptr %a5, ptr %l17, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l20
  br label %bb3
bb3:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = load i32, ptr %l20, !tbaa !23
  %t23 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %t20, ptr %t21, i32 %t22)
  store ptr %t23, ptr %l21
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l21, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = call %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %s0)
  store %"compiler/check:laneVals" %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load %"compiler/check:laneVals", ptr %l22
  store %"compiler/check:laneVals" %t26, ptr %l9
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l23, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l24
  store %"compiler/source:Span" %a2, ptr %l25
  store i32 %a3, ptr %l26
  %t31 = load i32, ptr %l6, !tbaa !23
  store i32 %t31, ptr %l27, !tbaa !23
  %t32 = load i64, ptr %l7, !tbaa !24
  store i64 %t32, ptr %l28, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l8, !tbaa !29
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t33, ptr %t34)
  store i64 %t37, ptr %l31
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l23, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l24
  %t40 = load %"compiler/source:Span", ptr %l25
  %t41 = load i32, ptr %l26
  %t42 = load i32, ptr %l27, !tbaa !23
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %s0, ptr %t38, %"compiler/source:Span" %t39, %"compiler/source:Span" %t40, i32 %t41, i32 %t42, i64 %t43, i64 %t44, ptr %l9)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca [2 x i64]
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca %"compiler/check:laneNode"
  %l22 = alloca i32
  %l26 = alloca %"compiler/check:laneNode"
  %l28 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i32
  %l52 = alloca %"compiler/check:laneNode"
  %l53 = alloca i64
  %l54 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a4)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t7, ptr %a5)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  %t14 = load i32, ptr %l3
  store i32 %t14, ptr %l17
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 39
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t17, i64 %t18)
  store %"compiler/check:laneNode" %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = getelementptr %"compiler/check:laneNode", ptr %l21, i32 0, i32 8
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l22, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 39
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t26, i64 %t27)
  store %"compiler/check:laneNode" %t30, ptr %l26
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/check:laneNode", ptr %l26, i32 0, i32 8
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i32, ptr %l17
  %t35 = load i32, ptr %l22, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %t33, i32 %t34, i32 %t35, i32 %t32)
  store i32 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i32, ptr %l28, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = insertvalue [2 x i64] undef, i64 %t39, 0
  %t44 = insertvalue [2 x i64] %t42, i64 %t40, 1
  store [2 x i64] %t44, ptr %l9
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t47, ptr %l33
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  store i64 %t49, ptr %l35, !tbaa !24
  %t50 = load i32, ptr %l3
  store i32 %t50, ptr %l36
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l37
  %t52 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t52, ptr %l38
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l39, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l40, !tbaa !24
  %t55 = load i32, ptr %l8, !tbaa !23
  store i32 %t55, ptr %l41, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l9, 1
  %t60 = load %"compiler/source:Span", ptr %l2
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t59, %"compiler/source:Span" %t60)
  store i64 %t64, ptr %l46
  br label %bb6
bb6:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = insertvalue { i64, ptr } undef, i64 2, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %l9, 1
  %t69 = load i32, ptr %l8, !tbaa !23
  %t73 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t68, i32 %t69)
  store i32 %t73, ptr %l51
  br label %bb7
bb7:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i32, ptr %l36
  %t76 = load %"compiler/source:Span", ptr %l37
  %t77 = load %"compiler/source:Span", ptr %l38
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = load i64, ptr %l40, !tbaa !24
  %t80 = load i32, ptr %l41, !tbaa !23
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = load i32, ptr %l51, !tbaa !23
  %t83 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t74, i32 %t75, %"compiler/source:Span" %t76, %"compiler/source:Span" %t77, i64 %t78, i64 %t79, i64 -1, ptr null, i32 %t80, i64 %t81, i32 %t82)
  store %"compiler/check:laneNode" %t83, ptr %l52
  br label %bb8
bb8:
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load %"compiler/check:laneNode", ptr %l52
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t84, %"compiler/check:laneNode" %t85)
  store i64 %t86, ptr %l53
  br label %bb9
bb9:
  %t87 = load ptr, ptr %l32, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i64 %t89)
  store ptr %t90, ptr %l54
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load ptr, ptr %l54, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l16 = alloca { i64, ptr }
  %l22 = alloca %"compiler/check:laneNode"
  %l28 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l3, !tbaa !24
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 39
  %t29 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s2, ptr %t25, i64 %t21)
  store %"compiler/check:laneNode" %t29, ptr %l22
  br label %bb5
bb5:
  %t30 = getelementptr %"compiler/check:laneNode", ptr %l22, i32 0, i32 9
  %t31 = load i64, ptr %t30, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t33 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp ne i64 %t41, %t42
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l28, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l33
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %s4, i64 %t50, i64 %t51)
  store %"compiler/msgs:Msg" %t54, ptr %l36
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t55 = load ptr, ptr %l32, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l33
  %t57 = load %"compiler/msgs:Msg", ptr %l36
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l37
  br label %bb15
bb15:
  %t59 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t59, ptr %rv
  br label %ret
bb16:
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb1
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  store i64 %t67, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneTarget(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca i32
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l22 = alloca i32
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca ptr
  %rv = alloca i64
  %t49 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l8, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t8)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = load i32, ptr %l10, !tbaa !23
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = load i32, ptr %l11, !tbaa !23
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t15, i32 %t16, i64 %t14)
  store i32 %t18, ptr %l13
  br label %bb3
bb3:
  %t19 = load i32, ptr %l13, !tbaa !23
  store i32 %t19, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t22 = load i32, ptr %l3, !tbaa !23
  %t26 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t20, %"compiler/source:Span" %t21, i32 %t22)
  store i64 %t26, ptr %l17
  br label %bb4
bb4:
  %t27 = load i64, ptr %l17, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l19
  %t30 = load i64, ptr %l4, !tbaa !24
  %t32 = trunc i64 %t30 to i32
  store i32 %t32, ptr %l22, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l23, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t35, %"compiler/source:Span" %t36, ptr %t37)
  store ptr %t41, ptr %l27
  br label %bb5
bb5:
  %t42 = load i32, ptr %l3, !tbaa !23
  %t43 = load %"compiler/source:Span", ptr %l1
  %t44 = load ptr, ptr %l23, !tbaa !29
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t48 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t44, ptr %t45, i32 %t42, %"compiler/source:Span" %t43)
  store ptr %t48, ptr %l30
  br label %bb6
bb6:
  store { i64, [3 x i64] } zeroinitializer, ptr %t49
  %t50 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 0
  store i64 0, ptr %t50
  %t51 = load %"compiler/source:Span", ptr %l19
  %t52 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t51, 0
  %t53 = load i32, ptr %l22, !tbaa !23
  %t54 = insertvalue { %"compiler/source:Span", i32, ptr } %t52, i32 %t53, 1
  %t55 = load ptr, ptr %l30, !tbaa !29
  %t56 = insertvalue { %"compiler/source:Span", i32, ptr } %t54, ptr %t55, 2
  %t57 = getelementptr { i64, [3 x i64] }, ptr %t49, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t56, ptr %t57
  %t58 = load { i64, [3 x i64] }, ptr %t49
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t58, ptr %t60
  %t61 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t61, ptr %t60)
  br label %bb7
bb7:
  %t63 = load i64, ptr %l4, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca [1 x i64]
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca %"compiler/check:laneNode"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l27 = alloca i64
  %l28 = alloca i32
  %l32 = alloca %"compiler/check:laneNode"
  %l33 = alloca i64
  %l38 = alloca i32
  %l39 = alloca %"compiler/check:laneNode"
  %l40 = alloca i64
  %l41 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l10, !tbaa !29
  %t8 = load i32, ptr %l2
  store i32 %t8, ptr %l11
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 39
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t12)
  store %"compiler/check:laneNode" %t15, ptr %l15
  br label %bb2
bb2:
  %t16 = getelementptr %"compiler/check:laneNode", ptr %l15, i32 0, i32 8
  %t17 = load i32, ptr %t16, !tbaa !23
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = load i32, ptr %l11
  %t21 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %t18, i32 %t19, i32 %t17)
  store i32 %t21, ptr %l17
  br label %bb3
bb3:
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = insertvalue [1 x i64] undef, i64 %t23, 0
  store [1 x i64] %t25, ptr %l6
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l20, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i32, ptr %l2
  store i32 %t31, ptr %l24
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l25
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l26
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  store i32 %t35, ptr %l28, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 39
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %s0, ptr %t38, i64 %t39)
  store %"compiler/check:laneNode" %t42, ptr %l32
  br label %bb4
bb4:
  %t43 = getelementptr %"compiler/check:laneNode", ptr %l32, i32 0, i32 9
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = insertvalue { i64, ptr } undef, i64 1, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %l6, 1
  %t49 = load i32, ptr %l5, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t45, { i64, ptr } %t48, i32 %t49)
  store i32 %t53, ptr %l38
  br label %bb5
bb5:
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = load i32, ptr %l24
  %t56 = load %"compiler/source:Span", ptr %l25
  %t57 = load %"compiler/source:Span", ptr %l26
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = load i32, ptr %l28, !tbaa !23
  %t60 = load i64, ptr %l33, !tbaa !24
  %t61 = load i32, ptr %l38, !tbaa !23
  %t62 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t54, i32 %t55, %"compiler/source:Span" %t56, %"compiler/source:Span" %t57, i64 %t58, i64 -1, i64 -1, ptr null, i32 %t59, i64 %t60, i32 %t61)
  store %"compiler/check:laneNode" %t62, ptr %l39
  br label %bb6
bb6:
  %t63 = load ptr, ptr %l22, !tbaa !29
  %t64 = load %"compiler/check:laneNode", ptr %l39
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t63, %"compiler/check:laneNode" %t64)
  store i64 %t65, ptr %l40
  br label %bb7
bb7:
  %t66 = load ptr, ptr %l20, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l21
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t66, %"compiler/source:Span" %t67, i64 %t68)
  store ptr %t69, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l41, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  %t14 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l13
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l5, !tbaa !24
  br label %bb3
bb3:
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t38, i32 %t34)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb3
bb9:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItem(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/check:reflList"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l15 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i64
  %l32 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/check:reflList" %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load %"compiler/source:Span", ptr %l1
  %t3 = load %"compiler/check:reflList", ptr %l2
  %t7 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %s0, ptr %t1, %"compiler/source:Span" %t2, %"compiler/check:reflList" %t3)
  store { i64, ptr } %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  %t9 = getelementptr %"compiler/check:reflList", ptr %l2, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t16, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = icmp sge i64 %t22, %t25
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t32, ptr %l21
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t39 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexRange(ptr %s2, i64 %t33, i64 %t36)
  store %"compiler/msgs:Msg" %t39, ptr %l25
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l21
  %t42 = load %"compiler/msgs:Msg", ptr %l25
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t40, %"compiler/source:Span" %t41, %"compiler/msgs:Msg" %t42)
  store i64 %t43, ptr %l26
  br label %bb11
bb11:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t44, ptr %rv
  br label %ret
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/check:reflList", ptr %l2
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i64, ptr %t51, i64 %t48
  %t53 = load i64, ptr %t52, !tbaa !34
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %t46, %"compiler/check:reflList" %t47, i64 %t53)
  store i32 %t57, ptr %l32
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l32, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l21 = alloca i1
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca i1
  %l27 = alloca %"compiler/source:Span"
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l47 = alloca i1
  %l49 = alloca %"compiler/source:Span"
  %l54 = alloca i1
  %l57 = alloca i1
  %l58 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t18, i32 0, i32 1
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t24, i32 0, i32 2
  %t26 = load i1, ptr %t25
  store i1 %t26, ptr %l5, !tbaa !21
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t30, i32 0, i32 3
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  br label %bb43
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load i1, ptr %l5, !tbaa !21
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t38 = load i1, ptr %l6, !tbaa !21
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 -1, i32 -1)
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t42 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t42, ptr %rv
  br label %ret
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l26
  br label %bb13
bb13:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 -1, i32 -1)
  store %"compiler/source:Span" %t49, ptr %l27
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  %t50 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t50, ptr %rv
  br label %ret
bb17:
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l34
  br label %bb20
bb19:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb25
bb20:
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb24
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb23
bb23:
  %t73 = load i32, ptr %l40
  %t75 = trunc i64 25 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l35, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l35, !tbaa !21
  store i1 %t78, ptr %l31, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l31, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t80 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t80, ptr %l43
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s1)
  %t81 = load %"compiler/source:Span", ptr %l43
  store %"compiler/source:Span" %t81, ptr %rv
  br label %ret
bb29:
  %t82 = load i32, ptr %l2, !tbaa !23
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp eq i32 %t82, %t83
  br i1 %t86, label %bb30, label %bb31
bb30:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l49
  br label %bb32
bb31:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb32:
  %t91 = getelementptr %"compiler/source:Span", ptr %l49, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t93 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t96 = add i32 %t94, 3
  %t99 = icmp sgt i32 %t92, %t96
  store i1 %t99, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l47, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l57
  br label %bb36
bb35:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb37
bb36:
  %t107 = load i1, ptr %l57, !tbaa !21
  store i1 %t107, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t108 = load i1, ptr %l54, !tbaa !21
  br i1 %t108, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 -1, i32 -1)
  store %"compiler/source:Span" %t109, ptr %l58
  br label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  %t110 = load %"compiler/source:Span", ptr %l58
  store %"compiler/source:Span" %t110, ptr %rv
  br label %ret
bb41:
  %t111 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t112 = load i32, ptr %t111, !tbaa !23
  %t113 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = add i32 %t114, 3
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t112, i32 %t116)
  store %"compiler/source:Span" %t119, ptr %l62
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s1)
  %t120 = load %"compiler/source:Span", ptr %l62
  store %"compiler/source:Span" %t120, ptr %rv
  br label %ret
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 -1, i32 -1)
  store %"compiler/source:Span" %t121, ptr %l63
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  %t122 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t122, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_5a62b0635aab9a02_96142af7f6ac351e)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l31 = alloca i1
  %l34 = alloca i64
  %l39 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca %"compiler/check:fixedInit"
  %l63 = alloca ptr
  %l65 = alloca ptr
  %l69 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l70 = alloca %"compiler/check:fixedInit"
  %l71 = alloca i32
  %l74 = alloca ptr
  %l79 = alloca ptr
  %l84 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l103 = alloca ptr
  %l106 = alloca i32
  %l107 = alloca ptr
  %l110 = alloca i32
  %l111 = alloca i32
  %l112 = alloca i1
  %l116 = alloca i1
  %l118 = alloca ptr
  %l125 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l144 = alloca { i64, ptr }
  %l146 = alloca %"compiler/msgs:Msg"
  %l147 = alloca i64
  %l150 = alloca ptr
  %l158 = alloca ptr
  %l160 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca %"compiler/source:Span"
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l176 = alloca i32
  %l180 = alloca ptr
  %l191 = alloca ptr
  %l198 = alloca ptr
  %l202 = alloca i1
  %l205 = alloca { i64, ptr }
  %l206 = alloca i1
  %l210 = alloca ptr
  %l215 = alloca ptr
  %l217 = alloca ptr
  %l222 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l223 = alloca i1
  %l225 = alloca i1
  %l227 = alloca ptr
  %l229 = alloca ptr
  %l234 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l235 = alloca i1
  %l237 = alloca i1
  %l242 = alloca i1
  %l244 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l252 = alloca ptr
  %l253 = alloca %"compiler/source:Span"
  %l256 = alloca { i64, ptr }
  %l258 = alloca %"compiler/msgs:Msg"
  %l259 = alloca i64
  %l264 = alloca i32
  %l267 = alloca ptr
  %l268 = alloca %"compiler/source:Span"
  %l271 = alloca { i64, ptr }
  %l274 = alloca %"compiler/msgs:Msg"
  %l275 = alloca i64
  %l276 = alloca ptr
  %l277 = alloca %"compiler/source:Span"
  %l280 = alloca { i64, ptr }
  %l283 = alloca %"compiler/msgs:Msg"
  %l284 = alloca i64
  %l286 = alloca ptr
  %l288 = alloca ptr
  %l293 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l296 = alloca ptr
  %l300 = alloca ptr
  %l301 = alloca %"compiler/source:Span"
  %l304 = alloca { i64, ptr }
  %l306 = alloca %"compiler/msgs:Msg"
  %l307 = alloca i64
  %l310 = alloca ptr
  %l319 = alloca i32
  %l322 = alloca i1
  %l325 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca %"compiler/source:Span"
  %l331 = alloca { i64, ptr }
  %l333 = alloca %"compiler/msgs:Msg"
  %l334 = alloca i64
  %l337 = alloca ptr
  %l341 = alloca ptr
  %l342 = alloca %"compiler/source:Span"
  %l347 = alloca i64
  %l351 = alloca ptr
  %l355 = alloca i32
  %l357 = alloca ptr
  %l361 = alloca i32
  %l362 = alloca i32
  %l367 = alloca ptr
  %l368 = alloca %"compiler/source:Span"
  %l371 = alloca { i64, ptr }
  %l372 = alloca %"compiler/msgs:Msg"
  %l373 = alloca i64
  %l376 = alloca ptr
  %l382 = alloca ptr
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca ptr
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t642 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l18, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l20
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l20, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l24
  br label %bb2
bb2:
  %t21 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t21, ptr %l5
  %t22 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t23 = load i32, ptr %t22
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %t28, i32 %t29)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t32 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t33 = load i32, ptr %t32
  %t35 = trunc i64 1 to i32
  %t36 = icmp eq i32 %t33, %t35
  br i1 %t36, label %bb7, label %bb8
bb7:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l34
  br label %bb9
bb8:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  %t43 = load i64, ptr %l34, !tbaa !24
  %t44 = icmp slt i64 %t43, 0
  store i1 %t44, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l31, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i32, ptr %l2, !tbaa !23
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflName(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i32 %t49)
  store ptr %t53, ptr %l39
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t54 = load ptr, ptr %l39, !tbaa !29
  store ptr %t54, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t61, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t65 = load i32, ptr %t64
  %t67 = trunc i64 1 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb18, label %bb19
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t70)
  store ptr %t72, ptr %l48
  br label %bb20
bb19:
  br label %bb89
bb20:
  %t73 = load ptr, ptr %l48, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 42
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t75, i32 %t76)
  store i1 %t79, ptr %l52
  br label %bb21
bb21:
  %t80 = load i1, ptr %l52, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t81)
  store ptr %t83, ptr %l55
  br label %bb24
bb23:
  br label %bb37
bb24:
  %t84 = load ptr, ptr %l55, !tbaa !29
  %t86 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 42
  %t87 = load i32, ptr %l2, !tbaa !23
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t86, i32 %t87)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l60
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb26, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l59
  br label %bb25
bb25:
  %t95 = load i64, ptr %l59, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  br label %bb28
bb26:
  br label %bb27
bb27:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb28
bb28:
  %t96 = load i64, ptr %l53, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 111
  store ptr %t99, ptr %l63, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t100)
  store ptr %t102, ptr %l65
  br label %bb29
bb29:
  %t103 = load ptr, ptr %l65, !tbaa !29
  %t105 = getelementptr %"compiler/check:frame", ptr %t103, i32 0, i32 43
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l69
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l63, !tbaa !29
  %t112 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l69
  %t113 = call { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v0, ptr %t111, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t112)
  %t114 = extractvalue { i32, %"compiler/check:fixedInit" } %t113, 1
  %t115 = extractvalue { i32, %"compiler/check:fixedInit" } %t113, 0
  store i32 %t115, ptr %l71
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb32, label %ok.117, !prof !99
ok.117:
  store %"compiler/check:fixedInit" %t114, ptr %l70
  br label %bb31
bb31:
  %t118 = load %"compiler/check:fixedInit", ptr %l70
  store %"compiler/check:fixedInit" %t118, ptr %l61
  br label %bb35
bb32:
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load %"compiler/source:Span", ptr %l1
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t119, %"compiler/source:Span" %t120)
  store ptr %t123, ptr %l74
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l74, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t124, ptr %rv
  br label %ret
bb35:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t126, ptr %lp8
  %t127 = load %"compiler/check:fixedInit", ptr %l61
  %t128 = load ptr, ptr %lp8
  store %"compiler/check:fixedInit" %t127, ptr %t128
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load ptr, ptr %lp8
  %t131 = getelementptr %"compiler/check:fixedInit", ptr %t130, i32 0, i32 0
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t133 = load ptr, ptr %lp8
  %t134 = getelementptr %"compiler/check:fixedInit", ptr %t133, i32 0, i32 1
  %t135 = load i32, ptr %t134, !tbaa !23
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t129, ptr %t132, i32 %t135)
  store ptr %t139, ptr %l79
  br label %bb36
bb36:
  %t140 = load ptr, ptr %l79, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t140, ptr %rv
  br label %ret
bb37:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l2, !tbaa !23
  %t144 = load %"compiler/source:Span", ptr %l1
  %t148 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t142, i32 %t143, %"compiler/source:Span" %t144)
  store i64 %t148, ptr %l84
  br label %bb38
bb38:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l9, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l2, !tbaa !23
  %t154 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t150, i32 %t151)
  store i64 %t154, ptr %l87
  br label %bb39
bb39:
  %t155 = load i64, ptr %l87, !tbaa !24
  store i64 %t155, ptr %l10, !tbaa !24
  %t156 = load i64, ptr %l10, !tbaa !24
  %t158 = icmp sge i64 %t156, 0
  br i1 %t158, label %bb40, label %bb41
bb40:
  %t160 = load i64, ptr %l9, !tbaa !24
  %t161 = load i64, ptr %l10, !tbaa !24
  %t164 = icmp ne i64 %t160, %t161
  store i1 %t164, ptr %l90, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb42
bb42:
  %t166 = load i1, ptr %l90, !tbaa !21
  br i1 %t166, label %bb43, label %bb44
bb43:
  br i1 %a4, label %bb45, label %bb46
bb44:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb55
bb45:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb54
bb46:
  %t169 = load i32, ptr %l3, !tbaa !23
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t173 = icmp ne i32 %t169, %t170
  br i1 %t173, label %bb47, label %bb48
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t180 = getelementptr %"compiler/generic:Program", ptr %t178, i32 0, i32 2
  store ptr %t180, ptr %l103, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l3, !tbaa !23
  %t185 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l106
  br label %bb49
bb48:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb53
bb49:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l107, !tbaa !29
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l10, !tbaa !24
  %t191 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t187, i64 %t188)
  store i32 %t191, ptr %l110
  br label %bb50
bb50:
  %t192 = load ptr, ptr %l107, !tbaa !29
  %t193 = load i32, ptr %l110, !tbaa !23
  %t194 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t194, ptr %l111
  br label %bb51
bb51:
  %t195 = load ptr, ptr %l103, !tbaa !29
  %t196 = load i32, ptr %l106, !tbaa !23
  %t197 = load i32, ptr %l111, !tbaa !23
  %t198 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t195, i32 %t196, i32 %t197)
  store i1 %t198, ptr %l112
  br label %bb52
bb52:
  %t199 = load i1, ptr %l112, !tbaa !21
  store i1 %t199, ptr %l100, !tbaa !21
  br label %bb53
bb53:
  %t200 = load i1, ptr %l100, !tbaa !21
  store i1 %t200, ptr %l96, !tbaa !21
  br label %bb54
bb54:
  %t201 = load i1, ptr %l96, !tbaa !21
  store i1 %t201, ptr %l94, !tbaa !21
  br label %bb55
bb55:
  %t202 = load i1, ptr %l94, !tbaa !21
  br i1 %t202, label %bb56, label %bb57
bb56:
  %t203 = load i64, ptr %l10, !tbaa !24
  store i64 %t203, ptr %l9, !tbaa !24
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t205 = load i64, ptr %l9, !tbaa !24
  %t207 = icmp slt i64 %t205, 0
  br i1 %t207, label %bb59, label %bb60
bb59:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t209)
  store ptr %t211, ptr %l118
  br label %bb61
bb60:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb62
bb61:
  %t212 = load ptr, ptr %l118, !tbaa !29
  %t214 = getelementptr %"compiler/check:frame", ptr %t212, i32 0, i32 29
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = icmp sge i64 %t215, 0
  store i1 %t217, ptr %l116, !tbaa !21
  br label %bb62
bb62:
  %t219 = load i1, ptr %l116, !tbaa !21
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  %t222 = load i32, ptr %l2, !tbaa !23
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %t220, %"compiler/source:Span" %t221, i32 %t222)
  store ptr %t226, ptr %l125
  br label %bb65
bb64:
  br label %bb70
bb65:
  %t227 = load ptr, ptr %l125, !tbaa !29
  store ptr %t227, ptr %l11, !tbaa !29
  %t228 = load ptr, ptr %l11, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  %t232 = xor i1 %t230, true
  br i1 %t232, label %bb66, label %bb67
bb66:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load ptr, ptr %l11, !tbaa !29
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t234, %"compiler/source:Span" %t235, ptr %t236)
  store ptr %t240, ptr %l132
  br label %bb68
bb67:
  br label %bb69
bb68:
  %t241 = load ptr, ptr %l132, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t241, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = icmp slt i64 %t243, 0
  br i1 %t245, label %bb71, label %bb72
bb71:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/check:Checker", ptr %t247, i32 0, i32 105
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = icmp sgt i64 %t250, 0
  store i1 %t252, ptr %l136, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb73
bb73:
  %t254 = load i1, ptr %l136, !tbaa !21
  br i1 %t254, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l140, !tbaa !29
  %t256 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t256, ptr %l141
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i32, ptr %l2, !tbaa !23
  %t261 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s10, ptr %t257, i32 %t258)
  store { i64, ptr } %t261, ptr %l144
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t262 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = extractvalue { i64, ptr } %t262, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t270 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeLocal(ptr %s10, ptr %s10, { i64, ptr } %t268)
  store %"compiler/msgs:Msg" %t270, ptr %l146
  br label %bb77
bb77:
  %t271 = load ptr, ptr %l140, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l141
  %t273 = load %"compiler/msgs:Msg", ptr %l146
  %t274 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t271, %"compiler/source:Span" %t272, %"compiler/msgs:Msg" %t273)
  store i64 %t274, ptr %l147
  br label %bb78
bb78:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t276 = load %"compiler/source:Span", ptr %l1
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t275, %"compiler/source:Span" %t276)
  store ptr %t279, ptr %l150
  br label %bb79
bb79:
  %t280 = load ptr, ptr %l150, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t280, ptr %rv
  br label %ret
bb80:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t284 = icmp slt i64 %t282, 0
  br i1 %t284, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s11
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s11, ptr %t286, %"compiler/source:Span" %t287, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load %"compiler/source:Span", ptr %l1
  %t294 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t290, %"compiler/source:Span" %t291)
  store ptr %t294, ptr %l158
  br label %bb84
bb84:
  %t295 = load ptr, ptr %l158, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t295, ptr %rv
  br label %ret
bb85:
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l160, !tbaa !29
  %t298 = load ptr, ptr %l0, !tbaa !29
  store ptr %t298, ptr %l161, !tbaa !29
  %t299 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t299, ptr %l162
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load %"compiler/source:Span", ptr %l1
  %t302 = load i64, ptr %l9, !tbaa !24
  %t306 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %t300, %"compiler/source:Span" %t301, i64 %t302)
  store ptr %t306, ptr %l166
  br label %bb86
bb86:
  %t307 = load ptr, ptr %l161, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l162
  %t309 = load ptr, ptr %l166, !tbaa !29
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t307, %"compiler/source:Span" %t308, ptr %t309)
  store ptr %t310, ptr %l167
  br label %bb87
bb87:
  %t311 = load i32, ptr %l2, !tbaa !23
  %t312 = load ptr, ptr %l160, !tbaa !29
  %t313 = load ptr, ptr %l167, !tbaa !29
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNarrowed(ptr %v0, ptr %t312, ptr %t313, i32 %t311)
  store ptr %t315, ptr %l169
  br label %bb88
bb88:
  %t316 = load ptr, ptr %l169, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t316, ptr %rv
  br label %ret
bb89:
  %t318 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t319 = load i32, ptr %t318
  %t321 = trunc i64 2 to i32
  %t322 = icmp eq i32 %t319, %t321
  br i1 %t322, label %bb90, label %bb91
bb90:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = load i32, ptr %l2, !tbaa !23
  %t331 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %t324, i64 %t326, i32 %t327)
  store i32 %t331, ptr %l176
  br label %bb92
bb91:
  br label %bb97
bb92:
  %t332 = load i32, ptr %l176, !tbaa !23
  store i32 %t332, ptr %l12, !tbaa !23
  %t333 = load i32, ptr %l12, !tbaa !23
  %t334 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t337 = icmp eq i32 %t333, %t334
  br i1 %t337, label %bb93, label %bb94
bb93:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l180, !tbaa !29
  %t340 = load ptr, ptr %l180, !tbaa !29
  %t341 = getelementptr %"compiler/check:Checker", ptr %t340, i32 0, i32 108
  %t342 = load i64, ptr %t341, !tbaa !24
  %t344 = add i64 %t342, 1
  %t346 = load ptr, ptr %l180, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 108
  store i64 %t344, ptr %t347, !tbaa !24
  br label %bb95
bb94:
  br label %bb95
bb95:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load %"compiler/source:Span", ptr %l1
  %t350 = load %"compiler/source:Span", ptr %l1
  %t351 = load i32, ptr %l12, !tbaa !23
  %t352 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 1, ptr %t356
  %t358 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t350, 0
  %t360 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t358, i32 %t351, 1
  %t362 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t360, i64 %t353, 2
  %t364 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t362, i32 %t354, 3
  %t365 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t364, ptr %t365
  %t366 = load { i64, [4 x i64] }, ptr %t355
  %t368 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t366, ptr %t368
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t348, %"compiler/source:Span" %t349, ptr %t368)
  store ptr %t372, ptr %l191
  br label %bb96
bb96:
  %t373 = load ptr, ptr %l191, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t373, ptr %rv
  br label %ret
bb97:
  %t375 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t376 = load i32, ptr %t375
  %t378 = trunc i64 6 to i32
  %t379 = icmp eq i32 %t376, %t378
  br i1 %t379, label %bb98, label %bb99
bb98:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load %"compiler/source:Span", ptr %l1
  %t383 = load i32, ptr %l2, !tbaa !23
  %t387 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %t381, %"compiler/source:Span" %t382, i32 %t383)
  store ptr %t387, ptr %l198
  br label %bb100
bb99:
  br label %bb101
bb100:
  %t388 = load ptr, ptr %l198, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t388, ptr %rv
  br label %ret
bb101:
  %t390 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t391 = load i32, ptr %t390
  %t393 = trunc i64 0 to i32
  %t394 = icmp eq i32 %t391, %t393
  br i1 %t394, label %bb102, label %bb103
bb102:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load i32, ptr %l2, !tbaa !23
  %t400 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t396, i32 %t397)
  store { i64, ptr } %t400, ptr %l205
  br label %bb104
bb103:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb106
bb104:
  %t401 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t402 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t402, ptr %l206
  br label %bb105
bb105:
  %t403 = load i1, ptr %l206, !tbaa !21
  store i1 %t403, ptr %l202, !tbaa !21
  br label %bb106
bb106:
  %t404 = load i1, ptr %l202, !tbaa !21
  br i1 %t404, label %bb107, label %bb108
bb107:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t407 = load i32, ptr %l3, !tbaa !23
  %t411 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %t405, %"compiler/source:Span" %t406, i32 %t407)
  store ptr %t411, ptr %l210
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t412 = load ptr, ptr %l210, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t412, ptr %rv
  br label %ret
bb110:
  %t414 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t415 = load i32, ptr %t414
  %t417 = trunc i64 0 to i32
  %t418 = icmp eq i32 %t415, %t417
  br i1 %t418, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s16
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t420, i32 0, i32 75
  store ptr %t422, ptr %l215, !tbaa !29
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t423)
  store ptr %t425, ptr %l217
  br label %bb113
bb112:
  br label %bb151
bb113:
  %t426 = load ptr, ptr %l217, !tbaa !29
  %t428 = getelementptr %"compiler/check:frame", ptr %t426, i32 0, i32 0
  %t429 = load i64, ptr %t428, !tbaa !24
  %t430 = load i32, ptr %l2, !tbaa !23
  %t432 = sext i32 %t430 to i64
  %t435 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s16, i64 %t429, i64 %t432)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t435, ptr %l222
  br label %bb114
bb114:
  %t436 = load ptr, ptr %l215, !tbaa !29
  %t437 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l222
  %t438 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t436, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t437)
  store i1 %t438, ptr %l223
  br label %bb115
bb115:
  %t439 = load i1, ptr %l223, !tbaa !21
  %t440 = xor i1 %t439, true
  br i1 %t440, label %bb116, label %bb117
bb116:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 74
  store ptr %t444, ptr %l227, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t445)
  store ptr %t447, ptr %l229
  br label %bb118
bb117:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb121
bb118:
  %t448 = load ptr, ptr %l229, !tbaa !29
  %t450 = getelementptr %"compiler/check:frame", ptr %t448, i32 0, i32 1
  %t451 = load i64, ptr %t450, !tbaa !24
  %t452 = load i32, ptr %l2, !tbaa !23
  %t454 = sext i32 %t452 to i64
  %t457 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s16, i64 %t451, i64 %t454)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t457, ptr %l234
  br label %bb119
bb119:
  %t458 = load ptr, ptr %l227, !tbaa !29
  %t459 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l234
  %t460 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t458, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t459)
  store i1 %t460, ptr %l235
  br label %bb120
bb120:
  %t461 = load i1, ptr %l235, !tbaa !21
  %t462 = xor i1 %t461, true
  store i1 %t462, ptr %l225, !tbaa !21
  br label %bb121
bb121:
  %t464 = load i1, ptr %l225, !tbaa !21
  br i1 %t464, label %bb122, label %bb123
bb122:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/check:Checker", ptr %t465, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !29
  %t470 = getelementptr %"compiler/generic:Program", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t472 = load i32, ptr %l2, !tbaa !23
  %t475 = call i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %t471, i32 %t472)
  store i1 %t475, ptr %l242
  br label %bb124
bb123:
  store i1 false, ptr %l237, !tbaa !21
  br label %bb125
bb124:
  %t476 = load i1, ptr %l242, !tbaa !21
  %t477 = xor i1 %t476, true
  store i1 %t477, ptr %l237, !tbaa !21
  br label %bb125
bb125:
  %t479 = load i1, ptr %l237, !tbaa !21
  br i1 %t479, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s17
  %t480 = load ptr, ptr %l0, !tbaa !29
  store ptr %t480, ptr %l244, !tbaa !29
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load i32, ptr %l2, !tbaa !23
  %t485 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t481, i32 %t482)
  store { i64, ptr } %t485, ptr %l247
  br label %bb128
bb127:
  br label %bb149
bb128:
  %t486 = load ptr, ptr %l244, !tbaa !29
  %t487 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t488 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s17, ptr %t486, { i64, ptr } %t487, i1 true)
  store { i64, ptr } %t488, ptr %l248
  br label %bb129
bb129:
  %t489 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t489, ptr %l13, !tbaa !27
  %t490 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t494 = icmp eq i64 %t492, 0
  br i1 %t494, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s18
  %t496 = load ptr, ptr %l0, !tbaa !29
  store ptr %t496, ptr %l252, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t497, ptr %l253
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load i32, ptr %l2, !tbaa !23
  %t502 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s18, ptr %t498, i32 %t499)
  store { i64, ptr } %t502, ptr %l256
  br label %bb132
bb131:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !29
  %t508 = getelementptr %"compiler/generic:Program", ptr %t506, i32 0, i32 2
  %t509 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t512 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s17, ptr %t508, { i64, ptr } %t509)
  store i32 %t512, ptr %l264
  br label %bb135
bb132:
  %t513 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t514 = extractvalue { i64, ptr } %t513, 0
  %t515 = extractvalue { i64, ptr } %t513, 1
  %t516 = mul i64 %t514, 1
  %t517 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t516)
  call void @llvm.memcpy.p0.p0.i64(ptr %t517, ptr %t515, i64 %t516, i1 false)
  %t518 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t517, 1
  %t521 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %s18, ptr %s18, { i64, ptr } %t519)
  store %"compiler/msgs:Msg" %t521, ptr %l258
  br label %bb133
bb133:
  %t522 = load ptr, ptr %l252, !tbaa !29
  %t523 = load %"compiler/source:Span", ptr %l253
  %t524 = load %"compiler/msgs:Msg", ptr %l258
  %t525 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t522, %"compiler/source:Span" %t523, %"compiler/msgs:Msg" %t524)
  store i64 %t525, ptr %l259
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s18)
  br label %bb145
bb135:
  %t526 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t527 = load i32, ptr %l264, !tbaa !23
  %t529 = icmp ne i32 %t527, %t526
  br i1 %t529, label %bb136, label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s20
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l267, !tbaa !29
  %t532 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t532, ptr %l268
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l2, !tbaa !23
  %t537 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s20, ptr %t533, i32 %t534)
  store { i64, ptr } %t537, ptr %l271
  br label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s21
  %t538 = load ptr, ptr %l0, !tbaa !29
  store ptr %t538, ptr %l276, !tbaa !29
  %t539 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t539, ptr %l277
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load i32, ptr %l2, !tbaa !23
  %t544 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s21, ptr %t540, i32 %t541)
  store { i64, ptr } %t544, ptr %l280
  br label %bb141
bb138:
  %t545 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t546 = extractvalue { i64, ptr } %t545, 0
  %t547 = extractvalue { i64, ptr } %t545, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  %t552 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t555 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s20, ptr %s17, ptr %s20, { i64, ptr } %t551, { i64, ptr } %t552)
  store %"compiler/msgs:Msg" %t555, ptr %l274
  br label %bb139
bb139:
  %t556 = load ptr, ptr %l267, !tbaa !29
  %t557 = load %"compiler/source:Span", ptr %l268
  %t558 = load %"compiler/msgs:Msg", ptr %l274
  %t559 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t556, %"compiler/source:Span" %t557, %"compiler/msgs:Msg" %t558)
  store i64 %t559, ptr %l275
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s20)
  br label %bb144
bb141:
  %t560 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 0
  %t562 = extractvalue { i64, ptr } %t560, 1
  %t563 = mul i64 %t561, 1
  %t564 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t563)
  call void @llvm.memcpy.p0.p0.i64(ptr %t564, ptr %t562, i64 %t563, i1 false)
  %t565 = insertvalue { i64, ptr } undef, i64 %t561, 0
  %t566 = insertvalue { i64, ptr } %t565, ptr %t564, 1
  %t567 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t570 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %s21, ptr %s17, ptr %s21, { i64, ptr } %t566, { i64, ptr } %t567)
  store %"compiler/msgs:Msg" %t570, ptr %l283
  br label %bb142
bb142:
  %t571 = load ptr, ptr %l276, !tbaa !29
  %t572 = load %"compiler/source:Span", ptr %l277
  %t573 = load %"compiler/msgs:Msg", ptr %l283
  %t574 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t571, %"compiler/source:Span" %t572, %"compiler/msgs:Msg" %t573)
  store i64 %t574, ptr %l284
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s21)
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = getelementptr %"compiler/check:Checker", ptr %t575, i32 0, i32 75
  store ptr %t577, ptr %l286, !tbaa !29
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t580 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t578)
  store ptr %t580, ptr %l288
  br label %bb146
bb146:
  %t581 = load ptr, ptr %l288, !tbaa !29
  %t583 = getelementptr %"compiler/check:frame", ptr %t581, i32 0, i32 0
  %t584 = load i64, ptr %t583, !tbaa !24
  %t585 = load i32, ptr %l2, !tbaa !23
  %t587 = sext i32 %t585 to i64
  %t590 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s17, i64 %t584, i64 %t587)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t590, ptr %l293
  br label %bb147
bb147:
  %t591 = load ptr, ptr %l286, !tbaa !29
  %t592 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l293
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t591, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t592, i1 true)
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s17)
  br label %bb149
bb149:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load %"compiler/source:Span", ptr %l1
  %t597 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t593, %"compiler/source:Span" %t594)
  store ptr %t597, ptr %l296
  br label %bb150
bb150:
  %t598 = load ptr, ptr %l296, !tbaa !29
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t598, ptr %rv
  br label %ret
bb151:
  %t600 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t601 = load i32, ptr %t600
  %t603 = trunc i64 7 to i32
  %t604 = icmp eq i32 %t601, %t603
  br i1 %t604, label %bb152, label %bb153
bb152:
  store %olang.scope zeroinitializer, ptr %s22
  %t606 = load ptr, ptr %l0, !tbaa !29
  store ptr %t606, ptr %l300, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t607, ptr %l301
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t609 = load i32, ptr %l2, !tbaa !23
  %t612 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s22, ptr %t608, i32 %t609)
  store { i64, ptr } %t612, ptr %l304
  br label %bb154
bb153:
  br label %bb158
bb154:
  %t613 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  %t615 = extractvalue { i64, ptr } %t613, 1
  %t616 = mul i64 %t614, 1
  %t617 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t616)
  call void @llvm.memcpy.p0.p0.i64(ptr %t617, ptr %t615, i64 %t616, i1 false)
  %t618 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  %t621 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %s22, ptr %s22, { i64, ptr } %t619)
  store %"compiler/msgs:Msg" %t621, ptr %l306
  br label %bb155
bb155:
  %t622 = load ptr, ptr %l300, !tbaa !29
  %t623 = load %"compiler/source:Span", ptr %l301
  %t624 = load %"compiler/msgs:Msg", ptr %l306
  %t625 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t622, %"compiler/source:Span" %t623, %"compiler/msgs:Msg" %t624)
  store i64 %t625, ptr %l307
  br label %bb156
bb156:
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load %"compiler/source:Span", ptr %l1
  %t630 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t626, %"compiler/source:Span" %t627)
  store ptr %t630, ptr %l310
  br label %bb157
bb157:
  %t631 = load ptr, ptr %l310, !tbaa !29
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t631, ptr %rv
  br label %ret
bb158:
  %t633 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t634 = load i32, ptr %t633
  %t636 = trunc i64 4 to i32
  %t637 = icmp eq i32 %t634, %t636
  br i1 %t637, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s23
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = load %"compiler/source:Span", ptr %l1
  %t641 = load i32, ptr %l2, !tbaa !23
  store { i64, [5 x i64] } zeroinitializer, ptr %t642
  %t643 = getelementptr { i64, [5 x i64] }, ptr %t642, i32 0, i32 0
  store i64 0, ptr %t643
  %t645 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t640, 0
  %t647 = insertvalue { %"compiler/source:Span", i32 } %t645, i32 %t641, 1
  %t648 = getelementptr { i64, [5 x i64] }, ptr %t642, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t647, ptr %t648
  %t649 = load { i64, [5 x i64] }, ptr %t642
  %t651 = call ptr @__olang_scope_alloc_a(ptr %s23, i64 48, i64 8)
  store { i64, [5 x i64] } %t649, ptr %t651
  %t654 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %s23, ptr %t639, ptr %t651)
  store i32 %t654, ptr %l319
  br label %bb161
bb160:
  br label %bb173
bb161:
  %t655 = load i32, ptr %l319, !tbaa !23
  store i32 %t655, ptr %l14, !tbaa !23
  %t656 = load i32, ptr %l14, !tbaa !23
  %t658 = icmp sge i32 %t656, 0
  br i1 %t658, label %bb162, label %bb163
bb162:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load i32, ptr %l14, !tbaa !23
  %t664 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t660, i32 %t661)
  store i1 %t664, ptr %l325
  br label %bb164
bb163:
  store i1 false, ptr %l322, !tbaa !21
  br label %bb165
bb164:
  %t665 = load i1, ptr %l325, !tbaa !21
  %t666 = xor i1 %t665, true
  store i1 %t666, ptr %l322, !tbaa !21
  br label %bb165
bb165:
  %t668 = load i1, ptr %l322, !tbaa !21
  br i1 %t668, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s24
  %t669 = load ptr, ptr %l0, !tbaa !29
  store ptr %t669, ptr %l327, !tbaa !29
  %t670 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t670, ptr %l328
  %t671 = load ptr, ptr %l0, !tbaa !29
  %t672 = load i32, ptr %l2, !tbaa !23
  %t675 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s24, ptr %t671, i32 %t672)
  store { i64, ptr } %t675, ptr %l331
  br label %bb168
bb167:
  br label %bb171
bb168:
  %t676 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t677 = extractvalue { i64, ptr } %t676, 0
  %t678 = extractvalue { i64, ptr } %t676, 1
  %t679 = mul i64 %t677, 1
  %t680 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t679)
  call void @llvm.memcpy.p0.p0.i64(ptr %t680, ptr %t678, i64 %t679, i1 false)
  %t681 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t680, 1
  %t684 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %s24, ptr %s24, { i64, ptr } %t682)
  store %"compiler/msgs:Msg" %t684, ptr %l333
  br label %bb169
bb169:
  %t685 = load ptr, ptr %l327, !tbaa !29
  %t686 = load %"compiler/source:Span", ptr %l328
  %t687 = load %"compiler/msgs:Msg", ptr %l333
  %t688 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t685, %"compiler/source:Span" %t686, %"compiler/msgs:Msg" %t687)
  store i64 %t688, ptr %l334
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s24)
  br label %bb171
bb171:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l1
  %t693 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t689, %"compiler/source:Span" %t690)
  store ptr %t693, ptr %l337
  br label %bb172
bb172:
  %t694 = load ptr, ptr %l337, !tbaa !29
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t694, ptr %rv
  br label %ret
bb173:
  %t696 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t697 = load i32, ptr %t696
  %t699 = trunc i64 3 to i32
  %t700 = icmp eq i32 %t697, %t699
  br i1 %t700, label %bb174, label %bb175
bb174:
  store %olang.scope zeroinitializer, ptr %s25
  %t702 = load ptr, ptr %l0, !tbaa !29
  store ptr %t702, ptr %l341, !tbaa !29
  %t703 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t703, ptr %l342
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t706 = getelementptr %"compiler/check:Checker", ptr %t704, i32 0, i32 1
  %t707 = load ptr, ptr %t706, !tbaa !29
  %t708 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t709 = load i64, ptr %t708, !tbaa !24
  %t710 = load i32, ptr %l2, !tbaa !23
  %t714 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t707, i64 %t709, i32 %t710)
  store i64 %t714, ptr %l347
  br label %bb176
bb175:
  br label %bb182
bb176:
  %t715 = icmp sge i64 0, 0
  br i1 %t715, label %bb177, label %bb178
bb177:
  %t717 = icmp sle i64 0, 2305843009213693951
  br i1 %t717, label %bb179, label %bb180
bb178:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb179:
  %t719 = mul i64 0, 4
  %t720 = call ptr @__olang_scope_alloc_zeroed(ptr %s25, i64 %t719)
  %t721 = insertvalue { i64, ptr } undef, i64 0, 0
  %t722 = insertvalue { i64, ptr } %t721, ptr %t720, 1
  %t723 = load ptr, ptr %l341, !tbaa !29
  %t724 = load %"compiler/source:Span", ptr %l342
  %t725 = load i64, ptr %l347, !tbaa !24
  %t727 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %s25, ptr %t723, %"compiler/source:Span" %t724, i64 %t725, { i64, ptr } %t722)
  store ptr %t727, ptr %l351
  br label %bb181
bb180:
  call void @__olang_check_failed(ptr @olang_loc_d573417cd970c31d_c74d35b0202ac379)
  unreachable
bb181:
  %t728 = load ptr, ptr %l351, !tbaa !29
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t728, ptr %rv
  br label %ret
bb182:
  %t730 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t731 = load i32, ptr %t730
  %t733 = trunc i64 8 to i32
  %t734 = icmp eq i32 %t731, %t733
  br i1 %t734, label %bb183, label %bb184
bb183:
  %t736 = load ptr, ptr %l0, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t736)
  store ptr %t738, ptr %l357
  br label %bb185
bb184:
  br label %bb197
bb185:
  %t739 = load ptr, ptr %l357, !tbaa !29
  %t741 = getelementptr %"compiler/check:frame", ptr %t739, i32 0, i32 4
  %t742 = getelementptr %"compiler/generic:Context", ptr %t741, i32 0, i32 2
  %t743 = load i32, ptr %l2, !tbaa !23
  %t746 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t742, i32 %t743)
  %t747 = extractvalue { i32, i32 } %t746, 1
  %t748 = extractvalue { i32, i32 } %t746, 0
  store i32 %t748, ptr %l362
  %t749 = icmp ne i32 %t748, 0
  br i1 %t749, label %bb187, label %ok.750, !prof !99
ok.750:
  store i32 %t747, ptr %l361
  br label %bb186
bb186:
  %t751 = load i32, ptr %l361, !tbaa !23
  store i32 %t751, ptr %l355, !tbaa !23
  br label %bb189
bb187:
  br label %bb188
bb188:
  call void @__olang_ert_req_clear()
  %t752 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t752, ptr %l355, !tbaa !23
  br label %bb189
bb189:
  %t754 = load i32, ptr %l355, !tbaa !23
  %t756 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t759 = icmp ne i32 %t754, %t756
  br i1 %t759, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s27
  %t761 = load ptr, ptr %l0, !tbaa !29
  store ptr %t761, ptr %l367, !tbaa !29
  %t762 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t762, ptr %l368
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t764 = load i32, ptr %l2, !tbaa !23
  %t767 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t763, i32 %t764)
  store { i64, ptr } %t767, ptr %l371
  br label %bb192
bb191:
  br label %bb196
bb192:
  %t768 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t769 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %s27, { i64, ptr } %t768)
  store %"compiler/msgs:Msg" %t769, ptr %l372
  br label %bb193
bb193:
  %t770 = load ptr, ptr %l367, !tbaa !29
  %t771 = load %"compiler/source:Span", ptr %l368
  %t772 = load %"compiler/msgs:Msg", ptr %l372
  %t773 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s27, ptr %t770, %"compiler/source:Span" %t771, %"compiler/msgs:Msg" %t772)
  store i64 %t773, ptr %l373
  br label %bb194
bb194:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t775 = load %"compiler/source:Span", ptr %l1
  %t778 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t774, %"compiler/source:Span" %t775)
  store ptr %t778, ptr %l376
  br label %bb195
bb195:
  %t779 = load ptr, ptr %l376, !tbaa !29
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t779, ptr %rv
  br label %ret
bb196:
  br label %bb197
bb197:
  %t781 = load ptr, ptr %l0, !tbaa !29
  %t782 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t781, %"compiler/source:Span" %t782, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb198
bb198:
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t786 = load %"compiler/source:Span", ptr %l1
  %t789 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t785, %"compiler/source:Span" %t786)
  store ptr %t789, ptr %l382
  br label %bb199
bb199:
  %t790 = load ptr, ptr %l382, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t790, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Func", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Func", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t10, i32 %t14)
  store { i64, ptr } %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 2, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Func", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb5, label %bb6
bb4:
  br label %bb8
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6fdba33c6e4026bf_8c9edfb8735784b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Func", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Param", ptr %t38, i32 0, i32 0
  %t42 = getelementptr %"compiler/source:Span", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 0
  %t47 = getelementptr %"compiler/source:Span", ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t51 = sub i32 %t43, %t48
  %t53 = sext i32 %t51 to i64
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb11
bb10:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = icmp sgt i64 %t59, %t62
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb11
bb11:
  %t67 = load i1, ptr %l32, !tbaa !21
  br i1 %t67, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t70, 0
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l39, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb17:
  %t83 = load i64, ptr %l42, !tbaa !24
  %t84 = load i64, ptr %l43, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb19:
  %t87 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l39, !tbaa !24
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = getelementptr i8, ptr %t88, i64 %t89
  %t92 = sub i64 %t90, %t89
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t94, { i64, ptr } %t95)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l50
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102, !prof !99
ok.102:
  store i64 %t99, ptr %l49
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb21:
  %t103 = load i64, ptr %l49, !tbaa !24
  store i64 %t103, ptr %l37, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb24
bb24:
  %t104 = load i64, ptr %l37, !tbaa !24
  store i64 %t104, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Func", ptr %t109, i32 0, i32 0
  %t112 = load %"compiler/source:Span", ptr %t111
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t112, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Func", ptr %t114, i32 0, i32 0
  %t117 = getelementptr %"compiler/source:Span", ptr %t116, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = load i64, ptr %l4, !tbaa !24
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = trunc i64 %t123 to i32
  %t128 = add i32 %t118, %t125
  store i32 %t128, ptr %l6, !tbaa !23
  %t130 = load i32, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = trunc i64 %t134 to i32
  %t139 = add i32 %t131, %t136
  %t142 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t130, i32 %t139)
  store %"compiler/source:Span" %t142, ptr %l68
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load %"compiler/source:Span", ptr %l68
  store %"compiler/source:Span" %t143, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca %"compiler/names:Ref"
  %l15 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t8)
  store ptr %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t20 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t17, i64 %t14, i32 %t16)
  store %"compiler/names:Ref" %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = getelementptr %"compiler/names:Ref", ptr %l11, i32 0, i32 0
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l2
  %t24 = load i32, ptr %l2
  %t26 = trunc i64 1 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t29 = load i32, ptr %l2
  %t31 = trunc i64 8 to i32
  %t32 = icmp eq i32 %t29, %t31
  store i1 %t32, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca i32
  %l65 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca i32
  %l85 = alloca %"compiler/typed:Payload"
  %l94 = alloca i64
  %l97 = alloca i64
  %l117 = alloca { i64, ptr }
  %l122 = alloca i64
  %l126 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l151 = alloca ptr
  %l157 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t94 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [2 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l26
  br label %bb2
bb2:
  %t10 = load i32, ptr %l26, !tbaa !23
  store i32 %t10, ptr %l6, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l6, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l29
  br label %bb3
bb3:
  %t16 = load i32, ptr %l29, !tbaa !23
  store i32 %t16, ptr %l7, !tbaa !23
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 45
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l32
  br label %bb4
bb4:
  %t22 = load i64, ptr %l32, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l35, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l38, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i32, ptr %l7, !tbaa !23
  %t40 = load i64, ptr %l3, !tbaa !24
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t38, i32 %t39, i64 %t40)
  store i32 %t44, ptr %l43
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l38, !tbaa !29
  %t46 = load i32, ptr %l43, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l44
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l35, !tbaa !29
  %t49 = load i32, ptr %l44, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l45
  br label %bb7
bb7:
  %t51 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t51, ptr %l9, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load %"compiler/source:Span", ptr %l1
  %t59 = load i32, ptr %l6, !tbaa !23
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t67 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t58, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, i32 } %t67, i32 %t59, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } %t69, i32 %t62, 2
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t64
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %l10, !tbaa !29
  %t77 = load ptr, ptr %l10, !tbaa !29
  store ptr %t77, ptr %l11, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l6, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l59
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t84 = load i1, ptr %l59, !tbaa !21
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l60
  %t86 = load i32, ptr %l7, !tbaa !23
  store i32 %t86, ptr %l61, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %l10, !tbaa !29
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89)
  store ptr %t93, ptr %l65
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load %"compiler/source:Span", ptr %l60
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t96, 0
  %t98 = load i32, ptr %l61, !tbaa !23
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t98, 1
  %t100 = load ptr, ptr %l65, !tbaa !29
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t100, 2
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [4 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t103, ptr %t105
  store ptr %t105, ptr %l11, !tbaa !29
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  store ptr %t112, ptr %l70, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l75
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t124 = load i32, ptr %l75, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l76
  br label %bb16
bb16:
  %t126 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t126, ptr %l77, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l80
  store i32 %t132, ptr %l81, !tbaa !23
  %t136 = load ptr, ptr %l11, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  %t141 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t136, i64 %t137, i32 0)
  store %"compiler/typed:Payload" %t141, ptr %l85
  br label %bb17
bb17:
  %t142 = load %"compiler/typed:Payload", ptr %l85
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t142, ptr %t143
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 5, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l80
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t146, 0
  %t148 = load i32, ptr %l81, !tbaa !23
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, i32 %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, ptr %t143, 2
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t151, ptr %t152
  %t153 = load { i64, [4 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t153, ptr %t155
  store ptr %t155, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t161 = load i64, ptr %l15, !tbaa !24
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb18, label %bb19
bb18:
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb23
bb20:
  %t171 = load i64, ptr %l15, !tbaa !24
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = sub i64 %t171, %t172
  %t176 = load i64, ptr %l16, !tbaa !24
  %t179 = add i64 %t175, %t176
  %t181 = sub i64 %t179, 1
  %t182 = load i64, ptr %l16, !tbaa !24
  %t185 = sdiv i64 %t181, %t182
  store i64 %t185, ptr %l97, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb22
bb22:
  %t187 = load i64, ptr %l97, !tbaa !24
  store i64 %t187, ptr %l94, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l94, !tbaa !24
  store i64 %t188, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb24
bb24:
  %t189 = load i64, ptr %l18, !tbaa !24
  %t190 = load i64, ptr %l17, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t197 = load i64, ptr %l14, !tbaa !24
  %t198 = load i64, ptr %l18, !tbaa !24
  %t199 = load i64, ptr %l16, !tbaa !24
  %t202 = mul i64 %t198, %t199
  %t205 = add i64 %t197, %t202
  store i64 %t205, ptr %l19, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t209, ptr %l117, !tbaa !27
  %t210 = load i64, ptr %l19, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [2 x i64] }, ptr %t216, i32 0, i32 0
  store i64 5, ptr %t217
  %t218 = load { i64, [2 x i64] }, ptr %t216
  %t224 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t207, i32 0, %"compiler/source:Span" %t208, i32 %t215, i32 4, { i64, [2 x i64] } %t218)
  store i64 %t224, ptr %l122
  br label %bb28
bb28:
  %t225 = load i64, ptr %l122, !tbaa !24
  store i64 %t225, ptr %l20, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t229, ptr %l126, !tbaa !27
  %t230 = load i64, ptr %l19, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i32, ptr %t233, i64 %t230
  %t235 = load i32, ptr %t234, !tbaa !33
  %t236 = load ptr, ptr %l13, !tbaa !29
  %t237 = load i64, ptr %l19, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 3, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t228, 0
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t241, i32 %t235, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t243, ptr %t236, 2
  %t247 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t245, i64 %t237, 3
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t247, ptr %t248
  %t249 = load { i64, [4 x i64] }, ptr %t238
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t249, ptr %t251
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t251)
  store ptr %t255, ptr %l133
  br label %bb29
bb29:
  %t256 = load ptr, ptr %l133, !tbaa !29
  store ptr %t256, ptr %l21, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l20, !tbaa !24
  %t259 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t257, i64 %t258, ptr %t259)
  br label %bb30
bb30:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l20, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l21, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb31
bb31:
  %t284 = load ptr, ptr %l5, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 45
  %t287 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t290 = load i64, ptr %l18, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l18, !tbaa !24
  br label %bb24
bb34:
  br label %bb35
bb35:
  %t294 = load ptr, ptr %l5, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 44
  store ptr %t296, ptr %l151, !tbaa !29
  %t297 = load i64, ptr %l2, !tbaa !24
  %t298 = load i64, ptr %l3, !tbaa !24
  %t299 = load i32, ptr %l7, !tbaa !23
  %t300 = load i64, ptr %l8, !tbaa !24
  %t307 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t297, i64 %t298, i32 %t299, i64 %t300, i64 %a4, i1 false)
  store %"compiler/check:narrowed" %t307, ptr %l157
  br label %bb36
bb36:
  %t308 = load ptr, ptr %l151, !tbaa !29
  %t309 = load %"compiler/check:narrowed", ptr %l157
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePush_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t308, %"compiler/check:narrowed" %t309)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedWrite(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/check:narrowed"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/check:narrowed"
  %l16 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l24 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca ptr
  %l42 = alloca ptr
  %l46 = alloca %"compiler/typed:Local"
  %l48 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l8, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 44
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %t7, i64 %a2)
  store i64 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t12, i64 %t13)
  store %"compiler/check:narrowed" %t14, ptr %l14
  br label %bb3
bb3:
  %t15 = load %"compiler/check:narrowed", ptr %l14
  store %"compiler/check:narrowed" %t15, ptr %l3
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t25, i32 %t27)
  store i32 %t30, ptr %l21
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i32, ptr %l21, !tbaa !23
  %t33 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t31, i32 %t32)
  store ptr %t33, ptr %l22
  br label %bb5
bb5:
  %t34 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t36, i64 %t35)
  store ptr %t38, ptr %l24
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l24, !tbaa !29
  store ptr %t39, ptr %l4, !tbaa !29
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = icmp eq ptr %t40, null
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l4, !tbaa !29
  %t49 = getelementptr %"compiler/ast:CaseDecl", ptr %t47, i32 0, i32 1
  %t50 = load i32, ptr %t49, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t46, i32 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l28, !tbaa !27
  br label %bb10
bb9:
  %t54 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t55, ptr %l5, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 2
  %t58 = load i32, ptr %t57, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t56, i32 %t58)
  store { i64, ptr } %t61, ptr %l35
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = extractvalue { i64, ptr } %t62, 1
  %t71 = extractvalue { i64, ptr } %t62, 0
  %t72 = add i64 %t68, %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t72)
  call void @olang_textcopy(ptr %t73, ptr %t64, i64 %t65)
  %t74 = getelementptr i8, ptr %t73, i64 %t65
  call void @olang_textcopy(ptr %t74, ptr %t66, i64 %t67)
  %t75 = getelementptr i8, ptr %t74, i64 %t67
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t73, 1
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t82)
  store ptr %t84, ptr %l42
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l42, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 7
  %t88 = getelementptr %"compiler/check:narrowed", ptr %l3, i32 0, i32 0
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t87, i64 %t89)
  store %"compiler/typed:Local" %t92, ptr %l46
  br label %bb13
bb13:
  %t93 = getelementptr %"compiler/typed:Local", ptr %l46, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load ptr, ptr %l40, !tbaa !29
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t95, i32 %t94)
  store { i64, ptr } %t97, ptr %l48
  br label %bb14
bb14:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t101 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t99, { i64, ptr } %t98)
  store %"compiler/msgs:Msg" %t101, ptr %l50
  br label %bb15
bb15:
  %t102 = load ptr, ptr %l38, !tbaa !29
  %t103 = load %"compiler/source:Span", ptr %l39
  %t104 = load %"compiler/msgs:Msg", ptr %l50
  %t105 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t102, %"compiler/source:Span" %t103, %"compiler/msgs:Msg" %t104)
  store i64 %t105, ptr %l51
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enestedBranches(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb4
bb2:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load i32, ptr %l3, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2edirectSet(ptr %v1, { i64, ptr } %t7, i32 %t8)
  store i1 %t11, ptr %l16
  br label %bb3
bb3:
  %t12 = load i1, ptr %l16, !tbaa !21
  store i1 %t12, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l13, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp slt i64 %t20, %t21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb33
bb10:
  br label %bb11
bb11:
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t28, ptr %l24, !tbaa !27
  %t29 = load i64, ptr %l6, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr ptr, ptr %t32, i64 %t29
  %t34 = load ptr, ptr %t33, !tbaa !39
  store ptr %t34, ptr %l8, !tbaa !29
  %t36 = load ptr, ptr %l8, !tbaa !29
  store ptr %t36, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %t40
  %t43 = icmp eq i64 %t41, 7
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l8, !tbaa !29
  %t47 = getelementptr { i64, [6 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  store ptr %t49, ptr %l9, !tbaa !29
  br label %bb16
bb15:
  br label %bb26
bb16:
  %t51 = load ptr, ptr %l9, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2fcheck_2echainSets(ptr %v1, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l35
  br label %bb17
bb17:
  %t56 = load i1, ptr %l35, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l9, !tbaa !29
  %t58 = load i32, ptr %l3, !tbaa !23
  %t61 = call i1 @compiler_2fcheck_2echainAssignsAll(ptr %v1, ptr %t57, i32 %t58)
  store i1 %t61, ptr %l39
  br label %bb20
bb19:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  %t62 = load i1, ptr %l39, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l9, !tbaa !29
  %t69 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %t68, i32 %t69, i32 %a4)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_8db10e524bac21a2_ad831be9185e1396)
  unreachable
bb31:
  br label %bb32
bb32:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l6, !tbaa !24
  br label %bb8
bb33:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l19 = alloca %"compiler/msgs:Nearest"
  %l31 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca %"compiler/msgs:Msg"
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/msgs:Msg"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t12, i32 %t13)
  store { i64, ptr } %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %s0, { i64, ptr } %t18)
  store %"compiler/msgs:Nearest" %t20, ptr %l19
  br label %bb3
bb3:
  %t21 = load %"compiler/msgs:Nearest", ptr %l19
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 40, i64 8)
  store %"compiler/msgs:Nearest" %t21, ptr %t22
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l8, !tbaa !24
  br label %bb6
bb5:
  br label %bb14
bb6:
  %t36 = load i64, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l8, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  br label %bb9
bb9:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l31, !tbaa !27
  %t45 = load i64, ptr %l7, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i32, ptr %t48, i64 %t45
  %t50 = load i32, ptr %t49, !tbaa !33
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l34, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t53, i32 %t50)
  store { i64, ptr } %t57, ptr %l37
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %s0, ptr %v0, ptr %t58, { i64, ptr } %t59)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb6
bb13:
  br label %bb14
bb14:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/msgs:Nearest", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load i32, ptr %l1, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t73, i32 %t74)
  store { i64, ptr } %t77, ptr %l46
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t78 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l47, !tbaa !27
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l2, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t85, i32 %t86)
  store { i64, ptr } %t89, ptr %l50
  br label %bb18
bb18:
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/msgs:Nearest", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v1, ptr %v1, ptr %s0, ptr %v1, { i64, ptr } %t101, { i64, ptr } %t96, { i64, ptr } %t100)
  store %"compiler/msgs:Msg" %t104, ptr %l54
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t105 = load %"compiler/msgs:Msg", ptr %l54
  store %"compiler/msgs:Msg" %t105, ptr %rv
  br label %ret
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i32, ptr %l1, !tbaa !23
  %t110 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t106, i32 %t107)
  store { i64, ptr } %t110, ptr %l57
  br label %bb21
bb21:
  %t111 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l58, !tbaa !27
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load i32, ptr %l2, !tbaa !23
  %t122 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %t118, i32 %t119)
  store { i64, ptr } %t122, ptr %l61
  br label %bb22
bb22:
  %t123 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t130 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t132 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t129)
  store %"compiler/msgs:Msg" %t132, ptr %l63
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/msgs:Msg", ptr %l63
  store %"compiler/msgs:Msg" %t133, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/msgs:Msg", ptr %rv
  ret %"compiler/msgs:Msg" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t1, %"compiler/source:Span" %a1)
  store %"compiler/source:Span" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t7, i32 %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, %"compiler/source:Span" %t9, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, i64 1, i1 true)
  store i1 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = add i64 %a4, 1
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t15, i32 %t16, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d46, i32 0, i32 1) }, i64 %t19)
  store i64 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 47
  %t31 = getelementptr %"compiler/source:Span", ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = icmp sge i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 47
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l23
  br label %bb11
bb10:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %a3)
  store { i64, ptr } %t47, ptr %l29
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %s2, ptr %s2, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t56, ptr %l31
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l23
  %t59 = load %"compiler/msgs:Msg", ptr %l31
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l32
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t62, ptr %l34
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store %"compiler/msgs:Msg" %t76, ptr %l39
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l33, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l34
  %t79 = load %"compiler/msgs:Msg", ptr %l39
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/msgs:Msg" %t79)
  store i64 %t80, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca i1
  %l22 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca i32
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca ptr
  %l129 = alloca i64
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca i64
  %l145 = alloca { i64, [3 x i64] }
  %l149 = alloca { i64, ptr }
  %l151 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t311 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i1, ptr %l22, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l19, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l19, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l26, !tbaa !29
  %t21 = load i32, ptr %l1, !tbaa !23
  store i32 %t21, ptr %l27, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  store i32 %t35, ptr %l33
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l26, !tbaa !29
  %t37 = load i32, ptr %l27, !tbaa !23
  %t38 = load i32, ptr %l33, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l34
  br label %bb9
bb9:
  %t40 = load i64, ptr %l34, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l38, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  store i32 %t49, ptr %l39, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l43, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s2, { i64, ptr } %t60)
  store { i64, ptr } %t62, ptr %l45
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t63 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t72 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t70, { i64, ptr } %t69)
  store i32 %t72, ptr %l47
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l38, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = load i32, ptr %l47, !tbaa !23
  %t76 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t73, i32 %t74, i32 %t75)
  store i64 %t76, ptr %l48
  br label %bb14
bb14:
  %t77 = load i64, ptr %l48, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/generic:Program", ptr %t92, i32 0, i32 2
  store ptr %t94, ptr %l57, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l61
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l57, !tbaa !29
  %t104 = load i32, ptr %l61, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t105, ptr %l62
  br label %bb20
bb20:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l62, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l63
  br label %bb21
bb21:
  %t109 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t112 = sub i64 %t110, 1
  store i64 %t112, ptr %l8, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  br i1 %t114, label %bb22, label %bb23
bb22:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  %t120 = icmp sge i64 %t116, %t117
  store i1 %t120, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  %t122 = load i64, ptr %l8, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = icmp eq i64 %t122, %t123
  store i1 %t126, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t130 = load i64, ptr %l8, !tbaa !24
  %t132 = icmp eq i64 %t130, 0
  br i1 %t132, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l77, !tbaa !27
  br label %bb33
bb29:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t136 = icmp eq i64 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l80, !tbaa !27
  br label %bb32
bb31:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t141 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t143)
  %t145 = call i64 @__olang_fmt_i64(ptr %t144, i64 %t138)
  %t146 = getelementptr i8, ptr %t144, i64 %t140
  call void @olang_textcopy(ptr %t146, ptr %t141, i64 %t142)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t144, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l80, !tbaa !27
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t157, ptr %l77, !tbaa !27
  br label %bb33
bb33:
  %t158 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t158, ptr %l9, !tbaa !27
  %t159 = load i64, ptr %l5, !tbaa !24
  %t161 = icmp eq i64 %t159, 1
  br i1 %t161, label %bb34, label %bb35
bb34:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb36
bb35:
  %t163 = load i64, ptr %l5, !tbaa !24
  %t165 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  %t167 = call i64 @__olang_fmt_i64(ptr %t166, i64 %t163)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = extractvalue { i64, ptr } %t169, 1
  %t173 = mul i64 %t171, 1
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @llvm.memcpy.p0.p0.i64(ptr %t174, ptr %t172, i64 %t173, i1 false)
  %t175 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  store { i64, ptr } %t176, ptr %l86, !tbaa !27
  br label %bb36
bb36:
  %t178 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t178, ptr %l10, !tbaa !27
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = icmp eq i64 %t179, 0
  br i1 %t181, label %bb37, label %bb38
bb37:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l92, !tbaa !27
  br label %bb42
bb38:
  %t183 = load i1, ptr %l6, !tbaa !21
  br i1 %t183, label %bb39, label %bb40
bb39:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t186 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t187 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t189 = extractvalue { i64, ptr } %t185, 1
  %t190 = extractvalue { i64, ptr } %t185, 0
  %t191 = add i64 %t187, %t190
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @olang_textcopy(ptr %t192, ptr %t186, i64 %t187)
  %t193 = getelementptr i8, ptr %t192, i64 %t187
  call void @olang_textcopy(ptr %t193, ptr %t189, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t192, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l94, !tbaa !27
  br label %bb41
bb40:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t204, ptr %l94, !tbaa !27
  br label %bb41
bb41:
  %t206 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t206, ptr %l92, !tbaa !27
  br label %bb42
bb42:
  %t207 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t207, ptr %l11, !tbaa !27
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l100
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i32, ptr %l1, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l103
  br label %bb43
bb43:
  %t215 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 1
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l104, !tbaa !27
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l105, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t227 = load i64, ptr %l7, !tbaa !24
  %t230 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l109
  br label %bb44
bb44:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l105, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t235, i32 %t234)
  store { i64, ptr } %t237, ptr %l112
  br label %bb45
bb45:
  %t238 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t246 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %s0, ptr %v0, ptr %s0, ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t238, { i64, ptr } %a4, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t246, ptr %l116
  br label %bb46
bb46:
  %t247 = load ptr, ptr %l99, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l100
  %t249 = load %"compiler/msgs:Msg", ptr %l116
  %t250 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t247, %"compiler/source:Span" %t248, %"compiler/msgs:Msg" %t249)
  store i64 %t250, ptr %l117
  br label %bb47
bb47:
  %t251 = load i64, ptr %l117, !tbaa !24
  store i64 %t251, ptr %l12, !tbaa !24
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l7, !tbaa !24
  %t259 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l121
  br label %bb48
bb48:
  %t260 = load ptr, ptr %l121, !tbaa !29
  store ptr %t260, ptr %l13, !tbaa !29
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/check:Checker", ptr %t261, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !29
  %t266 = getelementptr %"compiler/generic:Program", ptr %t264, i32 0, i32 0
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/load:Loader", ptr %t267, i32 0, i32 5
  store ptr %t269, ptr %l125, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/check:Checker", ptr %t270, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = load i64, ptr %l7, !tbaa !24
  %t277 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t273, i64 %t274)
  store i64 %t277, ptr %l129
  br label %bb49
bb49:
  %t278 = load ptr, ptr %l125, !tbaa !29
  %t279 = load i64, ptr %l129, !tbaa !24
  %t280 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t278, i64 %t279)
  store ptr %t280, ptr %l130
  br label %bb50
bb50:
  %t281 = load ptr, ptr %l130, !tbaa !29
  %t283 = getelementptr %"compiler/load:Module", ptr %t281, i32 0, i32 4
  %t284 = load i64, ptr %t283, !tbaa !24
  %t286 = load ptr, ptr %l13, !tbaa !29
  %t288 = getelementptr %"compiler/ast:Func", ptr %t286, i32 0, i32 0
  %t289 = load %"compiler/source:Span", ptr %t288
  store %"compiler/source:Span" %t289, ptr %l15
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 4
  %t300 = load ptr, ptr %t299, !tbaa !29
  store ptr %t300, ptr %l138, !tbaa !29
  %t301 = load i64, ptr %l12, !tbaa !24
  store i64 %t301, ptr %l139, !tbaa !24
  %t303 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t304 = load i32, ptr %t303, !tbaa !23
  %t306 = sext i32 %t304 to i64
  %t307 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 1
  %t308 = load i32, ptr %t307, !tbaa !23
  %t310 = sext i32 %t308 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t311
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 0
  store i64 3, ptr %t312
  %t314 = insertvalue { i64, i64, i64 } undef, i64 %t284, 0
  %t316 = insertvalue { i64, i64, i64 } %t314, i64 %t306, 1
  %t318 = insertvalue { i64, i64, i64 } %t316, i64 %t310, 2
  %t319 = getelementptr { i64, [3 x i64] }, ptr %t311, i32 0, i32 1
  store { i64, i64, i64 } %t318, ptr %t319
  %t320 = load { i64, [3 x i64] }, ptr %t311
  store { i64, [3 x i64] } %t320, ptr %l145
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l13, !tbaa !29
  %t324 = getelementptr %"compiler/ast:Func", ptr %t322, i32 0, i32 2
  %t325 = load i32, ptr %t324, !tbaa !23
  %t328 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s0, ptr %t321, i32 %t325)
  store { i64, ptr } %t328, ptr %l149
  br label %bb51
bb51:
  %t329 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %s0, ptr %s0, { i64, ptr } %t335)
  store %"compiler/msgs:Msg" %t337, ptr %l151
  br label %bb52
bb52:
  %t338 = load ptr, ptr %l138, !tbaa !29
  %t339 = load i64, ptr %l139, !tbaa !24
  %t340 = load { i64, [3 x i64] }, ptr %l145
  %t341 = load %"compiler/msgs:Msg", ptr %l151
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s0, ptr %t338, i64 %t339, { i64, [3 x i64] } %t340, %"compiler/msgs:Msg" %t341)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamIndex(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:Local"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l15 = alloca %"compiler/typed:Local"
  %l19 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l61 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = trunc i64 %t4 to i32
  %t8 = load ptr, ptr %l11, !tbaa !29
  %t10 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t8, i32 %t6)
  store %"compiler/typed:Local" %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load %"compiler/typed:Local", ptr %l15
  store %"compiler/typed:Local" %t11, ptr %l2
  %t12 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 4
  %t13 = load i32, ptr %t12
  %t15 = trunc i64 0 to i32
  %t16 = icmp eq i32 %t13, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb6
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t20, i32 %t22)
  store i1 %t25, ptr %l22
  br label %bb5
bb5:
  %t26 = load i1, ptr %l22, !tbaa !21
  store i1 %t26, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l19, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Local", ptr %l2, i32 0, i32 2
  %t30 = load i32, ptr %t29, !tbaa !23
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t28, i32 %t30)
  store i1 %t33, ptr %l26
  br label %bb9
bb9:
  %t34 = load i1, ptr %l26, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l23, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t39)
  store ptr %t41, ptr %l30
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l30, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Body", ptr %t42, i32 0, i32 5
  %t45 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t44
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t48 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3)
  store i64 %t48, ptr %l34
  br label %bb15
bb15:
  %t49 = load i64, ptr %l34, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l4, !tbaa !24
  %t54 = icmp sgt i64 %t50, %t51
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb21
bb18:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sub i64 %t60, %t61
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t70 = sub i64 %t68, 1
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = sdiv i64 %t70, %t71
  store i64 %t74, ptr %l41, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l41, !tbaa !24
  store i64 %t76, ptr %l38, !tbaa !24
  br label %bb21
bb21:
  %t77 = load i64, ptr %l38, !tbaa !24
  store i64 %t77, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb23, label %bb24
bb23:
  br label %bb31
bb24:
  br label %bb25
bb25:
  %t86 = load i64, ptr %l4, !tbaa !24
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = mul i64 %t87, %t88
  %t94 = add i64 %t86, %t91
  store i64 %t94, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %l3, i64 %t96)
  store i32 %t99, ptr %l61
  br label %bb26
bb26:
  %t100 = load i32, ptr %l61, !tbaa !23
  %t101 = sext i32 %t100 to i64
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp eq i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l9, !tbaa !24
  store i64 %t107, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t111 = add i64 %t109, 1
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb22
bb31:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamsOn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l39 = alloca %"compiler/generic:Binding"
  %l42 = alloca i1
  %l47 = alloca { i64, ptr }
  %l56 = alloca i64
  %l59 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca i32
  %l90 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l16, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l19, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l23
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l19, !tbaa !29
  %t22 = load i32, ptr %l23, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l24
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i32, ptr %l24, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l25
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t27, ptr %l3, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l27, !tbaa !24
  %t31 = load i64, ptr %l27, !tbaa !24
  %t32 = icmp sge i64 %t31, 0
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = load i64, ptr %l27, !tbaa !24
  %t35 = icmp sle i64 %t34, 2305843009213693951
  br i1 %t35, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb6:
  %t37 = load i64, ptr %l27, !tbaa !24
  %t38 = mul i64 %t37, 4
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t42, ptr %lp4
  %t44 = load ptr, ptr %lp4
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t45)
  store i64 %t47, ptr %l32
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_aac959024b9d6f15_55461456e770b1d1)
  unreachable
bb8:
  %t48 = load i64, ptr %l32, !tbaa !24
  store i64 %t48, ptr %l5, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l36
  br label %bb9
bb9:
  %t57 = load i64, ptr %l36, !tbaa !24
  store i64 %t57, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t58, i64 %t59)
  store %"compiler/generic:Binding" %t62, ptr %l39
  br label %bb10
bb10:
  %t63 = load %"compiler/generic:Binding", ptr %l39
  store %"compiler/generic:Binding" %t63, ptr %l7
  %t64 = load i64, ptr %l6, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp sgt i64 %t70, 0
  store i1 %t72, ptr %l42, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l42, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i32, ptr %t78, i64 0
  %t80 = load i32, ptr %t79, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t75, i32 %t80, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l8, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb18, label %bb19
bb18:
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb23
bb20:
  %t100 = load i64, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l10, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l59, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l59, !tbaa !24
  store i64 %t116, ptr %l56, !tbaa !24
  br label %bb23
bb23:
  %t117 = load i64, ptr %l56, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb25, label %bb26
bb25:
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  store i64 %t136, ptr %l77, !tbaa !24
  %t137 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb28, label %bb29
bb28:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t142, ptr %l82, !tbaa !27
  %t143 = load i64, ptr %l13, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t141, i32 %t148)
  store i32 %t151, ptr %l85
  br label %bb30
bb29:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t154 = load i64, ptr %l13, !tbaa !24
  %t159 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v0, ptr %s0, ptr %t152, { i64, ptr } %t153, i64 %t154, ptr %l7)
  store i32 %t159, ptr %l90
  br label %bb31
bb30:
  %t160 = load i32, ptr %l85, !tbaa !23
  store i32 %t160, ptr %l80, !tbaa !23
  br label %bb32
bb31:
  %t161 = load i32, ptr %l90, !tbaa !23
  store i32 %t161, ptr %l80, !tbaa !23
  br label %bb32
bb32:
  %t162 = load i32, ptr %l80, !tbaa !23
  %t163 = load ptr, ptr %lp4
  %t164 = load i64, ptr %l77, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i32, ptr %t166, i64 %t164
  store i32 %t162, ptr %t167, !tbaa !33
  br label %bb33
bb33:
  %t168 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l12, !tbaa !24
  br label %bb24
bb34:
  %t172 = load ptr, ptr %lp4
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t173, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceHere(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %lp14 = alloca ptr
  %lp15 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i32
  %l39 = alloca i32
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l93 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca i64
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l113 = alloca i32
  %l117 = alloca i64
  %l118 = alloca ptr
  %l122 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l135 = alloca ptr
  %l141 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t173 = alloca { i64, [2 x i64] }, align 8
  %t181 = alloca { i64, [5 x i64] }, align 8
  %t262 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i1, ptr %l22, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l24, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t12, ptr %l25
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l3, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t13, i32 %t14)
  store { i64, ptr } %t17, ptr %l28
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t18 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t19 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %s1, { i64, ptr } %t18)
  store %"compiler/msgs:Msg" %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l25
  %t22 = load %"compiler/msgs:Msg", ptr %l29
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t20, %"compiler/source:Span" %t21, %"compiler/msgs:Msg" %t22)
  store i64 %t23, ptr %l30
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t24, %"compiler/source:Span" %t25)
  store ptr %t28, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load ptr, ptr %l33, !tbaa !29
  store ptr %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l35
  br label %bb10
bb10:
  %t33 = load i32, ptr %l35, !tbaa !23
  store i32 %t33, ptr %l4, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t38 = load i32, ptr %l4, !tbaa !23
  %t41 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l39
  br label %bb11
bb11:
  %t42 = load i32, ptr %l39, !tbaa !23
  store i32 %t42, ptr %l5, !tbaa !23
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t47 = icmp eq i32 %t43, %t44
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l1
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t49, %"compiler/source:Span" %t50)
  store ptr %t53, ptr %l45
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load ptr, ptr %l45, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t55)
  store ptr %t57, ptr %l47
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l47, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 2
  %t61 = load i64, ptr %t60, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t63 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t64 = load i32, ptr %t63, !tbaa !23
  %t66 = sext i32 %t64 to i64
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 24
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  br i1 %t73, label %bb17, label %bb18
bb17:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 24
  %t78 = load i64, ptr %t77, !tbaa !24
  store i64 %t78, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 25
  %t83 = getelementptr %"compiler/source:Span", ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83, !tbaa !23
  %t86 = sext i32 %t84 to i64
  store i64 %t86, ptr %l7, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 4
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l8, !tbaa !29
  %t99 = load ptr, ptr %l8, !tbaa !29
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %s0, ptr %t99, i64 %t100)
  store { i64, ptr } %t103, ptr %l66
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t104, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load i64, ptr %l12, !tbaa !24
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t117 = load i64, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t125 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t125, ptr %l77, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t126
  %t131 = load i8, ptr %t130, !tbaa !32
  %t136 = load i64, ptr %l72, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t136
  store i8 %t131, ptr %t139, !tbaa !32
  %t140 = load i64, ptr %l72, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l72, !tbaa !24
  br label %bb25
bb25:
  %t142 = load i64, ptr %l11, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l11, !tbaa !24
  br label %bb21
bb26:
  %t146 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t146, ptr %lp14
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = load ptr, ptr %lp14
  store { i64, ptr } %t147, ptr %t148, !tbaa !27
  %t149 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t149, ptr %l84
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  store ptr %t155, ptr %l87, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t156)
  store i32 %t158, ptr %l89
  br label %bb27
bb27:
  %t159 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t160 = load ptr, ptr %l87, !tbaa !29
  %t161 = load i32, ptr %l89, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t160, i32 %t161, i64 %t159)
  store i32 %t163, ptr %l91
  br label %bb28
bb28:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t164)
  store ptr %t166, ptr %l93
  br label %bb29
bb29:
  %t167 = load ptr, ptr %l93, !tbaa !29
  %t169 = getelementptr %"compiler/check:frame", ptr %t167, i32 0, i32 2
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load ptr, ptr %lp14
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 0
  store i64 1, ptr %t174
  %t176 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t172, 0
  %t177 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 1
  store { { i64, ptr } } %t176, ptr %t177
  %t178 = load { i64, [2 x i64] }, ptr %t173
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t178, ptr %t180
  store { i64, [5 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 0
  store i64 1, ptr %t182
  %t183 = load %"compiler/source:Span", ptr %l84
  %t184 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t183, 0
  %t185 = load i32, ptr %l91, !tbaa !23
  %t186 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t184, i32 %t185, 1
  %t188 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t186, i64 %t170, 2
  %t190 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t188, ptr %t180, 3
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t181, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t190, ptr %t191
  %t192 = load { i64, [5 x i64] }, ptr %t181
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t192, ptr %t194
  store ptr %t194, ptr %l100, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l101, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t196, ptr %l102
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t197)
  store i32 %t199, ptr %l104
  br label %bb30
bb30:
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t201 = load i64, ptr %l6, !tbaa !24
  %t202 = load i64, ptr %l7, !tbaa !24
  %t206 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t200, i64 %t201, i64 %t202)
  store i64 %t206, ptr %l108
  br label %bb31
bb31:
  %t207 = load ptr, ptr %l101, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l102
  %t209 = load i32, ptr %l104, !tbaa !23
  %t210 = load i64, ptr %l108, !tbaa !24
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t207, %"compiler/source:Span" %t208, i32 %t209, i64 %t210)
  store ptr %t211, ptr %l109
  br label %bb32
bb32:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l110, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l111
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t214)
  store i32 %t216, ptr %l113
  br label %bb33
bb33:
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t218 = load i64, ptr %l6, !tbaa !24
  %t219 = load i64, ptr %l7, !tbaa !24
  %t223 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %t217, i64 %t218, i64 %t219)
  store i64 %t223, ptr %l117
  br label %bb34
bb34:
  %t224 = load ptr, ptr %l110, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l111
  %t226 = load i32, ptr %l113, !tbaa !23
  %t227 = load i64, ptr %l117, !tbaa !24
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t224, %"compiler/source:Span" %t225, i32 %t226, i64 %t227)
  store ptr %t228, ptr %l118
  br label %bb35
bb35:
  %t229 = load ptr, ptr %l100, !tbaa !29
  %t230 = insertvalue [3 x ptr] undef, ptr %t229, 0
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t232 = insertvalue [3 x ptr] %t230, ptr %t231, 1
  %t233 = load ptr, ptr %l118, !tbaa !29
  %t234 = insertvalue [3 x ptr] %t232, ptr %t233, 2
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t235, ptr %lp15
  %t237 = load ptr, ptr %lp15
  store [3 x ptr] %t234, ptr %t237
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l4, !tbaa !23
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t238, i32 %t239)
  store i64 %t242, ptr %l122
  br label %bb36
bb36:
  %t243 = load i64, ptr %l122, !tbaa !24
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/check:Checker", ptr %t244, i32 0, i32 23
  %t247 = load i32, ptr %t246, !tbaa !23
  store i32 %t247, ptr %l17, !tbaa !23
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i32, ptr %l4, !tbaa !23
  %t253 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 23
  store i32 %t250, ptr %t253, !tbaa !23
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l127, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t255, ptr %l128
  %t256 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t256, ptr %l129
  %t257 = load i32, ptr %l5, !tbaa !23
  store i32 %t257, ptr %l130, !tbaa !23
  %t260 = trunc i64 %t243 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t262
  %t263 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 0
  store i64 0, ptr %t263
  %t265 = insertvalue { i32 } undef, i32 %t260, 0
  %t266 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  store { i32 } %t265, ptr %t266
  %t267 = load { i64, [3 x i64] }, ptr %t262
  %t269 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t267, ptr %t269
  store ptr %t269, ptr %l135, !tbaa !29
  %t270 = icmp sge i64 0, 0
  br i1 %t270, label %bb37, label %bb38
bb37:
  %t272 = icmp sle i64 0, 1152921504606846975
  br i1 %t272, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb39:
  %t274 = mul i64 0, 8
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 0, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  %t278 = load ptr, ptr %lp15
  %t280 = insertvalue { i64, ptr } undef, i64 3, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t282 = load ptr, ptr %l127, !tbaa !29
  %t283 = load %"compiler/source:Span", ptr %l128
  %t284 = load %"compiler/source:Span", ptr %l129
  %t285 = load i32, ptr %l130, !tbaa !23
  %t286 = load ptr, ptr %l135, !tbaa !29
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %t282, %"compiler/source:Span" %t283, %"compiler/source:Span" %t284, i32 %t285, ptr %t286, i64 -1, ptr null, { i64, ptr } %t277, { i64, ptr } %t281)
  store ptr %t289, ptr %l141
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd)
  unreachable
bb41:
  %t290 = load ptr, ptr %l141, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l17, !tbaa !23
  %t295 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 23
  store i32 %t292, ptr %t295, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store ptr %t290, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeForeign(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i32
  %l7 = alloca i1
  %l14 = alloca i32
  %l19 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca ptr
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l14
  br label %bb5
bb5:
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t26, i32 %t20)
  store i32 %t30, ptr %l19
  br label %bb6
bb6:
  %t31 = load i32, ptr %l19, !tbaa !23
  store i32 %t31, ptr %l4, !tbaa !23
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l4, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i32, ptr %l25, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t43, i32 %t44)
  store { i64, ptr } %t45, ptr %l26
  br label %bb8
bb8:
  %t47 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t47, { i64, ptr } %a2)
  store i1 %t49, ptr %l28
  br label %bb9
bb9:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/generic:Program", ptr %t54, i32 0, i32 0
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/load:Loader", ptr %t57, i32 0, i32 5
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l4, !tbaa !23
  %t69 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t65, i32 %t66)
  store i64 %t69, ptr %l38
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb12:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i64, ptr %l38, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t72, ptr %l39
  br label %bb13
bb13:
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t75 = getelementptr %"compiler/load:Module", ptr %t73, i32 0, i32 3
  %t76 = load i1, ptr %t75, !tbaa !21
  store i1 %t76, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l29, !tbaa !21
  store i1 %t78, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, i64 }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca i32
  %l75 = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i1, ptr %l2, !tbaa !21
  %t19 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t16, ptr %t17, i1 %t18, i64 %t19)
  br label %bb6
bb6:
  br label %bb50
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t25 = load ptr, ptr %l24, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 3
  store i1 %t31, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load i32, ptr %l5
  %t47 = trunc i64 48 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l6, !tbaa !29
  %t52 = load i1, ptr %l2, !tbaa !21
  %t54 = xor i1 %t52, true
  %t55 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t50, ptr %t51, i1 %t54, i64 %t55)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb50
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  store ptr %t60, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l40, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l40, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr { i64, [5 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l7
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t77, i32 0, i32 1
  %t79 = load i32, ptr %t78
  store i32 %t79, ptr %l8
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l9, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t89, i32 0, i32 3
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l10, !tbaa !29
  br label %bb22
bb21:
  br label %bb45
bb22:
  %t93 = load i32, ptr %l8
  %t95 = trunc i64 45 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = load i1, ptr %l2, !tbaa !21
  store i1 %t98, ptr %l53, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t100 = load i1, ptr %l53, !tbaa !21
  br i1 %t100, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb31
bb27:
  %t101 = load i32, ptr %l8
  %t103 = trunc i64 46 to i32
  %t104 = icmp eq i32 %t101, %t103
  br i1 %t104, label %bb28, label %bb29
bb28:
  %t106 = load i1, ptr %l2, !tbaa !21
  %t108 = xor i1 %t106, true
  store i1 %t108, ptr %l58, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t110 = load i1, ptr %l58, !tbaa !21
  store i1 %t110, ptr %l55, !tbaa !21
  br label %bb31
bb31:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb32, label %bb33
bb32:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t114 = load i1, ptr %l2, !tbaa !21
  %t115 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t112, ptr %t113, i1 %t114, i64 %t115)
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t122 = load i1, ptr %l2, !tbaa !21
  %t123 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushCases(ptr %v0, ptr %v1, ptr %t120, ptr %t121, i1 %t122, i64 %t123)
  br label %bb35
bb35:
  br label %ret
bb36:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l69, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  store ptr %t129, ptr %l70, !tbaa !29
  %t130 = load i1, ptr %l2, !tbaa !21
  br i1 %t130, label %bb37, label %bb38
bb37:
  store i32 76, ptr %l72
  br label %bb39
bb38:
  store i32 77, ptr %l72
  br label %bb39
bb39:
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = load i32, ptr %l72
  %t137 = call { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %t134, ptr %t135, i32 %t136)
  store { i64, i64 } %t137, ptr %l75
  br label %bb40
bb40:
  %t138 = load { i64, i64 }, ptr %l75
  store { i64, i64 } %t138, ptr %l11
  %t139 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 0
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l12, !tbaa !24
  %t142 = getelementptr { i64, i64 }, ptr %l11, i32 0, i32 1
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t147 = icmp sge i64 %t145, 0
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l7
  %t151 = load i64, ptr %l12, !tbaa !24
  %t152 = load i64, ptr %l13, !tbaa !24
  %t153 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %t149, %"compiler/source:Span" %t150, i64 %t151, i64 %t152, i64 %t153)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_557e36687125b346_f828420618561f4a)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroBorrowedFrom(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca ptr
  %l34 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i64, ptr %l15, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb5
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l18, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 12
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Body", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %t33, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t41, i32 %t42, i64 0)
  store i64 %t45, ptr %l34
  br label %bb10
bb10:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t49 = icmp slt i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  store i64 0, ptr %l5, !tbaa !24
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Call", ptr %t52, i32 0, i32 1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t85 = load i64, ptr %l47, !tbaa !24
  store i64 %t85, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t86 = load i64, ptr %l44, !tbaa !24
  store i64 %t86, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb20
bb20:
  %t87 = load i64, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb21, label %bb22
bb21:
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t95 = load i64, ptr %l5, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l3, !tbaa !23
  %t112 = load i64, ptr %l10, !tbaa !24
  %t116 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t110, i32 %t111, i64 %t112)
  store i64 %t116, ptr %l70
  br label %bb24
bb24:
  %t117 = load i64, ptr %l70, !tbaa !24
  store i64 %t117, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l4, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb27
bb26:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t125 = load i64, ptr %l4, !tbaa !24
  %t128 = icmp eq i64 %t124, %t125
  store i1 %t128, ptr %l74, !tbaa !21
  br label %bb27
bb27:
  %t130 = load i1, ptr %l74, !tbaa !21
  br i1 %t130, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  %t137 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t131, i64 %t132, i64 %t133)
  store i1 %t137, ptr %l82
  br label %bb30
bb29:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb31
bb30:
  %t138 = load i1, ptr %l82, !tbaa !21
  store i1 %t138, ptr %l78, !tbaa !21
  br label %bb31
bb31:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb32, label %bb33
bb32:
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t142 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l9, !tbaa !24
  br label %bb20
bb36:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeepVal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l14 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l10
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10, ptr %l4
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 68
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t17 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %t13, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14)
  store i1 %t17, ptr %l14
  br label %bb5
bb5:
  %t18 = load i1, ptr %l14, !tbaa !21
  %t19 = xor i1 %t18, true
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 68
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l18
  %t25 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l19
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v0, ptr %t26, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t27, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 68
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t35 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  %t36 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 1
  %t37 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t35, 0
  store i32 %t37, ptr %l25
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39, !prof !99
ok.39:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l24
  br label %bb11
bb11:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l20
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  %t41 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l5
  %t42 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %l5, ptr %t42)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t46, i32 %t47, i32 0)
  store i32 %t48, ptr %l25
  br label %bb9
bb9:
  %t49 = load i32, ptr %l25, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l33
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t66 = load i32, ptr %l33, !tbaa !23
  store i32 %t66, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l38
  br label %bb15
bb15:
  %t77 = load i32, ptr %l38
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp ne i32 %t92, 0
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l58
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i32, ptr %l58, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t119, i32 0)
  store i32 %t120, ptr %l59
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l64
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t134, ptr %l65
  br label %bb25
bb25:
  %t135 = load i32, ptr %l65, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t136 = load i32, ptr %l1, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetLess(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca i32
  %l26 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l35 = alloca i32
  %l40 = alloca i32
  %l45 = alloca i32
  %l47 = alloca i64
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l5, !tbaa !24
  store i64 %t7, ptr %l14, !tbaa !24
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l16
  br label %bb3
bb3:
  %t11 = load i64, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l16, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l21
  br label %bb7
bb7:
  %t22 = load i32, ptr %l21, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l6, !tbaa !23
  %t32 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t28, i32 %t29)
  store i64 %t32, ptr %l26
  br label %bb8
bb8:
  %t33 = load i64, ptr %l26, !tbaa !65
  store i64 %t33, ptr %l7, !tbaa !65
  store ptr %a2, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t36 = load i64, ptr %l9, !tbaa !24
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load ptr, ptr %l8, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t37)
  store i64 %t39, ptr %l30
  br label %bb10
bb10:
  %t40 = load i64, ptr %l28, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb11, label %bb12
bb11:
  br label %bb22
bb12:
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l8, !tbaa !29
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t46, i64 %t47)
  store i32 %t50, ptr %l35
  br label %bb14
bb14:
  %t51 = load i32, ptr %l35, !tbaa !23
  store i32 %t51, ptr %l10, !tbaa !23
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l6, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l10, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb16
bb16:
  %t72 = load i32, ptr %l40, !tbaa !23
  %t73 = load i32, ptr %l45, !tbaa !23
  %t74 = icmp eq i32 %t72, %t73
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t76 = load i64, ptr %l7, !tbaa !65
  store i64 %t76, ptr %l47, !tbaa !65
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l10, !tbaa !23
  %t86 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t82, i32 %t83)
  store i64 %t86, ptr %l52
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t87 = load i64, ptr %l52, !tbaa !65
  %t88 = xor i64 %t87, -1
  %t89 = load i64, ptr %l47, !tbaa !65
  %t91 = and i64 %t89, %t88
  store i64 %t91, ptr %l7, !tbaa !65
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l9, !tbaa !24
  br label %bb9
bb22:
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l57, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load i32, ptr %l6, !tbaa !23
  %t107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t103, i32 %t104)
  store i32 %t107, ptr %l62
  br label %bb23
bb23:
  %t108 = load i64, ptr %l7, !tbaa !65
  %t109 = load ptr, ptr %l57, !tbaa !29
  %t110 = load i32, ptr %l62, !tbaa !23
  %t112 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t109, i32 %t110, i64 %t108)
  store i32 %t112, ptr %l64
  br label %bb24
bb24:
  %t113 = load i32, ptr %l64, !tbaa !23
  store i32 %t113, ptr %l11, !tbaa !23
  %t114 = load i32, ptr %l11, !tbaa !23
  %t115 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t118 = icmp ne i32 %t114, %t115
  br i1 %t118, label %bb25, label %bb26
bb25:
  %t120 = load ptr, ptr %lp3
  %t121 = load i32, ptr %l11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v3, ptr %t120, i32 %t121)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb2
bb30:
  %t128 = load ptr, ptr %lp3
  %t129 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t128
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t129, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t9 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %t6, i32 %a1, %"compiler/source:Span" %a2)
  store i32 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i32, ptr %l7, !tbaa !23
  store i32 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etoAny(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i64
  %lp12 = alloca ptr
  %l16 = alloca i32
  %l21 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l37 = alloca %"compiler/msgs:Msg"
  %l38 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i32
  %l48 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l65 = alloca i32
  %l68 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i1
  %l81 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/msgs:Msg"
  %l95 = alloca i64
  %l101 = alloca i1
  %l105 = alloca ptr
  %l110 = alloca i64
  %l115 = alloca ptr
  %l120 = alloca i64
  %l127 = alloca i1
  %l132 = alloca ptr
  %l136 = alloca i32
  %l142 = alloca i64
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca i32
  %l148 = alloca i32
  %l152 = alloca { i64, ptr }
  %l154 = alloca %"compiler/typed:Make"
  %l158 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l167 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca %"compiler/typed:Promote"
  %l175 = alloca ptr
  %l176 = alloca %"compiler/source:Span"
  %l177 = alloca i32
  %l178 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l183 = alloca i32
  %l185 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca ptr
  %l195 = alloca i32
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l200 = alloca i32
  %l201 = alloca i32
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l206 = alloca i32
  %l208 = alloca ptr
  %l210 = alloca ptr
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t299 = alloca { i64, [5 x i64] }, align 8
  %t341 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l16
  br label %bb1
bb1:
  %t5 = load i32, ptr %l16, !tbaa !23
  store i32 %t5, ptr %l4, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l2, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l21
  br label %bb2
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t22, i32 %t23)
  store i1 %t26, ptr %l26
  br label %bb3
bb3:
  %t27 = load i1, ptr %l26, !tbaa !21
  br i1 %t27, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l27, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l4, !tbaa !23
  %t34 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t30, i32 %t31)
  store { i64, ptr } %t34, ptr %l31
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l32, !tbaa !27
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t42, i32 %t43)
  store { i64, ptr } %t46, ptr %l35
  br label %bb7
bb7:
  %t47 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  %t54 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t56 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotConverted(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t54, { i64, ptr } %t53)
  store %"compiler/msgs:Msg" %t56, ptr %l37
  br label %bb8
bb8:
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l28
  %t59 = load %"compiler/msgs:Msg", ptr %l37
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l38
  br label %bb9
bb9:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l3
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t61, %"compiler/source:Span" %t62)
  store ptr %t65, ptr %l41
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t66 = load ptr, ptr %l41, !tbaa !29
  store ptr %t66, ptr %rv
  br label %ret
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i32, ptr %l4, !tbaa !23
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l44
  br label %bb12
bb12:
  %t72 = load i32, ptr %l44, !tbaa !23
  store i32 %t72, ptr %l6, !tbaa !23
  %t73 = load i32, ptr %l6, !tbaa !23
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = icmp eq i32 %t73, %t74
  br i1 %t77, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb15
bb14:
  %t79 = load i32, ptr %l5, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  store i1 %t83, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb16, label %bb17
bb16:
  %t86 = load ptr, ptr %l1, !tbaa !29
  store ptr %t86, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 2
  %t94 = load i32, ptr %l6, !tbaa !23
  %t97 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l57
  br label %bb19
bb19:
  %t98 = load i32, ptr %l57
  %t100 = trunc i64 29 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb23
bb21:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l6, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l65
  br label %bb22
bb22:
  %t113 = load i32, ptr %l65
  %t115 = trunc i64 21 to i32
  %t116 = icmp eq i32 %t113, %t115
  store i1 %t116, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t118 = load i1, ptr %l60, !tbaa !21
  br i1 %t118, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb26
bb25:
  %t119 = load i32, ptr %l6, !tbaa !23
  %t120 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t123 = icmp eq i32 %t119, %t120
  store i1 %t123, ptr %l68, !tbaa !21
  br label %bb26
bb26:
  %t125 = load i1, ptr %l68, !tbaa !21
  br i1 %t125, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb29
bb28:
  %t126 = load i32, ptr %l6, !tbaa !23
  %t127 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t130 = icmp eq i32 %t126, %t127
  store i1 %t130, ptr %l72, !tbaa !21
  br label %bb29
bb29:
  %t132 = load i1, ptr %l72, !tbaa !21
  br i1 %t132, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb33
bb31:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t138 = getelementptr %"compiler/generic:Program", ptr %t136, i32 0, i32 2
  %t139 = load i32, ptr %l6, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t138, i32 %t139)
  store i32 %t142, ptr %l81
  br label %bb32
bb32:
  %t143 = load i32, ptr %l81
  %t145 = trunc i64 22 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l76, !tbaa !21
  br label %bb33
bb33:
  %t148 = load i1, ptr %l76, !tbaa !21
  br i1 %t148, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l84, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t150, ptr %l85
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l2, !tbaa !23
  %t155 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t151, i32 %t152)
  store { i64, ptr } %t155, ptr %l88
  br label %bb36
bb35:
  br label %bb40
bb36:
  %t156 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l89, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s3, ptr %t163, ptr %t164)
  store { i64, ptr } %t167, ptr %l92
  br label %bb37
bb37:
  %t168 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t177 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s3, ptr %s3, ptr %s3, { i64, ptr } %t175, { i64, ptr } %t174)
  store %"compiler/msgs:Msg" %t177, ptr %l94
  br label %bb38
bb38:
  %t178 = load ptr, ptr %l84, !tbaa !29
  %t179 = load %"compiler/source:Span", ptr %l85
  %t180 = load %"compiler/msgs:Msg", ptr %l94
  %t181 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t178, %"compiler/source:Span" %t179, %"compiler/msgs:Msg" %t180)
  store i64 %t181, ptr %l95
  br label %bb39
bb39:
  %t182 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  store ptr %t182, ptr %rv
  br label %ret
bb40:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i32, ptr %l6, !tbaa !23
  %t186 = load i32, ptr %l5, !tbaa !23
  %t187 = load %"compiler/source:Span", ptr %l3
  %t192 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %t184, i32 %t185, i32 %t186, %"compiler/source:Span" %t187)
  store i1 %t192, ptr %l101
  br label %bb41
bb41:
  %t193 = load i1, ptr %l101, !tbaa !21
  %t194 = xor i1 %t193, true
  br i1 %t194, label %bb42, label %bb43
bb42:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load %"compiler/source:Span", ptr %l3
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t196, %"compiler/source:Span" %t197)
  store ptr %t200, ptr %l105
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb45:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i32, ptr %l6, !tbaa !23
  %t204 = load i32, ptr %l5, !tbaa !23
  %t205 = load %"compiler/source:Span", ptr %l3
  %t210 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %t202, i32 %t203, i32 %t204, %"compiler/source:Span" %t205)
  store i64 %t210, ptr %l110
  br label %bb46
bb46:
  %t211 = load i64, ptr %l110, !tbaa !24
  store i64 %t211, ptr %l7, !tbaa !24
  %t212 = load i64, ptr %l7, !tbaa !24
  %t214 = icmp slt i64 %t212, 0
  br i1 %t214, label %bb47, label %bb48
bb47:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l3
  %t220 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t216, %"compiler/source:Span" %t217)
  store ptr %t220, ptr %l115
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t221 = load ptr, ptr %l115, !tbaa !29
  store ptr %t221, ptr %rv
  br label %ret
bb50:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l2, !tbaa !23
  %t231 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t227, i32 %t228)
  store i64 %t231, ptr %l120
  br label %bb51
bb51:
  %t232 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t233 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t236 = or i64 %t232, %t233
  %t237 = load i64, ptr %l120, !tbaa !24
  %t239 = and i64 %t237, %t236
  store i64 %t239, ptr %l8, !tbaa !24
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l6, !tbaa !23
  %t245 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %t241, i32 %t242)
  store i1 %t245, ptr %l127
  br label %bb52
bb52:
  %t246 = load i1, ptr %l127, !tbaa !21
  br i1 %t246, label %bb53, label %bb54
bb53:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load i32, ptr %l6, !tbaa !23
  %t250 = load %"compiler/source:Span", ptr %l3
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t247, ptr %t248, i32 %t249, %"compiler/source:Span" %t250)
  store ptr %t255, ptr %l132
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t256 = load ptr, ptr %l132, !tbaa !29
  store ptr %t256, ptr %l9, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load i32, ptr %l6, !tbaa !23
  %t264 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %t260, i32 %t261)
  store i32 %t264, ptr %l136
  br label %bb56
bb56:
  %t265 = load i32, ptr %l136, !tbaa !23
  store i32 %t265, ptr %l10, !tbaa !23
  %t266 = load i32, ptr %l10, !tbaa !23
  %t267 = load i32, ptr %l6, !tbaa !23
  %t270 = icmp ne i32 %t266, %t267
  br i1 %t270, label %bb57, label %bb58
bb57:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/check:Checker", ptr %t272, i32 0, i32 36
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l142
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t277 = load i64, ptr %l142, !tbaa !24
  store i64 %t277, ptr %l11, !tbaa !24
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 36
  %t281 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t280, ptr %t281)
  br label %bb60
bb60:
  %t284 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t284, ptr %l146
  %t285 = load i32, ptr %l10, !tbaa !23
  store i32 %t285, ptr %l147, !tbaa !23
  store i32 0, ptr %l148
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 36
  %t289 = load i64, ptr %l11, !tbaa !24
  %t292 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t288, i64 %t289)
  store { i64, ptr } %t292, ptr %l152
  br label %bb61
bb61:
  %t293 = load i32, ptr %l148
  %t294 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t296 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t293, i64 0, { i64, ptr } %t294, ptr null, i32 -1, i32 0, i1 false)
  store %"compiler/typed:Make" %t296, ptr %l154
  br label %bb62
bb62:
  %t297 = load %"compiler/typed:Make", ptr %l154
  %t298 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Make" %t297, ptr %t298
  store { i64, [5 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 0
  store i64 7, ptr %t300
  %t301 = load %"compiler/source:Span", ptr %l146
  %t302 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t301, 0
  %t303 = load i32, ptr %l147, !tbaa !23
  %t304 = insertvalue { %"compiler/source:Span", i32, ptr } %t302, i32 %t303, 1
  %t306 = insertvalue { %"compiler/source:Span", i32, ptr } %t304, ptr %t298, 2
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t306, ptr %t307
  %t308 = load { i64, [5 x i64] }, ptr %t299
  %t310 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t308, ptr %t310
  store ptr %t310, ptr %l9, !tbaa !29
  br label %bb63
bb63:
  %t312 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t312, ptr %l158
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/check:Checker", ptr %t313, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !29
  %t318 = getelementptr %"compiler/generic:Program", ptr %t316, i32 0, i32 2
  %t319 = load i32, ptr %l10, !tbaa !23
  %t320 = load i64, ptr %l8, !tbaa !24
  %t321 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t324 = and i64 %t320, %t321
  %t328 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t318, i32 %t319, i64 %t324)
  store i32 %t328, ptr %l166
  br label %bb64
bb64:
  %t329 = load ptr, ptr %l9, !tbaa !29
  store ptr %t329, ptr %l167, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l3
  %t335 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t330, i32 2, %"compiler/source:Span" %t331)
  store i32 %t335, ptr %l171
  br label %bb65
bb65:
  %t336 = load ptr, ptr %l167, !tbaa !29
  %t337 = load i32, ptr %l171, !tbaa !23
  %t338 = call %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v0, ptr %t336, i32 %t337)
  store %"compiler/typed:Promote" %t338, ptr %l172
  br label %bb66
bb66:
  %t339 = load %"compiler/typed:Promote", ptr %l172
  %t340 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Promote" %t339, ptr %t340
  store { i64, [5 x i64] } zeroinitializer, ptr %t341
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 0
  store i64 5, ptr %t342
  %t343 = load %"compiler/source:Span", ptr %l158
  %t344 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t343, 0
  %t345 = load i32, ptr %l166, !tbaa !23
  %t346 = insertvalue { %"compiler/source:Span", i32, ptr } %t344, i32 %t345, 1
  %t348 = insertvalue { %"compiler/source:Span", i32, ptr } %t346, ptr %t340, 2
  %t349 = getelementptr { i64, [5 x i64] }, ptr %t341, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t348, ptr %t349
  %t350 = load { i64, [5 x i64] }, ptr %t341
  %t351 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t351, ptr %lp12
  %t353 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t350, ptr %t353
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l175, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t355, ptr %l176
  %t356 = load i32, ptr %l2, !tbaa !23
  store i32 %t356, ptr %l177, !tbaa !23
  store i32 40, ptr %l178
  %t357 = load ptr, ptr %lp12
  store ptr %t357, ptr %l179, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l180, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t359, ptr %l181
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t360)
  store i32 %t362, ptr %l183
  br label %bb67
bb67:
  %t363 = load i64, ptr %l7, !tbaa !24
  %t364 = load ptr, ptr %l180, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l181
  %t366 = load i32, ptr %l183, !tbaa !23
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t364, %"compiler/source:Span" %t365, i32 %t366, i64 %t363)
  store ptr %t368, ptr %l185
  br label %bb68
bb68:
  %t369 = load ptr, ptr %l185, !tbaa !29
  %t370 = load ptr, ptr %l175, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l176
  %t372 = load i32, ptr %l177, !tbaa !23
  %t373 = load i32, ptr %l178
  %t374 = load ptr, ptr %l179, !tbaa !29
  %t376 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t370, %"compiler/source:Span" %t371, i32 %t372, i32 %t373, ptr %t374, ptr %t369)
  store ptr %t376, ptr %l187
  br label %bb69
bb69:
  %t377 = load ptr, ptr %l187, !tbaa !29
  store ptr %t377, ptr %rv
  br label %ret
bb70:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l188, !tbaa !29
  %t379 = load ptr, ptr %l1, !tbaa !29
  store ptr %t379, ptr %l189, !tbaa !29
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/check:Checker", ptr %t380, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !29
  %t385 = getelementptr %"compiler/generic:Program", ptr %t383, i32 0, i32 2
  %t386 = load i32, ptr %l6, !tbaa !23
  %t387 = load i64, ptr %l8, !tbaa !24
  %t391 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t385, i32 %t386, i64 %t387)
  store i32 %t391, ptr %l195
  br label %bb71
bb71:
  %t392 = load %"compiler/source:Span", ptr %l3
  %t393 = load ptr, ptr %l188, !tbaa !29
  %t394 = load ptr, ptr %l189, !tbaa !29
  %t395 = load i32, ptr %l195, !tbaa !23
  %t397 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t393, ptr %t394, i32 %t395, %"compiler/source:Span" %t392)
  store ptr %t397, ptr %l197
  br label %bb72
bb72:
  %t398 = load ptr, ptr %l197, !tbaa !29
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l198, !tbaa !29
  %t400 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t400, ptr %l199
  %t401 = load i32, ptr %l2, !tbaa !23
  store i32 %t401, ptr %l200, !tbaa !23
  store i32 40, ptr %l201
  store ptr %t398, ptr %l202, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  store ptr %t403, ptr %l203, !tbaa !29
  %t404 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t404, ptr %l204
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t407 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t405)
  store i32 %t407, ptr %l206
  br label %bb73
bb73:
  %t408 = load i64, ptr %l7, !tbaa !24
  %t409 = load ptr, ptr %l203, !tbaa !29
  %t410 = load %"compiler/source:Span", ptr %l204
  %t411 = load i32, ptr %l206, !tbaa !23
  %t413 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t409, %"compiler/source:Span" %t410, i32 %t411, i64 %t408)
  store ptr %t413, ptr %l208
  br label %bb74
bb74:
  %t414 = load ptr, ptr %l208, !tbaa !29
  %t415 = load ptr, ptr %l198, !tbaa !29
  %t416 = load %"compiler/source:Span", ptr %l199
  %t417 = load i32, ptr %l200, !tbaa !23
  %t418 = load i32, ptr %l201
  %t419 = load ptr, ptr %l202, !tbaa !29
  %t421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t415, %"compiler/source:Span" %t416, i32 %t417, i32 %t418, ptr %t419, ptr %t414)
  store ptr %t421, ptr %l210
  br label %bb75
bb75:
  %t422 = load ptr, ptr %l210, !tbaa !29
  store ptr %t422, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l27 = alloca %"compiler/generic:Unmet"
  %l30 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca i1
  %l56 = alloca i64
  %l63 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l72 = alloca %"compiler/generic:Context"
  %l76 = alloca i32
  %l84 = alloca { i64, ptr }
  %l90 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca ptr
  %l97 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l105 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/source:Span"
  %l121 = alloca { i64, ptr }
  %l123 = alloca %"compiler/msgs:Msg"
  %l124 = alloca i64
  %l127 = alloca i1
  %l139 = alloca { i64, ptr }
  %l145 = alloca i1
  %l148 = alloca i1
  %l151 = alloca i1
  %l154 = alloca i32
  %l156 = alloca ptr
  %l158 = alloca ptr
  %l163 = alloca i32
  %l167 = alloca i32
  %l172 = alloca [1 x i32]
  %l173 = alloca { i64, ptr }
  %l178 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l183 = alloca ptr
  %l185 = alloca %"compiler/source:Span"
  %l186 = alloca { i64, ptr }
  %l187 = alloca %"compiler/msgs:Msg"
  %l188 = alloca i64
  %l192 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l195 = alloca i64
  %l197 = alloca i64
  %l198 = alloca { i64, ptr }
  %l208 = alloca { i64, ptr }
  %l215 = alloca %"compiler/generic:Unmet"
  %l218 = alloca i1
  %l220 = alloca ptr
  %l222 = alloca %"compiler/source:Span"
  %l225 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca %"compiler/msgs:Msg"
  %l237 = alloca i64
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l30, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l30, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t19 = load ptr, ptr %l36, !tbaa !29
  %t20 = icmp ne ptr %t19, null
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l36, !tbaa !29
  %t23 = load i64, ptr %t22
  %t25 = icmp eq i64 %t23, 2
  store i1 %t25, ptr %l37, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l37, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr { i64, [6 x i64] }, ptr %t27, i32 0, i32 1
  %t30 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t29, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr { i64, [6 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t35, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb11
bb10:
  br label %bb120
bb11:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t43 = icmp eq i64 %t41, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t49 = icmp eq i64 %t47, 0
  store i1 %t49, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l47, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load i64, ptr %l1, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/ast:TypeDecl", ptr %t57, i32 0, i32 0
  %t60 = load i32, ptr %t59, !tbaa !23
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t55, i64 %t56, i32 %t60)
  store i64 %t64, ptr %l56
  br label %bb18
bb18:
  %t65 = load i64, ptr %l56, !tbaa !24
  store i64 %t65, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t68 = icmp slt i64 %t66, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  br label %ret
bb20:
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t79 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t73, i64 %t74, i64 %t75)
  store i32 %t79, ptr %l63
  br label %bb22
bb22:
  %t80 = load i32, ptr %l63, !tbaa !23
  store i32 %t80, ptr %l7, !tbaa !23
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t81, i64 -1, i64 %t82, i32 %t83, i32 0)
  store ptr %t87, ptr %l67
  br label %bb23
bb23:
  %t88 = load ptr, ptr %l67, !tbaa !29
  store ptr %t88, ptr %l68, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load i32, ptr %l7, !tbaa !23
  %t97 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  store %"compiler/generic:Context" %t97, ptr %l72
  br label %bb24
bb24:
  %t98 = load %"compiler/generic:Context", ptr %l72
  %t99 = load ptr, ptr %l68, !tbaa !29
  %t100 = getelementptr %"compiler/check:frame", ptr %t99, i32 0, i32 4
  store %"compiler/generic:Context" %t98, ptr %t100
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i32, ptr %l7, !tbaa !23
  %t108 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t108, ptr %l76
  br label %bb25
bb25:
  %t109 = load i32, ptr %l76, !tbaa !23
  store i32 %t109, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t110 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t110, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t112 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t124 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t124, ptr %l84, !tbaa !27
  %t125 = load i64, ptr %l12, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr ptr, ptr %t128, i64 %t125
  %t130 = load ptr, ptr %t129, !tbaa !39
  store ptr %t130, ptr %l14, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load ptr, ptr %l14, !tbaa !29
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t132, i64 %t133, ptr %t134)
  store i1 %t138, ptr %l90
  br label %bb30
bb30:
  %t139 = load i1, ptr %l90, !tbaa !21
  %t140 = xor i1 %t139, true
  br i1 %t140, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l92, !tbaa !29
  %t143 = load ptr, ptr %l14, !tbaa !29
  %t145 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t143)
  store %"compiler/source:Span" %t145, ptr %l94
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l95, !tbaa !29
  %t147 = load ptr, ptr %l14, !tbaa !29
  %t149 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t147)
  store %"compiler/source:Span" %t149, ptr %l97
  br label %bb34
bb34:
  %t150 = load ptr, ptr %l95, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l97
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, ptr } %t152, ptr %l98
  br label %bb35
bb35:
  %t153 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %s7, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t154, ptr %l99
  br label %bb36
bb36:
  %t155 = load ptr, ptr %l92, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l94
  %t157 = load %"compiler/msgs:Msg", ptr %l99
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l100
  br label %bb37
bb37:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l12, !tbaa !24
  br label %bb26
bb40:
  %t163 = load i1, ptr %l10, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb41, label %bb42
bb41:
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t171 = icmp sgt i64 %t169, 0
  store i1 %t171, ptr %l105, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb43
bb43:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb44, label %bb45
bb44:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load i32, ptr %l7, !tbaa !23
  %t176 = load i32, ptr %l9, !tbaa !23
  %t180 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t174, i32 %t175, i32 %t176, i64 0)
  store i1 %t180, ptr %l113
  br label %bb46
bb45:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb47
bb46:
  %t181 = load i1, ptr %l113, !tbaa !21
  store i1 %t181, ptr %l109, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l109, !tbaa !21
  br i1 %t182, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s9
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l114, !tbaa !29
  %t184 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t184, ptr %l115, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr ptr, ptr %t186, i64 0
  %t188 = load ptr, ptr %t187, !tbaa !39
  %t190 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t188)
  store %"compiler/source:Span" %t190, ptr %l117
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t194 = getelementptr %"compiler/ast:TypeDecl", ptr %t192, i32 0, i32 0
  %t195 = load i32, ptr %t194, !tbaa !23
  %t198 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s9, ptr %t191, i32 %t195)
  store { i64, ptr } %t198, ptr %l121
  br label %bb51
bb51:
  %t199 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t207 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %s9, ptr %s9, { i64, ptr } %t205)
  store %"compiler/msgs:Msg" %t207, ptr %l123
  br label %bb52
bb52:
  %t208 = load ptr, ptr %l114, !tbaa !29
  %t209 = load %"compiler/source:Span", ptr %l117
  %t210 = load %"compiler/msgs:Msg", ptr %l123
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t208, %"compiler/source:Span" %t209, %"compiler/msgs:Msg" %t210)
  store i64 %t211, ptr %l124
  br label %bb53
bb53:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb54
bb54:
  %t212 = load i1, ptr %l10, !tbaa !21
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb55, label %bb56
bb55:
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/ast:TypeDecl", ptr %t216, i32 0, i32 1
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t223 = icmp eq i64 %t221, 0
  store i1 %t223, ptr %l127, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb57
bb57:
  %t225 = load i1, ptr %l127, !tbaa !21
  store i1 %t225, ptr %l15, !tbaa !21
  %t226 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t226, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l18, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t232 = load i64, ptr %l17, !tbaa !24
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = icmp slt i64 %t232, %t233
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb118
bb60:
  br label %bb61
bb61:
  %t240 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t240, ptr %l139, !tbaa !27
  %t241 = load i64, ptr %l17, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr ptr, ptr %t244, i64 %t241
  %t246 = load ptr, ptr %t245, !tbaa !39
  store ptr %t246, ptr %l19, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l1, !tbaa !24
  %t250 = load ptr, ptr %l19, !tbaa !29
  %t254 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %t248, i64 %t249, ptr %t250)
  store i1 %t254, ptr %l145
  br label %bb62
bb62:
  %t255 = load i1, ptr %l145, !tbaa !21
  store i1 %t255, ptr %l20, !tbaa !21
  %t256 = load i1, ptr %l20, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb63, label %bb64
bb63:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l19, !tbaa !29
  %t264 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t260, ptr %t261, i1 true)
  store i1 %t264, ptr %l151
  br label %bb65
bb64:
  store i1 false, ptr %l148, !tbaa !21
  br label %bb66
bb65:
  %t265 = load i1, ptr %l151, !tbaa !21
  %t266 = xor i1 %t265, true
  store i1 %t266, ptr %l148, !tbaa !21
  br label %bb66
bb66:
  %t268 = load i1, ptr %l148, !tbaa !21
  br i1 %t268, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb68:
  br label %bb69
bb69:
  %t269 = load i1, ptr %l20, !tbaa !21
  br i1 %t269, label %bb70, label %bb71
bb70:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  store ptr %t274, ptr %l156, !tbaa !29
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t275)
  store ptr %t277, ptr %l158
  br label %bb72
bb71:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load ptr, ptr %l19, !tbaa !29
  %t283 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t278, ptr %t279)
  store i32 %t283, ptr %l167
  br label %bb74
bb72:
  %t284 = load ptr, ptr %l158, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 4
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = load ptr, ptr %l156, !tbaa !29
  %t292 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t289, ptr %t286, ptr %t287)
  store i32 %t292, ptr %l163
  br label %bb73
bb73:
  %t293 = load i32, ptr %l163, !tbaa !23
  store i32 %t293, ptr %l154, !tbaa !23
  br label %bb75
bb74:
  %t294 = load i32, ptr %l167, !tbaa !23
  store i32 %t294, ptr %l154, !tbaa !23
  br label %bb75
bb75:
  %t295 = load i32, ptr %l154, !tbaa !23
  store i32 %t295, ptr %l21, !tbaa !23
  %t296 = load i32, ptr %l21, !tbaa !23
  %t297 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t300 = icmp eq i32 %t296, %t297
  br i1 %t300, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb77:
  br label %bb78
bb78:
  %t302 = load i32, ptr %l21, !tbaa !23
  %t304 = insertvalue [1 x i32] undef, i32 %t302, 0
  store [1 x i32] %t304, ptr %l172
  %t305 = mul i64 1, 4
  %t306 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t305)
  %t307 = insertvalue { i64, ptr } undef, i64 1, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l173, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = mul i64 1, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t310, ptr %l172, i64 %t311, i1 false)
  %t312 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t312, ptr %l22, !tbaa !27
  %t313 = load i1, ptr %l20, !tbaa !21
  br i1 %t313, label %bb79, label %bb80
bb79:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load i32, ptr %l21, !tbaa !23
  %t322 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t318, i32 %t319)
  store i1 %t322, ptr %l178
  br label %bb81
bb80:
  br label %bb94
bb81:
  %t323 = load i1, ptr %l178, !tbaa !21
  %t324 = xor i1 %t323, true
  br i1 %t324, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s15
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l180, !tbaa !29
  %t327 = load ptr, ptr %l19, !tbaa !29
  %t329 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t327)
  store %"compiler/source:Span" %t329, ptr %l182
  br label %bb84
bb83:
  br label %bb89
bb84:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l183, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t333 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t331)
  store %"compiler/source:Span" %t333, ptr %l185
  br label %bb85
bb85:
  %t334 = load ptr, ptr %l183, !tbaa !29
  %t335 = load %"compiler/source:Span", ptr %l185
  %t336 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t334, %"compiler/source:Span" %t335)
  store { i64, ptr } %t336, ptr %l186
  br label %bb86
bb86:
  %t337 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t338 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %s15, { i64, ptr } %t337)
  store %"compiler/msgs:Msg" %t338, ptr %l187
  br label %bb87
bb87:
  %t339 = load ptr, ptr %l180, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l182
  %t341 = load %"compiler/msgs:Msg", ptr %l187
  %t342 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t339, %"compiler/source:Span" %t340, %"compiler/msgs:Msg" %t341)
  store i64 %t342, ptr %l188
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb89:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = getelementptr %"compiler/check:Checker", ptr %t343, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !29
  %t347 = load i32, ptr %l21, !tbaa !23
  %t350 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t346, i32 %t347)
  store { i64, ptr } %t350, ptr %l192
  br label %bb90
bb90:
  %t351 = load { i64, ptr }, ptr %l192, !tbaa !27
  store { i64, ptr } %t351, ptr %l193, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t352, 0
  %t354 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  store i64 %t355, ptr %l195, !tbaa !24
  %t357 = load i64, ptr %l195, !tbaa !24
  %t358 = icmp eq i64 %t353, %t357
  br i1 %t358, label %bb91, label %bb92
bb91:
  %t360 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l195, !tbaa !24
  %t365 = mul i64 %t364, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t361, ptr %t363, i64 %t365, i1 false)
  br label %bb93
bb92:
  %t366 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 0
  store i64 %t367, ptr %l197, !tbaa !24
  %t368 = load i64, ptr %l197, !tbaa !24
  %t369 = mul i64 %t368, 4
  %t370 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t369)
  %t371 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  store { i64, ptr } %t372, ptr %l198, !tbaa !27
  %t373 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = load i64, ptr %l197, !tbaa !24
  %t378 = mul i64 %t377, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t374, ptr %t376, i64 %t378, i1 false)
  %t379 = load { i64, ptr }, ptr %l198, !tbaa !27
  store { i64, ptr } %t379, ptr %l22, !tbaa !27
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t380 = load i1, ptr %l15, !tbaa !21
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb96:
  br label %bb97
bb97:
  %t384 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t384, ptr %l23, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t386 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t386, 0
  store i64 %t388, ptr %l25, !tbaa !24
  br label %bb98
bb98:
  %t390 = load i64, ptr %l24, !tbaa !24
  %t391 = load i64, ptr %l25, !tbaa !24
  %t394 = icmp slt i64 %t390, %t391
  %t396 = xor i1 %t394, true
  br i1 %t396, label %bb99, label %bb100
bb99:
  br label %bb116
bb100:
  br label %bb101
bb101:
  %t398 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t398, ptr %l208, !tbaa !27
  %t399 = load i64, ptr %l24, !tbaa !24
  %t401 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr i32, ptr %t402, i64 %t399
  %t404 = load i32, ptr %t403, !tbaa !33
  store i32 %t404, ptr %l26, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/check:Checker", ptr %t406, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load i32, ptr %l26, !tbaa !23
  %t411 = load i32, ptr %l9, !tbaa !23
  %t415 = call %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %t409, i32 %t410, i32 %t411, i1 false, i64 0)
  store %"compiler/generic:Unmet" %t415, ptr %l215
  br label %bb102
bb102:
  %t416 = load %"compiler/generic:Unmet", ptr %l215
  store %"compiler/generic:Unmet" %t416, ptr %l27
  %t417 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 0
  %t418 = load i64, ptr %t417, !tbaa !24
  %t420 = icmp sge i64 %t418, 0
  br i1 %t420, label %bb103, label %bb104
bb103:
  %t422 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 3
  %t423 = load i1, ptr %t422, !tbaa !21
  store i1 %t423, ptr %l218, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb105
bb105:
  %t425 = load i1, ptr %l218, !tbaa !21
  br i1 %t425, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s19
  %t426 = load ptr, ptr %l0, !tbaa !29
  store ptr %t426, ptr %l220, !tbaa !29
  %t427 = load ptr, ptr %l19, !tbaa !29
  %t429 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t427)
  store %"compiler/source:Span" %t429, ptr %l222
  br label %bb108
bb107:
  br label %bb114
bb108:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i32, ptr %l26, !tbaa !23
  %t434 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s19, ptr %t430, i32 %t431)
  store { i64, ptr } %t434, ptr %l225
  br label %bb109
bb109:
  %t435 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t435, 0
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = mul i64 %t436, 1
  %t439 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t438)
  call void @llvm.memcpy.p0.p0.i64(ptr %t439, ptr %t437, i64 %t438, i1 false)
  %t440 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  store { i64, ptr } %t441, ptr %l226, !tbaa !27
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = getelementptr %"compiler/ast:TypeDecl", ptr %t443, i32 0, i32 0
  %t446 = load i32, ptr %t445, !tbaa !23
  %t449 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t442, i32 %t446)
  store { i64, ptr } %t449, ptr %l230
  br label %bb110
bb110:
  %t450 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t451 = extractvalue { i64, ptr } %t450, 0
  %t452 = extractvalue { i64, ptr } %t450, 1
  %t453 = mul i64 %t451, 1
  %t454 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t453)
  call void @llvm.memcpy.p0.p0.i64(ptr %t454, ptr %t452, i64 %t453, i1 false)
  %t455 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t456 = insertvalue { i64, ptr } %t455, ptr %t454, 1
  store { i64, ptr } %t456, ptr %l231, !tbaa !27
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/generic:Unmet", ptr %l27, i32 0, i32 2
  %t459 = load i32, ptr %t458, !tbaa !23
  %t462 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s19, ptr %t457, i32 %t459)
  store { i64, ptr } %t462, ptr %l234
  br label %bb111
bb111:
  %t463 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 0
  %t465 = extractvalue { i64, ptr } %t463, 1
  %t466 = mul i64 %t464, 1
  %t467 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t466)
  call void @llvm.memcpy.p0.p0.i64(ptr %t467, ptr %t465, i64 %t466, i1 false)
  %t468 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t470 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t471 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t473 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %s19, ptr %s19, ptr %s19, ptr %s19, { i64, ptr } %t470, { i64, ptr } %t471, { i64, ptr } %t469)
  store %"compiler/msgs:Msg" %t473, ptr %l236
  br label %bb112
bb112:
  %t474 = load ptr, ptr %l220, !tbaa !29
  %t475 = load %"compiler/source:Span", ptr %l222
  %t476 = load %"compiler/msgs:Msg", ptr %l236
  %t477 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t474, %"compiler/source:Span" %t475, %"compiler/msgs:Msg" %t476)
  store i64 %t477, ptr %l237
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s19)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t478 = load i64, ptr %l24, !tbaa !24
  %t480 = add i64 %t478, 1
  store i64 %t480, ptr %l24, !tbaa !24
  br label %bb98
bb116:
  call void @__olang_scope_close(ptr %s11)
  br label %bb117
bb117:
  %t482 = load i64, ptr %l17, !tbaa !24
  %t484 = add i64 %t482, 1
  store i64 %t484, ptr %l17, !tbaa !24
  br label %bb58
bb118:
  %t486 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t486)
  br label %bb119
bb119:
  br label %bb125
bb120:
  br i1 true, label %bb121, label %bb122
bb121:
  br label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb125
bb124:
  call void @__olang_check_failed(ptr @olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606)
  unreachable
bb125:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %s0, ptr %a0, ptr %l2, i32 %a1, i1 true)
  br label %bb2
bb2:
  %t9 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t10, ptr %l9, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l10, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t24, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l13 = alloca %"compiler/check:litv"
  %l16 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i1
  %l32 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i32
  %l60 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i1
  %l75 = alloca i64
  %l78 = alloca ptr
  %l80 = alloca %"compiler/source:Span"
  %l81 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l89 = alloca i1
  %l92 = alloca ptr
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l102 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca ptr
  %l122 = alloca i1
  %l123 = alloca i32
  %l127 = alloca i32
  %l129 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l140 = alloca ptr
  %l146 = alloca i1
  %l150 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca ptr
  %l157 = alloca i32
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l165 = alloca %"compiler/source:Span"
  %l168 = alloca ptr
  %l172 = alloca i1
  %l173 = alloca i32
  %l178 = alloca i32
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca ptr
  %l191 = alloca i32
  %l192 = alloca i32
  %l196 = alloca ptr
  %l199 = alloca %"compiler/source:Span"
  %l202 = alloca { i64, ptr }
  %l204 = alloca %"compiler/msgs:Msg"
  %l205 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l209 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store %"compiler/check:litv" %t6, ptr %l13
  br label %bb1
bb1:
  %t7 = load %"compiler/check:litv", ptr %l13
  store %"compiler/check:litv" %t7, ptr %l2
  %t8 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 0
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 1
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t19, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i32 %t21, ptr %l20
  br label %bb6
bb5:
  %t22 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 2
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb6:
  %t25 = load i32, ptr %l20, !tbaa !23
  store i32 %t25, ptr %l16, !tbaa !23
  br label %bb19
bb7:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t31, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i32 %t33, ptr %l26
  br label %bb9
bb8:
  %t34 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp sge i64 %t35, -2147483648
  br i1 %t37, label %bb10, label %bb11
bb9:
  %t39 = load i32, ptr %l26, !tbaa !23
  store i32 %t39, ptr %l22, !tbaa !23
  br label %bb18
bb10:
  %t40 = getelementptr %"compiler/check:litv", ptr %l2, i32 0, i32 3
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = icmp sle i64 %t41, 2147483647
  store i1 %t43, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb13, label %bb14
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s1, ptr %t51, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i32 %t53, ptr %l36
  br label %bb15
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l38
  br label %bb16
bb15:
  %t57 = load i32, ptr %l36, !tbaa !23
  store i32 %t57, ptr %l32, !tbaa !23
  br label %bb17
bb16:
  %t58 = load i32, ptr %l38, !tbaa !23
  store i32 %t58, ptr %l32, !tbaa !23
  br label %bb17
bb17:
  %t59 = load i32, ptr %l32, !tbaa !23
  store i32 %t59, ptr %l22, !tbaa !23
  br label %bb18
bb18:
  %t60 = load i32, ptr %l22, !tbaa !23
  store i32 %t60, ptr %l16, !tbaa !23
  br label %bb19
bb19:
  %t61 = load i32, ptr %l16, !tbaa !23
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t62, ptr %t63, i32 %t61)
  store ptr %t69, ptr %l43
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t71, ptr %t72, i32 %t74)
  store ptr %t78, ptr %l48
  br label %bb22
bb22:
  %t79 = load ptr, ptr %l48, !tbaa !29
  store ptr %t79, ptr %l4, !tbaa !29
  %t80 = load ptr, ptr %l4, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb23
bb23:
  %t84 = load i32, ptr %l51, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load i32, ptr %l5, !tbaa !23
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t89 = icmp eq i32 %t85, %t86
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t91, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l5, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l60
  br label %bb27
bb27:
  %t103 = load i32, ptr %l60, !tbaa !23
  store i32 %t103, ptr %l6, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  %t110 = load i32, ptr %l6, !tbaa !23
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t109, i32 %t110)
  store i32 %t113, ptr %l65
  br label %bb28
bb28:
  %t114 = load i32, ptr %l65
  store i32 %t114, ptr %l7
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l6, !tbaa !23
  %t124 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l70
  br label %bb29
bb29:
  %t125 = load i1, ptr %l70, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t131, i32 %t132)
  store i64 %t135, ptr %l75
  br label %bb32
bb31:
  br label %bb73
bb32:
  %t136 = load i64, ptr %l75, !tbaa !24
  store i64 %t136, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t139 = icmp slt i64 %t137, 32
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l78, !tbaa !29
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t142)
  store %"compiler/source:Span" %t144, ptr %l80
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t145 = load ptr, ptr %l4, !tbaa !29
  store ptr %t145, ptr %l81, !tbaa !29
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/generic:Program", ptr %t149, i32 0, i32 2
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i32 %t153, ptr %l85
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l80
  %t156 = load ptr, ptr %l81, !tbaa !29
  %t157 = load i32, ptr %l85, !tbaa !23
  %t158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t154, %"compiler/source:Span" %t155, ptr %t156, i32 %t157)
  store ptr %t158, ptr %l86
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t159 = load ptr, ptr %l86, !tbaa !29
  store ptr %t159, ptr %rv
  br label %ret
bb38:
  %t160 = load i32, ptr %l7
  %t162 = trunc i64 31 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb39, label %bb40
bb39:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t167 = icmp sgt i64 %t165, 64
  store i1 %t167, ptr %l89, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb41
bb41:
  %t169 = load i1, ptr %l89, !tbaa !21
  br i1 %t169, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l92, !tbaa !29
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t171, ptr %t172)
  store %"compiler/source:Span" %t175, ptr %l95
  br label %bb44
bb43:
  br label %bb50
bb44:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t176, i32 %t177)
  store { i64, ptr } %t180, ptr %l98
  br label %bb45
bb45:
  %t181 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %s5, ptr %s5, { i64, ptr } %t187)
  store %"compiler/msgs:Msg" %t189, ptr %l100
  br label %bb46
bb46:
  %t190 = load ptr, ptr %l92, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l95
  %t192 = load %"compiler/msgs:Msg", ptr %l100
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l101
  br label %bb47
bb47:
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t195)
  store %"compiler/source:Span" %t197, ptr %l104
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l104
  %t200 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t198, %"compiler/source:Span" %t199)
  store ptr %t200, ptr %l105
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t201 = load ptr, ptr %l105, !tbaa !29
  store ptr %t201, ptr %rv
  br label %ret
bb50:
  %t202 = load i32, ptr %l7
  %t204 = trunc i64 31 to i32
  %t205 = icmp eq i32 %t202, %t204
  br i1 %t205, label %bb51, label %bb52
bb51:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t209 = icmp ne i64 %t207, 32
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb53
bb53:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb54, label %bb55
bb54:
  %t212 = load i64, ptr %l8, !tbaa !24
  %t214 = icmp ne i64 %t212, 64
  store i1 %t214, ptr %l111, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb56
bb56:
  %t216 = load i1, ptr %l111, !tbaa !21
  br i1 %t216, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l114, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l116
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t221 = load ptr, ptr %l4, !tbaa !29
  store ptr %t221, ptr %l117, !tbaa !29
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  %t228 = load i32, ptr %l6, !tbaa !23
  %t231 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t227, i32 %t228)
  store i1 %t231, ptr %l122
  br label %bb60
bb60:
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  %t240 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s6, ptr %t238, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i32 %t240, ptr %l127
  br label %bb63
bb62:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t241)
  store i32 %t243, ptr %l129
  br label %bb64
bb63:
  %t244 = load i32, ptr %l127, !tbaa !23
  store i32 %t244, ptr %l123, !tbaa !23
  br label %bb65
bb64:
  %t245 = load i32, ptr %l129, !tbaa !23
  store i32 %t245, ptr %l123, !tbaa !23
  br label %bb65
bb65:
  %t246 = load ptr, ptr %l114, !tbaa !29
  %t247 = load %"compiler/source:Span", ptr %l116
  %t248 = load ptr, ptr %l117, !tbaa !29
  %t249 = load i32, ptr %l123, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t246, %"compiler/source:Span" %t247, ptr %t248, i32 %t249)
  store ptr %t250, ptr %l130
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t251 = load ptr, ptr %l130, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
bb67:
  %t252 = load i32, ptr %l6, !tbaa !23
  %t253 = load i32, ptr %l5, !tbaa !23
  %t256 = icmp ne i32 %t252, %t253
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l135, !tbaa !29
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t259)
  store %"compiler/source:Span" %t261, ptr %l137
  br label %bb70
bb69:
  %t262 = load ptr, ptr %l4, !tbaa !29
  store ptr %t262, ptr %l134, !tbaa !29
  br label %bb72
bb70:
  %t264 = load ptr, ptr %l4, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t266 = load ptr, ptr %l135, !tbaa !29
  %t267 = load %"compiler/source:Span", ptr %l137
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t266, %"compiler/source:Span" %t267, ptr %t264, i32 %t265)
  store ptr %t270, ptr %l140
  br label %bb71
bb71:
  %t271 = load ptr, ptr %l140, !tbaa !29
  store ptr %t271, ptr %l134, !tbaa !29
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t272 = load ptr, ptr %l134, !tbaa !29
  store ptr %t272, ptr %rv
  br label %ret
bb73:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/check:Checker", ptr %t273, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !29
  %t278 = getelementptr %"compiler/generic:Program", ptr %t276, i32 0, i32 2
  %t279 = load i32, ptr %l6, !tbaa !23
  %t282 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t278, i32 %t279)
  store i1 %t282, ptr %l146
  br label %bb74
bb74:
  %t283 = load i1, ptr %l146, !tbaa !21
  br i1 %t283, label %bb75, label %bb76
bb75:
  %t284 = load i32, ptr %l7
  %t286 = trunc i64 14 to i32
  %t287 = icmp eq i32 %t284, %t286
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb77, label %bb78
bb76:
  br label %bb88
bb77:
  store %olang.scope zeroinitializer, ptr %s8
  %t291 = load ptr, ptr %l0, !tbaa !29
  store ptr %t291, ptr %l150, !tbaa !29
  %t292 = load ptr, ptr %l1, !tbaa !29
  %t294 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t292)
  store %"compiler/source:Span" %t294, ptr %l152
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t295 = load ptr, ptr %l4, !tbaa !29
  store ptr %t295, ptr %l153, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = getelementptr %"compiler/check:Checker", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/generic:Program", ptr %t299, i32 0, i32 2
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s8, ptr %t301, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i32 %t303, ptr %l157
  br label %bb80
bb80:
  %t304 = load ptr, ptr %l150, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l152
  %t306 = load ptr, ptr %l153, !tbaa !29
  %t307 = load i32, ptr %l157, !tbaa !23
  %t308 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t304, %"compiler/source:Span" %t305, ptr %t306, i32 %t307)
  store ptr %t308, ptr %l158
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t309 = load ptr, ptr %l158, !tbaa !29
  store ptr %t309, ptr %rv
  br label %ret
bb82:
  %t310 = load i32, ptr %l6, !tbaa !23
  %t311 = load i32, ptr %l5, !tbaa !23
  %t314 = icmp ne i32 %t310, %t311
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l163, !tbaa !29
  %t317 = load ptr, ptr %l1, !tbaa !29
  %t319 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t317)
  store %"compiler/source:Span" %t319, ptr %l165
  br label %bb85
bb84:
  %t320 = load ptr, ptr %l4, !tbaa !29
  store ptr %t320, ptr %l162, !tbaa !29
  br label %bb87
bb85:
  %t322 = load ptr, ptr %l4, !tbaa !29
  %t323 = load i32, ptr %l6, !tbaa !23
  %t324 = load ptr, ptr %l163, !tbaa !29
  %t325 = load %"compiler/source:Span", ptr %l165
  %t328 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t324, %"compiler/source:Span" %t325, ptr %t322, i32 %t323)
  store ptr %t328, ptr %l168
  br label %bb86
bb86:
  %t329 = load ptr, ptr %l168, !tbaa !29
  store ptr %t329, ptr %l162, !tbaa !29
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t330 = load ptr, ptr %l162, !tbaa !29
  store ptr %t330, ptr %rv
  br label %ret
bb88:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l6, !tbaa !23
  %t335 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t331, i32 %t332)
  store i1 %t335, ptr %l172
  br label %bb89
bb89:
  %t336 = load i1, ptr %l172, !tbaa !21
  br i1 %t336, label %bb90, label %bb91
bb90:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/check:Checker", ptr %t337, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !29
  %t342 = getelementptr %"compiler/generic:Program", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %l6, !tbaa !23
  %t346 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t342, i32 %t343)
  store i32 %t346, ptr %l178
  br label %bb92
bb91:
  %t347 = load i32, ptr %l6, !tbaa !23
  store i32 %t347, ptr %l173, !tbaa !23
  br label %bb93
bb92:
  %t349 = load i32, ptr %l178, !tbaa !23
  store i32 %t349, ptr %l173, !tbaa !23
  br label %bb93
bb93:
  %t350 = load i32, ptr %l173, !tbaa !23
  store i32 %t350, ptr %l9, !tbaa !23
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i32, ptr %l6, !tbaa !23
  %t355 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t351, i32 %t352)
  store i1 %t355, ptr %l182
  br label %bb94
bb94:
  %t356 = load i1, ptr %l182, !tbaa !21
  br i1 %t356, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb99
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/check:Checker", ptr %t357, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t362 = getelementptr %"compiler/generic:Program", ptr %t360, i32 0, i32 2
  store ptr %t362, ptr %l186, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/check:Checker", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = getelementptr %"compiler/generic:Program", ptr %t366, i32 0, i32 2
  %t369 = load i32, ptr %l9, !tbaa !23
  %t372 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t368, i32 %t369)
  store i32 %t372, ptr %l191
  br label %bb97
bb97:
  %t373 = load ptr, ptr %l186, !tbaa !29
  %t374 = load i32, ptr %l191, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t373, i32 %t374)
  store i32 %t375, ptr %l192
  br label %bb98
bb98:
  %t376 = load i32, ptr %l192
  %t378 = trunc i64 19 to i32
  %t379 = icmp eq i32 %t376, %t378
  store i1 %t379, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t381 = load i1, ptr %l183, !tbaa !21
  br i1 %t381, label %bb100, label %bb101
bb100:
  %t382 = load ptr, ptr %l4, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t382, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t384, ptr %l196, !tbaa !29
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  %t389 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t385, ptr %t386)
  store %"compiler/source:Span" %t389, ptr %l199
  br label %bb103
bb103:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load i32, ptr %l5, !tbaa !23
  %t394 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t390, i32 %t391)
  store { i64, ptr } %t394, ptr %l202
  br label %bb104
bb104:
  %t395 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  %t397 = extractvalue { i64, ptr } %t395, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  %t403 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %s0, ptr %s0, { i64, ptr } %t401)
  store %"compiler/msgs:Msg" %t403, ptr %l204
  br label %bb105
bb105:
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t405 = load %"compiler/source:Span", ptr %l199
  %t406 = load %"compiler/msgs:Msg", ptr %l204
  %t407 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t404, %"compiler/source:Span" %t405, %"compiler/msgs:Msg" %t406)
  store i64 %t407, ptr %l205
  br label %bb106
bb106:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l206, !tbaa !29
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t409)
  store %"compiler/source:Span" %t411, ptr %l208
  br label %bb107
bb107:
  %t412 = load ptr, ptr %l206, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t412, %"compiler/source:Span" %t413)
  store ptr %t414, ptr %l209
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t415 = load ptr, ptr %l209, !tbaa !29
  store ptr %t415, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i1 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l18 = alloca i32
  %l22 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i1
  %l68 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 2
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l18
  br label %bb4
bb4:
  %t16 = load i32, ptr %l18
  store i32 %t16, ptr %l6
  %t17 = load i32, ptr %l6
  %t19 = trunc i64 25 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb16
bb7:
  br i1 %a4, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t29, i32 %t30)
  store i64 %t33, ptr %l27
  br label %bb10
bb9:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t37 = icmp eq i64 %t35, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l35
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l35, !tbaa !24
  %t53 = icmp eq i64 %t51, %t50
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l30, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
bb16:
  %t56 = load i32, ptr %l6
  %t58 = trunc i64 19 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l40, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l45
  br label %bb20
bb20:
  %t72 = load i64, ptr %l2, !tbaa !24
  %t73 = load i64, ptr %l3, !tbaa !24
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  %t77 = load ptr, ptr %l40, !tbaa !29
  %t78 = load i32, ptr %l45, !tbaa !23
  %t82 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t77, i32 %t78, i64 %t72, i64 %t73, i1 true, i64 %t76)
  store i1 %t82, ptr %l50
  br label %bb21
bb21:
  %t83 = load i1, ptr %l50, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
bb22:
  %t84 = load i32, ptr %l6
  %t86 = trunc i64 20 to i32
  %t87 = icmp eq i32 %t84, %t86
  br i1 %t87, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l53, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l1, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l58
  br label %bb26
bb26:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t102 = load i64, ptr %l5, !tbaa !24
  %t104 = add i64 %t102, 1
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = load i32, ptr %l58, !tbaa !23
  %t110 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t105, i32 %t106, i64 %t100, i64 %t101, i1 false, i64 %t104)
  store i1 %t110, ptr %l63
  br label %bb27
bb27:
  %t111 = load i1, ptr %l63, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb28:
  %t112 = load i32, ptr %l6
  %t114 = trunc i64 18 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb44
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  store ptr %t122, ptr %l68, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = getelementptr %"compiler/generic:Program", ptr %t126, i32 0, i32 2
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l73
  br label %bb32
bb32:
  %t133 = load ptr, ptr %l68, !tbaa !29
  %t134 = load i32, ptr %l73, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l74
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t136, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb34
bb34:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l81, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l2, !tbaa !24
  %t160 = load i64, ptr %l3, !tbaa !24
  %t161 = load i64, ptr %l5, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarInArray(ptr %v0, ptr %t157, i32 %t155, i64 %t159, i64 %t160, i1 true, i64 %t163)
  store i1 %t169, ptr %l90
  br label %bb38
bb38:
  %t170 = load i1, ptr %l90, !tbaa !21
  br i1 %t170, label %bb39, label %bb40
bb39:
  store i1 true, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l8, !tbaa !24
  br label %bb34
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store i1 false, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_7be86efb5ba886a_70e2aca6e0519896)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l52 = alloca i1
  %l55 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 44
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb32
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 44
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 44
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb17
bb16:
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 5
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l52, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l52, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb31
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t97)
  store i32 %t100, ptr %l60
  br label %bb21
bb21:
  %t101 = load ptr, ptr %l55, !tbaa !29
  %t102 = load i32, ptr %l60, !tbaa !23
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t101, i32 %t102)
  store ptr %t103, ptr %l61
  br label %bb22
bb22:
  %t104 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l61, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t106, i64 %t105)
  store ptr %t108, ptr %l63
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l63, !tbaa !29
  store ptr %t109, ptr %l10, !tbaa !29
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb26
bb25:
  %t114 = load ptr, ptr %l10, !tbaa !29
  %t116 = getelementptr %"compiler/ast:CaseDecl", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  %t119 = xor i1 %t117, true
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb26
bb26:
  %t121 = load i1, ptr %l66, !tbaa !21
  br i1 %t121, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l2, !tbaa !29
  %t125 = getelementptr %"compiler/check:frame", ptr %t123, i32 0, i32 45
  %t126 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t127 = load i64, ptr %t126, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t127)
  store i64 %t130, ptr %l74
  br label %bb30
bb30:
  %t131 = load i64, ptr %l74, !tbaa !24
  store i64 %t131, ptr %rv
  br label %ret
bb31:
  %t132 = load i64, ptr %l7, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l7, !tbaa !24
  br label %bb9
bb32:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eexprsAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2efloatLit(double %a0) #0 {
entry:
  %l2 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 true, i1 true, i1 false, i64 0, double %a0)
  store %"compiler/check:litv" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:litv", ptr %l2
  store %"compiler/check:litv" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb21
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_f65b5445e0db363a_c2ab951bd73e6226)
  unreachable
bb19:
  br label %bb20
bb20:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elistName(ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca [6 x { i64, ptr }]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t2 = insertvalue [6 x { i64, ptr }] %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t3 = insertvalue [6 x { i64, ptr }] %t2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d62, i32 0, i32 1) }, 2
  %t4 = insertvalue [6 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d63, i32 0, i32 1) }, 3
  %t5 = insertvalue [6 x { i64, ptr }] %t4, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, 4
  %t6 = insertvalue [6 x { i64, ptr }] %t5, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d65, i32 0, i32 1) }, 5
  store [6 x { i64, ptr }] %t6, ptr %l1
  %t9 = getelementptr [6 x { i64, ptr }], ptr %l1, i64 0, i64 %a0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !37
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local double @compiler_2fcheck_2elitF64(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l3 = alloca double
  %l10 = alloca double
  %rv = alloca double
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 7
  %t5 = load i1, ptr %t4, !tbaa !21
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t7 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t8 = load i128, ptr %t7
  %t10 = uitofp i128 %t8 to double
  %t12 = fneg double %t10
  store double %t12, ptr %l3, !tbaa !26
  br label %bb5
bb4:
  %t14 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 8
  %t15 = load i128, ptr %t14
  %t17 = uitofp i128 %t15 to double
  store double %t17, ptr %l3, !tbaa !26
  br label %bb5
bb5:
  %t19 = load double, ptr %l3, !tbaa !26
  store double %t19, ptr %rv
  br label %ret
bb6:
  %t20 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 2
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t27 = uitofp i64 %t24 to double
  store double %t27, ptr %l10, !tbaa !26
  br label %bb9
bb8:
  %t29 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sitofp i64 %t30 to double
  store double %t32, ptr %l10, !tbaa !26
  br label %bb9
bb9:
  %t34 = load double, ptr %l10, !tbaa !26
  store double %t34, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb4:
  %t6 = load i32, ptr %l0
  %t8 = trunc i64 53 to i32
  %t9 = icmp eq i32 %t6, %t8
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb8:
  %t11 = load i32, ptr %l0
  %t13 = trunc i64 54 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb12:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 55 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb16:
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 56 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb20:
  %t26 = load i32, ptr %l0
  %t28 = trunc i64 57 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb24:
  %t31 = load i32, ptr %l0
  %t33 = trunc i64 79 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t36 = load i32, ptr %l0
  %t38 = trunc i64 81 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t41 = load i32, ptr %l0
  %t43 = trunc i64 80 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t46 = load i32, ptr %l0
  %t48 = trunc i64 82 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb34:
  %t51 = load i32, ptr %l0
  %t53 = trunc i64 83 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb38:
  %t56 = load i32, ptr %l0
  %t58 = trunc i64 84 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb42:
  %t61 = load i32, ptr %l0
  %t63 = trunc i64 85 to i32
  %t64 = icmp eq i32 %t61, %t63
  br i1 %t64, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb46:
  %t66 = load i32, ptr %l0
  %t68 = trunc i64 88 to i32
  %t69 = icmp eq i32 %t66, %t68
  br i1 %t69, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb50:
  %t71 = load i32, ptr %l0
  %t73 = trunc i64 89 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l1, !tbaa !27
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_445c35e7b454dfb2_9156676d88e8071e)
  unreachable
bb59:
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eplainLen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb17
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l8, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l8, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [5 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32 }, ptr %t21, i32 0, i32 1
  %t23 = load i32, ptr %t22
  store i32 %t23, ptr %l1
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t25 = load i32, ptr %l1
  %t27 = trunc i64 2 to i32
  %t28 = icmp eq i32 %t25, %t27
  store i1 %t28, ptr %l2, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_64562bc7ca55259a_4dcf078b9ca87c6)
  unreachable
bb17:
  %t30 = load i1, ptr %l2, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 true, i64 %t1, i64 0, { i64, ptr } %a0, i32 %t3)
  store %"compiler/check:reflVal" %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"compiler/check:reflVal", ptr %l4
  store %"compiler/check:reflVal" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ewideBits(i32 %a0, %"compiler/check:litv" %a1, %"compiler/check:litv" %a2) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca { i1, i128 }
  %l4 = alloca i1
  %l5 = alloca i128
  %l6 = alloca { i1, i128 }
  %l7 = alloca i1
  %l8 = alloca i128
  %l9 = alloca i1
  %l10 = alloca i128
  %l12 = alloca { i1, i128 }
  %l16 = alloca { i1, i128 }
  %l21 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l36 = alloca i128
  %l42 = alloca i128
  %l52 = alloca %"compiler/check:litv"
  %l55 = alloca %"compiler/check:litv"
  %l58 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i1, i128 } @compiler_2fcheck_2etwos(%"compiler/check:litv" %a1)
  store { i1, i128 } %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load { i1, i128 }, ptr %l12
  store { i1, i128 } %t4, ptr %l3
  %t5 = getelementptr { i1, i128 }, ptr %l3, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l4, !tbaa !21
  %t8 = getelementptr { i1, i128 }, ptr %l3, i32 0, i32 1
  %t9 = load i128, ptr %t8
  store i128 %t9, ptr %l5
  %t13 = call { i1, i128 } @compiler_2fcheck_2etwos(%"compiler/check:litv" %a2)
  store { i1, i128 } %t13, ptr %l16
  br label %bb2
bb2:
  %t14 = load { i1, i128 }, ptr %l16
  store { i1, i128 } %t14, ptr %l6
  %t15 = getelementptr { i1, i128 }, ptr %l6, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  %t18 = getelementptr { i1, i128 }, ptr %l6, i32 0, i32 1
  %t19 = load i128, ptr %t18
  store i128 %t19, ptr %l8
  %t21 = load i32, ptr %l0
  %t23 = trunc i64 83 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i1, ptr %l4, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb4:
  %t28 = load i32, ptr %l0
  %t30 = trunc i64 84 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb8, label %bb9
bb5:
  %t33 = load i1, ptr %l7, !tbaa !21
  store i1 %t33, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t35 = load i1, ptr %l23, !tbaa !21
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb14
bb8:
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb9:
  %t38 = load i1, ptr %l4, !tbaa !21
  %t39 = load i1, ptr %l7, !tbaa !21
  %t42 = icmp ne i1 %t38, %t39
  store i1 %t42, ptr %l27, !tbaa !21
  br label %bb13
bb10:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i1, ptr %l7, !tbaa !21
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l21, !tbaa !21
  store i1 %t48, ptr %l9, !tbaa !21
  %t49 = load i32, ptr %l0
  %t51 = trunc i64 83 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t54 = load i128, ptr %l5
  %t55 = load i128, ptr %l8
  %t58 = and i128 %t54, %t55
  store i128 %t58, ptr %l36
  br label %bb20
bb16:
  %t60 = load i32, ptr %l0
  %t62 = trunc i64 84 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = load i128, ptr %l5
  %t66 = load i128, ptr %l8
  %t69 = or i128 %t65, %t66
  store i128 %t69, ptr %l42
  br label %bb19
bb18:
  %t71 = load i128, ptr %l5
  %t72 = load i128, ptr %l8
  %t75 = xor i128 %t71, %t72
  store i128 %t75, ptr %l42
  br label %bb19
bb19:
  %t77 = load i128, ptr %l42
  store i128 %t77, ptr %l36
  br label %bb20
bb20:
  %t78 = load i128, ptr %l36
  store i128 %t78, ptr %l10
  %t79 = load i1, ptr %l9, !tbaa !21
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load i128, ptr %l10
  %t85 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 false, i128 %t83)
  store %"compiler/check:litv" %t85, ptr %l52
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t86 = load %"compiler/check:litv", ptr %l52
  store %"compiler/check:litv" %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i128, ptr %l10
  %t89 = icmp eq i128 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t91, ptr %l55
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t92 = load %"compiler/check:litv", ptr %l55
  store %"compiler/check:litv" %t92, ptr %rv
  br label %ret
bb28:
  %t93 = load i128, ptr %l10
  %t95 = sub i128 0, %t93
  %t97 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 true, i128 %t95)
  store %"compiler/check:litv" %t97, ptr %l58
  br label %bb29
bb29:
  %t98 = load %"compiler/check:litv", ptr %l58
  store %"compiler/check:litv" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 4
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t17, i32 0, i32 2
  %t19 = load i1, ptr %t18
  store i1 %t19, ptr %l1, !tbaa !21
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i1, ptr %l1, !tbaa !21
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_dd9051e7d89be652_5717c5df078d4726)
  unreachable
bb14:
  %t23 = load i1, ptr %l5, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:fixedInit" @compiler_2fcheck_3afixedInit_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/check:fixedInit"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/check:fixedInit" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/check:fixedInit" %t6, i32 %a1, 1
  store %"compiler/check:fixedInit" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:fixedInit", ptr %rv
  ret %"compiler/check:fixedInit" %rr
}

define dso_local %"compiler/check:opShape" @compiler_2fcheck_3aopShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:opShape"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:opShape" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/check:opShape" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:opShape" %t12, i1 %a2, 2
  %t16 = insertvalue %"compiler/check:opShape" %t14, i1 %a3, 3
  store %"compiler/check:opShape" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:opShape", ptr %rv
  ret %"compiler/check:opShape" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fcheck() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fcheck_2eCtReq_2einit()
  br label %bb1
bb1:
  call void @compiler_2fcheck_2eCtEns_2einit()
  br label %bb2
bb2:
  call void @compiler_2fcheck_2eCtEntry_2einit()
  br label %bb3
bb3:
  call void @compiler_2fcheck_2eOpShapes_2einit()
  br label %bb4
bb4:
  call void @compiler_2fcheck_2eMaxUnroll_2einit()
  br label %bb5
bb5:
  call void @compiler_2fcheck_2eRoStored_2einit()
  br label %bb6
bb6:
  call void @compiler_2fcheck_2eRoDecl_2einit()
  br label %bb7
bb7:
  call void @compiler_2fcheck_2eRoReturned_2einit()
  br label %bb8
bb8:
  call void @compiler_2fcheck_2eRoGlobal_2einit()
  br label %bb9
bb9:
  call void @compiler_2fcheck_2eliteralOrder_2einit()
  br label %bb10
bb10:
  call void @compiler_2fcheck_2eRvInt_2einit()
  br label %bb11
bb11:
  call void @compiler_2fcheck_2eRvBool_2einit()
  br label %bb12
bb12:
  call void @compiler_2fcheck_2eRvText_2einit()
  br label %bb13
bb13:
  call void @compiler_2fcheck_2eRvCase_2einit()
  br label %bb14
bb14:
  call void @compiler_2fcheck_2eLaneArr_2einit()
  br label %bb15
bb15:
  call void @compiler_2fcheck_2eLaneScalar_2einit()
  br label %bb16
bb16:
  call void @compiler_2fcheck_2eLaneBin_2einit()
  br label %bb17
bb17:
  call void @compiler_2fcheck_2eLaneUn_2einit()
  br label %bb18
bb18:
  call void @compiler_2fcheck_2eLaneCmp_2einit()
  br label %bb19
bb19:
  call void @compiler_2fcheck_2eLaneSel_2einit()
  br label %bb20
bb20:
  call void @compiler_2fcheck_2eLaneMagic_2einit()
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"deferred code, which runs while its block is left" }>, align 8
@.d3 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"an assert's or an unreachable's message" }>, align 8
@.d4 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a task's clause" }>, align 8
@.d5 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a join block, whose tasks it would leave behind" }>, align 8
@.d6 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"a block with deferred code registered, which would run before the call" }>, align 8
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"try" }>, align 8
@.d10 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"a call given a scope argument (E25), whose result lives where that says" }>, align 8
@.d11 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no call" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"try" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"no call of a function" }>, align 8
@.d15 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"an export fn's call" }>, align 8
@.d16 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a constructor's call" }>, align 8
@.d17 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"a lambda's call" }>, align 8
@.d18 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"an extern fn's call" }>, align 8
@.d19 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"a call through a function value" }>, align 8
@.d20 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a call through an any" }>, align 8
@.d21 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"a call of what the compiler supplies" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_ert_req_clear()
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d24 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" and null" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"u:" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/argument" }>, align 8
@.d28 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ArgumentError" }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d30 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"nothing" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d34 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a local the checker has not bound" }>, align 8
@.d40 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d41 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a name of this kind as a value" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"'x[i]'" }>, align 8
@.d46 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d47 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"no parameters" }>, align 8
@.d48 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"one parameter" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d49 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" parameters" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"one" }>, align 8
@.d51 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"none" }>, align 8
@.d52 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"at least " }>, align 8
@.d53 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Here" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d57 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d59 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d61 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d62 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d63 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d64 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d65 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
@.d66 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d70 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d71 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d73 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d74 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d75 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d76 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d77 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eLaneBin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a6ae1e9a693d05c9_888d1f7981f90365 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eonlyFixed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebecomeWhere(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeOutside(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeInside(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e034fcd8e283054e_7f246e4998f63322 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeTry(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeNotCall(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_17e85edd6251e98f_328e7bc733525423 = external constant [0 x i8]
@olang_loc_7d1c92b0dd6ac454_401b3f55cbe19f48 = external constant [0 x i8]
@olang_loc_fcd7713830295b05_161c0b0a0c98f419 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameJump(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeSignature(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaMemoryJump(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBecomeMemory(ptr %v0)
declare %"compiler/check:tailAsk" @compiler_2fcheck_3atailAsk_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3atailAsk_3e_2ePush_3ccompiler_2fcheck_3atailAsk_3e(ptr %v0, ptr %a0, %"compiler/check:tailAsk" %a1)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4, i1 %a5)
@olang_loc_b092c7cdf5a0a7f2_b1af981e10a9543e = external constant [0 x i8]
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftypes_3aListId_3e__H9cb5d99387f926677a92c13412f9a8b2(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_3e_H2474e1fc3c93452d7765e4ed18f29a03(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hf3bb75ba9d3f922b4d327e9d3c1adfb0(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eblockOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5, i32 %a6)
@olang_loc_15dc8e5e4dc9449e_12f0342e5abdcdfa = external constant [0 x i8]
@olang_loc_7e3b8ef59b75af1f_c18e9d0b6f53f27b = external constant [0 x i8]
@olang_loc_9f75bc02dd96bce4_c2844b619abecf00 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCallbackNotExport(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fcheck_3aframe_26_3e_2_Hc8503b2b20cde402cc7bde6f68d96fc0(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_486b3db7a819736b_b4c2afa2fe5bd5af = external constant [0 x i8]
declare %"compiler/typed:Capture" @compiler_2ftyped_3aCapture_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aCapture_26_3e_2ePus_Hdab9bd3c8945274d6e7197d4fb29356b(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScopeVar_3e_2ePush_3ccompiler_2ftyped_3aScopeVar_3e(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3cf4b7359f29899a_630bdcef83a186 = external constant [0 x i8]
@olang_loc_7977da1af626a39b_b4b859805bc3ac67 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNow(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc394d3abb705b3d_774ad654d23301b9 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullKnown(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtUsed(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseNever(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetUnion(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrNeverNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaseForm(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_259a476ccf69be4f_4dd02f382a72243 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtMatchMissing(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
@olang_loc_514ceade83978a4d_1843f44cd2570191 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8bbd92ac148fb220_5a9ba8c1b178084 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehole(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eSetAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eTrunca_Hdac151ce4e73ec212dc55b02b0b7e7d0(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5)
@olang_loc_854899d5724a103b_e7dfb19072d83fa7 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_852b58c2eb82b3cc_e47a0c64d3951188 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTry(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollOnce(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollElem(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d826e759488f41a6_3ea05b0e10c73972 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthKey(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_He27db0a1785588531472bfd2db42574f(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForUnknown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H09835701baa5b197f16fe6901ed0f7b4(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/check:UnrollAsk" @compiler_2fcheck_3aUnrollAsk_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i32 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aUnrollAsk_3e_2ePush_He90a5e781e5223c39ec692b3f1e8f929(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:UnrollAsk" %a1)
@G_2ecompiler_2fcheck_2eMaxUnroll = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\10\00\00\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeForTooMany(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunrollConsts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestTarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclAttrs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etopAssert(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
@olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorDeclRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
@olang_loc_575e4285282f1c6b_a969c68061cd7c57 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
@olang_loc_27e3ab5b7d984c5a_74f0959f23b09f6e = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6)
@olang_loc_4b7cfa1fb5fcb474_4538ddb4be3a0770 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eeffSs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c7b5cbd58e58cb02_20344cc1e983d9b6 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportMethod(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportGeneric(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExportResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternParam(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eExternResult(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2enullValue(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8fffa2dcb89c09a5_7d27f2eeb87e61a1 = external constant [0 x i8]
@olang_loc_cf50a113ac2177e6_e3cc5936e852a452 = external constant [0 x i8]
@olang_loc_baddfb655e016c47_d17e78f9e01d2853 = external constant [0 x i8]
@olang_loc_3e69957d7270204c_dfbf9d9d846a9638 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9109cadfb541186e_2a46ab96c2b41f0a = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_24473ecab934ff5a_e5063e673d38f936 = external constant [0 x i8]
@olang_loc_1dc6773449e59e5b_c7fcef2f52138cd7 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2ePush_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eLen_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/check:laneVals" @compiler_2fcheck_3alaneVals_2ector(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneStore(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, i64 %a5, i64 %a6, ptr %a7)
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLaneLengths(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneUnType(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistItems(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/check:reflList" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflIndexRange(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescriptor(ptr %v0, ptr %a0, %"compiler/check:reflList" %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewrittenRefOrVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_5a62b0635aab9a02_96142af7f6ac351e = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflName(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"compiler/check:fixedInit" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H6f2dcaa3b3ff2363ea7964270c7a6b31(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstField(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eComptimeLocal(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalPlace(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrNarrowed(ptr %v0, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypedHole(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eImportSaid(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownNameMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeNotAValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_d573417cd970c31d_c74d35b0202ac379 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeVarAsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6fdba33c6e4026bf_8c9edfb8735784b = external constant [0 x i8]
@olang_loc_e5967d965d67f828_b4c4cbb3885481d4 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4, i1 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePush_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, %"compiler/check:narrowed" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOwner(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2edirectSet(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2fcheck_2echainSets(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2echainAssignsAll(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchesAssign(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3, i32 %a4)
@olang_loc_8db10e524bac21a2_ad831be9185e1396 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Nearest" @compiler_2fmsgs_3aNearest_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOffer(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCaseMeant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoSuchCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteDeclaredHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_aac959024b9d6f15_55461456e770b1d1 = external constant [0 x i8]
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePlaceMember(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eColumnAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b23b0b3c83be0ad1_2f776aac88ec27cd = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_557e36687125b346_f828420618561f4a = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H970bb490312910b3b744570a26468c6c(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hd27b567062a69be2f699d8e9ab74cf5a(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hca9d4f63e6a0ec4764c25705e3ecdd1f(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotConverted(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyMeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyTable(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnyStored(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5, i1 %a6)
declare %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitRef(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsNotTrait(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitExtendsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberOpen(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Unmet" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMissing(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3, i64 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_21d2c8212e1ec20a_d97fbaae9e5bc606 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgWide(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eVarArgType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7be86efb5ba886a_70e2aca6e0519896 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
@olang_loc_f65b5445e0db363a_c2ab951bd73e6226 = external constant [0 x i8]
@olang_loc_445c35e7b454dfb2_9156676d88e8071e = external constant [0 x i8]
@olang_loc_64562bc7ca55259a_4dcf078b9ca87c6 = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare { i1, i128 } @compiler_2fcheck_2etwos(%"compiler/check:litv" %a0)
declare %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i128 %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2enoLit()
@olang_loc_dd9051e7d89be652_5717c5df078d4726 = external constant [0 x i8]
declare void @compiler_2fcheck_2eCtReq_2einit()
declare void @compiler_2fcheck_2eCtEns_2einit()
declare void @compiler_2fcheck_2eCtEntry_2einit()
declare void @compiler_2fcheck_2eOpShapes_2einit()
declare void @compiler_2fcheck_2eMaxUnroll_2einit()
declare void @compiler_2fcheck_2eRoStored_2einit()
declare void @compiler_2fcheck_2eRoDecl_2einit()
declare void @compiler_2fcheck_2eRoReturned_2einit()
declare void @compiler_2fcheck_2eRoGlobal_2einit()
declare void @compiler_2fcheck_2eliteralOrder_2einit()
declare void @compiler_2fcheck_2eRvInt_2einit()
declare void @compiler_2fcheck_2eRvBool_2einit()
declare void @compiler_2fcheck_2eRvText_2einit()
declare void @compiler_2fcheck_2eRvCase_2einit()
declare void @compiler_2fcheck_2eLaneArr_2einit()
declare void @compiler_2fcheck_2eLaneScalar_2einit()
declare void @compiler_2fcheck_2eLaneUn_2einit()
declare void @compiler_2fcheck_2eLaneCmp_2einit()
declare void @compiler_2fcheck_2eLaneSel_2einit()
declare void @compiler_2fcheck_2eLaneMagic_2einit()

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
