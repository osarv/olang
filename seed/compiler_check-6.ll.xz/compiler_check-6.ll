; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" = type { i32, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:Ask" = type { i64, i64, i32, ptr, i64, { i64, ptr } }
%"compiler/check:AssertAsk" = type { i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, i64, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/typed:ScopeRel" = type { i64, i64, %"compiler/source:Span" }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Outlives" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
define dso_local void @compiler_2fcheck_2eCtEns_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2fcheck_2eCtEns, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t28, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t37 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t33, { i64, ptr } %a1)
  store i1 %t37, ptr %l23
  br label %bb8
bb8:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l3, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca i1
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i1
  %l108 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l126 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l134 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb114
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t20 = load ptr, ptr %l19, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l19, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l20, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb19
bb14:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = load i64, ptr %t38
  %t41 = icmp eq i64 %t39, 3
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l26, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l1, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t49)
  store i1 %t51, ptr %l32
  br label %bb20
bb20:
  %t52 = load i1, ptr %l32, !tbaa !21
  store i1 %t52, ptr %l10, !tbaa !21
  br label %bb114
bb21:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l33, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 5
  store i1 %t60, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Promote", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t71)
  store i1 %t73, ptr %l41
  br label %bb27
bb27:
  %t74 = load i1, ptr %l41, !tbaa !21
  store i1 %t74, ptr %l10, !tbaa !21
  br label %bb114
bb28:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t76 = load ptr, ptr %l42, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t79 = load ptr, ptr %l42, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 6
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t83 = load i1, ptr %l43, !tbaa !21
  br i1 %t83, label %bb31, label %bb32
bb31:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [5 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %t90)
  store i1 %t92, ptr %l49
  br label %bb34
bb34:
  %t93 = load i1, ptr %l49, !tbaa !21
  store i1 %t93, ptr %l10, !tbaa !21
  br label %bb114
bb35:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb36, label %bb37
bb36:
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 7
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb37
bb37:
  %t102 = load i1, ptr %l51, !tbaa !21
  br i1 %t102, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t105, i32 0, i32 2
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb52
bb40:
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Make", ptr %t109, i32 0, i32 2
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t112)
  store i1 %t114, ptr %l58
  br label %bb41
bb41:
  %t115 = load i1, ptr %l58, !tbaa !21
  br i1 %t115, label %bb42, label %bb43
bb42:
  %t116 = load ptr, ptr %l4, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Make", ptr %t116, i32 0, i32 3
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb44, label %bb45
bb43:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb51
bb44:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb50
bb45:
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Make", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_3c4137bcc23e7cab_322d476e7cbf1657)
  unreachable
bb47:
  br label %bb48
bb48:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/typed:Make", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t133)
  store i1 %t135, ptr %l69
  br label %bb49
bb49:
  %t136 = load i1, ptr %l69, !tbaa !21
  store i1 %t136, ptr %l63, !tbaa !21
  br label %bb50
bb50:
  %t137 = load i1, ptr %l63, !tbaa !21
  store i1 %t137, ptr %l59, !tbaa !21
  br label %bb51
bb51:
  %t138 = load i1, ptr %l59, !tbaa !21
  store i1 %t138, ptr %l10, !tbaa !21
  br label %bb114
bb52:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t140 = load ptr, ptr %l70, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb53, label %bb54
bb53:
  %t143 = load ptr, ptr %l70, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 9
  store i1 %t146, ptr %l71, !tbaa !21
  br label %bb54
bb54:
  %t147 = load i1, ptr %l71, !tbaa !21
  br i1 %t147, label %bb55, label %bb56
bb55:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr { i64, [5 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t150, i32 0, i32 4
  %t152 = load { i64, ptr }, ptr %t151
  store { i64, ptr } %t152, ptr %l5, !tbaa !27
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t156 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t154)
  store i1 %t156, ptr %l77
  br label %bb58
bb58:
  %t157 = load i1, ptr %l77, !tbaa !21
  store i1 %t157, ptr %l10, !tbaa !21
  br label %bb114
bb59:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t159 = load ptr, ptr %l78, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb60, label %bb61
bb60:
  %t162 = load ptr, ptr %l78, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 10
  store i1 %t165, ptr %l79, !tbaa !21
  br label %bb61
bb61:
  %t166 = load i1, ptr %l79, !tbaa !21
  br i1 %t166, label %bb62, label %bb63
bb62:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t169, i32 0, i32 2
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l6, !tbaa !29
  br label %bb64
bb63:
  br label %bb74
bb64:
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Slice", ptr %t173, i32 0, i32 0
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t176)
  store i1 %t178, ptr %l86
  br label %bb65
bb65:
  %t179 = load i1, ptr %l86, !tbaa !21
  br i1 %t179, label %bb66, label %bb67
bb66:
  %t180 = load ptr, ptr %l6, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Slice", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t183)
  store i1 %t185, ptr %l90
  br label %bb68
bb67:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb69
bb68:
  %t186 = load i1, ptr %l90, !tbaa !21
  store i1 %t186, ptr %l87, !tbaa !21
  br label %bb69
bb69:
  %t187 = load i1, ptr %l87, !tbaa !21
  br i1 %t187, label %bb70, label %bb71
bb70:
  %t188 = load ptr, ptr %l6, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Slice", ptr %t188, i32 0, i32 2
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t191)
  store i1 %t193, ptr %l94
  br label %bb72
bb71:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb73
bb72:
  %t194 = load i1, ptr %l94, !tbaa !21
  store i1 %t194, ptr %l91, !tbaa !21
  br label %bb73
bb73:
  %t195 = load i1, ptr %l91, !tbaa !21
  store i1 %t195, ptr %l10, !tbaa !21
  br label %bb114
bb74:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t197 = load ptr, ptr %l95, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb75, label %bb76
bb75:
  %t200 = load ptr, ptr %l95, !tbaa !29
  %t201 = load i64, ptr %t200
  %t203 = icmp eq i64 %t201, 11
  store i1 %t203, ptr %l96, !tbaa !21
  br label %bb76
bb76:
  %t204 = load i1, ptr %l96, !tbaa !21
  br i1 %t204, label %bb77, label %bb78
bb77:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l7, !tbaa !29
  br label %bb79
bb78:
  br label %bb95
bb79:
  %t211 = load ptr, ptr %l7, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Cond", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t214)
  store i1 %t216, ptr %l103
  br label %bb80
bb80:
  %t217 = load i1, ptr %l103, !tbaa !21
  br i1 %t217, label %bb81, label %bb82
bb81:
  %t218 = load ptr, ptr %l7, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Cond", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb83, label %bb84
bb82:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb90
bb83:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb89
bb84:
  %t225 = load ptr, ptr %l7, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Cond", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  br i1 %t230, label %bb85, label %bb86
bb85:
  call void @__olang_check_failed(ptr @olang_loc_64e99bada124913c_2f99d6e12db86a38)
  unreachable
bb86:
  br label %bb87
bb87:
  %t232 = load ptr, ptr %l7, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Cond", ptr %t232, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t235)
  store i1 %t237, ptr %l114
  br label %bb88
bb88:
  %t238 = load i1, ptr %l114, !tbaa !21
  store i1 %t238, ptr %l108, !tbaa !21
  br label %bb89
bb89:
  %t239 = load i1, ptr %l108, !tbaa !21
  store i1 %t239, ptr %l104, !tbaa !21
  br label %bb90
bb90:
  %t240 = load i1, ptr %l104, !tbaa !21
  br i1 %t240, label %bb91, label %bb92
bb91:
  %t241 = load ptr, ptr %l7, !tbaa !29
  %t243 = getelementptr %"compiler/typed:Cond", ptr %t241, i32 0, i32 2
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t244)
  store i1 %t246, ptr %l118
  br label %bb93
bb92:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb94
bb93:
  %t247 = load i1, ptr %l118, !tbaa !21
  store i1 %t247, ptr %l115, !tbaa !21
  br label %bb94
bb94:
  %t248 = load i1, ptr %l115, !tbaa !21
  store i1 %t248, ptr %l10, !tbaa !21
  br label %bb114
bb95:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t250 = load ptr, ptr %l119, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb96, label %bb97
bb96:
  %t253 = load ptr, ptr %l119, !tbaa !29
  %t254 = load i64, ptr %t253
  %t256 = icmp eq i64 %t254, 17
  store i1 %t256, ptr %l120, !tbaa !21
  br label %bb97
bb97:
  %t257 = load i1, ptr %l120, !tbaa !21
  br i1 %t257, label %bb98, label %bb99
bb98:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l8, !tbaa !29
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t264 = load ptr, ptr %l8, !tbaa !29
  %t266 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t264)
  store i1 %t266, ptr %l126
  br label %bb101
bb101:
  %t267 = load i1, ptr %l126, !tbaa !21
  store i1 %t267, ptr %l10, !tbaa !21
  br label %bb114
bb102:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t269 = load ptr, ptr %l127, !tbaa !29
  %t270 = icmp ne ptr %t269, null
  br i1 %t270, label %bb103, label %bb104
bb103:
  %t272 = load ptr, ptr %l127, !tbaa !29
  %t273 = load i64, ptr %t272
  %t275 = icmp eq i64 %t273, 15
  store i1 %t275, ptr %l128, !tbaa !21
  br label %bb104
bb104:
  %t276 = load i1, ptr %l128, !tbaa !21
  br i1 %t276, label %bb105, label %bb106
bb105:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t277, i32 0, i32 1
  %t280 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t279, i32 0, i32 2
  %t281 = load ptr, ptr %t280
  store ptr %t281, ptr %l9, !tbaa !29
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t283 = load ptr, ptr %l9, !tbaa !29
  %t285 = call i1 @compiler_2fcheck_2eclosedFn(ptr %v0, ptr %t283)
  store i1 %t285, ptr %l134
  br label %bb108
bb108:
  %t286 = load i1, ptr %l134, !tbaa !21
  store i1 %t286, ptr %l10, !tbaa !21
  br label %bb114
bb109:
  br i1 true, label %bb110, label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb113
bb112:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_f407e4aa2d3806b8_dd2e5682c5fdf6f4)
  unreachable
bb114:
  %t287 = load i1, ptr %l10, !tbaa !21
  store i1 %t287, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i1
  %l49 = alloca i1
  %l58 = alloca i1
  %l59 = alloca ptr
  %l67 = alloca i1
  %l68 = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l2, !tbaa !29
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/ast:If", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb2:
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:If", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t25 = getelementptr %"compiler/ast:Branch", ptr %t22, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp sge i64 %t26, 0
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr %"compiler/ast:If", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb10
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:If", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Branch", ptr %t41, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l18, !tbaa !29
  %t48 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t46, i64 %t45)
  store i1 %t48, ptr %l26
  br label %bb9
bb9:
  %t49 = load i1, ptr %l26, !tbaa !21
  store i1 %t49, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t50 = load i1, ptr %l17, !tbaa !21
  br i1 %t50, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l2, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr %"compiler/ast:If", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = icmp eq ptr %t55, null
  br i1 %t57, label %bb13, label %bb14
bb12:
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1b45850c01c63cc9_5ae567fd22704b05)
  unreachable
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/ast:If", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = getelementptr %"compiler/ast:Branch", ptr %t62, i32 0, i32 2
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t67, i64 %t66)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/ast:If", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/ast:If", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l3, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  store ptr %t81, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = icmp ne ptr %t82, null
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l40, !tbaa !29
  %t86 = load i64, ptr %t85
  %t88 = icmp eq i64 %t86, 5
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t89 = load i1, ptr %l41, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr }, ptr %t92, i32 0, i32 1
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb46
bb25:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/ast:If", ptr %t96, i32 0, i32 0
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = icmp eq ptr %t99, null
  br i1 %t101, label %bb26, label %bb27
bb26:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/ast:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb31
bb28:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/ast:If", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Branch", ptr %t113, i32 0, i32 2
  %t117 = load i64, ptr %t116, !tbaa !24
  %t119 = icmp sge i64 %t117, 0
  store i1 %t119, ptr %l49, !tbaa !21
  br label %bb31
bb31:
  %t121 = load i1, ptr %l49, !tbaa !21
  br i1 %t121, label %bb32, label %bb33
bb32:
  %t122 = load ptr, ptr %l2, !tbaa !29
  store ptr %t122, ptr %l59, !tbaa !29
  %t123 = load ptr, ptr %l4, !tbaa !29
  %t125 = getelementptr %"compiler/ast:If", ptr %t123, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t128 = icmp eq ptr %t126, null
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb35:
  br label %bb36
bb36:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/ast:If", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t136 = getelementptr %"compiler/ast:Branch", ptr %t133, i32 0, i32 2
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load ptr, ptr %l59, !tbaa !29
  %t140 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %t138, i64 %t137)
  store i1 %t140, ptr %l67
  br label %bb37
bb37:
  %t141 = load i1, ptr %l67, !tbaa !21
  store i1 %t141, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t142 = load i1, ptr %l58, !tbaa !21
  br i1 %t142, label %bb39, label %bb40
bb39:
  %t143 = load ptr, ptr %l2, !tbaa !29
  store ptr %t143, ptr %l68, !tbaa !29
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = getelementptr %"compiler/ast:If", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  call void @__olang_check_failed(ptr @olang_loc_fd7ab254095cc62_437ccc419ec0735e)
  unreachable
bb42:
  br label %bb43
bb43:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/ast:If", ptr %t151, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Branch", ptr %t154, i32 0, i32 2
  %t158 = load i64, ptr %t157, !tbaa !24
  %t159 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %t159, i64 %t158)
  br label %bb44
bb44:
  br label %bb45
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l25 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 13
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l10
  br label %bb3
bb3:
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = icmp sgt i64 %t13, 0
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t17, i32 %t18)
  store { i64, ptr } %t21, ptr %l14
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t22 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 6
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t23, i64 -1, i64 %t27, i32 %t28, i32 0)
  store ptr %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 5
  %t36 = load i1, ptr %t35, !tbaa !21
  store i1 %t36, ptr %l2, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 5
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %t41, i32 %t42)
  store { i64, ptr } %t45, ptr %l25
  br label %bb10
bb10:
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i1, ptr %l2, !tbaa !21
  %t53 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 5
  store i1 %t50, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t54)
  br label %bb11
bb11:
  %t56 = load ptr, ptr %lp3
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i1
  %l97 = alloca ptr
  %l103 = alloca i1
  %l107 = alloca i64
  %l116 = alloca i32
  %l120 = alloca ptr
  %l124 = alloca i1
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l150 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l155 = alloca %"compiler/msgs:Msg"
  %l156 = alloca i64
  %l161 = alloca ptr
  %l177 = alloca ptr
  %l179 = alloca i64
  %l180 = alloca i64
  %l182 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca i64
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l221 = alloca i1
  %l233 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load i64, ptr %l16, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l44
  br label %bb12
bb12:
  %t62 = load i1, ptr %l44, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 3
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l52
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb18
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load i64, ptr %l52, !tbaa !24
  %t88 = icmp ne i64 %t86, %t85
  store i1 %t88, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l48, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %t94, i64 %t95)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t101, i64 %t102)
  store i1 %t105, ptr %l64
  br label %bb24
bb24:
  %t106 = load i1, ptr %l64, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l70
  br label %bb27
bb26:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb28
bb27:
  %t117 = load ptr, ptr %l70, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Func", ptr %t117, i32 0, i32 7
  %t120 = load i1, ptr %t119, !tbaa !21
  store i1 %t120, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t122 = load i1, ptr %l66, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 3
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb35
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l80
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb34
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/load:Loader", ptr %t142, i32 0, i32 7
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = load i64, ptr %l80, !tbaa !24
  %t148 = icmp ne i64 %t146, %t145
  store i1 %t148, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t150 = load i1, ptr %l76, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t153 = load i1, ptr %l73, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %t154, i64 %t155)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i64, ptr %l6, !tbaa !24
  %t165 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l92
  br label %bb40
bb40:
  %t166 = load i1, ptr %l92, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb44
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l97
  br label %bb43
bb43:
  %t175 = load ptr, ptr %l97, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Func", ptr %t175, i32 0, i32 6
  %t178 = load i1, ptr %t177, !tbaa !21
  %t180 = xor i1 %t178, true
  store i1 %t180, ptr %l93, !tbaa !21
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  br i1 %t182, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb46:
  br label %bb47
bb47:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 3
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb48, label %bb49
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l6, !tbaa !24
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb51
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 7
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = load i64, ptr %l107, !tbaa !24
  %t208 = icmp ne i64 %t206, %t205
  store i1 %t208, ptr %l103, !tbaa !21
  br label %bb51
bb51:
  %t210 = load i1, ptr %l103, !tbaa !21
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb53:
  br label %bb54
bb54:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l6, !tbaa !24
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l116
  br label %bb55
bb55:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load i64, ptr %l6, !tbaa !24
  %t226 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t222, i64 %t223)
  store ptr %t226, ptr %l120
  br label %bb56
bb56:
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Func", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  br i1 %t232, label %bb57, label %bb58
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t238 = load i64, ptr %l6, !tbaa !24
  %t241 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t237, i64 %t238)
  store ptr %t241, ptr %l128
  br label %bb59
bb58:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb60
bb59:
  %t242 = load ptr, ptr %l128, !tbaa !29
  %t244 = getelementptr %"compiler/ast:Func", ptr %t242, i32 0, i32 3
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t245, i32 0, i32 6
  %t248 = load i1, ptr %t247, !tbaa !21
  store i1 %t248, ptr %l124, !tbaa !21
  br label %bb60
bb60:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l132, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l6, !tbaa !24
  %t259 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t255, i64 %t256)
  store i64 %t259, ptr %l136
  br label %bb63
bb62:
  br label %bb72
bb63:
  %t260 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t261 = load ptr, ptr %l132, !tbaa !29
  %t262 = load i64, ptr %l136, !tbaa !24
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t261, i64 -1, i64 %t262, i32 %t260, i32 0)
  store ptr %t264, ptr %l138
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l139, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l140, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t271 = load i64, ptr %l6, !tbaa !24
  %t274 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t270, i64 %t271)
  store ptr %t274, ptr %l144
  br label %bb65
bb65:
  %t275 = load ptr, ptr %l140, !tbaa !29
  %t276 = load ptr, ptr %l144, !tbaa !29
  %t277 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t275, ptr %t276)
  store %"compiler/source:Span" %t277, ptr %l145
  br label %bb66
bb66:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l146, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t283 = load i64, ptr %l6, !tbaa !24
  %t286 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t282, i64 %t283)
  store ptr %t286, ptr %l150
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l150, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Func", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load ptr, ptr %l146, !tbaa !29
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t291, i32 %t290)
  store { i64, ptr } %t293, ptr %l153
  br label %bb68
bb68:
  %t294 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s7, ptr %s7, { i64, ptr } %t300)
  store %"compiler/msgs:Msg" %t302, ptr %l155
  br label %bb69
bb69:
  %t303 = load ptr, ptr %l139, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l145
  %t305 = load %"compiler/msgs:Msg", ptr %l155
  %t306 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t303, %"compiler/source:Span" %t304, %"compiler/msgs:Msg" %t305)
  store i64 %t306, ptr %l156
  br label %bb70
bb70:
  %t307 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t307)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t313 = load i64, ptr %l6, !tbaa !24
  %t316 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t312, i64 %t313)
  store ptr %t316, ptr %l161
  br label %bb73
bb73:
  %t317 = load ptr, ptr %l161, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb74, label %bb75
bb74:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %t326, i64 %t327)
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %t330, i64 %t331)
  br label %bb77
bb77:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %t334, i64 %t335)
  br label %bb78
bb78:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %t338, i64 %t339)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %t342, i64 %t343)
  br label %bb81
bb81:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l177, !tbaa !29
  %t350 = load i64, ptr %l6, !tbaa !24
  %t352 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t350)
  store i64 %t352, ptr %l179
  br label %bb82
bb82:
  %t353 = load ptr, ptr %l177, !tbaa !29
  %t354 = load i64, ptr %l179, !tbaa !24
  %t355 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t355, ptr %l180
  br label %bb83
bb83:
  %t356 = load i64, ptr %l180, !tbaa !24
  %t357 = icmp sgt i64 %t356, 0
  br i1 %t357, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb85:
  br label %bb86
bb86:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l182, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t364 = load i64, ptr %l6, !tbaa !24
  %t367 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t363, i64 %t364, i32 0)
  store i64 %t367, ptr %l186
  br label %bb87
bb87:
  %t368 = load ptr, ptr %l182, !tbaa !29
  %t369 = load i64, ptr %l186, !tbaa !24
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t368, i64 %t369)
  store i64 %t370, ptr %l187
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb89:
  %t371 = load i64, ptr %l5, !tbaa !24
  %t373 = add i64 %t371, 1
  store i64 %t373, ptr %l5, !tbaa !24
  br label %bb8
bb90:
  store i64 0, ptr %l7, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 0
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/load:Loader", ptr %t381, i32 0, i32 5
  %t385 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l194
  br label %bb91
bb91:
  %t386 = load i64, ptr %l194, !tbaa !24
  store i64 %t386, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t387 = load i64, ptr %l8, !tbaa !24
  %t388 = load i64, ptr %l7, !tbaa !24
  %t391 = icmp sgt i64 %t387, %t388
  br i1 %t391, label %bb92, label %bb93
bb92:
  %t393 = load i64, ptr %l9, !tbaa !24
  %t395 = icmp sgt i64 %t393, 0
  br i1 %t395, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb97
bb94:
  %t397 = load i64, ptr %l8, !tbaa !24
  %t398 = load i64, ptr %l7, !tbaa !24
  %t401 = sub i64 %t397, %t398
  %t402 = load i64, ptr %l9, !tbaa !24
  %t405 = add i64 %t401, %t402
  %t407 = sub i64 %t405, 1
  %t408 = load i64, ptr %l9, !tbaa !24
  %t411 = sdiv i64 %t407, %t408
  store i64 %t411, ptr %l201, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb96
bb96:
  %t413 = load i64, ptr %l201, !tbaa !24
  store i64 %t413, ptr %l198, !tbaa !24
  br label %bb97
bb97:
  %t414 = load i64, ptr %l198, !tbaa !24
  store i64 %t414, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s12
  %t415 = load i64, ptr %l11, !tbaa !24
  %t416 = load i64, ptr %l10, !tbaa !24
  %t419 = icmp slt i64 %t415, %t416
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb100:
  br label %bb101
bb101:
  %t423 = load i64, ptr %l7, !tbaa !24
  %t424 = load i64, ptr %l11, !tbaa !24
  %t425 = load i64, ptr %l9, !tbaa !24
  %t428 = mul i64 %t424, %t425
  %t431 = add i64 %t423, %t428
  store i64 %t431, ptr %l12, !tbaa !24
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/check:Checker", ptr %t433, i32 0, i32 3
  %t436 = load i1, ptr %t435, !tbaa !21
  br i1 %t436, label %bb102, label %bb103
bb102:
  %t438 = load i64, ptr %l12, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 0
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/load:Loader", ptr %t445, i32 0, i32 7
  %t448 = load i64, ptr %t447, !tbaa !24
  %t451 = icmp ne i64 %t438, %t448
  store i1 %t451, ptr %l221, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb104
bb104:
  %t453 = load i1, ptr %l221, !tbaa !21
  br i1 %t453, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb106:
  br label %bb107
bb107:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 0
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/load:Loader", ptr %t460, i32 0, i32 5
  %t463 = load i64, ptr %l12, !tbaa !24
  %t466 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l233
  br label %bb108
bb108:
  %t467 = load ptr, ptr %l233, !tbaa !29
  %t469 = getelementptr %"compiler/load:Module", ptr %t467, i32 0, i32 8
  %t470 = load { i64, ptr }, ptr %t469, !tbaa !27
  store { i64, ptr } %t470, ptr %l13, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t476 = icmp sgt i64 %t474, 0
  br i1 %t476, label %bb109, label %bb110
bb109:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i64, ptr %l12, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v0, ptr %t478, i64 %t479, { i64, ptr } %t480)
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb113:
  %t484 = load i64, ptr %l11, !tbaa !24
  %t486 = add i64 %t484, 1
  store i64 %t486, ptr %l11, !tbaa !24
  br label %bb98
bb114:
  %t488 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t488)
  br label %bb115
bb115:
  %t490 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %t490)
  br label %bb116
bb116:
  %t492 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %t492)
  br label %bb117
bb117:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l17 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %t28)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l4, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i32
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l154 = alloca { i64, ptr }
  %l163 = alloca ptr
  %l164 = alloca i1
  %l177 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l218 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l228 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i1
  %l282 = alloca { i64, ptr }
  %l295 = alloca ptr
  %l296 = alloca i1
  %l309 = alloca { i64, ptr }
  %l326 = alloca { i64, ptr }
  %l339 = alloca ptr
  %l340 = alloca i1
  %l357 = alloca { i64, ptr }
  %l372 = alloca { i64, ptr }
  %l383 = alloca ptr
  %l384 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca i1
  %l399 = alloca ptr
  %l400 = alloca i1
  %l418 = alloca { i64, ptr }
  %l428 = alloca ptr
  %l429 = alloca i1
  %l444 = alloca ptr
  %l445 = alloca i1
  %l458 = alloca { i64, ptr }
  %l461 = alloca ptr
  %l462 = alloca i1
  %l474 = alloca ptr
  %l475 = alloca ptr
  %l477 = alloca i32
  %l480 = alloca ptr
  %l481 = alloca i1
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s53 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t6 = load ptr, ptr %l70, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l70, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l71, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l71, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t20, ptr %t21, ptr %t22)
  br label %bb9
bb9:
  br label %bb255
bb10:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t28 = load ptr, ptr %l80, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l80, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 3
  store i1 %t34, ptr %l81, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l81, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb255
bb17:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t50 = load ptr, ptr %l90, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb18, label %bb19
bb18:
  %t53 = load ptr, ptr %l90, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l91, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l91, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t64, ptr %t65, ptr %t66)
  br label %bb23
bb23:
  br label %bb255
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  store ptr %t71, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t72 = load ptr, ptr %l100, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb25, label %bb26
bb25:
  %t75 = load ptr, ptr %l100, !tbaa !29
  %t76 = load i64, ptr %t75
  %t78 = icmp eq i64 %t76, 5
  store i1 %t78, ptr %l101, !tbaa !21
  br label %bb26
bb26:
  %t79 = load i1, ptr %l101, !tbaa !21
  br i1 %t79, label %bb27, label %bb28
bb27:
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load ptr, ptr %l6, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t86, ptr %t87, ptr %t91)
  br label %bb30
bb30:
  br label %bb255
bb31:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t97 = load ptr, ptr %l111, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb32, label %bb33
bb32:
  %t100 = load ptr, ptr %l111, !tbaa !29
  %t101 = load i64, ptr %t100
  %t103 = icmp eq i64 %t101, 6
  store i1 %t103, ptr %l112, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l112, !tbaa !21
  br i1 %t104, label %bb34, label %bb35
bb34:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb69
bb36:
  %t111 = load ptr, ptr %l7, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l8, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  store ptr %t116, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t117 = load ptr, ptr %l119, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb37, label %bb38
bb37:
  %t120 = load ptr, ptr %l119, !tbaa !29
  %t121 = load i64, ptr %t120
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l120, !tbaa !21
  br label %bb38
bb38:
  %t124 = load i1, ptr %l120, !tbaa !21
  br i1 %t124, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %l8, !tbaa !29
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { i32 }, ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l9, !tbaa !23
  br label %bb41
bb40:
  br label %bb46
bb41:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr %"compiler/check:b5aWalk", ptr %t131, i32 0, i32 6
  %t134 = load i1, ptr %t133, !tbaa !21
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t140 = load i32, ptr %l9, !tbaa !23
  %t142 = sext i32 %t140 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t138, ptr %t139, i64 %t142)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb61
bb46:
  %t146 = load ptr, ptr %l8, !tbaa !29
  store ptr %t146, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t147 = load ptr, ptr %l132, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l132, !tbaa !29
  %t151 = load i64, ptr %t150
  %t153 = icmp eq i64 %t151, 2
  store i1 %t153, ptr %l133, !tbaa !21
  br label %bb48
bb48:
  %t154 = load i1, ptr %l133, !tbaa !21
  br i1 %t154, label %bb49, label %bb50
bb49:
  %t155 = load ptr, ptr %l8, !tbaa !29
  %t157 = getelementptr { i64, [3 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { ptr }, ptr %t157, i32 0, i32 0
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/check:b5aWalk", ptr %t161, i32 0, i32 6
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb52, label %bb53
bb52:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/check:b5aWalk", ptr %t168, i32 0, i32 7
  store i1 true, ptr %t170, !tbaa !21
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t171, ptr %t172, ptr %t173)
  br label %bb55
bb55:
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_94214b31169ec8c4_68c852e51d74cc68)
  unreachable
bb61:
  %t178 = load ptr, ptr %l7, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Call", ptr %t178, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  store i64 %t185, ptr %l13, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s13
  %t187 = load i64, ptr %l12, !tbaa !24
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s13)
  br label %bb68
bb64:
  br label %bb65
bb65:
  %t195 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t195, ptr %l154, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr ptr, ptr %t199, i64 %t196
  %t201 = load ptr, ptr %t200, !tbaa !39
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t203, ptr %t204, ptr %t201)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s13)
  br label %bb67
bb67:
  %t210 = load i64, ptr %l12, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l12, !tbaa !24
  br label %bb62
bb68:
  br label %bb255
bb69:
  %t214 = load ptr, ptr %l2, !tbaa !29
  store ptr %t214, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t215 = load ptr, ptr %l163, !tbaa !29
  %t216 = icmp ne ptr %t215, null
  br i1 %t216, label %bb70, label %bb71
bb70:
  %t218 = load ptr, ptr %l163, !tbaa !29
  %t219 = load i64, ptr %t218
  %t221 = icmp eq i64 %t219, 7
  store i1 %t221, ptr %l164, !tbaa !21
  br label %bb71
bb71:
  %t222 = load i1, ptr %l164, !tbaa !21
  br i1 %t222, label %bb72, label %bb73
bb72:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = getelementptr { i64, [5 x i64] }, ptr %t223, i32 0, i32 1
  %t226 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t225, i32 0, i32 2
  %t227 = load ptr, ptr %t226
  store ptr %t227, ptr %l15, !tbaa !29
  br label %bb74
bb73:
  br label %bb83
bb74:
  %t229 = load ptr, ptr %l15, !tbaa !29
  %t231 = getelementptr %"compiler/typed:Make", ptr %t229, i32 0, i32 2
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  store { i64, ptr } %t232, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t234 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  store i64 %t236, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s17
  %t238 = load i64, ptr %l17, !tbaa !24
  %t239 = load i64, ptr %l18, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s17)
  br label %bb81
bb77:
  br label %bb78
bb78:
  %t246 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t246, ptr %l177, !tbaa !27
  %t247 = load i64, ptr %l17, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr ptr, ptr %t250, i64 %t247
  %t252 = load ptr, ptr %t251, !tbaa !39
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t254, ptr %t255, ptr %t252)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s17)
  br label %bb80
bb80:
  %t261 = load i64, ptr %l17, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l17, !tbaa !24
  br label %bb75
bb81:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  %t267 = load ptr, ptr %l15, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Make", ptr %t267, i32 0, i32 3
  %t270 = load ptr, ptr %t269, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t265, ptr %t266, ptr %t270)
  br label %bb82
bb82:
  br label %bb255
bb83:
  %t274 = load ptr, ptr %l2, !tbaa !29
  store ptr %t274, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t275 = load ptr, ptr %l190, !tbaa !29
  %t276 = icmp ne ptr %t275, null
  br i1 %t276, label %bb84, label %bb85
bb84:
  %t278 = load ptr, ptr %l190, !tbaa !29
  %t279 = load i64, ptr %t278
  %t281 = icmp eq i64 %t279, 8
  store i1 %t281, ptr %l191, !tbaa !21
  br label %bb85
bb85:
  %t282 = load i1, ptr %l191, !tbaa !21
  br i1 %t282, label %bb86, label %bb87
bb86:
  %t283 = load ptr, ptr %l2, !tbaa !29
  %t285 = getelementptr { i64, [5 x i64] }, ptr %t283, i32 0, i32 1
  %t286 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t285, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  store ptr %t287, ptr %l20, !tbaa !29
  br label %bb88
bb87:
  br label %bb91
bb88:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t291 = load ptr, ptr %l20, !tbaa !29
  %t293 = getelementptr %"compiler/typed:Collect", ptr %t291, i32 0, i32 0
  %t294 = load ptr, ptr %t293, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t289, ptr %t290, ptr %t294)
  br label %bb89
bb89:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load ptr, ptr %l20, !tbaa !29
  %t302 = getelementptr %"compiler/typed:Collect", ptr %t300, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t298, ptr %t299, ptr %t303)
  br label %bb90
bb90:
  br label %bb255
bb91:
  %t308 = load ptr, ptr %l2, !tbaa !29
  store ptr %t308, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t309 = load ptr, ptr %l205, !tbaa !29
  %t310 = icmp ne ptr %t309, null
  br i1 %t310, label %bb92, label %bb93
bb92:
  %t312 = load ptr, ptr %l205, !tbaa !29
  %t313 = load i64, ptr %t312
  %t315 = icmp eq i64 %t313, 9
  store i1 %t315, ptr %l206, !tbaa !21
  br label %bb93
bb93:
  %t316 = load i1, ptr %l206, !tbaa !21
  br i1 %t316, label %bb94, label %bb95
bb94:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr { i64, [5 x i64] }, ptr %t317, i32 0, i32 1
  %t320 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t319, i32 0, i32 4
  %t321 = load { i64, ptr }, ptr %t320
  store { i64, ptr } %t321, ptr %l21, !tbaa !27
  br label %bb96
bb95:
  br label %bb104
bb96:
  %t323 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t323, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t325 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 0
  store i64 %t327, ptr %l24, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s22
  %t329 = load i64, ptr %l23, !tbaa !24
  %t330 = load i64, ptr %l24, !tbaa !24
  %t333 = icmp slt i64 %t329, %t330
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s22)
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t337 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t337, ptr %l218, !tbaa !27
  %t338 = load i64, ptr %l23, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr ptr, ptr %t341, i64 %t338
  %t343 = load ptr, ptr %t342, !tbaa !39
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t345, ptr %t346, ptr %t343)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s22)
  br label %bb102
bb102:
  %t352 = load i64, ptr %l23, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l23, !tbaa !24
  br label %bb97
bb103:
  br label %bb255
bb104:
  %t356 = load ptr, ptr %l2, !tbaa !29
  store ptr %t356, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t357 = load ptr, ptr %l227, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb105, label %bb106
bb105:
  %t360 = load ptr, ptr %l227, !tbaa !29
  %t361 = load i64, ptr %t360
  %t363 = icmp eq i64 %t361, 10
  store i1 %t363, ptr %l228, !tbaa !21
  br label %bb106
bb106:
  %t364 = load i1, ptr %l228, !tbaa !21
  br i1 %t364, label %bb107, label %bb108
bb107:
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t367, i32 0, i32 2
  %t369 = load ptr, ptr %t368
  store ptr %t369, ptr %l26, !tbaa !29
  br label %bb109
bb108:
  br label %bb113
bb109:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t373 = load ptr, ptr %l26, !tbaa !29
  %t375 = getelementptr %"compiler/typed:Slice", ptr %t373, i32 0, i32 0
  %t376 = load ptr, ptr %t375, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t371, ptr %t372, ptr %t376)
  br label %bb110
bb110:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t383 = load ptr, ptr %l26, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Slice", ptr %t383, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t381, ptr %t382, ptr %t386)
  br label %bb111
bb111:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l1, !tbaa !29
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Slice", ptr %t393, i32 0, i32 2
  %t396 = load ptr, ptr %t395, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t391, ptr %t392, ptr %t396)
  br label %bb112
bb112:
  br label %bb255
bb113:
  %t401 = load ptr, ptr %l2, !tbaa !29
  store ptr %t401, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t402 = load ptr, ptr %l248, !tbaa !29
  %t403 = icmp ne ptr %t402, null
  br i1 %t403, label %bb114, label %bb115
bb114:
  %t405 = load ptr, ptr %l248, !tbaa !29
  %t406 = load i64, ptr %t405
  %t408 = icmp eq i64 %t406, 11
  store i1 %t408, ptr %l249, !tbaa !21
  br label %bb115
bb115:
  %t409 = load i1, ptr %l249, !tbaa !21
  br i1 %t409, label %bb116, label %bb117
bb116:
  %t410 = load ptr, ptr %l2, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t412, i32 0, i32 2
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l27, !tbaa !29
  br label %bb118
bb117:
  br label %bb122
bb118:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t418 = load ptr, ptr %l27, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Cond", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t416, ptr %t417, ptr %t421)
  br label %bb119
bb119:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l1, !tbaa !29
  %t428 = load ptr, ptr %l27, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Cond", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t426, ptr %t427, ptr %t431)
  br label %bb120
bb120:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t437 = load ptr, ptr %l27, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Cond", ptr %t437, i32 0, i32 2
  %t440 = load ptr, ptr %t439, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t435, ptr %t436, ptr %t440)
  br label %bb121
bb121:
  br label %bb255
bb122:
  %t445 = load ptr, ptr %l2, !tbaa !29
  store ptr %t445, ptr %l268, !tbaa !29
  store i1 false, ptr %l269, !tbaa !21
  %t446 = load ptr, ptr %l268, !tbaa !29
  %t447 = icmp ne ptr %t446, null
  br i1 %t447, label %bb123, label %bb124
bb123:
  %t449 = load ptr, ptr %l268, !tbaa !29
  %t450 = load i64, ptr %t449
  %t452 = icmp eq i64 %t450, 12
  store i1 %t452, ptr %l269, !tbaa !21
  br label %bb124
bb124:
  %t453 = load i1, ptr %l269, !tbaa !21
  br i1 %t453, label %bb125, label %bb126
bb125:
  %t454 = load ptr, ptr %l2, !tbaa !29
  %t456 = getelementptr { i64, [5 x i64] }, ptr %t454, i32 0, i32 1
  %t457 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t456, i32 0, i32 2
  %t458 = load ptr, ptr %t457
  store ptr %t458, ptr %l28, !tbaa !29
  br label %bb127
bb126:
  br label %bb136
bb127:
  %t460 = load ptr, ptr %l28, !tbaa !29
  %t462 = getelementptr %"compiler/typed:Seq", ptr %t460, i32 0, i32 0
  %t463 = load { i64, ptr }, ptr %t462, !tbaa !27
  store { i64, ptr } %t463, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t465 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t465, 0
  store i64 %t467, ptr %l31, !tbaa !24
  br label %bb128
bb128:
  store %olang.scope zeroinitializer, ptr %s28
  %t469 = load i64, ptr %l30, !tbaa !24
  %t470 = load i64, ptr %l31, !tbaa !24
  %t473 = icmp slt i64 %t469, %t470
  %t475 = xor i1 %t473, true
  br i1 %t475, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s28)
  br label %bb134
bb130:
  br label %bb131
bb131:
  %t477 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t477, ptr %l282, !tbaa !27
  %t478 = load i64, ptr %l30, !tbaa !24
  %t480 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr ptr, ptr %t481, i64 %t478
  %t483 = load ptr, ptr %t482, !tbaa !39
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t485, ptr %t486, ptr %t483)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s28)
  br label %bb133
bb133:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t494 = add i64 %t492, 1
  store i64 %t494, ptr %l30, !tbaa !24
  br label %bb128
bb134:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t498 = load ptr, ptr %l28, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Seq", ptr %t498, i32 0, i32 1
  %t501 = load ptr, ptr %t500, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t496, ptr %t497, ptr %t501)
  br label %bb135
bb135:
  br label %bb255
bb136:
  %t505 = load ptr, ptr %l2, !tbaa !29
  store ptr %t505, ptr %l295, !tbaa !29
  store i1 false, ptr %l296, !tbaa !21
  %t506 = load ptr, ptr %l295, !tbaa !29
  %t507 = icmp ne ptr %t506, null
  br i1 %t507, label %bb137, label %bb138
bb137:
  %t509 = load ptr, ptr %l295, !tbaa !29
  %t510 = load i64, ptr %t509
  %t512 = icmp eq i64 %t510, 13
  store i1 %t512, ptr %l296, !tbaa !21
  br label %bb138
bb138:
  %t513 = load i1, ptr %l296, !tbaa !21
  br i1 %t513, label %bb139, label %bb140
bb139:
  %t514 = load ptr, ptr %l2, !tbaa !29
  %t516 = getelementptr { i64, [5 x i64] }, ptr %t514, i32 0, i32 1
  %t517 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t516, i32 0, i32 2
  %t518 = load ptr, ptr %t517
  store ptr %t518, ptr %l33, !tbaa !29
  br label %bb141
bb140:
  br label %bb157
bb141:
  %t520 = load ptr, ptr %l33, !tbaa !29
  %t522 = getelementptr %"compiler/typed:Match", ptr %t520, i32 0, i32 0
  %t523 = load { i64, ptr }, ptr %t522, !tbaa !27
  store { i64, ptr } %t523, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t525 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t527 = extractvalue { i64, ptr } %t525, 0
  store i64 %t527, ptr %l36, !tbaa !24
  br label %bb142
bb142:
  store %olang.scope zeroinitializer, ptr %s32
  %t529 = load i64, ptr %l35, !tbaa !24
  %t530 = load i64, ptr %l36, !tbaa !24
  %t533 = icmp slt i64 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s32)
  br label %bb148
bb144:
  br label %bb145
bb145:
  %t537 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t537, ptr %l309, !tbaa !27
  %t538 = load i64, ptr %l35, !tbaa !24
  %t540 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t541 = load ptr, ptr %t540, !tbaa !27
  %t542 = getelementptr ptr, ptr %t541, i64 %t538
  %t543 = load ptr, ptr %t542, !tbaa !39
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t545, ptr %t546, ptr %t543)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s32)
  br label %bb147
bb147:
  %t552 = load i64, ptr %l35, !tbaa !24
  %t554 = add i64 %t552, 1
  store i64 %t554, ptr %l35, !tbaa !24
  br label %bb142
bb148:
  %t556 = load ptr, ptr %l33, !tbaa !29
  %t558 = getelementptr %"compiler/typed:Match", ptr %t556, i32 0, i32 1
  %t559 = load { i64, ptr }, ptr %t558, !tbaa !27
  store { i64, ptr } %t559, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t561 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t561, 0
  store i64 %t563, ptr %l40, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s35
  %t565 = load i64, ptr %l39, !tbaa !24
  %t566 = load i64, ptr %l40, !tbaa !24
  %t569 = icmp slt i64 %t565, %t566
  %t571 = xor i1 %t569, true
  br i1 %t571, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s35)
  br label %bb155
bb151:
  br label %bb152
bb152:
  %t573 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t573, ptr %l326, !tbaa !27
  %t574 = load i64, ptr %l39, !tbaa !24
  %t576 = getelementptr { i64, ptr }, ptr %l326, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !27
  %t578 = getelementptr ptr, ptr %t577, i64 %t574
  %t579 = load ptr, ptr %t578, !tbaa !39
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t582 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t581, ptr %t582, ptr %t579)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s35)
  br label %bb154
bb154:
  %t588 = load i64, ptr %l39, !tbaa !24
  %t590 = add i64 %t588, 1
  store i64 %t590, ptr %l39, !tbaa !24
  br label %bb149
bb155:
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l1, !tbaa !29
  %t594 = load ptr, ptr %l33, !tbaa !29
  %t596 = getelementptr %"compiler/typed:Match", ptr %t594, i32 0, i32 2
  %t597 = load ptr, ptr %t596, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %t592, ptr %t593, ptr %t597)
  br label %bb156
bb156:
  br label %bb255
bb157:
  %t601 = load ptr, ptr %l2, !tbaa !29
  store ptr %t601, ptr %l339, !tbaa !29
  store i1 false, ptr %l340, !tbaa !21
  %t602 = load ptr, ptr %l339, !tbaa !29
  %t603 = icmp ne ptr %t602, null
  br i1 %t603, label %bb158, label %bb159
bb158:
  %t605 = load ptr, ptr %l339, !tbaa !29
  %t606 = load i64, ptr %t605
  %t608 = icmp eq i64 %t606, 14
  store i1 %t608, ptr %l340, !tbaa !21
  br label %bb159
bb159:
  %t609 = load i1, ptr %l340, !tbaa !21
  br i1 %t609, label %bb160, label %bb161
bb160:
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t612, i32 0, i32 2
  %t614 = load ptr, ptr %t613
  store ptr %t614, ptr %l42, !tbaa !29
  br label %bb162
bb161:
  br label %bb178
bb162:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l1, !tbaa !29
  %t618 = load ptr, ptr %l42, !tbaa !29
  %t620 = getelementptr %"compiler/typed:Try", ptr %t618, i32 0, i32 0
  %t621 = load ptr, ptr %t620, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t616, ptr %t617, ptr %t621)
  br label %bb163
bb163:
  %t625 = load ptr, ptr %l42, !tbaa !29
  %t627 = getelementptr %"compiler/typed:Try", ptr %t625, i32 0, i32 1
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !27
  store { i64, ptr } %t628, ptr %l43, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t630 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t632 = extractvalue { i64, ptr } %t630, 0
  store i64 %t632, ptr %l45, !tbaa !24
  br label %bb164
bb164:
  store %olang.scope zeroinitializer, ptr %s39
  %t634 = load i64, ptr %l44, !tbaa !24
  %t635 = load i64, ptr %l45, !tbaa !24
  %t638 = icmp slt i64 %t634, %t635
  %t640 = xor i1 %t638, true
  br i1 %t640, label %bb165, label %bb166
bb165:
  call void @__olang_scope_close(ptr %s39)
  br label %bb177
bb166:
  br label %bb167
bb167:
  %t642 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t642, ptr %l357, !tbaa !27
  %t643 = load i64, ptr %l44, !tbaa !24
  %t645 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t646 = load ptr, ptr %t645, !tbaa !27
  %t647 = getelementptr ptr, ptr %t646, i64 %t643
  %t648 = load ptr, ptr %t647, !tbaa !39
  store ptr %t648, ptr %l46, !tbaa !29
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load ptr, ptr %l1, !tbaa !29
  %t652 = load ptr, ptr %l46, !tbaa !29
  %t654 = getelementptr %"compiler/typed:Clause", ptr %t652, i32 0, i32 3
  %t655 = load ptr, ptr %t654, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t650, ptr %t651, ptr %t655)
  br label %bb168
bb168:
  %t659 = load ptr, ptr %l46, !tbaa !29
  %t661 = getelementptr %"compiler/typed:Clause", ptr %t659, i32 0, i32 4
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  store { i64, ptr } %t662, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t664 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t666 = extractvalue { i64, ptr } %t664, 0
  store i64 %t666, ptr %l49, !tbaa !24
  br label %bb169
bb169:
  store %olang.scope zeroinitializer, ptr %s41
  %t668 = load i64, ptr %l48, !tbaa !24
  %t669 = load i64, ptr %l49, !tbaa !24
  %t672 = icmp slt i64 %t668, %t669
  %t674 = xor i1 %t672, true
  br i1 %t674, label %bb170, label %bb171
bb170:
  call void @__olang_scope_close(ptr %s41)
  br label %bb175
bb171:
  br label %bb172
bb172:
  %t676 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t676, ptr %l372, !tbaa !27
  %t677 = load i64, ptr %l48, !tbaa !24
  %t679 = getelementptr { i64, ptr }, ptr %l372, i32 0, i32 1
  %t680 = load ptr, ptr %t679, !tbaa !27
  %t681 = getelementptr ptr, ptr %t680, i64 %t677
  %t682 = load ptr, ptr %t681, !tbaa !39
  %t684 = load ptr, ptr %l0, !tbaa !29
  %t685 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t684, ptr %t685, ptr %t682)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s41)
  br label %bb174
bb174:
  %t691 = load i64, ptr %l48, !tbaa !24
  %t693 = add i64 %t691, 1
  store i64 %t693, ptr %l48, !tbaa !24
  br label %bb169
bb175:
  call void @__olang_scope_close(ptr %s39)
  br label %bb176
bb176:
  %t695 = load i64, ptr %l44, !tbaa !24
  %t697 = add i64 %t695, 1
  store i64 %t697, ptr %l44, !tbaa !24
  br label %bb164
bb177:
  br label %bb255
bb178:
  %t699 = load ptr, ptr %l2, !tbaa !29
  store ptr %t699, ptr %l383, !tbaa !29
  store i1 false, ptr %l384, !tbaa !21
  %t700 = load ptr, ptr %l383, !tbaa !29
  %t701 = icmp ne ptr %t700, null
  br i1 %t701, label %bb179, label %bb180
bb179:
  %t703 = load ptr, ptr %l383, !tbaa !29
  %t704 = load i64, ptr %t703
  %t706 = icmp eq i64 %t704, 15
  store i1 %t706, ptr %l384, !tbaa !21
  br label %bb180
bb180:
  %t707 = load i1, ptr %l384, !tbaa !21
  br i1 %t707, label %bb181, label %bb182
bb181:
  %t708 = load ptr, ptr %l2, !tbaa !29
  %t710 = getelementptr { i64, [5 x i64] }, ptr %t708, i32 0, i32 1
  %t711 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t710, i32 0, i32 2
  %t712 = load ptr, ptr %t711
  store ptr %t712, ptr %l51, !tbaa !29
  br label %bb183
bb182:
  br label %bb214
bb183:
  %t714 = load ptr, ptr %l51, !tbaa !29
  store ptr %t714, ptr %l389, !tbaa !29
  store i1 false, ptr %l390, !tbaa !21
  %t715 = load ptr, ptr %l389, !tbaa !29
  %t716 = icmp ne ptr %t715, null
  br i1 %t716, label %bb184, label %bb185
bb184:
  %t718 = load ptr, ptr %l389, !tbaa !29
  %t719 = load i64, ptr %t718
  %t721 = icmp eq i64 %t719, 0
  store i1 %t721, ptr %l390, !tbaa !21
  br label %bb185
bb185:
  %t722 = load i1, ptr %l390, !tbaa !21
  br i1 %t722, label %bb186, label %bb187
bb186:
  %t723 = load ptr, ptr %l51, !tbaa !29
  %t725 = getelementptr { i64, [4 x i64] }, ptr %t723, i32 0, i32 1
  %t726 = getelementptr { i32 }, ptr %t725, i32 0, i32 0
  %t727 = load i32, ptr %t726
  store i32 %t727, ptr %l52, !tbaa !23
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t730 = load ptr, ptr %l1, !tbaa !29
  %t731 = load i32, ptr %l52, !tbaa !23
  %t733 = sext i32 %t731 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t729, ptr %t730, i64 %t733)
  br label %bb189
bb189:
  br label %bb213
bb190:
  %t737 = load ptr, ptr %l51, !tbaa !29
  store ptr %t737, ptr %l399, !tbaa !29
  store i1 false, ptr %l400, !tbaa !21
  %t738 = load ptr, ptr %l399, !tbaa !29
  %t739 = icmp ne ptr %t738, null
  br i1 %t739, label %bb191, label %bb192
bb191:
  %t741 = load ptr, ptr %l399, !tbaa !29
  %t742 = load i64, ptr %t741
  %t744 = icmp eq i64 %t742, 1
  store i1 %t744, ptr %l400, !tbaa !21
  br label %bb192
bb192:
  %t745 = load i1, ptr %l400, !tbaa !21
  br i1 %t745, label %bb193, label %bb194
bb193:
  %t746 = load ptr, ptr %l51, !tbaa !29
  %t748 = getelementptr { i64, [4 x i64] }, ptr %t746, i32 0, i32 1
  %t749 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t748, i32 0, i32 0
  %t750 = load i32, ptr %t749
  store i32 %t750, ptr %l53, !tbaa !23
  %t752 = load ptr, ptr %l51, !tbaa !29
  %t754 = getelementptr { i64, [4 x i64] }, ptr %t752, i32 0, i32 1
  %t755 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t754, i32 0, i32 1
  %t756 = load { i64, ptr }, ptr %t755
  store { i64, ptr } %t756, ptr %l54, !tbaa !27
  br label %bb195
bb194:
  br label %bb204
bb195:
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load ptr, ptr %l1, !tbaa !29
  %t760 = load i32, ptr %l53, !tbaa !23
  %t762 = sext i32 %t760 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t758, ptr %t759, i64 %t762)
  br label %bb196
bb196:
  %t766 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t766, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t768 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t770 = extractvalue { i64, ptr } %t768, 0
  store i64 %t770, ptr %l57, !tbaa !24
  br label %bb197
bb197:
  store %olang.scope zeroinitializer, ptr %s48
  %t772 = load i64, ptr %l56, !tbaa !24
  %t773 = load i64, ptr %l57, !tbaa !24
  %t776 = icmp slt i64 %t772, %t773
  %t778 = xor i1 %t776, true
  br i1 %t778, label %bb198, label %bb199
bb198:
  call void @__olang_scope_close(ptr %s48)
  br label %bb203
bb199:
  br label %bb200
bb200:
  %t780 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t780, ptr %l418, !tbaa !27
  %t781 = load i64, ptr %l56, !tbaa !24
  %t783 = getelementptr { i64, ptr }, ptr %l418, i32 0, i32 1
  %t784 = load ptr, ptr %t783, !tbaa !27
  %t785 = getelementptr ptr, ptr %t784, i64 %t781
  %t786 = load ptr, ptr %t785, !tbaa !39
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = load ptr, ptr %l1, !tbaa !29
  %t792 = getelementptr %"compiler/typed:Capture", ptr %t786, i32 0, i32 1
  %t793 = load ptr, ptr %t792, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t788, ptr %t789, ptr %t793)
  br label %bb201
bb201:
  call void @__olang_scope_close(ptr %s48)
  br label %bb202
bb202:
  %t798 = load i64, ptr %l56, !tbaa !24
  %t800 = add i64 %t798, 1
  store i64 %t800, ptr %l56, !tbaa !24
  br label %bb197
bb203:
  br label %bb213
bb204:
  %t802 = load ptr, ptr %l51, !tbaa !29
  store ptr %t802, ptr %l428, !tbaa !29
  store i1 false, ptr %l429, !tbaa !21
  %t803 = load ptr, ptr %l428, !tbaa !29
  %t804 = icmp ne ptr %t803, null
  br i1 %t804, label %bb205, label %bb206
bb205:
  %t806 = load ptr, ptr %l428, !tbaa !29
  %t807 = load i64, ptr %t806
  %t809 = icmp eq i64 %t807, 2
  store i1 %t809, ptr %l429, !tbaa !21
  br label %bb206
bb206:
  %t810 = load i1, ptr %l429, !tbaa !21
  br i1 %t810, label %bb207, label %bb208
bb207:
  %t811 = load ptr, ptr %l51, !tbaa !29
  %t813 = getelementptr { i64, [4 x i64] }, ptr %t811, i32 0, i32 1
  %t814 = getelementptr { i32, ptr, i32 }, ptr %t813, i32 0, i32 0
  %t815 = load i32, ptr %t814
  store i32 %t815, ptr %l59, !tbaa !23
  %t817 = load ptr, ptr %l51, !tbaa !29
  %t819 = getelementptr { i64, [4 x i64] }, ptr %t817, i32 0, i32 1
  %t820 = getelementptr { i32, ptr, i32 }, ptr %t819, i32 0, i32 1
  %t821 = load ptr, ptr %t820
  store ptr %t821, ptr %l60, !tbaa !29
  br label %bb209
bb208:
  br label %bb212
bb209:
  %t823 = load ptr, ptr %l0, !tbaa !29
  %t824 = load ptr, ptr %l1, !tbaa !29
  %t825 = load i32, ptr %l59, !tbaa !23
  %t827 = sext i32 %t825 to i64
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %t823, ptr %t824, i64 %t827)
  br label %bb210
bb210:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load ptr, ptr %l1, !tbaa !29
  %t833 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t831, ptr %t832, ptr %t833)
  br label %bb211
bb211:
  br label %bb213
bb212:
  call void @__olang_check_failed(ptr @olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39)
  unreachable
bb213:
  br label %bb255
bb214:
  %t838 = load ptr, ptr %l2, !tbaa !29
  store ptr %t838, ptr %l444, !tbaa !29
  store i1 false, ptr %l445, !tbaa !21
  %t839 = load ptr, ptr %l444, !tbaa !29
  %t840 = icmp ne ptr %t839, null
  br i1 %t840, label %bb215, label %bb216
bb215:
  %t842 = load ptr, ptr %l444, !tbaa !29
  %t843 = load i64, ptr %t842
  %t845 = icmp eq i64 %t843, 16
  store i1 %t845, ptr %l445, !tbaa !21
  br label %bb216
bb216:
  %t846 = load i1, ptr %l445, !tbaa !21
  br i1 %t846, label %bb217, label %bb218
bb217:
  %t847 = load ptr, ptr %l2, !tbaa !29
  %t849 = getelementptr { i64, [5 x i64] }, ptr %t847, i32 0, i32 1
  %t850 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t849, i32 0, i32 2
  %t851 = load ptr, ptr %t850
  store ptr %t851, ptr %l61, !tbaa !29
  br label %bb219
bb218:
  br label %bb243
bb219:
  %t853 = load ptr, ptr %l61, !tbaa !29
  %t855 = getelementptr %"compiler/typed:Text", ptr %t853, i32 0, i32 0
  %t856 = load { i64, ptr }, ptr %t855, !tbaa !27
  store { i64, ptr } %t856, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t858 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t858, 0
  store i64 %t860, ptr %l64, !tbaa !24
  br label %bb220
bb220:
  store %olang.scope zeroinitializer, ptr %s53
  %t862 = load i64, ptr %l63, !tbaa !24
  %t863 = load i64, ptr %l64, !tbaa !24
  %t866 = icmp slt i64 %t862, %t863
  %t868 = xor i1 %t866, true
  br i1 %t868, label %bb221, label %bb222
bb221:
  call void @__olang_scope_close(ptr %s53)
  br label %bb242
bb222:
  br label %bb223
bb223:
  %t870 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t870, ptr %l458, !tbaa !27
  %t871 = load i64, ptr %l63, !tbaa !24
  %t873 = getelementptr { i64, ptr }, ptr %l458, i32 0, i32 1
  %t874 = load ptr, ptr %t873, !tbaa !27
  %t875 = getelementptr ptr, ptr %t874, i64 %t871
  %t876 = load ptr, ptr %t875, !tbaa !39
  store ptr %t876, ptr %l65, !tbaa !29
  %t878 = load ptr, ptr %l65, !tbaa !29
  store ptr %t878, ptr %l461, !tbaa !29
  store i1 false, ptr %l462, !tbaa !21
  %t879 = load ptr, ptr %l461, !tbaa !29
  %t880 = icmp ne ptr %t879, null
  br i1 %t880, label %bb224, label %bb225
bb224:
  %t882 = load ptr, ptr %l461, !tbaa !29
  %t883 = load i64, ptr %t882
  %t885 = icmp eq i64 %t883, 1
  store i1 %t885, ptr %l462, !tbaa !21
  br label %bb225
bb225:
  %t886 = load i1, ptr %l462, !tbaa !21
  br i1 %t886, label %bb226, label %bb227
bb226:
  %t887 = load ptr, ptr %l65, !tbaa !29
  %t889 = getelementptr { i64, [2 x i64] }, ptr %t887, i32 0, i32 1
  %t890 = getelementptr { ptr }, ptr %t889, i32 0, i32 0
  %t891 = load ptr, ptr %t890
  store ptr %t891, ptr %l66, !tbaa !29
  br label %bb228
bb227:
  br label %bb235
bb228:
  %t893 = load ptr, ptr %l0, !tbaa !29
  %t894 = load ptr, ptr %l1, !tbaa !29
  %t895 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t893, ptr %t894, ptr %t895)
  br label %bb229
bb229:
  %t900 = load ptr, ptr %l1, !tbaa !29
  %t902 = getelementptr %"compiler/check:b5aWalk", ptr %t900, i32 0, i32 6
  %t903 = load i1, ptr %t902, !tbaa !21
  %t905 = xor i1 %t903, true
  br i1 %t905, label %bb230, label %bb231
bb230:
  %t907 = load ptr, ptr %l0, !tbaa !29
  store ptr %t907, ptr %l474, !tbaa !29
  %t908 = load ptr, ptr %l1, !tbaa !29
  store ptr %t908, ptr %l475, !tbaa !29
  %t909 = load ptr, ptr %l66, !tbaa !29
  %t911 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t909)
  store i32 %t911, ptr %l477
  br label %bb232
bb231:
  br label %bb234
bb232:
  %t912 = load ptr, ptr %l474, !tbaa !29
  %t913 = load ptr, ptr %l475, !tbaa !29
  %t914 = load i32, ptr %l477, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t912, ptr %t913, i32 %t914, i64 0)
  br label %bb233
bb233:
  br label %bb234
bb234:
  br label %bb240
bb235:
  br i1 true, label %bb236, label %bb237
bb236:
  br label %bb238
bb237:
  br label %bb239
bb238:
  br label %bb240
bb239:
  call void @__olang_check_failed(ptr @olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2)
  unreachable
bb240:
  call void @__olang_scope_close(ptr %s53)
  br label %bb241
bb241:
  %t915 = load i64, ptr %l63, !tbaa !24
  %t917 = add i64 %t915, 1
  store i64 %t917, ptr %l63, !tbaa !24
  br label %bb220
bb242:
  br label %bb255
bb243:
  %t919 = load ptr, ptr %l2, !tbaa !29
  store ptr %t919, ptr %l480, !tbaa !29
  store i1 false, ptr %l481, !tbaa !21
  %t920 = load ptr, ptr %l480, !tbaa !29
  %t921 = icmp ne ptr %t920, null
  br i1 %t921, label %bb244, label %bb245
bb244:
  %t923 = load ptr, ptr %l480, !tbaa !29
  %t924 = load i64, ptr %t923
  %t926 = icmp eq i64 %t924, 17
  store i1 %t926, ptr %l481, !tbaa !21
  br label %bb245
bb245:
  %t927 = load i1, ptr %l481, !tbaa !21
  br i1 %t927, label %bb246, label %bb247
bb246:
  %t928 = load ptr, ptr %l2, !tbaa !29
  %t930 = getelementptr { i64, [5 x i64] }, ptr %t928, i32 0, i32 1
  %t931 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t930, i32 0, i32 2
  %t932 = load ptr, ptr %t931
  store ptr %t932, ptr %l67, !tbaa !29
  br label %bb248
bb247:
  br label %bb250
bb248:
  %t934 = load ptr, ptr %l0, !tbaa !29
  %t935 = load ptr, ptr %l1, !tbaa !29
  %t936 = load ptr, ptr %l67, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t934, ptr %t935, ptr %t936)
  br label %bb249
bb249:
  br label %bb255
bb250:
  br i1 true, label %bb251, label %bb252
bb251:
  br label %bb253
bb252:
  br label %bb254
bb253:
  br label %bb255
bb254:
  call void @__olang_check_failed(ptr @olang_loc_8e70546afa6befff_28f677a32934e343)
  unreachable
bb255:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i32, ptr %l10
  %t16 = trunc i64 4 to i32
  %t17 = icmp eq i32 %t14, %t16
  %t19 = xor i1 %t17, true
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l19
  br label %bb9
bb9:
  %t33 = load i32, ptr %l19, !tbaa !23
  store i32 %t33, ptr %l2, !tbaa !23
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t34, i32 %t35)
  store i1 %t38, ptr %l22
  br label %bb10
bb10:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l2, !tbaa !23
  %t44 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l26
  br label %bb13
bb12:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb18
bb13:
  %t45 = load i32, ptr %l26
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb17
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l35
  br label %bb16
bb16:
  %t62 = load i32, ptr %l35, !tbaa !23
  %t63 = icmp ne i32 %t62, 0
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t65 = load i1, ptr %l30, !tbaa !21
  store i1 %t65, ptr %l23, !tbaa !21
  br label %bb18
bb18:
  %t66 = load i1, ptr %l23, !tbaa !21
  store i1 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca %"compiler/check:litv"
  %l12 = alloca %"compiler/check:litv"
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i1
  %l39 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i1
  %l83 = alloca i1
  %l86 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l107 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca i1
  %l126 = alloca ptr
  %l131 = alloca ptr
  %l133 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l140 = alloca i32
  %l141 = alloca ptr
  %l143 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca %"compiler/typed:Cond"
  %l152 = alloca %"compiler/source:Span"
  %l153 = alloca i32
  %l154 = alloca ptr
  %l158 = alloca ptr
  %l161 = alloca %"compiler/typed:Cond"
  %l165 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l169 = alloca %"compiler/source:Span"
  %l171 = alloca { i64, ptr }
  %l173 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/check:litv"
  %l181 = alloca %"compiler/check:litv"
  %l184 = alloca i1
  %l187 = alloca i1
  %l189 = alloca i1
  %l192 = alloca i1
  %l195 = alloca i1
  %l198 = alloca i1
  %l200 = alloca i1
  %l203 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca %"compiler/msgs:Msg"
  %l208 = alloca i64
  %l211 = alloca ptr
  %l214 = alloca i1
  %l218 = alloca i1
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i1
  %l228 = alloca i1
  %l231 = alloca i1
  %l234 = alloca i1
  %l237 = alloca i1
  %l240 = alloca ptr
  %l242 = alloca %"compiler/source:Span"
  %l243 = alloca %"compiler/msgs:Msg"
  %l244 = alloca i64
  %l247 = alloca ptr
  %l250 = alloca i1
  %l253 = alloca i1
  %l256 = alloca i1
  %l258 = alloca i1
  %l260 = alloca i1
  %l263 = alloca i1
  %l273 = alloca %"compiler/check:litv"
  %l276 = alloca ptr
  %l277 = alloca %"compiler/source:Span"
  %l278 = alloca %"compiler/msgs:Msg"
  %l279 = alloca i64
  %l282 = alloca ptr
  %l285 = alloca i1
  %l288 = alloca i1
  %l291 = alloca i1
  %l294 = alloca i1
  %l298 = alloca i1
  %l299 = alloca ptr
  %l304 = alloca ptr
  %l306 = alloca %"compiler/source:Span"
  %l307 = alloca ptr
  %l308 = alloca ptr
  %l311 = alloca i32
  %l312 = alloca i1
  %l313 = alloca i32
  %l314 = alloca ptr
  %l317 = alloca i32
  %l318 = alloca i32
  %l323 = alloca i1
  %l324 = alloca ptr
  %l326 = alloca ptr
  %l328 = alloca i32
  %l331 = alloca ptr
  %l334 = alloca i1
  %l335 = alloca ptr
  %l336 = alloca %"compiler/source:Span"
  %l339 = alloca i32
  %l342 = alloca i32
  %l343 = alloca i1
  %l346 = alloca ptr
  %l347 = alloca ptr
  %l348 = alloca %"compiler/source:Span"
  %l349 = alloca %"compiler/source:Span"
  %l350 = alloca i32
  %l351 = alloca ptr
  %l352 = alloca ptr
  %l354 = alloca %"compiler/source:Span"
  %l356 = alloca %"compiler/source:Span"
  %l357 = alloca ptr
  %l358 = alloca ptr
  %l363 = alloca ptr
  %l365 = alloca %"compiler/source:Span"
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l370 = alloca i32
  %l371 = alloca i1
  %l372 = alloca i32
  %l373 = alloca ptr
  %l376 = alloca i32
  %l377 = alloca i32
  %l382 = alloca i1
  %l383 = alloca ptr
  %l385 = alloca ptr
  %l387 = alloca i32
  %l390 = alloca ptr
  %l393 = alloca i1
  %l394 = alloca ptr
  %l395 = alloca %"compiler/source:Span"
  %l398 = alloca i32
  %l401 = alloca i32
  %l402 = alloca i1
  %l405 = alloca ptr
  %l406 = alloca ptr
  %l407 = alloca %"compiler/source:Span"
  %l408 = alloca %"compiler/source:Span"
  %l409 = alloca i32
  %l410 = alloca ptr
  %l411 = alloca ptr
  %l413 = alloca %"compiler/source:Span"
  %l415 = alloca %"compiler/source:Span"
  %l416 = alloca ptr
  %l418 = alloca i1
  %l421 = alloca i1
  %l423 = alloca ptr
  %l428 = alloca ptr
  %l430 = alloca %"compiler/source:Span"
  %l431 = alloca ptr
  %l435 = alloca i1
  %l436 = alloca i32
  %l439 = alloca i32
  %l443 = alloca i1
  %l444 = alloca ptr
  %l449 = alloca ptr
  %l455 = alloca ptr
  %l458 = alloca i1
  %l461 = alloca ptr
  %l466 = alloca ptr
  %l468 = alloca %"compiler/source:Span"
  %l469 = alloca ptr
  %l477 = alloca ptr
  %l482 = alloca ptr
  %l484 = alloca i1
  %l487 = alloca ptr
  %l488 = alloca ptr
  %l490 = alloca ptr
  %l492 = alloca i32
  %l495 = alloca ptr
  %l497 = alloca %"compiler/source:Span"
  %l498 = alloca ptr
  %l501 = alloca ptr
  %l504 = alloca i32
  %l505 = alloca i32
  %l508 = alloca i1
  %l510 = alloca ptr
  %l513 = alloca i32
  %l515 = alloca i32
  %l519 = alloca i1
  %l520 = alloca ptr
  %l525 = alloca ptr
  %l531 = alloca ptr
  %l539 = alloca ptr
  %l544 = alloca ptr
  %l547 = alloca i1
  %l548 = alloca i1
  %l551 = alloca i1
  %l553 = alloca ptr
  %l558 = alloca ptr
  %l560 = alloca %"compiler/source:Span"
  %l561 = alloca ptr
  %l563 = alloca ptr
  %l564 = alloca ptr
  %l566 = alloca ptr
  %l567 = alloca ptr
  %l570 = alloca i32
  %l571 = alloca i1
  %l572 = alloca i32
  %l573 = alloca ptr
  %l576 = alloca i32
  %l577 = alloca i32
  %l579 = alloca ptr
  %l581 = alloca %"compiler/source:Span"
  %l582 = alloca ptr
  %l586 = alloca i1
  %l587 = alloca i1
  %l590 = alloca i1
  %l592 = alloca ptr
  %l597 = alloca ptr
  %l599 = alloca %"compiler/source:Span"
  %l600 = alloca ptr
  %l602 = alloca ptr
  %l603 = alloca ptr
  %l605 = alloca ptr
  %l606 = alloca ptr
  %l609 = alloca i32
  %l610 = alloca i1
  %l611 = alloca i32
  %l612 = alloca ptr
  %l615 = alloca i32
  %l616 = alloca i32
  %l618 = alloca ptr
  %l620 = alloca %"compiler/source:Span"
  %l621 = alloca ptr
  %l624 = alloca i1
  %l626 = alloca i1
  %l629 = alloca i1
  %l632 = alloca i1
  %l635 = alloca i1
  %l638 = alloca i1
  %l639 = alloca i1
  %l642 = alloca i1
  %l646 = alloca i32
  %l647 = alloca ptr
  %l648 = alloca ptr
  %l649 = alloca %"compiler/check:litv"
  %l653 = alloca i1
  %l654 = alloca i32
  %l657 = alloca ptr
  %l659 = alloca ptr
  %l660 = alloca ptr
  %l661 = alloca %"compiler/check:litv"
  %l665 = alloca i1
  %l666 = alloca i32
  %l669 = alloca ptr
  %l671 = alloca ptr
  %l676 = alloca ptr
  %l678 = alloca %"compiler/source:Span"
  %l679 = alloca ptr
  %l681 = alloca ptr
  %l686 = alloca ptr
  %l688 = alloca %"compiler/source:Span"
  %l689 = alloca ptr
  %l691 = alloca ptr
  %l692 = alloca %"compiler/source:Span"
  %l693 = alloca %"compiler/source:Span"
  %l694 = alloca i32
  %l697 = alloca ptr
  %l700 = alloca ptr
  %l702 = alloca %"compiler/source:Span"
  %l704 = alloca %"compiler/source:Span"
  %l705 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %rv = alloca ptr
  %t240 = alloca { i64, [5 x i64] }, align 8
  %t271 = alloca { i64, [5 x i64] }, align 8
  %t487 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 72 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l2
  %t8 = trunc i64 74 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l29, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l29, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t12, ptr %t13)
  store i64 %t16, ptr %l34
  br label %bb6
bb5:
  br label %bb57
bb6:
  %t17 = load i64, ptr %l34, !tbaa !24
  %t18 = icmp sge i64 %t17, 0
  br i1 %t18, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v2, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l39
  br label %bb9
bb9:
  %t25 = load i64, ptr %l39, !tbaa !24
  %t26 = icmp sge i64 %t25, 0
  store i1 %t26, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l36, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  %t31 = load i32, ptr %l2
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCompare(ptr %v0, ptr %v1, ptr %v2, ptr %t29, %"compiler/source:Span" %t30, i32 %t31, ptr %t32, ptr %t33)
  store ptr %t39, ptr %l46
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load ptr, ptr %l46, !tbaa !29
  store ptr %t40, ptr %rv
  br label %ret
bb14:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v1, ptr %t41)
  store i1 %t43, ptr %l48
  br label %bb15
bb15:
  %t44 = load i1, ptr %l48, !tbaa !21
  br i1 %t44, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb19
bb17:
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t45)
  store i1 %t47, ptr %l51
  br label %bb18
bb18:
  %t48 = load i1, ptr %l51, !tbaa !21
  store i1 %t48, ptr %l49, !tbaa !21
  br label %bb19
bb19:
  %t49 = load i1, ptr %l49, !tbaa !21
  br i1 %t49, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v2, ptr %t50)
  store i1 %t52, ptr %l53
  br label %bb22
bb21:
  br label %bb38
bb22:
  %t53 = load i1, ptr %l53, !tbaa !21
  br i1 %t53, label %bb23, label %bb24
bb23:
  %t54 = load ptr, ptr %l3, !tbaa !29
  store ptr %t54, ptr %l54, !tbaa !29
  br label %bb25
bb24:
  %t56 = load ptr, ptr %l4, !tbaa !29
  store ptr %t56, ptr %l54, !tbaa !29
  br label %bb25
bb25:
  %t58 = load ptr, ptr %l54, !tbaa !29
  store ptr %t58, ptr %l6, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l57, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l58, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t61)
  store %"compiler/source:Span" %t63, ptr %l60
  br label %bb26
bb26:
  %t64 = load ptr, ptr %l4, !tbaa !29
  %t66 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t64)
  store %"compiler/source:Span" %t66, ptr %l62
  br label %bb27
bb27:
  %t67 = load i32, ptr %l2
  %t69 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s3, i32 %t67)
  store { i64, ptr } %t69, ptr %l64
  br label %bb28
bb28:
  %t70 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = load ptr, ptr %l58, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l60
  %t74 = load %"compiler/source:Span", ptr %l62
  %t76 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t72, %"compiler/source:Span" %t73, %"compiler/source:Span" %t74, i64 %t71)
  store %"compiler/source:Span" %t76, ptr %l66
  br label %bb29
bb29:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l67, !tbaa !29
  %t78 = load ptr, ptr %l6, !tbaa !29
  %t79 = load ptr, ptr @__olang_prog_scope
  %t81 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t79, ptr %t78)
  store %"compiler/source:Span" %t81, ptr %l69
  br label %bb30
bb30:
  %t82 = load ptr, ptr %l67, !tbaa !29
  %t83 = load %"compiler/source:Span", ptr %l69
  %t84 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t82, %"compiler/source:Span" %t83)
  store { i64, ptr } %t84, ptr %l70
  br label %bb31
bb31:
  %t85 = load i32, ptr %l2
  %t87 = trunc i64 72 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 7, ptr @.d0 }, ptr %l73, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 11, ptr @.d1 }, ptr %l73, !tbaa !27
  br label %bb34
bb34:
  %t90 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t92 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullCompared(ptr %v0, ptr %s3, ptr %s3, { i64, ptr } %t90, { i64, ptr } %t91)
  store %"compiler/msgs:Msg" %t92, ptr %l74
  br label %bb35
bb35:
  %t93 = load ptr, ptr %l57, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l66
  %t95 = load %"compiler/msgs:Msg", ptr %l74
  %t96 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t93, %"compiler/source:Span" %t94, %"compiler/msgs:Msg" %t95)
  store i64 %t96, ptr %l75
  br label %bb36
bb36:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l1
  %t99 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t97, %"compiler/source:Span" %t98, i32 %t99, i64 0)
  store ptr %t103, ptr %l79
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load ptr, ptr %l79, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
bb38:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l4, !tbaa !29
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t105, ptr %t106)
  store i1 %t109, ptr %l82
  br label %bb39
bb39:
  %t110 = load i1, ptr %l82, !tbaa !21
  br i1 %t110, label %bb40, label %bb41
bb40:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t111, ptr %t112)
  store i1 %t115, ptr %l86
  br label %bb42
bb41:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb43
bb42:
  %t116 = load i1, ptr %l86, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l83, !tbaa !21
  br label %bb43
bb43:
  %t119 = load i1, ptr %l83, !tbaa !21
  br i1 %t119, label %bb44, label %bb45
bb44:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  %t122 = load i32, ptr %l2
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t124 = load ptr, ptr %l4, !tbaa !29
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %t120, %"compiler/source:Span" %t121, i32 %t122, ptr %t123, ptr %t124)
  store ptr %t130, ptr %l93
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t131 = load ptr, ptr %l93, !tbaa !29
  store ptr %t131, ptr %rv
  br label %ret
bb47:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load ptr, ptr %l3, !tbaa !29
  %t136 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %t132, ptr %t133)
  store i1 %t136, ptr %l96
  br label %bb48
bb48:
  %t137 = load i1, ptr %l96, !tbaa !21
  br i1 %t137, label %bb49, label %bb50
bb49:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t142 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v2, ptr %t138, ptr %t139)
  store i1 %t142, ptr %l100
  br label %bb51
bb50:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb52
bb51:
  %t143 = load i1, ptr %l100, !tbaa !21
  %t144 = xor i1 %t143, true
  store i1 %t144, ptr %l97, !tbaa !21
  br label %bb52
bb52:
  %t146 = load i1, ptr %l97, !tbaa !21
  br i1 %t146, label %bb53, label %bb54
bb53:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t149 = load i32, ptr %l2
  %t150 = load ptr, ptr %l4, !tbaa !29
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t157 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v2, ptr %v1, ptr %t147, %"compiler/source:Span" %t148, i32 %t149, ptr %t150, ptr %t151)
  store ptr %t157, ptr %l107
  br label %bb55
bb54:
  br label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load ptr, ptr %l107, !tbaa !29
  store ptr %t158, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t159 = load i32, ptr %l2
  %t161 = trunc i64 44 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb60
bb59:
  %t164 = load i32, ptr %l2
  %t166 = trunc i64 45 to i32
  %t167 = icmp eq i32 %t164, %t166
  store i1 %t167, ptr %l110, !tbaa !21
  br label %bb60
bb60:
  %t169 = load i1, ptr %l110, !tbaa !21
  br i1 %t169, label %bb61, label %bb62
bb61:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l3, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %t170, ptr %t171)
  store ptr %t174, ptr %l115
  br label %bb63
bb62:
  br label %bb78
bb63:
  %t175 = load ptr, ptr %l115, !tbaa !29
  store ptr %t175, ptr %l7, !tbaa !29
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t176)
  store ptr %t178, ptr %l117
  br label %bb64
bb64:
  %t179 = load ptr, ptr %l117, !tbaa !29
  %t181 = getelementptr %"compiler/check:frame", ptr %t179, i32 0, i32 44
  %t183 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %t181)
  store i64 %t183, ptr %l120
  br label %bb65
bb65:
  %t184 = load i64, ptr %l120, !tbaa !24
  store i64 %t184, ptr %l8, !tbaa !24
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l121, !tbaa !29
  %t186 = load ptr, ptr %l3, !tbaa !29
  store ptr %t186, ptr %l122, !tbaa !29
  %t187 = load i32, ptr %l2
  %t189 = trunc i64 44 to i32
  %t190 = icmp eq i32 %t187, %t189
  store i1 %t190, ptr %l124, !tbaa !21
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t191)
  store ptr %t193, ptr %l126
  br label %bb66
bb66:
  %t194 = load ptr, ptr %l126, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 7
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = load ptr, ptr %l121, !tbaa !29
  %t199 = load ptr, ptr %l122, !tbaa !29
  %t200 = load i1, ptr %l124, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %t198, ptr %t199, i1 %t200, i64 %t197)
  br label %bb67
bb67:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l4, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %t202, ptr %t203)
  store ptr %t206, ptr %l131
  br label %bb68
bb68:
  %t207 = load ptr, ptr %l131, !tbaa !29
  store ptr %t207, ptr %l9, !tbaa !29
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t208)
  store ptr %t210, ptr %l133
  br label %bb69
bb69:
  %t211 = load ptr, ptr %l133, !tbaa !29
  %t213 = getelementptr %"compiler/check:frame", ptr %t211, i32 0, i32 44
  %t214 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %t213, i64 %t214)
  br label %bb70
bb70:
  %t217 = load i32, ptr %l2
  %t219 = trunc i64 44 to i32
  %t220 = icmp eq i32 %t217, %t219
  br i1 %t220, label %bb71, label %bb72
bb71:
  %t222 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t222, ptr %l139
  %t223 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t223, ptr %l140, !tbaa !23
  %t224 = load ptr, ptr %l7, !tbaa !29
  store ptr %t224, ptr %l141, !tbaa !29
  %t225 = load ptr, ptr %l9, !tbaa !29
  store ptr %t225, ptr %l143, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t227, %"compiler/source:Span" %t228, i32 %t229, i64 0)
  store ptr %t233, ptr %l147
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t234 = load ptr, ptr %l141, !tbaa !29
  %t235 = load ptr, ptr %l143, !tbaa !29
  %t236 = load ptr, ptr %l147, !tbaa !29
  %t237 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t234, ptr %t235, ptr %t236)
  store %"compiler/typed:Cond" %t237, ptr %l148
  br label %bb74
bb74:
  %t238 = load %"compiler/typed:Cond", ptr %l148
  %t239 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t238, ptr %t239
  store { i64, [5 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t240, i32 0, i32 0
  store i64 11, ptr %t241
  %t242 = load %"compiler/source:Span", ptr %l139
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t242, 0
  %t244 = load i32, ptr %l140, !tbaa !23
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr } %t243, i32 %t244, 1
  %t247 = insertvalue { %"compiler/source:Span", i32, ptr } %t245, ptr %t239, 2
  %t248 = getelementptr { i64, [5 x i64] }, ptr %t240, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t247, ptr %t248
  %t249 = load { i64, [5 x i64] }, ptr %t240
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t249, ptr %t251
  call void @__olang_scope_close(ptr %s0)
  store ptr %t251, ptr %rv
  br label %ret
bb75:
  %t253 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t253, ptr %l152
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t254, ptr %l153, !tbaa !23
  %t255 = load ptr, ptr %l7, !tbaa !29
  store ptr %t255, ptr %l154, !tbaa !29
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l1
  %t258 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t256, %"compiler/source:Span" %t257, i32 %t258, i64 1)
  store ptr %t262, ptr %l158
  br label %bb76
bb76:
  %t263 = load ptr, ptr %l158, !tbaa !29
  %t264 = load ptr, ptr %l9, !tbaa !29
  %t265 = load ptr, ptr %l154, !tbaa !29
  %t268 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t265, ptr %t263, ptr %t264)
  store %"compiler/typed:Cond" %t268, ptr %l161
  br label %bb77
bb77:
  %t269 = load %"compiler/typed:Cond", ptr %l161
  %t270 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t269, ptr %t270
  store { i64, [5 x i64] } zeroinitializer, ptr %t271
  %t272 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 0
  store i64 11, ptr %t272
  %t273 = load %"compiler/source:Span", ptr %l152
  %t274 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t273, 0
  %t275 = load i32, ptr %l153, !tbaa !23
  %t276 = insertvalue { %"compiler/source:Span", i32, ptr } %t274, i32 %t275, 1
  %t278 = insertvalue { %"compiler/source:Span", i32, ptr } %t276, ptr %t270, 2
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t271, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t278, ptr %t279
  %t280 = load { i64, [5 x i64] }, ptr %t271
  %t282 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t280, ptr %t282
  call void @__olang_scope_close(ptr %s0)
  store ptr %t282, ptr %rv
  br label %ret
bb78:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l165, !tbaa !29
  %t285 = load ptr, ptr %l3, !tbaa !29
  %t287 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t285)
  store %"compiler/source:Span" %t287, ptr %l167
  br label %bb79
bb79:
  %t288 = load ptr, ptr %l4, !tbaa !29
  %t290 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t288)
  store %"compiler/source:Span" %t290, ptr %l169
  br label %bb80
bb80:
  %t291 = load i32, ptr %l2
  %t293 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t291)
  store { i64, ptr } %t293, ptr %l171
  br label %bb81
bb81:
  %t294 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = load ptr, ptr %l165, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l167
  %t298 = load %"compiler/source:Span", ptr %l169
  %t300 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t296, %"compiler/source:Span" %t297, %"compiler/source:Span" %t298, i64 %t295)
  store %"compiler/source:Span" %t300, ptr %l173
  br label %bb82
bb82:
  %t301 = load %"compiler/source:Span", ptr %l173
  store %"compiler/source:Span" %t301, ptr %l10
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l3, !tbaa !29
  %t307 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t302, ptr %t303)
  store %"compiler/check:litv" %t307, ptr %l177
  br label %bb83
bb83:
  %t308 = load %"compiler/check:litv", ptr %l177
  store %"compiler/check:litv" %t308, ptr %l11
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l4, !tbaa !29
  %t314 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v2, ptr %t309, ptr %t310)
  store %"compiler/check:litv" %t314, ptr %l181
  br label %bb84
bb84:
  %t315 = load %"compiler/check:litv", ptr %l181
  store %"compiler/check:litv" %t315, ptr %l12
  %t316 = load i32, ptr %l2
  %t318 = trunc i64 51 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l184, !tbaa !21
  br label %bb87
bb86:
  %t321 = load i32, ptr %l2
  %t323 = trunc i64 52 to i32
  %t324 = icmp eq i32 %t321, %t323
  store i1 %t324, ptr %l184, !tbaa !21
  br label %bb87
bb87:
  %t326 = load i1, ptr %l184, !tbaa !21
  br i1 %t326, label %bb88, label %bb89
bb88:
  %t327 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t328 = load i1, ptr %t327, !tbaa !21
  store i1 %t328, ptr %l187, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb90
bb90:
  %t330 = load i1, ptr %l187, !tbaa !21
  br i1 %t330, label %bb91, label %bb92
bb91:
  %t331 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 1
  %t332 = load i1, ptr %t331, !tbaa !21
  %t334 = xor i1 %t332, true
  store i1 %t334, ptr %l189, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb93
bb93:
  %t336 = load i1, ptr %l189, !tbaa !21
  br i1 %t336, label %bb94, label %bb95
bb94:
  %t337 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 2
  %t338 = load i1, ptr %t337, !tbaa !21
  %t340 = xor i1 %t338, true
  store i1 %t340, ptr %l192, !tbaa !21
  br label %bb96
bb95:
  store i1 false, ptr %l192, !tbaa !21
  br label %bb96
bb96:
  %t342 = load i1, ptr %l192, !tbaa !21
  br i1 %t342, label %bb97, label %bb98
bb97:
  %t343 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 3
  %t344 = load i64, ptr %t343, !tbaa !24
  %t346 = icmp eq i64 %t344, 0
  store i1 %t346, ptr %l195, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb99
bb99:
  %t348 = load i1, ptr %l195, !tbaa !21
  br i1 %t348, label %bb100, label %bb101
bb100:
  %t349 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t350 = load i1, ptr %t349, !tbaa !21
  br i1 %t350, label %bb102, label %bb103
bb101:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb105
bb102:
  %t352 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 1
  %t353 = load i1, ptr %t352, !tbaa !21
  store i1 %t353, ptr %l200, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb104
bb104:
  %t355 = load i1, ptr %l200, !tbaa !21
  %t356 = xor i1 %t355, true
  store i1 %t356, ptr %l198, !tbaa !21
  br label %bb105
bb105:
  %t358 = load i1, ptr %l198, !tbaa !21
  br i1 %t358, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s8
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l203, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l4, !tbaa !29
  %t364 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v2, ptr %t360, ptr %t361)
  store %"compiler/source:Span" %t364, ptr %l206
  br label %bb108
bb107:
  br label %bb112
bb108:
  %t365 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %s8)
  store %"compiler/msgs:Msg" %t365, ptr %l207
  br label %bb109
bb109:
  %t366 = load ptr, ptr %l203, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l206
  %t368 = load %"compiler/msgs:Msg", ptr %l207
  %t369 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t366, %"compiler/source:Span" %t367, %"compiler/msgs:Msg" %t368)
  store i64 %t369, ptr %l208
  br label %bb110
bb110:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l1
  %t374 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t370, %"compiler/source:Span" %t371)
  store ptr %t374, ptr %l211
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t375 = load ptr, ptr %l211, !tbaa !29
  store ptr %t375, ptr %rv
  br label %ret
bb112:
  %t376 = load i32, ptr %l2
  %t378 = trunc i64 85 to i32
  %t379 = icmp eq i32 %t376, %t378
  br i1 %t379, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb115
bb114:
  %t381 = load i32, ptr %l2
  %t383 = trunc i64 86 to i32
  %t384 = icmp eq i32 %t381, %t383
  store i1 %t384, ptr %l214, !tbaa !21
  br label %bb115
bb115:
  %t386 = load i1, ptr %l214, !tbaa !21
  store i1 %t386, ptr %l13, !tbaa !21
  %t387 = load i1, ptr %l13, !tbaa !21
  br i1 %t387, label %bb116, label %bb117
bb116:
  %t389 = load i32, ptr %l5, !tbaa !23
  %t390 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t393 = icmp eq i32 %t389, %t390
  store i1 %t393, ptr %l218, !tbaa !21
  br label %bb118
bb117:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb118
bb118:
  %t395 = load i1, ptr %l218, !tbaa !21
  br i1 %t395, label %bb119, label %bb120
bb119:
  %t396 = load ptr, ptr %l3, !tbaa !29
  %t399 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v1, ptr %t396)
  store i1 %t399, ptr %l225
  br label %bb121
bb120:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb122
bb121:
  %t400 = load i1, ptr %l225, !tbaa !21
  store i1 %t400, ptr %l222, !tbaa !21
  br label %bb122
bb122:
  %t401 = load i1, ptr %l222, !tbaa !21
  br i1 %t401, label %bb123, label %bb124
bb123:
  %t402 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t403 = load i1, ptr %t402, !tbaa !21
  store i1 %t403, ptr %l226, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb125
bb125:
  %t405 = load i1, ptr %l226, !tbaa !21
  br i1 %t405, label %bb126, label %bb127
bb126:
  %t406 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 1
  %t407 = load i1, ptr %t406, !tbaa !21
  %t409 = xor i1 %t407, true
  store i1 %t409, ptr %l228, !tbaa !21
  br label %bb128
bb127:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb128
bb128:
  %t411 = load i1, ptr %l228, !tbaa !21
  br i1 %t411, label %bb129, label %bb130
bb129:
  %t412 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 2
  %t413 = load i1, ptr %t412, !tbaa !21
  %t415 = xor i1 %t413, true
  store i1 %t415, ptr %l231, !tbaa !21
  br label %bb131
bb130:
  store i1 false, ptr %l231, !tbaa !21
  br label %bb131
bb131:
  %t417 = load i1, ptr %l231, !tbaa !21
  br i1 %t417, label %bb132, label %bb133
bb132:
  %t418 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 3
  %t419 = load i64, ptr %t418, !tbaa !24
  %t421 = icmp slt i64 %t419, 0
  br i1 %t421, label %bb134, label %bb135
bb133:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb137
bb134:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb136
bb135:
  %t423 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 3
  %t424 = load i64, ptr %t423, !tbaa !24
  %t426 = icmp sge i64 %t424, 64
  store i1 %t426, ptr %l237, !tbaa !21
  br label %bb136
bb136:
  %t428 = load i1, ptr %l237, !tbaa !21
  store i1 %t428, ptr %l234, !tbaa !21
  br label %bb137
bb137:
  %t429 = load i1, ptr %l234, !tbaa !21
  br i1 %t429, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s9
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l240, !tbaa !29
  %t431 = load ptr, ptr %l4, !tbaa !29
  %t433 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t431)
  store %"compiler/source:Span" %t433, ptr %l242
  br label %bb140
bb139:
  br label %bb144
bb140:
  %t434 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %s9)
  store %"compiler/msgs:Msg" %t434, ptr %l243
  br label %bb141
bb141:
  %t435 = load ptr, ptr %l240, !tbaa !29
  %t436 = load %"compiler/source:Span", ptr %l242
  %t437 = load %"compiler/msgs:Msg", ptr %l243
  %t438 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t435, %"compiler/source:Span" %t436, %"compiler/msgs:Msg" %t437)
  store i64 %t438, ptr %l244
  br label %bb142
bb142:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load %"compiler/source:Span", ptr %l1
  %t443 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t439, %"compiler/source:Span" %t440)
  store ptr %t443, ptr %l247
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t444 = load ptr, ptr %l247, !tbaa !29
  store ptr %t444, ptr %rv
  br label %ret
bb144:
  %t445 = load i32, ptr %l2
  %t447 = trunc i64 48 to i32
  %t448 = icmp eq i32 %t445, %t447
  br i1 %t448, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l250, !tbaa !21
  br label %bb147
bb146:
  %t450 = load i32, ptr %l2
  %t452 = trunc i64 49 to i32
  %t453 = icmp eq i32 %t450, %t452
  store i1 %t453, ptr %l250, !tbaa !21
  br label %bb147
bb147:
  %t455 = load i1, ptr %l250, !tbaa !21
  br i1 %t455, label %bb148, label %bb149
bb148:
  store i1 true, ptr %l253, !tbaa !21
  br label %bb150
bb149:
  %t456 = load i32, ptr %l2
  %t458 = trunc i64 50 to i32
  %t459 = icmp eq i32 %t456, %t458
  store i1 %t459, ptr %l253, !tbaa !21
  br label %bb150
bb150:
  %t461 = load i1, ptr %l253, !tbaa !21
  br i1 %t461, label %bb151, label %bb152
bb151:
  %t462 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t463 = load i1, ptr %t462, !tbaa !21
  store i1 %t463, ptr %l256, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l256, !tbaa !21
  br label %bb153
bb153:
  %t465 = load i1, ptr %l256, !tbaa !21
  br i1 %t465, label %bb154, label %bb155
bb154:
  %t466 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t467 = load i1, ptr %t466, !tbaa !21
  store i1 %t467, ptr %l258, !tbaa !21
  br label %bb156
bb155:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb156
bb156:
  %t469 = load i1, ptr %l258, !tbaa !21
  br i1 %t469, label %bb157, label %bb158
bb157:
  %t470 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 1
  %t471 = load i1, ptr %t470, !tbaa !21
  %t473 = xor i1 %t471, true
  store i1 %t473, ptr %l260, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb159
bb159:
  %t475 = load i1, ptr %l260, !tbaa !21
  br i1 %t475, label %bb160, label %bb161
bb160:
  %t476 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 1
  %t477 = load i1, ptr %t476, !tbaa !21
  %t479 = xor i1 %t477, true
  store i1 %t479, ptr %l263, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb162
bb162:
  %t481 = load i1, ptr %l263, !tbaa !21
  br i1 %t481, label %bb163, label %bb164
bb163:
  store %olang.scope zeroinitializer, ptr %s10
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load %"compiler/source:Span", ptr %l1
  %t484 = load i32, ptr %l2
  %t485 = load ptr, ptr %l3, !tbaa !29
  %t486 = load ptr, ptr %l4, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t487
  %t488 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 0
  store i64 5, ptr %t488
  %t490 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t483, 0
  %t492 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t490, i32 %t484, 1
  %t494 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t492, ptr %t485, 2
  %t496 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t494, ptr %t486, 3
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t487, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t496, ptr %t497
  %t498 = load { i64, [5 x i64] }, ptr %t487
  %t500 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 48, i64 8)
  store { i64, [5 x i64] } %t498, ptr %t500
  %t503 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %s10, ptr %t482, ptr %t500)
  store %"compiler/check:litv" %t503, ptr %l273
  br label %bb165
bb164:
  br label %bb172
bb165:
  %t504 = getelementptr %"compiler/check:litv", ptr %l273, i32 0, i32 0
  %t505 = load i1, ptr %t504, !tbaa !21
  %t507 = xor i1 %t505, true
  br i1 %t507, label %bb166, label %bb167
bb166:
  store %olang.scope zeroinitializer, ptr %s11
  %t509 = load ptr, ptr %l0, !tbaa !29
  store ptr %t509, ptr %l276, !tbaa !29
  %t510 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t510, ptr %l277
  %t511 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %s11)
  store %"compiler/msgs:Msg" %t511, ptr %l278
  br label %bb168
bb167:
  br label %bb171
bb168:
  %t512 = load ptr, ptr %l276, !tbaa !29
  %t513 = load %"compiler/source:Span", ptr %l277
  %t514 = load %"compiler/msgs:Msg", ptr %l278
  %t515 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t512, %"compiler/source:Span" %t513, %"compiler/msgs:Msg" %t514)
  store i64 %t515, ptr %l279
  br label %bb169
bb169:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load %"compiler/source:Span", ptr %l1
  %t520 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t516, %"compiler/source:Span" %t517)
  store ptr %t520, ptr %l282
  br label %bb170
bb170:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t521 = load ptr, ptr %l282, !tbaa !29
  store ptr %t521, ptr %rv
  br label %ret
bb171:
  call void @__olang_scope_close(ptr %s10)
  br label %bb172
bb172:
  %t522 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t523 = load i1, ptr %t522, !tbaa !21
  %t525 = xor i1 %t523, true
  br i1 %t525, label %bb173, label %bb174
bb173:
  %t527 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t528 = load i1, ptr %t527, !tbaa !21
  %t530 = xor i1 %t528, true
  store i1 %t530, ptr %l285, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb175
bb175:
  %t532 = load i1, ptr %l285, !tbaa !21
  br i1 %t532, label %bb176, label %bb177
bb176:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load ptr, ptr %l3, !tbaa !29
  %t537 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t533, ptr %t534)
  store i1 %t537, ptr %l291
  br label %bb178
bb177:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb180
bb178:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load ptr, ptr %l4, !tbaa !29
  %t542 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t538, ptr %t539)
  store i1 %t542, ptr %l294
  br label %bb179
bb179:
  %t543 = load i1, ptr %l291, !tbaa !21
  %t544 = load i1, ptr %l294, !tbaa !21
  %t545 = icmp ne i1 %t543, %t544
  store i1 %t545, ptr %l288, !tbaa !21
  br label %bb180
bb180:
  %t547 = load i1, ptr %l288, !tbaa !21
  br i1 %t547, label %bb181, label %bb182
bb181:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load ptr, ptr %l4, !tbaa !29
  %t552 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v2, ptr %t548, ptr %t549)
  store i1 %t552, ptr %l298
  br label %bb183
bb182:
  br label %bb243
bb183:
  %t553 = load i1, ptr %l298, !tbaa !21
  br i1 %t553, label %bb184, label %bb185
bb184:
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l299, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load ptr, ptr %l3, !tbaa !29
  %t558 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t562 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t555, ptr %t556, i32 %t558)
  store ptr %t562, ptr %l304
  br label %bb186
bb185:
  br label %bb214
bb186:
  %t563 = load ptr, ptr %l3, !tbaa !29
  %t565 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t563)
  store %"compiler/source:Span" %t565, ptr %l306
  br label %bb187
bb187:
  %t566 = load ptr, ptr %l299, !tbaa !29
  %t567 = load ptr, ptr %l304, !tbaa !29
  %t568 = load %"compiler/source:Span", ptr %l306
  %t569 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t566, ptr %t567, %"compiler/source:Span" %t568)
  store ptr %t569, ptr %l307
  br label %bb188
bb188:
  %t570 = load ptr, ptr %l307, !tbaa !29
  store ptr %t570, ptr %l14, !tbaa !29
  %t571 = load ptr, ptr %l0, !tbaa !29
  store ptr %t571, ptr %l308, !tbaa !29
  %t572 = load ptr, ptr %l14, !tbaa !29
  %t575 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t572)
  store i32 %t575, ptr %l311
  br label %bb189
bb189:
  %t576 = load ptr, ptr %l308, !tbaa !29
  %t577 = load i32, ptr %l311, !tbaa !23
  %t578 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t576, i32 %t577)
  store i1 %t578, ptr %l312
  br label %bb190
bb190:
  %t579 = load i1, ptr %l312, !tbaa !21
  br i1 %t579, label %bb191, label %bb192
bb191:
  %t580 = load ptr, ptr %l0, !tbaa !29
  store ptr %t580, ptr %l314, !tbaa !29
  %t581 = load ptr, ptr %l14, !tbaa !29
  %t584 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t581)
  store i32 %t584, ptr %l317
  br label %bb193
bb192:
  %t585 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t585, ptr %l313, !tbaa !23
  br label %bb195
bb193:
  %t587 = load ptr, ptr %l314, !tbaa !29
  %t588 = load i32, ptr %l317, !tbaa !23
  %t589 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t587, i32 %t588)
  store i32 %t589, ptr %l318
  br label %bb194
bb194:
  %t590 = load i32, ptr %l318, !tbaa !23
  store i32 %t590, ptr %l313, !tbaa !23
  br label %bb195
bb195:
  %t591 = load i32, ptr %l313, !tbaa !23
  store i32 %t591, ptr %l15, !tbaa !23
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = load ptr, ptr %l4, !tbaa !29
  %t594 = load i32, ptr %l15, !tbaa !23
  %t598 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v2, ptr %t592, ptr %t593, i32 %t594)
  store i1 %t598, ptr %l323
  br label %bb196
bb196:
  %t599 = load i1, ptr %l323, !tbaa !21
  store i1 %t599, ptr %l16, !tbaa !21
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l324, !tbaa !29
  %t601 = load ptr, ptr %l4, !tbaa !29
  store ptr %t601, ptr %l326, !tbaa !29
  %t603 = load i1, ptr %l16, !tbaa !21
  br i1 %t603, label %bb197, label %bb198
bb197:
  %t605 = load i32, ptr %l15, !tbaa !23
  store i32 %t605, ptr %l328, !tbaa !23
  br label %bb199
bb198:
  %t607 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t607, ptr %l328, !tbaa !23
  br label %bb199
bb199:
  %t609 = load ptr, ptr %l324, !tbaa !29
  %t610 = load ptr, ptr %l326, !tbaa !29
  %t611 = load i32, ptr %l328, !tbaa !23
  %t612 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t609, ptr %t610, i32 %t611)
  store ptr %t612, ptr %l331
  br label %bb200
bb200:
  %t613 = load ptr, ptr %l331, !tbaa !29
  store ptr %t613, ptr %l17, !tbaa !29
  %t614 = load i1, ptr %l16, !tbaa !21
  %t616 = xor i1 %t614, true
  br i1 %t616, label %bb201, label %bb202
bb201:
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l335, !tbaa !29
  %t619 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t619, ptr %l336
  %t620 = load ptr, ptr %l14, !tbaa !29
  %t623 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t620)
  store i32 %t623, ptr %l339
  br label %bb203
bb202:
  store i1 false, ptr %l334, !tbaa !21
  br label %bb206
bb203:
  %t624 = load ptr, ptr %l17, !tbaa !29
  %t627 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t624)
  store i32 %t627, ptr %l342
  br label %bb204
bb204:
  %t628 = load ptr, ptr %l335, !tbaa !29
  %t629 = load %"compiler/source:Span", ptr %l336
  %t630 = load i32, ptr %l339, !tbaa !23
  %t631 = load i32, ptr %l342, !tbaa !23
  %t632 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t628, %"compiler/source:Span" %t629, i32 %t630, i32 %t631)
  store i1 %t632, ptr %l343
  br label %bb205
bb205:
  %t633 = load i1, ptr %l343, !tbaa !21
  store i1 %t633, ptr %l334, !tbaa !21
  br label %bb206
bb206:
  %t634 = load i1, ptr %l334, !tbaa !21
  br i1 %t634, label %bb207, label %bb208
bb207:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load %"compiler/source:Span", ptr %l1
  %t639 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t635, %"compiler/source:Span" %t636)
  store ptr %t639, ptr %l346
  br label %bb209
bb208:
  br label %bb210
bb209:
  call void @__olang_scope_close(ptr %s0)
  %t640 = load ptr, ptr %l346, !tbaa !29
  store ptr %t640, ptr %rv
  br label %ret
bb210:
  %t641 = load ptr, ptr %l0, !tbaa !29
  store ptr %t641, ptr %l347, !tbaa !29
  %t642 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t642, ptr %l348
  %t643 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t643, ptr %l349
  %t644 = load i32, ptr %l2
  store i32 %t644, ptr %l350
  %t645 = load ptr, ptr %l14, !tbaa !29
  store ptr %t645, ptr %l351, !tbaa !29
  %t646 = load ptr, ptr %l17, !tbaa !29
  store ptr %t646, ptr %l352, !tbaa !29
  %t647 = load ptr, ptr %l3, !tbaa !29
  %t649 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t647)
  store %"compiler/source:Span" %t649, ptr %l354
  br label %bb211
bb211:
  %t650 = load ptr, ptr %l4, !tbaa !29
  %t652 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t650)
  store %"compiler/source:Span" %t652, ptr %l356
  br label %bb212
bb212:
  %t653 = load ptr, ptr %l347, !tbaa !29
  %t654 = load %"compiler/source:Span", ptr %l348
  %t655 = load %"compiler/source:Span", ptr %l349
  %t656 = load i32, ptr %l350
  %t657 = load ptr, ptr %l351, !tbaa !29
  %t658 = load ptr, ptr %l352, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l354
  %t660 = load %"compiler/source:Span", ptr %l356
  %t661 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t653, %"compiler/source:Span" %t654, %"compiler/source:Span" %t655, i32 %t656, ptr %t657, ptr %t658, %"compiler/source:Span" %t659, %"compiler/source:Span" %t660)
  store ptr %t661, ptr %l357
  br label %bb213
bb213:
  call void @__olang_scope_close(ptr %s0)
  %t662 = load ptr, ptr %l357, !tbaa !29
  store ptr %t662, ptr %rv
  br label %ret
bb214:
  %t663 = load ptr, ptr %l0, !tbaa !29
  store ptr %t663, ptr %l358, !tbaa !29
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load ptr, ptr %l4, !tbaa !29
  %t667 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t671 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t664, ptr %t665, i32 %t667)
  store ptr %t671, ptr %l363
  br label %bb215
bb215:
  %t672 = load ptr, ptr %l4, !tbaa !29
  %t674 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t672)
  store %"compiler/source:Span" %t674, ptr %l365
  br label %bb216
bb216:
  %t675 = load ptr, ptr %l358, !tbaa !29
  %t676 = load ptr, ptr %l363, !tbaa !29
  %t677 = load %"compiler/source:Span", ptr %l365
  %t678 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t675, ptr %t676, %"compiler/source:Span" %t677)
  store ptr %t678, ptr %l366
  br label %bb217
bb217:
  %t679 = load ptr, ptr %l366, !tbaa !29
  store ptr %t679, ptr %l18, !tbaa !29
  %t680 = load ptr, ptr %l0, !tbaa !29
  store ptr %t680, ptr %l367, !tbaa !29
  %t681 = load ptr, ptr %l18, !tbaa !29
  %t684 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t681)
  store i32 %t684, ptr %l370
  br label %bb218
bb218:
  %t685 = load ptr, ptr %l367, !tbaa !29
  %t686 = load i32, ptr %l370, !tbaa !23
  %t687 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t685, i32 %t686)
  store i1 %t687, ptr %l371
  br label %bb219
bb219:
  %t688 = load i1, ptr %l371, !tbaa !21
  br i1 %t688, label %bb220, label %bb221
bb220:
  %t689 = load ptr, ptr %l0, !tbaa !29
  store ptr %t689, ptr %l373, !tbaa !29
  %t690 = load ptr, ptr %l18, !tbaa !29
  %t693 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t690)
  store i32 %t693, ptr %l376
  br label %bb222
bb221:
  %t694 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t694, ptr %l372, !tbaa !23
  br label %bb224
bb222:
  %t696 = load ptr, ptr %l373, !tbaa !29
  %t697 = load i32, ptr %l376, !tbaa !23
  %t698 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t696, i32 %t697)
  store i32 %t698, ptr %l377
  br label %bb223
bb223:
  %t699 = load i32, ptr %l377, !tbaa !23
  store i32 %t699, ptr %l372, !tbaa !23
  br label %bb224
bb224:
  %t700 = load i32, ptr %l372, !tbaa !23
  store i32 %t700, ptr %l19, !tbaa !23
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t702 = load ptr, ptr %l3, !tbaa !29
  %t703 = load i32, ptr %l19, !tbaa !23
  %t707 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t701, ptr %t702, i32 %t703)
  store i1 %t707, ptr %l382
  br label %bb225
bb225:
  %t708 = load i1, ptr %l382, !tbaa !21
  store i1 %t708, ptr %l20, !tbaa !21
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l383, !tbaa !29
  %t710 = load ptr, ptr %l3, !tbaa !29
  store ptr %t710, ptr %l385, !tbaa !29
  %t712 = load i1, ptr %l20, !tbaa !21
  br i1 %t712, label %bb226, label %bb227
bb226:
  %t714 = load i32, ptr %l19, !tbaa !23
  store i32 %t714, ptr %l387, !tbaa !23
  br label %bb228
bb227:
  %t716 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t716, ptr %l387, !tbaa !23
  br label %bb228
bb228:
  %t718 = load ptr, ptr %l383, !tbaa !29
  %t719 = load ptr, ptr %l385, !tbaa !29
  %t720 = load i32, ptr %l387, !tbaa !23
  %t721 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t718, ptr %t719, i32 %t720)
  store ptr %t721, ptr %l390
  br label %bb229
bb229:
  %t722 = load ptr, ptr %l390, !tbaa !29
  store ptr %t722, ptr %l21, !tbaa !29
  %t723 = load i1, ptr %l20, !tbaa !21
  %t725 = xor i1 %t723, true
  br i1 %t725, label %bb230, label %bb231
bb230:
  %t727 = load ptr, ptr %l0, !tbaa !29
  store ptr %t727, ptr %l394, !tbaa !29
  %t728 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t728, ptr %l395
  %t729 = load ptr, ptr %l18, !tbaa !29
  %t732 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t729)
  store i32 %t732, ptr %l398
  br label %bb232
bb231:
  store i1 false, ptr %l393, !tbaa !21
  br label %bb235
bb232:
  %t733 = load ptr, ptr %l21, !tbaa !29
  %t736 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t733)
  store i32 %t736, ptr %l401
  br label %bb233
bb233:
  %t737 = load ptr, ptr %l394, !tbaa !29
  %t738 = load %"compiler/source:Span", ptr %l395
  %t739 = load i32, ptr %l398, !tbaa !23
  %t740 = load i32, ptr %l401, !tbaa !23
  %t741 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t737, %"compiler/source:Span" %t738, i32 %t739, i32 %t740)
  store i1 %t741, ptr %l402
  br label %bb234
bb234:
  %t742 = load i1, ptr %l402, !tbaa !21
  store i1 %t742, ptr %l393, !tbaa !21
  br label %bb235
bb235:
  %t743 = load i1, ptr %l393, !tbaa !21
  br i1 %t743, label %bb236, label %bb237
bb236:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load %"compiler/source:Span", ptr %l1
  %t748 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t744, %"compiler/source:Span" %t745)
  store ptr %t748, ptr %l405
  br label %bb238
bb237:
  br label %bb239
bb238:
  call void @__olang_scope_close(ptr %s0)
  %t749 = load ptr, ptr %l405, !tbaa !29
  store ptr %t749, ptr %rv
  br label %ret
bb239:
  %t750 = load ptr, ptr %l0, !tbaa !29
  store ptr %t750, ptr %l406, !tbaa !29
  %t751 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t751, ptr %l407
  %t752 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t752, ptr %l408
  %t753 = load i32, ptr %l2
  store i32 %t753, ptr %l409
  %t754 = load ptr, ptr %l21, !tbaa !29
  store ptr %t754, ptr %l410, !tbaa !29
  %t755 = load ptr, ptr %l18, !tbaa !29
  store ptr %t755, ptr %l411, !tbaa !29
  %t756 = load ptr, ptr %l3, !tbaa !29
  %t758 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t756)
  store %"compiler/source:Span" %t758, ptr %l413
  br label %bb240
bb240:
  %t759 = load ptr, ptr %l4, !tbaa !29
  %t761 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t759)
  store %"compiler/source:Span" %t761, ptr %l415
  br label %bb241
bb241:
  %t762 = load ptr, ptr %l406, !tbaa !29
  %t763 = load %"compiler/source:Span", ptr %l407
  %t764 = load %"compiler/source:Span", ptr %l408
  %t765 = load i32, ptr %l409
  %t766 = load ptr, ptr %l410, !tbaa !29
  %t767 = load ptr, ptr %l411, !tbaa !29
  %t768 = load %"compiler/source:Span", ptr %l413
  %t769 = load %"compiler/source:Span", ptr %l415
  %t770 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t762, %"compiler/source:Span" %t763, %"compiler/source:Span" %t764, i32 %t765, ptr %t766, ptr %t767, %"compiler/source:Span" %t768, %"compiler/source:Span" %t769)
  store ptr %t770, ptr %l416
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s0)
  %t771 = load ptr, ptr %l416, !tbaa !29
  store ptr %t771, ptr %rv
  br label %ret
bb243:
  store ptr null, ptr %l22, !tbaa !29
  store ptr null, ptr %l23, !tbaa !29
  %t772 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t773 = load i1, ptr %t772, !tbaa !21
  br i1 %t773, label %bb244, label %bb245
bb244:
  %t775 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t776 = load i1, ptr %t775, !tbaa !21
  %t778 = xor i1 %t776, true
  store i1 %t778, ptr %l418, !tbaa !21
  br label %bb246
bb245:
  store i1 false, ptr %l418, !tbaa !21
  br label %bb246
bb246:
  %t780 = load i1, ptr %l418, !tbaa !21
  br i1 %t780, label %bb247, label %bb248
bb247:
  %t781 = load i1, ptr %l13, !tbaa !21
  store i1 %t781, ptr %l421, !tbaa !21
  br label %bb249
bb248:
  store i1 false, ptr %l421, !tbaa !21
  br label %bb249
bb249:
  %t783 = load i1, ptr %l421, !tbaa !21
  br i1 %t783, label %bb250, label %bb251
bb250:
  %t784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t784, ptr %l423, !tbaa !29
  %t785 = load ptr, ptr %l0, !tbaa !29
  %t786 = load ptr, ptr %l4, !tbaa !29
  %t788 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t792 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t785, ptr %t786, i32 %t788)
  store ptr %t792, ptr %l428
  br label %bb252
bb251:
  %t793 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t794 = load i1, ptr %t793, !tbaa !21
  br i1 %t794, label %bb266, label %bb267
bb252:
  %t796 = load ptr, ptr %l4, !tbaa !29
  %t798 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t796)
  store %"compiler/source:Span" %t798, ptr %l430
  br label %bb253
bb253:
  %t799 = load ptr, ptr %l423, !tbaa !29
  %t800 = load ptr, ptr %l428, !tbaa !29
  %t801 = load %"compiler/source:Span", ptr %l430
  %t802 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t799, ptr %t800, %"compiler/source:Span" %t801)
  store ptr %t802, ptr %l431
  br label %bb254
bb254:
  %t803 = load ptr, ptr %l431, !tbaa !29
  store ptr %t803, ptr %l23, !tbaa !29
  %t805 = load ptr, ptr %l0, !tbaa !29
  %t806 = load i32, ptr %l5, !tbaa !23
  %t809 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t805, i32 %t806)
  store i1 %t809, ptr %l435
  br label %bb255
bb255:
  %t810 = load i1, ptr %l435, !tbaa !21
  br i1 %t810, label %bb256, label %bb257
bb256:
  %t811 = load i32, ptr %l5, !tbaa !23
  store i32 %t811, ptr %l436, !tbaa !23
  br label %bb259
bb257:
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t813)
  store i32 %t815, ptr %l439
  br label %bb258
bb258:
  %t816 = load i32, ptr %l439, !tbaa !23
  store i32 %t816, ptr %l436, !tbaa !23
  br label %bb259
bb259:
  %t817 = load i32, ptr %l436, !tbaa !23
  store i32 %t817, ptr %l24, !tbaa !23
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load %"compiler/check:litv", ptr %l11
  %t820 = load i32, ptr %l24, !tbaa !23
  %t824 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t818, %"compiler/check:litv" %t819, i32 %t820)
  store i1 %t824, ptr %l443
  br label %bb260
bb260:
  %t825 = load i1, ptr %l443, !tbaa !21
  br i1 %t825, label %bb261, label %bb262
bb261:
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load ptr, ptr %l3, !tbaa !29
  %t828 = load %"compiler/check:litv", ptr %l11
  %t829 = load i32, ptr %l24, !tbaa !23
  %t834 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t826, ptr %t827, %"compiler/check:litv" %t828, i32 %t829)
  store ptr %t834, ptr %l449
  br label %bb263
bb262:
  %t835 = load ptr, ptr %l0, !tbaa !29
  %t836 = load ptr, ptr %l3, !tbaa !29
  %t837 = load %"compiler/check:litv", ptr %l11
  %t838 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t843 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t835, ptr %t836, %"compiler/check:litv" %t837, i32 %t838)
  store ptr %t843, ptr %l455
  br label %bb264
bb263:
  %t844 = load ptr, ptr %l449, !tbaa !29
  store ptr %t844, ptr %l444, !tbaa !29
  br label %bb265
bb264:
  %t846 = load ptr, ptr %l455, !tbaa !29
  store ptr %t846, ptr %l444, !tbaa !29
  br label %bb265
bb265:
  %t848 = load ptr, ptr %l444, !tbaa !29
  store ptr %t848, ptr %l22, !tbaa !29
  br label %bb396
bb266:
  %t849 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t850 = load i1, ptr %t849, !tbaa !21
  %t852 = xor i1 %t850, true
  store i1 %t852, ptr %l458, !tbaa !21
  br label %bb268
bb267:
  store i1 false, ptr %l458, !tbaa !21
  br label %bb268
bb268:
  %t854 = load i1, ptr %l458, !tbaa !21
  br i1 %t854, label %bb269, label %bb270
bb269:
  %t855 = load ptr, ptr %l0, !tbaa !29
  store ptr %t855, ptr %l461, !tbaa !29
  %t856 = load ptr, ptr %l0, !tbaa !29
  %t857 = load ptr, ptr %l4, !tbaa !29
  %t859 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t863 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t856, ptr %t857, i32 %t859)
  store ptr %t863, ptr %l466
  br label %bb271
bb270:
  %t864 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t865 = load i1, ptr %t864, !tbaa !21
  br i1 %t865, label %bb279, label %bb280
bb271:
  %t867 = load ptr, ptr %l4, !tbaa !29
  %t869 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t867)
  store %"compiler/source:Span" %t869, ptr %l468
  br label %bb272
bb272:
  %t870 = load ptr, ptr %l461, !tbaa !29
  %t871 = load ptr, ptr %l466, !tbaa !29
  %t872 = load %"compiler/source:Span", ptr %l468
  %t873 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t870, ptr %t871, %"compiler/source:Span" %t872)
  store ptr %t873, ptr %l469
  br label %bb273
bb273:
  %t874 = load ptr, ptr %l469, !tbaa !29
  store ptr %t874, ptr %l23, !tbaa !29
  %t876 = load ptr, ptr %l0, !tbaa !29
  %t877 = load ptr, ptr %l3, !tbaa !29
  %t878 = load %"compiler/check:litv", ptr %l11
  %t879 = load ptr, ptr %l23, !tbaa !29
  %t880 = load i32, ptr %l2
  %t881 = load %"compiler/source:Span", ptr %l10
  %t888 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %t876, ptr %t877, %"compiler/check:litv" %t878, ptr %t879, i32 %t880, %"compiler/source:Span" %t881, i1 false)
  store ptr %t888, ptr %l477
  br label %bb274
bb274:
  %t889 = load ptr, ptr %l477, !tbaa !29
  store ptr %t889, ptr %l22, !tbaa !29
  %t890 = load ptr, ptr %l22, !tbaa !29
  %t892 = icmp eq ptr %t890, null
  br i1 %t892, label %bb275, label %bb276
bb275:
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = load %"compiler/source:Span", ptr %l1
  %t898 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t894, %"compiler/source:Span" %t895)
  store ptr %t898, ptr %l482
  br label %bb277
bb276:
  br label %bb278
bb277:
  call void @__olang_scope_close(ptr %s0)
  %t899 = load ptr, ptr %l482, !tbaa !29
  store ptr %t899, ptr %rv
  br label %ret
bb278:
  br label %bb395
bb279:
  %t900 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t901 = load i1, ptr %t900, !tbaa !21
  %t903 = xor i1 %t901, true
  store i1 %t903, ptr %l484, !tbaa !21
  br label %bb281
bb280:
  store i1 false, ptr %l484, !tbaa !21
  br label %bb281
bb281:
  %t905 = load i1, ptr %l484, !tbaa !21
  br i1 %t905, label %bb282, label %bb283
bb282:
  %t906 = load ptr, ptr %l0, !tbaa !29
  store ptr %t906, ptr %l487, !tbaa !29
  %t907 = load ptr, ptr %l0, !tbaa !29
  store ptr %t907, ptr %l488, !tbaa !29
  %t908 = load ptr, ptr %l3, !tbaa !29
  store ptr %t908, ptr %l490, !tbaa !29
  %t910 = load i1, ptr %l13, !tbaa !21
  br i1 %t910, label %bb284, label %bb285
bb283:
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t913 = load ptr, ptr %l4, !tbaa !29
  %t916 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v2, ptr %t912, ptr %t913)
  store i1 %t916, ptr %l547
  br label %bb312
bb284:
  %t917 = load i32, ptr %l5, !tbaa !23
  store i32 %t917, ptr %l492, !tbaa !23
  br label %bb286
bb285:
  %t919 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t919, ptr %l492, !tbaa !23
  br label %bb286
bb286:
  %t921 = load ptr, ptr %l488, !tbaa !29
  %t922 = load ptr, ptr %l490, !tbaa !29
  %t923 = load i32, ptr %l492, !tbaa !23
  %t924 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t921, ptr %t922, i32 %t923)
  store ptr %t924, ptr %l495
  br label %bb287
bb287:
  %t925 = load ptr, ptr %l3, !tbaa !29
  %t927 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t925)
  store %"compiler/source:Span" %t927, ptr %l497
  br label %bb288
bb288:
  %t928 = load ptr, ptr %l487, !tbaa !29
  %t929 = load ptr, ptr %l495, !tbaa !29
  %t930 = load %"compiler/source:Span", ptr %l497
  %t931 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t928, ptr %t929, %"compiler/source:Span" %t930)
  store ptr %t931, ptr %l498
  br label %bb289
bb289:
  %t932 = load ptr, ptr %l498, !tbaa !29
  store ptr %t932, ptr %l22, !tbaa !29
  %t934 = load i1, ptr %l13, !tbaa !21
  br i1 %t934, label %bb290, label %bb291
bb290:
  %t936 = load ptr, ptr %l0, !tbaa !29
  store ptr %t936, ptr %l501, !tbaa !29
  %t937 = load ptr, ptr %l22, !tbaa !29
  %t940 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t937)
  store i32 %t940, ptr %l504
  br label %bb292
bb291:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t942 = load ptr, ptr %l4, !tbaa !29
  %t943 = load %"compiler/check:litv", ptr %l12
  %t944 = load ptr, ptr %l22, !tbaa !29
  %t945 = load i32, ptr %l2
  %t946 = load %"compiler/source:Span", ptr %l10
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v2, ptr %t941, ptr %t942, %"compiler/check:litv" %t943, ptr %t944, i32 %t945, %"compiler/source:Span" %t946, i1 true)
  store ptr %t953, ptr %l539
  br label %bb306
bb292:
  %t954 = load ptr, ptr %l501, !tbaa !29
  %t955 = load i32, ptr %l504, !tbaa !23
  %t956 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t954, i32 %t955)
  store i32 %t956, ptr %l505
  br label %bb293
bb293:
  %t957 = load i32, ptr %l505, !tbaa !23
  store i32 %t957, ptr %l25, !tbaa !23
  %t958 = load ptr, ptr %l0, !tbaa !29
  %t959 = load i32, ptr %l25, !tbaa !23
  %t962 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t958, i32 %t959)
  store i1 %t962, ptr %l508
  br label %bb294
bb294:
  %t963 = load i1, ptr %l508, !tbaa !21
  %t964 = xor i1 %t963, true
  br i1 %t964, label %bb295, label %bb296
bb295:
  %t966 = load ptr, ptr %l0, !tbaa !29
  store ptr %t966, ptr %l510, !tbaa !29
  %t967 = load ptr, ptr %l22, !tbaa !29
  %t970 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t967)
  store i32 %t970, ptr %l513
  br label %bb297
bb296:
  br label %bb299
bb297:
  %t971 = load i32, ptr %l2
  %t972 = load ptr, ptr %l510, !tbaa !29
  %t973 = load i32, ptr %l513, !tbaa !23
  %t975 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t972, i32 %t973, i32 %t971)
  store i32 %t975, ptr %l515
  br label %bb298
bb298:
  %t976 = load i32, ptr %l515, !tbaa !23
  store i32 %t976, ptr %l25, !tbaa !23
  br label %bb299
bb299:
  %t977 = load ptr, ptr %l0, !tbaa !29
  %t978 = load %"compiler/check:litv", ptr %l12
  %t979 = load i32, ptr %l25, !tbaa !23
  %t983 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t977, %"compiler/check:litv" %t978, i32 %t979)
  store i1 %t983, ptr %l519
  br label %bb300
bb300:
  %t984 = load i1, ptr %l519, !tbaa !21
  br i1 %t984, label %bb301, label %bb302
bb301:
  %t985 = load ptr, ptr %l0, !tbaa !29
  %t986 = load ptr, ptr %l4, !tbaa !29
  %t987 = load %"compiler/check:litv", ptr %l12
  %t988 = load i32, ptr %l25, !tbaa !23
  %t993 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %t985, ptr %t986, %"compiler/check:litv" %t987, i32 %t988)
  store ptr %t993, ptr %l525
  br label %bb303
bb302:
  %t994 = load ptr, ptr %l0, !tbaa !29
  %t995 = load ptr, ptr %l4, !tbaa !29
  %t996 = load %"compiler/check:litv", ptr %l12
  %t997 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1002 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %t994, ptr %t995, %"compiler/check:litv" %t996, i32 %t997)
  store ptr %t1002, ptr %l531
  br label %bb304
bb303:
  %t1003 = load ptr, ptr %l525, !tbaa !29
  store ptr %t1003, ptr %l520, !tbaa !29
  br label %bb305
bb304:
  %t1005 = load ptr, ptr %l531, !tbaa !29
  store ptr %t1005, ptr %l520, !tbaa !29
  br label %bb305
bb305:
  %t1007 = load ptr, ptr %l520, !tbaa !29
  store ptr %t1007, ptr %l23, !tbaa !29
  br label %bb311
bb306:
  %t1008 = load ptr, ptr %l539, !tbaa !29
  store ptr %t1008, ptr %l23, !tbaa !29
  %t1009 = load ptr, ptr %l23, !tbaa !29
  %t1011 = icmp eq ptr %t1009, null
  br i1 %t1011, label %bb307, label %bb308
bb307:
  %t1013 = load ptr, ptr %l0, !tbaa !29
  %t1014 = load %"compiler/source:Span", ptr %l1
  %t1017 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1013, %"compiler/source:Span" %t1014)
  store ptr %t1017, ptr %l544
  br label %bb309
bb308:
  br label %bb310
bb309:
  call void @__olang_scope_close(ptr %s0)
  %t1018 = load ptr, ptr %l544, !tbaa !29
  store ptr %t1018, ptr %rv
  br label %ret
bb310:
  br label %bb311
bb311:
  br label %bb394
bb312:
  %t1019 = load i1, ptr %l547, !tbaa !21
  br i1 %t1019, label %bb313, label %bb314
bb313:
  %t1020 = load ptr, ptr %l0, !tbaa !29
  %t1021 = load ptr, ptr %l3, !tbaa !29
  %t1024 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t1020, ptr %t1021)
  store i1 %t1024, ptr %l551
  br label %bb315
bb314:
  store i1 false, ptr %l548, !tbaa !21
  br label %bb316
bb315:
  %t1025 = load i1, ptr %l551, !tbaa !21
  %t1026 = xor i1 %t1025, true
  store i1 %t1026, ptr %l548, !tbaa !21
  br label %bb316
bb316:
  %t1028 = load i1, ptr %l548, !tbaa !21
  br i1 %t1028, label %bb317, label %bb318
bb317:
  %t1029 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1029, ptr %l553, !tbaa !29
  %t1030 = load ptr, ptr %l0, !tbaa !29
  %t1031 = load ptr, ptr %l3, !tbaa !29
  %t1033 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1037 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1030, ptr %t1031, i32 %t1033)
  store ptr %t1037, ptr %l558
  br label %bb319
bb318:
  %t1038 = load ptr, ptr %l0, !tbaa !29
  %t1039 = load ptr, ptr %l3, !tbaa !29
  %t1042 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t1038, ptr %t1039)
  store i1 %t1042, ptr %l586
  br label %bb332
bb319:
  %t1043 = load ptr, ptr %l3, !tbaa !29
  %t1045 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1043)
  store %"compiler/source:Span" %t1045, ptr %l560
  br label %bb320
bb320:
  %t1046 = load ptr, ptr %l553, !tbaa !29
  %t1047 = load ptr, ptr %l558, !tbaa !29
  %t1048 = load %"compiler/source:Span", ptr %l560
  %t1049 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1046, ptr %t1047, %"compiler/source:Span" %t1048)
  store ptr %t1049, ptr %l561
  br label %bb321
bb321:
  %t1050 = load ptr, ptr %l561, !tbaa !29
  store ptr %t1050, ptr %l22, !tbaa !29
  %t1052 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1052, ptr %l563, !tbaa !29
  %t1053 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1053, ptr %l564, !tbaa !29
  %t1054 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1054, ptr %l566, !tbaa !29
  %t1056 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1056, ptr %l567, !tbaa !29
  %t1057 = load ptr, ptr %l22, !tbaa !29
  %t1060 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1057)
  store i32 %t1060, ptr %l570
  br label %bb322
bb322:
  %t1061 = load ptr, ptr %l567, !tbaa !29
  %t1062 = load i32, ptr %l570, !tbaa !23
  %t1063 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1061, i32 %t1062)
  store i1 %t1063, ptr %l571
  br label %bb323
bb323:
  %t1064 = load i1, ptr %l571, !tbaa !21
  br i1 %t1064, label %bb324, label %bb325
bb324:
  %t1065 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1065, ptr %l573, !tbaa !29
  %t1066 = load ptr, ptr %l22, !tbaa !29
  %t1069 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1066)
  store i32 %t1069, ptr %l576
  br label %bb326
bb325:
  %t1070 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1070, ptr %l572, !tbaa !23
  br label %bb328
bb326:
  %t1072 = load ptr, ptr %l573, !tbaa !29
  %t1073 = load i32, ptr %l576, !tbaa !23
  %t1074 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t1072, i32 %t1073)
  store i32 %t1074, ptr %l577
  br label %bb327
bb327:
  %t1075 = load i32, ptr %l577, !tbaa !23
  store i32 %t1075, ptr %l572, !tbaa !23
  br label %bb328
bb328:
  %t1076 = load ptr, ptr %l564, !tbaa !29
  %t1077 = load ptr, ptr %l566, !tbaa !29
  %t1078 = load i32, ptr %l572, !tbaa !23
  %t1079 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t1076, ptr %t1077, i32 %t1078)
  store ptr %t1079, ptr %l579
  br label %bb329
bb329:
  %t1080 = load ptr, ptr %l4, !tbaa !29
  %t1082 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1080)
  store %"compiler/source:Span" %t1082, ptr %l581
  br label %bb330
bb330:
  %t1083 = load ptr, ptr %l563, !tbaa !29
  %t1084 = load ptr, ptr %l579, !tbaa !29
  %t1085 = load %"compiler/source:Span", ptr %l581
  %t1086 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1083, ptr %t1084, %"compiler/source:Span" %t1085)
  store ptr %t1086, ptr %l582
  br label %bb331
bb331:
  %t1087 = load ptr, ptr %l582, !tbaa !29
  store ptr %t1087, ptr %l23, !tbaa !29
  br label %bb393
bb332:
  %t1089 = load i1, ptr %l586, !tbaa !21
  br i1 %t1089, label %bb333, label %bb334
bb333:
  %t1090 = load ptr, ptr %l0, !tbaa !29
  %t1091 = load ptr, ptr %l4, !tbaa !29
  %t1094 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v2, ptr %t1090, ptr %t1091)
  store i1 %t1094, ptr %l590
  br label %bb335
bb334:
  store i1 false, ptr %l587, !tbaa !21
  br label %bb336
bb335:
  %t1095 = load i1, ptr %l590, !tbaa !21
  %t1096 = xor i1 %t1095, true
  store i1 %t1096, ptr %l587, !tbaa !21
  br label %bb336
bb336:
  %t1098 = load i1, ptr %l587, !tbaa !21
  br i1 %t1098, label %bb337, label %bb338
bb337:
  %t1099 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1099, ptr %l592, !tbaa !29
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1101 = load ptr, ptr %l4, !tbaa !29
  %t1103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t1100, ptr %t1101, i32 %t1103)
  store ptr %t1107, ptr %l597
  br label %bb339
bb338:
  %t1108 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 0
  %t1109 = load i1, ptr %t1108, !tbaa !21
  br i1 %t1109, label %bb352, label %bb353
bb339:
  %t1111 = load ptr, ptr %l4, !tbaa !29
  %t1113 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1111)
  store %"compiler/source:Span" %t1113, ptr %l599
  br label %bb340
bb340:
  %t1114 = load ptr, ptr %l592, !tbaa !29
  %t1115 = load ptr, ptr %l597, !tbaa !29
  %t1116 = load %"compiler/source:Span", ptr %l599
  %t1117 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1114, ptr %t1115, %"compiler/source:Span" %t1116)
  store ptr %t1117, ptr %l600
  br label %bb341
bb341:
  %t1118 = load ptr, ptr %l600, !tbaa !29
  store ptr %t1118, ptr %l23, !tbaa !29
  %t1120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1120, ptr %l602, !tbaa !29
  %t1121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1121, ptr %l603, !tbaa !29
  %t1122 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1122, ptr %l605, !tbaa !29
  %t1124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1124, ptr %l606, !tbaa !29
  %t1125 = load ptr, ptr %l23, !tbaa !29
  %t1128 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1125)
  store i32 %t1128, ptr %l609
  br label %bb342
bb342:
  %t1129 = load ptr, ptr %l606, !tbaa !29
  %t1130 = load i32, ptr %l609, !tbaa !23
  %t1131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %t1129, i32 %t1130)
  store i1 %t1131, ptr %l610
  br label %bb343
bb343:
  %t1132 = load i1, ptr %l610, !tbaa !21
  br i1 %t1132, label %bb344, label %bb345
bb344:
  %t1133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1133, ptr %l612, !tbaa !29
  %t1134 = load ptr, ptr %l23, !tbaa !29
  %t1137 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1134)
  store i32 %t1137, ptr %l615
  br label %bb346
bb345:
  %t1138 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1138, ptr %l611, !tbaa !23
  br label %bb348
bb346:
  %t1140 = load ptr, ptr %l612, !tbaa !29
  %t1141 = load i32, ptr %l615, !tbaa !23
  %t1142 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t1140, i32 %t1141)
  store i32 %t1142, ptr %l616
  br label %bb347
bb347:
  %t1143 = load i32, ptr %l616, !tbaa !23
  store i32 %t1143, ptr %l611, !tbaa !23
  br label %bb348
bb348:
  %t1144 = load ptr, ptr %l603, !tbaa !29
  %t1145 = load ptr, ptr %l605, !tbaa !29
  %t1146 = load i32, ptr %l611, !tbaa !23
  %t1147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1144, ptr %t1145, i32 %t1146)
  store ptr %t1147, ptr %l618
  br label %bb349
bb349:
  %t1148 = load ptr, ptr %l3, !tbaa !29
  %t1150 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1148)
  store %"compiler/source:Span" %t1150, ptr %l620
  br label %bb350
bb350:
  %t1151 = load ptr, ptr %l602, !tbaa !29
  %t1152 = load ptr, ptr %l618, !tbaa !29
  %t1153 = load %"compiler/source:Span", ptr %l620
  %t1154 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1151, ptr %t1152, %"compiler/source:Span" %t1153)
  store ptr %t1154, ptr %l621
  br label %bb351
bb351:
  %t1155 = load ptr, ptr %l621, !tbaa !29
  store ptr %t1155, ptr %l22, !tbaa !29
  br label %bb392
bb352:
  %t1157 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 0
  %t1158 = load i1, ptr %t1157, !tbaa !21
  store i1 %t1158, ptr %l624, !tbaa !21
  br label %bb354
bb353:
  store i1 false, ptr %l624, !tbaa !21
  br label %bb354
bb354:
  %t1160 = load i1, ptr %l624, !tbaa !21
  br i1 %t1160, label %bb355, label %bb356
bb355:
  %t1161 = getelementptr %"compiler/check:litv", ptr %l11, i32 0, i32 1
  %t1162 = load i1, ptr %t1161, !tbaa !21
  %t1164 = xor i1 %t1162, true
  store i1 %t1164, ptr %l626, !tbaa !21
  br label %bb357
bb356:
  store i1 false, ptr %l626, !tbaa !21
  br label %bb357
bb357:
  %t1166 = load i1, ptr %l626, !tbaa !21
  br i1 %t1166, label %bb358, label %bb359
bb358:
  %t1167 = getelementptr %"compiler/check:litv", ptr %l12, i32 0, i32 1
  %t1168 = load i1, ptr %t1167, !tbaa !21
  %t1170 = xor i1 %t1168, true
  store i1 %t1170, ptr %l629, !tbaa !21
  br label %bb360
bb359:
  store i1 false, ptr %l629, !tbaa !21
  br label %bb360
bb360:
  %t1172 = load i1, ptr %l629, !tbaa !21
  br i1 %t1172, label %bb361, label %bb362
bb361:
  %t1173 = load i1, ptr %l13, !tbaa !21
  %t1175 = xor i1 %t1173, true
  store i1 %t1175, ptr %l632, !tbaa !21
  br label %bb363
bb362:
  store i1 false, ptr %l632, !tbaa !21
  br label %bb363
bb363:
  %t1177 = load i1, ptr %l632, !tbaa !21
  br i1 %t1177, label %bb364, label %bb365
bb364:
  %t1178 = load ptr, ptr %l0, !tbaa !29
  %t1179 = load ptr, ptr %l3, !tbaa !29
  %t1182 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %t1178, ptr %t1179)
  store i1 %t1182, ptr %l638
  br label %bb366
bb365:
  store i1 false, ptr %l635, !tbaa !21
  br label %bb371
bb366:
  %t1183 = load i1, ptr %l638, !tbaa !21
  br i1 %t1183, label %bb367, label %bb368
bb367:
  store i1 true, ptr %l639, !tbaa !21
  br label %bb370
bb368:
  %t1184 = load ptr, ptr %l0, !tbaa !29
  %t1185 = load ptr, ptr %l4, !tbaa !29
  %t1188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v2, ptr %t1184, ptr %t1185)
  store i1 %t1188, ptr %l642
  br label %bb369
bb369:
  %t1189 = load i1, ptr %l642, !tbaa !21
  store i1 %t1189, ptr %l639, !tbaa !21
  br label %bb370
bb370:
  %t1190 = load i1, ptr %l639, !tbaa !21
  store i1 %t1190, ptr %l635, !tbaa !21
  br label %bb371
bb371:
  %t1191 = load i1, ptr %l635, !tbaa !21
  br i1 %t1191, label %bb372, label %bb373
bb372:
  store %olang.scope zeroinitializer, ptr %s31
  %t1192 = load ptr, ptr %l0, !tbaa !29
  %t1194 = getelementptr %"compiler/check:Checker", ptr %t1192, i32 0, i32 1
  %t1195 = load ptr, ptr %t1194, !tbaa !29
  %t1197 = getelementptr %"compiler/generic:Program", ptr %t1195, i32 0, i32 2
  %t1199 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s31, ptr %t1197, { i64, ptr } { i64 3, ptr @.d2 })
  store i32 %t1199, ptr %l646
  br label %bb374
bb373:
  %t1200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1200, ptr %l671, !tbaa !29
  %t1201 = load ptr, ptr %l0, !tbaa !29
  %t1202 = load ptr, ptr %l3, !tbaa !29
  %t1204 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1208 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1201, ptr %t1202, i32 %t1204)
  store ptr %t1208, ptr %l676
  br label %bb385
bb374:
  %t1209 = load i32, ptr %l646, !tbaa !23
  store i32 %t1209, ptr %l26, !tbaa !23
  %t1210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1210, ptr %l647, !tbaa !29
  %t1211 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1211, ptr %l648, !tbaa !29
  %t1212 = load %"compiler/check:litv", ptr %l11
  store %"compiler/check:litv" %t1212, ptr %l649
  %t1213 = load ptr, ptr %l0, !tbaa !29
  %t1214 = load %"compiler/check:litv", ptr %l11
  %t1215 = load i32, ptr %l26, !tbaa !23
  %t1219 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t1213, %"compiler/check:litv" %t1214, i32 %t1215)
  store i1 %t1219, ptr %l653
  br label %bb375
bb375:
  %t1220 = load i1, ptr %l653, !tbaa !21
  br i1 %t1220, label %bb376, label %bb377
bb376:
  %t1221 = load i32, ptr %l26, !tbaa !23
  store i32 %t1221, ptr %l654, !tbaa !23
  br label %bb378
bb377:
  %t1223 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1223, ptr %l654, !tbaa !23
  br label %bb378
bb378:
  %t1225 = load ptr, ptr %l647, !tbaa !29
  %t1226 = load ptr, ptr %l648, !tbaa !29
  %t1227 = load %"compiler/check:litv", ptr %l649
  %t1228 = load i32, ptr %l654, !tbaa !23
  %t1229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t1225, ptr %t1226, %"compiler/check:litv" %t1227, i32 %t1228)
  store ptr %t1229, ptr %l657
  br label %bb379
bb379:
  %t1230 = load ptr, ptr %l657, !tbaa !29
  store ptr %t1230, ptr %l22, !tbaa !29
  %t1232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1232, ptr %l659, !tbaa !29
  %t1233 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1233, ptr %l660, !tbaa !29
  %t1234 = load %"compiler/check:litv", ptr %l12
  store %"compiler/check:litv" %t1234, ptr %l661
  %t1235 = load ptr, ptr %l0, !tbaa !29
  %t1236 = load %"compiler/check:litv", ptr %l12
  %t1237 = load i32, ptr %l26, !tbaa !23
  %t1241 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t1235, %"compiler/check:litv" %t1236, i32 %t1237)
  store i1 %t1241, ptr %l665
  br label %bb380
bb380:
  %t1242 = load i1, ptr %l665, !tbaa !21
  br i1 %t1242, label %bb381, label %bb382
bb381:
  %t1243 = load i32, ptr %l26, !tbaa !23
  store i32 %t1243, ptr %l666, !tbaa !23
  br label %bb383
bb382:
  %t1245 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t1245, ptr %l666, !tbaa !23
  br label %bb383
bb383:
  %t1247 = load ptr, ptr %l659, !tbaa !29
  %t1248 = load ptr, ptr %l660, !tbaa !29
  %t1249 = load %"compiler/check:litv", ptr %l661
  %t1250 = load i32, ptr %l666, !tbaa !23
  %t1251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v2, ptr %t1247, ptr %t1248, %"compiler/check:litv" %t1249, i32 %t1250)
  store ptr %t1251, ptr %l669
  br label %bb384
bb384:
  %t1252 = load ptr, ptr %l669, !tbaa !29
  store ptr %t1252, ptr %l23, !tbaa !29
  call void @__olang_scope_close(ptr %s31)
  br label %bb391
bb385:
  %t1254 = load ptr, ptr %l3, !tbaa !29
  %t1256 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1254)
  store %"compiler/source:Span" %t1256, ptr %l678
  br label %bb386
bb386:
  %t1257 = load ptr, ptr %l671, !tbaa !29
  %t1258 = load ptr, ptr %l676, !tbaa !29
  %t1259 = load %"compiler/source:Span", ptr %l678
  %t1260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1257, ptr %t1258, %"compiler/source:Span" %t1259)
  store ptr %t1260, ptr %l679
  br label %bb387
bb387:
  %t1261 = load ptr, ptr %l679, !tbaa !29
  store ptr %t1261, ptr %l22, !tbaa !29
  %t1263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1263, ptr %l681, !tbaa !29
  %t1264 = load ptr, ptr %l0, !tbaa !29
  %t1265 = load ptr, ptr %l4, !tbaa !29
  %t1267 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %t1264, ptr %t1265, i32 %t1267)
  store ptr %t1271, ptr %l686
  br label %bb388
bb388:
  %t1272 = load ptr, ptr %l4, !tbaa !29
  %t1274 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1272)
  store %"compiler/source:Span" %t1274, ptr %l688
  br label %bb389
bb389:
  %t1275 = load ptr, ptr %l681, !tbaa !29
  %t1276 = load ptr, ptr %l686, !tbaa !29
  %t1277 = load %"compiler/source:Span", ptr %l688
  %t1278 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t1275, ptr %t1276, %"compiler/source:Span" %t1277)
  store ptr %t1278, ptr %l689
  br label %bb390
bb390:
  %t1279 = load ptr, ptr %l689, !tbaa !29
  store ptr %t1279, ptr %l23, !tbaa !29
  br label %bb391
bb391:
  br label %bb392
bb392:
  br label %bb393
bb393:
  br label %bb394
bb394:
  br label %bb395
bb395:
  br label %bb396
bb396:
  %t1281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1281, ptr %l691, !tbaa !29
  %t1282 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1282, ptr %l692
  %t1283 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t1283, ptr %l693
  %t1284 = load i32, ptr %l2
  store i32 %t1284, ptr %l694
  %t1285 = load ptr, ptr %l22, !tbaa !29
  %t1287 = icmp eq ptr %t1285, null
  br i1 %t1287, label %bb397, label %bb398
bb397:
  call void @__olang_check_failed(ptr @olang_loc_a245edc164872a99_7db9d56e029b164d)
  unreachable
bb398:
  br label %bb399
bb399:
  %t1289 = load ptr, ptr %l22, !tbaa !29
  store ptr %t1289, ptr %l697, !tbaa !29
  %t1290 = load ptr, ptr %l23, !tbaa !29
  %t1292 = icmp eq ptr %t1290, null
  br i1 %t1292, label %bb400, label %bb401
bb400:
  call void @__olang_check_failed(ptr @olang_loc_a245edc164872a99_7db9d56e029b164d)
  unreachable
bb401:
  br label %bb402
bb402:
  %t1294 = load ptr, ptr %l23, !tbaa !29
  store ptr %t1294, ptr %l700, !tbaa !29
  %t1295 = load ptr, ptr %l3, !tbaa !29
  %t1297 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1295)
  store %"compiler/source:Span" %t1297, ptr %l702
  br label %bb403
bb403:
  %t1298 = load ptr, ptr %l4, !tbaa !29
  %t1300 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t1298)
  store %"compiler/source:Span" %t1300, ptr %l704
  br label %bb404
bb404:
  %t1301 = load ptr, ptr %l691, !tbaa !29
  %t1302 = load %"compiler/source:Span", ptr %l692
  %t1303 = load %"compiler/source:Span", ptr %l693
  %t1304 = load i32, ptr %l694
  %t1305 = load ptr, ptr %l697, !tbaa !29
  %t1306 = load ptr, ptr %l700, !tbaa !29
  %t1307 = load %"compiler/source:Span", ptr %l702
  %t1308 = load %"compiler/source:Span", ptr %l704
  %t1309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t1301, %"compiler/source:Span" %t1302, %"compiler/source:Span" %t1303, i32 %t1304, ptr %t1305, ptr %t1306, %"compiler/source:Span" %t1307, %"compiler/source:Span" %t1308)
  store ptr %t1309, ptr %l705
  br label %bb405
bb405:
  call void @__olang_scope_close(ptr %s0)
  %t1310 = load ptr, ptr %l705, !tbaa !29
  store ptr %t1310, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebindType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l17 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l17
  br label %bb9
bb8:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t32)
  store i32 %t34, ptr %l19
  br label %bb10
bb10:
  %t35 = load i32, ptr %l17, !tbaa !23
  %t36 = load i32, ptr %l19, !tbaa !23
  %t37 = icmp eq i32 %t35, %t36
  store i1 %t37, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l12, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t40)
  store i32 %t42, ptr %l22
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t43 = load i32, ptr %l22, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t44)
  store i32 %t47, ptr %l25
  br label %bb18
bb18:
  %t48 = load i32, ptr %l25, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca ptr
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 11
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t18, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t28 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t28, ptr %l3
  %t30 = load { i64, [2 x i64] }, ptr %l3
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l24
  br label %bb10
bb10:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseName(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca %"compiler/names:Ref"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"compiler/names:Ref"
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i64
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l54 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb9
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l3, !tbaa !29
  br label %bb9
bb8:
  br label %bb41
bb9:
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l4
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32 }, ptr %t48, i32 0, i32 1
  %t50 = load i32, ptr %t49
  store i32 %t50, ptr %l5, !tbaa !23
  br label %bb14
bb13:
  br label %bb39
bb14:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l29, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t59)
  store ptr %t61, ptr %l31
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l31, !tbaa !29
  %t64 = getelementptr %"compiler/check:frame", ptr %t62, i32 0, i32 2
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l29, !tbaa !29
  %t71 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t68, i64 %t65, i32 %t67)
  store %"compiler/names:Ref" %t71, ptr %l35
  br label %bb16
bb16:
  %t72 = load %"compiler/names:Ref", ptr %l35
  store %"compiler/names:Ref" %t72, ptr %l6
  %t73 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 0 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l38, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t80, ptr %l39
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i32, ptr %l5, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t81, i32 %t82)
  store { i64, ptr } %t85, ptr %l42
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  %t88 = extractvalue { i64, ptr } %t86, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t94 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %s3, ptr %s3, { i64, ptr } %t92)
  store %"compiler/msgs:Msg" %t94, ptr %l44
  br label %bb20
bb20:
  %t95 = load ptr, ptr %l38, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l39
  %t97 = load %"compiler/msgs:Msg", ptr %l44
  %t98 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t95, %"compiler/source:Span" %t96, %"compiler/msgs:Msg" %t97)
  store i64 %t98, ptr %l45
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 69
  store ptr %t101, ptr %l47, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t102)
  store ptr %t104, ptr %l49
  br label %bb22
bb22:
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 0
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i32, ptr %l5, !tbaa !23
  %t111 = sext i32 %t109 to i64
  %t114 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t108, i64 %t111)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t114, ptr %l54
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l47, !tbaa !29
  %t116 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t115, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t116, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb25:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l6, i32 0, i32 0
  %t119 = load i32, ptr %t118
  %t121 = trunc i64 1 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t124 = load i64, ptr %l2, !tbaa !24
  %t126 = icmp sge i64 %t124, 0
  store i1 %t126, ptr %l58, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t128 = load i1, ptr %l58, !tbaa !21
  br i1 %t128, label %bb29, label %bb30
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l5, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t129, i32 %t130)
  store i64 %t133, ptr %l64
  br label %bb31
bb30:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb32
bb31:
  %t134 = load i64, ptr %l2, !tbaa !24
  %t135 = load i64, ptr %l64, !tbaa !24
  %t137 = icmp eq i64 %t135, %t134
  store i1 %t137, ptr %l61, !tbaa !21
  br label %bb32
bb32:
  %t139 = load i1, ptr %l61, !tbaa !21
  br i1 %t139, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l67, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t141, ptr %l68
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load i32, ptr %l5, !tbaa !23
  %t146 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t142, i32 %t143)
  store { i64, ptr } %t146, ptr %l71
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t147 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  %t155 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %s4, ptr %s4, { i64, ptr } %t153)
  store %"compiler/msgs:Msg" %t155, ptr %l73
  br label %bb36
bb36:
  %t156 = load ptr, ptr %l67, !tbaa !29
  %t157 = load %"compiler/source:Span", ptr %l68
  %t158 = load %"compiler/msgs:Msg", ptr %l73
  %t159 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t156, %"compiler/source:Span" %t157, %"compiler/msgs:Msg" %t158)
  store i64 %t159, ptr %l74
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, i64 %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %lp12 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l37 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l51 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca %"compiler/typed:Cond"
  %l75 = alloca ptr
  %l77 = alloca i32
  %l81 = alloca i64
  %l84 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca i32
  %l97 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca %"compiler/source:Span"
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca ptr
  %l110 = alloca ptr
  %l111 = alloca %"compiler/source:Span"
  %l112 = alloca i32
  %l116 = alloca { i64, ptr }
  %l119 = alloca %"compiler/typed:Seq"
  %l122 = alloca ptr
  %l123 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l136 = alloca i32
  %l137 = alloca ptr
  %l139 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t106 = alloca { i64, [5 x i64] }, align 8
  %t171 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca { i64, [5 x i64] }, align 8
  %t278 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Chain", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = load i64, ptr %l5, !tbaa !24
  %t10 = add i64 %t8, 2
  %t14 = icmp sge i64 %t10, %t6
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t17, ptr %l22
  %t18 = load ptr, ptr %l2, !tbaa !29
  store ptr %t18, ptr %l23, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l24, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  store ptr %t20, ptr %l25, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l26, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t24 = add i64 %t22, 1
  %t26 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i1, ptr %t27, i64 %t24
  %t29 = load i1, ptr %t28, !tbaa !31
  br i1 %t29, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  store ptr null, ptr %l30, !tbaa !29
  br label %bb6
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 32
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = add i64 %t38, 1
  %t43 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t40)
  store ptr %t43, ptr %l37
  br label %bb5
bb5:
  %t44 = load ptr, ptr %l37, !tbaa !29
  store ptr %t44, ptr %l30, !tbaa !29
  br label %bb6
bb6:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l22
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t46, %"compiler/source:Span" %t47, ptr %t48, i64 %t49, ptr %t50, ptr %t51)
  store ptr %t52, ptr %l39
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load ptr, ptr %l39, !tbaa !29
  store ptr %t53, ptr %rv
  br label %ret
bb8:
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t54, ptr %l40, !tbaa !27
  %t55 = load i64, ptr %l5, !tbaa !24
  %t57 = add i64 %t55, 1
  %t59 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i1, ptr %t60, i64 %t57
  %t62 = load i1, ptr %t61, !tbaa !31
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t64, ptr %l44
  %t65 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t65, ptr %l45, !tbaa !23
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t66, %"compiler/source:Span" %t67, ptr %t68, i64 %t69, ptr %t70, ptr null)
  store ptr %t76, ptr %l51
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t84 = add i64 %t82, 1
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %t77, %"compiler/source:Span" %t78, ptr %t79, i64 %t80, { i64, ptr } %t81, i64 %t84, ptr null)
  store ptr %t91, ptr %l59
  br label %bb12
bb12:
  %t92 = load ptr, ptr %l59, !tbaa !29
  store ptr %t92, ptr %l60, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 0)
  store ptr %t99, ptr %l64
  br label %bb13
bb13:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l60, !tbaa !29
  %t102 = load ptr, ptr %l64, !tbaa !29
  %t103 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t100, ptr %t101, ptr %t102)
  store %"compiler/typed:Cond" %t103, ptr %l65
  br label %bb14
bb14:
  %t104 = load %"compiler/typed:Cond", ptr %l65
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t104, ptr %t105
  store { i64, [5 x i64] } zeroinitializer, ptr %t106
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 0
  store i64 11, ptr %t107
  %t108 = load %"compiler/source:Span", ptr %l44
  %t109 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t108, 0
  %t110 = load i32, ptr %l45, !tbaa !23
  %t111 = insertvalue { %"compiler/source:Span", i32, ptr } %t109, i32 %t110, 1
  %t113 = insertvalue { %"compiler/source:Span", i32, ptr } %t111, ptr %t105, 2
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t106, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t113, ptr %t114
  %t115 = load { i64, [5 x i64] }, ptr %t106
  %t117 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t115, ptr %t117
  call void @__olang_scope_close(ptr %s0)
  store ptr %t117, ptr %rv
  br label %ret
bb15:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 32
  %t122 = load i64, ptr %l3, !tbaa !24
  %t123 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = add i64 %t126, 1
  %t131 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %s0, ptr %t121, i64 %t128)
  store ptr %t131, ptr %l75
  br label %bb16
bb16:
  %t132 = load ptr, ptr %l75, !tbaa !29
  %t134 = call i32 @compiler_2fcheck_2etypeOf(ptr %s0, ptr %t132)
  store i32 %t134, ptr %l77
  br label %bb17
bb17:
  %t135 = load i32, ptr %l77, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  %t142 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t136, %"compiler/source:Span" %t137, i32 %t135)
  store i64 %t142, ptr %l81
  br label %bb18
bb18:
  %t143 = load i64, ptr %l81, !tbaa !24
  store i64 %t143, ptr %l9, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 33
  %t148 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t146)
  store i64 %t148, ptr %l84
  br label %bb19
bb19:
  %t149 = load i64, ptr %l84, !tbaa !24
  store i64 %t149, ptr %l10, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 33
  store ptr %t152, ptr %l86, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l87
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  store i32 %t156, ptr %l90, !tbaa !23
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 32
  %t161 = load i64, ptr %l3, !tbaa !24
  %t162 = load i64, ptr %l5, !tbaa !24
  %t165 = add i64 %t161, %t162
  %t167 = add i64 %t165, 1
  %t170 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t160, i64 %t167)
  store ptr %t170, ptr %l97
  br label %bb20
bb20:
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l87
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l90, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t177, 2
  %t179 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [3 x i64] }, ptr %t171
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t180, ptr %t182
  %t183 = load ptr, ptr %l86, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t183, ptr %t182)
  br label %bb21
bb21:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l100, !tbaa !29
  %t186 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t186, ptr %l101
  %t187 = load ptr, ptr %l2, !tbaa !29
  store ptr %t187, ptr %l102, !tbaa !29
  %t188 = load i64, ptr %l5, !tbaa !24
  store i64 %t188, ptr %l103, !tbaa !24
  %t189 = load ptr, ptr %l6, !tbaa !29
  store ptr %t189, ptr %l104, !tbaa !29
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t192 = load i64, ptr %l9, !tbaa !24
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t190, %"compiler/source:Span" %t191, i64 %t192)
  store ptr %t196, ptr %l108
  br label %bb22
bb22:
  %t197 = load ptr, ptr %l108, !tbaa !29
  %t198 = load ptr, ptr %l100, !tbaa !29
  %t199 = load %"compiler/source:Span", ptr %l101
  %t200 = load ptr, ptr %l102, !tbaa !29
  %t201 = load i64, ptr %l103, !tbaa !24
  %t202 = load ptr, ptr %l104, !tbaa !29
  %t204 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %t198, %"compiler/source:Span" %t199, ptr %t200, i64 %t201, ptr %t202, ptr %t197)
  store ptr %t204, ptr %l110
  br label %bb23
bb23:
  %t205 = load ptr, ptr %l110, !tbaa !29
  store ptr %t205, ptr %l11, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l111
  %t207 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t207, ptr %l112, !tbaa !23
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 33
  %t211 = load i64, ptr %l10, !tbaa !24
  %t214 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l116
  br label %bb24
bb24:
  %t215 = load ptr, ptr %l11, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t219 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t217, ptr %t215)
  store %"compiler/typed:Seq" %t219, ptr %l119
  br label %bb25
bb25:
  %t220 = load %"compiler/typed:Seq", ptr %l119
  %t221 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t220, ptr %t221
  store { i64, [5 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 0
  store i64 12, ptr %t223
  %t224 = load %"compiler/source:Span", ptr %l111
  %t225 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t224, 0
  %t226 = load i32, ptr %l112, !tbaa !23
  %t227 = insertvalue { %"compiler/source:Span", i32, ptr } %t225, i32 %t226, 1
  %t229 = insertvalue { %"compiler/source:Span", i32, ptr } %t227, ptr %t221, 2
  %t230 = getelementptr { i64, [5 x i64] }, ptr %t222, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t229, ptr %t230
  %t231 = load { i64, [5 x i64] }, ptr %t222
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t232, ptr %lp12
  %t234 = load ptr, ptr %lp12
  store { i64, [5 x i64] } %t231, ptr %t234
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l122, !tbaa !29
  %t236 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t236, ptr %l123
  %t237 = load ptr, ptr %l2, !tbaa !29
  store ptr %t237, ptr %l124, !tbaa !29
  %t238 = load i64, ptr %l3, !tbaa !24
  store i64 %t238, ptr %l125, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = load i64, ptr %l5, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l128, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load i64, ptr %l9, !tbaa !24
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, i64 %t245)
  store ptr %t249, ptr %l132
  br label %bb26
bb26:
  %t250 = load ptr, ptr %l132, !tbaa !29
  %t251 = load ptr, ptr %l122, !tbaa !29
  %t252 = load %"compiler/source:Span", ptr %l123
  %t253 = load ptr, ptr %l124, !tbaa !29
  %t254 = load i64, ptr %l125, !tbaa !24
  %t255 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t256 = load i64, ptr %l128, !tbaa !24
  %t258 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainFrom(ptr %v0, ptr %v1, ptr %v2, ptr %t251, %"compiler/source:Span" %t252, ptr %t253, i64 %t254, { i64, ptr } %t255, i64 %t256, ptr %t250)
  store ptr %t258, ptr %l134
  br label %bb27
bb27:
  %t259 = load ptr, ptr %l134, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l135
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t261, ptr %l136, !tbaa !23
  %t262 = load ptr, ptr %lp12
  store ptr %t262, ptr %l137, !tbaa !29
  store ptr %t259, ptr %l139, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  %t267 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t271 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t265, %"compiler/source:Span" %t266, i32 %t267, i64 0)
  store ptr %t271, ptr %l143
  br label %bb28
bb28:
  %t272 = load ptr, ptr %l137, !tbaa !29
  %t273 = load ptr, ptr %l139, !tbaa !29
  %t274 = load ptr, ptr %l143, !tbaa !29
  %t275 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t272, ptr %t273, ptr %t274)
  store %"compiler/typed:Cond" %t275, ptr %l144
  br label %bb29
bb29:
  %t276 = load %"compiler/typed:Cond", ptr %l144
  %t277 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t276, ptr %t277
  store { i64, [5 x i64] } zeroinitializer, ptr %t278
  %t279 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 0
  store i64 11, ptr %t279
  %t280 = load %"compiler/source:Span", ptr %l135
  %t281 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t280, 0
  %t282 = load i32, ptr %l136, !tbaa !23
  %t283 = insertvalue { %"compiler/source:Span", i32, ptr } %t281, i32 %t282, 1
  %t285 = insertvalue { %"compiler/source:Span", i32, ptr } %t283, ptr %t277, 2
  %t286 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t285, ptr %t286
  %t287 = load { i64, [5 x i64] }, ptr %t278
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t287, ptr %t289
  call void @__olang_scope_close(ptr %s0)
  store ptr %t289, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %lp6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l14 = alloca i32
  %l20 = alloca i1
  %l21 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %l41 = alloca i64
  %l46 = alloca i64
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l61 = alloca i1
  %l66 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l83 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i32, ptr %l9, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t7, i32 %a2)
  store i32 %t11, ptr %l12
  br label %bb2
bb2:
  %t12 = load i32, ptr %l12, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 18, ptr @.d3 }, { i64, ptr } { i64 11, ptr @.d4 }, { i64, ptr } { i64 8, ptr @.d5 })
  store i32 %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 0, i64 8)
  store ptr %t17, ptr %lp6
  %t19 = load ptr, ptr %lp6
  store [0 x i32] zeroinitializer, ptr %t19
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l20
  br label %bb4
bb4:
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l4, !tbaa !23
  %t40 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l26, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l21, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t45, { i64, ptr } { i64 18, ptr @.d6 }, { i64, ptr } { i64 11, ptr @.d7 }, { i64, ptr } { i64 7, ptr @.d8 })
  store i32 %t47, ptr %l29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t48 = load i32, ptr %l5, !tbaa !23
  %t49 = mul i64 2, 4
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 2, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l31, !tbaa !27
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i32, ptr %t55, i64 0
  store i32 %t53, ptr %t56, !tbaa !33
  %t58 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 1
  store i32 %t48, ptr %t60, !tbaa !33
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l3, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t71, ptr %l36
  br label %bb13
bb13:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  %t79 = load i32, ptr %l4, !tbaa !23
  %t82 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t78, i32 %t79)
  store i64 %t82, ptr %l41
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l3, !tbaa !23
  %t92 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t92, ptr %l46
  br label %bb17
bb17:
  %t93 = load i64, ptr %l41, !tbaa !24
  %t94 = load i64, ptr %l46, !tbaa !24
  %t95 = icmp slt i64 %t93, %t94
  br i1 %t95, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t97 = load i32, ptr %l4, !tbaa !23
  %t98 = load i32, ptr %l3, !tbaa !23
  %t101 = icmp ne i32 %t97, %t98
  store i1 %t101, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb21, label %bb22
bb21:
  %t104 = load i32, ptr %l5, !tbaa !23
  %t105 = mul i64 1, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 1, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l54, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr i32, ptr %t111, i64 0
  store i32 %t104, ptr %t112, !tbaa !33
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  br label %bb23
bb22:
  %t114 = load ptr, ptr %lp6
  %t116 = insertvalue { i64, ptr } undef, i64 0, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t114, 1
  store { i64, ptr } %t117, ptr %l52, !tbaa !27
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
bb24:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l4, !tbaa !23
  %t129 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t125, i32 %t126)
  store i1 %t129, ptr %l61
  br label %bb25
bb25:
  %t130 = load i1, ptr %l61, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Program", ptr %t134, i32 0, i32 2
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t136, i32 %t137)
  store i64 %t140, ptr %l66
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t141 = load i64, ptr %l66, !tbaa !24
  %t142 = icmp sle i64 %t141, 16
  br i1 %t142, label %bb29, label %bb30
bb29:
  %t144 = load i32, ptr %l5, !tbaa !23
  %t145 = mul i64 1, 4
  %t146 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t145)
  %t147 = insertvalue { i64, ptr } undef, i64 1, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l70, !tbaa !27
  %t150 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i32, ptr %t151, i64 0
  store i32 %t144, ptr %t152, !tbaa !33
  %t153 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  br label %bb31
bb30:
  %t154 = load ptr, ptr %lp6
  %t156 = insertvalue { i64, ptr } undef, i64 0, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t154, 1
  store { i64, ptr } %t157, ptr %l68, !tbaa !27
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t159, ptr %rv
  br label %ret
bb32:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/check:Checker", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t164 = load i32, ptr %l3, !tbaa !23
  %t165 = load i32, ptr %l4, !tbaa !23
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t163, i32 %t164, i32 %t165)
  store i32 %t169, ptr %l77
  br label %bb33
bb33:
  %t170 = load i32, ptr %l4, !tbaa !23
  %t171 = load i32, ptr %l77, !tbaa !23
  %t173 = icmp eq i32 %t171, %t170
  br i1 %t173, label %bb34, label %bb35
bb34:
  %t175 = load ptr, ptr %lp6
  %t177 = insertvalue { i64, ptr } undef, i64 0, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t178, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t180 = load i32, ptr %l5, !tbaa !23
  %t181 = mul i64 1, 4
  %t182 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t181)
  %t183 = insertvalue { i64, ptr } undef, i64 1, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l83, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr i32, ptr %t187, i64 0
  store i32 %t180, ptr %t188, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecover(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, ptr %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l41 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i32
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l83 = alloca i64
  %l86 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l108 = alloca i1
  %l115 = alloca i1
  %l118 = alloca i1
  %l119 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca %"compiler/source:Span"
  %l125 = alloca { i64, ptr }
  %l127 = alloca %"compiler/msgs:Msg"
  %l128 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca i1
  %l148 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca i1
  %l168 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l172 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca i64
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t1)
  store i64 %t3, ptr %l27
  br label %bb1
bb1:
  %t4 = load i64, ptr %l27, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t8 = load ptr, ptr %l29, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load ptr, ptr %l29, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 5
  store i1 %t14, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l30, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t18, i32 0, i32 0
  %t20 = load %"compiler/source:Span", ptr %t19
  store %"compiler/source:Span" %t20, ptr %l5
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb63
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l2, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb10
bb10:
  %t38 = load i32, ptr %l41
  %t40 = trunc i64 29 to i32
  %t41 = icmp eq i32 %t38, %t40
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l6, !tbaa !29
  store ptr %t45, ptr %l7, !tbaa !29
  %t47 = load ptr, ptr %l6, !tbaa !29
  store ptr %t47, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t48 = load ptr, ptr %l46, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l46, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 3
  store i1 %t54, ptr %l47, !tbaa !21
  br label %bb15
bb15:
  %t55 = load i1, ptr %l47, !tbaa !21
  br i1 %t55, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l6, !tbaa !29
  %t58 = getelementptr { i64, [5 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l8, !tbaa !29
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load ptr, ptr %l8, !tbaa !29
  store ptr %t62, ptr %l7, !tbaa !29
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t64, ptr %t65, i1 false)
  store i1 %t68, ptr %l55
  br label %bb21
bb21:
  %t69 = load i1, ptr %l55, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 2
  store ptr %t75, ptr %l59, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i32 %t81, ptr %l63
  br label %bb24
bb23:
  %t82 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t82, ptr %l56, !tbaa !23
  br label %bb26
bb24:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i32, ptr %l63, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t86, ptr %l64
  br label %bb25
bb25:
  %t87 = load i32, ptr %l64, !tbaa !23
  store i32 %t87, ptr %l56, !tbaa !23
  br label %bb26
bb26:
  %t88 = load i32, ptr %l56, !tbaa !23
  store i32 %t88, ptr %l9, !tbaa !23
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  store ptr %t92, ptr %l67, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l2, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l72
  br label %bb27
bb27:
  %t103 = load ptr, ptr %l67, !tbaa !29
  %t104 = load i32, ptr %l72, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %s2, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l73
  br label %bb28
bb28:
  %t106 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t106, ptr %l10, !tbaa !27
  %t107 = load i32, ptr %l9, !tbaa !23
  %t108 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t111 = icmp eq i32 %t107, %t108
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 91
  store i1 true, ptr %t115, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb30:
  br label %bb31
bb31:
  store i64 0, ptr %l11, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb32, label %bb33
bb32:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb37
bb34:
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l86, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb36
bb36:
  %t146 = load i64, ptr %l86, !tbaa !24
  store i64 %t146, ptr %l83, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l83, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t148 = load i64, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb62
bb40:
  br label %bb41
bb41:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  store i64 %t166, ptr %l104, !tbaa !24
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v2, ptr %t167)
  store i64 %t169, ptr %l106
  br label %bb42
bb42:
  %t170 = load i64, ptr %l104, !tbaa !24
  %t171 = load i64, ptr %l106, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  br i1 %t172, label %bb43, label %bb44
bb43:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i64, ptr %l16, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i32, ptr %t183, i64 %t180
  %t185 = load i32, ptr %t184, !tbaa !33
  %t186 = load i32, ptr %l9, !tbaa !23
  %t190 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t179, i32 %t185, i32 %t186)
  store i1 %t190, ptr %l115
  br label %bb45
bb44:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb46
bb45:
  %t191 = load i1, ptr %l115, !tbaa !21
  store i1 %t191, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t192 = load i1, ptr %l108, !tbaa !21
  br i1 %t192, label %bb47, label %bb48
bb47:
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t194 = load i64, ptr %l16, !tbaa !24
  %t197 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v2, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l118
  br label %bb49
bb48:
  br label %bb60
bb49:
  %t198 = load i1, ptr %l118, !tbaa !21
  br i1 %t198, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb52
bb51:
  store i1 %a4, ptr %l119, !tbaa !21
  br label %bb52
bb52:
  %t201 = load i1, ptr %l119, !tbaa !21
  br i1 %t201, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l121, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t203, ptr %l122
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l9, !tbaa !23
  %t208 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t204, i32 %t205)
  store { i64, ptr } %t208, ptr %l125
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t209 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t217 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %s10, ptr %s10, { i64, ptr } %t215)
  store %"compiler/msgs:Msg" %t217, ptr %l127
  br label %bb56
bb56:
  %t218 = load ptr, ptr %l121, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l122
  %t220 = load %"compiler/msgs:Msg", ptr %l127
  %t221 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t218, %"compiler/source:Span" %t219, %"compiler/msgs:Msg" %t220)
  store i64 %t221, ptr %l128
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb58:
  %t222 = load ptr, ptr %l3, !tbaa !29
  %t223 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t222, i64 %t223, i1 true)
  br label %bb59
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb61:
  %t226 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t226, 1
  store i64 %t228, ptr %l15, !tbaa !24
  br label %bb38
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb107
bb63:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb64, label %bb65
bb64:
  %t234 = load ptr, ptr %l133, !tbaa !29
  %t235 = load i64, ptr %t234
  %t237 = icmp eq i64 %t235, 1
  store i1 %t237, ptr %l134, !tbaa !21
  br label %bb65
bb65:
  %t238 = load i1, ptr %l134, !tbaa !21
  br i1 %t238, label %bb66, label %bb67
bb66:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr }, ptr %t241, i32 0, i32 1
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l17, !tbaa !29
  br label %bb72
bb67:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t246 = load ptr, ptr %l139, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb68, label %bb69
bb68:
  %t249 = load ptr, ptr %l139, !tbaa !29
  %t250 = load i64, ptr %t249
  %t252 = icmp eq i64 %t250, 4
  store i1 %t252, ptr %l140, !tbaa !21
  br label %bb69
bb69:
  %t253 = load i1, ptr %l140, !tbaa !21
  br i1 %t253, label %bb70, label %bb71
bb70:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [4 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", ptr }, ptr %t256, i32 0, i32 1
  %t258 = load ptr, ptr %t257
  store ptr %t258, ptr %l17, !tbaa !29
  br label %bb72
bb71:
  br label %bb78
bb72:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l17, !tbaa !29
  %t262 = load i32, ptr %l2, !tbaa !23
  %t266 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t260, ptr %t261, i32 %t262)
  store i64 %t266, ptr %l148
  br label %bb73
bb73:
  %t267 = load i64, ptr %l148, !tbaa !24
  store i64 %t267, ptr %l18, !tbaa !24
  %t268 = load i64, ptr %l18, !tbaa !24
  %t270 = icmp sge i64 %t268, 0
  br i1 %t270, label %bb74, label %bb75
bb74:
  %t272 = load ptr, ptr %l3, !tbaa !29
  %t273 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t272, i64 %t273, i1 true)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb107
bb78:
  %t276 = load ptr, ptr %l1, !tbaa !29
  store ptr %t276, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t277 = load ptr, ptr %l153, !tbaa !29
  %t278 = icmp ne ptr %t277, null
  br i1 %t278, label %bb79, label %bb80
bb79:
  %t280 = load ptr, ptr %l153, !tbaa !29
  %t281 = load i64, ptr %t280
  %t283 = icmp eq i64 %t281, 2
  store i1 %t283, ptr %l154, !tbaa !21
  br label %bb80
bb80:
  %t284 = load i1, ptr %l154, !tbaa !21
  br i1 %t284, label %bb81, label %bb82
bb81:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t287 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  %t288 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t287, i32 0, i32 1
  %t289 = load ptr, ptr %t288
  store ptr %t289, ptr %l19, !tbaa !29
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [4 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t293, i32 0, i32 2
  %t295 = load { i64, ptr }, ptr %t294
  store { i64, ptr } %t295, ptr %l20, !tbaa !27
  br label %bb83
bb82:
  br label %bb106
bb83:
  %t297 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t297, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l23, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s16
  %t303 = load i64, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l23, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb100
bb86:
  br label %bb87
bb87:
  %t311 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t311, ptr %l168, !tbaa !27
  %t312 = load i64, ptr %l22, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 %t312
  %t317 = load ptr, ptr %t316, !tbaa !39
  store ptr %t317, ptr %l24, !tbaa !29
  %t319 = load ptr, ptr %l24, !tbaa !29
  store ptr %t319, ptr %l171, !tbaa !29
  store i1 false, ptr %l172, !tbaa !21
  %t320 = load ptr, ptr %l171, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb88, label %bb89
bb88:
  %t323 = load ptr, ptr %l171, !tbaa !29
  %t324 = load i64, ptr %t323
  %t326 = icmp eq i64 %t324, 3
  store i1 %t326, ptr %l172, !tbaa !21
  br label %bb89
bb89:
  %t327 = load i1, ptr %l172, !tbaa !21
  br i1 %t327, label %bb90, label %bb91
bb90:
  br label %bb96
bb91:
  %t328 = load ptr, ptr %l24, !tbaa !29
  store ptr %t328, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t329 = load ptr, ptr %l175, !tbaa !29
  %t330 = icmp ne ptr %t329, null
  br i1 %t330, label %bb92, label %bb93
bb92:
  %t332 = load ptr, ptr %l175, !tbaa !29
  %t333 = load i64, ptr %t332
  %t335 = icmp eq i64 %t333, 0
  store i1 %t335, ptr %l176, !tbaa !21
  br label %bb93
bb93:
  %t336 = load i1, ptr %l176, !tbaa !21
  br i1 %t336, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb98
bb97:
  call void @__olang_scope_close(ptr %s16)
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %bb99
bb99:
  %t337 = load i64, ptr %l22, !tbaa !24
  %t339 = add i64 %t337, 1
  store i64 %t339, ptr %l22, !tbaa !24
  br label %bb84
bb100:
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load ptr, ptr %l19, !tbaa !29
  %t343 = load i32, ptr %l2, !tbaa !23
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t341, ptr %t342, i32 %t343)
  store i64 %t347, ptr %l184
  br label %bb101
bb101:
  %t348 = load i64, ptr %l184, !tbaa !24
  store i64 %t348, ptr %l25, !tbaa !24
  %t349 = load i64, ptr %l25, !tbaa !24
  %t351 = icmp sge i64 %t349, 0
  br i1 %t351, label %bb102, label %bb103
bb102:
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t354 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v2, ptr %t353, i64 %t354, i1 true)
  br label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb105
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l9 = alloca { i64, [3 x i64] }
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t15 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t11, %"compiler/source:Span" %a1)
  store { i64, [3 x i64] } %t15, ptr %l9
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load { i64, [3 x i64] }, ptr %l9
  %t20 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %t17, { i64, [3 x i64] } %t18, %"compiler/msgs:Msg" %a2)
  store i64 %t20, ptr %l11
  br label %bb2
bb2:
  %t21 = load i64, ptr %l11, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/names:Ref"
  %l31 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca %"compiler/names:Ref"
  %l46 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i32
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l80 = alloca %"compiler/msgs:Msg"
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l101 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l11, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  br label %bb8
bb7:
  br label %bb34
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l23
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t46 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t43, i64 %t40, i32 %t42)
  store %"compiler/names:Ref" %t46, ptr %l27
  br label %bb10
bb10:
  %t47 = load %"compiler/names:Ref", ptr %l27
  store %"compiler/names:Ref" %t47, ptr %l4
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t52 = icmp sgt i64 %t50, 1
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t55 = load i32, ptr %t54
  %t57 = trunc i64 0 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/generic:Program", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t68)
  store ptr %t70, ptr %l38
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 2
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load ptr, ptr %l36, !tbaa !29
  %t80 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t77, i64 %t74, i32 %t76)
  store %"compiler/names:Ref" %t80, ptr %l42
  br label %bb17
bb17:
  %t81 = load %"compiler/names:Ref", ptr %l42
  store %"compiler/names:Ref" %t81, ptr %l4
  br label %bb18
bb18:
  %t82 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t83 = load i32, ptr %t82
  %t85 = trunc i64 4 to i32
  %t86 = icmp eq i32 %t83, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb21
bb20:
  %t90 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t91 = load i64, ptr %t90, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  store i1 %t93, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l46, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l52, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t110 = load i64, ptr %t109, !tbaa !24
  %t114 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t106, i64 %t108, i64 %t110)
  store i32 %t114, ptr %l57
  br label %bb25
bb25:
  %t115 = load ptr, ptr %l52, !tbaa !29
  %t116 = load i32, ptr %l57, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t115, i32 %t116)
  store i32 %t117, ptr %l58
  br label %bb26
bb26:
  %t118 = load i32, ptr %l58
  %t120 = trunc i64 2 to i32
  %t121 = icmp eq i32 %t118, %t120
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l64, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t132 = sub i64 %t130, 1
  %t134 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  %t140 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t126, i32 %t137)
  store { i64, ptr } %t140, ptr %l69
  br label %bb30
bb30:
  %t141 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t141, ptr %l5, !tbaa !27
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l70, !tbaa !29
  %t143 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t144 = load i32, ptr %t143, !tbaa !23
  %t145 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t149 = trunc i64 %t147 to i32
  %t152 = sub i32 %t144, %t149
  %t153 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t154 = load i32, ptr %t153, !tbaa !23
  %t157 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t152, i32 %t154)
  store %"compiler/source:Span" %t157, ptr %l77
  br label %bb31
bb31:
  %t158 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t162 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t158, { i64, ptr } %t159)
  store %"compiler/msgs:Msg" %t162, ptr %l80
  br label %bb32
bb32:
  %t163 = load ptr, ptr %l70, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l77
  %t165 = load %"compiler/msgs:Msg", ptr %l80
  %t166 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t163, %"compiler/source:Span" %t164, %"compiler/msgs:Msg" %t165)
  store i64 %t166, ptr %l81
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb34:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t169 = load ptr, ptr %l83, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb35, label %bb36
bb35:
  %t172 = load ptr, ptr %l83, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 3
  store i1 %t175, ptr %l84, !tbaa !21
  br label %bb36
bb36:
  %t176 = load i1, ptr %l84, !tbaa !21
  br i1 %t176, label %bb37, label %bb38
bb37:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l6, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l6, !tbaa !29
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %t183, ptr %t184)
  store i1 %t188, ptr %l92
  br label %bb40
bb40:
  %t189 = load i1, ptr %l92, !tbaa !21
  store i1 %t189, ptr %rv
  br label %ret
bb41:
  %t190 = load ptr, ptr %l1, !tbaa !29
  store ptr %t190, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t191 = load ptr, ptr %l93, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb42, label %bb43
bb42:
  %t194 = load ptr, ptr %l93, !tbaa !29
  %t195 = load i64, ptr %t194
  %t197 = icmp eq i64 %t195, 4
  store i1 %t197, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t198 = load i1, ptr %l94, !tbaa !21
  br i1 %t198, label %bb44, label %bb45
bb44:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t201, i32 0, i32 1
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l7, !tbaa !29
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load ptr, ptr %l7, !tbaa !29
  %t209 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorTypeHeld(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store i1 %t209, ptr %l101
  br label %bb47
bb47:
  %t210 = load i1, ptr %l101, !tbaa !21
  store i1 %t210, ptr %rv
  br label %ret
bb48:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l47 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l61 = alloca %"compiler/source:Span"
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l85 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i32
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca { i64, ptr }
  %l134 = alloca i32
  %l141 = alloca { i64, ptr }
  %l144 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t181 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l31
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l31, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %t27)
  store { i64, ptr } %t30, ptr %l35
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %s0, ptr %t35, i64 %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l39
  br label %bb10
bb10:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l6
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t42, ptr %l41
  br label %bb11
bb11:
  %t43 = load i64, ptr %l41, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp eq i64 %t44, 0
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l44, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l45, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l47
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s2, { i64, ptr } %t56)
  store %"compiler/msgs:Msg" %t58, ptr %l49
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l44, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l47
  %t61 = load %"compiler/msgs:Msg", ptr %l49
  %t62 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t59, %"compiler/source:Span" %t60, %"compiler/msgs:Msg" %t61)
  store i64 %t62, ptr %l50
  br label %bb16
bb16:
  %t63 = icmp sge i64 0, 0
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t65 = icmp sle i64 0, 2305843009213693951
  br i1 %t65, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb19:
  %t67 = mul i64 0, 4
  %t68 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 0, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb21:
  %t72 = load i64, ptr %l7, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t78 = icmp ne i64 %t72, %t75
  br i1 %t78, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l58, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t81, ptr %l59, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t87 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t85)
  store %"compiler/source:Span" %t87, ptr %l61
  br label %bb24
bb23:
  br label %bb31
bb24:
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s3, { i64, ptr } %t88, i64 %t89, i64 %t92)
  store %"compiler/msgs:Msg" %t96, ptr %l66
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l58, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l61
  %t99 = load %"compiler/msgs:Msg", ptr %l66
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l67
  br label %bb26
bb26:
  %t101 = icmp sge i64 0, 0
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t103 = icmp sle i64 0, 2305843009213693951
  br i1 %t103, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb29:
  %t105 = mul i64 0, 4
  %t106 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 0, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t108, ptr %rv
  br label %ret
bb30:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb31:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l6, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t111 = load ptr, ptr %l9, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t111, i64 %t112)
  %t116 = extractvalue { i32, { i64, ptr } } %t115, 1
  %t117 = extractvalue { i32, { i64, ptr } } %t115, 0
  store i32 %t117, ptr %l76
  %t118 = icmp ne i32 %t117, 0
  br i1 %t118, label %bb34, label %ok.119
ok.119:
  store { i64, ptr } %t116, ptr %l75
  br label %bb33
bb33:
  %t120 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t120, ptr %l72, !tbaa !27
  br label %bb38
bb34:
  %t121 = load i32, ptr %l76, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ebcf32f47df7174f_4e59f8f3ef8032cb)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb38:
  %t126 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t126, ptr %l11, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  store i64 %t129, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s6
  %t131 = load i64, ptr %l13, !tbaa !24
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = icmp slt i64 %t131, %t132
  %t137 = xor i1 %t135, true
  br i1 %t137, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t139 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t139, ptr %l85, !tbaa !27
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t140
  %t145 = load i64, ptr %t144, !tbaa !34
  store i64 %t145, ptr %l14, !tbaa !24
  %t147 = load i64, ptr %l14, !tbaa !24
  %t149 = add i64 %t147, 1
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = icmp sgt i64 %t149, %t150
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t155 = load i64, ptr %l14, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l8, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb46:
  %t159 = load i64, ptr %l13, !tbaa !24
  %t161 = add i64 %t159, 1
  store i64 %t161, ptr %l13, !tbaa !24
  br label %bb39
bb47:
  %t163 = load i64, ptr %l10, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = add i64 %t163, %t164
  store i64 %t167, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb48:
  br label %bb32
bb49:
  %t169 = load i64, ptr %l8, !tbaa !24
  store i64 %t169, ptr %l99, !tbaa !24
  %t170 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t170, ptr %l100, !tbaa !23
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = icmp sge i64 %t171, 0
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t174 = load i64, ptr %l99, !tbaa !24
  %t175 = icmp sle i64 %t174, 2305843009213693951
  br i1 %t175, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb52:
  %t177 = load i64, ptr %l99, !tbaa !24
  %t178 = mul i64 %t177, 4
  %t179 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t178)
  %t180 = load i32, ptr %l100, !tbaa !23
  store i64 0, ptr %t181
  br label %fill.182
fill.182:
  %t185 = load i64, ptr %t181
  %t186 = icmp slt i64 %t185, %t177
  br i1 %t186, label %fillb.183, label %filld.184
fillb.183:
  %t187 = getelementptr i32, ptr %t179, i64 %t185
  store i32 %t180, ptr %t187
  %t188 = add i64 %t185, 1
  store i64 %t188, ptr %t181
  br label %fill.182
filld.184:
  %t189 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t179, 1
  store { i64, ptr } %t190, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l7, !tbaa !24
  store i64 %t192, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t195 = load i64, ptr %l16, !tbaa !24
  %t198 = icmp sgt i64 %t194, %t195
  br i1 %t198, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e4324c4b30f6563f_ec149b7f01d5683b)
  unreachable
bb54:
  %t200 = load i64, ptr %l18, !tbaa !24
  %t202 = icmp sgt i64 %t200, 0
  br i1 %t202, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb59
bb56:
  %t204 = load i64, ptr %l17, !tbaa !24
  %t205 = load i64, ptr %l16, !tbaa !24
  %t208 = sub i64 %t204, %t205
  %t209 = load i64, ptr %l18, !tbaa !24
  %t212 = add i64 %t208, %t209
  %t214 = sub i64 %t212, 1
  %t215 = load i64, ptr %l18, !tbaa !24
  %t218 = sdiv i64 %t214, %t215
  store i64 %t218, ptr %l111, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb58
bb58:
  %t220 = load i64, ptr %l111, !tbaa !24
  store i64 %t220, ptr %l108, !tbaa !24
  br label %bb59
bb59:
  %t221 = load i64, ptr %l108, !tbaa !24
  store i64 %t221, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t222 = load i64, ptr %l20, !tbaa !24
  %t223 = load i64, ptr %l19, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb74
bb62:
  br label %bb63
bb63:
  %t230 = load i64, ptr %l16, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t232 = load i64, ptr %l18, !tbaa !24
  %t235 = mul i64 %t231, %t232
  %t238 = add i64 %t230, %t235
  store i64 %t238, ptr %l21, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t241, ptr %l130, !tbaa !27
  %t242 = load i64, ptr %l21, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t251 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t240, ptr %t247)
  store i32 %t251, ptr %l134
  br label %bb64
bb64:
  %t252 = load i32, ptr %l134, !tbaa !23
  store i32 %t252, ptr %l22, !tbaa !23
  %t253 = load i32, ptr %l22, !tbaa !23
  %t254 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t257 = icmp eq i32 %t253, %t254
  br i1 %t257, label %bb65, label %bb66
bb65:
  %t259 = icmp sge i64 0, 0
  br i1 %t259, label %bb67, label %bb68
bb66:
  br label %bb71
bb67:
  %t261 = icmp sle i64 0, 2305843009213693951
  br i1 %t261, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb69:
  %t263 = mul i64 0, 4
  %t264 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t263)
  %t265 = insertvalue { i64, ptr } undef, i64 0, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t266, ptr %rv
  br label %ret
bb70:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb71:
  %t268 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t268, ptr %l141, !tbaa !27
  %t269 = load i64, ptr %l21, !tbaa !24
  %t272 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t269)
  store i64 %t272, ptr %l144
  br label %bb72
bb72:
  %t273 = load i32, ptr %l22, !tbaa !23
  %t275 = load i64, ptr %l144, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr i32, ptr %t277, i64 %t275
  store i32 %t273, ptr %t278, !tbaa !33
  call void @__olang_scope_close(ptr %s10)
  br label %bb73
bb73:
  %t279 = load i64, ptr %l20, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l20, !tbaa !24
  br label %bb60
bb74:
  %t283 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca %"compiler/source:Span"
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca %"compiler/source:Span"
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca %"compiler/source:Span"
  %l70 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca ptr
  %l75 = alloca %"compiler/source:Span"
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l92 = alloca i1
  %l94 = alloca ptr
  %l97 = alloca i64
  %l99 = alloca i64
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %l111 = alloca ptr
  %l113 = alloca %"compiler/source:Span"
  %l115 = alloca ptr
  %l119 = alloca %"compiler/check:litv"
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l127 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca i1
  %l150 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca i1
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l166 = alloca i1
  %l180 = alloca ptr
  %l184 = alloca ptr
  %l185 = alloca i1
  %l202 = alloca ptr
  %l209 = alloca ptr
  %l210 = alloca ptr
  %l211 = alloca i1
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca i1
  %l242 = alloca i64
  %l245 = alloca ptr
  %l246 = alloca %"compiler/source:Span"
  %l248 = alloca i32
  %l250 = alloca ptr
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l258 = alloca i1
  %l269 = alloca ptr
  %l270 = alloca %"compiler/source:Span"
  %l276 = alloca ptr
  %l278 = alloca ptr
  %l279 = alloca ptr
  %l280 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca ptr
  %l295 = alloca i1
  %l308 = alloca ptr
  %l309 = alloca ptr
  %l310 = alloca i1
  %l319 = alloca ptr
  %l320 = alloca %"compiler/source:Span"
  %l323 = alloca i32
  %l325 = alloca ptr
  %l326 = alloca ptr
  %l327 = alloca i1
  %l337 = alloca ptr
  %l338 = alloca ptr
  %l339 = alloca i1
  %l353 = alloca ptr
  %l354 = alloca ptr
  %l355 = alloca i1
  %l370 = alloca ptr
  %l371 = alloca ptr
  %l372 = alloca i1
  %l381 = alloca ptr
  %l382 = alloca ptr
  %l384 = alloca %"compiler/source:Span"
  %l385 = alloca %"compiler/source:Span"
  %l387 = alloca { i64, ptr }
  %l390 = alloca %"compiler/msgs:Msg"
  %l391 = alloca i64
  %l394 = alloca ptr
  %l395 = alloca ptr
  %l396 = alloca i1
  %l412 = alloca ptr
  %l413 = alloca ptr
  %l414 = alloca i1
  %l427 = alloca ptr
  %l428 = alloca ptr
  %l429 = alloca i1
  %l440 = alloca ptr
  %l441 = alloca ptr
  %l443 = alloca %"compiler/source:Span"
  %l445 = alloca %"compiler/source:Span"
  %l446 = alloca %"compiler/source:Span"
  %l448 = alloca { i64, ptr }
  %l449 = alloca %"compiler/msgs:Msg"
  %l450 = alloca i64
  %l454 = alloca ptr
  %l455 = alloca ptr
  %l456 = alloca i1
  %l472 = alloca ptr
  %l473 = alloca ptr
  %l474 = alloca i1
  %l483 = alloca ptr
  %l484 = alloca %"compiler/source:Span"
  %l489 = alloca ptr
  %l490 = alloca ptr
  %l491 = alloca ptr
  %l492 = alloca i1
  %l502 = alloca ptr
  %l503 = alloca ptr
  %l504 = alloca i1
  %l515 = alloca ptr
  %l516 = alloca ptr
  %l517 = alloca i1
  %l527 = alloca ptr
  %l528 = alloca ptr
  %l529 = alloca i1
  %l540 = alloca ptr
  %l541 = alloca ptr
  %l542 = alloca i1
  %l553 = alloca i64
  %l555 = alloca ptr
  %l558 = alloca i64
  %l561 = alloca { i64, ptr }
  %l567 = alloca ptr
  %l568 = alloca ptr
  %l569 = alloca %"compiler/source:Span"
  %l572 = alloca i64
  %l574 = alloca ptr
  %l575 = alloca ptr
  %l577 = alloca %"compiler/source:Span"
  %l579 = alloca { i64, ptr }
  %l580 = alloca ptr
  %l582 = alloca %"compiler/source:Span"
  %l583 = alloca ptr
  %s1 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l83, !tbaa !29
  %t6 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 0, i32 0)
  store %"compiler/source:Span" %t6, ptr %l84
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l83, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l84
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t7, %"compiler/source:Span" %t8)
  store ptr %t9, ptr %l85
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  %t10 = load ptr, ptr %l85, !tbaa !29
  store ptr %t10, ptr %rv
  br label %ret
bb5:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l87
  br label %bb6
bb6:
  %t14 = load ptr, ptr %l87, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 47
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr @G_2ecompiler_2fcheck_2eCtEns, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l94
  br label %bb9
bb8:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l94, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 49
  %t30 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l97
  br label %bb10
bb10:
  %t31 = load i64, ptr %l97, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  store i1 %t32, ptr %l92, !tbaa !21
  br label %bb11
bb11:
  %t34 = load i1, ptr %l92, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t35)
  store ptr %t37, ptr %l101
  br label %bb14
bb13:
  br label %bb26
bb14:
  %t38 = load ptr, ptr %l101, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 49
  store ptr %t40, ptr %l103, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t41)
  store %"compiler/source:Span" %t43, ptr %l105
  br label %bb15
bb15:
  %t44 = load %"compiler/source:Span", ptr %l105
  %t45 = call i64 @compiler_2fcheck_2ectKey(%"compiler/source:Span" %t44)
  store i64 %t45, ptr %l106
  br label %bb16
bb16:
  %t46 = load ptr, ptr %l103, !tbaa !29
  %t47 = load i64, ptr %l106, !tbaa !24
  %t48 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t46, i64 %t47)
  %t49 = extractvalue { i32, i64 } %t48, 1
  %t50 = extractvalue { i32, i64 } %t48, 0
  store i32 %t50, ptr %l108
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb18, label %ok.52
ok.52:
  store i64 %t49, ptr %l107
  br label %bb17
bb17:
  %t53 = load i64, ptr %l107, !tbaa !24
  store i64 %t53, ptr %l99, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb20
bb20:
  %t54 = load i64, ptr %l99, !tbaa !24
  store i64 %t54, ptr %l3, !tbaa !24
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l111, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l113
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load ptr, ptr %l111, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l113
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t64, %"compiler/source:Span" %t65, i64 %t63)
  store ptr %t67, ptr %l115
  br label %bb24
bb24:
  %t68 = load ptr, ptr %l115, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l119
  br label %bb27
bb27:
  %t75 = load %"compiler/check:litv", ptr %l119
  store %"compiler/check:litv" %t75, ptr %l4
  %t76 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t77 = load i1, ptr %t76, !tbaa !21
  br i1 %t77, label %bb28, label %bb29
bb28:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load %"compiler/check:litv", ptr %l4
  %t82 = load i32, ptr %l2, !tbaa !23
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %t79, ptr %t80, %"compiler/check:litv" %t81, i32 %t82)
  store ptr %t87, ptr %l125
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t88 = load ptr, ptr %l125, !tbaa !29
  store ptr %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t90 = load ptr, ptr %l126, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l126, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 1
  store i1 %t96, ptr %l127, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l127, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32 }, ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/source:Span", ptr %t101
  store %"compiler/source:Span" %t102, ptr %l5
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l6
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l5
  %t112 = load i32, ptr %l6
  %t113 = load i32, ptr %l2, !tbaa !23
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteral(ptr %v0, ptr %t110, %"compiler/source:Span" %t111, i32 %t112, i32 %t113)
  store ptr %t118, ptr %l138
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l138, !tbaa !29
  store ptr %t119, ptr %rv
  br label %ret
bb38:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t121 = load ptr, ptr %l139, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb39, label %bb40
bb39:
  %t124 = load ptr, ptr %l139, !tbaa !29
  %t125 = load i64, ptr %t124
  %t127 = icmp eq i64 %t125, 0
  store i1 %t127, ptr %l140, !tbaa !21
  br label %bb40
bb40:
  %t128 = load i1, ptr %l140, !tbaa !21
  br i1 %t128, label %bb41, label %bb42
bb41:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [5 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32 }, ptr %t131, i32 0, i32 0
  %t133 = load %"compiler/source:Span", ptr %t132
  store %"compiler/source:Span" %t133, ptr %l7
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32 }, ptr %t137, i32 0, i32 1
  %t139 = load i32, ptr %t138
  store i32 %t139, ptr %l8, !tbaa !23
  br label %bb43
bb42:
  br label %bb48
bb43:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l7
  %t143 = load i32, ptr %l8, !tbaa !23
  %t147 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %t141, %"compiler/source:Span" %t142, i32 %t143)
  store ptr %t147, ptr %l150
  br label %bb44
bb44:
  %t148 = load ptr, ptr %l150, !tbaa !29
  store ptr %t148, ptr %l9, !tbaa !29
  %t149 = load ptr, ptr %l9, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_edce07484728b5af_b35724a5016b0523)
  unreachable
bb46:
  br label %bb47
bb47:
  %t153 = load ptr, ptr %l9, !tbaa !29
  store ptr %t153, ptr %rv
  br label %ret
bb48:
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t156 = load ptr, ptr %l154, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb49, label %bb50
bb49:
  %t159 = load ptr, ptr %l154, !tbaa !29
  %t160 = load i64, ptr %t159
  %t162 = icmp eq i64 %t160, 2
  store i1 %t162, ptr %l155, !tbaa !21
  br label %bb50
bb50:
  %t163 = load i1, ptr %l155, !tbaa !21
  br i1 %t163, label %bb51, label %bb52
bb51:
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", ptr }, ptr %t166, i32 0, i32 1
  %t168 = load ptr, ptr %t167
  store ptr %t168, ptr %l10, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l10, !tbaa !29
  %t173 = load i32, ptr %l2, !tbaa !23
  %t177 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t170, ptr %t171, i32 %t173)
  store ptr %t177, ptr %l164
  br label %bb54
bb54:
  %t178 = load ptr, ptr %l164, !tbaa !29
  store ptr %t178, ptr %rv
  br label %ret
bb55:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t180 = load ptr, ptr %l165, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb56, label %bb57
bb56:
  %t183 = load ptr, ptr %l165, !tbaa !29
  %t184 = load i64, ptr %t183
  %t186 = icmp eq i64 %t184, 3
  store i1 %t186, ptr %l166, !tbaa !21
  br label %bb57
bb57:
  %t187 = load i1, ptr %l166, !tbaa !21
  br i1 %t187, label %bb58, label %bb59
bb58:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t190, i32 0, i32 0
  %t192 = load %"compiler/source:Span", ptr %t191
  store %"compiler/source:Span" %t192, ptr %l11
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t196, i32 0, i32 1
  %t198 = load i32, ptr %t197
  store i32 %t198, ptr %l12
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l13, !tbaa !29
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load %"compiler/source:Span", ptr %l11
  %t208 = load i32, ptr %l12
  %t209 = load ptr, ptr %l13, !tbaa !29
  %t210 = load i32, ptr %l2, !tbaa !23
  %t216 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %t206, %"compiler/source:Span" %t207, i32 %t208, ptr %t209, i32 %t210)
  store ptr %t216, ptr %l180
  br label %bb61
bb61:
  %t217 = load ptr, ptr %l180, !tbaa !29
  store ptr %t217, ptr %l14, !tbaa !29
  %t218 = load ptr, ptr %l14, !tbaa !29
  %t220 = icmp eq ptr %t218, null
  br i1 %t220, label %bb62, label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_1cb65e67365b7050_f7614dad1dc2ba14)
  unreachable
bb63:
  br label %bb64
bb64:
  %t222 = load ptr, ptr %l14, !tbaa !29
  store ptr %t222, ptr %rv
  br label %ret
bb65:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t225 = load ptr, ptr %l184, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb66, label %bb67
bb66:
  %t228 = load ptr, ptr %l184, !tbaa !29
  %t229 = load i64, ptr %t228
  %t231 = icmp eq i64 %t229, 5
  store i1 %t231, ptr %l185, !tbaa !21
  br label %bb67
bb67:
  %t232 = load i1, ptr %l185, !tbaa !21
  br i1 %t232, label %bb68, label %bb69
bb68:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t235, i32 0, i32 0
  %t237 = load %"compiler/source:Span", ptr %t236
  store %"compiler/source:Span" %t237, ptr %l15
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t241, i32 0, i32 1
  %t243 = load i32, ptr %t242
  store i32 %t243, ptr %l16
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l17, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t253, i32 0, i32 3
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l18, !tbaa !29
  br label %bb70
bb69:
  br label %bb76
bb70:
  %t257 = load i32, ptr %l16
  %t259 = trunc i64 25 to i32
  %t260 = icmp eq i32 %t257, %t259
  br i1 %t260, label %bb71, label %bb72
bb71:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l15
  %t264 = load ptr, ptr %l17, !tbaa !29
  %t265 = load ptr, ptr %l18, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v1, ptr %t262, %"compiler/source:Span" %t263, ptr %t264, ptr %t265)
  store ptr %t270, ptr %l202
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t271 = load ptr, ptr %l202, !tbaa !29
  store ptr %t271, ptr %rv
  br label %ret
bb74:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load %"compiler/source:Span", ptr %l15
  %t274 = load i32, ptr %l16
  %t275 = load ptr, ptr %l17, !tbaa !29
  %t276 = load ptr, ptr %l18, !tbaa !29
  %t277 = load i32, ptr %l2, !tbaa !23
  %t284 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %t272, %"compiler/source:Span" %t273, i32 %t274, ptr %t275, ptr %t276, i32 %t277)
  store ptr %t284, ptr %l209
  br label %bb75
bb75:
  %t285 = load ptr, ptr %l209, !tbaa !29
  store ptr %t285, ptr %rv
  br label %ret
bb76:
  %t286 = load ptr, ptr %l1, !tbaa !29
  store ptr %t286, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t287 = load ptr, ptr %l210, !tbaa !29
  %t288 = icmp ne ptr %t287, null
  br i1 %t288, label %bb77, label %bb78
bb77:
  %t290 = load ptr, ptr %l210, !tbaa !29
  %t291 = load i64, ptr %t290
  %t293 = icmp eq i64 %t291, 8
  store i1 %t293, ptr %l211, !tbaa !21
  br label %bb78
bb78:
  %t294 = load i1, ptr %l211, !tbaa !21
  br i1 %t294, label %bb79, label %bb80
bb79:
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t295, i32 0, i32 1
  %t298 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t297, i32 0, i32 0
  %t299 = load %"compiler/source:Span", ptr %t298
  store %"compiler/source:Span" %t299, ptr %l19
  %t301 = load ptr, ptr %l1, !tbaa !29
  %t303 = getelementptr { i64, [5 x i64] }, ptr %t301, i32 0, i32 1
  %t304 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t303, i32 0, i32 1
  %t305 = load ptr, ptr %t304
  store ptr %t305, ptr %l20, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr { i64, [5 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t309, i32 0, i32 2
  %t311 = load ptr, ptr %t310
  store ptr %t311, ptr %l21, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t315, i32 0, i32 3
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l22, !tbaa !29
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load %"compiler/source:Span", ptr %l19
  %t321 = load ptr, ptr %l20, !tbaa !29
  %t322 = load ptr, ptr %l21, !tbaa !29
  %t323 = load ptr, ptr %l22, !tbaa !29
  %t324 = load i32, ptr %l2, !tbaa !23
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t319, %"compiler/source:Span" %t320, ptr %t321, ptr %t322, ptr %t323, i32 %t324)
  store ptr %t331, ptr %l228
  br label %bb82
bb82:
  %t332 = load ptr, ptr %l228, !tbaa !29
  store ptr %t332, ptr %rv
  br label %ret
bb83:
  %t333 = load ptr, ptr %l1, !tbaa !29
  store ptr %t333, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t334 = load ptr, ptr %l229, !tbaa !29
  %t335 = icmp ne ptr %t334, null
  br i1 %t335, label %bb84, label %bb85
bb84:
  %t337 = load ptr, ptr %l229, !tbaa !29
  %t338 = load i64, ptr %t337
  %t340 = icmp eq i64 %t338, 12
  store i1 %t340, ptr %l230, !tbaa !21
  br label %bb85
bb85:
  %t341 = load i1, ptr %l230, !tbaa !21
  br i1 %t341, label %bb86, label %bb87
bb86:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t344 = getelementptr { i64, [5 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t344, i32 0, i32 0
  %t346 = load %"compiler/source:Span", ptr %t345
  store %"compiler/source:Span" %t346, ptr %l23
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l24, !tbaa !29
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t356, i32 0, i32 2
  %t358 = load { i64, ptr }, ptr %t357
  store { i64, ptr } %t358, ptr %l25, !tbaa !27
  br label %bb88
bb87:
  br label %bb96
bb88:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l24, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t366 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v1, ptr %t360, ptr %t361, { i64, ptr } %t362)
  store i64 %t366, ptr %l242
  br label %bb89
bb89:
  %t367 = load i64, ptr %l242, !tbaa !24
  store i64 %t367, ptr %l26, !tbaa !24
  %t368 = load i64, ptr %l26, !tbaa !24
  %t370 = icmp sge i64 %t368, 0
  br i1 %t370, label %bb90, label %bb91
bb90:
  %t372 = load ptr, ptr %l0, !tbaa !29
  store ptr %t372, ptr %l245, !tbaa !29
  %t373 = load %"compiler/source:Span", ptr %l23
  store %"compiler/source:Span" %t373, ptr %l246
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t374)
  store i32 %t376, ptr %l248
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t377 = load i64, ptr %l26, !tbaa !24
  %t378 = load ptr, ptr %l245, !tbaa !29
  %t379 = load %"compiler/source:Span", ptr %l246
  %t380 = load i32, ptr %l248, !tbaa !23
  %t382 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t378, %"compiler/source:Span" %t379, i32 %t380, i64 %t377)
  store ptr %t382, ptr %l250
  br label %bb93
bb93:
  %t383 = load ptr, ptr %l250, !tbaa !29
  store ptr %t383, ptr %rv
  br label %ret
bb94:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l23
  %t386 = load ptr, ptr %l24, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t388 = load i32, ptr %l2, !tbaa !23
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall(ptr %v0, ptr %v1, ptr %v1, ptr %t384, %"compiler/source:Span" %t385, ptr %t386, { i64, ptr } %t387, i32 %t388)
  store ptr %t394, ptr %l256
  br label %bb95
bb95:
  %t395 = load ptr, ptr %l256, !tbaa !29
  store ptr %t395, ptr %rv
  br label %ret
bb96:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l257, !tbaa !29
  store i1 false, ptr %l258, !tbaa !21
  %t397 = load ptr, ptr %l257, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb97, label %bb98
bb97:
  %t400 = load ptr, ptr %l257, !tbaa !29
  %t401 = load i64, ptr %t400
  %t403 = icmp eq i64 %t401, 13
  store i1 %t403, ptr %l258, !tbaa !21
  br label %bb98
bb98:
  %t404 = load i1, ptr %l258, !tbaa !21
  br i1 %t404, label %bb99, label %bb100
bb99:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [5 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t407, i32 0, i32 0
  %t409 = load %"compiler/source:Span", ptr %t408
  store %"compiler/source:Span" %t409, ptr %l27
  %t411 = load ptr, ptr %l1, !tbaa !29
  %t413 = getelementptr { i64, [5 x i64] }, ptr %t411, i32 0, i32 1
  %t414 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t413, i32 0, i32 1
  %t415 = load ptr, ptr %t414
  store ptr %t415, ptr %l28, !tbaa !29
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [5 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t419, i32 0, i32 2
  %t421 = load i32, ptr %t420
  store i32 %t421, ptr %l29, !tbaa !23
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr { i64, [5 x i64] }, ptr %t423, i32 0, i32 1
  %t426 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t425, i32 0, i32 3
  %t427 = load { i64, ptr }, ptr %t426
  store { i64, ptr } %t427, ptr %l30, !tbaa !27
  br label %bb101
bb100:
  br label %bb104
bb101:
  %t429 = load ptr, ptr %l0, !tbaa !29
  store ptr %t429, ptr %l269, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t430, ptr %l270
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load %"compiler/source:Span", ptr %l27
  %t433 = load ptr, ptr %l28, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t435 = load i32, ptr %l2, !tbaa !23
  %t441 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall(ptr %v0, ptr %v1, ptr %v1, ptr %t431, %"compiler/source:Span" %t432, ptr %t433, { i64, ptr } %t434, i32 %t435)
  store ptr %t441, ptr %l276
  br label %bb102
bb102:
  %t442 = load i32, ptr %l29, !tbaa !23
  %t443 = load ptr, ptr %l269, !tbaa !29
  %t444 = load %"compiler/source:Span", ptr %l270
  %t445 = load ptr, ptr %l276, !tbaa !29
  %t447 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escoped(ptr %v0, ptr %t443, %"compiler/source:Span" %t444, ptr %t445, i32 %t442)
  store ptr %t447, ptr %l278
  br label %bb103
bb103:
  %t448 = load ptr, ptr %l278, !tbaa !29
  store ptr %t448, ptr %rv
  br label %ret
bb104:
  %t449 = load ptr, ptr %l1, !tbaa !29
  store ptr %t449, ptr %l279, !tbaa !29
  store i1 false, ptr %l280, !tbaa !21
  %t450 = load ptr, ptr %l279, !tbaa !29
  %t451 = icmp ne ptr %t450, null
  br i1 %t451, label %bb105, label %bb106
bb105:
  %t453 = load ptr, ptr %l279, !tbaa !29
  %t454 = load i64, ptr %t453
  %t456 = icmp eq i64 %t454, 15
  store i1 %t456, ptr %l280, !tbaa !21
  br label %bb106
bb106:
  %t457 = load i1, ptr %l280, !tbaa !21
  br i1 %t457, label %bb107, label %bb108
bb107:
  %t458 = load ptr, ptr %l1, !tbaa !29
  %t460 = getelementptr { i64, [5 x i64] }, ptr %t458, i32 0, i32 1
  %t461 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t460, i32 0, i32 0
  %t462 = load %"compiler/source:Span", ptr %t461
  store %"compiler/source:Span" %t462, ptr %l31
  %t464 = load ptr, ptr %l1, !tbaa !29
  %t466 = getelementptr { i64, [5 x i64] }, ptr %t464, i32 0, i32 1
  %t467 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t466, i32 0, i32 1
  %t468 = load ptr, ptr %t467
  store ptr %t468, ptr %l32, !tbaa !29
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  %t473 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t472, i32 0, i32 2
  %t474 = load i32, ptr %t473
  store i32 %t474, ptr %l33, !tbaa !23
  br label %bb109
bb108:
  br label %bb111
bb109:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t477 = load %"compiler/source:Span", ptr %l31
  %t478 = load ptr, ptr %l32, !tbaa !29
  %t479 = load i32, ptr %l33, !tbaa !23
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emember(ptr %v0, ptr %v1, ptr %t476, %"compiler/source:Span" %t477, ptr %t478, i32 %t479)
  store ptr %t484, ptr %l293
  br label %bb110
bb110:
  %t485 = load ptr, ptr %l293, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb111:
  %t486 = load ptr, ptr %l1, !tbaa !29
  store ptr %t486, ptr %l294, !tbaa !29
  store i1 false, ptr %l295, !tbaa !21
  %t487 = load ptr, ptr %l294, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb112, label %bb113
bb112:
  %t490 = load ptr, ptr %l294, !tbaa !29
  %t491 = load i64, ptr %t490
  %t493 = icmp eq i64 %t491, 16
  store i1 %t493, ptr %l295, !tbaa !21
  br label %bb113
bb113:
  %t494 = load i1, ptr %l295, !tbaa !21
  br i1 %t494, label %bb114, label %bb115
bb114:
  %t495 = load ptr, ptr %l1, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t497, i32 0, i32 0
  %t499 = load %"compiler/source:Span", ptr %t498
  store %"compiler/source:Span" %t499, ptr %l34
  %t501 = load ptr, ptr %l1, !tbaa !29
  %t503 = getelementptr { i64, [5 x i64] }, ptr %t501, i32 0, i32 1
  %t504 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t503, i32 0, i32 1
  %t505 = load ptr, ptr %t504
  store ptr %t505, ptr %l35, !tbaa !29
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t509, i32 0, i32 2
  %t511 = load { i64, ptr }, ptr %t510
  store { i64, ptr } %t511, ptr %l36, !tbaa !27
  br label %bb116
bb115:
  br label %bb118
bb116:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t514 = load %"compiler/source:Span", ptr %l34
  %t515 = load ptr, ptr %l35, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t521 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindex(ptr %v0, ptr %v1, ptr %v1, ptr %t513, %"compiler/source:Span" %t514, ptr %t515, { i64, ptr } %t516)
  store ptr %t521, ptr %l308
  br label %bb117
bb117:
  %t522 = load ptr, ptr %l308, !tbaa !29
  store ptr %t522, ptr %rv
  br label %ret
bb118:
  %t523 = load ptr, ptr %l1, !tbaa !29
  store ptr %t523, ptr %l309, !tbaa !29
  store i1 false, ptr %l310, !tbaa !21
  %t524 = load ptr, ptr %l309, !tbaa !29
  %t525 = icmp ne ptr %t524, null
  br i1 %t525, label %bb119, label %bb120
bb119:
  %t527 = load ptr, ptr %l309, !tbaa !29
  %t528 = load i64, ptr %t527
  %t530 = icmp eq i64 %t528, 18
  store i1 %t530, ptr %l310, !tbaa !21
  br label %bb120
bb120:
  %t531 = load i1, ptr %l310, !tbaa !21
  br i1 %t531, label %bb121, label %bb122
bb121:
  %t532 = load ptr, ptr %l1, !tbaa !29
  %t534 = getelementptr { i64, [5 x i64] }, ptr %t532, i32 0, i32 1
  %t535 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t534, i32 0, i32 0
  %t536 = load %"compiler/source:Span", ptr %t535
  store %"compiler/source:Span" %t536, ptr %l37
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr { i64, [5 x i64] }, ptr %t538, i32 0, i32 1
  %t541 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t540, i32 0, i32 1
  %t542 = load ptr, ptr %t541
  store ptr %t542, ptr %l38, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr { i64, [5 x i64] }, ptr %t544, i32 0, i32 1
  %t547 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t546, i32 0, i32 2
  %t548 = load { i64, ptr }, ptr %t547
  store { i64, ptr } %t548, ptr %l39, !tbaa !27
  br label %bb123
bb122:
  br label %bb126
bb123:
  %t550 = load ptr, ptr %l0, !tbaa !29
  store ptr %t550, ptr %l319, !tbaa !29
  %t551 = load %"compiler/source:Span", ptr %l37
  store %"compiler/source:Span" %t551, ptr %l320
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t553 = load ptr, ptr %l38, !tbaa !29
  %t556 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t552, ptr %t553)
  store i32 %t556, ptr %l323
  br label %bb124
bb124:
  %t557 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t558 = load ptr, ptr %l319, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l320
  %t560 = load i32, ptr %l323, !tbaa !23
  %t562 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %t558, %"compiler/source:Span" %t559, i32 %t560, { i64, ptr } %t557)
  store ptr %t562, ptr %l325
  br label %bb125
bb125:
  %t563 = load ptr, ptr %l325, !tbaa !29
  store ptr %t563, ptr %rv
  br label %ret
bb126:
  %t564 = load ptr, ptr %l1, !tbaa !29
  store ptr %t564, ptr %l326, !tbaa !29
  store i1 false, ptr %l327, !tbaa !21
  %t565 = load ptr, ptr %l326, !tbaa !29
  %t566 = icmp ne ptr %t565, null
  br i1 %t566, label %bb127, label %bb128
bb127:
  %t568 = load ptr, ptr %l326, !tbaa !29
  %t569 = load i64, ptr %t568
  %t571 = icmp eq i64 %t569, 21
  store i1 %t571, ptr %l327, !tbaa !21
  br label %bb128
bb128:
  %t572 = load i1, ptr %l327, !tbaa !21
  br i1 %t572, label %bb129, label %bb130
bb129:
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t575 = getelementptr { i64, [5 x i64] }, ptr %t573, i32 0, i32 1
  %t576 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t575, i32 0, i32 0
  %t577 = load %"compiler/source:Span", ptr %t576
  store %"compiler/source:Span" %t577, ptr %l40
  %t579 = load ptr, ptr %l1, !tbaa !29
  %t581 = getelementptr { i64, [5 x i64] }, ptr %t579, i32 0, i32 1
  %t582 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t581, i32 0, i32 1
  %t583 = load { i64, ptr }, ptr %t582
  store { i64, ptr } %t583, ptr %l41, !tbaa !27
  br label %bb131
bb130:
  br label %bb133
bb131:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load %"compiler/source:Span", ptr %l40
  %t587 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t591 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoin(ptr %v0, ptr %v1, ptr %t585, %"compiler/source:Span" %t586, { i64, ptr } %t587)
  store ptr %t591, ptr %l337
  br label %bb132
bb132:
  %t592 = load ptr, ptr %l337, !tbaa !29
  store ptr %t592, ptr %rv
  br label %ret
bb133:
  %t593 = load ptr, ptr %l1, !tbaa !29
  store ptr %t593, ptr %l338, !tbaa !29
  store i1 false, ptr %l339, !tbaa !21
  %t594 = load ptr, ptr %l338, !tbaa !29
  %t595 = icmp ne ptr %t594, null
  br i1 %t595, label %bb134, label %bb135
bb134:
  %t597 = load ptr, ptr %l338, !tbaa !29
  %t598 = load i64, ptr %t597
  %t600 = icmp eq i64 %t598, 22
  store i1 %t600, ptr %l339, !tbaa !21
  br label %bb135
bb135:
  %t601 = load i1, ptr %l339, !tbaa !21
  br i1 %t601, label %bb136, label %bb137
bb136:
  %t602 = load ptr, ptr %l1, !tbaa !29
  %t604 = getelementptr { i64, [5 x i64] }, ptr %t602, i32 0, i32 1
  %t605 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t604, i32 0, i32 0
  %t606 = load %"compiler/source:Span", ptr %t605
  store %"compiler/source:Span" %t606, ptr %l42
  %t608 = load ptr, ptr %l1, !tbaa !29
  %t610 = getelementptr { i64, [5 x i64] }, ptr %t608, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t610, i32 0, i32 1
  %t612 = load ptr, ptr %t611
  store ptr %t612, ptr %l43, !tbaa !29
  %t614 = load ptr, ptr %l1, !tbaa !29
  %t616 = getelementptr { i64, [5 x i64] }, ptr %t614, i32 0, i32 1
  %t617 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t616, i32 0, i32 2
  %t618 = load { i64, ptr }, ptr %t617
  store { i64, ptr } %t618, ptr %l44, !tbaa !27
  br label %bb138
bb137:
  br label %bb140
bb138:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t621 = load %"compiler/source:Span", ptr %l42
  %t622 = load ptr, ptr %l43, !tbaa !29
  %t623 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t624 = load i32, ptr %l2, !tbaa !23
  %t630 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryExpr(ptr %v0, ptr %v1, ptr %v1, ptr %t620, %"compiler/source:Span" %t621, ptr %t622, { i64, ptr } %t623, i32 %t624)
  store ptr %t630, ptr %l353
  br label %bb139
bb139:
  %t631 = load ptr, ptr %l353, !tbaa !29
  store ptr %t631, ptr %rv
  br label %ret
bb140:
  %t632 = load ptr, ptr %l1, !tbaa !29
  store ptr %t632, ptr %l354, !tbaa !29
  store i1 false, ptr %l355, !tbaa !21
  %t633 = load ptr, ptr %l354, !tbaa !29
  %t634 = icmp ne ptr %t633, null
  br i1 %t634, label %bb141, label %bb142
bb141:
  %t636 = load ptr, ptr %l354, !tbaa !29
  %t637 = load i64, ptr %t636
  %t639 = icmp eq i64 %t637, 4
  store i1 %t639, ptr %l355, !tbaa !21
  br label %bb142
bb142:
  %t640 = load i1, ptr %l355, !tbaa !21
  br i1 %t640, label %bb143, label %bb144
bb143:
  %t641 = load ptr, ptr %l1, !tbaa !29
  %t643 = getelementptr { i64, [5 x i64] }, ptr %t641, i32 0, i32 1
  %t644 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t643, i32 0, i32 0
  %t645 = load %"compiler/source:Span", ptr %t644
  store %"compiler/source:Span" %t645, ptr %l45
  %t647 = load ptr, ptr %l1, !tbaa !29
  %t649 = getelementptr { i64, [5 x i64] }, ptr %t647, i32 0, i32 1
  %t650 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t649, i32 0, i32 1
  %t651 = load i32, ptr %t650
  store i32 %t651, ptr %l46
  %t653 = load ptr, ptr %l1, !tbaa !29
  %t655 = getelementptr { i64, [5 x i64] }, ptr %t653, i32 0, i32 1
  %t656 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t655, i32 0, i32 2
  %t657 = load ptr, ptr %t656
  store ptr %t657, ptr %l47, !tbaa !29
  br label %bb145
bb144:
  br label %bb149
bb145:
  %t659 = load i32, ptr %l46
  %t661 = trunc i64 75 to i32
  %t662 = icmp eq i32 %t659, %t661
  br i1 %t662, label %bb146, label %bb147
bb146:
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t665 = load %"compiler/source:Span", ptr %l45
  %t666 = load ptr, ptr %l47, !tbaa !29
  %t667 = load i32, ptr %l2, !tbaa !23
  %t672 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebang(ptr %v0, ptr %v1, ptr %t664, %"compiler/source:Span" %t665, ptr %t666, i32 %t667)
  store ptr %t672, ptr %l370
  br label %bb148
bb147:
  br label %bb149
bb148:
  %t673 = load ptr, ptr %l370, !tbaa !29
  store ptr %t673, ptr %rv
  br label %ret
bb149:
  %t674 = load ptr, ptr %l1, !tbaa !29
  store ptr %t674, ptr %l371, !tbaa !29
  store i1 false, ptr %l372, !tbaa !21
  %t675 = load ptr, ptr %l371, !tbaa !29
  %t676 = icmp ne ptr %t675, null
  br i1 %t676, label %bb150, label %bb151
bb150:
  %t678 = load ptr, ptr %l371, !tbaa !29
  %t679 = load i64, ptr %t678
  %t681 = icmp eq i64 %t679, 4
  store i1 %t681, ptr %l372, !tbaa !21
  br label %bb151
bb151:
  %t682 = load i1, ptr %l372, !tbaa !21
  br i1 %t682, label %bb152, label %bb153
bb152:
  %t683 = load ptr, ptr %l1, !tbaa !29
  %t685 = getelementptr { i64, [5 x i64] }, ptr %t683, i32 0, i32 1
  %t686 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t685, i32 0, i32 0
  %t687 = load %"compiler/source:Span", ptr %t686
  store %"compiler/source:Span" %t687, ptr %l48
  %t689 = load ptr, ptr %l1, !tbaa !29
  %t691 = getelementptr { i64, [5 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t691, i32 0, i32 1
  %t693 = load i32, ptr %t692
  store i32 %t693, ptr %l49
  %t695 = load ptr, ptr %l1, !tbaa !29
  %t697 = getelementptr { i64, [5 x i64] }, ptr %t695, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t697, i32 0, i32 2
  %t699 = load ptr, ptr %t698
  store ptr %t699, ptr %l50, !tbaa !29
  br label %bb154
bb153:
  br label %bb161
bb154:
  store %olang.scope zeroinitializer, ptr %s21
  %t701 = load ptr, ptr %l0, !tbaa !29
  store ptr %t701, ptr %l381, !tbaa !29
  %t702 = load ptr, ptr %l0, !tbaa !29
  store ptr %t702, ptr %l382, !tbaa !29
  %t703 = load ptr, ptr %l50, !tbaa !29
  %t705 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t703)
  store %"compiler/source:Span" %t705, ptr %l384
  br label %bb155
bb155:
  %t706 = load ptr, ptr %l382, !tbaa !29
  %t707 = load %"compiler/source:Span", ptr %l384
  %t708 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t706, %"compiler/source:Span" %t707, i64 2)
  store %"compiler/source:Span" %t708, ptr %l385
  br label %bb156
bb156:
  %t709 = load i32, ptr %l49
  %t711 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s21, i32 %t709)
  store { i64, ptr } %t711, ptr %l387
  br label %bb157
bb157:
  %t712 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 1
  %t713 = extractvalue { i64, ptr } { i64 1, ptr @.d9 }, 0
  %t714 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t715 = extractvalue { i64, ptr } %t714, 1
  %t716 = extractvalue { i64, ptr } %t714, 0
  %t717 = add i64 %t713, %t716
  %t718 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t719 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t720 = add i64 %t717, %t719
  %t721 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t720)
  call void @olang_textcopy(ptr %t721, ptr %t712, i64 %t713)
  %t722 = getelementptr i8, ptr %t721, i64 %t713
  call void @olang_textcopy(ptr %t722, ptr %t715, i64 %t716)
  %t723 = getelementptr i8, ptr %t722, i64 %t716
  call void @olang_textcopy(ptr %t723, ptr %t718, i64 %t719)
  %t724 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t721, 1
  %t727 = extractvalue { i64, ptr } %t725, 0
  %t728 = extractvalue { i64, ptr } %t725, 1
  %t729 = mul i64 %t727, 1
  %t730 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t729)
  call void @llvm.memcpy.p0.p0.i64(ptr %t730, ptr %t728, i64 %t729, i1 false)
  %t731 = insertvalue { i64, ptr } undef, i64 %t727, 0
  %t732 = insertvalue { i64, ptr } %t731, ptr %t730, 1
  %t734 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecInExpression(ptr %s21, ptr %s21, { i64, ptr } %t732)
  store %"compiler/msgs:Msg" %t734, ptr %l390
  br label %bb158
bb158:
  %t735 = load ptr, ptr %l381, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l385
  %t737 = load %"compiler/msgs:Msg", ptr %l390
  %t738 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t735, %"compiler/source:Span" %t736, %"compiler/msgs:Msg" %t737)
  store i64 %t738, ptr %l391
  br label %bb159
bb159:
  %t739 = load ptr, ptr %l0, !tbaa !29
  %t740 = load %"compiler/source:Span", ptr %l48
  %t743 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t739, %"compiler/source:Span" %t740)
  store ptr %t743, ptr %l394
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s21)
  %t744 = load ptr, ptr %l394, !tbaa !29
  store ptr %t744, ptr %rv
  br label %ret
bb161:
  %t745 = load ptr, ptr %l1, !tbaa !29
  store ptr %t745, ptr %l395, !tbaa !29
  store i1 false, ptr %l396, !tbaa !21
  %t746 = load ptr, ptr %l395, !tbaa !29
  %t747 = icmp ne ptr %t746, null
  br i1 %t747, label %bb162, label %bb163
bb162:
  %t749 = load ptr, ptr %l395, !tbaa !29
  %t750 = load i64, ptr %t749
  %t752 = icmp eq i64 %t750, 10
  store i1 %t752, ptr %l396, !tbaa !21
  br label %bb163
bb163:
  %t753 = load i1, ptr %l396, !tbaa !21
  br i1 %t753, label %bb164, label %bb165
bb164:
  %t754 = load ptr, ptr %l1, !tbaa !29
  %t756 = getelementptr { i64, [5 x i64] }, ptr %t754, i32 0, i32 1
  %t757 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t756, i32 0, i32 0
  %t758 = load %"compiler/source:Span", ptr %t757
  store %"compiler/source:Span" %t758, ptr %l51
  %t760 = load ptr, ptr %l1, !tbaa !29
  %t762 = getelementptr { i64, [5 x i64] }, ptr %t760, i32 0, i32 1
  %t763 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t762, i32 0, i32 1
  %t764 = load ptr, ptr %t763
  store ptr %t764, ptr %l52, !tbaa !29
  %t766 = load ptr, ptr %l1, !tbaa !29
  %t768 = getelementptr { i64, [5 x i64] }, ptr %t766, i32 0, i32 1
  %t769 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t768, i32 0, i32 2
  %t770 = load ptr, ptr %t769
  store ptr %t770, ptr %l53, !tbaa !29
  %t772 = load ptr, ptr %l1, !tbaa !29
  %t774 = getelementptr { i64, [5 x i64] }, ptr %t772, i32 0, i32 1
  %t775 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t774, i32 0, i32 3
  %t776 = load i1, ptr %t775
  store i1 %t776, ptr %l54, !tbaa !21
  br label %bb166
bb165:
  br label %bb168
bb166:
  %t778 = load ptr, ptr %l0, !tbaa !29
  %t779 = load %"compiler/source:Span", ptr %l51
  %t780 = load ptr, ptr %l52, !tbaa !29
  %t781 = load ptr, ptr %l53, !tbaa !29
  %t782 = load i1, ptr %l54, !tbaa !21
  %t788 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v1, ptr %t778, %"compiler/source:Span" %t779, ptr %t780, ptr %t781, i1 %t782)
  store ptr %t788, ptr %l412
  br label %bb167
bb167:
  %t789 = load ptr, ptr %l412, !tbaa !29
  store ptr %t789, ptr %rv
  br label %ret
bb168:
  %t790 = load ptr, ptr %l1, !tbaa !29
  store ptr %t790, ptr %l413, !tbaa !29
  store i1 false, ptr %l414, !tbaa !21
  %t791 = load ptr, ptr %l413, !tbaa !29
  %t792 = icmp ne ptr %t791, null
  br i1 %t792, label %bb169, label %bb170
bb169:
  %t794 = load ptr, ptr %l413, !tbaa !29
  %t795 = load i64, ptr %t794
  %t797 = icmp eq i64 %t795, 11
  store i1 %t797, ptr %l414, !tbaa !21
  br label %bb170
bb170:
  %t798 = load i1, ptr %l414, !tbaa !21
  br i1 %t798, label %bb171, label %bb172
bb171:
  %t799 = load ptr, ptr %l1, !tbaa !29
  %t801 = getelementptr { i64, [5 x i64] }, ptr %t799, i32 0, i32 1
  %t802 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t801, i32 0, i32 0
  %t803 = load %"compiler/source:Span", ptr %t802
  store %"compiler/source:Span" %t803, ptr %l55
  %t805 = load ptr, ptr %l1, !tbaa !29
  %t807 = getelementptr { i64, [5 x i64] }, ptr %t805, i32 0, i32 1
  %t808 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t807, i32 0, i32 1
  %t809 = load ptr, ptr %t808
  store ptr %t809, ptr %l56, !tbaa !29
  %t811 = load ptr, ptr %l1, !tbaa !29
  %t813 = getelementptr { i64, [5 x i64] }, ptr %t811, i32 0, i32 1
  %t814 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t813, i32 0, i32 2
  %t815 = load ptr, ptr %t814
  store ptr %t815, ptr %l57, !tbaa !29
  br label %bb173
bb172:
  br label %bb175
bb173:
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t818 = load %"compiler/source:Span", ptr %l55
  %t819 = load ptr, ptr %l56, !tbaa !29
  %t820 = load ptr, ptr %l57, !tbaa !29
  %t825 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easCase(ptr %v0, ptr %v1, ptr %v1, ptr %t817, %"compiler/source:Span" %t818, ptr %t819, ptr %t820)
  store ptr %t825, ptr %l427
  br label %bb174
bb174:
  %t826 = load ptr, ptr %l427, !tbaa !29
  store ptr %t826, ptr %rv
  br label %ret
bb175:
  %t827 = load ptr, ptr %l1, !tbaa !29
  store ptr %t827, ptr %l428, !tbaa !29
  store i1 false, ptr %l429, !tbaa !21
  %t828 = load ptr, ptr %l428, !tbaa !29
  %t829 = icmp ne ptr %t828, null
  br i1 %t829, label %bb176, label %bb177
bb176:
  %t831 = load ptr, ptr %l428, !tbaa !29
  %t832 = load i64, ptr %t831
  %t834 = icmp eq i64 %t832, 9
  store i1 %t834, ptr %l429, !tbaa !21
  br label %bb177
bb177:
  %t835 = load i1, ptr %l429, !tbaa !21
  br i1 %t835, label %bb178, label %bb179
bb178:
  %t836 = load ptr, ptr %l1, !tbaa !29
  %t838 = getelementptr { i64, [5 x i64] }, ptr %t836, i32 0, i32 1
  %t839 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t838, i32 0, i32 0
  %t840 = load %"compiler/source:Span", ptr %t839
  store %"compiler/source:Span" %t840, ptr %l58
  %t842 = load ptr, ptr %l1, !tbaa !29
  %t844 = getelementptr { i64, [5 x i64] }, ptr %t842, i32 0, i32 1
  %t845 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t844, i32 0, i32 1
  %t846 = load ptr, ptr %t845
  store ptr %t846, ptr %l59, !tbaa !29
  %t848 = load ptr, ptr %l1, !tbaa !29
  %t850 = getelementptr { i64, [5 x i64] }, ptr %t848, i32 0, i32 1
  %t851 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t850, i32 0, i32 2
  %t852 = load ptr, ptr %t851
  store ptr %t852, ptr %l60, !tbaa !29
  %t854 = load ptr, ptr %l1, !tbaa !29
  %t856 = getelementptr { i64, [5 x i64] }, ptr %t854, i32 0, i32 1
  %t857 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t856, i32 0, i32 3
  %t858 = load i1, ptr %t857
  store i1 %t858, ptr %l61, !tbaa !21
  br label %bb180
bb179:
  br label %bb190
bb180:
  store %olang.scope zeroinitializer, ptr %s25
  %t860 = load ptr, ptr %l0, !tbaa !29
  store ptr %t860, ptr %l440, !tbaa !29
  %t861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t861, ptr %l441, !tbaa !29
  %t862 = load ptr, ptr %l59, !tbaa !29
  %t864 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t862)
  store %"compiler/source:Span" %t864, ptr %l443
  br label %bb181
bb181:
  %t865 = load ptr, ptr %l60, !tbaa !29
  %t867 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t865)
  store %"compiler/source:Span" %t867, ptr %l445
  br label %bb182
bb182:
  %t868 = load ptr, ptr %l441, !tbaa !29
  %t869 = load %"compiler/source:Span", ptr %l443
  %t870 = load %"compiler/source:Span", ptr %l445
  %t871 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t868, %"compiler/source:Span" %t869, %"compiler/source:Span" %t870, i64 2)
  store %"compiler/source:Span" %t871, ptr %l446
  br label %bb183
bb183:
  %t872 = load i1, ptr %l61, !tbaa !21
  br i1 %t872, label %bb184, label %bb185
bb184:
  store { i64, ptr } { i64 2, ptr @.d11 }, ptr %l448, !tbaa !27
  br label %bb186
bb185:
  store { i64, ptr } { i64 2, ptr @.d12 }, ptr %l448, !tbaa !27
  br label %bb186
bb186:
  %t874 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t875 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %s25, ptr %s25, { i64, ptr } %t874)
  store %"compiler/msgs:Msg" %t875, ptr %l449
  br label %bb187
bb187:
  %t876 = load ptr, ptr %l440, !tbaa !29
  %t877 = load %"compiler/source:Span", ptr %l446
  %t878 = load %"compiler/msgs:Msg", ptr %l449
  %t879 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s25, ptr %t876, %"compiler/source:Span" %t877, %"compiler/msgs:Msg" %t878)
  store i64 %t879, ptr %l450
  br label %bb188
bb188:
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t881 = load %"compiler/source:Span", ptr %l58
  %t882 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t886 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t880, %"compiler/source:Span" %t881, i32 %t882, i64 0)
  store ptr %t886, ptr %l454
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s25)
  %t887 = load ptr, ptr %l454, !tbaa !29
  store ptr %t887, ptr %rv
  br label %ret
bb190:
  %t888 = load ptr, ptr %l1, !tbaa !29
  store ptr %t888, ptr %l455, !tbaa !29
  store i1 false, ptr %l456, !tbaa !21
  %t889 = load ptr, ptr %l455, !tbaa !29
  %t890 = icmp ne ptr %t889, null
  br i1 %t890, label %bb191, label %bb192
bb191:
  %t892 = load ptr, ptr %l455, !tbaa !29
  %t893 = load i64, ptr %t892
  %t895 = icmp eq i64 %t893, 17
  store i1 %t895, ptr %l456, !tbaa !21
  br label %bb192
bb192:
  %t896 = load i1, ptr %l456, !tbaa !21
  br i1 %t896, label %bb193, label %bb194
bb193:
  %t897 = load ptr, ptr %l1, !tbaa !29
  %t899 = getelementptr { i64, [5 x i64] }, ptr %t897, i32 0, i32 1
  %t900 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t899, i32 0, i32 0
  %t901 = load %"compiler/source:Span", ptr %t900
  store %"compiler/source:Span" %t901, ptr %l62
  %t903 = load ptr, ptr %l1, !tbaa !29
  %t905 = getelementptr { i64, [5 x i64] }, ptr %t903, i32 0, i32 1
  %t906 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t905, i32 0, i32 1
  %t907 = load ptr, ptr %t906
  store ptr %t907, ptr %l63, !tbaa !29
  %t909 = load ptr, ptr %l1, !tbaa !29
  %t911 = getelementptr { i64, [5 x i64] }, ptr %t909, i32 0, i32 1
  %t912 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t911, i32 0, i32 2
  %t913 = load ptr, ptr %t912
  store ptr %t913, ptr %l64, !tbaa !29
  %t915 = load ptr, ptr %l1, !tbaa !29
  %t917 = getelementptr { i64, [5 x i64] }, ptr %t915, i32 0, i32 1
  %t918 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t917, i32 0, i32 3
  %t919 = load ptr, ptr %t918
  store ptr %t919, ptr %l65, !tbaa !29
  br label %bb195
bb194:
  br label %bb197
bb195:
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l62
  %t923 = load ptr, ptr %l63, !tbaa !29
  %t924 = load ptr, ptr %l64, !tbaa !29
  %t925 = load ptr, ptr %l65, !tbaa !29
  %t931 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslice(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t921, %"compiler/source:Span" %t922, ptr %t923, ptr %t924, ptr %t925)
  store ptr %t931, ptr %l472
  br label %bb196
bb196:
  %t932 = load ptr, ptr %l472, !tbaa !29
  store ptr %t932, ptr %rv
  br label %ret
bb197:
  %t933 = load ptr, ptr %l1, !tbaa !29
  store ptr %t933, ptr %l473, !tbaa !29
  store i1 false, ptr %l474, !tbaa !21
  %t934 = load ptr, ptr %l473, !tbaa !29
  %t935 = icmp ne ptr %t934, null
  br i1 %t935, label %bb198, label %bb199
bb198:
  %t937 = load ptr, ptr %l473, !tbaa !29
  %t938 = load i64, ptr %t937
  %t940 = icmp eq i64 %t938, 6
  store i1 %t940, ptr %l474, !tbaa !21
  br label %bb199
bb199:
  %t941 = load i1, ptr %l474, !tbaa !21
  br i1 %t941, label %bb200, label %bb201
bb200:
  %t942 = load ptr, ptr %l1, !tbaa !29
  %t944 = getelementptr { i64, [5 x i64] }, ptr %t942, i32 0, i32 1
  %t945 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t944, i32 0, i32 0
  %t946 = load %"compiler/source:Span", ptr %t945
  store %"compiler/source:Span" %t946, ptr %l66
  %t948 = load ptr, ptr %l1, !tbaa !29
  %t950 = getelementptr { i64, [5 x i64] }, ptr %t948, i32 0, i32 1
  %t951 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t950, i32 0, i32 1
  %t952 = load ptr, ptr %t951
  store ptr %t952, ptr %l67, !tbaa !29
  %t954 = load ptr, ptr %l1, !tbaa !29
  %t956 = getelementptr { i64, [5 x i64] }, ptr %t954, i32 0, i32 1
  %t957 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t956, i32 0, i32 2
  %t958 = load ptr, ptr %t957
  store ptr %t958, ptr %l68, !tbaa !29
  br label %bb202
bb201:
  br label %bb205
bb202:
  %t960 = load ptr, ptr %l0, !tbaa !29
  store ptr %t960, ptr %l483, !tbaa !29
  %t961 = load %"compiler/source:Span", ptr %l66
  store %"compiler/source:Span" %t961, ptr %l484
  %t962 = load ptr, ptr %l0, !tbaa !29
  %t963 = load %"compiler/source:Span", ptr %l66
  %t964 = load ptr, ptr %l67, !tbaa !29
  %t965 = load ptr, ptr %l68, !tbaa !29
  %t970 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v1, ptr %t962, %"compiler/source:Span" %t963, ptr %t964, ptr %t965)
  store ptr %t970, ptr %l489
  br label %bb203
bb203:
  %t971 = load ptr, ptr %l483, !tbaa !29
  %t972 = load %"compiler/source:Span", ptr %l484
  %t973 = load ptr, ptr %l489, !tbaa !29
  %t974 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t971, %"compiler/source:Span" %t972, ptr %t973)
  store ptr %t974, ptr %l490
  br label %bb204
bb204:
  %t975 = load ptr, ptr %l490, !tbaa !29
  store ptr %t975, ptr %rv
  br label %ret
bb205:
  %t976 = load ptr, ptr %l1, !tbaa !29
  store ptr %t976, ptr %l491, !tbaa !29
  store i1 false, ptr %l492, !tbaa !21
  %t977 = load ptr, ptr %l491, !tbaa !29
  %t978 = icmp ne ptr %t977, null
  br i1 %t978, label %bb206, label %bb207
bb206:
  %t980 = load ptr, ptr %l491, !tbaa !29
  %t981 = load i64, ptr %t980
  %t983 = icmp eq i64 %t981, 7
  store i1 %t983, ptr %l492, !tbaa !21
  br label %bb207
bb207:
  %t984 = load i1, ptr %l492, !tbaa !21
  br i1 %t984, label %bb208, label %bb209
bb208:
  %t985 = load ptr, ptr %l1, !tbaa !29
  %t987 = getelementptr { i64, [5 x i64] }, ptr %t985, i32 0, i32 1
  %t988 = getelementptr { %"compiler/source:Span", ptr }, ptr %t987, i32 0, i32 0
  %t989 = load %"compiler/source:Span", ptr %t988
  store %"compiler/source:Span" %t989, ptr %l69
  %t991 = load ptr, ptr %l1, !tbaa !29
  %t993 = getelementptr { i64, [5 x i64] }, ptr %t991, i32 0, i32 1
  %t994 = getelementptr { %"compiler/source:Span", ptr }, ptr %t993, i32 0, i32 1
  %t995 = load ptr, ptr %t994
  store ptr %t995, ptr %l70, !tbaa !29
  br label %bb210
bb209:
  br label %bb212
bb210:
  %t997 = load ptr, ptr %l0, !tbaa !29
  %t998 = load %"compiler/source:Span", ptr %l69
  %t999 = load ptr, ptr %l70, !tbaa !29
  %t1003 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %t997, %"compiler/source:Span" %t998, ptr %t999)
  store ptr %t1003, ptr %l502
  br label %bb211
bb211:
  %t1004 = load ptr, ptr %l502, !tbaa !29
  store ptr %t1004, ptr %rv
  br label %ret
bb212:
  %t1005 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1005, ptr %l503, !tbaa !29
  store i1 false, ptr %l504, !tbaa !21
  %t1006 = load ptr, ptr %l503, !tbaa !29
  %t1007 = icmp ne ptr %t1006, null
  br i1 %t1007, label %bb213, label %bb214
bb213:
  %t1009 = load ptr, ptr %l503, !tbaa !29
  %t1010 = load i64, ptr %t1009
  %t1012 = icmp eq i64 %t1010, 24
  store i1 %t1012, ptr %l504, !tbaa !21
  br label %bb214
bb214:
  %t1013 = load i1, ptr %l504, !tbaa !21
  br i1 %t1013, label %bb215, label %bb216
bb215:
  %t1014 = load ptr, ptr %l1, !tbaa !29
  %t1016 = getelementptr { i64, [5 x i64] }, ptr %t1014, i32 0, i32 1
  %t1017 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1016, i32 0, i32 0
  %t1018 = load %"compiler/source:Span", ptr %t1017
  store %"compiler/source:Span" %t1018, ptr %l71
  %t1020 = load ptr, ptr %l1, !tbaa !29
  %t1022 = getelementptr { i64, [5 x i64] }, ptr %t1020, i32 0, i32 1
  %t1023 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1022, i32 0, i32 1
  %t1024 = load ptr, ptr %t1023
  store ptr %t1024, ptr %l72, !tbaa !29
  br label %bb217
bb216:
  br label %bb219
bb217:
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1027 = load %"compiler/source:Span", ptr %l71
  %t1028 = load ptr, ptr %l72, !tbaa !29
  %t1029 = load i32, ptr %l2, !tbaa !23
  %t1034 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValue(ptr %v0, ptr %v1, ptr %t1026, %"compiler/source:Span" %t1027, ptr %t1028, i32 %t1029)
  store ptr %t1034, ptr %l515
  br label %bb218
bb218:
  %t1035 = load ptr, ptr %l515, !tbaa !29
  store ptr %t1035, ptr %rv
  br label %ret
bb219:
  %t1036 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1036, ptr %l516, !tbaa !29
  store i1 false, ptr %l517, !tbaa !21
  %t1037 = load ptr, ptr %l516, !tbaa !29
  %t1038 = icmp ne ptr %t1037, null
  br i1 %t1038, label %bb220, label %bb221
bb220:
  %t1040 = load ptr, ptr %l516, !tbaa !29
  %t1041 = load i64, ptr %t1040
  %t1043 = icmp eq i64 %t1041, 20
  store i1 %t1043, ptr %l517, !tbaa !21
  br label %bb221
bb221:
  %t1044 = load i1, ptr %l517, !tbaa !21
  br i1 %t1044, label %bb222, label %bb223
bb222:
  %t1045 = load ptr, ptr %l1, !tbaa !29
  %t1047 = getelementptr { i64, [5 x i64] }, ptr %t1045, i32 0, i32 1
  %t1048 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1047, i32 0, i32 0
  %t1049 = load %"compiler/source:Span", ptr %t1048
  store %"compiler/source:Span" %t1049, ptr %l73
  %t1051 = load ptr, ptr %l1, !tbaa !29
  %t1053 = getelementptr { i64, [5 x i64] }, ptr %t1051, i32 0, i32 1
  %t1054 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1053, i32 0, i32 1
  %t1055 = load ptr, ptr %t1054
  store ptr %t1055, ptr %l74, !tbaa !29
  br label %bb224
bb223:
  br label %bb226
bb224:
  %t1057 = load ptr, ptr %l0, !tbaa !29
  %t1058 = load %"compiler/source:Span", ptr %l73
  %t1059 = load ptr, ptr %l74, !tbaa !29
  %t1063 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprehension(ptr %v0, ptr %v1, ptr %t1057, %"compiler/source:Span" %t1058, ptr %t1059)
  store ptr %t1063, ptr %l527
  br label %bb225
bb225:
  %t1064 = load ptr, ptr %l527, !tbaa !29
  store ptr %t1064, ptr %rv
  br label %ret
bb226:
  %t1065 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1065, ptr %l528, !tbaa !29
  store i1 false, ptr %l529, !tbaa !21
  %t1066 = load ptr, ptr %l528, !tbaa !29
  %t1067 = icmp ne ptr %t1066, null
  br i1 %t1067, label %bb227, label %bb228
bb227:
  %t1069 = load ptr, ptr %l528, !tbaa !29
  %t1070 = load i64, ptr %t1069
  %t1072 = icmp eq i64 %t1070, 23
  store i1 %t1072, ptr %l529, !tbaa !21
  br label %bb228
bb228:
  %t1073 = load i1, ptr %l529, !tbaa !21
  br i1 %t1073, label %bb229, label %bb230
bb229:
  %t1074 = load ptr, ptr %l1, !tbaa !29
  %t1076 = getelementptr { i64, [5 x i64] }, ptr %t1074, i32 0, i32 1
  %t1077 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1076, i32 0, i32 0
  %t1078 = load %"compiler/source:Span", ptr %t1077
  store %"compiler/source:Span" %t1078, ptr %l75
  %t1080 = load ptr, ptr %l1, !tbaa !29
  %t1082 = getelementptr { i64, [5 x i64] }, ptr %t1080, i32 0, i32 1
  %t1083 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1082, i32 0, i32 1
  %t1084 = load ptr, ptr %t1083
  store ptr %t1084, ptr %l76, !tbaa !29
  br label %bb231
bb230:
  br label %bb233
bb231:
  %t1086 = load ptr, ptr %l0, !tbaa !29
  %t1087 = load %"compiler/source:Span", ptr %l75
  %t1088 = load ptr, ptr %l76, !tbaa !29
  %t1089 = load i32, ptr %l2, !tbaa !23
  %t1094 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %t1086, %"compiler/source:Span" %t1087, ptr %t1088, i32 %t1089)
  store ptr %t1094, ptr %l540
  br label %bb232
bb232:
  %t1095 = load ptr, ptr %l540, !tbaa !29
  store ptr %t1095, ptr %rv
  br label %ret
bb233:
  %t1096 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1096, ptr %l541, !tbaa !29
  store i1 false, ptr %l542, !tbaa !21
  %t1097 = load ptr, ptr %l541, !tbaa !29
  %t1098 = icmp ne ptr %t1097, null
  br i1 %t1098, label %bb234, label %bb235
bb234:
  %t1100 = load ptr, ptr %l541, !tbaa !29
  %t1101 = load i64, ptr %t1100
  %t1103 = icmp eq i64 %t1101, 14
  store i1 %t1103, ptr %l542, !tbaa !21
  br label %bb235
bb235:
  %t1104 = load i1, ptr %l542, !tbaa !21
  br i1 %t1104, label %bb236, label %bb237
bb236:
  %t1105 = load ptr, ptr %l1, !tbaa !29
  %t1107 = getelementptr { i64, [5 x i64] }, ptr %t1105, i32 0, i32 1
  %t1108 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t1107, i32 0, i32 0
  %t1109 = load %"compiler/source:Span", ptr %t1108
  store %"compiler/source:Span" %t1109, ptr %l77
  %t1111 = load ptr, ptr %l1, !tbaa !29
  %t1113 = getelementptr { i64, [5 x i64] }, ptr %t1111, i32 0, i32 1
  %t1114 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t1113, i32 0, i32 1
  %t1115 = load ptr, ptr %t1114
  store ptr %t1115, ptr %l78, !tbaa !29
  %t1117 = load ptr, ptr %l1, !tbaa !29
  %t1119 = getelementptr { i64, [5 x i64] }, ptr %t1117, i32 0, i32 1
  %t1120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t1119, i32 0, i32 2
  %t1121 = load { i64, ptr }, ptr %t1120
  store { i64, ptr } %t1121, ptr %l79, !tbaa !27
  br label %bb238
bb237:
  br label %bb250
bb238:
  %t1123 = load ptr, ptr %l0, !tbaa !29
  %t1124 = load ptr, ptr %l78, !tbaa !29
  %t1127 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t1123, ptr %t1124)
  store i64 %t1127, ptr %l553
  br label %bb239
bb239:
  %t1128 = load i64, ptr %l553, !tbaa !24
  %t1129 = icmp sge i64 %t1128, 0
  br i1 %t1129, label %bb240, label %bb241
bb240:
  %t1131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1131, ptr %l555, !tbaa !29
  %t1132 = load ptr, ptr %l0, !tbaa !29
  %t1133 = load ptr, ptr %l78, !tbaa !29
  %t1136 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t1132, ptr %t1133)
  store i64 %t1136, ptr %l558
  br label %bb242
bb241:
  br label %bb250
bb242:
  %t1137 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t1138 = load %"compiler/source:Span", ptr %l77
  %t1139 = load ptr, ptr %l555, !tbaa !29
  %t1140 = load i64, ptr %l558, !tbaa !24
  %t1143 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %t1139, i64 %t1140, { i64, ptr } %t1137, %"compiler/source:Span" %t1138)
  store { i64, ptr } %t1143, ptr %l561
  br label %bb243
bb243:
  %t1144 = load { i64, ptr }, ptr %l561, !tbaa !27
  store { i64, ptr } %t1144, ptr %l80, !tbaa !27
  %t1145 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1147 = extractvalue { i64, ptr } %t1145, 0
  %t1149 = icmp eq i64 %t1147, 0
  br i1 %t1149, label %bb244, label %bb245
bb244:
  %t1151 = load ptr, ptr %l0, !tbaa !29
  %t1152 = load %"compiler/source:Span", ptr %l77
  %t1155 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1151, %"compiler/source:Span" %t1152)
  store ptr %t1155, ptr %l567
  br label %bb246
bb245:
  br label %bb247
bb246:
  %t1156 = load ptr, ptr %l567, !tbaa !29
  store ptr %t1156, ptr %rv
  br label %ret
bb247:
  %t1157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1157, ptr %l568, !tbaa !29
  %t1158 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t1158, ptr %l569
  %t1159 = load ptr, ptr %l0, !tbaa !29
  %t1160 = load ptr, ptr %l78, !tbaa !29
  %t1163 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t1159, ptr %t1160)
  store i64 %t1163, ptr %l572
  br label %bb248
bb248:
  %t1164 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1165 = load ptr, ptr %l568, !tbaa !29
  %t1166 = load %"compiler/source:Span", ptr %l569
  %t1167 = load i64, ptr %l572, !tbaa !24
  %t1169 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v0, ptr %t1165, %"compiler/source:Span" %t1166, i64 %t1167, { i64, ptr } %t1164)
  store ptr %t1169, ptr %l574
  br label %bb249
bb249:
  %t1170 = load ptr, ptr %l574, !tbaa !29
  store ptr %t1170, ptr %rv
  br label %ret
bb250:
  store %olang.scope zeroinitializer, ptr %s34
  %t1171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1171, ptr %l575, !tbaa !29
  %t1172 = load ptr, ptr %l1, !tbaa !29
  %t1174 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1172)
  store %"compiler/source:Span" %t1174, ptr %l577
  br label %bb251
bb251:
  %t1175 = load ptr, ptr %l1, !tbaa !29
  %t1177 = call { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v1, ptr %s34, ptr %t1175)
  store { i64, ptr } %t1177, ptr %l579
  br label %bb252
bb252:
  %t1178 = load ptr, ptr %l575, !tbaa !29
  %t1179 = load %"compiler/source:Span", ptr %l577
  %t1180 = load { i64, ptr }, ptr %l579, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s34, ptr %t1178, %"compiler/source:Span" %t1179, { i64, ptr } %t1180)
  br label %bb253
bb253:
  %t1181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1181, ptr %l580, !tbaa !29
  %t1182 = load ptr, ptr %l1, !tbaa !29
  %t1184 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t1182)
  store %"compiler/source:Span" %t1184, ptr %l582
  br label %bb254
bb254:
  %t1185 = load ptr, ptr %l580, !tbaa !29
  %t1186 = load %"compiler/source:Span", ptr %l582
  %t1187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t1185, %"compiler/source:Span" %t1186)
  store ptr %t1187, ptr %l583
  br label %bb255
bb255:
  call void @__olang_scope_close(ptr %s34)
  %t1188 = load ptr, ptr %l583, !tbaa !29
  store ptr %t1188, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l19 = alloca i32
  %l21 = alloca i1
  %l27 = alloca i32
  %l30 = alloca i1
  %l35 = alloca i32
  %l42 = alloca i32
  %l44 = alloca i1
  %l48 = alloca i1
  %l53 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load i32, ptr %l2, !tbaa !23
  %t12 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t6, i32 %t7, i32 %t8)
  store i1 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb10
bb8:
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l19, !tbaa !23
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t33, i32 %t34, i32 %t32)
  store i1 %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l13, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/generic:Program", ptr %t43, i32 0, i32 2
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l27
  br label %bb14
bb14:
  %t50 = load i32, ptr %l27
  %t52 = trunc i64 19 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l2, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb18
bb17:
  %t65 = load i32, ptr %l35
  %t67 = trunc i64 19 to i32
  %t68 = icmp eq i32 %t65, %t67
  store i1 %t68, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t70 = load i1, ptr %l30, !tbaa !21
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  %t77 = load i32, ptr %l2, !tbaa !23
  %t80 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t76, i32 %t77)
  store i32 %t80, ptr %l42
  br label %bb21
bb20:
  br label %bb38
bb21:
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l1, !tbaa !23
  %t86 = load i32, ptr %l2, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %t84, i32 %t85, i32 %t86)
  store i1 %t90, ptr %l48
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t91 = load i1, ptr %l48, !tbaa !21
  %t92 = xor i1 %t91, true
  store i1 %t92, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t94 = load i1, ptr %l44, !tbaa !21
  br i1 %t94, label %bb26, label %bb27
bb26:
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l53, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t107, i32 %t108)
  store i32 %t111, ptr %l58
  br label %bb29
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t117, i32 %t118)
  store i32 %t121, ptr %l63
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l53, !tbaa !29
  %t123 = load i32, ptr %l58, !tbaa !23
  %t124 = load i32, ptr %l63, !tbaa !23
  %t125 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t122, i32 %t123, i32 %t124)
  store i1 %t125, ptr %l64
  br label %bb31
bb31:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb33:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l66, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = getelementptr %"compiler/generic:Program", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %l1, !tbaa !23
  %t137 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t133, i32 %t134)
  store i32 %t137, ptr %l71
  br label %bb34
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l2, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l76
  br label %bb35
bb35:
  %t148 = load ptr, ptr %l66, !tbaa !29
  %t149 = load i32, ptr %l71, !tbaa !23
  %t150 = load i32, ptr %l76, !tbaa !23
  %t151 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t148, i32 %t149, i32 %t150)
  store i1 %t151, ptr %l77
  br label %bb36
bb36:
  %t152 = load i1, ptr %l77, !tbaa !21
  store i1 %t152, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t153 = load i1, ptr %l65, !tbaa !21
  store i1 %t153, ptr %rv
  br label %ret
bb38:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb5
bb5:
  %t20 = load i32, ptr %l12, !tbaa !23
  store i32 %t20, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l15
  br label %bb6
bb6:
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l2, !tbaa !23
  %t31 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb10
bb9:
  %t32 = load i32, ptr %l19
  %t34 = trunc i64 5 to i32
  %t35 = icmp eq i32 %t32, %t34
  store i1 %t35, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l16, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca %"compiler/names:Ref"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca i1
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/source:Span"
  %l25 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca %"compiler/names:Ref"
  %l28 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca i1
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca %"compiler/names:Ref"
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i1
  %l60 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca %"compiler/msgs:Msg"
  %l69 = alloca i64
  %l72 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l92 = alloca i1
  %l94 = alloca ptr
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l103 = alloca ptr
  %l107 = alloca i32
  %l108 = alloca { i64, ptr }
  %l110 = alloca %"compiler/msgs:Msg"
  %l111 = alloca i64
  %l116 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l122 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca i1
  %l135 = alloca i1
  %l140 = alloca { i64, ptr }
  %l144 = alloca ptr
  %l147 = alloca i32
  %l152 = alloca i32
  %l155 = alloca i1
  %l160 = alloca i32
  %l162 = alloca i1
  %l165 = alloca ptr
  %l170 = alloca i32
  %l173 = alloca ptr
  %l176 = alloca i32
  %l177 = alloca i32
  %l178 = alloca i1
  %l186 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca ptr
  %l193 = alloca { i64, ptr }
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca %"compiler/source:Span"
  %l199 = alloca { i64, ptr }
  %l201 = alloca %"compiler/msgs:Msg"
  %l202 = alloca i64
  %l203 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l207 = alloca i32
  %l208 = alloca ptr
  %l211 = alloca ptr
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l220 = alloca %"compiler/source:Span"
  %l221 = alloca %"compiler/source:Span"
  %l224 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %l232 = alloca ptr
  %l239 = alloca ptr
  %l243 = alloca i1
  %l246 = alloca { i64, ptr }
  %l247 = alloca i1
  %l248 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca { i64, ptr }
  %l255 = alloca %"compiler/source:Span"
  %l258 = alloca %"compiler/msgs:Msg"
  %l259 = alloca i64
  %l264 = alloca ptr
  %l268 = alloca i1
  %l271 = alloca ptr
  %l272 = alloca %"compiler/source:Span"
  %l273 = alloca i32
  %l280 = alloca i32
  %l286 = alloca ptr
  %l293 = alloca ptr
  %l301 = alloca i64
  %l306 = alloca { i64, ptr }
  %l314 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca %"compiler/source:Span"
  %l318 = alloca %"compiler/source:Span"
  %l319 = alloca i64
  %l320 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l327 = alloca ptr
  %l328 = alloca i1
  %l337 = alloca i64
  %l341 = alloca i64
  %l346 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l356 = alloca ptr
  %l357 = alloca %"compiler/source:Span"
  %l358 = alloca %"compiler/source:Span"
  %l361 = alloca { i64, ptr }
  %l363 = alloca %"compiler/source:Span"
  %l364 = alloca i64
  %l365 = alloca { i64, ptr }
  %l370 = alloca ptr
  %l372 = alloca ptr
  %l373 = alloca i1
  %l384 = alloca ptr
  %l386 = alloca ptr
  %l390 = alloca %"compiler/names:Ref"
  %l393 = alloca i1
  %l397 = alloca ptr
  %l399 = alloca ptr
  %l401 = alloca ptr
  %l406 = alloca i32
  %l408 = alloca i32
  %l414 = alloca ptr
  %l419 = alloca i1
  %l420 = alloca ptr
  %l421 = alloca i32
  %l422 = alloca { i64, ptr }
  %l424 = alloca %"compiler/source:Span"
  %l425 = alloca i1
  %l429 = alloca ptr
  %l436 = alloca ptr
  %l440 = alloca i1
  %l443 = alloca i1
  %l445 = alloca i1
  %l448 = alloca i32
  %l450 = alloca ptr
  %l451 = alloca %"compiler/source:Span"
  %l452 = alloca ptr
  %l453 = alloca i32
  %l454 = alloca %"compiler/source:Span"
  %l457 = alloca { i64, ptr }
  %l459 = alloca %"compiler/source:Span"
  %l463 = alloca ptr
  %l469 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca ptr
  %t525 = alloca i64
  %t536 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  store ptr %t1, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t2 = load ptr, ptr %l29, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l29, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l30, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l30, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l7
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l8, !tbaa !23
  br label %bb5
bb4:
  br label %bb154
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l39, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l41
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l41, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l39, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l45
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l45
  store %"compiler/names:Ref" %t42, ptr %l9
  %t43 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l8, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t49, i32 %t50)
  store { i64, ptr } %t53, ptr %l51
  br label %bb10
bb9:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb12
bb10:
  %t54 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t54, { i64, ptr } { i64 5, ptr @.d13 })
  store i1 %t55, ptr %l52
  br label %bb11
bb11:
  %t56 = load i1, ptr %l52, !tbaa !21
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t62 = icmp eq i64 %t60, 1
  store i1 %t62, ptr %l53, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb15
bb15:
  %t64 = load i1, ptr %l53, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  %t65 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = icmp slt i64 %t67, 1
  br i1 %t69, label %bb18, label %bb19
bb17:
  br label %bb106
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t71 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t75 = icmp sgt i64 %t73, 2
  store i1 %t75, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t77 = load i1, ptr %l60, !tbaa !21
  br i1 %t77, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l64, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l65
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %s3, i64 1, i64 2, i64 %t82)
  store %"compiler/msgs:Msg" %t84, ptr %l68
  br label %bb23
bb22:
  br label %bb26
bb23:
  %t85 = load ptr, ptr %l64, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l65
  %t87 = load %"compiler/msgs:Msg", ptr %l68
  %t88 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t85, %"compiler/source:Span" %t86, %"compiler/msgs:Msg" %t87)
  store i64 %t88, ptr %l69
  br label %bb24
bb24:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l1
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t89, %"compiler/source:Span" %t90)
  store ptr %t93, ptr %l72
  br label %bb25
bb25:
  %t94 = load ptr, ptr %l72, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t94, ptr %rv
  br label %ret
bb26:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l74, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr ptr, ptr %t98, i64 0
  %t100 = load ptr, ptr %t99, !tbaa !39
  store ptr %t100, ptr %l10, !tbaa !29
  %t102 = load ptr, ptr %l10, !tbaa !29
  store ptr %t102, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t103 = load ptr, ptr %l76, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb27, label %bb28
bb27:
  %t106 = load ptr, ptr %l76, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 4
  store i1 %t109, ptr %l77, !tbaa !21
  br label %bb28
bb28:
  %t110 = load i1, ptr %l77, !tbaa !21
  br i1 %t110, label %bb29, label %bb30
bb29:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t113, i32 0, i32 0
  %t115 = load %"compiler/source:Span", ptr %t114
  store %"compiler/source:Span" %t115, ptr %l11
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l12, !tbaa !29
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t125 = getelementptr { i64, [5 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t125, i32 0, i32 2
  %t127 = load i1, ptr %t126
  store i1 %t127, ptr %l13, !tbaa !21
  br label %bb31
bb30:
  br label %bb50
bb31:
  %t129 = load i1, ptr %l13, !tbaa !21
  br i1 %t129, label %bb32, label %bb33
bb32:
  %t131 = load ptr, ptr %l0, !tbaa !29
  store ptr %t131, ptr %l88, !tbaa !29
  %t132 = load ptr, ptr %l12, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb34, label %bb35
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb38
bb34:
  call void @__olang_check_failed(ptr @olang_loc_63e5d6ec29e0915f_e13c517565128b43)
  unreachable
bb35:
  br label %bb36
bb36:
  %t136 = load ptr, ptr %l12, !tbaa !29
  %t137 = load ptr, ptr %l88, !tbaa !29
  %t139 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v2, ptr %t137, ptr %t136)
  store i1 %t139, ptr %l92
  br label %bb37
bb37:
  %t140 = load i1, ptr %l92, !tbaa !21
  %t141 = xor i1 %t140, true
  store i1 %t141, ptr %l87, !tbaa !21
  br label %bb38
bb38:
  %t143 = load i1, ptr %l87, !tbaa !21
  br i1 %t143, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l94, !tbaa !29
  %t145 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = add i32 %t148, 3
  %t153 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s5, i32 %t146, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l98
  br label %bb41
bb40:
  br label %bb49
bb41:
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l99, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  store ptr %t158, ptr %l101, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t159)
  store ptr %t161, ptr %l103
  br label %bb42
bb42:
  %t162 = load ptr, ptr %l103, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 4
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t166 = load ptr, ptr %l101, !tbaa !29
  %t169 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v2, ptr %t166, ptr %t164, ptr %t165)
  store i32 %t169, ptr %l107
  br label %bb43
bb43:
  %t170 = load ptr, ptr %l99, !tbaa !29
  %t171 = load i32, ptr %l107, !tbaa !23
  %t172 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t170, i32 %t171)
  store { i64, ptr } %t172, ptr %l108
  br label %bb44
bb44:
  %t173 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t175 = extractvalue { i64, ptr } %t173, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t181 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %s5, ptr %s5, { i64, ptr } %t179)
  store %"compiler/msgs:Msg" %t181, ptr %l110
  br label %bb45
bb45:
  %t182 = load ptr, ptr %l94, !tbaa !29
  %t183 = load %"compiler/source:Span", ptr %l98
  %t184 = load %"compiler/msgs:Msg", ptr %l110
  %t185 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t182, %"compiler/source:Span" %t183, %"compiler/msgs:Msg" %t184)
  store i64 %t185, ptr %l111
  br label %bb46
bb46:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t186, { i64, ptr } %t187)
  br label %bb47
bb47:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l116
  br label %bb48
bb48:
  %t195 = load ptr, ptr %l116, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t195, ptr %rv
  br label %ret
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t198, ptr %l119, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr ptr, ptr %t200, i64 0
  %t202 = load ptr, ptr %t201, !tbaa !39
  %t206 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v2, ptr %t197, ptr %t202)
  store i32 %t206, ptr %l122
  br label %bb52
bb52:
  %t207 = load i32, ptr %l122, !tbaa !23
  store i32 %t207, ptr %l14, !tbaa !23
  %t208 = load i32, ptr %l14, !tbaa !23
  %t209 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t212 = icmp eq i32 %t208, %t209
  br i1 %t212, label %bb53, label %bb54
bb53:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t214, { i64, ptr } %t215)
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load %"compiler/source:Span", ptr %l1
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t218, %"compiler/source:Span" %t219)
  store ptr %t222, ptr %l130
  br label %bb56
bb56:
  %t223 = load ptr, ptr %l130, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t223, ptr %rv
  br label %ret
bb57:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l14, !tbaa !23
  %t229 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t225, i32 %t226)
  store i1 %t229, ptr %l134
  br label %bb58
bb58:
  %t230 = load i1, ptr %l134, !tbaa !21
  br i1 %t230, label %bb59, label %bb60
bb59:
  %t231 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t235 = icmp eq i64 %t233, 2
  store i1 %t235, ptr %l135, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb61
bb61:
  %t237 = load i1, ptr %l135, !tbaa !21
  br i1 %t237, label %bb62, label %bb63
bb62:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t239, ptr %l140, !tbaa !27
  %t240 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 1
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t245 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %t238, ptr %t243, i32 %t245)
  store ptr %t249, ptr %l144
  br label %bb64
bb63:
  br label %bb93
bb64:
  %t250 = load ptr, ptr %l144, !tbaa !29
  store ptr %t250, ptr %l15, !tbaa !29
  %t251 = load ptr, ptr %l15, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t251)
  store i32 %t254, ptr %l147
  br label %bb65
bb65:
  %t255 = load i32, ptr %l147, !tbaa !23
  store i32 %t255, ptr %l16, !tbaa !23
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = getelementptr %"compiler/generic:Program", ptr %t259, i32 0, i32 2
  %t262 = load i32, ptr %l16, !tbaa !23
  %t265 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t261, i32 %t262)
  store i32 %t265, ptr %l152
  br label %bb66
bb66:
  %t266 = load i32, ptr %l152
  %t268 = trunc i64 19 to i32
  %t269 = icmp eq i32 %t266, %t268
  br i1 %t269, label %bb67, label %bb68
bb67:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 2
  %t277 = load i32, ptr %l16, !tbaa !23
  %t280 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t276, i32 %t277)
  store i32 %t280, ptr %l160
  br label %bb69
bb68:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb70
bb69:
  %t281 = load i32, ptr %l160, !tbaa !23
  %t282 = icmp ne i32 %t281, 0
  store i1 %t282, ptr %l155, !tbaa !21
  br label %bb70
bb70:
  %t284 = load i1, ptr %l155, !tbaa !21
  br i1 %t284, label %bb71, label %bb72
bb71:
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  store ptr %t290, ptr %l165, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t291, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 2
  %t297 = load i32, ptr %l16, !tbaa !23
  %t300 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t300, ptr %l170
  br label %bb73
bb72:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb77
bb73:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/check:Checker", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/generic:Program", ptr %t304, i32 0, i32 2
  store ptr %t306, ptr %l173, !tbaa !29
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i32, ptr %l14, !tbaa !23
  %t311 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t307, i32 %t308)
  store i32 %t311, ptr %l176
  br label %bb74
bb74:
  %t312 = load ptr, ptr %l173, !tbaa !29
  %t313 = load i32, ptr %l176, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t312, i32 %t313)
  store i32 %t314, ptr %l177
  br label %bb75
bb75:
  %t315 = load ptr, ptr %l165, !tbaa !29
  %t316 = load i32, ptr %l170, !tbaa !23
  %t317 = load i32, ptr %l177, !tbaa !23
  %t318 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t315, i32 %t316, i32 %t317)
  store i1 %t318, ptr %l178
  br label %bb76
bb76:
  %t319 = load i1, ptr %l178, !tbaa !21
  store i1 %t319, ptr %l162, !tbaa !21
  br label %bb77
bb77:
  %t320 = load i1, ptr %l162, !tbaa !21
  br i1 %t320, label %bb78, label %bb79
bb78:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  %t323 = load i32, ptr %l16, !tbaa !23
  %t324 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t325 = load i32, ptr %l6, !tbaa !23
  %t326 = load ptr, ptr %l15, !tbaa !29
  %t334 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v3, ptr %t321, %"compiler/source:Span" %t322, i32 %t323, { i64, ptr } %t324, i32 %t325, ptr %t326)
  store ptr %t334, ptr %l186
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t335 = load ptr, ptr %l186, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t335, ptr %rv
  br label %ret
bb81:
  %t337 = load i32, ptr %l16, !tbaa !23
  %t338 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t341 = icmp ne i32 %t337, %t338
  br i1 %t341, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s10
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l191, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l192, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t345, ptr %l193, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr ptr, ptr %t347, i64 0
  %t349 = load ptr, ptr %t348, !tbaa !39
  %t351 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t349)
  store %"compiler/source:Span" %t351, ptr %l195
  br label %bb84
bb83:
  br label %bb89
bb84:
  %t352 = load ptr, ptr %l192, !tbaa !29
  %t353 = load %"compiler/source:Span", ptr %l195
  %t354 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %t352, %"compiler/source:Span" %t353)
  store %"compiler/source:Span" %t354, ptr %l196
  br label %bb85
bb85:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l14, !tbaa !23
  %t359 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t355, i32 %t356)
  store { i64, ptr } %t359, ptr %l199
  br label %bb86
bb86:
  %t360 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 0
  %t362 = extractvalue { i64, ptr } %t360, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t368 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s10, ptr %s10, { i64, ptr } %t366)
  store %"compiler/msgs:Msg" %t368, ptr %l201
  br label %bb87
bb87:
  %t369 = load ptr, ptr %l191, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l196
  %t371 = load %"compiler/msgs:Msg", ptr %l201
  %t372 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t369, %"compiler/source:Span" %t370, %"compiler/msgs:Msg" %t371)
  store i64 %t372, ptr %l202
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb89:
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l203, !tbaa !29
  %t374 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t374, ptr %l204, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr ptr, ptr %t376, i64 0
  %t378 = load ptr, ptr %t377, !tbaa !39
  store ptr %t378, ptr %l205, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t379)
  store i32 %t381, ptr %l207
  br label %bb90
bb90:
  %t382 = load ptr, ptr %l203, !tbaa !29
  %t383 = load ptr, ptr %l205, !tbaa !29
  %t384 = load i32, ptr %l207, !tbaa !23
  %t385 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v3, ptr %t382, ptr %t383, i32 %t384)
  store ptr %t385, ptr %l208
  br label %bb91
bb91:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load %"compiler/source:Span", ptr %l1
  %t390 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t386, %"compiler/source:Span" %t387)
  store ptr %t390, ptr %l211
  br label %bb92
bb92:
  %t391 = load ptr, ptr %l211, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t391, ptr %rv
  br label %ret
bb93:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i32, ptr %l14, !tbaa !23
  %t397 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t393, i32 %t394)
  store i1 %t397, ptr %l215
  br label %bb94
bb94:
  %t398 = load i1, ptr %l215, !tbaa !21
  br i1 %t398, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s11
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l216, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  store ptr %t400, ptr %l217, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t401, ptr %l218, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr ptr, ptr %t403, i64 0
  %t405 = load ptr, ptr %t404, !tbaa !39
  %t407 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t405)
  store %"compiler/source:Span" %t407, ptr %l220
  br label %bb97
bb96:
  br label %bb104
bb97:
  %t408 = load ptr, ptr %l217, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l220
  %t410 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %t408, %"compiler/source:Span" %t409)
  store %"compiler/source:Span" %t410, ptr %l221
  br label %bb98
bb98:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i32, ptr %l14, !tbaa !23
  %t415 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t411, i32 %t412)
  store { i64, ptr } %t415, ptr %l224
  br label %bb99
bb99:
  %t416 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 0
  %t418 = extractvalue { i64, ptr } %t416, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  %t424 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s11, ptr %s11, { i64, ptr } %t422)
  store %"compiler/msgs:Msg" %t424, ptr %l226
  br label %bb100
bb100:
  %t425 = load ptr, ptr %l216, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l221
  %t427 = load %"compiler/msgs:Msg", ptr %l226
  %t428 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t425, %"compiler/source:Span" %t426, %"compiler/msgs:Msg" %t427)
  store i64 %t428, ptr %l227
  br label %bb101
bb101:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t429, { i64, ptr } %t430)
  br label %bb102
bb102:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load %"compiler/source:Span", ptr %l1
  %t437 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t433, %"compiler/source:Span" %t434)
  store ptr %t437, ptr %l232
  br label %bb103
bb103:
  %t438 = load ptr, ptr %l232, !tbaa !29
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t438, ptr %rv
  br label %ret
bb104:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load %"compiler/source:Span", ptr %l1
  %t442 = load i32, ptr %l14, !tbaa !23
  %t443 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t444 = load i32, ptr %l6, !tbaa !23
  %t450 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v3, ptr %t440, %"compiler/source:Span" %t441, i32 %t442, { i64, ptr } %t443, i32 %t444, ptr null)
  store ptr %t450, ptr %l239
  br label %bb105
bb105:
  %t451 = load ptr, ptr %l239, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t451, ptr %rv
  br label %ret
bb106:
  %t453 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t454 = load i32, ptr %t453
  %t456 = trunc i64 7 to i32
  %t457 = icmp eq i32 %t454, %t456
  br i1 %t457, label %bb107, label %bb108
bb107:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l8, !tbaa !23
  %t463 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t459, i32 %t460)
  store { i64, ptr } %t463, ptr %l246
  br label %bb109
bb108:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb111
bb109:
  %t464 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t465 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t464, { i64, ptr } { i64 5, ptr @.d14 })
  store i1 %t465, ptr %l247
  br label %bb110
bb110:
  %t466 = load i1, ptr %l247, !tbaa !21
  store i1 %t466, ptr %l243, !tbaa !21
  br label %bb111
bb111:
  %t467 = load i1, ptr %l243, !tbaa !21
  br i1 %t467, label %bb112, label %bb113
bb112:
  %t468 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t472 = icmp sgt i64 %t470, 1
  store i1 %t472, ptr %l248, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb114
bb114:
  %t474 = load i1, ptr %l248, !tbaa !21
  br i1 %t474, label %bb115, label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s12
  %t475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t475, ptr %l252, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t476, ptr %l253, !tbaa !27
  %t477 = getelementptr { i64, ptr }, ptr %l253, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr ptr, ptr %t478, i64 1
  %t480 = load ptr, ptr %t479, !tbaa !39
  %t482 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t480)
  store %"compiler/source:Span" %t482, ptr %l255
  br label %bb117
bb116:
  br label %bb122
bb117:
  %t483 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t487 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %s12, i64 %t485)
  store %"compiler/msgs:Msg" %t487, ptr %l258
  br label %bb118
bb118:
  %t488 = load ptr, ptr %l252, !tbaa !29
  %t489 = load %"compiler/source:Span", ptr %l255
  %t490 = load %"compiler/msgs:Msg", ptr %l258
  %t491 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t488, %"compiler/source:Span" %t489, %"compiler/msgs:Msg" %t490)
  store i64 %t491, ptr %l259
  br label %bb119
bb119:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t492, { i64, ptr } %t493)
  br label %bb120
bb120:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load %"compiler/source:Span", ptr %l1
  %t500 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t496, %"compiler/source:Span" %t497)
  store ptr %t500, ptr %l264
  br label %bb121
bb121:
  %t501 = load ptr, ptr %l264, !tbaa !29
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t501, ptr %rv
  br label %ret
bb122:
  %t503 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t504 = load i32, ptr %t503
  %t506 = trunc i64 4 to i32
  %t507 = icmp eq i32 %t504, %t506
  br i1 %t507, label %bb123, label %bb124
bb123:
  %t509 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 2
  %t510 = load i64, ptr %t509, !tbaa !24
  %t512 = icmp sge i64 %t510, 0
  store i1 %t512, ptr %l268, !tbaa !21
  br label %bb125
bb124:
  store i1 false, ptr %l268, !tbaa !21
  br label %bb125
bb125:
  %t514 = load i1, ptr %l268, !tbaa !21
  br i1 %t514, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s13
  %t515 = load ptr, ptr %l0, !tbaa !29
  store ptr %t515, ptr %l271, !tbaa !29
  %t516 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t516, ptr %l272
  %t517 = load i32, ptr %l8, !tbaa !23
  store i32 %t517, ptr %l273, !tbaa !23
  %t518 = icmp sge i64 1, 0
  br i1 %t518, label %bb128, label %bb129
bb127:
  br label %bb138
bb128:
  %t520 = icmp sle i64 1, 2305843009213693951
  br i1 %t520, label %bb130, label %bb131
bb129:
  call void @__olang_check_failed(ptr @olang_loc_b174354d9e16fd38_b3c97c50613a8cf4)
  unreachable
bb130:
  %t522 = mul i64 1, 4
  %t523 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t522)
  %t524 = load i32, ptr %l273, !tbaa !23
  store i64 0, ptr %t525
  br label %fill.526
fill.526:
  %t529 = load i64, ptr %t525
  %t530 = icmp slt i64 %t529, 1
  br i1 %t530, label %fillb.527, label %filld.528
fillb.527:
  %t531 = getelementptr i32, ptr %t523, i64 %t529
  store i32 %t524, ptr %t531
  %t532 = add i64 %t529, 1
  store i64 %t532, ptr %t525
  br label %fill.526
filld.528:
  %t533 = insertvalue { i64, ptr } undef, i64 1, 0
  %t534 = insertvalue { i64, ptr } %t533, ptr %t523, 1
  %t535 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t536
  %t537 = getelementptr { i64, [5 x i64] }, ptr %t536, i32 0, i32 0
  store i64 0, ptr %t537
  %t538 = load %"compiler/source:Span", ptr %l272
  %t539 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t538, 0
  %t541 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t539, { i64, ptr } %t534, 1
  %t543 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t541, { i64, ptr } %t535, 2
  %t544 = getelementptr { i64, [5 x i64] }, ptr %t536, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t543, ptr %t544
  %t545 = load { i64, [5 x i64] }, ptr %t536
  %t547 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 48, i64 8)
  store { i64, [5 x i64] } %t545, ptr %t547
  %t548 = load ptr, ptr %l271, !tbaa !29
  %t550 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %s13, ptr %t548, ptr %t547)
  store i32 %t550, ptr %l280
  br label %bb132
bb131:
  call void @__olang_check_failed(ptr @olang_loc_b174354d9e16fd38_b3c97c50613a8cf4)
  unreachable
bb132:
  %t551 = load i32, ptr %l280, !tbaa !23
  store i32 %t551, ptr %l17, !tbaa !23
  %t552 = load i32, ptr %l17, !tbaa !23
  %t553 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t556 = icmp eq i32 %t552, %t553
  br i1 %t556, label %bb133, label %bb134
bb133:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load %"compiler/source:Span", ptr %l1
  %t562 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t558, %"compiler/source:Span" %t559)
  store ptr %t562, ptr %l286
  br label %bb135
bb134:
  br label %bb136
bb135:
  %t563 = load ptr, ptr %l286, !tbaa !29
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t563, ptr %rv
  br label %ret
bb136:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load %"compiler/source:Span", ptr %l1
  %t567 = load %"compiler/source:Span", ptr %l7
  %t568 = load i32, ptr %l17, !tbaa !23
  %t569 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t575 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v3, ptr %t565, %"compiler/source:Span" %t566, %"compiler/source:Span" %t567, i32 %t568, { i64, ptr } %t569)
  store ptr %t575, ptr %l293
  br label %bb137
bb137:
  %t576 = load ptr, ptr %l293, !tbaa !29
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t576, ptr %rv
  br label %ret
bb138:
  %t578 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t579 = load i32, ptr %t578
  %t581 = trunc i64 3 to i32
  %t582 = icmp eq i32 %t579, %t581
  br i1 %t582, label %bb139, label %bb140
bb139:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/check:Checker", ptr %t584, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !29
  %t588 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 1
  %t589 = load i64, ptr %t588, !tbaa !24
  %t590 = load i32, ptr %l8, !tbaa !23
  %t594 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t587, i64 %t589, i32 %t590)
  store i64 %t594, ptr %l301
  br label %bb141
bb140:
  br label %bb153
bb141:
  %t595 = load i64, ptr %l301, !tbaa !24
  store i64 %t595, ptr %l18, !tbaa !24
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load i64, ptr %l18, !tbaa !24
  %t598 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t599 = load %"compiler/source:Span", ptr %l2
  %t604 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v2, ptr %t596, i64 %t597, { i64, ptr } %t598, %"compiler/source:Span" %t599)
  store { i64, ptr } %t604, ptr %l306
  br label %bb142
bb142:
  %t605 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t605, ptr %l19, !tbaa !27
  %t606 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t610 = icmp eq i64 %t608, 0
  br i1 %t610, label %bb143, label %bb144
bb143:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t612, { i64, ptr } %t613)
  br label %bb145
bb144:
  br label %bb147
bb145:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load %"compiler/source:Span", ptr %l1
  %t620 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t616, %"compiler/source:Span" %t617)
  store ptr %t620, ptr %l314
  br label %bb146
bb146:
  %t621 = load ptr, ptr %l314, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t621, ptr %rv
  br label %ret
bb147:
  %t623 = load ptr, ptr %l0, !tbaa !29
  store ptr %t623, ptr %l316, !tbaa !29
  %t624 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t624, ptr %l317
  %t625 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t625, ptr %l318
  %t626 = load i64, ptr %l18, !tbaa !24
  store i64 %t626, ptr %l319, !tbaa !24
  %t627 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t627, ptr %l320, !tbaa !27
  %t628 = icmp sge i64 0, 0
  br i1 %t628, label %bb148, label %bb149
bb148:
  %t630 = icmp sle i64 0, 1152921504606846975
  br i1 %t630, label %bb150, label %bb151
bb149:
  call void @__olang_check_failed(ptr @olang_loc_8ebb37c5c90e9f1b_48dd25e04e404e97)
  unreachable
bb150:
  %t632 = mul i64 0, 8
  %t633 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t632)
  %t634 = insertvalue { i64, ptr } undef, i64 0, 0
  %t635 = insertvalue { i64, ptr } %t634, ptr %t633, 1
  %t636 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t637 = load ptr, ptr %l316, !tbaa !29
  %t638 = load %"compiler/source:Span", ptr %l317
  %t639 = load %"compiler/source:Span", ptr %l318
  %t640 = load i64, ptr %l319, !tbaa !24
  %t641 = load { i64, ptr }, ptr %l320, !tbaa !27
  %t644 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %t637, %"compiler/source:Span" %t638, %"compiler/source:Span" %t639, i64 %t640, ptr null, { i64, ptr } %t641, { i64, ptr } %t635, { i64, ptr } %t636)
  store ptr %t644, ptr %l325
  br label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_8ebb37c5c90e9f1b_48dd25e04e404e97)
  unreachable
bb152:
  %t645 = load ptr, ptr %l325, !tbaa !29
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t645, ptr %rv
  br label %ret
bb153:
  call void @__olang_scope_close(ptr %s1)
  br label %bb223
bb154:
  %t647 = load ptr, ptr %l3, !tbaa !29
  store ptr %t647, ptr %l327, !tbaa !29
  store i1 false, ptr %l328, !tbaa !21
  %t648 = load ptr, ptr %l327, !tbaa !29
  %t649 = icmp ne ptr %t648, null
  br i1 %t649, label %bb155, label %bb156
bb155:
  %t651 = load ptr, ptr %l327, !tbaa !29
  %t652 = load i64, ptr %t651
  %t654 = icmp eq i64 %t652, 15
  store i1 %t654, ptr %l328, !tbaa !21
  br label %bb156
bb156:
  %t655 = load i1, ptr %l328, !tbaa !21
  br i1 %t655, label %bb157, label %bb158
bb157:
  %t656 = load ptr, ptr %l3, !tbaa !29
  %t658 = getelementptr { i64, [5 x i64] }, ptr %t656, i32 0, i32 1
  %t659 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t658, i32 0, i32 0
  %t660 = load %"compiler/source:Span", ptr %t659
  store %"compiler/source:Span" %t660, ptr %l20
  %t662 = load ptr, ptr %l3, !tbaa !29
  %t664 = getelementptr { i64, [5 x i64] }, ptr %t662, i32 0, i32 1
  %t665 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t664, i32 0, i32 2
  %t666 = load i32, ptr %t665
  store i32 %t666, ptr %l21, !tbaa !23
  br label %bb159
bb158:
  br label %bb177
bb159:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load ptr, ptr %l3, !tbaa !29
  %t672 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t668, ptr %t669)
  store i64 %t672, ptr %l337
  br label %bb160
bb160:
  %t673 = load i64, ptr %l337, !tbaa !24
  %t674 = icmp sge i64 %t673, 0
  br i1 %t674, label %bb161, label %bb162
bb161:
  %t676 = load ptr, ptr %l0, !tbaa !29
  %t677 = load ptr, ptr %l3, !tbaa !29
  %t680 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %t676, ptr %t677)
  store i64 %t680, ptr %l341
  br label %bb163
bb162:
  br label %bb177
bb163:
  %t681 = load i64, ptr %l341, !tbaa !24
  store i64 %t681, ptr %l22, !tbaa !24
  %t682 = load ptr, ptr %l0, !tbaa !29
  %t683 = load i64, ptr %l22, !tbaa !24
  %t684 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t685 = load %"compiler/source:Span", ptr %l2
  %t690 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v2, ptr %t682, i64 %t683, { i64, ptr } %t684, %"compiler/source:Span" %t685)
  store { i64, ptr } %t690, ptr %l346
  br label %bb164
bb164:
  %t691 = load { i64, ptr }, ptr %l346, !tbaa !27
  store { i64, ptr } %t691, ptr %l23, !tbaa !27
  %t692 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t694 = extractvalue { i64, ptr } %t692, 0
  %t696 = icmp eq i64 %t694, 0
  br i1 %t696, label %bb165, label %bb166
bb165:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v3, ptr %t698, { i64, ptr } %t699)
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load %"compiler/source:Span", ptr %l1
  %t706 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t702, %"compiler/source:Span" %t703)
  store ptr %t706, ptr %l354
  br label %bb168
bb168:
  %t707 = load ptr, ptr %l354, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t707, ptr %rv
  br label %ret
bb169:
  %t709 = load ptr, ptr %l0, !tbaa !29
  store ptr %t709, ptr %l356, !tbaa !29
  %t710 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t710, ptr %l357
  %t711 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t711, ptr %l358
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t713 = load i32, ptr %l21, !tbaa !23
  %t716 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t712, i32 %t713)
  store { i64, ptr } %t716, ptr %l361
  br label %bb170
bb170:
  %t717 = load { i64, ptr }, ptr %l361, !tbaa !27
  %t718 = extractvalue { i64, ptr } %t717, 0
  %t719 = load %"compiler/source:Span", ptr %l358
  %t721 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t719, i64 %t718)
  store %"compiler/source:Span" %t721, ptr %l363
  br label %bb171
bb171:
  %t722 = load i64, ptr %l22, !tbaa !24
  store i64 %t722, ptr %l364, !tbaa !24
  %t723 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t723, ptr %l365, !tbaa !27
  %t724 = icmp sge i64 0, 0
  br i1 %t724, label %bb172, label %bb173
bb172:
  %t726 = icmp sle i64 0, 1152921504606846975
  br i1 %t726, label %bb174, label %bb175
bb173:
  call void @__olang_check_failed(ptr @olang_loc_428b3df5b28fd586_8d50c863a2687fe2)
  unreachable
bb174:
  %t728 = mul i64 0, 8
  %t729 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t728)
  %t730 = insertvalue { i64, ptr } undef, i64 0, 0
  %t731 = insertvalue { i64, ptr } %t730, ptr %t729, 1
  %t732 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t733 = load ptr, ptr %l356, !tbaa !29
  %t734 = load %"compiler/source:Span", ptr %l357
  %t735 = load %"compiler/source:Span", ptr %l363
  %t736 = load i64, ptr %l364, !tbaa !24
  %t737 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t740 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v3, ptr %v0, ptr %t733, %"compiler/source:Span" %t734, %"compiler/source:Span" %t735, i64 %t736, ptr null, { i64, ptr } %t737, { i64, ptr } %t731, { i64, ptr } %t732)
  store ptr %t740, ptr %l370
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_428b3df5b28fd586_8d50c863a2687fe2)
  unreachable
bb176:
  %t741 = load ptr, ptr %l370, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t741, ptr %rv
  br label %ret
bb177:
  %t743 = load ptr, ptr %l3, !tbaa !29
  store ptr %t743, ptr %l372, !tbaa !29
  store i1 false, ptr %l373, !tbaa !21
  %t744 = load ptr, ptr %l372, !tbaa !29
  %t745 = icmp ne ptr %t744, null
  br i1 %t745, label %bb178, label %bb179
bb178:
  %t747 = load ptr, ptr %l372, !tbaa !29
  %t748 = load i64, ptr %t747
  %t750 = icmp eq i64 %t748, 15
  store i1 %t750, ptr %l373, !tbaa !21
  br label %bb179
bb179:
  %t751 = load i1, ptr %l373, !tbaa !21
  br i1 %t751, label %bb180, label %bb181
bb180:
  %t752 = load ptr, ptr %l3, !tbaa !29
  %t754 = getelementptr { i64, [5 x i64] }, ptr %t752, i32 0, i32 1
  %t755 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t754, i32 0, i32 0
  %t756 = load %"compiler/source:Span", ptr %t755
  store %"compiler/source:Span" %t756, ptr %l24
  %t758 = load ptr, ptr %l3, !tbaa !29
  %t760 = getelementptr { i64, [5 x i64] }, ptr %t758, i32 0, i32 1
  %t761 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t760, i32 0, i32 1
  %t762 = load ptr, ptr %t761
  store ptr %t762, ptr %l25, !tbaa !29
  %t764 = load ptr, ptr %l3, !tbaa !29
  %t766 = getelementptr { i64, [5 x i64] }, ptr %t764, i32 0, i32 1
  %t767 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t766, i32 0, i32 2
  %t768 = load i32, ptr %t767
  store i32 %t768, ptr %l26, !tbaa !23
  br label %bb182
bb181:
  br label %bb222
bb182:
  %t770 = load ptr, ptr %l0, !tbaa !29
  %t772 = getelementptr %"compiler/check:Checker", ptr %t770, i32 0, i32 1
  %t773 = load ptr, ptr %t772, !tbaa !29
  %t775 = getelementptr %"compiler/generic:Program", ptr %t773, i32 0, i32 1
  %t776 = load ptr, ptr %t775, !tbaa !29
  store ptr %t776, ptr %l384, !tbaa !29
  %t777 = load ptr, ptr %l0, !tbaa !29
  %t779 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t777)
  store ptr %t779, ptr %l386
  br label %bb183
bb183:
  %t780 = load ptr, ptr %l386, !tbaa !29
  %t782 = getelementptr %"compiler/check:frame", ptr %t780, i32 0, i32 2
  %t783 = load i64, ptr %t782, !tbaa !24
  %t784 = getelementptr %"compiler/source:Span", ptr %l24, i32 0, i32 1
  %t785 = load i32, ptr %t784, !tbaa !23
  %t786 = load ptr, ptr %l384, !tbaa !29
  %t789 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t786, i64 %t783, i32 %t785)
  store %"compiler/names:Ref" %t789, ptr %l390
  br label %bb184
bb184:
  %t790 = load %"compiler/names:Ref", ptr %l390
  store %"compiler/names:Ref" %t790, ptr %l27
  %t791 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 0
  %t792 = load i32, ptr %t791
  %t794 = trunc i64 4 to i32
  %t795 = icmp eq i32 %t792, %t794
  br i1 %t795, label %bb185, label %bb186
bb185:
  %t797 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 2
  %t798 = load i64, ptr %t797, !tbaa !24
  %t800 = icmp sge i64 %t798, 0
  store i1 %t800, ptr %l393, !tbaa !21
  br label %bb187
bb186:
  store i1 false, ptr %l393, !tbaa !21
  br label %bb187
bb187:
  %t802 = load i1, ptr %l393, !tbaa !21
  br i1 %t802, label %bb188, label %bb189
bb188:
  %t803 = load ptr, ptr %l0, !tbaa !29
  %t805 = getelementptr %"compiler/check:Checker", ptr %t803, i32 0, i32 1
  %t806 = load ptr, ptr %t805, !tbaa !29
  store ptr %t806, ptr %l397, !tbaa !29
  %t807 = load ptr, ptr %l0, !tbaa !29
  %t809 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t807)
  store ptr %t809, ptr %l399
  br label %bb190
bb189:
  br label %bb207
bb190:
  %t810 = load ptr, ptr %l399, !tbaa !29
  %t812 = getelementptr %"compiler/check:frame", ptr %t810, i32 0, i32 4
  store ptr %t812, ptr %l401, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t815 = getelementptr %"compiler/check:Checker", ptr %t813, i32 0, i32 1
  %t816 = load ptr, ptr %t815, !tbaa !29
  %t817 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 1
  %t818 = load i64, ptr %t817, !tbaa !24
  %t819 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 2
  %t820 = load i64, ptr %t819, !tbaa !24
  %t824 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t816, i64 %t818, i64 %t820)
  store i32 %t824, ptr %l406
  br label %bb191
bb191:
  %t825 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t826 = load ptr, ptr %l397, !tbaa !29
  %t827 = load ptr, ptr %l401, !tbaa !29
  %t828 = load i32, ptr %l406, !tbaa !23
  %t830 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v2, ptr %t826, ptr %t827, i32 %t828, { i64, ptr } %t825)
  store i32 %t830, ptr %l408
  br label %bb192
bb192:
  %t831 = load i32, ptr %l408, !tbaa !23
  store i32 %t831, ptr %l28, !tbaa !23
  %t832 = load i32, ptr %l28, !tbaa !23
  %t833 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t836 = icmp eq i32 %t832, %t833
  br i1 %t836, label %bb193, label %bb194
bb193:
  %t838 = load ptr, ptr %l0, !tbaa !29
  %t839 = load %"compiler/source:Span", ptr %l1
  %t842 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t838, %"compiler/source:Span" %t839)
  store ptr %t842, ptr %l414
  br label %bb195
bb194:
  br label %bb196
bb195:
  %t843 = load ptr, ptr %l414, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t843, ptr %rv
  br label %ret
bb196:
  %t845 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t847 = extractvalue { i64, ptr } %t845, 0
  %t849 = icmp sgt i64 %t847, 0
  br i1 %t849, label %bb197, label %bb198
bb197:
  %t851 = load ptr, ptr %l0, !tbaa !29
  store ptr %t851, ptr %l420, !tbaa !29
  %t852 = load i32, ptr %l28, !tbaa !23
  store i32 %t852, ptr %l421, !tbaa !23
  %t853 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t853, ptr %l422, !tbaa !27
  %t854 = getelementptr { i64, ptr }, ptr %l422, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = getelementptr ptr, ptr %t855, i64 0
  %t857 = load ptr, ptr %t856, !tbaa !39
  %t859 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t857)
  store %"compiler/source:Span" %t859, ptr %l424
  br label %bb199
bb198:
  store i1 false, ptr %l419, !tbaa !21
  br label %bb201
bb199:
  %t860 = load ptr, ptr %l420, !tbaa !29
  %t861 = load i32, ptr %l421, !tbaa !23
  %t862 = load %"compiler/source:Span", ptr %l424
  %t863 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t860, i32 %t861, %"compiler/source:Span" %t862)
  store i1 %t863, ptr %l425
  br label %bb200
bb200:
  %t864 = load i1, ptr %l425, !tbaa !21
  %t865 = xor i1 %t864, true
  store i1 %t865, ptr %l419, !tbaa !21
  br label %bb201
bb201:
  %t867 = load i1, ptr %l419, !tbaa !21
  br i1 %t867, label %bb202, label %bb203
bb202:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t869 = load %"compiler/source:Span", ptr %l1
  %t872 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t868, %"compiler/source:Span" %t869)
  store ptr %t872, ptr %l429
  br label %bb204
bb203:
  br label %bb205
bb204:
  %t873 = load ptr, ptr %l429, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t873, ptr %rv
  br label %ret
bb205:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t876 = load %"compiler/source:Span", ptr %l1
  %t877 = load %"compiler/source:Span", ptr %l24
  %t878 = load i32, ptr %l28, !tbaa !23
  %t879 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t885 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v3, ptr %t875, %"compiler/source:Span" %t876, %"compiler/source:Span" %t877, i32 %t878, { i64, ptr } %t879)
  store ptr %t885, ptr %l436
  br label %bb206
bb206:
  %t886 = load ptr, ptr %l436, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t886, ptr %rv
  br label %ret
bb207:
  %t888 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 0
  %t889 = load i32, ptr %t888
  %t891 = trunc i64 0 to i32
  %t892 = icmp eq i32 %t889, %t891
  br i1 %t892, label %bb208, label %bb209
bb208:
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t895 = load ptr, ptr %l25, !tbaa !29
  %t898 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %t894, ptr %t895)
  store i1 %t898, ptr %l443
  br label %bb210
bb209:
  store i1 false, ptr %l440, !tbaa !21
  br label %bb211
bb210:
  %t899 = load i1, ptr %l443, !tbaa !21
  %t900 = xor i1 %t899, true
  store i1 %t900, ptr %l440, !tbaa !21
  br label %bb211
bb211:
  %t902 = load i1, ptr %l440, !tbaa !21
  br i1 %t902, label %bb212, label %bb213
bb212:
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load ptr, ptr %l25, !tbaa !29
  %t907 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t903, ptr %t904)
  store i32 %t907, ptr %l448
  br label %bb214
bb213:
  store i1 false, ptr %l445, !tbaa !21
  br label %bb215
bb214:
  %t908 = load i32, ptr %l448, !tbaa !23
  %t909 = icmp slt i32 %t908, 0
  store i1 %t909, ptr %l445, !tbaa !21
  br label %bb215
bb215:
  %t911 = load i1, ptr %l445, !tbaa !21
  br i1 %t911, label %bb216, label %bb217
bb216:
  %t912 = load ptr, ptr %l0, !tbaa !29
  store ptr %t912, ptr %l450, !tbaa !29
  %t913 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t913, ptr %l451
  %t914 = load ptr, ptr %l25, !tbaa !29
  store ptr %t914, ptr %l452, !tbaa !29
  %t915 = load i32, ptr %l26, !tbaa !23
  store i32 %t915, ptr %l453, !tbaa !23
  %t916 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t916, ptr %l454
  %t917 = load ptr, ptr %l0, !tbaa !29
  %t918 = load i32, ptr %l26, !tbaa !23
  %t921 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t917, i32 %t918)
  store { i64, ptr } %t921, ptr %l457
  br label %bb218
bb217:
  br label %bb221
bb218:
  %t922 = load { i64, ptr }, ptr %l457, !tbaa !27
  %t923 = extractvalue { i64, ptr } %t922, 0
  %t924 = load %"compiler/source:Span", ptr %l454
  %t926 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t924, i64 %t923)
  store %"compiler/source:Span" %t926, ptr %l459
  br label %bb219
bb219:
  %t927 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t928 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t929 = load %"compiler/source:Span", ptr %l2
  %t930 = load ptr, ptr %l450, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l451
  %t932 = load ptr, ptr %l452, !tbaa !29
  %t933 = load i32, ptr %l453, !tbaa !23
  %t934 = load %"compiler/source:Span", ptr %l459
  %t938 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v3, ptr %v2, ptr %t930, %"compiler/source:Span" %t931, ptr %t932, i32 %t933, %"compiler/source:Span" %t934, { i64, ptr } %t927, { i64, ptr } %t928, %"compiler/source:Span" %t929)
  store ptr %t938, ptr %l463
  br label %bb220
bb220:
  %t939 = load ptr, ptr %l463, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t939, ptr %rv
  br label %ret
bb221:
  br label %bb223
bb222:
  br label %bb223
bb223:
  %t941 = load ptr, ptr %l0, !tbaa !29
  %t942 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t941, %"compiler/source:Span" %t942, { i64, ptr } { i64 27, ptr @.d15 })
  br label %bb224
bb224:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  %t949 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t945, %"compiler/source:Span" %t946)
  store ptr %t949, ptr %l469
  br label %bb225
bb225:
  %t950 = load ptr, ptr %l469, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t950, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca ptr
  %l44 = alloca ptr
  %l48 = alloca %"compiler/names:Ref"
  %l55 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l24
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l24
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 3 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t53 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i32, ptr %l3, !tbaa !23
  %t59 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t52, i64 %t54, i32 %t55)
  store i64 %t59, ptr %l31
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t60 = load i64, ptr %l31, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb11:
  br label %bb25
bb12:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t62 = load ptr, ptr %l32, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l32, !tbaa !29
  %t66 = load i64, ptr %t65
  %t68 = icmp eq i64 %t66, 15
  store i1 %t68, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l33, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [5 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/source:Span", ptr %t73
  store %"compiler/source:Span" %t74, ptr %l5
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t78, i32 0, i32 2
  %t80 = load i32, ptr %t79
  store i32 %t80, ptr %l6, !tbaa !23
  br label %bb17
bb16:
  br label %bb24
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  store ptr %t88, ptr %l42, !tbaa !29
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t89)
  store ptr %t91, ptr %l44
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l44, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 2
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l42, !tbaa !29
  %t101 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t98, i64 %t95, i32 %t97)
  store %"compiler/names:Ref" %t101, ptr %l48
  br label %bb19
bb19:
  %t102 = load %"compiler/names:Ref", ptr %l48
  store %"compiler/names:Ref" %t102, ptr %l7
  %t103 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t104 = load i32, ptr %t103
  %t106 = trunc i64 3 to i32
  %t107 = icmp eq i32 %t104, %t106
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load i32, ptr %l6, !tbaa !23
  %t119 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t112, i64 %t114, i32 %t115)
  store i64 %t119, ptr %l55
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t120 = load i64, ptr %l55, !tbaa !24
  store i64 %t120, ptr %rv
  br label %ret
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v1, i64 %a1)
  store %"compiler/check:b5aWalk" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load %"compiler/check:b5aWalk", ptr %l6
  %t6 = load ptr, ptr %lp3
  store %"compiler/check:b5aWalk" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t7, ptr %t8, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %lp3
  %t14 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 7
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load ptr, ptr %lp3
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t18, i32 0, i32 2
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %lp3
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %lp3
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 2
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38, i64 %t39)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t44 = load ptr, ptr %lp3
  %t45 = getelementptr %"compiler/check:b5aWalk", ptr %t44, i32 0, i32 3
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindexPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca ptr
  %l16 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store ptr %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l7, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v2, ptr %t12, %"compiler/source:Span" %a1, ptr %t14, { i64, ptr } %a3, i32 0)
  store ptr %t21, ptr %l16
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l16, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t12, i32 %a1)
  store i32 %t16, ptr %l10
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l11
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l2, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = icmp eq i64 %t23, 1
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i32, ptr %t29, i64 0
  %t31 = load i32, ptr %t30, !tbaa !33
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t37 = load i1, ptr %l15, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstHoldsItself(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i64
  %l36 = alloca i64
  %l54 = alloca i64
  %l56 = alloca i64
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  store ptr %t17, ptr %l19, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l24
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = load i32, ptr %l24, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t28, i32 %t29)
  store { i64, ptr } %t30, ptr %l25
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v1, ptr %s0, ptr %a3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l27
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l5
  store i64 0, ptr %l6, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb10:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb12
bb12:
  %t66 = load i64, ptr %l36, !tbaa !24
  store i64 %t66, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t67 = load i64, ptr %l33, !tbaa !24
  store i64 %t67, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l10, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb16:
  br label %bb17
bb17:
  %t76 = load i64, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l11, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  store i64 %t86, ptr %l54, !tbaa !24
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l5)
  store i64 %t88, ptr %l56
  br label %bb18
bb18:
  %t89 = load i64, ptr %l54, !tbaa !24
  %t90 = load i64, ptr %l56, !tbaa !24
  %t91 = icmp slt i64 %t89, %t90
  br i1 %t91, label %bb19, label %bb20
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = load i64, ptr %l11, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i32, ptr %t98, i64 %t95
  %t100 = load i32, ptr %t99, !tbaa !33
  %t101 = load i32, ptr %l1, !tbaa !23
  %t105 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t93, i32 %t100, i32 %t101, i64 0)
  store i1 %t105, ptr %l64
  br label %bb21
bb20:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb22
bb21:
  %t106 = load i1, ptr %l64, !tbaa !21
  store i1 %t106, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t107 = load i1, ptr %l58, !tbaa !21
  br i1 %t107, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l65, !tbaa !29
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l5, i64 %t109)
  store %"compiler/source:Span" %t112, ptr %l68
  br label %bb25
bb24:
  br label %bb29
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t113, i32 %t114)
  store { i64, ptr } %t117, ptr %l71
  br label %bb26
bb26:
  %t118 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  %t126 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %s4, ptr %s4, { i64, ptr } %t124)
  store %"compiler/msgs:Msg" %t126, ptr %l73
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l65, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l68
  %t129 = load %"compiler/msgs:Msg", ptr %l73
  %t130 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t127, %"compiler/source:Span" %t128, %"compiler/msgs:Msg" %t129)
  store i64 %t130, ptr %l74
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t133 = add i64 %t131, 1
  store i64 %t133, ptr %l10, !tbaa !24
  br label %bb14
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisGlobalBody(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 11
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 6
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l56 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l15
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t3, ptr %lp2
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t5 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 23
  store ptr %t8, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t10, i64 %t11)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l22
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb4, label %ok.18
ok.18:
  store { i64, ptr } %t15, ptr %l21
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  br label %bb8
bb4:
  %t20 = load i32, ptr %l22, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_1010397456489e66_cacc16b72eedbd12)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t25, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t38 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i32, ptr %t42, i64 %t39
  %t44 = load i32, ptr %t43, !tbaa !33
  %t46 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t46, i32 %t44)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l7, !tbaa !24
  br label %bb9
bb15:
  %t54 = load i64, ptr %l4, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = add i64 %t54, %t55
  store i64 %t58, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  br label %bb2
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 24
  store ptr %t62, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t64 = load ptr, ptr %l9, !tbaa !29
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t64, i64 %t65)
  %t69 = extractvalue { i32, { i64, ptr } } %t68, 1
  %t70 = extractvalue { i32, { i64, ptr } } %t68, 0
  store i32 %t70, ptr %l47
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb20, label %ok.72
ok.72:
  store { i64, ptr } %t69, ptr %l46
  br label %bb19
bb19:
  %t73 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t73, ptr %l43, !tbaa !27
  br label %bb24
bb20:
  %t74 = load i32, ptr %l47, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  br i1 %t77, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fb9d93c6082892c7_80b52fbeeb5e713)
  unreachable
bb23:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb24:
  %t79 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t79, ptr %l11, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t84 = load i64, ptr %l13, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t92 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t92, ptr %l56, !tbaa !27
  %t93 = load i64, ptr %l13, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t100 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t100, i32 %t98)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t104 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = add i64 %t108, %t109
  store i64 %t112, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  br label %bb18
bb33:
  %t114 = load ptr, ptr %lp2
  %t115 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t114
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  %t86 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l12
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb15
bb15:
  %t36 = load i32, ptr %l22
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb19
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb23
bb21:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb22
bb22:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store ptr null, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l42
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l44
  br label %bb28
bb28:
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l45, !tbaa !23
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = icmp sle i64 1, 1152921504606846975
  br i1 %t81, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb31:
  %t83 = mul i64 1, 8
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load ptr, ptr %l46, !tbaa !29
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr ptr, ptr %t84, i64 %t90
  store ptr %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l42
  %t98 = load %"compiler/source:Span", ptr %l44
  %t99 = load i32, ptr %l45, !tbaa !23
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v0, ptr %t96, %"compiler/source:Span" %t97, %"compiler/source:Span" %t98, i32 %t99, { i64, ptr } %t95)
  store ptr %t101, ptr %l50
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb33:
  %t102 = load ptr, ptr %l50, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l21 = alloca %"compiler/typed:Local"
  %l22 = alloca i32
  %l26 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i32
  %l41 = alloca %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t5)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 7
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t26 = call %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %s0, i32 %t8, %"compiler/source:Span" %a2, i32 %a3, i32 %t16, i32 %a4, { i64, [2 x i64] } %a5)
  store %"compiler/typed:Local" %t26, ptr %l21
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l11, !tbaa !29
  %t28 = load %"compiler/typed:Local", ptr %l21
  %t29 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %t27, %"compiler/typed:Local" %t28)
  store i32 %t29, ptr %l22
  br label %bb4
bb4:
  %t30 = load i32, ptr %l22, !tbaa !23
  %t31 = sext i32 %t30 to i64
  store i64 %t31, ptr %l7, !tbaa !24
  %t33 = load i32, ptr %l1, !tbaa !23
  %t35 = icmp ne i32 %t33, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l1, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l29
  br label %bb7
bb6:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb9
bb7:
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 1, ptr @.d16 })
  store i1 %t43, ptr %l30
  br label %bb8
bb8:
  %t44 = load i1, ptr %l30, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb9
bb9:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t50 = getelementptr %"compiler/check:frame", ptr %t48, i32 0, i32 9
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  store i32 %t51, ptr %l34, !tbaa !23
  %t52 = load ptr, ptr %l6, !tbaa !29
  %t54 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 8
  %t55 = load i32, ptr %l1, !tbaa !23
  %t58 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t54, i32 %t55)
  %t59 = extractvalue { i32, i64 } %t58, 1
  %t60 = extractvalue { i32, i64 } %t58, 0
  store i32 %t60, ptr %l40
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62
ok.62:
  store i64 %t59, ptr %l39
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t63 = load i64, ptr %l39, !tbaa !24
  store i64 %t63, ptr %l35, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i32, ptr %l34, !tbaa !23
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = call %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %s1, i32 %t64, i64 %t65)
  store %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t66, ptr %l41
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed", ptr %l41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %t67, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %t68)
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 8
  %t72 = load i32, ptr %l1, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t71, i32 %t72, i64 %t73)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  %t77 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/names:Ref"
  %l32 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Catch", ptr %t1, i32 0, i32 5
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp ne i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/ast:Catch", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t15 = icmp ne i64 %t13, 1
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/ast:Catch", ptr %t18, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l12, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 0
  %t25 = load ptr, ptr %t24, !tbaa !39
  %t27 = getelementptr %"compiler/ast:Path", ptr %t25, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp ne i64 %t30, 1
  store i1 %t32, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l18, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l21, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t44)
  store ptr %t46, ptr %l23
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l23, !tbaa !29
  %t49 = getelementptr %"compiler/check:frame", ptr %t47, i32 0, i32 2
  %t50 = load i64, ptr %t49, !tbaa !24
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Catch", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l27, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr ptr, ptr %t56, i64 0
  %t58 = load ptr, ptr %t57, !tbaa !39
  %t60 = getelementptr %"compiler/ast:Path", ptr %t58, i32 0, i32 0
  %t61 = getelementptr %"compiler/source:Span", ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l21, !tbaa !29
  %t66 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t63, i64 %t50, i32 %t62)
  store %"compiler/names:Ref" %t66, ptr %l30
  br label %bb11
bb11:
  %t67 = getelementptr %"compiler/names:Ref", ptr %l30, i32 0, i32 0
  %t68 = load i32, ptr %t67
  %t69 = load ptr, ptr %l18, !tbaa !29
  %t71 = call i1 @compiler_2fnames_2eLoneCatchName(ptr %v1, ptr %t69, i32 %t68)
  store i1 %t71, ptr %l32
  br label %bb12
bb12:
  %t72 = load i1, ptr %l32, !tbaa !21
  store i1 %t72, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca ptr
  %l43 = alloca i32
  %l45 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i1
  %l79 = alloca ptr
  %l82 = alloca i1
  %l85 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca i32
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca { i64, ptr }
  %l100 = alloca %"compiler/msgs:Msg"
  %l101 = alloca i64
  %l106 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca i1
  %l127 = alloca i1
  %l131 = alloca i64
  %l133 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l141 = alloca { i64, ptr }
  %l143 = alloca %"compiler/msgs:Msg"
  %l144 = alloca i64
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l147 = alloca %"compiler/source:Span"
  %l148 = alloca i64
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca i32
  %l176 = alloca ptr
  %l178 = alloca ptr
  %l181 = alloca i32
  %l183 = alloca i64
  %l187 = alloca ptr
  %l190 = alloca i32
  %l192 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l194 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l201 = alloca i32
  %l202 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca %"compiler/msgs:Msg"
  %l209 = alloca i64
  %l214 = alloca ptr
  %l216 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i1
  %l231 = alloca i1
  %l232 = alloca ptr
  %l234 = alloca %"compiler/source:Span"
  %l235 = alloca ptr
  %l237 = alloca %"compiler/source:Span"
  %l238 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca ptr
  %l245 = alloca %"compiler/source:Span"
  %l246 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l249 = alloca %"compiler/msgs:Msg"
  %l250 = alloca i64
  %l255 = alloca i32
  %l258 = alloca i1
  %l260 = alloca i1
  %l261 = alloca i1
  %l265 = alloca i1
  %l268 = alloca i32
  %l271 = alloca ptr
  %l272 = alloca %"compiler/source:Span"
  %l274 = alloca i32
  %l277 = alloca ptr
  %l280 = alloca i1
  %l283 = alloca i32
  %l286 = alloca i1
  %l287 = alloca ptr
  %l290 = alloca i32
  %l291 = alloca i1
  %l296 = alloca ptr
  %l299 = alloca i1
  %l301 = alloca i1
  %l303 = alloca i1
  %l304 = alloca ptr
  %l307 = alloca i32
  %l308 = alloca i1
  %l309 = alloca i1
  %l310 = alloca ptr
  %l313 = alloca i32
  %l314 = alloca i1
  %l315 = alloca i1
  %l317 = alloca ptr
  %l320 = alloca i32
  %l321 = alloca i1
  %l323 = alloca i1
  %l324 = alloca ptr
  %l327 = alloca i32
  %l329 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l332 = alloca ptr
  %l335 = alloca i32
  %l336 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l342 = alloca %"compiler/msgs:Msg"
  %l343 = alloca i64
  %l348 = alloca ptr
  %l358 = alloca ptr
  %l365 = alloca i32
  %l368 = alloca i1
  %l369 = alloca i1
  %l373 = alloca i64
  %l376 = alloca ptr
  %l380 = alloca %"compiler/source:Span"
  %l381 = alloca i32
  %l382 = alloca ptr
  %l383 = alloca ptr
  %l384 = alloca i32
  %l386 = alloca %"compiler/source:Span"
  %l387 = alloca i32
  %l390 = alloca ptr
  %l391 = alloca %"compiler/source:Span"
  %l392 = alloca %"compiler/source:Span"
  %l397 = alloca ptr
  %l401 = alloca ptr
  %l402 = alloca %"compiler/source:Span"
  %l403 = alloca %"compiler/source:Span"
  %l407 = alloca ptr
  %l409 = alloca ptr
  %l412 = alloca i1
  %l413 = alloca i1
  %l416 = alloca i32
  %l423 = alloca ptr
  %l425 = alloca i1
  %l426 = alloca i1
  %l428 = alloca i1
  %l431 = alloca ptr
  %l432 = alloca %"compiler/source:Span"
  %l435 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l439 = alloca { i64, ptr }
  %l441 = alloca %"compiler/msgs:Msg"
  %l442 = alloca i64
  %l447 = alloca ptr
  %l448 = alloca { i64, ptr }
  %l450 = alloca i1
  %l452 = alloca i1
  %l456 = alloca i64
  %l458 = alloca ptr
  %l462 = alloca ptr
  %l463 = alloca %"compiler/source:Span"
  %l466 = alloca { i64, ptr }
  %l468 = alloca %"compiler/msgs:Msg"
  %l469 = alloca i64
  %l470 = alloca ptr
  %l471 = alloca %"compiler/source:Span"
  %l472 = alloca %"compiler/source:Span"
  %l473 = alloca i64
  %l475 = alloca ptr
  %l476 = alloca { i64, ptr }
  %l479 = alloca { i64, ptr }
  %l483 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca ptr
  %t757 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t1, ptr %t2, i32 %t4)
  store ptr %t8, ptr %l24
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l24, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t13 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t10)
  store i32 %t13, ptr %l27
  br label %bb2
bb2:
  %t14 = load i32, ptr %l27, !tbaa !23
  store i32 %t14, ptr %l9, !tbaa !23
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t19 = icmp eq i32 %t15, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t21, { i64, ptr } %t22)
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  %t29 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t25, %"compiler/source:Span" %t26)
  store ptr %t29, ptr %l35
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load ptr, ptr %l35, !tbaa !29
  store ptr %t30, ptr %rv
  br label %ret
bb7:
  %t31 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l40, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i32, ptr %l9, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l43
  br label %bb10
bb9:
  br label %bb74
bb10:
  %t46 = load i32, ptr %l3, !tbaa !23
  %t47 = load ptr, ptr %l40, !tbaa !29
  %t48 = load i32, ptr %l43, !tbaa !23
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t47, i32 %t48, i32 %t46)
  store i64 %t50, ptr %l45
  br label %bb11
bb11:
  %t51 = load i64, ptr %l45, !tbaa !24
  store i64 %t51, ptr %l10, !tbaa !24
  %t52 = load i64, ptr %l10, !tbaa !24
  %t54 = icmp slt i64 %t52, 0
  br i1 %t54, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l49, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load i32, ptr %l9, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l52
  br label %bb14
bb13:
  br label %bb21
bb14:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l49, !tbaa !29
  %t67 = load i32, ptr %l52, !tbaa !23
  %t69 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s3, ptr %t66, i32 %t67, i32 %t65)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l54
  br label %bb15
bb15:
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l11
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s3, ptr %l11)
  store i64 %t72, ptr %l56
  br label %bb16
bb16:
  %t73 = load i64, ptr %l56, !tbaa !24
  %t74 = icmp eq i64 %t73, 1
  br i1 %t74, label %bb17, label %bb18
bb17:
  %t77 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s3, ptr %l11, i64 0)
  store i64 %t77, ptr %l59
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t78 = load i64, ptr %l59, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t83, i32 %t84)
  store { i64, ptr } %t87, ptr %l65
  br label %bb24
bb23:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb26
bb24:
  %t88 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t88, { i64, ptr } { i64 6, ptr @.d17 })
  store i1 %t89, ptr %l66
  br label %bb25
bb25:
  %t90 = load i1, ptr %l66, !tbaa !21
  store i1 %t90, ptr %l62, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l62, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l68, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l9, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l71
  br label %bb29
bb28:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb31
bb29:
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t99 = load i32, ptr %l71, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t98, i32 %t99)
  store i1 %t100, ptr %l72
  br label %bb30
bb30:
  %t101 = load i1, ptr %l72, !tbaa !21
  store i1 %t101, ptr %l67, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l67, !tbaa !21
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  %t105 = load %"compiler/source:Span", ptr %l4
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t115 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v3, ptr %v2, ptr %t103, %"compiler/source:Span" %t104, %"compiler/source:Span" %t105, ptr %t106, { i64, ptr } %t107, { i64, ptr } %t108)
  store ptr %t115, ptr %l79
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load ptr, ptr %l79, !tbaa !29
  store ptr %t116, ptr %rv
  br label %ret
bb35:
  %t117 = load i64, ptr %l10, !tbaa !24
  %t119 = icmp slt i64 %t117, 0
  br i1 %t119, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb40
bb37:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  store ptr %t126, ptr %l85, !tbaa !29
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l9, !tbaa !23
  %t131 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l88
  br label %bb38
bb38:
  %t132 = load ptr, ptr %l85, !tbaa !29
  %t133 = load i32, ptr %l88, !tbaa !23
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t132, i32 %t133)
  store i32 %t134, ptr %l89
  br label %bb39
bb39:
  %t135 = load i32, ptr %l89
  %t137 = trunc i64 29 to i32
  %t138 = icmp eq i32 %t135, %t137
  store i1 %t138, ptr %l82, !tbaa !21
  br label %bb40
bb40:
  %t140 = load i1, ptr %l82, !tbaa !21
  br i1 %t140, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l92, !tbaa !29
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t142, ptr %l93, !tbaa !27
  %t143 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr ptr, ptr %t144, i64 0
  %t146 = load ptr, ptr %t145, !tbaa !39
  %t148 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t146)
  store %"compiler/source:Span" %t148, ptr %l95
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i32, ptr %l3, !tbaa !23
  %t153 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t149, i32 %t150)
  store { i64, ptr } %t153, ptr %l98
  br label %bb44
bb44:
  %t154 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %s6, ptr %s6, { i64, ptr } %t160)
  store %"compiler/msgs:Msg" %t162, ptr %l100
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l92, !tbaa !29
  %t164 = load %"compiler/source:Span", ptr %l95
  %t165 = load %"compiler/msgs:Msg", ptr %l100
  %t166 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t163, %"compiler/source:Span" %t164, %"compiler/msgs:Msg" %t165)
  store i64 %t166, ptr %l101
  br label %bb46
bb46:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t167, { i64, ptr } %t168)
  br label %bb47
bb47:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load %"compiler/source:Span", ptr %l1
  %t175 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t171, %"compiler/source:Span" %t172)
  store ptr %t175, ptr %l106
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t176 = load ptr, ptr %l106, !tbaa !29
  store ptr %t176, ptr %rv
  br label %ret
bb49:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l10, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t185 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v3, ptr %t177, i64 %t178, { i64, ptr } %t179, %"compiler/source:Span" %a7)
  store { i64, ptr } %t185, ptr %l111
  br label %bb50
bb50:
  %t186 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t186, ptr %l12, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = icmp eq i64 %t189, 0
  br i1 %t191, label %bb51, label %bb52
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t193, { i64, ptr } %t194)
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l1
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t197, %"compiler/source:Span" %t198)
  store ptr %t201, ptr %l119
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load ptr, ptr %l119, !tbaa !29
  store ptr %t202, ptr %rv
  br label %ret
bb55:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i32, ptr %l3, !tbaa !23
  %t207 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t203, i32 %t204)
  store { i64, ptr } %t207, ptr %l122
  br label %bb56
bb56:
  %t208 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t208, ptr %l123, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = getelementptr i8, ptr %t210, i64 0
  %t212 = load i8, ptr %t211, !tbaa !32
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t212)
  store i1 %t214, ptr %l125
  br label %bb57
bb57:
  %t215 = load i1, ptr %l125, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb58, label %bb59
bb58:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t222 = load i64, ptr %l10, !tbaa !24
  %t225 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t221, i64 %t222)
  store i64 %t225, ptr %l131
  br label %bb60
bb59:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb62
bb60:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t226)
  store ptr %t228, ptr %l133
  br label %bb61
bb61:
  %t229 = load ptr, ptr %l133, !tbaa !29
  %t231 = getelementptr %"compiler/check:frame", ptr %t229, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load i64, ptr %l131, !tbaa !24
  %t235 = icmp ne i64 %t233, %t232
  store i1 %t235, ptr %l127, !tbaa !21
  br label %bb62
bb62:
  %t237 = load i1, ptr %l127, !tbaa !21
  br i1 %t237, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s8
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l137, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t239, ptr %l138
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load i32, ptr %l3, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t240, i32 %t241)
  store { i64, ptr } %t244, ptr %l141
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t245 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = mul i64 %t246, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t248)
  call void @llvm.memcpy.p0.p0.i64(ptr %t249, ptr %t247, i64 %t248, i1 false)
  %t250 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s8, ptr %s8, { i64, ptr } %t251)
  store %"compiler/msgs:Msg" %t253, ptr %l143
  br label %bb66
bb66:
  %t254 = load ptr, ptr %l137, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l138
  %t256 = load %"compiler/msgs:Msg", ptr %l143
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t254, %"compiler/source:Span" %t255, %"compiler/msgs:Msg" %t256)
  store i64 %t257, ptr %l144
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s8)
  br label %bb68
bb68:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l145, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t259, ptr %l146
  %t260 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t260, ptr %l147
  %t261 = load i64, ptr %l10, !tbaa !24
  store i64 %t261, ptr %l148, !tbaa !24
  %t262 = load ptr, ptr %l8, !tbaa !29
  store ptr %t262, ptr %l150, !tbaa !29
  %t264 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t264, ptr %l151, !tbaa !27
  %t265 = icmp sge i64 0, 0
  br i1 %t265, label %bb69, label %bb70
bb69:
  %t267 = icmp sle i64 0, 1152921504606846975
  br i1 %t267, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb71:
  %t269 = mul i64 0, 8
  %t270 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t269)
  %t271 = insertvalue { i64, ptr } undef, i64 0, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  %t273 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t274 = load ptr, ptr %l145, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l146
  %t276 = load %"compiler/source:Span", ptr %l147
  %t277 = load i64, ptr %l148, !tbaa !24
  %t278 = load ptr, ptr %l150, !tbaa !29
  %t279 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %t274, %"compiler/source:Span" %t275, %"compiler/source:Span" %t276, i64 %t277, ptr %t278, { i64, ptr } %t279, { i64, ptr } %t272, { i64, ptr } %t273)
  store ptr %t282, ptr %l156
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_d23330c3ef7ea91b_34477ea00961dc87)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t283 = load ptr, ptr %l156, !tbaa !29
  store ptr %t283, ptr %rv
  br label %ret
bb74:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i32, ptr %l3, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t284, i32 %t285)
  store { i64, ptr } %t288, ptr %l159
  br label %bb75
bb75:
  %t289 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t289, ptr %l13, !tbaa !27
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t295 = getelementptr %"compiler/generic:Program", ptr %t293, i32 0, i32 2
  store ptr %t295, ptr %l162, !tbaa !29
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load i32, ptr %l9, !tbaa !23
  %t300 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t296, i32 %t297)
  store i32 %t300, ptr %l165
  br label %bb76
bb76:
  %t301 = load ptr, ptr %l162, !tbaa !29
  %t302 = load i32, ptr %l165, !tbaa !23
  %t303 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t301, i32 %t302)
  store i32 %t303, ptr %l166
  br label %bb77
bb77:
  %t304 = load i32, ptr %l166
  %t306 = trunc i64 29 to i32
  %t307 = icmp eq i32 %t304, %t306
  br i1 %t307, label %bb78, label %bb79
bb78:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/source:Span", ptr %l1
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t312 = load ptr, ptr %l8, !tbaa !29
  %t313 = load i32, ptr %l3, !tbaa !23
  %t314 = load %"compiler/source:Span", ptr %l4
  %t315 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %t309, %"compiler/source:Span" %t310, ptr %t311, ptr %t312, i32 %t313, %"compiler/source:Span" %t314, { i64, ptr } %t315)
  store ptr %t323, ptr %l176
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t324 = load ptr, ptr %l176, !tbaa !29
  store ptr %t324, ptr %rv
  br label %ret
bb81:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/check:Checker", ptr %t325, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !29
  store ptr %t328, ptr %l178, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l9, !tbaa !23
  %t333 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t329, i32 %t330)
  store i32 %t333, ptr %l181
  br label %bb82
bb82:
  %t334 = load i32, ptr %l3, !tbaa !23
  %t335 = load ptr, ptr %l178, !tbaa !29
  %t336 = load i32, ptr %l181, !tbaa !23
  %t338 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t335, i32 %t336, i32 %t334)
  store i64 %t338, ptr %l183
  br label %bb83
bb83:
  %t339 = load i64, ptr %l183, !tbaa !24
  store i64 %t339, ptr %l14, !tbaa !24
  %t340 = load i64, ptr %l14, !tbaa !24
  %t342 = icmp slt i64 %t340, 0
  br i1 %t342, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/check:Checker", ptr %t344, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l187, !tbaa !29
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t349 = load i32, ptr %l9, !tbaa !23
  %t352 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t352, ptr %l190
  br label %bb86
bb85:
  br label %bb104
bb86:
  %t353 = load i32, ptr %l3, !tbaa !23
  %t354 = load ptr, ptr %l187, !tbaa !29
  %t355 = load i32, ptr %l190, !tbaa !23
  %t357 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s10, ptr %t354, i32 %t355, i32 %t353)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t357, ptr %l192
  br label %bb87
bb87:
  %t358 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l192
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t358, ptr %l15
  %t360 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %l15)
  store i64 %t360, ptr %l194
  br label %bb88
bb88:
  %t361 = load i64, ptr %l194, !tbaa !24
  %t362 = icmp sgt i64 %t361, 1
  br i1 %t362, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s11
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l196, !tbaa !29
  %t365 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t365, ptr %l197
  %t366 = load ptr, ptr %l0, !tbaa !29
  store ptr %t366, ptr %l198, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i32, ptr %l9, !tbaa !23
  %t371 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t367, i32 %t368)
  store i32 %t371, ptr %l201
  br label %bb91
bb90:
  br label %bb98
bb91:
  %t372 = load ptr, ptr %l198, !tbaa !29
  %t373 = load i32, ptr %l201, !tbaa !23
  %t374 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s11, ptr %t372, i32 %t373)
  store { i64, ptr } %t374, ptr %l202
  br label %bb92
bb92:
  %t375 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  %t377 = extractvalue { i64, ptr } %t375, 1
  %t378 = mul i64 %t376, 1
  %t379 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t378)
  call void @llvm.memcpy.p0.p0.i64(ptr %t379, ptr %t377, i64 %t378, i1 false)
  %t380 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  store { i64, ptr } %t381, ptr %l203, !tbaa !27
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i32, ptr %l3, !tbaa !23
  %t386 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s11, ptr %t382, i32 %t383)
  store { i64, ptr } %t386, ptr %l206
  br label %bb93
bb93:
  %t387 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 0
  %t389 = extractvalue { i64, ptr } %t387, 1
  %t390 = mul i64 %t388, 1
  %t391 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t390)
  call void @llvm.memcpy.p0.p0.i64(ptr %t391, ptr %t389, i64 %t390, i1 false)
  %t392 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t391, 1
  %t394 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t396 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %s11, ptr %s11, ptr %s11, { i64, ptr } %t394, { i64, ptr } %t393)
  store %"compiler/msgs:Msg" %t396, ptr %l208
  br label %bb94
bb94:
  %t397 = load ptr, ptr %l196, !tbaa !29
  %t398 = load %"compiler/source:Span", ptr %l197
  %t399 = load %"compiler/msgs:Msg", ptr %l208
  %t400 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t397, %"compiler/source:Span" %t398, %"compiler/msgs:Msg" %t399)
  store i64 %t400, ptr %l209
  br label %bb95
bb95:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t401, { i64, ptr } %t402)
  br label %bb96
bb96:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load %"compiler/source:Span", ptr %l1
  %t409 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t405, %"compiler/source:Span" %t406)
  store ptr %t409, ptr %l214
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t410 = load ptr, ptr %l214, !tbaa !29
  store ptr %t410, ptr %rv
  br label %ret
bb98:
  %t412 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s10, ptr %l15)
  store i64 %t412, ptr %l216
  br label %bb99
bb99:
  %t413 = load i64, ptr %l216, !tbaa !24
  %t414 = icmp eq i64 %t413, 1
  br i1 %t414, label %bb100, label %bb101
bb100:
  %t417 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s10, ptr %l15, i64 0)
  store i64 %t417, ptr %l219
  br label %bb102
bb101:
  br label %bb103
bb102:
  %t418 = load i64, ptr %l219, !tbaa !24
  store i64 %t418, ptr %l14, !tbaa !24
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s10)
  br label %bb104
bb104:
  %t419 = load i64, ptr %l14, !tbaa !24
  %t421 = icmp slt i64 %t419, 0
  br i1 %t421, label %bb105, label %bb106
bb105:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i32, ptr %l9, !tbaa !23
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t423, i32 %t424)
  store i1 %t427, ptr %l225
  br label %bb107
bb106:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb108
bb107:
  %t428 = load i1, ptr %l225, !tbaa !21
  store i1 %t428, ptr %l222, !tbaa !21
  br label %bb108
bb108:
  %t429 = load i1, ptr %l222, !tbaa !21
  br i1 %t429, label %bb109, label %bb110
bb109:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !29
  %t435 = getelementptr %"compiler/generic:Program", ptr %t433, i32 0, i32 2
  %t436 = load i32, ptr %l9, !tbaa !23
  %t439 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t435, i32 %t436)
  store i1 %t439, ptr %l231
  br label %bb111
bb110:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb112
bb111:
  %t440 = load i1, ptr %l231, !tbaa !21
  store i1 %t440, ptr %l226, !tbaa !21
  br label %bb112
bb112:
  %t441 = load i1, ptr %l226, !tbaa !21
  br i1 %t441, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s13
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l232, !tbaa !29
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t443)
  store %"compiler/source:Span" %t445, ptr %l234
  br label %bb115
bb114:
  br label %bb125
bb115:
  %t446 = load ptr, ptr %l0, !tbaa !29
  store ptr %t446, ptr %l235, !tbaa !29
  %t447 = load ptr, ptr %l2, !tbaa !29
  %t449 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t447)
  store %"compiler/source:Span" %t449, ptr %l237
  br label %bb116
bb116:
  %t450 = load ptr, ptr %l235, !tbaa !29
  %t451 = load %"compiler/source:Span", ptr %l237
  %t452 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t450, %"compiler/source:Span" %t451)
  store { i64, ptr } %t452, ptr %l238
  br label %bb117
bb117:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load i32, ptr %l9, !tbaa !23
  %t457 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s13, ptr %t453, i32 %t454)
  store { i64, ptr } %t457, ptr %l241
  br label %bb118
bb118:
  %t458 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t459 = extractvalue { i64, ptr } %t458, 0
  %t460 = extractvalue { i64, ptr } %t458, 1
  %t461 = mul i64 %t459, 1
  %t462 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t461)
  call void @llvm.memcpy.p0.p0.i64(ptr %t462, ptr %t460, i64 %t461, i1 false)
  %t463 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t464 = insertvalue { i64, ptr } %t463, ptr %t462, 1
  store { i64, ptr } %t464, ptr %l242, !tbaa !27
  %t465 = load ptr, ptr %l0, !tbaa !29
  store ptr %t465, ptr %l243, !tbaa !29
  %t466 = load ptr, ptr %l2, !tbaa !29
  %t468 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t466)
  store %"compiler/source:Span" %t468, ptr %l245
  br label %bb119
bb119:
  %t469 = load ptr, ptr %l243, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l245
  %t471 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t469, %"compiler/source:Span" %t470)
  store { i64, ptr } %t471, ptr %l246
  br label %bb120
bb120:
  %t472 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t473 = call { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %s13, { i64, ptr } %t472)
  store { i64, ptr } %t473, ptr %l247
  br label %bb121
bb121:
  %t474 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t474, 0
  %t476 = extractvalue { i64, ptr } %t474, 1
  %t477 = mul i64 %t475, 1
  %t478 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t477)
  call void @llvm.memcpy.p0.p0.i64(ptr %t478, ptr %t476, i64 %t477, i1 false)
  %t479 = insertvalue { i64, ptr } undef, i64 %t475, 0
  %t480 = insertvalue { i64, ptr } %t479, ptr %t478, 1
  %t481 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t482 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t484 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %s13, ptr %s13, ptr %s13, { i64, ptr } %t481, { i64, ptr } %t482, { i64, ptr } %t480)
  store %"compiler/msgs:Msg" %t484, ptr %l249
  br label %bb122
bb122:
  %t485 = load ptr, ptr %l232, !tbaa !29
  %t486 = load %"compiler/source:Span", ptr %l234
  %t487 = load %"compiler/msgs:Msg", ptr %l249
  %t488 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t485, %"compiler/source:Span" %t486, %"compiler/msgs:Msg" %t487)
  store i64 %t488, ptr %l250
  br label %bb123
bb123:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t494 = getelementptr %"compiler/generic:Program", ptr %t492, i32 0, i32 2
  %t495 = load i32, ptr %l9, !tbaa !23
  %t498 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %t494, i32 %t495)
  store i32 %t498, ptr %l255
  br label %bb124
bb124:
  %t499 = load i32, ptr %l255, !tbaa !23
  store i32 %t499, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  br label %bb125
bb125:
  %t500 = load i64, ptr %l14, !tbaa !24
  %t502 = icmp slt i64 %t500, 0
  br i1 %t502, label %bb126, label %bb127
bb126:
  %t504 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t506 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t504, { i64, ptr } { i64 3, ptr @.d18 })
  store i1 %t506, ptr %l260
  br label %bb128
bb127:
  store i1 false, ptr %l258, !tbaa !21
  br label %bb129
bb128:
  %t507 = load i1, ptr %l260, !tbaa !21
  store i1 %t507, ptr %l258, !tbaa !21
  br label %bb129
bb129:
  %t508 = load i1, ptr %l258, !tbaa !21
  br i1 %t508, label %bb130, label %bb131
bb130:
  %t509 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t511 = extractvalue { i64, ptr } %t509, 0
  %t513 = icmp eq i64 %t511, 0
  store i1 %t513, ptr %l261, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l261, !tbaa !21
  br label %bb132
bb132:
  %t515 = load i1, ptr %l261, !tbaa !21
  br i1 %t515, label %bb133, label %bb134
bb133:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load i32, ptr %l9, !tbaa !23
  %t520 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t516, i32 %t517)
  store i32 %t520, ptr %l268
  br label %bb135
bb134:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb136
bb135:
  %t521 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t522 = load i32, ptr %l268, !tbaa !23
  %t524 = icmp ne i32 %t522, %t521
  store i1 %t524, ptr %l265, !tbaa !21
  br label %bb136
bb136:
  %t526 = load i1, ptr %l265, !tbaa !21
  br i1 %t526, label %bb137, label %bb138
bb137:
  %t527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t527, ptr %l271, !tbaa !29
  %t528 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t528, ptr %l272
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t529)
  store i32 %t531, ptr %l274
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t532 = load ptr, ptr %l8, !tbaa !29
  %t533 = load ptr, ptr %l271, !tbaa !29
  %t534 = load %"compiler/source:Span", ptr %l272
  %t535 = load i32, ptr %l274, !tbaa !23
  %t538 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t533, %"compiler/source:Span" %t534, i32 %t535, i32 22, ptr %t532, ptr null)
  store ptr %t538, ptr %l277
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  %t539 = load ptr, ptr %l277, !tbaa !29
  store ptr %t539, ptr %rv
  br label %ret
bb141:
  %t540 = load i64, ptr %l14, !tbaa !24
  %t542 = icmp slt i64 %t540, 0
  br i1 %t542, label %bb142, label %bb143
bb142:
  %t544 = load ptr, ptr %l0, !tbaa !29
  %t545 = load i32, ptr %l9, !tbaa !23
  %t548 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t544, i32 %t545)
  store i32 %t548, ptr %l283
  br label %bb144
bb143:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb150
bb144:
  %t549 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t550 = load i32, ptr %l283, !tbaa !23
  %t552 = icmp eq i32 %t550, %t549
  br i1 %t552, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb149
bb146:
  %t554 = load ptr, ptr %l0, !tbaa !29
  store ptr %t554, ptr %l287, !tbaa !29
  %t555 = load ptr, ptr %l0, !tbaa !29
  %t556 = load i32, ptr %l9, !tbaa !23
  %t559 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t555, i32 %t556)
  store i32 %t559, ptr %l290
  br label %bb147
bb147:
  %t560 = load ptr, ptr %l287, !tbaa !29
  %t561 = load i32, ptr %l290, !tbaa !23
  %t562 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebadOver(ptr %v0, ptr %t560, i32 %t561)
  store i1 %t562, ptr %l291
  br label %bb148
bb148:
  %t563 = load i1, ptr %l291, !tbaa !21
  store i1 %t563, ptr %l286, !tbaa !21
  br label %bb149
bb149:
  %t564 = load i1, ptr %l286, !tbaa !21
  store i1 %t564, ptr %l280, !tbaa !21
  br label %bb150
bb150:
  %t565 = load i1, ptr %l280, !tbaa !21
  br i1 %t565, label %bb151, label %bb152
bb151:
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t567 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t566, { i64, ptr } %t567)
  br label %bb153
bb152:
  br label %bb155
bb153:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load %"compiler/source:Span", ptr %l1
  %t574 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t570, %"compiler/source:Span" %t571)
  store ptr %t574, ptr %l296
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s0)
  %t575 = load ptr, ptr %l296, !tbaa !29
  store ptr %t575, ptr %rv
  br label %ret
bb155:
  %t576 = load i64, ptr %l14, !tbaa !24
  %t578 = icmp slt i64 %t576, 0
  br i1 %t578, label %bb156, label %bb157
bb156:
  %t580 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t582 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t580, { i64, ptr } { i64 3, ptr @.d19 })
  store i1 %t582, ptr %l301
  br label %bb158
bb157:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb159
bb158:
  %t583 = load i1, ptr %l301, !tbaa !21
  %t584 = xor i1 %t583, true
  store i1 %t584, ptr %l299, !tbaa !21
  br label %bb159
bb159:
  %t586 = load i1, ptr %l299, !tbaa !21
  br i1 %t586, label %bb160, label %bb161
bb160:
  %t587 = load ptr, ptr %l0, !tbaa !29
  store ptr %t587, ptr %l304, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i32, ptr %l9, !tbaa !23
  %t592 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t588, i32 %t589)
  store i32 %t592, ptr %l307
  br label %bb162
bb161:
  store i1 false, ptr %l303, !tbaa !21
  br label %bb164
bb162:
  %t593 = load ptr, ptr %l304, !tbaa !29
  %t594 = load i32, ptr %l307, !tbaa !23
  %t595 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t593, i32 %t594)
  store i1 %t595, ptr %l308
  br label %bb163
bb163:
  %t596 = load i1, ptr %l308, !tbaa !21
  store i1 %t596, ptr %l303, !tbaa !21
  br label %bb164
bb164:
  %t597 = load i1, ptr %l303, !tbaa !21
  br i1 %t597, label %bb165, label %bb166
bb165:
  %t598 = load ptr, ptr %l0, !tbaa !29
  store ptr %t598, ptr %l310, !tbaa !29
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load i32, ptr %l9, !tbaa !23
  %t603 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t599, i32 %t600)
  store i32 %t603, ptr %l313
  br label %bb167
bb166:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb169
bb167:
  %t604 = load ptr, ptr %l310, !tbaa !29
  %t605 = load i32, ptr %l313, !tbaa !23
  %t606 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %t604, i32 %t605)
  store i1 %t606, ptr %l314
  br label %bb168
bb168:
  %t607 = load i1, ptr %l314, !tbaa !21
  store i1 %t607, ptr %l309, !tbaa !21
  br label %bb169
bb169:
  %t608 = load i1, ptr %l309, !tbaa !21
  br i1 %t608, label %bb170, label %bb171
bb170:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t611 = getelementptr %"compiler/check:Checker", ptr %t609, i32 0, i32 1
  %t612 = load ptr, ptr %t611, !tbaa !29
  store ptr %t612, ptr %l317, !tbaa !29
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load i32, ptr %l9, !tbaa !23
  %t617 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t613, i32 %t614)
  store i32 %t617, ptr %l320
  br label %bb172
bb171:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb174
bb172:
  %t618 = load ptr, ptr %l317, !tbaa !29
  %t619 = load i32, ptr %l320, !tbaa !23
  %t620 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t618, i32 %t619)
  store i1 %t620, ptr %l321
  br label %bb173
bb173:
  %t621 = load i1, ptr %l321, !tbaa !21
  %t622 = xor i1 %t621, true
  store i1 %t622, ptr %l315, !tbaa !21
  br label %bb174
bb174:
  %t624 = load i1, ptr %l315, !tbaa !21
  br i1 %t624, label %bb175, label %bb176
bb175:
  %t625 = load ptr, ptr %l0, !tbaa !29
  store ptr %t625, ptr %l324, !tbaa !29
  %t626 = load ptr, ptr %l0, !tbaa !29
  %t627 = load i32, ptr %l9, !tbaa !23
  %t630 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t626, i32 %t627)
  store i32 %t630, ptr %l327
  br label %bb177
bb176:
  store i1 false, ptr %l323, !tbaa !21
  br label %bb179
bb177:
  %t631 = load i32, ptr %l3, !tbaa !23
  %t632 = load ptr, ptr %l324, !tbaa !29
  %t633 = load i32, ptr %l327, !tbaa !23
  %t635 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %t632, i32 %t633, i32 %t631)
  store i1 %t635, ptr %l329
  br label %bb178
bb178:
  %t636 = load i1, ptr %l329, !tbaa !21
  store i1 %t636, ptr %l323, !tbaa !21
  br label %bb179
bb179:
  %t637 = load i1, ptr %l323, !tbaa !21
  br i1 %t637, label %bb180, label %bb181
bb180:
  store %olang.scope zeroinitializer, ptr %s16
  %t638 = load ptr, ptr %l0, !tbaa !29
  store ptr %t638, ptr %l330, !tbaa !29
  %t639 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t639, ptr %l331
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l332, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t642 = load i32, ptr %l9, !tbaa !23
  %t645 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t641, i32 %t642)
  store i32 %t645, ptr %l335
  br label %bb182
bb181:
  br label %bb189
bb182:
  %t646 = load ptr, ptr %l332, !tbaa !29
  %t647 = load i32, ptr %l335, !tbaa !23
  %t648 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t646, i32 %t647)
  store { i64, ptr } %t648, ptr %l336
  br label %bb183
bb183:
  %t649 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t650 = extractvalue { i64, ptr } %t649, 0
  %t651 = extractvalue { i64, ptr } %t649, 1
  %t652 = mul i64 %t650, 1
  %t653 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t652)
  call void @llvm.memcpy.p0.p0.i64(ptr %t653, ptr %t651, i64 %t652, i1 false)
  %t654 = insertvalue { i64, ptr } undef, i64 %t650, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t653, 1
  store { i64, ptr } %t655, ptr %l337, !tbaa !27
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load i32, ptr %l3, !tbaa !23
  %t660 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s16, ptr %t656, i32 %t657)
  store { i64, ptr } %t660, ptr %l340
  br label %bb184
bb184:
  %t661 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t662 = extractvalue { i64, ptr } %t661, 0
  %t663 = extractvalue { i64, ptr } %t661, 1
  %t664 = mul i64 %t662, 1
  %t665 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t664)
  call void @llvm.memcpy.p0.p0.i64(ptr %t665, ptr %t663, i64 %t664, i1 false)
  %t666 = insertvalue { i64, ptr } undef, i64 %t662, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  %t668 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t670 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %s16, ptr %s16, ptr %s16, { i64, ptr } %t668, { i64, ptr } %t667)
  store %"compiler/msgs:Msg" %t670, ptr %l342
  br label %bb185
bb185:
  %t671 = load ptr, ptr %l330, !tbaa !29
  %t672 = load %"compiler/source:Span", ptr %l331
  %t673 = load %"compiler/msgs:Msg", ptr %l342
  %t674 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t671, %"compiler/source:Span" %t672, %"compiler/msgs:Msg" %t673)
  store i64 %t674, ptr %l343
  br label %bb186
bb186:
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t675, { i64, ptr } %t676)
  br label %bb187
bb187:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t680 = load %"compiler/source:Span", ptr %l1
  %t683 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t679, %"compiler/source:Span" %t680)
  store ptr %t683, ptr %l348
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t684 = load ptr, ptr %l348, !tbaa !29
  store ptr %t684, ptr %rv
  br label %ret
bb189:
  %t685 = load i64, ptr %l14, !tbaa !24
  %t687 = icmp slt i64 %t685, 0
  br i1 %t687, label %bb190, label %bb191
bb190:
  store %olang.scope zeroinitializer, ptr %s17
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load %"compiler/source:Span", ptr %l1
  %t691 = load %"compiler/source:Span", ptr %l4
  %t692 = load ptr, ptr %l2, !tbaa !29
  %t693 = load ptr, ptr %l8, !tbaa !29
  %t694 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t695 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t703 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v0, ptr %v2, ptr %t689, %"compiler/source:Span" %t690, %"compiler/source:Span" %t691, ptr %t692, ptr %t693, { i64, ptr } %t694, { i64, ptr } %t695)
  store ptr %t703, ptr %l358
  br label %bb192
bb191:
  br label %bb246
bb192:
  %t704 = load ptr, ptr %l358, !tbaa !29
  store ptr %t704, ptr %l16, !tbaa !29
  %t705 = load ptr, ptr %l16, !tbaa !29
  %t707 = icmp eq ptr %t705, null
  %t709 = xor i1 %t707, true
  br i1 %t709, label %bb193, label %bb194
bb193:
  %t711 = load ptr, ptr %l16, !tbaa !29
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t711, ptr %rv
  br label %ret
bb194:
  br label %bb195
bb195:
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t714 = load i32, ptr %l9, !tbaa !23
  %t717 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t713, i32 %t714)
  store i32 %t717, ptr %l365
  br label %bb196
bb196:
  %t718 = load i32, ptr %l365, !tbaa !23
  store i32 %t718, ptr %l17, !tbaa !23
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t720 = load i32, ptr %l17, !tbaa !23
  %t723 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t719, i32 %t720)
  store i1 %t723, ptr %l368
  br label %bb197
bb197:
  %t724 = load i1, ptr %l368, !tbaa !21
  br i1 %t724, label %bb198, label %bb199
bb198:
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load i32, ptr %l17, !tbaa !23
  %t727 = load i32, ptr %l3, !tbaa !23
  %t731 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %t725, i32 %t726, i32 %t727)
  store i64 %t731, ptr %l373
  br label %bb200
bb199:
  store i1 false, ptr %l369, !tbaa !21
  br label %bb201
bb200:
  %t732 = load i64, ptr %l373, !tbaa !24
  %t733 = icmp sge i64 %t732, 0
  store i1 %t733, ptr %l369, !tbaa !21
  br label %bb201
bb201:
  %t735 = load i1, ptr %l369, !tbaa !21
  br i1 %t735, label %bb202, label %bb203
bb202:
  %t736 = load ptr, ptr %l8, !tbaa !29
  %t738 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t736)
  store ptr %t738, ptr %l376
  br label %bb204
bb203:
  br label %bb220
bb204:
  %t739 = load ptr, ptr %l376, !tbaa !29
  store ptr %t739, ptr %l18, !tbaa !29
  %t740 = load ptr, ptr %l18, !tbaa !29
  %t742 = icmp eq ptr %t740, null
  br i1 %t742, label %bb205, label %bb206
bb205:
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t744)
  store %"compiler/source:Span" %t746, ptr %l380
  br label %bb207
bb206:
  br label %bb210
bb207:
  %t747 = load i32, ptr %l9, !tbaa !23
  store i32 %t747, ptr %l381, !tbaa !23
  %t748 = load ptr, ptr %l8, !tbaa !29
  store ptr %t748, ptr %l382, !tbaa !29
  %t749 = load ptr, ptr %l0, !tbaa !29
  store ptr %t749, ptr %l383, !tbaa !29
  store i32 8, ptr %l384
  %t750 = load ptr, ptr %l2, !tbaa !29
  %t752 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t750)
  store %"compiler/source:Span" %t752, ptr %l386
  br label %bb208
bb208:
  %t753 = load ptr, ptr %l383, !tbaa !29
  %t754 = load i32, ptr %l384
  %t755 = load %"compiler/source:Span", ptr %l386
  %t756 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t753, i32 %t754, %"compiler/source:Span" %t755)
  store i32 %t756, ptr %l387
  br label %bb209
bb209:
  store { i64, [4 x i64] } zeroinitializer, ptr %t757
  %t758 = getelementptr { i64, [4 x i64] }, ptr %t757, i32 0, i32 0
  store i64 6, ptr %t758
  %t759 = load %"compiler/source:Span", ptr %l380
  %t760 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t759, 0
  %t761 = load i32, ptr %l381, !tbaa !23
  %t762 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t760, i32 %t761, 1
  %t763 = load ptr, ptr %l382, !tbaa !29
  %t764 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t762, ptr %t763, 2
  %t765 = load i32, ptr %l387, !tbaa !23
  %t766 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t764, i32 %t765, 3
  %t767 = getelementptr { i64, [4 x i64] }, ptr %t757, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t766, ptr %t767
  %t768 = load { i64, [4 x i64] }, ptr %t757
  %t770 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t768, ptr %t770
  store ptr %t770, ptr %l18, !tbaa !29
  br label %bb210
bb210:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l390, !tbaa !29
  %t773 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t773, ptr %l391
  %t774 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t774, ptr %l392
  %t775 = load ptr, ptr %l18, !tbaa !29
  %t777 = icmp eq ptr %t775, null
  br i1 %t777, label %bb211, label %bb212
bb211:
  call void @__olang_check_failed(ptr @olang_loc_897998a95b9e5e2e_e7f90bd867c953f2)
  unreachable
bb212:
  br label %bb213
bb213:
  %t779 = load ptr, ptr %l18, !tbaa !29
  %t780 = load i32, ptr %l3, !tbaa !23
  %t781 = load ptr, ptr %l390, !tbaa !29
  %t782 = load %"compiler/source:Span", ptr %l391
  %t783 = load %"compiler/source:Span", ptr %l392
  %t786 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %t781, %"compiler/source:Span" %t782, %"compiler/source:Span" %t783, ptr %t779, i32 %t780)
  store ptr %t786, ptr %l397
  br label %bb214
bb214:
  %t787 = load ptr, ptr %l397, !tbaa !29
  store ptr %t787, ptr %l19, !tbaa !29
  %t788 = load ptr, ptr %l19, !tbaa !29
  %t790 = icmp eq ptr %t788, null
  %t792 = xor i1 %t790, true
  br i1 %t792, label %bb215, label %bb216
bb215:
  %t794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t794, ptr %l401, !tbaa !29
  %t795 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t795, ptr %l402
  %t796 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t796, ptr %l403
  %t797 = load ptr, ptr %l0, !tbaa !29
  %t798 = load %"compiler/source:Span", ptr %l1
  %t799 = load ptr, ptr %l19, !tbaa !29
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t797, %"compiler/source:Span" %t798, ptr %t799)
  store ptr %t803, ptr %l407
  br label %bb217
bb216:
  br label %bb219
bb217:
  %t804 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t805 = load ptr, ptr %l401, !tbaa !29
  %t806 = load %"compiler/source:Span", ptr %l402
  %t807 = load %"compiler/source:Span", ptr %l403
  %t808 = load ptr, ptr %l407, !tbaa !29
  %t810 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v2, ptr %t805, %"compiler/source:Span" %t806, %"compiler/source:Span" %t807, ptr %t808, { i64, ptr } %t804)
  store ptr %t810, ptr %l409
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t811 = load ptr, ptr %l409, !tbaa !29
  store ptr %t811, ptr %rv
  br label %ret
bb219:
  br label %bb220
bb220:
  %t812 = load ptr, ptr %l0, !tbaa !29
  %t813 = load i32, ptr %l17, !tbaa !23
  %t816 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t812, i32 %t813)
  store i1 %t816, ptr %l412
  br label %bb221
bb221:
  %t817 = load i1, ptr %l412, !tbaa !21
  br i1 %t817, label %bb222, label %bb223
bb222:
  %t818 = load ptr, ptr %l0, !tbaa !29
  %t819 = load i32, ptr %l17, !tbaa !23
  %t822 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t818, i32 %t819)
  store i32 %t822, ptr %l416
  br label %bb224
bb223:
  store i1 false, ptr %l413, !tbaa !21
  br label %bb225
bb224:
  %t823 = load i32, ptr %l416
  %t825 = trunc i64 3 to i32
  %t826 = icmp eq i32 %t823, %t825
  store i1 %t826, ptr %l413, !tbaa !21
  br label %bb225
bb225:
  %t828 = load i1, ptr %l413, !tbaa !21
  br i1 %t828, label %bb226, label %bb227
bb226:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t830 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t829, { i64, ptr } %t830)
  br label %bb228
bb227:
  br label %bb230
bb228:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load %"compiler/source:Span", ptr %l1
  %t837 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t833, %"compiler/source:Span" %t834)
  store ptr %t837, ptr %l423
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t838 = load ptr, ptr %l423, !tbaa !29
  store ptr %t838, ptr %rv
  br label %ret
bb230:
  %t839 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t841 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t839, { i64, ptr } { i64 4, ptr @.d20 })
  store i1 %t841, ptr %l425
  br label %bb231
bb231:
  %t842 = load i1, ptr %l425, !tbaa !21
  br i1 %t842, label %bb232, label %bb233
bb232:
  store i1 true, ptr %l426, !tbaa !21
  br label %bb235
bb233:
  %t843 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t845 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t843, { i64, ptr } { i64 3, ptr @.d21 })
  store i1 %t845, ptr %l428
  br label %bb234
bb234:
  %t846 = load i1, ptr %l428, !tbaa !21
  store i1 %t846, ptr %l426, !tbaa !21
  br label %bb235
bb235:
  %t847 = load i1, ptr %l426, !tbaa !21
  br i1 %t847, label %bb236, label %bb237
bb236:
  store %olang.scope zeroinitializer, ptr %s23
  %t848 = load ptr, ptr %l0, !tbaa !29
  %t849 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s23, ptr %t848, %"compiler/source:Span" %t849, { i64, ptr } { i64 43, ptr @.d22 })
  br label %bb238
bb237:
  store %olang.scope zeroinitializer, ptr %s24
  %t852 = load ptr, ptr %l0, !tbaa !29
  store ptr %t852, ptr %l431, !tbaa !29
  %t853 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t853, ptr %l432
  %t854 = load ptr, ptr %l0, !tbaa !29
  %t855 = load i32, ptr %l9, !tbaa !23
  %t858 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s24, ptr %t854, i32 %t855)
  store { i64, ptr } %t858, ptr %l435
  br label %bb239
bb238:
  call void @__olang_scope_close(ptr %s23)
  br label %bb243
bb239:
  %t859 = load { i64, ptr }, ptr %l435, !tbaa !27
  %t860 = extractvalue { i64, ptr } %t859, 0
  %t861 = extractvalue { i64, ptr } %t859, 1
  %t862 = mul i64 %t860, 1
  %t863 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t862)
  call void @llvm.memcpy.p0.p0.i64(ptr %t863, ptr %t861, i64 %t862, i1 false)
  %t864 = insertvalue { i64, ptr } undef, i64 %t860, 0
  %t865 = insertvalue { i64, ptr } %t864, ptr %t863, 1
  store { i64, ptr } %t865, ptr %l436, !tbaa !27
  %t866 = load ptr, ptr %l0, !tbaa !29
  %t867 = load i32, ptr %l3, !tbaa !23
  %t870 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s24, ptr %t866, i32 %t867)
  store { i64, ptr } %t870, ptr %l439
  br label %bb240
bb240:
  %t871 = load { i64, ptr }, ptr %l439, !tbaa !27
  %t872 = extractvalue { i64, ptr } %t871, 0
  %t873 = extractvalue { i64, ptr } %t871, 1
  %t874 = mul i64 %t872, 1
  %t875 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t874)
  call void @llvm.memcpy.p0.p0.i64(ptr %t875, ptr %t873, i64 %t874, i1 false)
  %t876 = insertvalue { i64, ptr } undef, i64 %t872, 0
  %t877 = insertvalue { i64, ptr } %t876, ptr %t875, 1
  %t878 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t880 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %s24, ptr %s24, ptr %s24, { i64, ptr } %t878, { i64, ptr } %t877)
  store %"compiler/msgs:Msg" %t880, ptr %l441
  br label %bb241
bb241:
  %t881 = load ptr, ptr %l431, !tbaa !29
  %t882 = load %"compiler/source:Span", ptr %l432
  %t883 = load %"compiler/msgs:Msg", ptr %l441
  %t884 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s24, ptr %t881, %"compiler/source:Span" %t882, %"compiler/msgs:Msg" %t883)
  store i64 %t884, ptr %l442
  br label %bb242
bb242:
  call void @__olang_scope_close(ptr %s24)
  br label %bb243
bb243:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t885, { i64, ptr } %t886)
  br label %bb244
bb244:
  %t889 = load ptr, ptr %l0, !tbaa !29
  %t890 = load %"compiler/source:Span", ptr %l1
  %t893 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t889, %"compiler/source:Span" %t890)
  store ptr %t893, ptr %l447
  br label %bb245
bb245:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t894 = load ptr, ptr %l447, !tbaa !29
  store ptr %t894, ptr %rv
  br label %ret
bb246:
  %t895 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t895, ptr %l448, !tbaa !27
  %t896 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t897 = load ptr, ptr %t896, !tbaa !27
  %t898 = getelementptr i8, ptr %t897, i64 0
  %t899 = load i8, ptr %t898, !tbaa !32
  %t901 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t899)
  store i1 %t901, ptr %l450
  br label %bb247
bb247:
  %t902 = load i1, ptr %l450, !tbaa !21
  %t903 = xor i1 %t902, true
  br i1 %t903, label %bb248, label %bb249
bb248:
  %t905 = load ptr, ptr %l0, !tbaa !29
  %t907 = getelementptr %"compiler/check:Checker", ptr %t905, i32 0, i32 1
  %t908 = load ptr, ptr %t907, !tbaa !29
  %t909 = load i64, ptr %l14, !tbaa !24
  %t912 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t908, i64 %t909)
  store i64 %t912, ptr %l456
  br label %bb250
bb249:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb252
bb250:
  %t913 = load ptr, ptr %l0, !tbaa !29
  %t915 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t913)
  store ptr %t915, ptr %l458
  br label %bb251
bb251:
  %t916 = load ptr, ptr %l458, !tbaa !29
  %t918 = getelementptr %"compiler/check:frame", ptr %t916, i32 0, i32 1
  %t919 = load i64, ptr %t918, !tbaa !24
  %t920 = load i64, ptr %l456, !tbaa !24
  %t922 = icmp ne i64 %t920, %t919
  store i1 %t922, ptr %l452, !tbaa !21
  br label %bb252
bb252:
  %t924 = load i1, ptr %l452, !tbaa !21
  br i1 %t924, label %bb253, label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s25
  %t925 = load ptr, ptr %l0, !tbaa !29
  store ptr %t925, ptr %l462, !tbaa !29
  %t926 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t926, ptr %l463
  %t927 = load ptr, ptr %l0, !tbaa !29
  %t928 = load i32, ptr %l3, !tbaa !23
  %t931 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s25, ptr %t927, i32 %t928)
  store { i64, ptr } %t931, ptr %l466
  br label %bb255
bb254:
  br label %bb258
bb255:
  %t932 = load { i64, ptr }, ptr %l466, !tbaa !27
  %t933 = extractvalue { i64, ptr } %t932, 0
  %t934 = extractvalue { i64, ptr } %t932, 1
  %t935 = mul i64 %t933, 1
  %t936 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t935)
  call void @llvm.memcpy.p0.p0.i64(ptr %t936, ptr %t934, i64 %t935, i1 false)
  %t937 = insertvalue { i64, ptr } undef, i64 %t933, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr %t936, 1
  %t940 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %s25, ptr %s25, { i64, ptr } %t938)
  store %"compiler/msgs:Msg" %t940, ptr %l468
  br label %bb256
bb256:
  %t941 = load ptr, ptr %l462, !tbaa !29
  %t942 = load %"compiler/source:Span", ptr %l463
  %t943 = load %"compiler/msgs:Msg", ptr %l468
  %t944 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s25, ptr %t941, %"compiler/source:Span" %t942, %"compiler/msgs:Msg" %t943)
  store i64 %t944, ptr %l469
  br label %bb257
bb257:
  call void @__olang_scope_close(ptr %s25)
  br label %bb258
bb258:
  %t945 = load ptr, ptr %l0, !tbaa !29
  store ptr %t945, ptr %l470, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t946, ptr %l471
  %t947 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t947, ptr %l472
  %t948 = load i64, ptr %l14, !tbaa !24
  store i64 %t948, ptr %l473, !tbaa !24
  %t949 = load ptr, ptr %l8, !tbaa !29
  store ptr %t949, ptr %l475, !tbaa !29
  %t951 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t951, ptr %l476, !tbaa !27
  %t952 = icmp sge i64 0, 0
  br i1 %t952, label %bb259, label %bb260
bb259:
  %t954 = icmp sle i64 0, 1152921504606846975
  br i1 %t954, label %bb261, label %bb262
bb260:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb261:
  %t956 = mul i64 0, 8
  %t957 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t956)
  %t958 = insertvalue { i64, ptr } undef, i64 0, 0
  %t959 = insertvalue { i64, ptr } %t958, ptr %t957, 1
  store { i64, ptr } %t959, ptr %l479, !tbaa !27
  %t960 = icmp sge i64 0, 0
  br i1 %t960, label %bb263, label %bb264
bb262:
  call void @__olang_check_failed(ptr @olang_loc_97297cf958301a5_897be3a3c1a33231)
  unreachable
bb263:
  %t962 = icmp sle i64 0, 2305843009213693951
  br i1 %t962, label %bb265, label %bb266
bb264:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb265:
  %t964 = mul i64 0, 4
  %t965 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t964)
  %t966 = insertvalue { i64, ptr } undef, i64 0, 0
  %t967 = insertvalue { i64, ptr } %t966, ptr %t965, 1
  %t968 = load ptr, ptr %l470, !tbaa !29
  %t969 = load %"compiler/source:Span", ptr %l471
  %t970 = load %"compiler/source:Span", ptr %l472
  %t971 = load i64, ptr %l473, !tbaa !24
  %t972 = load ptr, ptr %l475, !tbaa !29
  %t973 = load { i64, ptr }, ptr %l476, !tbaa !27
  %t974 = load { i64, ptr }, ptr %l479, !tbaa !27
  %t976 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %s0, ptr %t968, %"compiler/source:Span" %t969, %"compiler/source:Span" %t970, i64 %t971, ptr %t972, { i64, ptr } %t973, { i64, ptr } %t974, { i64, ptr } %t967)
  store ptr %t976, ptr %l483
  br label %bb267
bb266:
  call void @__olang_check_failed(ptr @olang_loc_f4ec2e4bc4870738_831a294d3dfd1224)
  unreachable
bb267:
  call void @__olang_scope_close(ptr %s0)
  %t977 = load ptr, ptr %l483, !tbaa !29
  store ptr %t977, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l22 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i64
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l69 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca i32
  %l84 = alloca %"compiler/typed:Payload"
  %l93 = alloca i64
  %l96 = alloca i64
  %l116 = alloca { i64, ptr }
  %l121 = alloca i64
  %l125 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l150 = alloca ptr
  %l157 = alloca %"compiler/check:narrowed"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t64 = alloca { i64, [4 x i64] }, align 8
  %t94 = alloca { i64, [4 x i64] }, align 8
  %t144 = alloca { i64, [4 x i64] }, align 8
  %t216 = alloca { i64, [2 x i64] }, align 8
  %t238 = alloca { i64, [4 x i64] }, align 8
  %t270 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l22, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t5, i64 %t6)
  store i32 %t9, ptr %l25
  br label %bb2
bb2:
  %t10 = load i32, ptr %l25, !tbaa !23
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l5, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l28
  br label %bb3
bb3:
  %t16 = load i32, ptr %l28, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 42
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l31
  br label %bb4
bb4:
  %t22 = load i64, ptr %l31, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/generic:Program", ptr %t26, i32 0, i32 2
  store ptr %t28, ptr %l34, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load i64, ptr %l3, !tbaa !24
  %t44 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t38, i32 %t39, i64 %t40)
  store i32 %t44, ptr %l42
  br label %bb5
bb5:
  %t45 = load ptr, ptr %l37, !tbaa !29
  %t46 = load i32, ptr %l42, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l43
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l34, !tbaa !29
  %t49 = load i32, ptr %l43, !tbaa !23
  %t50 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t50, ptr %l44
  br label %bb7
bb7:
  %t51 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t51, ptr %l8, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t56 = icmp sgt i64 %t54, 0
  br i1 %t56, label %bb8, label %bb9
bb8:
  %t58 = load %"compiler/source:Span", ptr %l1
  %t59 = load i32, ptr %l5, !tbaa !23
  %t60 = load i64, ptr %l2, !tbaa !24
  %t62 = trunc i64 %t60 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t64
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 0
  store i64 0, ptr %t65
  %t67 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t58, 0
  %t69 = insertvalue { %"compiler/source:Span", i32, i32 } %t67, i32 %t59, 1
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } %t69, i32 %t62, 2
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t71, ptr %t72
  %t73 = load { i64, [4 x i64] }, ptr %t64
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t73, ptr %t75
  store ptr %t75, ptr %l9, !tbaa !29
  %t77 = load ptr, ptr %l9, !tbaa !29
  store ptr %t77, ptr %l10, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l5, !tbaa !23
  %t83 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t79, i32 %t80)
  store i1 %t83, ptr %l58
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb11, label %bb12
bb11:
  %t85 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t85, ptr %l59
  %t86 = load i32, ptr %l6, !tbaa !23
  store i32 %t86, ptr %l60, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l1
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t93 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, ptr %t89)
  store ptr %t93, ptr %l64
  br label %bb13
bb12:
  br label %bb14
bb13:
  store { i64, [4 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 0
  store i64 2, ptr %t95
  %t96 = load %"compiler/source:Span", ptr %l59
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t96, 0
  %t98 = load i32, ptr %l60, !tbaa !23
  %t99 = insertvalue { %"compiler/source:Span", i32, ptr } %t97, i32 %t98, 1
  %t100 = load ptr, ptr %l64, !tbaa !29
  %t101 = insertvalue { %"compiler/source:Span", i32, ptr } %t99, ptr %t100, 2
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t101, ptr %t102
  %t103 = load { i64, [4 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t103, ptr %t105
  store ptr %t105, ptr %l10, !tbaa !29
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 2
  store ptr %t112, ptr %l69, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l6, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l74
  br label %bb15
bb15:
  %t123 = load ptr, ptr %l69, !tbaa !29
  %t124 = load i32, ptr %l74, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t123, i32 %t124)
  store { i64, ptr } %t125, ptr %l75
  br label %bb16
bb16:
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t126, ptr %l76, !tbaa !27
  %t127 = load i64, ptr %l3, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t134 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t134, ptr %l79
  store i32 %t132, ptr %l80, !tbaa !23
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  %t141 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t136, i64 %t137, i32 0)
  store %"compiler/typed:Payload" %t141, ptr %l84
  br label %bb17
bb17:
  %t142 = load %"compiler/typed:Payload", ptr %l84
  %t143 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t142, ptr %t143
  store { i64, [4 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 0
  store i64 5, ptr %t145
  %t146 = load %"compiler/source:Span", ptr %l79
  %t147 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t146, 0
  %t148 = load i32, ptr %l80, !tbaa !23
  %t149 = insertvalue { %"compiler/source:Span", i32, ptr } %t147, i32 %t148, 1
  %t151 = insertvalue { %"compiler/source:Span", i32, ptr } %t149, ptr %t143, 2
  %t152 = getelementptr { i64, [4 x i64] }, ptr %t144, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t151, ptr %t152
  %t153 = load { i64, [4 x i64] }, ptr %t144
  %t155 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t153, ptr %t155
  store ptr %t155, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  store i64 %t159, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l13, !tbaa !24
  %t165 = icmp sgt i64 %t161, %t162
  br i1 %t165, label %bb18, label %bb19
bb18:
  %t167 = load i64, ptr %l15, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  br i1 %t169, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb23
bb20:
  %t171 = load i64, ptr %l14, !tbaa !24
  %t172 = load i64, ptr %l13, !tbaa !24
  %t175 = sub i64 %t171, %t172
  %t176 = load i64, ptr %l15, !tbaa !24
  %t179 = add i64 %t175, %t176
  %t181 = sub i64 %t179, 1
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = sdiv i64 %t181, %t182
  store i64 %t185, ptr %l96, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb22
bb22:
  %t187 = load i64, ptr %l96, !tbaa !24
  store i64 %t187, ptr %l93, !tbaa !24
  br label %bb23
bb23:
  %t188 = load i64, ptr %l93, !tbaa !24
  store i64 %t188, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t189 = load i64, ptr %l17, !tbaa !24
  %t190 = load i64, ptr %l16, !tbaa !24
  %t193 = icmp slt i64 %t189, %t190
  %t195 = xor i1 %t193, true
  br i1 %t195, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb26:
  br label %bb27
bb27:
  %t197 = load i64, ptr %l13, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  %t202 = mul i64 %t198, %t199
  %t205 = add i64 %t197, %t202
  store i64 %t205, ptr %l18, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load %"compiler/source:Span", ptr %l1
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t209, ptr %l116, !tbaa !27
  %t210 = load i64, ptr %l18, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i32, ptr %t213, i64 %t210
  %t215 = load i32, ptr %t214, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t216
  %t217 = getelementptr { i64, [2 x i64] }, ptr %t216, i32 0, i32 0
  store i64 5, ptr %t217
  %t218 = load { i64, [2 x i64] }, ptr %t216
  %t224 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t207, i32 0, %"compiler/source:Span" %t208, i32 %t215, i32 4, { i64, [2 x i64] } %t218)
  store i64 %t224, ptr %l121
  br label %bb28
bb28:
  %t225 = load i64, ptr %l121, !tbaa !24
  store i64 %t225, ptr %l19, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t229, ptr %l125, !tbaa !27
  %t230 = load i64, ptr %l18, !tbaa !24
  %t232 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr i32, ptr %t233, i64 %t230
  %t235 = load i32, ptr %t234, !tbaa !33
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t237 = load i64, ptr %l18, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t238
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 0
  store i64 3, ptr %t239
  %t241 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t228, 0
  %t243 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t241, i32 %t235, 1
  %t245 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t243, ptr %t236, 2
  %t247 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t245, i64 %t237, 3
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t247, ptr %t248
  %t249 = load { i64, [4 x i64] }, ptr %t238
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t249, ptr %t251
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t226, %"compiler/source:Span" %t227, ptr %t251)
  store ptr %t255, ptr %l132
  br label %bb29
bb29:
  %t256 = load ptr, ptr %l132, !tbaa !29
  store ptr %t256, ptr %l20, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i64, ptr %l19, !tbaa !24
  %t259 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t257, i64 %t258, ptr %t259)
  br label %bb30
bb30:
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load %"compiler/source:Span", ptr %l1
  %t265 = load i64, ptr %l19, !tbaa !24
  %t267 = trunc i64 %t265 to i32
  %t269 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t270
  %t271 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 0
  store i64 0, ptr %t271
  %t273 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t264, 0
  %t275 = insertvalue { %"compiler/source:Span", i32, ptr } %t273, i32 %t267, 1
  %t277 = insertvalue { %"compiler/source:Span", i32, ptr } %t275, ptr %t269, 2
  %t278 = getelementptr { i64, [3 x i64] }, ptr %t270, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t277, ptr %t278
  %t279 = load { i64, [3 x i64] }, ptr %t270
  %t281 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t279, ptr %t281
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t263, ptr %t281)
  br label %bb31
bb31:
  %t284 = load ptr, ptr %l4, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 42
  %t287 = load i64, ptr %l19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t290 = load i64, ptr %l17, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l17, !tbaa !24
  br label %bb24
bb34:
  br label %bb35
bb35:
  %t294 = load ptr, ptr %l4, !tbaa !29
  %t296 = getelementptr %"compiler/check:frame", ptr %t294, i32 0, i32 41
  store ptr %t296, ptr %l150, !tbaa !29
  %t297 = load i64, ptr %l2, !tbaa !24
  %t298 = load i64, ptr %l3, !tbaa !24
  %t299 = load i32, ptr %l6, !tbaa !23
  %t300 = load i64, ptr %l7, !tbaa !24
  %t301 = load ptr, ptr %l4, !tbaa !29
  %t303 = getelementptr %"compiler/check:frame", ptr %t301, i32 0, i32 7
  %t304 = load i64, ptr %t303, !tbaa !24
  %t310 = call %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %s0, i64 %t297, i64 %t298, i32 %t299, i64 %t300, i64 %t304)
  store %"compiler/check:narrowed" %t310, ptr %l157
  br label %bb36
bb36:
  %t311 = load ptr, ptr %l150, !tbaa !29
  %t312 = load %"compiler/check:narrowed", ptr %l157
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %t311, %"compiler/check:narrowed" %t312)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoIndex(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/source:Span"
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l29 = alloca { i64, ptr }
  %l31 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %t1, %"compiler/source:Span" %a1)
  store %"compiler/source:Span" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load %"compiler/source:Span", ptr %l8
  store %"compiler/source:Span" %t6, ptr %l5
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l5
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t7, i32 %t8, { i64, ptr } { i64 2, ptr @.d23 }, %"compiler/source:Span" %t9, { i64, ptr } { i64 6, ptr @.d24 }, i64 1, i1 true)
  store i1 %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = add i64 %a4, 1
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t15, i32 %t16, { i64, ptr } { i64 5, ptr @.d25 }, i64 %t19)
  store i64 %t23, ptr %l17
  br label %bb6
bb6:
  %t24 = load i64, ptr %l17, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 41
  %t31 = getelementptr %"compiler/source:Span", ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = icmp sge i32 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 41
  %t39 = load %"compiler/source:Span", ptr %t38
  store %"compiler/source:Span" %t39, ptr %l23
  br label %bb11
bb10:
  %t41 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t41, ptr %l23
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t47 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t43, i32 %a3)
  store { i64, ptr } %t47, ptr %l29
  br label %bb12
bb12:
  %t48 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  %t56 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %s2, ptr %s2, { i64, ptr } %t54)
  store %"compiler/msgs:Msg" %t56, ptr %l31
  br label %bb13
bb13:
  %t57 = load ptr, ptr %l19, !tbaa !29
  %t58 = load %"compiler/source:Span", ptr %l23
  %t59 = load %"compiler/msgs:Msg", ptr %l31
  %t60 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t57, %"compiler/source:Span" %t58, %"compiler/msgs:Msg" %t59)
  store i64 %t60, ptr %l32
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l33, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t62, ptr %l34
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l2, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t63, i32 %t64)
  store { i64, ptr } %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store %"compiler/msgs:Msg" %t76, ptr %l39
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l33, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l34
  %t79 = load %"compiler/msgs:Msg", ptr %l39
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t77, %"compiler/source:Span" %t78, %"compiler/msgs:Msg" %t79)
  store i64 %t80, ptr %l40
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 86
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, i1 true)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca { i64, ptr }
  %l47 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l72 = alloca i1
  %l73 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l112 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t17 = load ptr, ptr %l16, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 10
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t46 = load ptr, ptr %l2, !tbaa !29
  store ptr %t46, ptr %l9, !tbaa !29
  br label %bb21
bb14:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 7
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l3, !tbaa !29
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Chain", ptr %t64, i32 0, i32 1
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  %t68 = load ptr, ptr %l3, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Chain", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t75 = sub i64 %t73, 2
  %t77 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr ptr, ptr %t78, i64 %t75
  %t80 = load ptr, ptr %t79, !tbaa !39
  store ptr %t80, ptr %l9, !tbaa !29
  br label %bb21
bb20:
  store ptr null, ptr %l9, !tbaa !29
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l9, !tbaa !29
  store ptr %t83, ptr %l4, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t86 = icmp eq ptr %t84, null
  br i1 %t86, label %bb22, label %bb23
bb22:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t88)
  store %"compiler/source:Span" %t90, ptr %l47
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load %"compiler/source:Span", ptr %l47
  store %"compiler/source:Span" %t91, ptr %rv
  br label %ret
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 5
  store ptr %t100, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t101)
  store ptr %t103, ptr %l53
  br label %bb26
bb26:
  %t104 = load ptr, ptr %l53, !tbaa !29
  %t106 = getelementptr %"compiler/check:frame", ptr %t104, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load ptr, ptr %l51, !tbaa !29
  %t110 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t108, i64 %t107)
  store ptr %t110, ptr %l56
  br label %bb27
bb27:
  %t111 = load ptr, ptr %l56, !tbaa !29
  %t113 = getelementptr %"compiler/load:Module", ptr %t111, i32 0, i32 6
  %t114 = load ptr, ptr %t113, !tbaa !29
  store ptr %t114, ptr %l5, !tbaa !29
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  br i1 %t118, label %bb28, label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_60d47afda00c6d15_78511e797186b151)
  unreachable
bb29:
  br label %bb30
bb30:
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr %"compiler/source:Source", ptr %t120, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l6, !tbaa !27
  %t126 = load ptr, ptr %l4, !tbaa !29
  %t128 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t126)
  store %"compiler/source:Span" %t128, ptr %l65
  br label %bb31
bb31:
  %t129 = getelementptr %"compiler/source:Span", ptr %l65, i32 0, i32 1
  %t130 = load i32, ptr %t129, !tbaa !23
  %t132 = sext i32 %t130 to i64
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t134 = load i64, ptr %l7, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = icmp slt i64 %t134, %t137
  br i1 %t140, label %bb33, label %bb34
bb33:
  %t142 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t142, ptr %l73, !tbaa !27
  %t143 = load i64, ptr %l7, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i8, ptr %t146, i64 %t143
  %t148 = load i8, ptr %t147, !tbaa !32
  %t150 = icmp eq i8 %t148, 32
  br i1 %t150, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb38
bb35:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb37
bb36:
  %t152 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t152, ptr %l78, !tbaa !27
  %t153 = load i64, ptr %l7, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i8, ptr %t156, i64 %t153
  %t158 = load i8, ptr %t157, !tbaa !32
  %t160 = icmp eq i8 %t158, 41
  store i1 %t160, ptr %l77, !tbaa !21
  br label %bb37
bb37:
  %t162 = load i1, ptr %l77, !tbaa !21
  store i1 %t162, ptr %l72, !tbaa !21
  br label %bb38
bb38:
  %t163 = load i1, ptr %l72, !tbaa !21
  %t164 = xor i1 %t163, true
  br i1 %t164, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb40:
  br label %bb41
bb41:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  br label %bb32
bb43:
  %t170 = load i64, ptr %l7, !tbaa !24
  store i64 %t170, ptr %l8, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t172 = load i64, ptr %l8, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t178 = icmp slt i64 %t172, %t175
  br i1 %t178, label %bb45, label %bb46
bb45:
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t180, ptr %l91, !tbaa !27
  %t181 = load i64, ptr %l8, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i8, ptr %t184, i64 %t181
  %t186 = load i8, ptr %t185, !tbaa !32
  %t188 = icmp ne i8 %t186, 32
  store i1 %t188, ptr %l90, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l90, !tbaa !21
  br label %bb47
bb47:
  %t190 = load i1, ptr %l90, !tbaa !21
  br i1 %t190, label %bb48, label %bb49
bb48:
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t191, ptr %l96, !tbaa !27
  %t192 = load i64, ptr %l8, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr i8, ptr %t195, i64 %t192
  %t197 = load i8, ptr %t196, !tbaa !32
  %t199 = icmp ne i8 %t197, 40
  store i1 %t199, ptr %l95, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb50
bb50:
  %t201 = load i1, ptr %l95, !tbaa !21
  br i1 %t201, label %bb51, label %bb52
bb51:
  %t202 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t202, ptr %l101, !tbaa !27
  %t203 = load i64, ptr %l8, !tbaa !24
  %t205 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr i8, ptr %t206, i64 %t203
  %t208 = load i8, ptr %t207, !tbaa !32
  %t210 = icmp ne i8 %t208, 10
  store i1 %t210, ptr %l100, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb53
bb53:
  %t212 = load i1, ptr %l100, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb55:
  br label %bb56
bb56:
  %t215 = load i64, ptr %l8, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb57:
  br label %bb44
bb58:
  %t219 = load i64, ptr %l7, !tbaa !24
  %t221 = trunc i64 %t219 to i32
  %t222 = load i64, ptr %l8, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  %t227 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t221, i32 %t224)
  store %"compiler/source:Span" %t227, ptr %l112
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  %t228 = load %"compiler/source:Span", ptr %l112
  store %"compiler/source:Span" %t228, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca i1
  %l21 = alloca i32
  %l26 = alloca i32
  %l33 = alloca i32
  %l39 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i32
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca i1
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Program", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l15
  br label %bb4
bb4:
  %t18 = load i1, ptr %l15, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l21
  br label %bb8
bb8:
  %t30 = load i32, ptr %l21, !tbaa !23
  store i32 %t30, ptr %l2, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l26
  br label %bb9
bb9:
  %t41 = load i32, ptr %l26
  %t43 = trunc i64 19 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l2, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l33
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t56 = load i32, ptr %l33, !tbaa !23
  %t57 = icmp eq i32 %t56, 0
  store i1 %t57, ptr %rv
  br label %ret
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l39
  br label %bb14
bb14:
  %t69 = load i32, ptr %l39
  %t71 = trunc i64 22 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb18
bb16:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l47
  br label %bb17
bb17:
  %t84 = load i32, ptr %l47
  %t86 = trunc i64 23 to i32
  %t87 = icmp eq i32 %t84, %t86
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb19, label %bb20
bb19:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  store ptr %t95, ptr %l52, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  %t102 = load i32, ptr %l2, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l57
  br label %bb21
bb20:
  br label %bb33
bb21:
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t107 = load i32, ptr %l57, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l58
  br label %bb22
bb22:
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t109, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb25:
  br label %bb26
bb26:
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t122, ptr %l65, !tbaa !27
  %t123 = load i64, ptr %l4, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceable(ptr %v0, ptr %t130, i32 %t128)
  store i1 %t134, ptr %l70
  br label %bb27
bb27:
  %t135 = load i1, ptr %l70, !tbaa !21
  br i1 %t135, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l4, !tbaa !24
  br label %bb23
bb32:
  br label %bb33
bb33:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca i64
  %l27 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 22
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v0, ptr %t10, ptr %t11)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 0
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 18
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb12
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/load:Loader", ptr %t32, i32 0, i32 4
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/check:frame", ptr %t38, i32 0, i32 37
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t44 = icmp sgt i64 %t42, %t41
  store i1 %t44, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l14, !tbaa !21
  store i1 %t46, ptr %l11, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l11, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 84
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %t53, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t50, i64 %t54, i1 true)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 13
  %t61 = call { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H89a3697e96ae7f34894afc674ffcde65(ptr %v0, ptr %v0, ptr %t59)
  %t62 = extractvalue { i32, ptr } %t61, 1
  %t63 = extractvalue { i32, ptr } %t61, 0
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb18, label %ok.65
ok.65:
  store ptr %t62, ptr %l30
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l30, !tbaa !29
  store ptr %t66, ptr %l27, !tbaa !29
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %s2, ptr %t9, i32 %a2)
  store { i64, ptr } %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 4
  %t18 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb7:
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l22, !tbaa !27
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  store i32 %t40, ptr %l7, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l7, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l29
  br label %bb9
bb9:
  %t52 = load i32, ptr %l29
  %t54 = trunc i64 18 to i32
  %t55 = icmp eq i32 %t52, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l7, !tbaa !23
  %t68 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t64, i32 %t65)
  store i32 %t68, ptr %l37
  br label %bb13
bb13:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t70 = load i32, ptr %l37, !tbaa !23
  %t72 = icmp eq i32 %t70, %t69
  br i1 %t72, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t77 = load i32, ptr %l7, !tbaa !23
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 1
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesTrait(ptr %v0, ptr %t75, i32 %t76, i32 %t77, i64 %t80)
  store i1 %t85, ptr %l46
  br label %bb17
bb17:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l5, !tbaa !24
  br label %bb5
bb22:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb66
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 11
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_64f1128892bbfadb_2fd1650a543ec847)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Cond", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Cond", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb66
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9b328daa59c12fec_530ed6f7b483a728)
  unreachable
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Seq", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t100, ptr %t99)
  store i1 %t102, ptr %l54
  br label %bb32
bb32:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l47, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  br label %bb66
bb34:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 13
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store i1 %t124, ptr %l63
  br label %bb40
bb40:
  %t125 = load i1, ptr %l63, !tbaa !21
  store i1 %t125, ptr %l8, !tbaa !21
  br label %bb66
bb41:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 14
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l65, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Try", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Try", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_aa71917389f82fa1_ab8db462134cc7fd)
  unreachable
bb50:
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Try", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t162, ptr %t161)
  store i1 %t164, ptr %l81
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  store i1 %t165, ptr %l74, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l74, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb66
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t168 = load ptr, ptr %l82, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i1 %t186, ptr %l90
  br label %bb60
bb60:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_45c1f7cb36e76579_9732da1c199d4515)
  unreachable
bb66:
  %t188 = load i1, ptr %l8, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i64
  %l17 = alloca i1
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca i32
  %l41 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca i32
  %l46 = alloca i64
  %l49 = alloca i1
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t5 = load i32, ptr %l1, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/generic:Program", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/load:Loader", ptr %t12, i32 0, i32 3
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t16)
  store i32 %t19, ptr %l13
  br label %bb1
bb1:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load i32, ptr %l7, !tbaa !23
  %t22 = load i32, ptr %l13, !tbaa !23
  %t23 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t20, i32 %t21, i32 %t22)
  store i64 %t23, ptr %l14
  br label %bb2
bb2:
  %t24 = load i64, ptr %l14, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/generic:Program", ptr %t38, i32 0, i32 2
  store ptr %t40, ptr %l23, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t44, i64 %t45)
  store i32 %t48, ptr %l27
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t49 = load ptr, ptr %l23, !tbaa !29
  %t50 = load i32, ptr %l27, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t51, ptr %l28
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l20, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l29
  br label %bb7
bb7:
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  %t62 = icmp eq i64 %t56, %t59
  store i1 %t62, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t64 = load i1, ptr %l17, !tbaa !21
  br i1 %t64, label %bb9, label %bb10
bb9:
  %t65 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t65, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  store i32 %t71, ptr %l37, !tbaa !23
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  store ptr %t81, ptr %l41, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s0, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l43
  br label %bb12
bb12:
  %t85 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l41, !tbaa !29
  %t94 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t92, { i64, ptr } %t91)
  store i32 %t94, ptr %l45
  br label %bb13
bb13:
  %t95 = load ptr, ptr %l36, !tbaa !29
  %t96 = load i32, ptr %l37, !tbaa !23
  %t97 = load i32, ptr %l45, !tbaa !23
  %t98 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t95, i32 %t96, i32 %t97)
  store i64 %t98, ptr %l46
  br label %bb14
bb14:
  %t99 = load i64, ptr %l46, !tbaa !24
  store i64 %t99, ptr %l4, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t102 = icmp sge i64 %t100, 0
  br i1 %t102, label %bb15, label %bb16
bb15:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 2
  store ptr %t109, ptr %l52, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 2
  store ptr %t115, ptr %l55, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l4, !tbaa !24
  %t123 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t119, i64 %t120)
  store i32 %t123, ptr %l59
  br label %bb17
bb16:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb20
bb17:
  %t124 = load ptr, ptr %l55, !tbaa !29
  %t125 = load i32, ptr %l59, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t126, ptr %l60
  br label %bb18
bb18:
  %t127 = load ptr, ptr %l52, !tbaa !29
  %t128 = load i32, ptr %l60, !tbaa !23
  %t129 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t127, i32 %t128)
  store { i64, ptr } %t129, ptr %l61
  br label %bb19
bb19:
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  %t137 = icmp eq i64 %t131, %t134
  store i1 %t137, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t139 = load i1, ptr %l49, !tbaa !21
  br i1 %t139, label %bb21, label %bb22
bb21:
  %t140 = load i64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t140, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l49 = alloca { i64, ptr }
  %l56 = alloca i32
  %l61 = alloca i32
  %l63 = alloca ptr
  %l68 = alloca i32
  %l73 = alloca i64
  %l78 = alloca i64
  %l80 = alloca i32
  %l96 = alloca ptr
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l17
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  store ptr %a1, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t7 = load i64, ptr %l5, !tbaa !24
  %t10 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t6, i64 %t7)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l23
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb4, label %ok.14
ok.14:
  store { i64, ptr } %t11, ptr %l22
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t15, ptr %l19, !tbaa !27
  br label %bb8
bb4:
  %t16 = load i32, ptr %l23, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4aa9dd44a8cec868_fb6ff994c97fa99c)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb8:
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  store i64 %t24, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = icmp slt i64 %t26, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb11:
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t34, ptr %l32, !tbaa !27
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr i32, ptr %t38, i64 %t35
  %t40 = load i32, ptr %t39, !tbaa !33
  store i32 %t40, ptr %l9, !tbaa !23
  store ptr %a2, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t44 = load ptr, ptr %l10, !tbaa !29
  %t45 = load i64, ptr %l11, !tbaa !24
  %t48 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v2, ptr %t44, i64 %t45)
  %t49 = extractvalue { i32, { i64, ptr } } %t48, 1
  %t50 = extractvalue { i32, { i64, ptr } } %t48, 0
  store i32 %t50, ptr %l40
  %t51 = icmp ne i32 %t50, 0
  br i1 %t51, label %bb15, label %ok.52
ok.52:
  store { i64, ptr } %t49, ptr %l39
  br label %bb14
bb14:
  %t53 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  br label %bb19
bb15:
  %t54 = load i32, ptr %l40, !tbaa !23
  %t55 = ashr i32 %t54, 16
  %t57 = icmp eq i32 %t55, 1
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7a17fa9e9f4eb839_ac023da83e9691cd)
  unreachable
bb18:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb40
bb19:
  %t59 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t59, ptr %l12, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t64 = load i64, ptr %l14, !tbaa !24
  %t65 = load i64, ptr %l13, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb22:
  br label %bb23
bb23:
  %t72 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t72, ptr %l49, !tbaa !27
  %t73 = load i64, ptr %l14, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 %t73
  %t78 = load i32, ptr %t77, !tbaa !33
  store i32 %t78, ptr %l15, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %l9, !tbaa !23
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l56
  br label %bb24
bb24:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = load i32, ptr %l15, !tbaa !23
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t95, i32 %t96)
  store i32 %t99, ptr %l61
  br label %bb25
bb25:
  %t100 = load i32, ptr %l56, !tbaa !23
  %t101 = load i32, ptr %l61, !tbaa !23
  %t102 = icmp ne i32 %t100, %t101
  br i1 %t102, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l63, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %l9, !tbaa !23
  %t114 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t114, ptr %l68
  br label %bb29
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/generic:Program", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %l9, !tbaa !23
  %t124 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t120, i32 %t121)
  store i64 %t124, ptr %l73
  br label %bb30
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = load i32, ptr %l15, !tbaa !23
  %t134 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t130, i32 %t131)
  store i64 %t134, ptr %l78
  br label %bb31
bb31:
  %t135 = load i64, ptr %l73, !tbaa !65
  %t136 = load i64, ptr %l78, !tbaa !65
  %t137 = and i64 %t135, %t136
  %t138 = load ptr, ptr %l63, !tbaa !29
  %t139 = load i32, ptr %l68, !tbaa !23
  %t141 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t138, i32 %t139, i64 %t137)
  store i32 %t141, ptr %l80
  br label %bb32
bb32:
  %t142 = load i32, ptr %l80, !tbaa !23
  store i32 %t142, ptr %l16, !tbaa !23
  %t143 = load i32, ptr %l16, !tbaa !23
  %t144 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t147 = icmp ne i32 %t143, %t144
  br i1 %t147, label %bb33, label %bb34
bb33:
  %t149 = load i32, ptr %l16, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l3, i32 %t149)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t152 = load i64, ptr %l14, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l14, !tbaa !24
  br label %bb20
bb38:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = add i64 %t156, %t157
  store i64 %t160, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb13
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l8, !tbaa !24
  br label %bb9
bb42:
  %t166 = load i64, ptr %l5, !tbaa !24
  %t167 = load i64, ptr %l7, !tbaa !24
  %t170 = add i64 %t166, %t167
  store i64 %t170, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb43:
  br label %bb2
bb44:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l96, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t176 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %v3, ptr %t173, ptr %l3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %l99
  br label %bb45
bb45:
  %t177 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  %t178 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t177, ptr %t178
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t181 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v3, ptr %v3, ptr %t179, ptr %t178)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t181, ptr %l101
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load i64, ptr %l10, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 7, ptr @.d26 }, ptr %l12, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t7, ptr %l13, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load i64, ptr %l14, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t21, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t23, ptr %l16
  br label %bb5
bb5:
  %t24 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t24, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t25)
  store i64 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i64, ptr %l18, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l25, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l25, !tbaa !24
  store i64 %t55, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l22, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } { i64 2, ptr @.d27 })
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  store ptr %l2, ptr %l46, !tbaa !29
  store ptr %a0, ptr %l47, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t81, i64 %t82)
  store i32 %t85, ptr %l50
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l47, !tbaa !29
  %t87 = load i32, ptr %l50, !tbaa !23
  %t88 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s3, ptr %t86, i32 %t87)
  store { i64, ptr } %t88, ptr %l51
  br label %bb22
bb22:
  %t89 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = mul i64 %t90, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t92)
  call void @llvm.memcpy.p0.p0.i64(ptr %t93, ptr %t91, i64 %t92, i1 false)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  %t96 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t96, { i64, ptr } %t95)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb13
bb25:
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t103, ptr %l56
  br label %bb26
bb26:
  %t104 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t104, ptr %l57, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l58, !tbaa !24
  %t107 = load i64, ptr %l58, !tbaa !24
  %t108 = mul i64 %t107, 1
  %t109 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l59, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l58, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  %t118 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t118, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleFixed(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/check:Ask"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/check:AssertAsk"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca %"compiler/check:Ask"
  %l50 = alloca i1
  %l66 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i64
  %l94 = alloca %"compiler/check:AssertAsk"
  %l98 = alloca i1
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 74
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load i64, ptr %l18, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l22, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 74
  %t59 = call %"compiler/check:Ask" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t55, i64 %t51)
  store %"compiler/check:Ask" %t59, ptr %l46
  br label %bb12
bb12:
  %t60 = load %"compiler/check:Ask", ptr %l46
  store %"compiler/check:Ask" %t60, ptr %l8
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 4
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 5
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t61, i64 %t63, { i64, ptr } %t65)
  store i1 %t69, ptr %l50
  br label %bb13
bb13:
  %t70 = load i1, ptr %l50, !tbaa !21
  br i1 %t70, label %bb14, label %bb15
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/check:Ask", ptr %l8, i32 0, i32 3
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eRunning(ptr %v0, ptr %v0, ptr %t71, ptr %t73)
  br label %bb16
bb15:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 74
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load %"compiler/check:Ask", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v0, ptr %t78, i64 %t79, %"compiler/check:Ask" %t80)
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t84, 1
  store i64 %t86, ptr %l1, !tbaa !24
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb8
bb20:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 74
  %t95 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %t94, i64 %t95)
  br label %bb21
bb21:
  store i64 0, ptr %l1, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 75
  %t102 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %t100)
  store i64 %t102, ptr %l66
  br label %bb22
bb22:
  %t103 = load i64, ptr %l66, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l9, !tbaa !24
  %t108 = icmp sgt i64 %t104, %t105
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t110 = load i64, ptr %l11, !tbaa !24
  %t112 = icmp sgt i64 %t110, 0
  br i1 %t112, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb28
bb25:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t118, %t119
  %t124 = sub i64 %t122, 1
  %t125 = load i64, ptr %l11, !tbaa !24
  %t128 = sdiv i64 %t124, %t125
  store i64 %t128, ptr %l73, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t130 = load i64, ptr %l73, !tbaa !24
  store i64 %t130, ptr %l70, !tbaa !24
  br label %bb28
bb28:
  %t131 = load i64, ptr %l70, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l13, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp slt i64 %t132, %t133
  %t138 = xor i1 %t136, true
  br i1 %t138, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb31:
  br label %bb32
bb32:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t142 = load i64, ptr %l11, !tbaa !24
  %t145 = mul i64 %t141, %t142
  %t148 = add i64 %t140, %t145
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 75
  %t156 = call %"compiler/check:AssertAsk" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eA_Hdc7a201c0afbc93ed6dfeec3b1f47711(ptr %v0, ptr %v0, ptr %t152, i64 %t148)
  store %"compiler/check:AssertAsk" %t156, ptr %l94
  br label %bb33
bb33:
  %t157 = load %"compiler/check:AssertAsk", ptr %l94
  store %"compiler/check:AssertAsk" %t157, ptr %l15
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/check:AssertAsk", ptr %l15, i32 0, i32 6
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t166 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v0, ptr %t158, i64 %t160, { i64, ptr } %t162)
  store i1 %t166, ptr %l98
  br label %bb34
bb34:
  %t167 = load i1, ptr %l98, !tbaa !21
  %t168 = xor i1 %t167, true
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 75
  %t173 = load i64, ptr %l1, !tbaa !24
  %t174 = load %"compiler/check:AssertAsk", ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eS_Hc42af0083e860bde3bfdbe1629d1fbcf(ptr %v0, ptr %v0, ptr %t172, i64 %t173, %"compiler/check:AssertAsk" %t174)
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t178 = load i64, ptr %l1, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l1, !tbaa !24
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s7)
  br label %bb39
bb39:
  %t182 = load i64, ptr %l13, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l13, !tbaa !24
  br label %bb29
bb40:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 75
  %t189 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eT_H5b1bf5f8eb2d6b750ac9501715f6a378(ptr %v0, ptr %t188, i64 %t189)
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l27 = alloca i1
  %l33 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca %"compiler/check:litv"
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca %"compiler/check:litv"
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l59 = alloca i1
  %l63 = alloca %"compiler/check:litv"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load i1, ptr %l14, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t49 = load i32, ptr %l3
  %t51 = trunc i64 85 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb15
bb14:
  %t54 = load i32, ptr %l3
  %t56 = trunc i64 86 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  store %"compiler/check:litv" %t65, ptr %l33
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t66 = getelementptr %"compiler/check:litv", ptr %l33, i32 0, i32 0
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l5, !tbaa !29
  %t74 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t69, ptr %t70)
  store %"compiler/check:litv" %t74, ptr %l39
  br label %bb21
bb20:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb22
bb21:
  %t75 = getelementptr %"compiler/check:litv", ptr %l39, i32 0, i32 0
  %t76 = load i1, ptr %t75, !tbaa !21
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l35, !tbaa !21
  br label %bb22
bb22:
  %t80 = load i1, ptr %l35, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t81, ptr %t82)
  store i1 %t85, ptr %l44
  br label %bb24
bb24:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t92 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t87, ptr %t88)
  store %"compiler/check:litv" %t92, ptr %l49
  br label %bb27
bb26:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb32
bb27:
  %t93 = getelementptr %"compiler/check:litv", ptr %l49, i32 0, i32 0
  %t94 = load i1, ptr %t93, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb31
bb29:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l54
  br label %bb30
bb30:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %l51, !tbaa !21
  br label %bb31
bb31:
  %t102 = load i1, ptr %l51, !tbaa !21
  store i1 %t102, ptr %l45, !tbaa !21
  br label %bb32
bb32:
  %t103 = load i1, ptr %l45, !tbaa !21
  br i1 %t103, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb40
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i1 %t108, ptr %l58
  br label %bb35
bb35:
  %t109 = load i1, ptr %l58, !tbaa !21
  br i1 %t109, label %bb36, label %bb37
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  %t115 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store %"compiler/check:litv" %t115, ptr %l63
  br label %bb38
bb37:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb39
bb38:
  %t116 = getelementptr %"compiler/check:litv", ptr %l63, i32 0, i32 0
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l59, !tbaa !21
  br label %bb39
bb39:
  %t119 = load i1, ptr %l59, !tbaa !21
  store i1 %t119, ptr %l55, !tbaa !21
  br label %bb40
bb40:
  %t120 = load i1, ptr %l55, !tbaa !21
  store i1 %t120, ptr %rv
  br label %ret
bb41:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etakenSet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/typed:Item"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca { i64, ptr }
  %l32 = alloca i1
  %l39 = alloca i32
  %l50 = alloca i32
  %l52 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l65 = alloca { i64, ptr }
  %l77 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca ptr
  %l92 = alloca i64
  %l94 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l106 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l18
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l5
  store { i64, ptr } %a1, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb53
bb4:
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t18, ptr %l26, !tbaa !27
  %t19 = load i64, ptr %l7, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i32, ptr %t22, i64 %t19
  %t24 = load i32, ptr %t23, !tbaa !33
  store i32 %t24, ptr %l9, !tbaa !23
  %t26 = load i32, ptr %l9, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  %t30 = icmp eq i32 %t26, %t27
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb8
bb7:
  %t32 = load i32, ptr %l9, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  store i1 %t36, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t38 = load i1, ptr %l32, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb10:
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l9, !tbaa !23
  %t45 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v3, ptr %t39, i32 %t40, ptr %a4)
  store i32 %t45, ptr %l39
  br label %bb12
bb12:
  %t46 = load i32, ptr %l39, !tbaa !23
  store i32 %t46, ptr %l10, !tbaa !23
  %t47 = load i32, ptr %l10, !tbaa !23
  %t48 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t51 = icmp eq i32 %t47, %t48
  br i1 %t51, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb14:
  br label %bb15
bb15:
  br i1 %a3, label %bb16, label %bb17
bb16:
  %t55 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t55)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l10, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l50
  br label %bb20
bb20:
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %l11, !tbaa !23
  store ptr %a2, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s7
  %t71 = load ptr, ptr %l12, !tbaa !29
  %t72 = load i64, ptr %l13, !tbaa !24
  %t75 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eRunFrom_3ccompiler_2ftyped_3aItem_3e(ptr %v2, ptr %t71, i64 %t72)
  %t76 = extractvalue { i32, { i64, ptr } } %t75, 1
  %t77 = extractvalue { i32, { i64, ptr } } %t75, 0
  store i32 %t77, ptr %l56
  %t78 = icmp ne i32 %t77, 0
  br i1 %t78, label %bb23, label %ok.79
ok.79:
  store { i64, ptr } %t76, ptr %l55
  br label %bb22
bb22:
  %t80 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t80, ptr %l52, !tbaa !27
  br label %bb27
bb23:
  %t81 = load i32, ptr %l56, !tbaa !23
  %t82 = ashr i32 %t81, 16
  %t84 = icmp eq i32 %t82, 1
  br i1 %t84, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_5fd52f4d7445d4a4_148eaf691bd21768)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb27:
  %t86 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t86, ptr %l14, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t91 = load i64, ptr %l16, !tbaa !24
  %t92 = load i64, ptr %l15, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb30:
  br label %bb31
bb31:
  %t99 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t99, ptr %l65, !tbaa !27
  %t100 = load i64, ptr %l16, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr %"compiler/typed:Item", ptr %t103, i64 %t100
  %t105 = load %"compiler/typed:Item", ptr %t104
  store %"compiler/typed:Item" %t105, ptr %l17
  %t107 = getelementptr %"compiler/typed:Item", ptr %l17, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  %t109 = load i32, ptr %l11, !tbaa !23
  %t112 = icmp ne i32 %t108, %t109
  br i1 %t112, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb33:
  br label %bb34
bb34:
  %t114 = getelementptr %"compiler/typed:Item", ptr %l17, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = icmp slt i64 %t115, 0
  br i1 %t117, label %bb35, label %bb36
bb35:
  %t119 = load i32, ptr %l10, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l5, i32 %t119)
  br label %bb37
bb36:
  %t122 = getelementptr %"compiler/typed:Item", ptr %l17, i32 0, i32 1
  %t123 = load i64, ptr %t122, !tbaa !24
  %t125 = icmp slt i64 %t123, 64
  br i1 %t125, label %bb38, label %bb39
bb37:
  br label %bb47
bb38:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 2
  %t133 = load i32, ptr %l10, !tbaa !23
  %t136 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t132, i32 %t133)
  store i64 %t136, ptr %l82
  br label %bb40
bb39:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb41
bb40:
  %t137 = getelementptr %"compiler/typed:Item", ptr %l17, i32 0, i32 1
  %t138 = load i64, ptr %t137, !tbaa !24
  store i64 %t138, ptr %l83, !tbaa !24
  %t139 = load i64, ptr %l83, !tbaa !24
  %t140 = load i64, ptr %l83, !tbaa !24
  %t141 = shl i64 1, %t140
  %t142 = load i64, ptr %l82, !tbaa !65
  %t144 = and i64 %t142, %t141
  %t146 = icmp ne i64 %t144, 0
  store i1 %t146, ptr %l77, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l77, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  store ptr %l5, ptr %l87, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l11, !tbaa !23
  %t156 = getelementptr %"compiler/typed:Item", ptr %l17, i32 0, i32 1
  %t157 = load i64, ptr %t156, !tbaa !24
  store i64 %t157, ptr %l92, !tbaa !24
  %t158 = load i64, ptr %l92, !tbaa !24
  %t159 = load i64, ptr %l92, !tbaa !24
  %t160 = shl i64 1, %t159
  %t164 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t154, i32 %t155, i64 %t160)
  store i32 %t164, ptr %l94
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = load i32, ptr %l94, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t165, i32 %t166)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l16, !tbaa !24
  br label %bb28
bb49:
  %t171 = load i64, ptr %l13, !tbaa !24
  %t172 = load i64, ptr %l15, !tbaa !24
  %t175 = add i64 %t171, %t172
  store i64 %t175, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  br label %bb21
bb51:
  call void @__olang_scope_close(ptr %s2)
  br label %bb52
bb52:
  %t177 = load i64, ptr %l7, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l7, !tbaa !24
  br label %bb2
bb53:
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l102, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  store ptr %t182, ptr %l103, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t186 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s0, ptr %s0, ptr %t183, ptr %l5)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %l106
  br label %bb54
bb54:
  %t187 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  %t188 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t187, ptr %t188
  %t189 = load ptr, ptr %l103, !tbaa !29
  %t191 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %s0, ptr %s0, ptr %t189, ptr %t188)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %l108
  br label %bb55
bb55:
  %t192 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  %t193 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %t193
  %t194 = load ptr, ptr %l102, !tbaa !29
  %t196 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s0, ptr %t194, ptr %t193)
  store i32 %t196, ptr %l110
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t197 = load i32, ptr %l110, !tbaa !23
  store i32 %t197, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store ptr %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l15, !tbaa !29
  store ptr %t21, ptr %l6, !tbaa !29
  br label %bb32
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store ptr %t44, ptr %l25
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l25, !tbaa !29
  store ptr %t45, ptr %l6, !tbaa !29
  br label %bb32
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l27, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etempValue(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store ptr %t68, ptr %l35
  br label %bb20
bb20:
  %t69 = load ptr, ptr %l35, !tbaa !29
  store ptr %t69, ptr %l6, !tbaa !29
  br label %bb32
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l36, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb27
bb26:
  %t85 = load ptr, ptr %l5, !tbaa !29
  store ptr %t85, ptr %l6, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_8e2cf6b2c24620f0_dcbb1c47a1cef46c)
  unreachable
bb32:
  %t88 = load ptr, ptr %l6, !tbaa !29
  store ptr %t88, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 44
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr @.d28 }, { i64, ptr } { i64 6, ptr @.d29 })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 44
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 44
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/names:Ref"
  %l9 = alloca ptr
  %l10 = alloca i1
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca %"compiler/names:Ref"
  %l30 = alloca i32
  %l34 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca i32
  %l60 = alloca i1
  %l65 = alloca i32
  %l69 = alloca i1
  %l74 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca ptr
  %l93 = alloca %"compiler/names:Ref"
  %l96 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca i32
  %l105 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb42
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l19, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t29)
  store ptr %t31, ptr %l21
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l21, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l19, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l25
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l25
  store %"compiler/names:Ref" %t42, ptr %l4
  %t43 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t44 = load i32, ptr %t43
  %t46 = trunc i64 7 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l30
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t54 = load i32, ptr %l30, !tbaa !23
  store i32 %t54, ptr %l5, !tbaa !23
  %t55 = load i32, ptr %l5, !tbaa !23
  %t56 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t59 = icmp ne i32 %t55, %t56
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = load i32, ptr %l5, !tbaa !23
  store i32 %t61, ptr %l34, !tbaa !23
  br label %bb13
bb12:
  store i32 -1, ptr %l34, !tbaa !23
  br label %bb13
bb13:
  %t63 = load i32, ptr %l34, !tbaa !23
  store i32 %t63, ptr %rv
  br label %ret
bb14:
  %t64 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t65 = load i32, ptr %t64
  %t67 = trunc i64 4 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  store i1 %t73, ptr %l38, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t81 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i32 %t88, ptr %l46
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = load i32, ptr %l46, !tbaa !23
  %t91 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t91, ptr %l47
  br label %bb21
bb21:
  %t92 = load i32, ptr %l47, !tbaa !23
  store i32 %t92, ptr %rv
  br label %ret
bb22:
  %t93 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t94 = load i32, ptr %t93
  %t96 = trunc i64 8 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t99)
  store ptr %t101, ptr %l52
  br label %bb25
bb24:
  br label %bb41
bb25:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 4
  %t105 = getelementptr %"compiler/generic:Context", ptr %t104, i32 0, i32 2
  %t106 = load i32, ptr %l3, !tbaa !23
  %t109 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t105, i32 %t106)
  %t110 = extractvalue { i32, i32 } %t109, 1
  %t111 = extractvalue { i32, i32 } %t109, 0
  store i32 %t111, ptr %l57
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb27, label %ok.113
ok.113:
  store i32 %t110, ptr %l56
  br label %bb26
bb26:
  %t114 = load i32, ptr %l56, !tbaa !23
  store i32 %t114, ptr %l50, !tbaa !23
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  store i32 -1, ptr %l50, !tbaa !23
  br label %bb29
bb29:
  %t115 = load i32, ptr %l50, !tbaa !23
  store i32 %t115, ptr %l6, !tbaa !23
  %t116 = load i32, ptr %l6, !tbaa !23
  %t118 = icmp sge i32 %t116, 0
  br i1 %t118, label %bb30, label %bb31
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l6, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l65
  br label %bb32
bb31:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i32, ptr %l65
  %t132 = trunc i64 26 to i32
  %t133 = icmp eq i32 %t130, %t132
  %t135 = xor i1 %t133, true
  store i1 %t135, ptr %l60, !tbaa !21
  br label %bb33
bb33:
  %t137 = load i1, ptr %l60, !tbaa !21
  br i1 %t137, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l6, !tbaa !23
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t143, i32 %t144)
  store i32 %t147, ptr %l74
  br label %bb36
bb35:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb37
bb36:
  %t148 = load i32, ptr %l74
  %t150 = trunc i64 27 to i32
  %t151 = icmp eq i32 %t148, %t150
  %t153 = xor i1 %t151, true
  store i1 %t153, ptr %l69, !tbaa !21
  br label %bb37
bb37:
  %t155 = load i1, ptr %l69, !tbaa !21
  br i1 %t155, label %bb38, label %bb39
bb38:
  %t156 = load i32, ptr %l6, !tbaa !23
  store i32 %t156, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb59
bb42:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t159 = load ptr, ptr %l79, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t162 = load ptr, ptr %l79, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 15
  store i1 %t165, ptr %l80, !tbaa !21
  br label %bb44
bb44:
  %t166 = load i1, ptr %l80, !tbaa !21
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t169, i32 0, i32 0
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l7
  br label %bb47
bb46:
  br label %bb58
bb47:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t178 = getelementptr %"compiler/generic:Program", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  store ptr %t179, ptr %l87, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t180)
  store ptr %t182, ptr %l89
  br label %bb48
bb48:
  %t183 = load ptr, ptr %l89, !tbaa !29
  %t185 = getelementptr %"compiler/check:frame", ptr %t183, i32 0, i32 2
  %t186 = load i64, ptr %t185, !tbaa !24
  %t187 = getelementptr %"compiler/source:Span", ptr %l7, i32 0, i32 1
  %t188 = load i32, ptr %t187, !tbaa !23
  %t189 = load ptr, ptr %l87, !tbaa !29
  %t192 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t189, i64 %t186, i32 %t188)
  store %"compiler/names:Ref" %t192, ptr %l93
  br label %bb49
bb49:
  %t193 = load %"compiler/names:Ref", ptr %l93
  store %"compiler/names:Ref" %t193, ptr %l8
  %t194 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 0
  %t195 = load i32, ptr %t194
  %t197 = trunc i64 4 to i32
  %t198 = icmp eq i32 %t195, %t197
  br i1 %t198, label %bb50, label %bb51
bb50:
  %t200 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t201 = load i64, ptr %t200, !tbaa !24
  %t203 = icmp sge i64 %t201, 0
  store i1 %t203, ptr %l96, !tbaa !21
  br label %bb52
bb51:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb52
bb52:
  %t205 = load i1, ptr %l96, !tbaa !21
  br i1 %t205, label %bb53, label %bb54
bb53:
  %t206 = load ptr, ptr %l0, !tbaa !29
  store ptr %t206, ptr %l99, !tbaa !29
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 1
  %t212 = load i64, ptr %t211, !tbaa !24
  %t213 = getelementptr %"compiler/names:Ref", ptr %l8, i32 0, i32 2
  %t214 = load i64, ptr %t213, !tbaa !24
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t210, i64 %t212, i64 %t214)
  store i32 %t218, ptr %l104
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t219 = load ptr, ptr %l99, !tbaa !29
  %t220 = load i32, ptr %l104, !tbaa !23
  %t221 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %t219, i32 %t220)
  store i32 %t221, ptr %l105
  br label %bb56
bb56:
  %t222 = load i32, ptr %l105, !tbaa !23
  store i32 %t222, ptr %rv
  br label %ret
bb57:
  br label %bb59
bb58:
  br label %bb59
bb59:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l44 = alloca i32
  %l52 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a1, ptr %l6, !tbaa !23
  store i32 %a2, ptr %l7, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i32, ptr %l6, !tbaa !23
  %t9 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l12
  br label %bb1
bb1:
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l7, !tbaa !23
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l16
  br label %bb4
bb3:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i1, ptr %l16, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l13, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l22
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t30 = load i32, ptr %l22, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l7, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l25
  br label %bb10
bb10:
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !tbaa !23
  %t41 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb14
bb13:
  %t42 = load i1, ptr %l29, !tbaa !21
  %t43 = xor i1 %t42, true
  store i1 %t43, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t45 = load i1, ptr %l26, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l6, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t56 = load i32, ptr %l36
  %t58 = trunc i64 25 to i32
  %t59 = icmp eq i32 %t56, %t58
  %t61 = xor i1 %t59, true
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/check:Checker", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/generic:Program", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %l7, !tbaa !23
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t69, i32 %t70)
  store i32 %t73, ptr %l44
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t74 = load i32, ptr %l44, !tbaa !23
  store i32 %t74, ptr %l7, !tbaa !23
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/check:Checker", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t79 = load i32, ptr %l6, !tbaa !23
  %t80 = load i32, ptr %l7, !tbaa !23
  %t90 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %t78, i32 %t79, i32 %t80, ptr %a3, i1 %a4, i1 %a5)
  store i1 %t90, ptr %l52
  br label %bb23
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunifySoft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Binding"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca %"compiler/generic:Binding"
  %l21 = alloca i1
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca { i64, ptr }
  %l60 = alloca i1
  %l62 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/generic:Binding", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t4, i64 %t8)
  store %"compiler/generic:Binding" %t11, ptr %l15
  br label %bb1
bb1:
  %t12 = load %"compiler/generic:Binding", ptr %l15
  store %"compiler/generic:Binding" %t12, ptr %l4
  %t15 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t23 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %s0, ptr %t16, i32 %a1, i32 %a2, ptr %l4, i1 false, i1 false)
  store i1 %t23, ptr %l21
  br label %bb2
bb2:
  store i64 0, ptr %l5, !tbaa !24
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Binding", ptr %t24, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l7, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l30, !tbaa !24
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t56 = load i64, ptr %l27, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb11:
  br label %bb12
bb12:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l10, !tbaa !24
  %t75 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l48, !tbaa !27
  %t77 = load i64, ptr %l10, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  %t83 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t86 = icmp ne i32 %t82, %t83
  br i1 %t86, label %bb13, label %bb14
bb13:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Binding", ptr %t88, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i32, ptr %t95, i64 %t92
  %t97 = load i32, ptr %t96, !tbaa !33
  %t98 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t101 = icmp eq i32 %t97, %t98
  br i1 %t101, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb18
bb15:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb17
bb16:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Binding", ptr %t103, i32 0, i32 3
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l62, !tbaa !27
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i1, ptr %t110, i64 %t107
  %t112 = load i1, ptr %t111, !tbaa !31
  store i1 %t112, ptr %l60, !tbaa !21
  br label %bb17
bb17:
  %t114 = load i1, ptr %l60, !tbaa !21
  store i1 %t114, ptr %l53, !tbaa !21
  br label %bb18
bb18:
  %t115 = load i1, ptr %l53, !tbaa !21
  br i1 %t115, label %bb19, label %bb20
bb19:
  %t116 = load ptr, ptr %l3, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Binding", ptr %t116, i32 0, i32 2
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l66, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l68, !tbaa !27
  %t123 = load i64, ptr %l10, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  %t131 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr i32, ptr %t132, i64 %t120
  store i32 %t128, ptr %t133, !tbaa !33
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t136 = getelementptr %"compiler/generic:Binding", ptr %t134, i32 0, i32 3
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l72, !tbaa !27
  %t138 = load i64, ptr %l10, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i1, ptr %t141, i64 %t138
  store i1 false, ptr %t142, !tbaa !31
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = add i64 %t143, 1
  store i64 %t145, ptr %l9, !tbaa !24
  br label %bb9
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l82 = alloca %"compiler/check:atRec"
  %l86 = alloca i1
  %l90 = alloca %"compiler/check:atRec"
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l21
  br label %bb6
bb6:
  %t21 = load i64, ptr %l21, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l23, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t37, ptr %t41)
  store i64 %t44, ptr %l31
  br label %bb13
bb13:
  %t45 = load i64, ptr %l31, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb14:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t47 = load ptr, ptr %l32, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = load i64, ptr %t50
  %t53 = icmp eq i64 %t51, 5
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l33, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Payload", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTemp(ptr %v0, ptr %v1, ptr %t61, ptr %t65)
  store i64 %t68, ptr %l41
  br label %bb20
bb20:
  %t69 = load i64, ptr %l41, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t71 = load ptr, ptr %l42, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load i64, ptr %t74
  %t77 = icmp eq i64 %t75, 6
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t78 = load i1, ptr %l43, !tbaa !21
  br i1 %t78, label %bb24, label %bb25
bb24:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t81, i32 0, i32 3
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l5, !tbaa !23
  br label %bb26
bb25:
  br label %bb49
bb26:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t85)
  store ptr %t87, ptr %l49
  br label %bb27
bb27:
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 0
  %t91 = load i64, ptr %t90, !tbaa !24
  store i64 %t91, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 34
  %t97 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l54
  br label %bb28
bb28:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = icmp sgt i64 %t99, %t100
  br i1 %t103, label %bb29, label %bb30
bb29:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t107 = icmp sgt i64 %t105, 0
  br i1 %t107, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb34
bb31:
  %t109 = load i64, ptr %l8, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = sub i64 %t109, %t110
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = add i64 %t113, %t114
  %t119 = sub i64 %t117, 1
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = sdiv i64 %t119, %t120
  store i64 %t123, ptr %l61, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb33
bb33:
  %t125 = load i64, ptr %l61, !tbaa !24
  store i64 %t125, ptr %l58, !tbaa !24
  br label %bb34
bb34:
  %t126 = load i64, ptr %l58, !tbaa !24
  store i64 %t126, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb37:
  br label %bb38
bb38:
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = mul i64 %t136, %t137
  %t143 = add i64 %t135, %t140
  store i64 %t143, ptr %l12, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 34
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t147, i64 %t148)
  store %"compiler/check:atRec" %t151, ptr %l82
  br label %bb39
bb39:
  %t152 = getelementptr %"compiler/check:atRec", ptr %l82, i32 0, i32 0
  %t153 = load i64, ptr %t152, !tbaa !24
  %t154 = load i64, ptr %l6, !tbaa !24
  %t157 = icmp eq i64 %t153, %t154
  br i1 %t157, label %bb40, label %bb41
bb40:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 34
  %t162 = load i64, ptr %l12, !tbaa !24
  %t165 = call %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %s6, ptr %t161, i64 %t162)
  store %"compiler/check:atRec" %t165, ptr %l90
  br label %bb42
bb41:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb43
bb42:
  %t166 = getelementptr %"compiler/check:atRec", ptr %l90, i32 0, i32 1
  %t167 = load i64, ptr %t166, !tbaa !24
  %t168 = load i32, ptr %l5, !tbaa !23
  %t170 = sext i32 %t168 to i64
  %t173 = icmp eq i64 %t167, %t170
  store i1 %t173, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t175 = load i1, ptr %l86, !tbaa !21
  br i1 %t175, label %bb44, label %bb45
bb44:
  %t176 = load i64, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  store i64 %t176, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l11, !tbaa !24
  br label %bb35
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb4
bb3:
  %t15 = load i32, ptr %l4, !tbaa !23
  store i32 %t15, ptr %l12, !tbaa !23
  br label %bb5
bb4:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t20)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t30)
  store i32 %t33, ptr %l25
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load i1, ptr %l27, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l35
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l36
  br label %bb15
bb15:
  %t57 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s1, ptr %t64, ptr %t65)
  store { i64, ptr } %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t76, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l29, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load %"compiler/msgs:Msg", ptr %l42
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l43
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, i64 0)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l47, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l49
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l50
  store i32 72, ptr %l51
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, ptr %a2)
  store ptr %t101, ptr %l56
  br label %bb21
bb21:
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t103, ptr %t104, %"compiler/source:Span" %t102)
  store ptr %t106, ptr %l58
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l5, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l60
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l62
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l49
  %t114 = load %"compiler/source:Span", ptr %l50
  %t115 = load i32, ptr %l51
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l62
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i32 %t115, ptr %t116, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i1
  %l28 = alloca i32
  %l35 = alloca i64
  %l38 = alloca i1
  %l43 = alloca i64
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l88 = alloca i32
  %l97 = alloca i32
  %l99 = alloca ptr
  %l104 = alloca i32
  %l111 = alloca ptr
  %l116 = alloca i32
  %l125 = alloca ptr
  %l130 = alloca i32
  %l131 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l154 = alloca i32
  %l165 = alloca ptr
  %l170 = alloca i32
  %l171 = alloca { i64, ptr }
  %l178 = alloca { i64, ptr }
  %l191 = alloca ptr
  %l196 = alloca i32
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp sgt i64 %t1, 32
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l20, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l28
  br label %bb7
bb7:
  %t22 = load i32, ptr %l28
  store i32 %t22, ptr %l5
  %t23 = load i32, ptr %l5
  %t25 = trunc i64 25 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l35
  br label %bb11
bb11:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l35, !tbaa !24
  %t41 = icmp eq i64 %t39, %t38
  br i1 %t41, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t52, ptr %l43
  br label %bb14
bb13:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb15
bb14:
  %t53 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = load i64, ptr %l43, !tbaa !24
  %t58 = icmp slt i64 %t56, %t55
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t61, ptr %l47, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l1, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l52
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t72 = load i64, ptr %l52, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i1, ptr %t74, i64 %t72
  store i1 true, ptr %t75, !tbaa !31
  br label %bb19
bb19:
  br label %bb88
bb20:
  %t76 = load i32, ptr %l5
  %t78 = trunc i64 18 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb33
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t86 = getelementptr %"compiler/generic:Program", ptr %t84, i32 0, i32 2
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l62
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l57, !tbaa !29
  %t98 = load i32, ptr %l62, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l63
  br label %bb25
bb25:
  %t100 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t100, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  store i64 %t103, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t113, ptr %l70, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l2, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = add i64 %t125, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t121, i32 %t119, i64 %t123, { i64, ptr } %t124, i64 %t127)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l7, !tbaa !24
  br label %bb26
bb32:
  br label %bb88
bb33:
  %t137 = load i32, ptr %l5
  %t139 = trunc i64 19 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb45
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l83, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l88
  br label %bb37
bb37:
  %t153 = load i64, ptr %l2, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = load i64, ptr %l4, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load ptr, ptr %l83, !tbaa !29
  %t159 = load i32, ptr %l88, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t158, i32 %t159, i64 %t153, { i64, ptr } %t154, i64 %t157)
  br label %bb38
bb38:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l1, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t168, i32 %t169)
  store i32 %t172, ptr %l97
  br label %bb39
bb39:
  %t173 = load i32, ptr %l97, !tbaa !23
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb40, label %bb41
bb40:
  %t176 = load ptr, ptr %l0, !tbaa !29
  store ptr %t176, ptr %l99, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/generic:Program", ptr %t180, i32 0, i32 2
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t182, i32 %t183)
  store i32 %t186, ptr %l104
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t187 = load i64, ptr %l2, !tbaa !24
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load i64, ptr %l4, !tbaa !24
  %t191 = add i64 %t189, 1
  %t192 = load ptr, ptr %l99, !tbaa !29
  %t193 = load i32, ptr %l104, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t192, i32 %t193, i64 %t187, { i64, ptr } %t188, i64 %t191)
  br label %bb43
bb43:
  br label %bb44
bb44:
  br label %bb88
bb45:
  %t197 = load i32, ptr %l5
  %t199 = trunc i64 20 to i32
  %t200 = icmp eq i32 %t197, %t199
  br i1 %t200, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l111, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l1, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l116
  br label %bb49
bb49:
  %t213 = load i64, ptr %l2, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t215 = load i64, ptr %l4, !tbaa !24
  %t217 = add i64 %t215, 1
  %t218 = load ptr, ptr %l111, !tbaa !29
  %t219 = load i32, ptr %l116, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t218, i32 %t219, i64 %t213, { i64, ptr } %t214, i64 %t217)
  br label %bb50
bb50:
  br label %bb88
bb51:
  %t223 = load i32, ptr %l5
  %t225 = trunc i64 21 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb66
bb54:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  store ptr %t233, ptr %l125, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %l1, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l130
  br label %bb55
bb55:
  %t244 = load ptr, ptr %l125, !tbaa !29
  %t245 = load i32, ptr %l130, !tbaa !23
  %t246 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t244, i32 %t245)
  store { i64, ptr } %t246, ptr %l131
  br label %bb56
bb56:
  %t247 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t247, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t248, 0
  store i64 %t250, ptr %l12, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s13
  %t252 = load i64, ptr %l11, !tbaa !24
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = icmp slt i64 %t252, %t253
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s13)
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t260 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t260, ptr %l138, !tbaa !27
  %t261 = load i64, ptr %l11, !tbaa !24
  %t263 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t264 = load ptr, ptr %t263, !tbaa !27
  %t265 = getelementptr i32, ptr %t264, i64 %t261
  %t266 = load i32, ptr %t265, !tbaa !33
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i64, ptr %l2, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t272 = load i64, ptr %l4, !tbaa !24
  %t274 = add i64 %t272, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t268, i32 %t266, i64 %t270, { i64, ptr } %t271, i64 %t274)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s13)
  br label %bb62
bb62:
  %t280 = load i64, ptr %l11, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l11, !tbaa !24
  br label %bb57
bb63:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l149, !tbaa !29
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !29
  %t290 = getelementptr %"compiler/generic:Program", ptr %t288, i32 0, i32 2
  %t291 = load i32, ptr %l1, !tbaa !23
  %t294 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t294, ptr %l154
  br label %bb64
bb64:
  %t295 = load i64, ptr %l2, !tbaa !24
  %t296 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t297 = load i64, ptr %l4, !tbaa !24
  %t299 = add i64 %t297, 1
  %t300 = load ptr, ptr %l149, !tbaa !29
  %t301 = load i32, ptr %l154, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t300, i32 %t301, i64 %t295, { i64, ptr } %t296, i64 %t299)
  br label %bb65
bb65:
  br label %bb88
bb66:
  %t305 = load i32, ptr %l5
  %t307 = trunc i64 22 to i32
  %t308 = icmp eq i32 %t305, %t307
  br i1 %t308, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  %t310 = load i32, ptr %l5
  %t312 = trunc i64 23 to i32
  %t313 = icmp eq i32 %t310, %t312
  br i1 %t313, label %bb69, label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb81
bb71:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Program", ptr %t318, i32 0, i32 2
  store ptr %t320, ptr %l165, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/check:Checker", ptr %t321, i32 0, i32 1
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/generic:Program", ptr %t324, i32 0, i32 2
  %t327 = load i32, ptr %l1, !tbaa !23
  %t330 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t326, i32 %t327)
  store i32 %t330, ptr %l170
  br label %bb72
bb72:
  %t331 = load ptr, ptr %l165, !tbaa !29
  %t332 = load i32, ptr %l170, !tbaa !23
  %t333 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t331, i32 %t332)
  store { i64, ptr } %t333, ptr %l171
  br label %bb73
bb73:
  %t334 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t334, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l16, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s17
  %t339 = load i64, ptr %l15, !tbaa !24
  %t340 = load i64, ptr %l16, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb80
bb76:
  br label %bb77
bb77:
  %t347 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t347, ptr %l178, !tbaa !27
  %t348 = load i64, ptr %l15, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr i32, ptr %t351, i64 %t348
  %t353 = load i32, ptr %t352, !tbaa !33
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = load i64, ptr %l2, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t359 = load i64, ptr %l4, !tbaa !24
  %t361 = add i64 %t359, 1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t355, i32 %t353, i64 %t357, { i64, ptr } %t358, i64 %t361)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  %t367 = load i64, ptr %l15, !tbaa !24
  %t369 = add i64 %t367, 1
  store i64 %t369, ptr %l15, !tbaa !24
  br label %bb74
bb80:
  br label %bb88
bb81:
  %t371 = load i32, ptr %l5
  %t373 = trunc i64 29 to i32
  %t374 = icmp eq i32 %t371, %t373
  br i1 %t374, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l191, !tbaa !29
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = getelementptr %"compiler/generic:Program", ptr %t380, i32 0, i32 2
  %t383 = load i32, ptr %l1, !tbaa !23
  %t386 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t382, i32 %t383)
  store i32 %t386, ptr %l196
  br label %bb85
bb85:
  %t387 = load i64, ptr %l2, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t389 = load i64, ptr %l4, !tbaa !24
  %t391 = add i64 %t389, 1
  %t392 = load ptr, ptr %l191, !tbaa !29
  %t393 = load i32, ptr %l196, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evarsIn(ptr %v0, ptr %v1, ptr %t392, i32 %t393, i64 %t387, { i64, ptr } %t388, i64 %t391)
  br label %bb86
bb86:
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalk(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l67 = alloca i32
  %l74 = alloca i32
  %l80 = alloca i1
  %l81 = alloca i32
  %l88 = alloca i32
  %l92 = alloca i64
  %l94 = alloca ptr
  %l97 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l100 = alloca i1
  %l101 = alloca i1
  %l105 = alloca i1
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca i32
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i32
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l142 = alloca i32
  %l143 = alloca ptr
  %l146 = alloca ptr
  %l147 = alloca %"compiler/source:Span"
  %l149 = alloca i32
  %l150 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l156 = alloca ptr
  %l157 = alloca %"compiler/source:Span"
  %l159 = alloca i32
  %l160 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l180 = alloca ptr
  %l184 = alloca i32
  %l189 = alloca i32
  %l193 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l205 = alloca i64
  %l208 = alloca i64
  %l227 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l231 = alloca i1
  %l232 = alloca i1
  %l235 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l242 = alloca i32
  %l243 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l260 = alloca %"compiler/source:Span"
  %l263 = alloca { i64, ptr }
  %l265 = alloca %"compiler/msgs:Msg"
  %l266 = alloca i64
  %l271 = alloca i64
  %l275 = alloca i64
  %l278 = alloca i1
  %l281 = alloca i1
  %l285 = alloca i1
  %l309 = alloca i64
  %l312 = alloca ptr
  %l313 = alloca %"compiler/source:Span"
  %l316 = alloca %"compiler/source:Span"
  %l317 = alloca i64
  %l319 = alloca ptr
  %l322 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l329 = alloca ptr
  %l330 = alloca ptr
  %l331 = alloca ptr
  %l334 = alloca i32
  %l335 = alloca i32
  %l336 = alloca i64
  %l339 = alloca ptr
  %l342 = alloca %"compiler/source:Span"
  %l355 = alloca i64
  %l358 = alloca i64
  %l361 = alloca i1
  %l364 = alloca ptr
  %l367 = alloca ptr
  %l371 = alloca i32
  %l372 = alloca i32
  %l373 = alloca { i64, ptr }
  %l377 = alloca ptr
  %l378 = alloca ptr
  %l383 = alloca i1
  %l398 = alloca i1
  %l400 = alloca ptr
  %l403 = alloca %"compiler/source:Span"
  %l406 = alloca { i64, ptr }
  %l408 = alloca %"compiler/msgs:Msg"
  %l409 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca ptr
  %t196 = alloca { i64, [3 x i64] }, align 8
  %t235 = alloca { i64, [3 x i64] }, align 8
  %t283 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ForIn", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  store ptr %t6, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t7 = load ptr, ptr %l32, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l32, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 25
  store i1 %t13, ptr %l33, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l33, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t17, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load %"compiler/source:Span", ptr %l1
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t26 = load i32, ptr %l4, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t21, %"compiler/source:Span" %t22, ptr %t23, { i64, ptr } %t24, ptr %t25, i32 %t26)
  store ptr %t33, ptr %l44
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load ptr, ptr %l44, !tbaa !29
  store ptr %t34, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:ForIn", ptr %t35, i32 0, i32 3
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t40)
  store ptr %t42, ptr %l48
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t43 = load ptr, ptr %l48, !tbaa !29
  store ptr %t43, ptr %l49, !tbaa !29
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 15
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t50 = load ptr, ptr %l49, !tbaa !29
  %t51 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 15
  store i64 %t48, ptr %t51, !tbaa !24
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 2
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t62 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t52, ptr %t56, i32 %t58)
  store ptr %t62, ptr %l57
  br label %bb13
bb13:
  %t63 = load ptr, ptr %l57, !tbaa !29
  store ptr %t63, ptr %l7, !tbaa !29
  %t64 = load ptr, ptr %l2, !tbaa !29
  %t66 = getelementptr %"compiler/ast:ForIn", ptr %t64, i32 0, i32 3
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t69)
  store ptr %t71, ptr %l61
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t72 = load ptr, ptr %l61, !tbaa !29
  store ptr %t72, ptr %l62, !tbaa !29
  %t73 = load ptr, ptr %l62, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 15
  %t75 = load i64, ptr %t74, !tbaa !24
  %t77 = sub i64 %t75, 1
  %t79 = load ptr, ptr %l62, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 15
  store i64 %t77, ptr %t80, !tbaa !24
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t84 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t81)
  store i32 %t84, ptr %l67
  br label %bb18
bb18:
  %t85 = load i32, ptr %l67, !tbaa !23
  store i32 %t85, ptr %l8, !tbaa !23
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t90 = icmp eq i32 %t86, %t87
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l8, !tbaa !23
  %t97 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t97, ptr %l74
  br label %bb22
bb22:
  %t98 = load i32, ptr %l74, !tbaa !23
  store i32 %t98, ptr %l9, !tbaa !23
  %t99 = load i32, ptr %l9, !tbaa !23
  %t100 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t103 = icmp ne i32 %t99, %t100
  br i1 %t103, label %bb23, label %bb24
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l8, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t105, i32 %t106)
  store i1 %t109, ptr %l80
  br label %bb25
bb24:
  br label %bb57
bb25:
  %t110 = load i1, ptr %l80, !tbaa !21
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t111 = load i32, ptr %l8, !tbaa !23
  store i32 %t111, ptr %l81, !tbaa !23
  br label %bb29
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l8, !tbaa !23
  %t120 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t124 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t118, i32 %t119, i64 %t120)
  store i32 %t124, ptr %l88
  br label %bb28
bb28:
  %t125 = load i32, ptr %l88, !tbaa !23
  store i32 %t125, ptr %l81, !tbaa !23
  br label %bb29
bb29:
  %t126 = load i32, ptr %l81, !tbaa !23
  store i32 %t126, ptr %l10, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t129 = load i32, ptr %l10, !tbaa !23
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t127, %"compiler/source:Span" %t128, i32 %t129)
  store i64 %t133, ptr %l92
  br label %bb30
bb30:
  %t134 = load i64, ptr %l92, !tbaa !24
  store i64 %t134, ptr %l11, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/check:Checker", ptr %t135, i32 0, i32 56
  store ptr %t137, ptr %l94, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t138, i64 %t139)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t142, ptr %l97
  br label %bb31
bb31:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i32, ptr %l8, !tbaa !23
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t143, i32 %t144)
  store i1 %t147, ptr %l100
  br label %bb32
bb32:
  %t148 = load i1, ptr %l100, !tbaa !21
  br i1 %t148, label %bb33, label %bb34
bb33:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load ptr, ptr %l7, !tbaa !29
  %t154 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t149, ptr %t150)
  store i1 %t154, ptr %l105
  br label %bb35
bb34:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l106, !tbaa !29
  %t156 = load ptr, ptr %l7, !tbaa !29
  %t158 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t156)
  store ptr %t158, ptr %l108
  br label %bb36
bb35:
  %t159 = load i1, ptr %l105, !tbaa !21
  store i1 %t159, ptr %l101, !tbaa !21
  br label %bb38
bb36:
  %t160 = load ptr, ptr %l106, !tbaa !29
  %t161 = load ptr, ptr %l108, !tbaa !29
  %t162 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t160, ptr %t161)
  store i1 %t162, ptr %l109
  br label %bb37
bb37:
  %t163 = load i1, ptr %l109, !tbaa !21
  store i1 %t163, ptr %l101, !tbaa !21
  br label %bb38
bb38:
  %t164 = load ptr, ptr %l94, !tbaa !29
  %t165 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l97
  %t166 = load i1, ptr %l101, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t164, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t165, i1 %t166)
  br label %bb39
bb39:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l110, !tbaa !29
  %t168 = load ptr, ptr %l7, !tbaa !29
  store ptr %t168, ptr %l111, !tbaa !29
  %t169 = load i32, ptr %l10, !tbaa !23
  store i32 %t169, ptr %l112, !tbaa !23
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/ast:ForIn", ptr %t170, i32 0, i32 2
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t173)
  store %"compiler/source:Span" %t175, ptr %l115
  br label %bb40
bb40:
  %t176 = load ptr, ptr %l110, !tbaa !29
  %t177 = load ptr, ptr %l111, !tbaa !29
  %t178 = load i32, ptr %l112, !tbaa !23
  %t179 = load %"compiler/source:Span", ptr %l115
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t176, ptr %t177, i32 %t178, %"compiler/source:Span" %t179)
  store ptr %t180, ptr %l116
  br label %bb41
bb41:
  %t181 = load ptr, ptr %l116, !tbaa !29
  store ptr %t181, ptr %l12, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i64, ptr %l11, !tbaa !24
  %t184 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t182, i64 %t183, ptr %t184)
  br label %bb42
bb42:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load %"compiler/source:Span", ptr %l1
  %t191 = load i64, ptr %l11, !tbaa !24
  %t193 = trunc i64 %t191 to i32
  %t195 = load ptr, ptr %l12, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t196
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 0
  store i64 0, ptr %t197
  %t199 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t190, 0
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } %t199, i32 %t193, 1
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, ptr %t195, 2
  %t204 = getelementptr { i64, [3 x i64] }, ptr %t196, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t203, ptr %t204
  %t205 = load { i64, [3 x i64] }, ptr %t196
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t205, ptr %t207
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t189, ptr %t207)
  br label %bb43
bb43:
  %t210 = load ptr, ptr %l0, !tbaa !29
  store ptr %t210, ptr %l129, !tbaa !29
  %t211 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t211, ptr %l130
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t212)
  store i32 %t214, ptr %l132
  br label %bb44
bb44:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l130
  %t217 = load i32, ptr %l132, !tbaa !23
  %t218 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t215, %"compiler/source:Span" %t216, i32 %t217)
  store i64 %t218, ptr %l133
  br label %bb45
bb45:
  %t219 = load i64, ptr %l133, !tbaa !24
  store i64 %t219, ptr %l13, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l134, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t221, ptr %l135
  %t222 = load i64, ptr %l13, !tbaa !24
  %t224 = trunc i64 %t222 to i32
  store i32 %t224, ptr %l138, !tbaa !23
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l139, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t227, ptr %l140
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t228)
  store i32 %t230, ptr %l142
  br label %bb46
bb46:
  %t231 = load ptr, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l140
  %t233 = load i32, ptr %l142, !tbaa !23
  %t234 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t231, %"compiler/source:Span" %t232, i32 %t233, i64 0)
  store ptr %t234, ptr %l143
  br label %bb47
bb47:
  store { i64, [3 x i64] } zeroinitializer, ptr %t235
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 0
  store i64 0, ptr %t236
  %t237 = load %"compiler/source:Span", ptr %l135
  %t238 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t237, 0
  %t239 = load i32, ptr %l138, !tbaa !23
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } %t238, i32 %t239, 1
  %t241 = load ptr, ptr %l143, !tbaa !29
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, ptr %t241, 2
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t235, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t242, ptr %t243
  %t244 = load { i64, [3 x i64] }, ptr %t235
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t244, ptr %t246
  %t247 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t247, ptr %t246)
  br label %bb48
bb48:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l146, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t250, ptr %l147
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t251)
  store i32 %t253, ptr %l149
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l146, !tbaa !29
  %t255 = load %"compiler/source:Span", ptr %l147
  %t256 = load i32, ptr %l149, !tbaa !23
  %t257 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t254, %"compiler/source:Span" %t255, i32 %t256)
  store i64 %t257, ptr %l150
  br label %bb50
bb50:
  %t258 = load i64, ptr %l150, !tbaa !24
  store i64 %t258, ptr %l14, !tbaa !24
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l151, !tbaa !29
  %t260 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t260, ptr %l152
  %t261 = load i64, ptr %l14, !tbaa !24
  %t263 = trunc i64 %t261 to i32
  store i32 %t263, ptr %l155, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l156, !tbaa !29
  %t266 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t266, ptr %l157
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t267)
  store i32 %t269, ptr %l159
  br label %bb51
bb51:
  store i32 22, ptr %l160
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load %"compiler/source:Span", ptr %l1
  %t272 = load i64, ptr %l11, !tbaa !24
  %t276 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t270, %"compiler/source:Span" %t271, i64 %t272)
  store ptr %t276, ptr %l164
  br label %bb52
bb52:
  %t277 = load ptr, ptr %l156, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l157
  %t279 = load i32, ptr %l159, !tbaa !23
  %t280 = load i32, ptr %l160
  %t281 = load ptr, ptr %l164, !tbaa !29
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t277, %"compiler/source:Span" %t278, i32 %t279, i32 %t280, ptr %t281, ptr null)
  store ptr %t282, ptr %l165
  br label %bb53
bb53:
  store { i64, [3 x i64] } zeroinitializer, ptr %t283
  %t284 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 0
  store i64 0, ptr %t284
  %t285 = load %"compiler/source:Span", ptr %l152
  %t286 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t285, 0
  %t287 = load i32, ptr %l155, !tbaa !23
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr } %t286, i32 %t287, 1
  %t289 = load ptr, ptr %l165, !tbaa !29
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr } %t288, ptr %t289, 2
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t283, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t290, ptr %t291
  %t292 = load { i64, [3 x i64] }, ptr %t283
  %t294 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t292, ptr %t294
  %t295 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t295, ptr %t294)
  br label %bb54
bb54:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/source:Span", ptr %l1
  %t299 = load ptr, ptr %l2, !tbaa !29
  %t300 = load i64, ptr %l13, !tbaa !24
  %t301 = load i64, ptr %l14, !tbaa !24
  %t302 = load i64, ptr %l11, !tbaa !24
  %t303 = load i32, ptr %l9, !tbaa !23
  %t304 = load ptr, ptr %l3, !tbaa !29
  %t305 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %t297, %"compiler/source:Span" %t298, ptr %t299, i64 %t300, i64 %t301, i64 %t302, i32 %t303, i64 -1, i64 -1, ptr %t304, i32 %t305)
  br label %bb55
bb55:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load %"compiler/source:Span", ptr %l1
  %t317 = load i64, ptr %l14, !tbaa !24
  %t321 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t315, %"compiler/source:Span" %t316, i64 %t317)
  store ptr %t321, ptr %l180
  br label %bb56
bb56:
  %t322 = load ptr, ptr %l180, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t322, ptr %rv
  br label %ret
bb57:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i32, ptr %l8, !tbaa !23
  %t328 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t324, i32 %t325)
  store i32 %t328, ptr %l184
  br label %bb58
bb58:
  %t329 = load i32, ptr %l184, !tbaa !23
  store i32 %t329, ptr %l15, !tbaa !23
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t330, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t335 = getelementptr %"compiler/generic:Program", ptr %t333, i32 0, i32 2
  %t336 = load i32, ptr %l15, !tbaa !23
  %t339 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t335, i32 %t336)
  store i32 %t339, ptr %l189
  br label %bb59
bb59:
  %t340 = load i32, ptr %l189
  %t342 = trunc i64 29 to i32
  %t343 = icmp eq i32 %t340, %t342
  br i1 %t343, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  store ptr %t348, ptr %l193, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/check:Checker", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = getelementptr %"compiler/generic:Program", ptr %t352, i32 0, i32 2
  %t355 = load i32, ptr %l15, !tbaa !23
  %t358 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l198
  br label %bb62
bb61:
  br label %bb91
bb62:
  %t359 = load ptr, ptr %l193, !tbaa !29
  %t360 = load i32, ptr %l198, !tbaa !23
  %t361 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t359, i32 %t360)
  store { i64, ptr } %t361, ptr %l199
  br label %bb63
bb63:
  %t362 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t362, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t363 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t363, 0
  store i64 %t365, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t367 = load i64, ptr %l18, !tbaa !24
  %t368 = load i64, ptr %l17, !tbaa !24
  %t371 = icmp sgt i64 %t367, %t368
  br i1 %t371, label %bb64, label %bb65
bb64:
  %t373 = load i64, ptr %l19, !tbaa !24
  %t375 = icmp sgt i64 %t373, 0
  br i1 %t375, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l205, !tbaa !24
  br label %bb69
bb66:
  %t377 = load i64, ptr %l18, !tbaa !24
  %t378 = load i64, ptr %l17, !tbaa !24
  %t381 = sub i64 %t377, %t378
  %t382 = load i64, ptr %l19, !tbaa !24
  %t385 = add i64 %t381, %t382
  %t387 = sub i64 %t385, 1
  %t388 = load i64, ptr %l19, !tbaa !24
  %t391 = sdiv i64 %t387, %t388
  store i64 %t391, ptr %l208, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb68
bb68:
  %t393 = load i64, ptr %l208, !tbaa !24
  store i64 %t393, ptr %l205, !tbaa !24
  br label %bb69
bb69:
  %t394 = load i64, ptr %l205, !tbaa !24
  store i64 %t394, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s9
  %t395 = load i64, ptr %l21, !tbaa !24
  %t396 = load i64, ptr %l20, !tbaa !24
  %t399 = icmp slt i64 %t395, %t396
  %t401 = xor i1 %t399, true
  br i1 %t401, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s9)
  br label %bb86
bb72:
  br label %bb73
bb73:
  %t403 = load i64, ptr %l17, !tbaa !24
  %t404 = load i64, ptr %l21, !tbaa !24
  %t405 = load i64, ptr %l19, !tbaa !24
  %t408 = mul i64 %t404, %t405
  %t411 = add i64 %t403, %t408
  store i64 %t411, ptr %l22, !tbaa !24
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t414, ptr %l227, !tbaa !27
  %t415 = load i64, ptr %l22, !tbaa !24
  %t417 = getelementptr { i64, ptr }, ptr %l227, i32 0, i32 1
  %t418 = load ptr, ptr %t417, !tbaa !27
  %t419 = getelementptr %"compiler/generic:AnySlot", ptr %t418, i64 %t415
  %t420 = getelementptr %"compiler/generic:AnySlot", ptr %t419, i32 0, i32 0
  %t421 = load i32, ptr %t420, !tbaa !23
  %t424 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t413, i32 %t421)
  store { i64, ptr } %t424, ptr %l230
  br label %bb74
bb74:
  %t425 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t426 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s9, { i64, ptr } %t425, { i64, ptr } { i64 4, ptr @.d30 })
  store i1 %t426, ptr %l231
  br label %bb75
bb75:
  %t427 = load i1, ptr %l231, !tbaa !21
  br i1 %t427, label %bb76, label %bb77
bb76:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/check:Checker", ptr %t428, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !29
  %t433 = getelementptr %"compiler/generic:Program", ptr %t431, i32 0, i32 2
  store ptr %t433, ptr %l235, !tbaa !29
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = getelementptr %"compiler/check:Checker", ptr %t434, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = getelementptr %"compiler/generic:Program", ptr %t437, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t440, ptr %l239, !tbaa !27
  %t441 = load i64, ptr %l22, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr %"compiler/generic:AnySlot", ptr %t444, i64 %t441
  %t446 = getelementptr %"compiler/generic:AnySlot", ptr %t445, i32 0, i32 5
  %t447 = load i32, ptr %t446, !tbaa !23
  %t450 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t439, i32 %t447)
  store i32 %t450, ptr %l242
  br label %bb78
bb77:
  store i1 false, ptr %l232, !tbaa !21
  br label %bb80
bb78:
  %t451 = load ptr, ptr %l235, !tbaa !29
  %t452 = load i32, ptr %l242, !tbaa !23
  %t453 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t451, i32 %t452)
  store { i64, ptr } %t453, ptr %l243
  br label %bb79
bb79:
  %t454 = load { i64, ptr }, ptr %l243, !tbaa !27
  %t455 = extractvalue { i64, ptr } %t454, 0
  %t457 = icmp eq i64 %t455, 1
  store i1 %t457, ptr %l232, !tbaa !21
  br label %bb80
bb80:
  %t459 = load i1, ptr %l232, !tbaa !21
  br i1 %t459, label %bb81, label %bb82
bb81:
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t463 = load ptr, ptr %l7, !tbaa !29
  %t464 = load i64, ptr %l22, !tbaa !24
  %t466 = sub i64 -2, %t464
  %t467 = load ptr, ptr %l3, !tbaa !29
  %t468 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t460, %"compiler/source:Span" %t461, ptr %t462, ptr %t463, i64 %t466, ptr %t467, i32 %t468)
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb84:
  call void @__olang_scope_close(ptr %s9)
  br label %bb85
bb85:
  %t477 = load i64, ptr %l21, !tbaa !24
  %t479 = add i64 %t477, 1
  store i64 %t479, ptr %l21, !tbaa !24
  br label %bb70
bb86:
  %t481 = load ptr, ptr %l0, !tbaa !29
  store ptr %t481, ptr %l257, !tbaa !29
  %t482 = load ptr, ptr %l2, !tbaa !29
  %t484 = getelementptr %"compiler/ast:ForIn", ptr %t482, i32 0, i32 2
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t485)
  store %"compiler/source:Span" %t487, ptr %l260
  br label %bb87
bb87:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l8, !tbaa !23
  %t492 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t488, i32 %t489)
  store { i64, ptr } %t492, ptr %l263
  br label %bb88
bb88:
  %t493 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t493, 0
  %t495 = extractvalue { i64, ptr } %t493, 1
  %t496 = mul i64 %t494, 1
  %t497 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t496)
  call void @llvm.memcpy.p0.p0.i64(ptr %t497, ptr %t495, i64 %t496, i1 false)
  %t498 = insertvalue { i64, ptr } undef, i64 %t494, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t497, 1
  %t501 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s7, ptr %s7, { i64, ptr } %t499)
  store %"compiler/msgs:Msg" %t501, ptr %l265
  br label %bb89
bb89:
  %t502 = load ptr, ptr %l257, !tbaa !29
  %t503 = load %"compiler/source:Span", ptr %l260
  %t504 = load %"compiler/msgs:Msg", ptr %l265
  %t505 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t502, %"compiler/source:Span" %t503, %"compiler/msgs:Msg" %t504)
  store i64 %t505, ptr %l266
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb91:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t508 = load i32, ptr %l15, !tbaa !23
  %t509 = load %"compiler/source:Span", ptr %l1
  %t513 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t507, i32 %t508, { i64, ptr } { i64 7, ptr @.d31 }, i64 1, %"compiler/source:Span" %t509, { i64, ptr } { i64 5, ptr @.d32 })
  store i64 %t513, ptr %l271
  br label %bb92
bb92:
  %t514 = load i64, ptr %l271, !tbaa !24
  store i64 %t514, ptr %l23, !tbaa !24
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load i32, ptr %l15, !tbaa !23
  %t517 = load %"compiler/source:Span", ptr %l1
  %t521 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t515, i32 %t516, { i64, ptr } { i64 4, ptr @.d33 }, i64 0, %"compiler/source:Span" %t517, { i64, ptr } { i64 5, ptr @.d34 })
  store i64 %t521, ptr %l275
  br label %bb93
bb93:
  %t522 = load i64, ptr %l275, !tbaa !24
  store i64 %t522, ptr %l24, !tbaa !24
  %t523 = load i64, ptr %l24, !tbaa !24
  %t525 = icmp sge i64 %t523, 0
  br i1 %t525, label %bb94, label %bb95
bb94:
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load i64, ptr %l24, !tbaa !24
  %t531 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %t527, i64 %t528)
  store i1 %t531, ptr %l281
  br label %bb96
bb95:
  store i1 false, ptr %l278, !tbaa !21
  br label %bb97
bb96:
  %t532 = load i1, ptr %l281, !tbaa !21
  %t533 = xor i1 %t532, true
  store i1 %t533, ptr %l278, !tbaa !21
  br label %bb97
bb97:
  %t535 = load i1, ptr %l278, !tbaa !21
  br i1 %t535, label %bb98, label %bb99
bb98:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb100
bb99:
  br label %bb100
bb100:
  %t536 = load i64, ptr %l23, !tbaa !24
  %t538 = icmp sge i64 %t536, 0
  br i1 %t538, label %bb101, label %bb102
bb101:
  %t540 = load i64, ptr %l24, !tbaa !24
  %t542 = icmp slt i64 %t540, 0
  store i1 %t542, ptr %l285, !tbaa !21
  br label %bb103
bb102:
  store i1 false, ptr %l285, !tbaa !21
  br label %bb103
bb103:
  %t544 = load i1, ptr %l285, !tbaa !21
  br i1 %t544, label %bb104, label %bb105
bb104:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t546 = load %"compiler/source:Span", ptr %l1
  %t547 = load ptr, ptr %l2, !tbaa !29
  %t548 = load ptr, ptr %l7, !tbaa !29
  %t549 = load i64, ptr %l23, !tbaa !24
  %t550 = load ptr, ptr %l3, !tbaa !29
  %t551 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %t545, %"compiler/source:Span" %t546, ptr %t547, ptr %t548, i64 %t549, ptr %t550, i32 %t551)
  br label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb107:
  %t560 = load i64, ptr %l24, !tbaa !24
  %t562 = icmp sge i64 %t560, 0
  br i1 %t562, label %bb108, label %bb109
bb108:
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load %"compiler/source:Span", ptr %l1
  %t566 = load ptr, ptr %l2, !tbaa !29
  %t567 = load ptr, ptr %l7, !tbaa !29
  %t568 = load i64, ptr %l24, !tbaa !24
  %t569 = load ptr, ptr %l3, !tbaa !29
  %t570 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t564, %"compiler/source:Span" %t565, ptr %t566, ptr %t567, i64 %t568, ptr %t569, i32 %t570)
  br label %bb110
bb109:
  br label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb111:
  %t579 = load ptr, ptr %l0, !tbaa !29
  %t580 = load i32, ptr %l15, !tbaa !23
  %t581 = load %"compiler/source:Span", ptr %l1
  %t585 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t579, i32 %t580, { i64, ptr } { i64 4, ptr @.d35 }, i64 0, %"compiler/source:Span" %t581, { i64, ptr } { i64 5, ptr @.d36 })
  store i64 %t585, ptr %l309
  br label %bb112
bb112:
  %t586 = load i64, ptr %l309, !tbaa !24
  store i64 %t586, ptr %l25, !tbaa !24
  %t587 = load i64, ptr %l25, !tbaa !24
  %t589 = icmp sge i64 %t587, 0
  br i1 %t589, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t591 = load ptr, ptr %l0, !tbaa !29
  store ptr %t591, ptr %l312, !tbaa !29
  %t592 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t592, ptr %l313
  %t593 = load ptr, ptr %l2, !tbaa !29
  %t595 = getelementptr %"compiler/ast:ForIn", ptr %t593, i32 0, i32 2
  %t596 = load ptr, ptr %t595, !tbaa !29
  %t598 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t596)
  store %"compiler/source:Span" %t598, ptr %l316
  br label %bb115
bb114:
  br label %bb138
bb115:
  %t599 = load i64, ptr %l25, !tbaa !24
  store i64 %t599, ptr %l317, !tbaa !24
  %t600 = load ptr, ptr %l7, !tbaa !29
  store ptr %t600, ptr %l319, !tbaa !29
  %t602 = icmp sge i64 0, 0
  br i1 %t602, label %bb116, label %bb117
bb116:
  %t604 = icmp sle i64 0, 1152921504606846975
  br i1 %t604, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb118:
  %t606 = mul i64 0, 8
  %t607 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t606)
  %t608 = insertvalue { i64, ptr } undef, i64 0, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  store { i64, ptr } %t609, ptr %l322, !tbaa !27
  %t610 = icmp sge i64 0, 0
  br i1 %t610, label %bb120, label %bb121
bb119:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb120:
  %t612 = icmp sle i64 0, 1152921504606846975
  br i1 %t612, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb122:
  %t614 = mul i64 0, 8
  %t615 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t614)
  %t616 = insertvalue { i64, ptr } undef, i64 0, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  store { i64, ptr } %t617, ptr %l325, !tbaa !27
  %t618 = icmp sge i64 0, 0
  br i1 %t618, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_b5c196eacf828aab_2dac07573477728f)
  unreachable
bb124:
  %t620 = icmp sle i64 0, 2305843009213693951
  br i1 %t620, label %bb126, label %bb127
bb125:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb126:
  %t622 = mul i64 0, 4
  %t623 = call ptr @__olang_scope_alloc_zeroed(ptr %s15, i64 %t622)
  %t624 = insertvalue { i64, ptr } undef, i64 0, 0
  %t625 = insertvalue { i64, ptr } %t624, ptr %t623, 1
  %t626 = load ptr, ptr %l312, !tbaa !29
  %t627 = load %"compiler/source:Span", ptr %l313
  %t628 = load %"compiler/source:Span", ptr %l316
  %t629 = load i64, ptr %l317, !tbaa !24
  %t630 = load ptr, ptr %l319, !tbaa !29
  %t631 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t632 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t634 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s15, ptr %t626, %"compiler/source:Span" %t627, %"compiler/source:Span" %t628, i64 %t629, ptr %t630, { i64, ptr } %t631, { i64, ptr } %t632, { i64, ptr } %t625)
  store ptr %t634, ptr %l329
  br label %bb128
bb127:
  call void @__olang_check_failed(ptr @olang_loc_139af6e2a2dcda96_1438f6a9e620193a)
  unreachable
bb128:
  %t635 = load ptr, ptr %l329, !tbaa !29
  store ptr %t635, ptr %l26, !tbaa !29
  %t636 = load ptr, ptr %l0, !tbaa !29
  store ptr %t636, ptr %l330, !tbaa !29
  %t637 = load ptr, ptr %l0, !tbaa !29
  store ptr %t637, ptr %l331, !tbaa !29
  %t638 = load ptr, ptr %l26, !tbaa !29
  %t641 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t638)
  store i32 %t641, ptr %l334
  br label %bb129
bb129:
  %t642 = load ptr, ptr %l331, !tbaa !29
  %t643 = load i32, ptr %l334, !tbaa !23
  %t644 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t642, i32 %t643)
  store i32 %t644, ptr %l335
  br label %bb130
bb130:
  %t645 = load ptr, ptr %l330, !tbaa !29
  %t646 = load i32, ptr %l335, !tbaa !23
  %t647 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s15, ptr %t645, i32 %t646, { i64, ptr } { i64 4, ptr @.d37 }, i64 0)
  store i64 %t647, ptr %l336
  br label %bb131
bb131:
  %t648 = load i64, ptr %l336, !tbaa !24
  store i64 %t648, ptr %l27, !tbaa !24
  %t649 = load i64, ptr %l27, !tbaa !24
  %t651 = icmp slt i64 %t649, 0
  br i1 %t651, label %bb132, label %bb133
bb132:
  store %olang.scope zeroinitializer, ptr %s16
  %t653 = load ptr, ptr %l0, !tbaa !29
  store ptr %t653, ptr %l339, !tbaa !29
  %t654 = load ptr, ptr %l2, !tbaa !29
  %t656 = getelementptr %"compiler/ast:ForIn", ptr %t654, i32 0, i32 2
  %t657 = load ptr, ptr %t656, !tbaa !29
  %t659 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t657)
  store %"compiler/source:Span" %t659, ptr %l342
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t660 = load ptr, ptr %l339, !tbaa !29
  %t661 = load %"compiler/source:Span", ptr %l342
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s16, ptr %t660, %"compiler/source:Span" %t661, { i64, ptr } { i64 43, ptr @.d38 })
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb136:
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load %"compiler/source:Span", ptr %l1
  %t665 = load ptr, ptr %l2, !tbaa !29
  %t666 = load ptr, ptr %l26, !tbaa !29
  %t667 = load i64, ptr %l27, !tbaa !24
  %t668 = load ptr, ptr %l3, !tbaa !29
  %t669 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %t663, %"compiler/source:Span" %t664, ptr %t665, ptr %t666, i64 %t667, ptr %t668, i32 %t669)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb138:
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t679 = load i32, ptr %l15, !tbaa !23
  %t680 = load %"compiler/source:Span", ptr %l1
  %t684 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %s0, ptr %s0, ptr %t678, i32 %t679, { i64, ptr } { i64 2, ptr @.d39 }, i64 1, %"compiler/source:Span" %t680, { i64, ptr } { i64 5, ptr @.d40 })
  store i64 %t684, ptr %l355
  br label %bb139
bb139:
  %t685 = load i64, ptr %l355, !tbaa !24
  store i64 %t685, ptr %l28, !tbaa !24
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t687 = load i32, ptr %l15, !tbaa !23
  %t690 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t686, i32 %t687, { i64, ptr } { i64 3, ptr @.d41 }, i64 0)
  store i64 %t690, ptr %l358
  br label %bb140
bb140:
  %t691 = load i64, ptr %l358, !tbaa !24
  store i64 %t691, ptr %l29, !tbaa !24
  %t692 = load i64, ptr %l28, !tbaa !24
  %t694 = icmp sge i64 %t692, 0
  br i1 %t694, label %bb141, label %bb142
bb141:
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t698 = getelementptr %"compiler/check:Checker", ptr %t696, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !29
  %t701 = getelementptr %"compiler/generic:Program", ptr %t699, i32 0, i32 2
  store ptr %t701, ptr %l364, !tbaa !29
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = getelementptr %"compiler/check:Checker", ptr %t702, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !29
  %t707 = getelementptr %"compiler/generic:Program", ptr %t705, i32 0, i32 2
  store ptr %t707, ptr %l367, !tbaa !29
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t710 = getelementptr %"compiler/check:Checker", ptr %t708, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !29
  %t712 = load i64, ptr %l28, !tbaa !24
  %t715 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t711, i64 %t712)
  store i32 %t715, ptr %l371
  br label %bb143
bb142:
  store i1 false, ptr %l361, !tbaa !21
  br label %bb146
bb143:
  %t716 = load ptr, ptr %l367, !tbaa !29
  %t717 = load i32, ptr %l371, !tbaa !23
  %t718 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t716, i32 %t717)
  store i32 %t718, ptr %l372
  br label %bb144
bb144:
  %t719 = load ptr, ptr %l364, !tbaa !29
  %t720 = load i32, ptr %l372, !tbaa !23
  %t721 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t719, i32 %t720)
  store { i64, ptr } %t721, ptr %l373
  br label %bb145
bb145:
  %t722 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t723 = extractvalue { i64, ptr } %t722, 0
  %t725 = icmp sgt i64 %t723, 0
  store i1 %t725, ptr %l361, !tbaa !21
  br label %bb146
bb146:
  %t727 = load i1, ptr %l361, !tbaa !21
  br i1 %t727, label %bb147, label %bb148
bb147:
  %t728 = load ptr, ptr %l0, !tbaa !29
  %t730 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t728)
  store ptr %t730, ptr %l377
  br label %bb149
bb148:
  br label %bb150
bb149:
  %t731 = load ptr, ptr %l377, !tbaa !29
  store ptr %t731, ptr %l378, !tbaa !29
  %t732 = load ptr, ptr %l378, !tbaa !29
  %t733 = getelementptr %"compiler/check:frame", ptr %t732, i32 0, i32 17
  %t734 = load i64, ptr %t733, !tbaa !24
  %t736 = add i64 %t734, 1
  %t738 = load ptr, ptr %l378, !tbaa !29
  %t739 = getelementptr %"compiler/check:frame", ptr %t738, i32 0, i32 17
  store i64 %t736, ptr %t739, !tbaa !24
  br label %bb150
bb150:
  %t740 = load i64, ptr %l28, !tbaa !24
  %t742 = icmp sge i64 %t740, 0
  br i1 %t742, label %bb151, label %bb152
bb151:
  %t744 = load i64, ptr %l29, !tbaa !24
  %t746 = icmp sge i64 %t744, 0
  store i1 %t746, ptr %l383, !tbaa !21
  br label %bb153
bb152:
  store i1 false, ptr %l383, !tbaa !21
  br label %bb153
bb153:
  %t748 = load i1, ptr %l383, !tbaa !21
  br i1 %t748, label %bb154, label %bb155
bb154:
  %t749 = load ptr, ptr %l0, !tbaa !29
  %t750 = load %"compiler/source:Span", ptr %l1
  %t751 = load ptr, ptr %l2, !tbaa !29
  %t752 = load ptr, ptr %l7, !tbaa !29
  %t753 = load i64, ptr %l28, !tbaa !24
  %t754 = load i64, ptr %l29, !tbaa !24
  %t755 = load ptr, ptr %l3, !tbaa !29
  %t756 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %t749, %"compiler/source:Span" %t750, ptr %t751, ptr %t752, i64 %t753, i64 %t754, ptr %t755, i32 %t756)
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb157:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load i32, ptr %l15, !tbaa !23
  %t768 = load %"compiler/source:Span", ptr %l1
  %t772 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s0, ptr %s0, ptr %t766, i32 %t767, { i64, ptr } { i64 4, ptr @.d42 }, %"compiler/source:Span" %t768, { i64, ptr } { i64 12, ptr @.d43 }, i64 0, i1 false)
  store i1 %t772, ptr %l398
  br label %bb158
bb158:
  %t773 = load i1, ptr %l398, !tbaa !21
  br i1 %t773, label %bb159, label %bb160
bb159:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l400, !tbaa !29
  %t776 = load ptr, ptr %l2, !tbaa !29
  %t778 = getelementptr %"compiler/ast:ForIn", ptr %t776, i32 0, i32 2
  %t779 = load ptr, ptr %t778, !tbaa !29
  %t781 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t779)
  store %"compiler/source:Span" %t781, ptr %l403
  br label %bb162
bb162:
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t783 = load i32, ptr %l8, !tbaa !23
  %t786 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t782, i32 %t783)
  store { i64, ptr } %t786, ptr %l406
  br label %bb163
bb163:
  %t787 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t788 = extractvalue { i64, ptr } %t787, 0
  %t789 = extractvalue { i64, ptr } %t787, 1
  %t790 = mul i64 %t788, 1
  %t791 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t790)
  call void @llvm.memcpy.p0.p0.i64(ptr %t791, ptr %t789, i64 %t790, i1 false)
  %t792 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t793 = insertvalue { i64, ptr } %t792, ptr %t791, 1
  %t795 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %s0, ptr %s0, { i64, ptr } %t793)
  store %"compiler/msgs:Msg" %t795, ptr %l408
  br label %bb164
bb164:
  %t796 = load ptr, ptr %l400, !tbaa !29
  %t797 = load %"compiler/source:Span", ptr %l403
  %t798 = load %"compiler/msgs:Msg", ptr %l408
  %t799 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t796, %"compiler/source:Span" %t797, %"compiler/msgs:Msg" %t798)
  store i64 %t799, ptr %l409
  br label %bb165
bb165:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 41
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 41
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 41
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l53, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t91, i32 %t93)
  store i32 %t96, ptr %l58
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i32, ptr %l58, !tbaa !23
  %t99 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t97, i32 %t98)
  store ptr %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l59, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t102, i64 %t101)
  store ptr %t104, ptr %l61
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l61, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = getelementptr %"compiler/ast:CaseDecl", ptr %t110, i32 0, i32 3
  %t113 = load i1, ptr %t112, !tbaa !21
  %t115 = xor i1 %t113, true
  store i1 %t115, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 42
  %t122 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t123 = load i64, ptr %t122, !tbaa !24
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t121, i64 %t123)
  store i64 %t126, ptr %l72
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb28:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb9
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordBefore(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l55 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_db613d0fd16ec597_dffdd95765f5abab)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = load i32, ptr %l1, !tbaa !23
  %t37 = sext i32 %t35 to i64
  %t39 = sub i64 %t37, 1
  store i64 %t39, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb7, label %bb8
bb7:
  %t45 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t45, ptr %l29, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i8, ptr %t49, i64 %t46
  %t51 = load i8, ptr %t50, !tbaa !32
  %t53 = icmp eq i8 %t51, 32
  br i1 %t53, label %bb9, label %bb10
bb8:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb15
bb9:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb11
bb10:
  %t55 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t55, ptr %l34, !tbaa !27
  %t56 = load i64, ptr %l5, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = icmp eq i8 %t61, 9
  store i1 %t63, ptr %l33, !tbaa !21
  br label %bb11
bb11:
  %t65 = load i1, ptr %l33, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb14
bb13:
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  %t74 = icmp eq i8 %t72, 10
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb14
bb14:
  %t76 = load i1, ptr %l38, !tbaa !21
  store i1 %t76, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t77 = load i1, ptr %l28, !tbaa !21
  %t78 = xor i1 %t77, true
  br i1 %t78, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t82 = sub i64 %t80, 1
  store i64 %t82, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb19
bb19:
  br label %bb6
bb20:
  %t84 = load i64, ptr %l5, !tbaa !24
  %t86 = add i64 %t84, 1
  %t89 = extractvalue { i64, ptr } %a2, 0
  %t92 = sub i64 %t86, %t89
  store i64 %t92, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i32, ptr %l1, !tbaa !23
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t98, i32 %t99)
  store %"compiler/source:Span" %t102, ptr %l55
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t103, ptr %rv
  br label %ret
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = trunc i64 %t104 to i32
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = add i64 %t107, 1
  %t111 = trunc i64 %t109 to i32
  %t114 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t106, i32 %t111)
  store %"compiler/source:Span" %t114, ptr %l61
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t115 = load %"compiler/source:Span", ptr %l61
  store %"compiler/source:Span" %t115, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i1
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l94 = alloca i1
  %l100 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l12, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l14
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t19 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l17
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l3, !tbaa !29
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_261e3060da575f7_c13e4a553a852783)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t46 = add i64 %t40, %t43
  %t47 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t48 = load i32, ptr %t47, !tbaa !23
  %t50 = sext i32 %t48 to i64
  %t53 = icmp sle i64 %t46, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb50
bb8:
  br label %bb9
bb9:
  %t57 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = load i64, ptr %l5, !tbaa !24
  store i64 %t58, ptr %l36, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = add i64 %t59, %t62
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sge i64 %t68, 0
  br i1 %t69, label %bb10, label %bb11
bb10:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb12:
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = load i64, ptr %l41, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb14:
  %t79 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l36, !tbaa !24
  %t82 = load i64, ptr %l40, !tbaa !24
  %t83 = getelementptr i8, ptr %t80, i64 %t81
  %t84 = sub i64 %t82, %t81
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t86, { i64, ptr } %t87)
  store i1 %t90, ptr %l47
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_1591269354839ba0_3246c27539059c2c)
  unreachable
bb16:
  %t91 = load i1, ptr %l47, !tbaa !21
  br i1 %t91, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp eq i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  br label %bb48
bb19:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb29
bb20:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t96, ptr %l51, !tbaa !27
  %t97 = load i64, ptr %l5, !tbaa !24
  %t99 = sub i64 %t97, 1
  %t101 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t99
  %t104 = load i8, ptr %t103, !tbaa !32
  %t106 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t104)
  store i1 %t106, ptr %l55
  br label %bb21
bb21:
  %t107 = load i1, ptr %l55, !tbaa !21
  br i1 %t107, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb25
bb23:
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t108, ptr %l57, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t109, 1
  %t113 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i8, ptr %t114, i64 %t111
  %t116 = load i8, ptr %t115, !tbaa !32
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t116)
  store i1 %t118, ptr %l61
  br label %bb24
bb24:
  %t119 = load i1, ptr %l61, !tbaa !21
  store i1 %t119, ptr %l56, !tbaa !21
  br label %bb25
bb25:
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb28
bb27:
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t121, ptr %l63, !tbaa !27
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = sub i64 %t122, 1
  %t126 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t124
  %t129 = load i8, ptr %t128, !tbaa !32
  %t131 = icmp eq i8 %t129, 95
  store i1 %t131, ptr %l62, !tbaa !21
  br label %bb28
bb28:
  %t133 = load i1, ptr %l62, !tbaa !21
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l50, !tbaa !21
  br label %bb29
bb29:
  %t136 = load i1, ptr %l50, !tbaa !21
  store i1 %t136, ptr %l6, !tbaa !21
  %t137 = load i64, ptr %l5, !tbaa !24
  %t138 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t143 = add i64 %t137, %t140
  store i64 %t143, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t151 = icmp sge i64 %t145, %t148
  br i1 %t151, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb40
bb31:
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t153, ptr %l78, !tbaa !27
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t154
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t159)
  store i1 %t161, ptr %l81
  br label %bb32
bb32:
  %t162 = load i1, ptr %l81, !tbaa !21
  br i1 %t162, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb36
bb34:
  %t163 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t163, ptr %l83, !tbaa !27
  %t164 = load i64, ptr %l7, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i8, ptr %t167, i64 %t164
  %t169 = load i8, ptr %t168, !tbaa !32
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t169)
  store i1 %t171, ptr %l86
  br label %bb35
bb35:
  %t172 = load i1, ptr %l86, !tbaa !21
  store i1 %t172, ptr %l82, !tbaa !21
  br label %bb36
bb36:
  %t173 = load i1, ptr %l82, !tbaa !21
  br i1 %t173, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l87, !tbaa !21
  br label %bb39
bb38:
  %t174 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t174, ptr %l88, !tbaa !27
  %t175 = load i64, ptr %l7, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = icmp eq i8 %t180, 95
  store i1 %t182, ptr %l87, !tbaa !21
  br label %bb39
bb39:
  %t184 = load i1, ptr %l87, !tbaa !21
  %t185 = xor i1 %t184, true
  store i1 %t185, ptr %l77, !tbaa !21
  br label %bb40
bb40:
  %t187 = load i1, ptr %l77, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  %t188 = load i1, ptr %l6, !tbaa !21
  br i1 %t188, label %bb41, label %bb42
bb41:
  %t190 = load i1, ptr %l8, !tbaa !21
  store i1 %t190, ptr %l94, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t192 = load i1, ptr %l94, !tbaa !21
  br i1 %t192, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s3
  %t193 = load i64, ptr %l5, !tbaa !24
  %t195 = trunc i64 %t193 to i32
  %t196 = load i64, ptr %l7, !tbaa !24
  %t198 = trunc i64 %t196 to i32
  %t201 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t195, i32 %t198)
  store %"compiler/source:Span" %t201, ptr %l100
  br label %bb46
bb45:
  br label %bb47
bb46:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load %"compiler/source:Span", ptr %l100
  store %"compiler/source:Span" %t202, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t203 = load i64, ptr %l5, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb49
bb49:
  br label %bb6
bb50:
  %t207 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t207, ptr %l103
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load %"compiler/source:Span", ptr %l103
  store %"compiler/source:Span" %t208, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, %"compiler/check:ctSource" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l26 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l70 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca i1
  %l86 = alloca ptr
  %l88 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:ScopeRel"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/ast:ContractBlock", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t15, i32 %t16)
  store { i64, ptr } %t19, ptr %l26
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr %"compiler/ast:ContractBlock", ptr %t21, i32 0, i32 2
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb7:
  br label %bb8
bb8:
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t38, ptr %l35, !tbaa !27
  %t39 = load i64, ptr %l7, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr ptr, ptr %t42, i64 %t39
  %t44 = load ptr, ptr %t43, !tbaa !39
  store ptr %t44, ptr %l9, !tbaa !29
  store i64 -1, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t46 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Outlives", ptr %t46, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  store i64 %t51, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t53 = load i64, ptr %l12, !tbaa !24
  %t54 = load i64, ptr %l11, !tbaa !24
  %t57 = icmp sgt i64 %t53, %t54
  br i1 %t57, label %bb9, label %bb10
bb9:
  %t59 = load i64, ptr %l13, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb14
bb11:
  %t63 = load i64, ptr %l12, !tbaa !24
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = sub i64 %t63, %t64
  %t68 = load i64, ptr %l13, !tbaa !24
  %t71 = add i64 %t67, %t68
  %t73 = sub i64 %t71, 1
  %t74 = load i64, ptr %l13, !tbaa !24
  %t77 = sdiv i64 %t73, %t74
  store i64 %t77, ptr %l47, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb13
bb13:
  %t79 = load i64, ptr %l47, !tbaa !24
  store i64 %t79, ptr %l44, !tbaa !24
  br label %bb14
bb14:
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l15, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  %t85 = icmp slt i64 %t81, %t82
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t89 = load i64, ptr %l11, !tbaa !24
  %t90 = load i64, ptr %l15, !tbaa !24
  %t91 = load i64, ptr %l13, !tbaa !24
  %t94 = mul i64 %t90, %t91
  %t97 = add i64 %t89, %t94
  store i64 %t97, ptr %l16, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l2, !tbaa !23
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = load ptr, ptr %l9, !tbaa !29
  %t105 = getelementptr %"compiler/ast:Outlives", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l70, !tbaa !27
  %t107 = load i64, ptr %l16, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr i32, ptr %t110, i64 %t107
  %t112 = load i32, ptr %t111, !tbaa !33
  %t113 = load ptr, ptr %l9, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Outlives", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l74, !tbaa !27
  %t117 = load i64, ptr %l16, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/source:Span", ptr %t120, i64 %t117
  %t122 = load %"compiler/source:Span", ptr %t121
  %t129 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escopeVarOf(ptr %v0, ptr %s0, ptr %v1, ptr %t99, i32 %t100, { i64, ptr } %t101, %"compiler/check:ctSource" %a3, i32 %t112, %"compiler/source:Span" %t122)
  store i64 %t129, ptr %l77
  br label %bb19
bb19:
  %t130 = load i64, ptr %l77, !tbaa !24
  store i64 %t130, ptr %l17, !tbaa !24
  %t131 = load i64, ptr %l17, !tbaa !24
  %t133 = icmp sge i64 %t131, 0
  br i1 %t133, label %bb20, label %bb21
bb20:
  %t135 = load i64, ptr %l10, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  store i1 %t137, ptr %l80, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb22
bb22:
  %t139 = load i1, ptr %l80, !tbaa !21
  br i1 %t139, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 11
  %t146 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t142, i64 %a1)
  store ptr %t146, ptr %l86
  br label %bb25
bb24:
  br label %bb28
bb25:
  %t147 = load ptr, ptr %l86, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 12
  store ptr %t149, ptr %l88, !tbaa !29
  %t150 = load i64, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l17, !tbaa !24
  %t152 = load ptr, ptr %l9, !tbaa !29
  %t154 = getelementptr %"compiler/ast:Outlives", ptr %t152, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l92, !tbaa !27
  %t156 = load i64, ptr %l16, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/source:Span", ptr %t159, i64 %t156
  %t161 = load %"compiler/source:Span", ptr %t160
  %t165 = call %"compiler/typed:ScopeRel" @compiler_2ftyped_3aScopeRel_2ector(ptr %s6, i64 %t150, i64 %t151, %"compiler/source:Span" %t161)
  store %"compiler/typed:ScopeRel" %t165, ptr %l95
  br label %bb26
bb26:
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load %"compiler/typed:ScopeRel", ptr %l95
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2ePu_H3d39058be51439e1c4066e8dcab52826(ptr %v0, ptr %t166, %"compiler/typed:ScopeRel" %t167)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb28:
  %t168 = load i64, ptr %l17, !tbaa !24
  store i64 %t168, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb29:
  %t170 = load i64, ptr %l15, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l15, !tbaa !24
  br label %bb15
bb30:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb31:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t176 = add i64 %t174, 1
  store i64 %t176, ptr %l7, !tbaa !24
  br label %bb5
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezeroCalls(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l14 = alloca i32
  %l18 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i32
  %l32 = alloca i1
  %l35 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i1, ptr %l9, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb7:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l14
  br label %bb8
bb8:
  %t21 = load i32, ptr %l14
  %t23 = trunc i64 4 to i32
  %t24 = icmp eq i32 %t21, %t23
  %t26 = xor i1 %t24, true
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l11, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb13
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i32, ptr %l1, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l22
  br label %bb12
bb12:
  %t37 = load i1, ptr %l22, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l18, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l18, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i32, ptr %l1, !tbaa !23
  %t49 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t49, ptr %l28
  br label %bb17
bb17:
  %t50 = load i32, ptr %l28, !tbaa !23
  store i32 %t50, ptr %l2, !tbaa !23
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t55 = icmp ne i32 %t51, %t52
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  store ptr %t62, ptr %l35, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 2
  %t69 = load i32, ptr %l2, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t72, ptr %l40
  br label %bb20
bb19:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb22
bb20:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t73, i32 %t74)
  store { i64, ptr } %t75, ptr %l41
  br label %bb21
bb21:
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t79 = icmp eq i64 %t77, 1
  store i1 %t79, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t81 = load i1, ptr %l32, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisArrayMake(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18
  %t21 = trunc i64 2 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisCharLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_83df14ccfb59caa2_79e7c0956b45666e)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1)
  store i1 %t4, ptr %l7
  br label %bb1
bb1:
  %t5 = load i1, ptr %l7, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Block", ptr %t7, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t16 = load i64, ptr %l2, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t24, ptr %l17, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 %t25
  %t30 = load ptr, ptr %t29, !tbaa !39
  store ptr %t30, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t33 = load ptr, ptr %l20, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l20, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 5
  store i1 %t39, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb5
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elimitBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i1
  %l13 = alloca i1
  %l17 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca [6 x i64]
  %l41 = alloca [6 x i64]
  %l46 = alloca [6 x i64]
  %l49 = alloca [6 x i64]
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l1, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t13, i32 %t14)
  store i1 %t17, ptr %l13
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t18 = load i1, ptr %l13, !tbaa !21
  store i1 %t18, ptr %l4, !tbaa !21
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp eq i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  %t23 = load i1, ptr %l4, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb7:
  br label %bb14
bb8:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t27 = icmp eq i64 %t25, 64
  br i1 %t27, label %bb10, label %bb11
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = shl i64 1, %t33
  %t36 = sub i64 %t34, 1
  store i64 %t36, ptr %l17, !tbaa !24
  br label %bb13
bb10:
  store i64 -1, ptr %l20, !tbaa !24
  br label %bb12
bb11:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = shl i64 1, %t40
  %t43 = sub i64 %t41, 1
  store i64 %t43, ptr %l20, !tbaa !24
  br label %bb12
bb12:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l17, !tbaa !24
  br label %bb13
bb13:
  %t46 = load i64, ptr %l17, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = load i1, ptr %l4, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb17
bb16:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = sub i64 %t49, 1
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = shl i64 1, %t53
  %t56 = sub i64 0, %t54
  store i64 %t56, ptr %l29, !tbaa !24
  br label %bb17
bb17:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = load i32, ptr %l1, !tbaa !23
  %t61 = icmp eq i32 %t59, 13
  br i1 %t61, label %bb19, label %bb20
bb19:
  %t63 = insertvalue [6 x i64] undef, i64 2139095039, 0
  %t64 = insertvalue [6 x i64] %t63, i64 4286578687, 1
  %t65 = insertvalue [6 x i64] %t64, i64 2139095040, 2
  %t66 = insertvalue [6 x i64] %t65, i64 2143289344, 3
  %t67 = insertvalue [6 x i64] %t66, i64 872415232, 4
  %t68 = insertvalue [6 x i64] %t67, i64 8388608, 5
  store [6 x i64] %t68, ptr %l36
  %t69 = load i64, ptr %l2, !tbaa !24
  %t71 = getelementptr [6 x i64], ptr %l36, i64 0, i64 %t69
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t74 = load i32, ptr %l1, !tbaa !23
  %t76 = icmp eq i32 %t74, 11
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = insertvalue [6 x i64] undef, i64 31743, 0
  %t79 = insertvalue [6 x i64] %t78, i64 64511, 1
  %t80 = insertvalue [6 x i64] %t79, i64 31744, 2
  %t81 = insertvalue [6 x i64] %t80, i64 32256, 3
  %t82 = insertvalue [6 x i64] %t81, i64 5120, 4
  %t83 = insertvalue [6 x i64] %t82, i64 1024, 5
  store [6 x i64] %t83, ptr %l41
  %t84 = load i64, ptr %l2, !tbaa !24
  %t86 = getelementptr [6 x i64], ptr %l41, i64 0, i64 %t84
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t89 = load i32, ptr %l1, !tbaa !23
  %t91 = icmp eq i32 %t89, 12
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = insertvalue [6 x i64] undef, i64 32639, 0
  %t94 = insertvalue [6 x i64] %t93, i64 65407, 1
  %t95 = insertvalue [6 x i64] %t94, i64 32640, 2
  %t96 = insertvalue [6 x i64] %t95, i64 32704, 3
  %t97 = insertvalue [6 x i64] %t96, i64 15360, 4
  %t98 = insertvalue [6 x i64] %t97, i64 128, 5
  store [6 x i64] %t98, ptr %l46
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr [6 x i64], ptr %l46, i64 0, i64 %t99
  %t102 = load i64, ptr %t101, !tbaa !34
  store i64 %t102, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t104 = insertvalue [6 x i64] undef, i64 9218868437227405311, 0
  %t105 = insertvalue [6 x i64] %t104, i64 -4503599627370497, 1
  %t106 = insertvalue [6 x i64] %t105, i64 9218868437227405312, 2
  %t107 = insertvalue [6 x i64] %t106, i64 9221120237041090560, 3
  %t108 = insertvalue [6 x i64] %t107, i64 4372995238176751616, 4
  %t109 = insertvalue [6 x i64] %t108, i64 4503599627370496, 5
  store [6 x i64] %t109, ptr %l49
  %t110 = load i64, ptr %l2, !tbaa !24
  %t112 = getelementptr [6 x i64], ptr %l49, i64 0, i64 %t110
  %t113 = load i64, ptr %t112, !tbaa !34
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l8, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a6ce77febe1defe5_34385e948c177179)
  unreachable
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i8
  %l39 = alloca { i64, ptr }
  %l42 = alloca i8
  %l43 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  store ptr %l1, ptr %l35, !tbaa !29
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l39, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t63)
  store i8 %t65, ptr %l42
  br label %bb14
bb13:
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l43, !tbaa !27
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l38, !tbaa !22
  br label %bb15
bb14:
  %t74 = load i8, ptr %l42, !tbaa !22
  store i8 %t74, ptr %l38, !tbaa !22
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l35, !tbaa !29
  %t76 = load i8, ptr %l38, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t75, i8 %t76)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t82 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t82, ptr %l49
  br label %bb19
bb19:
  %t83 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t83, ptr %l50, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = mul i64 %t86, 1
  %t88 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l52, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = mul i64 %t95, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t92, ptr %t94, i64 %t96, i1 false)
  %t97 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %l20 = alloca i1
  %l28 = alloca i1
  %l37 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 3
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = getelementptr %"compiler/ast:Case", ptr %t24, i32 0, i32 4
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t29, { i64, ptr } %t30)
  store i1 %t33, ptr %l20
  br label %bb5
bb5:
  %t34 = load i1, ptr %l20, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Match", ptr %t40, i32 0, i32 4
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Match", ptr %t49, i32 0, i32 4
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb13, label %bb14
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb17
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bff01f20505ccdb5_4aab420456ab469)
  unreachable
bb14:
  br label %bb15
bb15:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Match", ptr %t56, i32 0, i32 4
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t62 = getelementptr %"compiler/ast:Case", ptr %t59, i32 0, i32 4
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t67 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t63, { i64, ptr } %t64)
  store i1 %t67, ptr %l37
  br label %bb16
bb16:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %l28, !tbaa !21
  br label %bb17
bb17:
  %t69 = load i1, ptr %l28, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l95 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 1
  store i1 %t13, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l13, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32 }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l1
  br label %bb8
bb7:
  br label %bb12
bb8:
  %t21 = load i32, ptr %l1
  %t23 = trunc i64 2 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb11
bb10:
  %t26 = load i32, ptr %l1
  %t28 = trunc i64 3 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l20, !tbaa !21
  store i1 %t31, ptr %l11, !tbaa !21
  br label %bb78
bb12:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", ptr }, ptr %t43, i32 0, i32 1
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t50 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t47)
  store i1 %t50, ptr %l31
  br label %bb18
bb18:
  %t51 = load i1, ptr %l31, !tbaa !21
  store i1 %t51, ptr %l11, !tbaa !21
  br label %bb78
bb19:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t53 = load ptr, ptr %l32, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l32, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 3
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t60 = load i1, ptr %l33, !tbaa !21
  br i1 %t60, label %bb22, label %bb23
bb22:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l3
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l4, !tbaa !29
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t73 = load i32, ptr %l3
  %t75 = trunc i64 49 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb27
bb26:
  %t78 = load i32, ptr %l3
  %t80 = trunc i64 83 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t84)
  store i1 %t87, ptr %l48
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t88 = load i1, ptr %l48, !tbaa !21
  store i1 %t88, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t89 = load i1, ptr %l45, !tbaa !21
  store i1 %t89, ptr %l11, !tbaa !21
  br label %bb78
bb32:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t91 = load ptr, ptr %l49, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb33, label %bb34
bb33:
  %t94 = load ptr, ptr %l49, !tbaa !29
  %t95 = load i64, ptr %t94
  %t97 = icmp eq i64 %t95, 5
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb34
bb34:
  %t98 = load i1, ptr %l50, !tbaa !21
  br i1 %t98, label %bb35, label %bb36
bb35:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t101, i32 0, i32 1
  %t103 = load i32, ptr %t102
  store i32 %t103, ptr %l5
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l6, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t113, i32 0, i32 3
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb73
bb37:
  %t117 = load i32, ptr %l5
  %t119 = trunc i64 48 to i32
  %t120 = icmp eq i32 %t117, %t119
  br i1 %t120, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb40
bb39:
  %t122 = load i32, ptr %l5
  %t124 = trunc i64 49 to i32
  %t125 = icmp eq i32 %t122, %t124
  store i1 %t125, ptr %l61, !tbaa !21
  br label %bb40
bb40:
  %t127 = load i1, ptr %l61, !tbaa !21
  br i1 %t127, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb43
bb42:
  %t128 = load i32, ptr %l5
  %t130 = trunc i64 50 to i32
  %t131 = icmp eq i32 %t128, %t130
  store i1 %t131, ptr %l64, !tbaa !21
  br label %bb43
bb43:
  %t133 = load i1, ptr %l64, !tbaa !21
  br i1 %t133, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb46
bb45:
  %t134 = load i32, ptr %l5
  %t136 = trunc i64 51 to i32
  %t137 = icmp eq i32 %t134, %t136
  store i1 %t137, ptr %l67, !tbaa !21
  br label %bb46
bb46:
  %t139 = load i1, ptr %l67, !tbaa !21
  br i1 %t139, label %bb47, label %bb48
bb47:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb49
bb48:
  %t140 = load i32, ptr %l5
  %t142 = trunc i64 52 to i32
  %t143 = icmp eq i32 %t140, %t142
  store i1 %t143, ptr %l70, !tbaa !21
  br label %bb49
bb49:
  %t145 = load i1, ptr %l70, !tbaa !21
  br i1 %t145, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb52
bb51:
  %t146 = load i32, ptr %l5
  %t148 = trunc i64 80 to i32
  %t149 = icmp eq i32 %t146, %t148
  store i1 %t149, ptr %l73, !tbaa !21
  br label %bb52
bb52:
  %t151 = load i1, ptr %l73, !tbaa !21
  br i1 %t151, label %bb53, label %bb54
bb53:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb55
bb54:
  %t152 = load i32, ptr %l5
  %t154 = trunc i64 81 to i32
  %t155 = icmp eq i32 %t152, %t154
  store i1 %t155, ptr %l76, !tbaa !21
  br label %bb55
bb55:
  %t157 = load i1, ptr %l76, !tbaa !21
  br i1 %t157, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb58
bb57:
  %t158 = load i32, ptr %l5
  %t160 = trunc i64 82 to i32
  %t161 = icmp eq i32 %t158, %t160
  store i1 %t161, ptr %l79, !tbaa !21
  br label %bb58
bb58:
  %t163 = load i1, ptr %l79, !tbaa !21
  br i1 %t163, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb61
bb60:
  %t164 = load i32, ptr %l5
  %t166 = trunc i64 85 to i32
  %t167 = icmp eq i32 %t164, %t166
  store i1 %t167, ptr %l82, !tbaa !21
  br label %bb61
bb61:
  %t169 = load i1, ptr %l82, !tbaa !21
  br i1 %t169, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb64
bb63:
  %t170 = load i32, ptr %l5
  %t172 = trunc i64 86 to i32
  %t173 = icmp eq i32 %t170, %t172
  store i1 %t173, ptr %l85, !tbaa !21
  br label %bb64
bb64:
  %t175 = load i1, ptr %l85, !tbaa !21
  br i1 %t175, label %bb65, label %bb66
bb65:
  %t176 = load ptr, ptr %l6, !tbaa !29
  %t179 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t176)
  store i1 %t179, ptr %l91
  br label %bb67
bb66:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb68
bb67:
  %t180 = load i1, ptr %l91, !tbaa !21
  store i1 %t180, ptr %l88, !tbaa !21
  br label %bb68
bb68:
  %t181 = load i1, ptr %l88, !tbaa !21
  br i1 %t181, label %bb69, label %bb70
bb69:
  %t182 = load ptr, ptr %l7, !tbaa !29
  %t185 = call i1 @compiler_2fcheck_2enumberLitsOnly(ptr %v0, ptr %t182)
  store i1 %t185, ptr %l95
  br label %bb71
bb70:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb72
bb71:
  %t186 = load i1, ptr %l95, !tbaa !21
  store i1 %t186, ptr %l92, !tbaa !21
  br label %bb72
bb72:
  %t187 = load i1, ptr %l92, !tbaa !21
  store i1 %t187, ptr %l11, !tbaa !21
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_a2bfaee8e4bbf2f0_c4354a8bc250ee0c)
  unreachable
bb78:
  %t188 = load i1, ptr %l11, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 13
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 22
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 4
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb39
bb18:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb19, label %bb20
bb19:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 2
  store i1 %t44, ptr %l21, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", ptr }, ptr %t48, i32 0, i32 1
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l1, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t52)
  store i1 %t54, ptr %l27
  br label %bb24
bb24:
  %t55 = load i1, ptr %l27, !tbaa !21
  store i1 %t55, ptr %l3, !tbaa !21
  br label %bb39
bb25:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb26, label %bb27
bb26:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb27
bb27:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb28, label %bb29
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t67, i32 0, i32 1
  %t69 = load i32, ptr %t68
  store i32 %t69, ptr %l2
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t71 = load i32, ptr %l2
  %t73 = trunc i64 70 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb33
bb32:
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 71 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l36, !tbaa !21
  br label %bb33
bb33:
  %t81 = load i1, ptr %l36, !tbaa !21
  store i1 %t81, ptr %l3, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d195b38137e2d30_7d67c1d5e7f3802c)
  unreachable
bb39:
  %t82 = load i1, ptr %l3, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l69 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca i1
  %l92 = alloca ptr
  %l93 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca ptr
  %l128 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l184 = alloca ptr
  %l185 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l200 = alloca ptr
  %l201 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i1
  %l239 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l250 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i1
  %s7 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t6 = load ptr, ptr %l34, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l34, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l35, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l35, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t20, ptr %t22)
  br label %bb9
bb9:
  br label %bb161
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t26 = load ptr, ptr %l43, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l43, !tbaa !29
  %t30 = load i64, ptr %t29
  %t32 = icmp eq i64 %t30, 1
  store i1 %t32, ptr %l44, !tbaa !21
  br label %bb12
bb12:
  %t33 = load i1, ptr %l44, !tbaa !21
  br i1 %t33, label %bb13, label %bb14
bb13:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr }, ptr %t36, i32 0, i32 1
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l3, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = getelementptr %"compiler/ast:VarDecl", ptr %t40, i32 0, i32 3
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  %t44 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t43, ptr %t44)
  br label %bb16
bb16:
  br label %bb161
bb17:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t48 = load ptr, ptr %l52, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb18, label %bb19
bb18:
  %t51 = load ptr, ptr %l52, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 2
  store i1 %t54, ptr %l53, !tbaa !21
  br label %bb19
bb19:
  %t55 = load i1, ptr %l53, !tbaa !21
  br i1 %t55, label %bb20, label %bb21
bb20:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb34
bb22:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/ast:Multi", ptr %t62, i32 0, i32 1
  %t65 = load i1, ptr %t64, !tbaa !21
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Multi", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  store i64 %t76, ptr %l7, !tbaa !24
  br label %bb25
bb24:
  br label %bb32
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t78 = load i64, ptr %l6, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp slt i64 %t78, %t79
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t86, ptr %l69, !tbaa !27
  %t87 = load i64, ptr %l6, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr ptr, ptr %t90, i64 %t87
  %t92 = load ptr, ptr %t91, !tbaa !39
  %t95 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t92, ptr %t95)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t98 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l6, !tbaa !24
  br label %bb25
bb31:
  br label %bb32
bb32:
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t104 = getelementptr %"compiler/ast:Multi", ptr %t102, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t105, ptr %t106)
  br label %bb33
bb33:
  br label %bb161
bb34:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t110 = load ptr, ptr %l79, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l79, !tbaa !29
  %t114 = load i64, ptr %t113
  %t116 = icmp eq i64 %t114, 3
  store i1 %t116, ptr %l80, !tbaa !21
  br label %bb36
bb36:
  %t117 = load i1, ptr %l80, !tbaa !21
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l9, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t126, i32 0, i32 3
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t130 = load ptr, ptr %l9, !tbaa !29
  %t131 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb40
bb40:
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t136 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t134, ptr %t136)
  br label %bb41
bb41:
  br label %bb161
bb42:
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t140 = load ptr, ptr %l92, !tbaa !29
  %t141 = icmp ne ptr %t140, null
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t143 = load ptr, ptr %l92, !tbaa !29
  %t144 = load i64, ptr %t143
  %t146 = icmp eq i64 %t144, 4
  store i1 %t146, ptr %l93, !tbaa !21
  br label %bb44
bb44:
  %t147 = load i1, ptr %l93, !tbaa !21
  br i1 %t147, label %bb45, label %bb46
bb45:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr { i64, [4 x i64] }, ptr %t148, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t150, i32 0, i32 1
  %t152 = load ptr, ptr %t151
  store ptr %t152, ptr %l11, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t156, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157
  store { i64, ptr } %t158, ptr %l12, !tbaa !27
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t160 = load ptr, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t160, ptr %t162)
  br label %bb48
bb48:
  %t165 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t165, ptr %t166)
  br label %bb49
bb49:
  br label %bb161
bb50:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t170 = load ptr, ptr %l105, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb51, label %bb52
bb51:
  %t173 = load ptr, ptr %l105, !tbaa !29
  %t174 = load i64, ptr %t173
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t177 = load i1, ptr %l106, !tbaa !21
  br i1 %t177, label %bb53, label %bb54
bb53:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", ptr }, ptr %t180, i32 0, i32 1
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l13, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t184 = load ptr, ptr %l13, !tbaa !29
  %t185 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %t184, ptr %t185)
  br label %bb56
bb56:
  br label %bb161
bb57:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t189 = load ptr, ptr %l113, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb58, label %bb59
bb58:
  %t192 = load ptr, ptr %l113, !tbaa !29
  %t193 = load i64, ptr %t192
  %t195 = icmp eq i64 %t193, 6
  store i1 %t195, ptr %l114, !tbaa !21
  br label %bb59
bb59:
  %t196 = load i1, ptr %l114, !tbaa !21
  br i1 %t196, label %bb60, label %bb61
bb60:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr { i64, [4 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t199, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l14, !tbaa !27
  br label %bb66
bb61:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t204 = load ptr, ptr %l119, !tbaa !29
  %t205 = icmp ne ptr %t204, null
  br i1 %t205, label %bb62, label %bb63
bb62:
  %t207 = load ptr, ptr %l119, !tbaa !29
  %t208 = load i64, ptr %t207
  %t210 = icmp eq i64 %t208, 19
  store i1 %t210, ptr %l120, !tbaa !21
  br label %bb63
bb63:
  %t211 = load i1, ptr %l120, !tbaa !21
  br i1 %t211, label %bb64, label %bb65
bb64:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t212, i32 0, i32 1
  %t215 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t214, i32 0, i32 1
  %t216 = load { i64, ptr }, ptr %t215
  store { i64, ptr } %t216, ptr %l14, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t218 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t219 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t218, ptr %t219)
  br label %bb67
bb67:
  br label %bb161
bb68:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l127, !tbaa !29
  store i1 false, ptr %l128, !tbaa !21
  %t223 = load ptr, ptr %l127, !tbaa !29
  %t224 = icmp ne ptr %t223, null
  br i1 %t224, label %bb69, label %bb70
bb69:
  %t226 = load ptr, ptr %l127, !tbaa !29
  %t227 = load i64, ptr %t226
  %t229 = icmp eq i64 %t227, 7
  store i1 %t229, ptr %l128, !tbaa !21
  br label %bb70
bb70:
  %t230 = load i1, ptr %l128, !tbaa !21
  br i1 %t230, label %bb71, label %bb72
bb71:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr { i64, [4 x i64] }, ptr %t231, i32 0, i32 1
  %t234 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t233, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  store ptr %t235, ptr %l15, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t239, i32 0, i32 2
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l16, !tbaa !27
  br label %bb77
bb72:
  %t243 = load ptr, ptr %l0, !tbaa !29
  store ptr %t243, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t244 = load ptr, ptr %l135, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb73, label %bb74
bb73:
  %t247 = load ptr, ptr %l135, !tbaa !29
  %t248 = load i64, ptr %t247
  %t250 = icmp eq i64 %t248, 10
  store i1 %t250, ptr %l136, !tbaa !21
  br label %bb74
bb74:
  %t251 = load i1, ptr %l136, !tbaa !21
  br i1 %t251, label %bb75, label %bb76
bb75:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t254, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255
  store { i64, ptr } %t256, ptr %l16, !tbaa !27
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t260, i32 0, i32 2
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t264 = load ptr, ptr %l15, !tbaa !29
  %t266 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t264, ptr %t266)
  br label %bb78
bb78:
  %t269 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t270 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t269, ptr %t270)
  br label %bb79
bb79:
  br label %bb161
bb80:
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t274 = load ptr, ptr %l148, !tbaa !29
  %t275 = icmp ne ptr %t274, null
  br i1 %t275, label %bb81, label %bb82
bb81:
  %t277 = load ptr, ptr %l148, !tbaa !29
  %t278 = load i64, ptr %t277
  %t280 = icmp eq i64 %t278, 8
  store i1 %t280, ptr %l149, !tbaa !21
  br label %bb82
bb82:
  %t281 = load i1, ptr %l149, !tbaa !21
  br i1 %t281, label %bb83, label %bb84
bb83:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr { i64, [4 x i64] }, ptr %t282, i32 0, i32 1
  %t285 = getelementptr { %"compiler/source:Span", ptr }, ptr %t284, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  store ptr %t286, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t288 = load ptr, ptr %l17, !tbaa !29
  %t290 = getelementptr %"compiler/ast:For3", ptr %t288, i32 0, i32 0
  %t291 = load ptr, ptr %t290, !tbaa !29
  %t293 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t291, ptr %t293)
  br label %bb86
bb86:
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/ast:For3", ptr %t296, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t300 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t299, ptr %t300)
  br label %bb87
bb87:
  %t303 = load ptr, ptr %l17, !tbaa !29
  %t305 = getelementptr %"compiler/ast:For3", ptr %t303, i32 0, i32 2
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t308 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t306, ptr %t308)
  br label %bb88
bb88:
  %t311 = load ptr, ptr %l17, !tbaa !29
  %t313 = getelementptr %"compiler/ast:For3", ptr %t311, i32 0, i32 3
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t315 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t314, ptr %t315)
  br label %bb89
bb89:
  br label %bb161
bb90:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t319 = load ptr, ptr %l168, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb91, label %bb92
bb91:
  %t322 = load ptr, ptr %l168, !tbaa !29
  %t323 = load i64, ptr %t322
  %t325 = icmp eq i64 %t323, 9
  store i1 %t325, ptr %l169, !tbaa !21
  br label %bb92
bb92:
  %t326 = load i1, ptr %l169, !tbaa !21
  br i1 %t326, label %bb93, label %bb94
bb93:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb95
bb94:
  br label %bb99
bb95:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t335 = getelementptr %"compiler/ast:ForIn", ptr %t333, i32 0, i32 2
  %t336 = load ptr, ptr %t335, !tbaa !29
  %t338 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t336, ptr %t338)
  br label %bb96
bb96:
  %t341 = load ptr, ptr %l18, !tbaa !29
  %t343 = getelementptr %"compiler/ast:ForIn", ptr %t341, i32 0, i32 4
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t345 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t344, ptr %t345)
  br label %bb97
bb97:
  %t348 = load ptr, ptr %l18, !tbaa !29
  %t350 = getelementptr %"compiler/ast:ForIn", ptr %t348, i32 0, i32 5
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t352 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t351, ptr %t352)
  br label %bb98
bb98:
  br label %bb161
bb99:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t356 = load ptr, ptr %l184, !tbaa !29
  %t357 = icmp ne ptr %t356, null
  br i1 %t357, label %bb100, label %bb101
bb100:
  %t359 = load ptr, ptr %l184, !tbaa !29
  %t360 = load i64, ptr %t359
  %t362 = icmp eq i64 %t360, 11
  store i1 %t362, ptr %l185, !tbaa !21
  br label %bb101
bb101:
  %t363 = load i1, ptr %l185, !tbaa !21
  br i1 %t363, label %bb102, label %bb103
bb102:
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t364, i32 0, i32 1
  %t367 = getelementptr { %"compiler/source:Span", ptr }, ptr %t366, i32 0, i32 1
  %t368 = load ptr, ptr %t367
  store ptr %t368, ptr %l19, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t370 = load ptr, ptr %l19, !tbaa !29
  %t371 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  br label %bb105
bb105:
  br label %bb161
bb106:
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t375 = load ptr, ptr %l192, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb107, label %bb108
bb107:
  %t378 = load ptr, ptr %l192, !tbaa !29
  %t379 = load i64, ptr %t378
  %t381 = icmp eq i64 %t379, 12
  store i1 %t381, ptr %l193, !tbaa !21
  br label %bb108
bb108:
  %t382 = load i1, ptr %l193, !tbaa !21
  br i1 %t382, label %bb109, label %bb110
bb109:
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t385, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386
  store { i64, ptr } %t387, ptr %l20, !tbaa !27
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t389 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t389, ptr %t390)
  br label %bb112
bb112:
  br label %bb161
bb113:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l200, !tbaa !29
  store i1 false, ptr %l201, !tbaa !21
  %t394 = load ptr, ptr %l200, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb114, label %bb115
bb114:
  %t397 = load ptr, ptr %l200, !tbaa !29
  %t398 = load i64, ptr %t397
  %t400 = icmp eq i64 %t398, 14
  store i1 %t400, ptr %l201, !tbaa !21
  br label %bb115
bb115:
  %t401 = load i1, ptr %l201, !tbaa !21
  br i1 %t401, label %bb116, label %bb117
bb116:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t404 = getelementptr { i64, [4 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t404, i32 0, i32 1
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l21, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr { i64, [4 x i64] }, ptr %t408, i32 0, i32 1
  %t411 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t410, i32 0, i32 2
  %t412 = load ptr, ptr %t411
  store ptr %t412, ptr %l22, !tbaa !29
  br label %bb118
bb117:
  br label %bb121
bb118:
  %t414 = load ptr, ptr %l21, !tbaa !29
  %t416 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t414, ptr %t416)
  br label %bb119
bb119:
  %t419 = load ptr, ptr %l22, !tbaa !29
  %t420 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t419, ptr %t420)
  br label %bb120
bb120:
  br label %bb161
bb121:
  %t423 = load ptr, ptr %l0, !tbaa !29
  store ptr %t423, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t424 = load ptr, ptr %l213, !tbaa !29
  %t425 = icmp ne ptr %t424, null
  br i1 %t425, label %bb122, label %bb123
bb122:
  %t427 = load ptr, ptr %l213, !tbaa !29
  %t428 = load i64, ptr %t427
  %t430 = icmp eq i64 %t428, 13
  store i1 %t430, ptr %l214, !tbaa !21
  br label %bb123
bb123:
  %t431 = load i1, ptr %l214, !tbaa !21
  br i1 %t431, label %bb124, label %bb125
bb124:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr { i64, [4 x i64] }, ptr %t432, i32 0, i32 1
  %t435 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t434, i32 0, i32 2
  %t436 = load ptr, ptr %t435
  store ptr %t436, ptr %l23, !tbaa !29
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t438 = load ptr, ptr %l23, !tbaa !29
  %t439 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t438, ptr %t439)
  br label %bb127
bb127:
  br label %bb161
bb128:
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t443 = load ptr, ptr %l221, !tbaa !29
  %t444 = icmp ne ptr %t443, null
  br i1 %t444, label %bb129, label %bb130
bb129:
  %t446 = load ptr, ptr %l221, !tbaa !29
  %t447 = load i64, ptr %t446
  %t449 = icmp eq i64 %t447, 16
  store i1 %t449, ptr %l222, !tbaa !21
  br label %bb130
bb130:
  %t450 = load i1, ptr %l222, !tbaa !21
  br i1 %t450, label %bb131, label %bb132
bb131:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t453, i32 0, i32 1
  %t455 = load { i64, ptr }, ptr %t454
  store { i64, ptr } %t455, ptr %l24, !tbaa !27
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t457, i32 0, i32 1
  %t460 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t459, i32 0, i32 2
  %t461 = load ptr, ptr %t460
  store ptr %t461, ptr %l25, !tbaa !29
  br label %bb133
bb132:
  br label %bb145
bb133:
  %t463 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t463, 0
  %t467 = icmp sgt i64 %t465, 0
  br i1 %t467, label %bb134, label %bb135
bb134:
  %t469 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t469, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t471 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 0
  store i64 %t473, ptr %l28, !tbaa !24
  br label %bb136
bb135:
  br label %bb143
bb136:
  store %olang.scope zeroinitializer, ptr %s23
  %t475 = load i64, ptr %l27, !tbaa !24
  %t476 = load i64, ptr %l28, !tbaa !24
  %t479 = icmp slt i64 %t475, %t476
  %t481 = xor i1 %t479, true
  br i1 %t481, label %bb137, label %bb138
bb137:
  call void @__olang_scope_close(ptr %s23)
  br label %bb142
bb138:
  br label %bb139
bb139:
  %t483 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t483, ptr %l239, !tbaa !27
  %t484 = load i64, ptr %l27, !tbaa !24
  %t486 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t487 = load ptr, ptr %t486, !tbaa !27
  %t488 = getelementptr ptr, ptr %t487, i64 %t484
  %t489 = load ptr, ptr %t488, !tbaa !39
  %t492 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t489, ptr %t492)
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s23)
  br label %bb141
bb141:
  %t495 = load i64, ptr %l27, !tbaa !24
  %t497 = add i64 %t495, 1
  store i64 %t497, ptr %l27, !tbaa !24
  br label %bb136
bb142:
  br label %bb143
bb143:
  %t499 = load ptr, ptr %l25, !tbaa !29
  %t501 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t499, ptr %t501)
  br label %bb144
bb144:
  br label %bb161
bb145:
  %t504 = load ptr, ptr %l0, !tbaa !29
  store ptr %t504, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t505 = load ptr, ptr %l249, !tbaa !29
  %t506 = icmp ne ptr %t505, null
  br i1 %t506, label %bb146, label %bb147
bb146:
  %t508 = load ptr, ptr %l249, !tbaa !29
  %t509 = load i64, ptr %t508
  %t511 = icmp eq i64 %t509, 17
  store i1 %t511, ptr %l250, !tbaa !21
  br label %bb147
bb147:
  %t512 = load i1, ptr %l250, !tbaa !21
  br i1 %t512, label %bb148, label %bb149
bb148:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr { i64, [4 x i64] }, ptr %t513, i32 0, i32 1
  %t516 = getelementptr { %"compiler/source:Span", ptr }, ptr %t515, i32 0, i32 1
  %t517 = load ptr, ptr %t516
  store ptr %t517, ptr %l30, !tbaa !29
  br label %bb150
bb149:
  br label %bb153
bb150:
  %t519 = load ptr, ptr %l30, !tbaa !29
  %t521 = getelementptr %"compiler/ast:JoinS", ptr %t519, i32 0, i32 1
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t523 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t522, ptr %t523)
  br label %bb151
bb151:
  %t526 = load ptr, ptr %l30, !tbaa !29
  %t528 = getelementptr %"compiler/ast:JoinS", ptr %t526, i32 0, i32 2
  %t529 = load { i64, ptr }, ptr %t528, !tbaa !27
  %t530 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t529, ptr %t530)
  br label %bb152
bb152:
  br label %bb161
bb153:
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l261, !tbaa !29
  store i1 false, ptr %l262, !tbaa !21
  %t534 = load ptr, ptr %l261, !tbaa !29
  %t535 = icmp ne ptr %t534, null
  br i1 %t535, label %bb154, label %bb155
bb154:
  %t537 = load ptr, ptr %l261, !tbaa !29
  %t538 = load i64, ptr %t537
  %t540 = icmp eq i64 %t538, 18
  store i1 %t540, ptr %l262, !tbaa !21
  br label %bb155
bb155:
  %t541 = load i1, ptr %l262, !tbaa !21
  br i1 %t541, label %bb156, label %bb157
bb156:
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 1
  %t545 = getelementptr { %"compiler/source:Span", ptr }, ptr %t544, i32 0, i32 1
  %t546 = load ptr, ptr %t545
  store ptr %t546, ptr %l31, !tbaa !29
  br label %bb158
bb157:
  br label %bb160
bb158:
  %t548 = load ptr, ptr %l31, !tbaa !29
  %t550 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t548, ptr %t550)
  br label %bb159
bb159:
  br label %bb161
bb160:
  br label %bb161
bb161:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:errBind" @compiler_2fcheck_3aerrBind_2ector(ptr %v0, i32 %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %rv = alloca %"compiler/check:errBind"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:errBind" undef, i32 %a0, 0
  %t12 = insertvalue %"compiler/check:errBind" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:errBind" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/check:errBind" %t14, %"compiler/source:Span" %a3, 3
  store %"compiler/check:errBind" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:errBind", ptr %rv
  ret %"compiler/check:errBind" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d0 = private constant [7 x i8] c"is null"
@.d1 = private constant [11 x i8] c"is not null"
@.d2 = private constant [3 x i8] c"U64"
@.d3 = private constant [18 x i8] c"std/prelude/number"
@.d4 = private constant [11 x i8] c"NumberError"
@.d5 = private constant [8 x i8] c"OVERFLOW"
@.d6 = private constant [18 x i8] c"std/prelude/number"
@.d7 = private constant [11 x i8] c"NumberError"
@.d8 = private constant [7 x i8] c"INVALID"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_ert_req_clear()
@.d9 = private constant [1 x i8] c"'"
@.d10 = private constant [1 x i8] c"'"
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d11 = private constant [2 x i8] c"!="
@.d12 = private constant [2 x i8] c"=="
@.d13 = private constant [5 x i8] c"Array"
@.d14 = private constant [5 x i8] c"Array"
@.d15 = private constant [27 x i8] c"a generic call of this kind"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d16 = private constant [1 x i8] c"_"
@.d17 = private constant [6 x i8] c"Narrow"
@.d18 = private constant [3 x i8] c"Len"
@.d19 = private constant [3 x i8] c"Len"
@.d20 = private constant [4 x i8] c"Hash"
@.d21 = private constant [3 x i8] c"Str"
@.d22 = private constant [43 x i8] c"a method the compiler supplies (E10b, E11c)"
@.d23 = private constant [2 x i8] c"At"
@.d24 = private constant [6 x i8] c"'x[i]'"
@.d25 = private constant [5 x i8] c"SetAt"
@.d26 = private constant [7 x i8] c"nothing"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant [2 x i8] c", "
@.d28 = private constant [16 x i8] c"std/prelude/text"
@.d29 = private constant [6 x i8] c"String"
@.d30 = private constant [4 x i8] c"Next"
@.d31 = private constant [7 x i8] c"RunFrom"
@.d32 = private constant [5 x i8] c"'for'"
@.d33 = private constant [4 x i8] c"Next"
@.d34 = private constant [5 x i8] c"'for'"
@.d35 = private constant [4 x i8] c"Iter"
@.d36 = private constant [5 x i8] c"'for'"
@.d37 = private constant [4 x i8] c"Next"
@.d38 = private constant [43 x i8] c"an Iter() whose result is no iterator (S9c)"
@.d39 = private constant [2 x i8] c"At"
@.d40 = private constant [5 x i8] c"'for'"
@.d41 = private constant [3 x i8] c"Len"
@.d42 = private constant [4 x i8] c"Next"
@.d43 = private constant [12 x i8] c"'for ... in'"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eCtEns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_3c4137bcc23e7cab_322d476e7cbf1657 = external constant [0 x i8]
@olang_loc_64e99bada124913c_2f99d6e12db86a38 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eclosedFn(ptr %v0, ptr %a0)
@olang_loc_f407e4aa2d3806b8_dd2e5682c5fdf6f4 = external constant [0 x i8]
@olang_loc_1b45850c01c63cc9_5ae567fd22704b05 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fd7ab254095cc62_437ccc419ec0735e = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_94214b31169ec8c4_68c852e51d74cc68 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
@olang_loc_d48ba9fb56fa57b5_9836703f13f4bc39 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
@olang_loc_964ce48e3719b9fe_ecf9d1875d849bc2 = external constant [0 x i8]
@olang_loc_8e70546afa6befff_28f677a32934e343 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCompare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNullCompared(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseCompare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H86c927da52ed537ecb3749a8061e4fd7(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2e_H929f17842d04d84b7252ab4439481a7f(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDivideByZero(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eShiftUnadapted(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLiteralExprNoValue(ptr %v0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisInt(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitU64(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_a245edc164872a99_7db9d56e029b164d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseUnknownName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseIsSubject(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echainCmp(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, ptr %a4, ptr %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseTwice(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorTypeAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ebcf32f47df7174f_4e59f8f3ef8032cb = external constant [0 x i8]
@olang_loc_e4324c4b30f6563f_ec149b7f01d5683b = external constant [0 x i8]
@olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ectKey(%"compiler/source:Span" %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ename(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
@olang_loc_edce07484728b5af_b35724a5016b0523 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunary(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, i32 %a4)
@olang_loc_1cb65e67365b7050_f7614dad1dc2ba14 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembership(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escoped(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emember(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoin(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etryExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebang(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIncdecInExpression(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eidentity(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i1 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easCase(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsOnlyNull(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eslice(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echain(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ematchValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomprehension(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fcheck_2eexprKindName(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisOver(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elengthsMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCountRange(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
@olang_loc_63e5d6ec29e0915f_e13c517565128b43 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMutOnValueType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayMake(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3, i32 %a4, ptr %a5)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleadWord(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0)
@olang_loc_b174354d9e16fd38_b3c97c50613a8cf4 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_8ebb37c5c90e9f1b_48dd25e04e404e97 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
@olang_loc_428b3df5b28fd586_8d50c863a2687fe2 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemPlace(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2efieldSpans(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeHoldsItself(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_4bb92e4e6aa9fa92_ae49a41c9a1a92ee = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1010397456489e66_cacc16b72eedbd12 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fb9d93c6082892c7_80b52fbeeb5e713 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_89233ed815a81c43_385dc0f6d58c413f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @compiler_2ftyped_3aLocal_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0, i32 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsour_H00be49c2f1e120c94602e8686f44be2a(ptr %v0, ptr %a0, %"std/pair:Pair.ee791c76fa337c2e45b252e8964cf3ed" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fnames_2eLoneCatchName(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodIsPrivate(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d23330c3ef7ea91b_34477ea00961dc87 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, { i64, ptr } %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDefaultAmbiguous(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNonNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebaseHas(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodNotInherited(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuppliedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_897998a95b9e5e2e_e7f90bd867c953f2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efield(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnknownMethod(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_97297cf958301a5_897be3a3c1a33231 = external constant [0 x i8]
@olang_loc_f4ec2e4bc4870738_831a294d3dfd1224 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/check:narrowed" @compiler_2fcheck_3anarrowed_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ePu_H8ca7ff483075a23de06ba27b878260e2(ptr %v0, ptr %a0, %"compiler/check:narrowed" %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebracketIn(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAtUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_60d47afda00c6d15_78511e797186b151 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettle(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H89a3697e96ae7f34894afc674ffcde65(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtended(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64f1128892bbfadb_2fd1650a543ec847 = external constant [0 x i8]
@olang_loc_9b328daa59c12fec_530ed6f7b483a728 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_aa71917389f82fa1_ab8db462134cc7fd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_45c1f7cb36e76579_9732da1c199d4515 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_4aa9dd44a8cec868_fb6ff994c97fa99c = external constant [0 x i8]
@olang_loc_7a17fa9e9f4eb839_ac023da83e9691cd = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eLen_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0)
declare %"compiler/check:Ask" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eSetAt_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:Ask" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAsk_3e_2eTruncate_3ccompiler_2fcheck_3aAsk_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eL_H74c4c659bc848d1046c0a3f6eab69368(ptr %v0, ptr %a0)
declare %"compiler/check:AssertAsk" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eA_Hdc7a201c0afbc93ed6dfeec3b1f47711(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eS_Hc42af0083e860bde3bfdbe1629d1fbcf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/check:AssertAsk" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aAssertAsk_3e_2eT_H5b1bf5f8eb2d6b750ac9501715f6a378(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aItem_3e_2eRunFrom_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5fd52f4d7445d4a4_148eaf691bd21768 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8e2cf6b2c24620f0_dcbb1c47a1cef46c = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclType(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyArg(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eLen_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %a0)
declare %"compiler/check:atRec" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aatRec_3e_2eAt_3ccompiler_2fcheck_3aatRec_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIter(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIterable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleUse(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eiterShaped(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkRuns(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, ptr %a5, i32 %a6)
@olang_loc_b5c196eacf828aab_2dac07573477728f = external constant [0 x i8]
@olang_loc_139af6e2a2dcda96_1438f6a9e620193a = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkIndexed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i64 %a4, i64 %a5, ptr %a6, i32 %a7)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_db613d0fd16ec597_dffdd95765f5abab = external constant [0 x i8]
@olang_loc_261e3060da575f7_c13e4a553a852783 = external constant [0 x i8]
@olang_loc_1591269354839ba0_3246c27539059c2c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escopeVarOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/check:ctSource" %a3, i32 %a4, %"compiler/source:Span" %a5)
declare %"compiler/typed:ScopeRel" @compiler_2ftyped_3aScopeRel_2ector(ptr %v0, i64 %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2ePu_H3d39058be51439e1c4066e8dcab52826(ptr %v0, ptr %a0, %"compiler/typed:ScopeRel" %a1)
@olang_loc_83df14ccfb59caa2_79e7c0956b45666e = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8 = external constant [0 x i8]
@olang_loc_a6ce77febe1defe5_34385e948c177179 = external constant [0 x i8]
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
@olang_loc_bff01f20505ccdb5_4aab420456ab469 = external constant [0 x i8]
@olang_loc_a2bfaee8e4bbf2f0_c4354a8bc250ee0c = external constant [0 x i8]
@olang_loc_d195b38137e2d30_7d67c1d5e7f3802c = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
