; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2e_3cmath_2eh_3e_2eFP__ILOGB0 = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\80" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__ILOGBNAN = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\80" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INFINITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INT__DOWNWARD = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INT__TONEAREST = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INT__TONEARESTFROMZERO = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INT__TOWARDZERO = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__INT__UPWARD = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__LLOGB0 = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__LLOGBNAN = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\80" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__NAN = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__NORMAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__SUBNORMAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eFP__ZERO = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eMATH__ERREXCEPT = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eMATH__ERRNO = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cmath_2eh_3e_2eMAXFLOAT = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\7F\7F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__1__PI = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\D4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__1__PIf = constant <{ [4 x i8] }> <{ [4 x i8] c"\83\F9\A2\3E" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__1__PIf32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\D4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__1__PIf64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\D4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__PI = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\E4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__PIf = constant <{ [4 x i8] }> <{ [4 x i8] c"\83\F9\22\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__PIf32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\E4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__PIf64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\83\C8\C9\6D\30\5F\E4\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__SQRTPI = constant <{ [8 x i8] }> <{ [8 x i8] c"\6D\9B\42\50\D7\0D\F2\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf = constant <{ [4 x i8] }> <{ [4 x i8] c"\BB\6E\90\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\6D\9B\42\50\D7\0D\F2\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\6D\9B\42\50\D7\0D\F2\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__E = constant <{ [8 x i8] }> <{ [8 x i8] c"\69\57\14\8B\0A\BF\05\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__Ef = constant <{ [4 x i8] }> <{ [4 x i8] c"\54\F8\2D\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__Ef32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\69\57\14\8B\0A\BF\05\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__Ef64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\69\57\14\8B\0A\BF\05\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN10 = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\55\B5\BB\B1\6B\02\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN10f = constant <{ [4 x i8] }> <{ [4 x i8] c"\8E\5D\13\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN10f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\55\B5\BB\B1\6B\02\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN10f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\16\55\B5\BB\B1\6B\02\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN2 = constant <{ [8 x i8] }> <{ [8 x i8] c"\EF\39\FA\FE\42\2E\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN2f = constant <{ [4 x i8] }> <{ [4 x i8] c"\18\72\31\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN2f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\EF\39\FA\FE\42\2E\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LN2f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\EF\39\FA\FE\42\2E\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG10E = constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\E5\26\15\7B\CB\DB\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG10Ef = constant <{ [4 x i8] }> <{ [4 x i8] c"\D9\5B\DE\3E" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG10Ef32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\E5\26\15\7B\CB\DB\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG10Ef64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\E5\26\15\7B\CB\DB\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG2E = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\82\2B\65\47\15\F7\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG2Ef = constant <{ [4 x i8] }> <{ [4 x i8] c"\3B\AA\B8\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG2Ef32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\82\2B\65\47\15\F7\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__LOG2Ef64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\82\2B\65\47\15\F7\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\09\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__2 = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\F9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__2f = constant <{ [4 x i8] }> <{ [4 x i8] c"\DB\0F\C9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__2f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\F9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__2f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\F9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__4 = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\E9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__4f = constant <{ [4 x i8] }> <{ [4 x i8] c"\DB\0F\49\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__4f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\E9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PI__4f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\E9\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PIf = constant <{ [4 x i8] }> <{ [4 x i8] c"\DB\0F\49\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PIf32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\09\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__PIf64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\18\2D\44\54\FB\21\09\40" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT1__2 = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT1__2f = constant <{ [4 x i8] }> <{ [4 x i8] c"\F3\04\35\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT1__2f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT1__2f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\E6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT2 = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\F6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT2f = constant <{ [4 x i8] }> <{ [4 x i8] c"\F3\04\B5\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT2f32x = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\F6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2eM__SQRT2f64 = constant <{ [8 x i8] }> <{ [8 x i8] c"\CD\3B\7F\66\9E\A0\F6\3F" }>, align 8
@G_2e_3cmath_2eh_3e_2emath__errhandling = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
define dso_local void @_3cmath_2eh_3e_2eFP__ILOGB0_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -2147483648, ptr @G_2e_3cmath_2eh_3e_2eFP__ILOGB0, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__ILOGBNAN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -2147483648, ptr @G_2e_3cmath_2eh_3e_2eFP__ILOGBNAN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INFINITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cmath_2eh_3e_2eFP__INFINITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INT__DOWNWARD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cmath_2eh_3e_2eFP__INT__DOWNWARD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INT__TONEARESTFROMZERO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cmath_2eh_3e_2eFP__INT__TONEARESTFROMZERO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INT__TONEAREST_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cmath_2eh_3e_2eFP__INT__TONEAREST, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INT__TOWARDZERO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cmath_2eh_3e_2eFP__INT__TOWARDZERO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__INT__UPWARD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cmath_2eh_3e_2eFP__INT__UPWARD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__LLOGB0_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -9223372036854775808, ptr @G_2e_3cmath_2eh_3e_2eFP__LLOGB0, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__LLOGBNAN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 -9223372036854775808, ptr @G_2e_3cmath_2eh_3e_2eFP__LLOGBNAN, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__NAN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cmath_2eh_3e_2eFP__NAN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__NORMAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cmath_2eh_3e_2eFP__NORMAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__SUBNORMAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cmath_2eh_3e_2eFP__SUBNORMAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eFP__ZERO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cmath_2eh_3e_2eFP__ZERO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eMATH__ERREXCEPT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cmath_2eh_3e_2eMATH__ERREXCEPT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eMATH__ERRNO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cmath_2eh_3e_2eMATH__ERRNO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eMAXFLOAT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x47efffffe0000000, ptr @G_2e_3cmath_2eh_3e_2eMAXFLOAT, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__1__PI_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fd45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__1__PI, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__1__PIf32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fd45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__1__PIf32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__1__PIf64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fd45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__1__PIf64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__1__PIf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fd45f3060000000, ptr @G_2e_3cmath_2eh_3e_2eM__1__PIf, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__PI_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__2__PI, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__PIf32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__2__PIf32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__PIf64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe45f306dc9c883, ptr @G_2e_3cmath_2eh_3e_2eM__2__PIf64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__PIf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fe45f3060000000, ptr @G_2e_3cmath_2eh_3e_2eM__2__PIf, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__SQRTPI_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff20dd750429b6d, ptr @G_2e_3cmath_2eh_3e_2eM__2__SQRTPI, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__SQRTPIf32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff20dd750429b6d, ptr @G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__SQRTPIf64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff20dd750429b6d, ptr @G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__2__SQRTPIf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3ff20dd760000000, ptr @G_2e_3cmath_2eh_3e_2eM__2__SQRTPIf, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__E_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x4005bf0a8b145769, ptr @G_2e_3cmath_2eh_3e_2eM__E, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__Ef32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x4005bf0a8b145769, ptr @G_2e_3cmath_2eh_3e_2eM__Ef32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__Ef64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x4005bf0a8b145769, ptr @G_2e_3cmath_2eh_3e_2eM__Ef64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__Ef_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x4005bf0a80000000, ptr @G_2e_3cmath_2eh_3e_2eM__Ef, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN10_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x40026bb1bbb55516, ptr @G_2e_3cmath_2eh_3e_2eM__LN10, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN10f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x40026bb1bbb55516, ptr @G_2e_3cmath_2eh_3e_2eM__LN10f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN10f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x40026bb1bbb55516, ptr @G_2e_3cmath_2eh_3e_2eM__LN10f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN10f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x40026bb1c0000000, ptr @G_2e_3cmath_2eh_3e_2eM__LN10f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN2_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe62e42fefa39ef, ptr @G_2e_3cmath_2eh_3e_2eM__LN2, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN2f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe62e42fefa39ef, ptr @G_2e_3cmath_2eh_3e_2eM__LN2f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN2f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe62e42fefa39ef, ptr @G_2e_3cmath_2eh_3e_2eM__LN2f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LN2f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fe62e4300000000, ptr @G_2e_3cmath_2eh_3e_2eM__LN2f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG10E_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fdbcb7b1526e50e, ptr @G_2e_3cmath_2eh_3e_2eM__LOG10E, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG10Ef32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fdbcb7b1526e50e, ptr @G_2e_3cmath_2eh_3e_2eM__LOG10Ef32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG10Ef64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fdbcb7b1526e50e, ptr @G_2e_3cmath_2eh_3e_2eM__LOG10Ef64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG10Ef_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fdbcb7b20000000, ptr @G_2e_3cmath_2eh_3e_2eM__LOG10Ef, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG2E_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff71547652b82fe, ptr @G_2e_3cmath_2eh_3e_2eM__LOG2E, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG2Ef32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff71547652b82fe, ptr @G_2e_3cmath_2eh_3e_2eM__LOG2Ef32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG2Ef64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff71547652b82fe, ptr @G_2e_3cmath_2eh_3e_2eM__LOG2Ef64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__LOG2Ef_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3ff7154760000000, ptr @G_2e_3cmath_2eh_3e_2eM__LOG2Ef, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x400921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__2_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__2, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__2f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__2f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__2f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__2f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__2f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3ff921fb60000000, ptr @G_2e_3cmath_2eh_3e_2eM__PI__2f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__4_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__4, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__4f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__4f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__4f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PI__4f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PI__4f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fe921fb60000000, ptr @G_2e_3cmath_2eh_3e_2eM__PI__4f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PIf32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x400921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PIf32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PIf64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x400921fb54442d18, ptr @G_2e_3cmath_2eh_3e_2eM__PIf64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__PIf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x400921fb60000000, ptr @G_2e_3cmath_2eh_3e_2eM__PIf, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT1__2_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT1__2, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT1__2f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT1__2f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT1__2f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3fe6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT1__2f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT1__2f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3fe6a09e60000000, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT1__2f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT2_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT2, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT2f32x_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT2f32x, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT2f64_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store double 0x3ff6a09e667f3bcd, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT2f64, !tbaa !26
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2eM__SQRT2f_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store float 0x3ff6a09e60000000, ptr @G_2e_3cmath_2eh_3e_2eM__SQRT2f, !tbaa !25
  br label %ret
ret:
  ret void
}

define dso_local void @_3cmath_2eh_3e_2emath__errhandling_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cmath_2eh_3e_2emath__errhandling, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2e_3cmath_2eh_3e() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_3cmath_2eh_3e_2eFP__INT__UPWARD_2einit()
  br label %bb1
bb1:
  call void @_3cmath_2eh_3e_2eFP__INT__DOWNWARD_2einit()
  br label %bb2
bb2:
  call void @_3cmath_2eh_3e_2eFP__INT__TOWARDZERO_2einit()
  br label %bb3
bb3:
  call void @_3cmath_2eh_3e_2eFP__INT__TONEARESTFROMZERO_2einit()
  br label %bb4
bb4:
  call void @_3cmath_2eh_3e_2eFP__INT__TONEAREST_2einit()
  br label %bb5
bb5:
  call void @_3cmath_2eh_3e_2eFP__NAN_2einit()
  br label %bb6
bb6:
  call void @_3cmath_2eh_3e_2eFP__INFINITE_2einit()
  br label %bb7
bb7:
  call void @_3cmath_2eh_3e_2eFP__ZERO_2einit()
  br label %bb8
bb8:
  call void @_3cmath_2eh_3e_2eFP__SUBNORMAL_2einit()
  br label %bb9
bb9:
  call void @_3cmath_2eh_3e_2eFP__NORMAL_2einit()
  br label %bb10
bb10:
  call void @_3cmath_2eh_3e_2eFP__ILOGB0_2einit()
  br label %bb11
bb11:
  call void @_3cmath_2eh_3e_2eFP__ILOGBNAN_2einit()
  br label %bb12
bb12:
  call void @_3cmath_2eh_3e_2eFP__LLOGB0_2einit()
  br label %bb13
bb13:
  call void @_3cmath_2eh_3e_2eFP__LLOGBNAN_2einit()
  br label %bb14
bb14:
  call void @_3cmath_2eh_3e_2eMATH__ERRNO_2einit()
  br label %bb15
bb15:
  call void @_3cmath_2eh_3e_2eMATH__ERREXCEPT_2einit()
  br label %bb16
bb16:
  call void @_3cmath_2eh_3e_2emath__errhandling_2einit()
  br label %bb17
bb17:
  call void @_3cmath_2eh_3e_2eMAXFLOAT_2einit()
  br label %bb18
bb18:
  call void @_3cmath_2eh_3e_2eM__E_2einit()
  br label %bb19
bb19:
  call void @_3cmath_2eh_3e_2eM__LOG2E_2einit()
  br label %bb20
bb20:
  call void @_3cmath_2eh_3e_2eM__LOG10E_2einit()
  br label %bb21
bb21:
  call void @_3cmath_2eh_3e_2eM__LN2_2einit()
  br label %bb22
bb22:
  call void @_3cmath_2eh_3e_2eM__LN10_2einit()
  br label %bb23
bb23:
  call void @_3cmath_2eh_3e_2eM__PI_2einit()
  br label %bb24
bb24:
  call void @_3cmath_2eh_3e_2eM__PI__2_2einit()
  br label %bb25
bb25:
  call void @_3cmath_2eh_3e_2eM__PI__4_2einit()
  br label %bb26
bb26:
  call void @_3cmath_2eh_3e_2eM__1__PI_2einit()
  br label %bb27
bb27:
  call void @_3cmath_2eh_3e_2eM__2__PI_2einit()
  br label %bb28
bb28:
  call void @_3cmath_2eh_3e_2eM__2__SQRTPI_2einit()
  br label %bb29
bb29:
  call void @_3cmath_2eh_3e_2eM__SQRT2_2einit()
  br label %bb30
bb30:
  call void @_3cmath_2eh_3e_2eM__SQRT1__2_2einit()
  br label %bb31
bb31:
  call void @_3cmath_2eh_3e_2eM__Ef_2einit()
  br label %bb32
bb32:
  call void @_3cmath_2eh_3e_2eM__LOG2Ef_2einit()
  br label %bb33
bb33:
  call void @_3cmath_2eh_3e_2eM__LOG10Ef_2einit()
  br label %bb34
bb34:
  call void @_3cmath_2eh_3e_2eM__LN2f_2einit()
  br label %bb35
bb35:
  call void @_3cmath_2eh_3e_2eM__LN10f_2einit()
  br label %bb36
bb36:
  call void @_3cmath_2eh_3e_2eM__PIf_2einit()
  br label %bb37
bb37:
  call void @_3cmath_2eh_3e_2eM__PI__2f_2einit()
  br label %bb38
bb38:
  call void @_3cmath_2eh_3e_2eM__PI__4f_2einit()
  br label %bb39
bb39:
  call void @_3cmath_2eh_3e_2eM__1__PIf_2einit()
  br label %bb40
bb40:
  call void @_3cmath_2eh_3e_2eM__2__PIf_2einit()
  br label %bb41
bb41:
  call void @_3cmath_2eh_3e_2eM__2__SQRTPIf_2einit()
  br label %bb42
bb42:
  call void @_3cmath_2eh_3e_2eM__SQRT2f_2einit()
  br label %bb43
bb43:
  call void @_3cmath_2eh_3e_2eM__SQRT1__2f_2einit()
  br label %bb44
bb44:
  call void @_3cmath_2eh_3e_2eM__Ef64_2einit()
  br label %bb45
bb45:
  call void @_3cmath_2eh_3e_2eM__LOG2Ef64_2einit()
  br label %bb46
bb46:
  call void @_3cmath_2eh_3e_2eM__LOG10Ef64_2einit()
  br label %bb47
bb47:
  call void @_3cmath_2eh_3e_2eM__LN2f64_2einit()
  br label %bb48
bb48:
  call void @_3cmath_2eh_3e_2eM__LN10f64_2einit()
  br label %bb49
bb49:
  call void @_3cmath_2eh_3e_2eM__PIf64_2einit()
  br label %bb50
bb50:
  call void @_3cmath_2eh_3e_2eM__PI__2f64_2einit()
  br label %bb51
bb51:
  call void @_3cmath_2eh_3e_2eM__PI__4f64_2einit()
  br label %bb52
bb52:
  call void @_3cmath_2eh_3e_2eM__1__PIf64_2einit()
  br label %bb53
bb53:
  call void @_3cmath_2eh_3e_2eM__2__PIf64_2einit()
  br label %bb54
bb54:
  call void @_3cmath_2eh_3e_2eM__2__SQRTPIf64_2einit()
  br label %bb55
bb55:
  call void @_3cmath_2eh_3e_2eM__SQRT2f64_2einit()
  br label %bb56
bb56:
  call void @_3cmath_2eh_3e_2eM__SQRT1__2f64_2einit()
  br label %bb57
bb57:
  call void @_3cmath_2eh_3e_2eM__Ef32x_2einit()
  br label %bb58
bb58:
  call void @_3cmath_2eh_3e_2eM__LOG2Ef32x_2einit()
  br label %bb59
bb59:
  call void @_3cmath_2eh_3e_2eM__LOG10Ef32x_2einit()
  br label %bb60
bb60:
  call void @_3cmath_2eh_3e_2eM__LN2f32x_2einit()
  br label %bb61
bb61:
  call void @_3cmath_2eh_3e_2eM__LN10f32x_2einit()
  br label %bb62
bb62:
  call void @_3cmath_2eh_3e_2eM__PIf32x_2einit()
  br label %bb63
bb63:
  call void @_3cmath_2eh_3e_2eM__PI__2f32x_2einit()
  br label %bb64
bb64:
  call void @_3cmath_2eh_3e_2eM__PI__4f32x_2einit()
  br label %bb65
bb65:
  call void @_3cmath_2eh_3e_2eM__1__PIf32x_2einit()
  br label %bb66
bb66:
  call void @_3cmath_2eh_3e_2eM__2__PIf32x_2einit()
  br label %bb67
bb67:
  call void @_3cmath_2eh_3e_2eM__2__SQRTPIf32x_2einit()
  br label %bb68
bb68:
  call void @_3cmath_2eh_3e_2eM__SQRT2f32x_2einit()
  br label %bb69
bb69:
  call void @_3cmath_2eh_3e_2eM__SQRT1__2f32x_2einit()
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}


!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
