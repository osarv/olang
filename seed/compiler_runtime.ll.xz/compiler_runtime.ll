; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2fruntime_2eArchs = global { i64, ptr } zeroinitializer
@G_2ecompiler_2fruntime_2eFactArm = global { i64, ptr } zeroinitializer
@G_2ecompiler_2fruntime_2eFactNames = global { i64, ptr } zeroinitializer
@G_2ecompiler_2fruntime_2eFactX86 = global { i64, ptr } zeroinitializer
@G_2ecompiler_2fruntime_2eHeaderTbaa = global { i64, ptr } zeroinitializer
define dso_local void @compiler_2fruntime_2eArchs_2einit() #0 {
entry:
  %l0 = alloca [2 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr @.d0 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr @.d1 }, 1
  store [2 x { i64, ptr }] %t2, ptr %l0
  %t3 = load [2 x { i64, ptr }], ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call ptr @__olang_scope_alloc(ptr %t4, i64 32)
  store [2 x { i64, ptr }] %t3, ptr %t5
  %t6 = insertvalue { i64, ptr } undef, i64 2, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  %t8 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eArchs, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp eq i64 %t12, %t13
  store i1 %t14, ptr %l4, !tbaa !21
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t16 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eArchs, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = mul i64 %t20, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  br label %bb3
bb2:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr @G_2ecompiler_2fruntime_2eArchs, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l6, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t5, ptr %l7
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l7
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l3, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %t7)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l11
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l11, !tbaa !23
  %t15 = ashr i32 %t14, 16
  store i32 %t15, ptr %l12, !tbaa !23
  %t16 = load i32, ptr %l12, !tbaa !23
  %t17 = icmp eq i32 %t16, 1
  store i1 %t17, ptr %l13, !tbaa !21
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb9:
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t20 = load i1, ptr %l2, !tbaa !21
  store i1 %t20, ptr %l14, !tbaa !21
  %t21 = load i1, ptr %l14, !tbaa !21
  br i1 %t21, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l1, ptr %l15, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t23, { i64, ptr } %t24)
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t25, ptr %l20, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t27 = call i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %t26)
  store i1 %t27, ptr %l21
  br label %bb18
bb12:
  store ptr %l1, ptr %l17, !tbaa !29
  %t28 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t28, i8 10)
  br label %bb13
bb13:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t29, ptr %l18, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t30, { i64, ptr } { i64 1, ptr @.d3 })
  store i1 %t31, ptr %l19
  br label %bb14
bb14:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb18:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l22, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l24, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = icmp sge i64 7, 0
  store i1 %t41, ptr %l28, !tbaa !21
  %t42 = load i1, ptr %l28, !tbaa !21
  br i1 %t42, label %bb21, label %bb22
bb20:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l1, ptr %l34, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t43, ptr %l35, !tbaa !27
  %t44 = load ptr, ptr %l34, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l35, !tbaa !27
  call void @compiler_2fruntime_2edeclare(ptr %s0, ptr %v0, ptr %t44, { i64, ptr } %t45)
  br label %bb28
bb21:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp sle i64 7, %t46
  store i1 %t47, ptr %l29, !tbaa !21
  %t48 = load i1, ptr %l29, !tbaa !21
  br i1 %t48, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb23:
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  store i1 %t51, ptr %l30, !tbaa !21
  %t52 = load i1, ptr %l30, !tbaa !21
  br i1 %t52, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb25:
  %t53 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 7
  %t57 = sub i64 %t55, 7
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t60 = extractvalue { i64, ptr } { i64 28, ptr @.d5 }, 1
  %t61 = extractvalue { i64, ptr } { i64 28, ptr @.d5 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t60, i64 %t61)
  %t62 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  call void @__olang_sb_put(ptr %s7, ptr %t63, i64 %t64)
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 0
  call void @__olang_sb_put(ptr %s7, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s7
  %t68 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t67, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l32, !tbaa !27
  call void @__olang_sb_done(ptr %s7)
  %t73 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  %t80 = load ptr, ptr %l22, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t80, { i64, ptr } %t81)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb27:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb3
bb32:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l36, !tbaa !29
  %t82 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t82, i8 10)
  br label %bb33
bb33:
  store ptr %l1, ptr %l37, !tbaa !29
  %t83 = load ptr, ptr %l37, !tbaa !29
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t83)
  store { i64, ptr } %t84, ptr %l38
  br label %bb34
bb34:
  %t85 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t85, ptr %l39, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l40, !tbaa !24
  %t88 = load i64, ptr %l40, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l41, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t99, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load i1, ptr %l3, !tbaa !21
  store i1 %t2, ptr %l10, !tbaa !21
  %t3 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t4 = load i1, ptr %l10, !tbaa !21
  %t5 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t3, i1 %t4, i1 false)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %l13, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t20, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load i1, ptr %l3, !tbaa !21
  store i1 %t24, ptr %l16, !tbaa !21
  %t25 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t25, i1 %t26, i1 true)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l17
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  br label %bb6
bb5:
  %t33 = load i32, ptr %l18, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  store i32 %t41, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t42 = load i32, ptr %l19, !tbaa !23
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t42, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t45, ptr %l20, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l21, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t48 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s0, { i64, ptr } %t47)
  store { i64, ptr } %t48, ptr %l22
  br label %bb7
bb7:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t49, ptr %l23, !tbaa !27
  %t50 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  store { i64, ptr } %t50, ptr %l24, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t51 = extractvalue { i64, ptr } { i64 17, ptr @.d7 }, 1
  %t52 = extractvalue { i64, ptr } { i64 17, ptr @.d7 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t51, i64 %t52)
  %t53 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  call void @__olang_sb_put(ptr %s1, ptr %t54, i64 %t55)
  %t56 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 1
  %t57 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t56, i64 %t57)
  %t58 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  call void @__olang_sb_put(ptr %s1, ptr %t59, i64 %t60)
  %t61 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  call void @__olang_sb_put(ptr %s1, ptr %t62, i64 %t63)
  %t64 = extractvalue { i64, ptr } { i64 19, ptr @.d9 }, 1
  %t65 = extractvalue { i64, ptr } { i64 19, ptr @.d9 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t64, i64 %t65)
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = extractvalue { i64, ptr } %t66, 0
  call void @__olang_sb_put(ptr %s1, ptr %t67, i64 %t68)
  %t69 = load ptr, ptr %s1
  %t70 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t71 = load i64, ptr %t70
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t69, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  store { i64, ptr } %t74, ptr %l25, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t75 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t75, ptr %l7, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t76, ptr %l26, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t77, ptr %l27, !tbaa !27
  %t78 = load i1, ptr %l4, !tbaa !21
  store i1 %t78, ptr %l28, !tbaa !21
  %t79 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t81 = load i1, ptr %l28, !tbaa !21
  %t82 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t79, { i64, ptr } %t80, i1 %t81)
  store { i64, ptr } %t82, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t83, 1
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fruntime_2eFactArm_2einit() #0 {
entry:
  %l0 = alloca [12 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [12 x i64] undef, i64 128, 0
  %t2 = insertvalue [12 x i64] %t1, i64 16, 1
  %t3 = insertvalue [12 x i64] %t2, i64 48, 2
  %t4 = insertvalue [12 x i64] %t3, i64 88, 3
  %t5 = insertvalue [12 x i64] %t4, i64 96, 4
  %t6 = insertvalue [12 x i64] %t5, i64 19, 5
  %t7 = insertvalue [12 x i64] %t6, i64 80, 6
  %t8 = insertvalue [12 x i64] %t7, i64 64, 7
  %t9 = insertvalue [12 x i64] %t8, i64 312, 8
  %t10 = insertvalue [12 x i64] %t9, i64 152, 9
  %t11 = insertvalue [12 x i64] %t10, i64 136, 10
  %t12 = insertvalue [12 x i64] %t11, i64 1, 11
  store [12 x i64] %t12, ptr %l0
  %t13 = load [12 x i64], ptr %l0
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call ptr @__olang_scope_alloc(ptr %t14, i64 96)
  store [12 x i64] %t13, ptr %t15
  %t16 = insertvalue { i64, ptr } undef, i64 12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactArm, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp eq i64 %t22, %t23
  store i1 %t24, ptr %l4, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t26 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactArm, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = mul i64 %t30, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  br label %bb3
bb2:
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr @G_2ecompiler_2fruntime_2eFactArm, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fruntime_2eFactNames_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [12 x { i64, ptr }] undef, { i64, ptr } { i64 10, ptr @.d10 }, 0
  %t2 = insertvalue [12 x { i64, ptr }] %t1, { i64, ptr } { i64 9, ptr @.d11 }, 1
  %t3 = insertvalue [12 x { i64, ptr }] %t2, { i64, ptr } { i64 9, ptr @.d12 }, 2
  %t4 = insertvalue [12 x { i64, ptr }] %t3, { i64, ptr } { i64 13, ptr @.d13 }, 3
  %t5 = insertvalue [12 x { i64, ptr }] %t4, { i64, ptr } { i64 14, ptr @.d14 }, 4
  %t6 = insertvalue [12 x { i64, ptr }] %t5, { i64, ptr } { i64 11, ptr @.d15 }, 5
  %t7 = insertvalue [12 x { i64, ptr }] %t6, { i64, ptr } { i64 24, ptr @.d16 }, 6
  %t8 = insertvalue [12 x { i64, ptr }] %t7, { i64, ptr } { i64 18, ptr @.d17 }, 7
  %t9 = insertvalue [12 x { i64, ptr }] %t8, { i64, ptr } { i64 13, ptr @.d18 }, 8
  %t10 = insertvalue [12 x { i64, ptr }] %t9, { i64, ptr } { i64 15, ptr @.d19 }, 9
  %t11 = insertvalue [12 x { i64, ptr }] %t10, { i64, ptr } { i64 15, ptr @.d20 }, 10
  %t12 = insertvalue [12 x { i64, ptr }] %t11, { i64, ptr } { i64 15, ptr @.d21 }, 11
  store [12 x { i64, ptr }] %t12, ptr %l0
  %t13 = load [12 x { i64, ptr }], ptr %l0
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call ptr @__olang_scope_alloc(ptr %t14, i64 192)
  store [12 x { i64, ptr }] %t13, ptr %t15
  %t16 = insertvalue { i64, ptr } undef, i64 12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactNames, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp eq i64 %t22, %t23
  store i1 %t24, ptr %l4, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t26 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactNames, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = mul i64 %t30, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  br label %bb3
bb2:
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr @G_2ecompiler_2fruntime_2eFactNames, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fruntime_2eFactX86_2einit() #0 {
entry:
  %l0 = alloca [12 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [12 x i64] undef, i64 144, 0
  %t2 = insertvalue [12 x i64] %t1, i64 24, 1
  %t3 = insertvalue [12 x i64] %t2, i64 48, 2
  %t4 = insertvalue [12 x i64] %t3, i64 88, 3
  %t5 = insertvalue [12 x i64] %t4, i64 96, 4
  %t6 = insertvalue [12 x i64] %t5, i64 19, 5
  %t7 = insertvalue [12 x i64] %t6, i64 80, 6
  %t8 = insertvalue [12 x i64] %t7, i64 56, 7
  %t9 = insertvalue [12 x i64] %t8, i64 200, 8
  %t10 = insertvalue [12 x i64] %t9, i64 152, 9
  %t11 = insertvalue [12 x i64] %t10, i64 136, 10
  %t12 = insertvalue [12 x i64] %t11, i64 2, 11
  store [12 x i64] %t12, ptr %l0
  %t13 = load [12 x i64], ptr %l0
  %t14 = load ptr, ptr @__olang_prog_scope
  %t15 = call ptr @__olang_scope_alloc(ptr %t14, i64 96)
  store [12 x i64] %t13, ptr %t15
  %t16 = insertvalue { i64, ptr } undef, i64 12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  %t18 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactX86, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp eq i64 %t22, %t23
  store i1 %t24, ptr %l4, !tbaa !21
  %t25 = load i1, ptr %l4, !tbaa !21
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t26 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactX86, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = mul i64 %t30, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t27, ptr %t29, i64 %t31, i1 false)
  br label %bb3
bb2:
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr @G_2ecompiler_2fruntime_2eFactX86, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l40 = alloca i32
  %l41 = alloca i1
  %l42 = alloca i32
  %l43 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca %"std/prelude/text:StringBuilder"
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/text:LineIter"
  %l51 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca i32
  %l56 = alloca i1
  %l57 = alloca i32
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i32
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca i32
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca i1
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i1
  %l134 = alloca { i64, ptr }
  %l135 = alloca i64
  %l136 = alloca i32
  %l137 = alloca i32
  %l138 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i64
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l146 = alloca i32
  %l147 = alloca i32
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca i32
  %l161 = alloca i64
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i1
  %l170 = alloca i1
  %l171 = alloca i1
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i1
  %l181 = alloca i1
  %l182 = alloca i1
  %l183 = alloca { i64, ptr }
  %l184 = alloca i64
  %l185 = alloca { i64, ptr }
  %l186 = alloca i64
  %l187 = alloca i32
  %l188 = alloca i64
  %l189 = alloca i1
  %l190 = alloca { i64, ptr }
  %l191 = alloca i64
  %l192 = alloca i32
  %l193 = alloca i32
  %l194 = alloca i64
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i1
  %l199 = alloca i1
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i32
  %l205 = alloca i32
  %l206 = alloca i1
  %l207 = alloca i32
  %l208 = alloca { i64, ptr }
  %l209 = alloca i64
  %l210 = alloca i32
  %l211 = alloca i32
  %l212 = alloca ptr
  %l213 = alloca i64
  %l214 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l217 = alloca i64
  %l218 = alloca i64
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca i64
  %l222 = alloca i64
  %l223 = alloca i1
  %l224 = alloca i1
  %l225 = alloca i1
  %l226 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l228 = alloca i1
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca i32
  %l232 = alloca i32
  %l233 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l235 = alloca { i64, ptr }
  %l236 = alloca i64
  %l237 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.builder
  %s22room = alloca [64 x i8], align 8
  %s23 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l26
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l27, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t3 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = extractvalue { i64, ptr } { i64 9, ptr @.d22 }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr @.d22 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l28, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l30, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t19)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l32
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb3, label %ok.24
ok.24:
  store { i64, ptr } %t21, ptr %l31
  br label %bb2
bb2:
  %t25 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t25, ptr %l29, !tbaa !27
  br label %bb13
bb3:
  %t26 = load i32, ptr %l32, !tbaa !23
  %t27 = ashr i32 %t26, 16
  store i32 %t27, ptr %l33, !tbaa !23
  %t28 = load i32, ptr %l33, !tbaa !23
  %t29 = icmp eq i32 %t28, 1
  store i1 %t29, ptr %l34, !tbaa !21
  %t30 = load i1, ptr %l34, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t31 = load i32, ptr %l32, !tbaa !23
  %t32 = lshr i32 %t31, 16
  %t33 = and i32 %t31, 65535
  %t34 = icmp eq i32 %t32, 1
  %t35 = select i1 %t34, i32 0, i32 0
  %t36 = icmp eq i32 %t31, 0
  %t37 = shl i32 %t35, 16
  %t38 = or i32 %t37, %t33
  %t39 = select i1 %t36, i32 0, i32 %t38
  store i32 %t39, ptr %l35, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l35, !tbaa !23
  %t41 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t41, ptr %rv
  br label %ret
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t42, ptr %l36, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t43 = extractvalue { i64, ptr } { i64 7, ptr @.d23 }, 1
  %t44 = extractvalue { i64, ptr } { i64 7, ptr @.d23 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t43, i64 %t44)
  %t45 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  call void @__olang_sb_put(ptr %s3, ptr %t46, i64 %t47)
  %t48 = extractvalue { i64, ptr } { i64 23, ptr @.d24 }, 1
  %t49 = extractvalue { i64, ptr } { i64 23, ptr @.d24 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t48, i64 %t49)
  %t50 = load ptr, ptr %s3
  %t51 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t52 = load i64, ptr %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t50, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l37, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t56 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t64 = call i32 @std_2fio_2ePrintErrln(ptr %s2, { i64, ptr } %t63)
  store i32 %t64, ptr %l39
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb8, label %ok.66
ok.66:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t67 = load i32, ptr %l39, !tbaa !23
  %t68 = ashr i32 %t67, 16
  store i32 %t68, ptr %l40, !tbaa !23
  %t69 = load i32, ptr %l40, !tbaa !23
  %t70 = icmp eq i32 %t69, 1
  store i1 %t70, ptr %l41, !tbaa !21
  %t71 = load i1, ptr %l41, !tbaa !21
  br i1 %t71, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  %t72 = load i32, ptr %l39, !tbaa !23
  %t73 = lshr i32 %t72, 16
  %t74 = and i32 %t72, 65535
  %t75 = icmp eq i32 %t73, 1
  %t76 = select i1 %t75, i32 0, i32 0
  %t77 = icmp eq i32 %t72, 0
  %t78 = shl i32 %t76, 16
  %t79 = or i32 %t78, %t74
  %t80 = select i1 %t77, i32 0, i32 %t79
  store i32 %t80, ptr %l42, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i32, ptr %l42, !tbaa !23
  %t82 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t81, 0
  store { i32, { i64, ptr } } %t82, ptr %rv
  br label %ret
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  store i32 65536, ptr %l43, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load i32, ptr %l43, !tbaa !23
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t83, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb13:
  %t85 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t85, ptr %l4, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t86, ptr %l44, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t88, ptr %l5, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t89, ptr %l46, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t91 = call i64 @compiler_2fruntime_2earchRow(ptr %v1, { i64, ptr } %t90)
  store i64 %t91, ptr %l47
  br label %bb14
bb14:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l6, !tbaa !24
  %t93 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t93, ptr %l48
  br label %bb15
bb15:
  %t94 = load %"std/prelude/text:StringBuilder", ptr %l48
  store %"std/prelude/text:StringBuilder" %t94, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s5
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l49, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t97 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t96)
  store %"std/prelude/text:LineIter" %t97, ptr %l50
  br label %bb16
bb16:
  %t98 = load %"std/prelude/text:LineIter", ptr %l50
  store %"std/prelude/text:LineIter" %t98, ptr %l13
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l13, ptr %l52, !tbaa !29
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %t99)
  %t101 = extractvalue { i32, { i64, ptr } } %t100, 1
  %t102 = extractvalue { i32, { i64, ptr } } %t100, 0
  store i32 %t102, ptr %l54
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb19, label %ok.104
ok.104:
  store { i64, ptr } %t101, ptr %l53
  br label %bb18
bb18:
  %t105 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t105, ptr %l51, !tbaa !27
  br label %bb23
bb19:
  %t106 = load i32, ptr %l54, !tbaa !23
  %t107 = ashr i32 %t106, 16
  store i32 %t107, ptr %l55, !tbaa !23
  %t108 = load i32, ptr %l55, !tbaa !23
  %t109 = icmp eq i32 %t108, 1
  store i1 %t109, ptr %l56, !tbaa !21
  %t110 = load i1, ptr %l56, !tbaa !21
  br i1 %t110, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t111 = load i32, ptr %l54, !tbaa !23
  %t112 = lshr i32 %t111, 16
  %t113 = and i32 %t111, 65535
  %t114 = icmp eq i32 %t112, 1
  %t115 = select i1 %t114, i32 0, i32 0
  %t116 = icmp eq i32 %t111, 0
  %t117 = shl i32 %t115, 16
  %t118 = or i32 %t117, %t113
  %t119 = select i1 %t116, i32 0, i32 %t118
  store i32 %t119, ptr %l57, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t120 = load i32, ptr %l57, !tbaa !23
  %t121 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t120, 0
  store { i32, { i64, ptr } } %t121, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb169
bb23:
  %t122 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t122, ptr %l14, !tbaa !27
  %t123 = load i64, ptr %l8, !tbaa !24
  store i64 %t123, ptr %l58, !tbaa !24
  %t124 = load i64, ptr %l58, !tbaa !24
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l59, !tbaa !24
  %t126 = load i64, ptr %l59, !tbaa !24
  store i64 %t126, ptr %l8, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t127, ptr %l60, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t129 = call i64 @compiler_2fruntime_2edirective(ptr %s0, { i64, ptr } %t128)
  store i64 %t129, ptr %l61
  br label %bb24
bb24:
  %t130 = load i64, ptr %l61, !tbaa !24
  store i64 %t130, ptr %l15, !tbaa !24
  %t131 = load i64, ptr %l15, !tbaa !24
  store i64 %t131, ptr %l62, !tbaa !24
  %t132 = load i64, ptr %l62, !tbaa !24
  %t133 = icmp eq i64 %t132, 0
  store i1 %t133, ptr %l63, !tbaa !21
  %t134 = load i1, ptr %l63, !tbaa !21
  br i1 %t134, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t135 = load i1, ptr %l9, !tbaa !21
  store i1 %t135, ptr %l64, !tbaa !21
  %t136 = load i1, ptr %l64, !tbaa !21
  br i1 %t136, label %bb27, label %bb28
bb26:
  br label %bb79
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t137 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t137, ptr %l65, !tbaa !27
  %t138 = load i64, ptr %l8, !tbaa !24
  store i64 %t138, ptr %l66, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t140 = load i64, ptr %l66, !tbaa !24
  %t141 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s8, { i64, ptr } %t139, i64 %t140, { i64, ptr } { i64 22, ptr @.d25 })
  store i32 %t141, ptr %l67
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb30, label %ok.143
ok.143:
  br label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb31
bb30:
  %t144 = load i32, ptr %l67, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  store i32 %t152, ptr %l68, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load i32, ptr %l68, !tbaa !23
  %t154 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t153, 0
  store { i32, { i64, ptr } } %t154, ptr %rv
  br label %ret
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  %t155 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t155, ptr %l69, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t156, ptr %l70, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t157, ptr %l71, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 0
  store i64 %t159, ptr %l72, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l73, !tbaa !24
  %t162 = icmp sge i64 6, 0
  store i1 %t162, ptr %l74, !tbaa !21
  %t163 = load i1, ptr %l74, !tbaa !21
  br i1 %t163, label %bb33, label %bb34
bb33:
  %t164 = load i64, ptr %l72, !tbaa !24
  %t165 = icmp sle i64 6, %t164
  store i1 %t165, ptr %l75, !tbaa !21
  %t166 = load i1, ptr %l75, !tbaa !21
  br i1 %t166, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb35:
  %t167 = load i64, ptr %l72, !tbaa !24
  %t168 = load i64, ptr %l73, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  store i1 %t169, ptr %l76, !tbaa !21
  %t170 = load i1, ptr %l76, !tbaa !21
  br i1 %t170, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb37:
  %t171 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l72, !tbaa !24
  %t174 = getelementptr i8, ptr %t172, i64 6
  %t175 = sub i64 %t173, 6
  %t176 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  store { i64, ptr } %t177, ptr %l77, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t179 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t178)
  store { i64, ptr } %t179, ptr %l78
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb39:
  %t180 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t180, ptr %l16, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t181, ptr %l79, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t183 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t182, { i64, ptr } { i64 1, ptr @.d27 })
  store i1 %t183, ptr %l80
  br label %bb40
bb40:
  %t184 = load i1, ptr %l80, !tbaa !21
  store i1 %t184, ptr %l17, !tbaa !21
  %t185 = load i1, ptr %l17, !tbaa !21
  store i1 %t185, ptr %l81, !tbaa !21
  %t186 = load i1, ptr %l81, !tbaa !21
  br i1 %t186, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t187 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t187, ptr %l82, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t188, ptr %l83, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t189, ptr %l84, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  store i64 %t191, ptr %l85, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l86, !tbaa !24
  %t194 = icmp sge i64 1, 0
  store i1 %t194, ptr %l87, !tbaa !21
  %t195 = load i1, ptr %l87, !tbaa !21
  br i1 %t195, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t196 = load i64, ptr %l85, !tbaa !24
  %t197 = icmp sle i64 1, %t196
  store i1 %t197, ptr %l88, !tbaa !21
  %t198 = load i1, ptr %l88, !tbaa !21
  br i1 %t198, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb45:
  %t199 = load i64, ptr %l85, !tbaa !24
  %t200 = load i64, ptr %l86, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  store i1 %t201, ptr %l89, !tbaa !21
  %t202 = load i1, ptr %l89, !tbaa !21
  br i1 %t202, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb47:
  %t203 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l85, !tbaa !24
  %t206 = getelementptr i8, ptr %t204, i64 1
  %t207 = sub i64 %t205, 1
  %t208 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  store { i64, ptr } %t209, ptr %l90, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t210, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb49:
  %t211 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t211, ptr %l92, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t213 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s7, { i64, ptr } %t212, { i64, ptr } { i64 1, ptr @.d29 })
  %t214 = extractvalue { i32, i64 } %t213, 1
  %t215 = extractvalue { i32, i64 } %t213, 0
  store i32 %t215, ptr %l94
  %t216 = icmp ne i32 %t215, 0
  br i1 %t216, label %bb51, label %ok.217
ok.217:
  store i64 %t214, ptr %l93
  br label %bb50
bb50:
  %t218 = load i64, ptr %l93, !tbaa !24
  store i64 %t218, ptr %l91, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i64 -1, ptr %l91, !tbaa !24
  br label %bb53
bb53:
  %t219 = load i64, ptr %l91, !tbaa !24
  store i64 %t219, ptr %l18, !tbaa !24
  %t220 = load i64, ptr %l18, !tbaa !24
  store i64 %t220, ptr %l95, !tbaa !24
  %t221 = load i64, ptr %l95, !tbaa !24
  %t222 = icmp sge i64 %t221, 0
  store i1 %t222, ptr %l96, !tbaa !21
  %t223 = load i1, ptr %l96, !tbaa !21
  br i1 %t223, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t224 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t224, ptr %l97, !tbaa !27
  %t225 = load i64, ptr %l18, !tbaa !24
  store i64 %t225, ptr %l98, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l99, !tbaa !24
  %t228 = icmp sge i64 0, 0
  store i1 %t228, ptr %l100, !tbaa !21
  %t229 = load i1, ptr %l100, !tbaa !21
  br i1 %t229, label %bb56, label %bb57
bb55:
  br label %bb62
bb56:
  %t230 = load i64, ptr %l98, !tbaa !24
  %t231 = icmp sle i64 0, %t230
  store i1 %t231, ptr %l101, !tbaa !21
  %t232 = load i1, ptr %l101, !tbaa !21
  br i1 %t232, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb58:
  %t233 = load i64, ptr %l98, !tbaa !24
  %t234 = load i64, ptr %l99, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  store i1 %t235, ptr %l102, !tbaa !21
  %t236 = load i1, ptr %l102, !tbaa !21
  br i1 %t236, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb60:
  %t237 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l98, !tbaa !24
  %t240 = getelementptr i8, ptr %t238, i64 0
  %t241 = sub i64 %t239, 0
  %t242 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  store { i64, ptr } %t243, ptr %l103, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t244, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb62:
  %t245 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t245, ptr %l104, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t246, { i64, ptr } { i64 3, ptr @.d31 })
  store i1 %t247, ptr %l105
  br label %bb63
bb63:
  %t248 = load i1, ptr %l105, !tbaa !21
  %t249 = xor i1 %t248, true
  store i1 %t249, ptr %l106, !tbaa !21
  %t250 = load i1, ptr %l106, !tbaa !21
  br i1 %t250, label %bb64, label %bb65
bb64:
  %t251 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t251, ptr %l108, !tbaa !27
  %t252 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t252, ptr %l19, !tbaa !27
  %t253 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eArchs, !tbaa !27
  store { i64, ptr } %t253, ptr %l109, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t254, ptr %l110, !tbaa !27
  %t255 = load ptr, ptr @__olang_prog_scope
  %t256 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t258 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t255, ptr %s0, { i64, ptr } %t256, { i64, ptr } %t257)
  store i1 %t258, ptr %l111
  br label %bb66
bb65:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb67
bb66:
  %t259 = load i1, ptr %l111, !tbaa !21
  %t260 = xor i1 %t259, true
  store i1 %t260, ptr %l112, !tbaa !21
  %t261 = load i1, ptr %l112, !tbaa !21
  store i1 %t261, ptr %l107, !tbaa !21
  br label %bb67
bb67:
  %t262 = load i1, ptr %l107, !tbaa !21
  br i1 %t262, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t263 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t263, ptr %l113, !tbaa !27
  %t264 = load i64, ptr %l8, !tbaa !24
  store i64 %t264, ptr %l114, !tbaa !24
  %t265 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t266 = load i64, ptr %l114, !tbaa !24
  %t267 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s11, { i64, ptr } %t265, i64 %t266, { i64, ptr } { i64 53, ptr @.d32 })
  store i32 %t267, ptr %l115
  %t268 = icmp ne i32 %t267, 0
  br i1 %t268, label %bb71, label %ok.269
ok.269:
  br label %bb70
bb69:
  br label %bb73
bb70:
  br label %bb72
bb71:
  %t270 = load i32, ptr %l115, !tbaa !23
  %t271 = lshr i32 %t270, 16
  %t272 = and i32 %t270, 65535
  %t273 = icmp eq i32 %t271, 1
  %t274 = select i1 %t273, i32 1, i32 0
  %t275 = icmp eq i32 %t270, 0
  %t276 = shl i32 %t274, 16
  %t277 = or i32 %t276, %t272
  %t278 = select i1 %t275, i32 0, i32 %t277
  store i32 %t278, ptr %l116, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t279 = load i32, ptr %l116, !tbaa !23
  %t280 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t279, 0
  store { i32, { i64, ptr } } %t280, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t281 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t281, ptr %l117, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t283 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t282, { i64, ptr } { i64 3, ptr @.d33 })
  store i1 %t283, ptr %l118
  br label %bb74
bb74:
  %t284 = load i1, ptr %l118, !tbaa !21
  br i1 %t284, label %bb75, label %bb76
bb75:
  %t285 = load i1, ptr %l2, !tbaa !21
  store i1 %t285, ptr %l120, !tbaa !21
  %t286 = load i1, ptr %l120, !tbaa !21
  store i1 %t286, ptr %l119, !tbaa !21
  br label %bb78
bb76:
  %t287 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t287, ptr %l121, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t288, ptr %l122, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t291 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t289, { i64, ptr } %t290)
  store i1 %t291, ptr %l123
  br label %bb77
bb77:
  %t292 = load i1, ptr %l123, !tbaa !21
  store i1 %t292, ptr %l119, !tbaa !21
  br label %bb78
bb78:
  %t293 = load i1, ptr %l119, !tbaa !21
  store i1 %t293, ptr %l20, !tbaa !21
  %t294 = load i1, ptr %l20, !tbaa !21
  store i1 %t294, ptr %l124, !tbaa !21
  %t295 = load i1, ptr %l17, !tbaa !21
  store i1 %t295, ptr %l125, !tbaa !21
  %t296 = load i1, ptr %l124, !tbaa !21
  %t297 = load i1, ptr %l125, !tbaa !21
  %t298 = icmp ne i1 %t296, %t297
  store i1 %t298, ptr %l126, !tbaa !21
  %t299 = load i1, ptr %l126, !tbaa !21
  store i1 %t299, ptr %l11, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t300 = load i64, ptr %l8, !tbaa !24
  store i64 %t300, ptr %l127, !tbaa !24
  %t301 = load i64, ptr %l127, !tbaa !24
  store i64 %t301, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb79:
  %t302 = load i64, ptr %l15, !tbaa !24
  store i64 %t302, ptr %l128, !tbaa !24
  %t303 = load i64, ptr %l128, !tbaa !24
  %t304 = icmp eq i64 %t303, 1
  store i1 %t304, ptr %l129, !tbaa !21
  %t305 = load i1, ptr %l129, !tbaa !21
  br i1 %t305, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t306 = load i1, ptr %l9, !tbaa !21
  store i1 %t306, ptr %l130, !tbaa !21
  %t307 = load i1, ptr %l130, !tbaa !21
  %t308 = xor i1 %t307, true
  store i1 %t308, ptr %l131, !tbaa !21
  %t309 = load i1, ptr %l131, !tbaa !21
  br i1 %t309, label %bb82, label %bb83
bb81:
  br label %bb91
bb82:
  store i1 true, ptr %l132, !tbaa !21
  br label %bb84
bb83:
  %t310 = load i1, ptr %l10, !tbaa !21
  store i1 %t310, ptr %l133, !tbaa !21
  %t311 = load i1, ptr %l133, !tbaa !21
  store i1 %t311, ptr %l132, !tbaa !21
  br label %bb84
bb84:
  %t312 = load i1, ptr %l132, !tbaa !21
  br i1 %t312, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t313 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t313, ptr %l134, !tbaa !27
  %t314 = load i64, ptr %l8, !tbaa !24
  store i64 %t314, ptr %l135, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t316 = load i64, ptr %l135, !tbaa !24
  %t317 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s13, { i64, ptr } %t315, i64 %t316, { i64, ptr } { i64 30, ptr @.d34 })
  store i32 %t317, ptr %l136
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb88, label %ok.319
ok.319:
  br label %bb87
bb86:
  br label %bb90
bb87:
  br label %bb89
bb88:
  %t320 = load i32, ptr %l136, !tbaa !23
  %t321 = lshr i32 %t320, 16
  %t322 = and i32 %t320, 65535
  %t323 = icmp eq i32 %t321, 1
  %t324 = select i1 %t323, i32 1, i32 0
  %t325 = icmp eq i32 %t320, 0
  %t326 = shl i32 %t324, 16
  %t327 = or i32 %t326, %t322
  %t328 = select i1 %t325, i32 0, i32 %t327
  store i32 %t328, ptr %l137, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t329 = load i32, ptr %l137, !tbaa !23
  %t330 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t329, 0
  store { i32, { i64, ptr } } %t330, ptr %rv
  br label %ret
bb89:
  call void @__olang_scope_close(ptr %s13)
  br label %bb90
bb90:
  %t331 = load i1, ptr %l11, !tbaa !21
  store i1 %t331, ptr %l138, !tbaa !21
  %t332 = load i1, ptr %l138, !tbaa !21
  %t333 = xor i1 %t332, true
  store i1 %t333, ptr %l139, !tbaa !21
  %t334 = load i1, ptr %l139, !tbaa !21
  store i1 %t334, ptr %l11, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb91:
  %t335 = load i64, ptr %l15, !tbaa !24
  store i64 %t335, ptr %l140, !tbaa !24
  %t336 = load i64, ptr %l140, !tbaa !24
  %t337 = icmp eq i64 %t336, 2
  store i1 %t337, ptr %l141, !tbaa !21
  %t338 = load i1, ptr %l141, !tbaa !21
  br i1 %t338, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s14
  %t339 = load i1, ptr %l9, !tbaa !21
  store i1 %t339, ptr %l142, !tbaa !21
  %t340 = load i1, ptr %l142, !tbaa !21
  %t341 = xor i1 %t340, true
  store i1 %t341, ptr %l143, !tbaa !21
  %t342 = load i1, ptr %l143, !tbaa !21
  br i1 %t342, label %bb94, label %bb95
bb93:
  br label %bb100
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  %t343 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t343, ptr %l144, !tbaa !27
  %t344 = load i64, ptr %l8, !tbaa !24
  store i64 %t344, ptr %l145, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t346 = load i64, ptr %l145, !tbaa !24
  %t347 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s15, { i64, ptr } %t345, i64 %t346, { i64, ptr } { i64 29, ptr @.d35 })
  store i32 %t347, ptr %l146
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb97, label %ok.349
ok.349:
  br label %bb96
bb95:
  br label %bb99
bb96:
  br label %bb98
bb97:
  %t350 = load i32, ptr %l146, !tbaa !23
  %t351 = lshr i32 %t350, 16
  %t352 = and i32 %t350, 65535
  %t353 = icmp eq i32 %t351, 1
  %t354 = select i1 %t353, i32 1, i32 0
  %t355 = icmp eq i32 %t350, 0
  %t356 = shl i32 %t354, 16
  %t357 = or i32 %t356, %t352
  %t358 = select i1 %t355, i32 0, i32 %t357
  store i32 %t358, ptr %l147, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t359 = load i32, ptr %l147, !tbaa !23
  %t360 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t359, 0
  store { i32, { i64, ptr } } %t360, ptr %rv
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb99
bb99:
  store i1 false, ptr %l9, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb100:
  %t361 = load i1, ptr %l11, !tbaa !21
  store i1 %t361, ptr %l148, !tbaa !21
  %t362 = load i1, ptr %l148, !tbaa !21
  %t363 = xor i1 %t362, true
  store i1 %t363, ptr %l149, !tbaa !21
  %t364 = load i1, ptr %l149, !tbaa !21
  br i1 %t364, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s16
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb102:
  br label %bb103
bb103:
  %t365 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t365, ptr %l150, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t367 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t366)
  store { i64, ptr } %t367, ptr %l151
  br label %bb104
bb104:
  %t368 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t369 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t368, { i64, ptr } { i64 1, ptr @.d36 })
  store i1 %t369, ptr %l152
  br label %bb105
bb105:
  %t370 = load i1, ptr %l152, !tbaa !21
  br i1 %t370, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l7, ptr %l153, !tbaa !29
  %t371 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t371, ptr %l154, !tbaa !27
  %t372 = load ptr, ptr %l153, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l154, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t372, { i64, ptr } %t373)
  br label %bb108
bb107:
  br label %bb110
bb108:
  store ptr %l7, ptr %l155, !tbaa !29
  %t374 = load ptr, ptr %l155, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t374, i8 10)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb110:
  %t375 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t375, ptr %l156, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t376, ptr %l21, !tbaa !27
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s18
  %t377 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t377, ptr %l158, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t379 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t378, { i64, ptr } { i64 2, ptr @.d37 })
  %t380 = extractvalue { i32, i64 } %t379, 1
  %t381 = extractvalue { i32, i64 } %t379, 0
  store i32 %t381, ptr %l160
  %t382 = icmp ne i32 %t381, 0
  br i1 %t382, label %bb113, label %ok.383
ok.383:
  store i64 %t380, ptr %l159
  br label %bb112
bb112:
  %t384 = load i64, ptr %l159, !tbaa !24
  store i64 %t384, ptr %l157, !tbaa !24
  br label %bb115
bb113:
  br label %bb114
bb114:
  store i64 -1, ptr %l157, !tbaa !24
  br label %bb115
bb115:
  %t385 = load i64, ptr %l157, !tbaa !24
  store i64 %t385, ptr %l22, !tbaa !24
  %t386 = load i64, ptr %l22, !tbaa !24
  store i64 %t386, ptr %l161, !tbaa !24
  %t387 = load i64, ptr %l161, !tbaa !24
  %t388 = icmp slt i64 %t387, 0
  store i1 %t388, ptr %l162, !tbaa !21
  %t389 = load i1, ptr %l162, !tbaa !21
  br i1 %t389, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s19
  store ptr %l7, ptr %l163, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t390, ptr %l164, !tbaa !27
  %t391 = load ptr, ptr %l163, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l164, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t391, { i64, ptr } %t392)
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s18)
  br label %bb166
bb119:
  store ptr %l7, ptr %l165, !tbaa !29
  %t393 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t393, ptr %l166, !tbaa !27
  %t394 = load i64, ptr %l22, !tbaa !24
  store i64 %t394, ptr %l167, !tbaa !24
  %t395 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 0
  store i64 %t396, ptr %l168, !tbaa !24
  %t397 = icmp sge i64 0, 0
  store i1 %t397, ptr %l169, !tbaa !21
  %t398 = load i1, ptr %l169, !tbaa !21
  br i1 %t398, label %bb120, label %bb121
bb120:
  %t399 = load i64, ptr %l167, !tbaa !24
  %t400 = icmp sle i64 0, %t399
  store i1 %t400, ptr %l170, !tbaa !21
  %t401 = load i1, ptr %l170, !tbaa !21
  br i1 %t401, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb122:
  %t402 = load i64, ptr %l167, !tbaa !24
  %t403 = load i64, ptr %l168, !tbaa !24
  %t404 = icmp sle i64 %t402, %t403
  store i1 %t404, ptr %l171, !tbaa !21
  %t405 = load i1, ptr %l171, !tbaa !21
  br i1 %t405, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb124:
  %t406 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = load i64, ptr %l167, !tbaa !24
  %t409 = getelementptr i8, ptr %t407, i64 0
  %t410 = sub i64 %t408, 0
  %t411 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t409, 1
  store { i64, ptr } %t412, ptr %l172, !tbaa !27
  %t413 = load ptr, ptr %l165, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l172, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t413, { i64, ptr } %t414)
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb126:
  %t415 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t415, ptr %l173, !tbaa !27
  %t416 = load i64, ptr %l22, !tbaa !24
  store i64 %t416, ptr %l174, !tbaa !24
  %t417 = load i64, ptr %l174, !tbaa !24
  %t418 = add i64 %t417, 2
  store i64 %t418, ptr %l175, !tbaa !24
  %t419 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t419, ptr %l176, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t420, ptr %l177, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t421, 0
  store i64 %t422, ptr %l178, !tbaa !24
  %t423 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t423, 0
  store i64 %t424, ptr %l179, !tbaa !24
  %t425 = load i64, ptr %l175, !tbaa !24
  %t426 = icmp sge i64 %t425, 0
  store i1 %t426, ptr %l180, !tbaa !21
  %t427 = load i1, ptr %l180, !tbaa !21
  br i1 %t427, label %bb127, label %bb128
bb127:
  %t428 = load i64, ptr %l175, !tbaa !24
  %t429 = load i64, ptr %l178, !tbaa !24
  %t430 = icmp sle i64 %t428, %t429
  store i1 %t430, ptr %l181, !tbaa !21
  %t431 = load i1, ptr %l181, !tbaa !21
  br i1 %t431, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb129:
  %t432 = load i64, ptr %l178, !tbaa !24
  %t433 = load i64, ptr %l179, !tbaa !24
  %t434 = icmp sle i64 %t432, %t433
  store i1 %t434, ptr %l182, !tbaa !21
  %t435 = load i1, ptr %l182, !tbaa !21
  br i1 %t435, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb131:
  %t436 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l175, !tbaa !24
  %t439 = load i64, ptr %l178, !tbaa !24
  %t440 = getelementptr i8, ptr %t437, i64 %t438
  %t441 = sub i64 %t439, %t438
  %t442 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t440, 1
  store { i64, ptr } %t443, ptr %l183, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t444, ptr %l23, !tbaa !27
  %t445 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t445, ptr %l185, !tbaa !27
  %t446 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t447 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t446, { i64, ptr } { i64 2, ptr @.d40 })
  %t448 = extractvalue { i32, i64 } %t447, 1
  %t449 = extractvalue { i32, i64 } %t447, 0
  store i32 %t449, ptr %l187
  %t450 = icmp ne i32 %t449, 0
  br i1 %t450, label %bb134, label %ok.451
ok.451:
  store i64 %t448, ptr %l186
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb133:
  %t452 = load i64, ptr %l186, !tbaa !24
  store i64 %t452, ptr %l184, !tbaa !24
  br label %bb136
bb134:
  br label %bb135
bb135:
  store i64 -1, ptr %l184, !tbaa !24
  br label %bb136
bb136:
  %t453 = load i64, ptr %l184, !tbaa !24
  store i64 %t453, ptr %l24, !tbaa !24
  %t454 = load i64, ptr %l24, !tbaa !24
  store i64 %t454, ptr %l188, !tbaa !24
  %t455 = load i64, ptr %l188, !tbaa !24
  %t456 = icmp slt i64 %t455, 0
  store i1 %t456, ptr %l189, !tbaa !21
  %t457 = load i1, ptr %l189, !tbaa !21
  br i1 %t457, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s20
  %t458 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t458, ptr %l190, !tbaa !27
  %t459 = load i64, ptr %l8, !tbaa !24
  store i64 %t459, ptr %l191, !tbaa !24
  %t460 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t461 = load i64, ptr %l191, !tbaa !24
  %t462 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s20, { i64, ptr } %t460, i64 %t461, { i64, ptr } { i64 31, ptr @.d41 })
  store i32 %t462, ptr %l192
  %t463 = icmp ne i32 %t462, 0
  br i1 %t463, label %bb140, label %ok.464
ok.464:
  br label %bb139
bb138:
  br label %bb142
bb139:
  br label %bb141
bb140:
  %t465 = load i32, ptr %l192, !tbaa !23
  %t466 = lshr i32 %t465, 16
  %t467 = and i32 %t465, 65535
  %t468 = icmp eq i32 %t466, 1
  %t469 = select i1 %t468, i32 1, i32 0
  %t470 = icmp eq i32 %t465, 0
  %t471 = shl i32 %t469, 16
  %t472 = or i32 %t471, %t467
  %t473 = select i1 %t470, i32 0, i32 %t472
  store i32 %t473, ptr %l193, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t474 = load i32, ptr %l193, !tbaa !23
  %t475 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t474, 0
  store { i32, { i64, ptr } } %t475, ptr %rv
  br label %ret
bb141:
  call void @__olang_scope_close(ptr %s20)
  br label %bb142
bb142:
  %t476 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t476, ptr %l195, !tbaa !27
  %t477 = load i64, ptr %l24, !tbaa !24
  store i64 %t477, ptr %l196, !tbaa !24
  %t478 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 0
  store i64 %t479, ptr %l197, !tbaa !24
  %t480 = icmp sge i64 0, 0
  store i1 %t480, ptr %l198, !tbaa !21
  %t481 = load i1, ptr %l198, !tbaa !21
  br i1 %t481, label %bb143, label %bb144
bb143:
  %t482 = load i64, ptr %l196, !tbaa !24
  %t483 = icmp sle i64 0, %t482
  store i1 %t483, ptr %l199, !tbaa !21
  %t484 = load i1, ptr %l199, !tbaa !21
  br i1 %t484, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb145:
  %t485 = load i64, ptr %l196, !tbaa !24
  %t486 = load i64, ptr %l197, !tbaa !24
  %t487 = icmp sle i64 %t485, %t486
  store i1 %t487, ptr %l200, !tbaa !21
  %t488 = load i1, ptr %l200, !tbaa !21
  br i1 %t488, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb147:
  %t489 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t490 = load ptr, ptr %t489, !tbaa !27
  %t491 = load i64, ptr %l196, !tbaa !24
  %t492 = getelementptr i8, ptr %t490, i64 0
  %t493 = sub i64 %t491, 0
  %t494 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t495 = insertvalue { i64, ptr } %t494, ptr %t492, 1
  store { i64, ptr } %t495, ptr %l201, !tbaa !27
  %t496 = load i64, ptr %l6, !tbaa !24
  store i64 %t496, ptr %l202, !tbaa !24
  %t497 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t498 = load i64, ptr %l202, !tbaa !24
  %t499 = call { i32, i64 } @compiler_2fruntime_2efact(ptr %s0, { i64, ptr } %t497, i64 %t498)
  %t500 = extractvalue { i32, i64 } %t499, 1
  %t501 = extractvalue { i32, i64 } %t499, 0
  store i32 %t501, ptr %l204
  %t502 = icmp ne i32 %t501, 0
  br i1 %t502, label %bb150, label %ok.503
ok.503:
  store i64 %t500, ptr %l203
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb149:
  %t504 = load i64, ptr %l203, !tbaa !24
  store i64 %t504, ptr %l194, !tbaa !24
  br label %bb157
bb150:
  %t505 = load i32, ptr %l204, !tbaa !23
  %t506 = ashr i32 %t505, 16
  store i32 %t506, ptr %l205, !tbaa !23
  %t507 = load i32, ptr %l205, !tbaa !23
  %t508 = icmp eq i32 %t507, 1
  store i1 %t508, ptr %l206, !tbaa !21
  %t509 = load i1, ptr %l206, !tbaa !21
  br i1 %t509, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  %t510 = load i32, ptr %l204, !tbaa !23
  %t511 = lshr i32 %t510, 16
  %t512 = and i32 %t510, 65535
  %t513 = icmp eq i32 %t511, 1
  %t514 = select i1 %t513, i32 1, i32 0
  %t515 = icmp eq i32 %t510, 0
  %t516 = shl i32 %t514, 16
  %t517 = or i32 %t516, %t512
  %t518 = select i1 %t515, i32 0, i32 %t517
  store i32 %t518, ptr %l207, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t519 = load i32, ptr %l207, !tbaa !23
  %t520 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t519, 0
  store { i32, { i64, ptr } } %t520, ptr %rv
  br label %ret
bb153:
  store %olang.scope zeroinitializer, ptr %s21
  %t521 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t521, ptr %l208, !tbaa !27
  %t522 = load i64, ptr %l8, !tbaa !24
  store i64 %t522, ptr %l209, !tbaa !24
  %t523 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t524 = load i64, ptr %l209, !tbaa !24
  %t525 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s21, { i64, ptr } %t523, i64 %t524, { i64, ptr } { i64 42, ptr @.d43 })
  store i32 %t525, ptr %l210
  %t526 = icmp ne i32 %t525, 0
  br i1 %t526, label %bb155, label %ok.527
ok.527:
  br label %bb154
bb154:
  br label %bb156
bb155:
  %t528 = load i32, ptr %l210, !tbaa !23
  %t529 = lshr i32 %t528, 16
  %t530 = and i32 %t528, 65535
  %t531 = icmp eq i32 %t529, 1
  %t532 = select i1 %t531, i32 1, i32 0
  %t533 = icmp eq i32 %t528, 0
  %t534 = shl i32 %t532, 16
  %t535 = or i32 %t534, %t530
  %t536 = select i1 %t533, i32 0, i32 %t535
  store i32 %t536, ptr %l211, !tbaa !23
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t537 = load i32, ptr %l211, !tbaa !23
  %t538 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t537, 0
  store { i32, { i64, ptr } } %t538, ptr %rv
  br label %ret
bb156:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb157:
  %t539 = load i64, ptr %l194, !tbaa !24
  store i64 %t539, ptr %l25, !tbaa !24
  store ptr %l7, ptr %l212, !tbaa !29
  %t540 = load i64, ptr %l25, !tbaa !24
  store i64 %t540, ptr %l213, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s22
  store ptr %s22room, ptr %s22
  %t541 = load i64, ptr %l213, !tbaa !24
  %t542 = call ptr @__olang_sb_room(ptr %s22, i64 24)
  %t543 = call i64 @__olang_fmt_i64(ptr %t542, i64 %t541)
  call void @__olang_sb_add(ptr %s22, i64 %t543)
  %t544 = load ptr, ptr %s22
  %t545 = getelementptr %olang.builder, ptr %s22, i32 0, i32 1
  %t546 = load i64, ptr %t545
  %t547 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t546)
  call void @llvm.memcpy.p0.p0.i64(ptr %t547, ptr %t544, i64 %t546, i1 false)
  %t548 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t549 = insertvalue { i64, ptr } %t548, ptr %t547, 1
  store { i64, ptr } %t549, ptr %l214, !tbaa !27
  call void @__olang_sb_done(ptr %s22)
  %t550 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t551 = extractvalue { i64, ptr } %t550, 0
  %t552 = extractvalue { i64, ptr } %t550, 1
  %t553 = mul i64 %t551, 1
  %t554 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t553)
  call void @llvm.memcpy.p0.p0.i64(ptr %t554, ptr %t552, i64 %t553, i1 false)
  %t555 = insertvalue { i64, ptr } undef, i64 %t551, 0
  %t556 = insertvalue { i64, ptr } %t555, ptr %t554, 1
  store { i64, ptr } %t556, ptr %l215, !tbaa !27
  %t557 = load ptr, ptr %l212, !tbaa !29
  %t558 = load { i64, ptr }, ptr %l215, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t557, { i64, ptr } %t558)
  br label %bb158
bb158:
  %t559 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t559, ptr %l216, !tbaa !27
  %t560 = load i64, ptr %l24, !tbaa !24
  store i64 %t560, ptr %l217, !tbaa !24
  %t561 = load i64, ptr %l217, !tbaa !24
  %t562 = add i64 %t561, 2
  store i64 %t562, ptr %l218, !tbaa !24
  %t563 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t563, ptr %l219, !tbaa !27
  %t564 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t564, ptr %l220, !tbaa !27
  %t565 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t566 = extractvalue { i64, ptr } %t565, 0
  store i64 %t566, ptr %l221, !tbaa !24
  %t567 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 0
  store i64 %t568, ptr %l222, !tbaa !24
  %t569 = load i64, ptr %l218, !tbaa !24
  %t570 = icmp sge i64 %t569, 0
  store i1 %t570, ptr %l223, !tbaa !21
  %t571 = load i1, ptr %l223, !tbaa !21
  br i1 %t571, label %bb159, label %bb160
bb159:
  %t572 = load i64, ptr %l218, !tbaa !24
  %t573 = load i64, ptr %l221, !tbaa !24
  %t574 = icmp sle i64 %t572, %t573
  store i1 %t574, ptr %l224, !tbaa !21
  %t575 = load i1, ptr %l224, !tbaa !21
  br i1 %t575, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb161:
  %t576 = load i64, ptr %l221, !tbaa !24
  %t577 = load i64, ptr %l222, !tbaa !24
  %t578 = icmp sle i64 %t576, %t577
  store i1 %t578, ptr %l225, !tbaa !21
  %t579 = load i1, ptr %l225, !tbaa !21
  br i1 %t579, label %bb163, label %bb164
bb162:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb163:
  %t580 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = load i64, ptr %l218, !tbaa !24
  %t583 = load i64, ptr %l221, !tbaa !24
  %t584 = getelementptr i8, ptr %t581, i64 %t582
  %t585 = sub i64 %t583, %t582
  %t586 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t584, 1
  store { i64, ptr } %t587, ptr %l226, !tbaa !27
  %t588 = load { i64, ptr }, ptr %l226, !tbaa !27
  store { i64, ptr } %t588, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb165
bb164:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb165:
  br label %bb111
bb166:
  store ptr %l7, ptr %l227, !tbaa !29
  %t589 = load ptr, ptr %l227, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t589, i8 10)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb168:
  br label %bb17
bb169:
  call void @__olang_scope_close(ptr %s5)
  %t590 = load i1, ptr %l9, !tbaa !21
  store i1 %t590, ptr %l228, !tbaa !21
  %t591 = load i1, ptr %l228, !tbaa !21
  br i1 %t591, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s23
  %t592 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t592, ptr %l229, !tbaa !27
  %t593 = load i64, ptr %l12, !tbaa !24
  store i64 %t593, ptr %l230, !tbaa !24
  %t594 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t595 = load i64, ptr %l230, !tbaa !24
  %t596 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s23, { i64, ptr } %t594, i64 %t595, { i64, ptr } { i64 24, ptr @.d46 })
  store i32 %t596, ptr %l231
  %t597 = icmp ne i32 %t596, 0
  br i1 %t597, label %bb173, label %ok.598
ok.598:
  br label %bb172
bb171:
  br label %bb175
bb172:
  br label %bb174
bb173:
  %t599 = load i32, ptr %l231, !tbaa !23
  %t600 = lshr i32 %t599, 16
  %t601 = and i32 %t599, 65535
  %t602 = icmp eq i32 %t600, 1
  %t603 = select i1 %t602, i32 1, i32 0
  %t604 = icmp eq i32 %t599, 0
  %t605 = shl i32 %t603, 16
  %t606 = or i32 %t605, %t601
  %t607 = select i1 %t604, i32 0, i32 %t606
  store i32 %t607, ptr %l232, !tbaa !23
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t608 = load i32, ptr %l232, !tbaa !23
  %t609 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t608, 0
  store { i32, { i64, ptr } } %t609, ptr %rv
  br label %ret
bb174:
  call void @__olang_scope_close(ptr %s23)
  br label %bb175
bb175:
  store ptr %l7, ptr %l233, !tbaa !29
  %t610 = load ptr, ptr %l233, !tbaa !29
  %t611 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t610)
  store { i64, ptr } %t611, ptr %l234
  br label %bb176
bb176:
  %t612 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t612, ptr %l235, !tbaa !27
  %t613 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 0
  store i64 %t614, ptr %l236, !tbaa !24
  %t615 = load i64, ptr %l236, !tbaa !24
  %t616 = mul i64 %t615, 1
  %t617 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t616)
  %t618 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t619 = insertvalue { i64, ptr } %t618, ptr %t617, 1
  store { i64, ptr } %t619, ptr %l237, !tbaa !27
  %t620 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !27
  %t622 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !27
  %t624 = load i64, ptr %l236, !tbaa !24
  %t625 = mul i64 %t624, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t621, ptr %t623, i64 %t625, i1 false)
  %t626 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t626, ptr %l235, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t627 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t628 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t627, 1
  store { i32, { i64, ptr } } %t628, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fruntime_2eHeaderTbaa_2einit() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t1 = extractvalue { i64, ptr } { i64 66, ptr @.d47 }, 1
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t1, i64 %t2)
  %t3 = extractvalue { i64, ptr } { i64 50, ptr @.d48 }, 1
  %t4 = extractvalue { i64, ptr } { i64 50, ptr @.d48 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t3, i64 %t4)
  %t5 = load ptr, ptr %s1
  %t6 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t7 = load i64, ptr %t6
  %t8 = load ptr, ptr @__olang_prog_scope
  %t9 = call ptr @__olang_scope_alloc(ptr %t8, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t9, ptr %t5, i64 %t7, i1 false)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l0, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  %t14 = extractvalue { i64, ptr } %t12, 1
  %t15 = mul i64 %t13, 1
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = call ptr @__olang_scope_alloc(ptr %t16, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t14, i64 %t15, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l1, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load i1, ptr %l3, !tbaa !21
  store i1 %t2, ptr %l8, !tbaa !21
  %t3 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t4 = load i1, ptr %l8, !tbaa !21
  %t5 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t3, i1 %t4, i1 false)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l10, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l11, !tbaa !23
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t20, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t24, ptr %l13, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t25 = extractvalue { i64, ptr } { i64 17, ptr @.d49 }, 1
  %t26 = extractvalue { i64, ptr } { i64 17, ptr @.d49 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t25, i64 %t26)
  %t27 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  call void @__olang_sb_put(ptr %s1, ptr %t28, i64 %t29)
  %t30 = extractvalue { i64, ptr } { i64 3, ptr @.d50 }, 1
  %t31 = extractvalue { i64, ptr } { i64 3, ptr @.d50 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t30, i64 %t31)
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  call void @__olang_sb_put(ptr %s1, ptr %t33, i64 %t34)
  %t35 = load ptr, ptr %s1
  %t36 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t37 = load i64, ptr %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t35, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l14, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t41 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l15, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t48, ptr %l16, !tbaa !27
  %t49 = load i1, ptr %l4, !tbaa !21
  store i1 %t49, ptr %l17, !tbaa !21
  %t50 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t52 = load i1, ptr %l17, !tbaa !21
  %t53 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v3, ptr %v2, ptr %v3, { i64, ptr } %t50, { i64, ptr } %t51, i1 %t52)
  store { i64, ptr } %t53, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t55 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t54, 1
  store { i32, { i64, ptr } } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca i1
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l2, !tbaa !21
  store i1 %t1, ptr %l5, !tbaa !21
  %t2 = load i1, ptr %l5, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load i1, ptr %l1, !tbaa !21
  store i1 %t4, ptr %l8, !tbaa !21
  %t5 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t6 = load i1, ptr %l8, !tbaa !21
  %t7 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr @.d51 }, { i64, ptr } %t5, i1 %t6)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l9
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  store i32 %t21, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t22, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load i1, ptr %l1, !tbaa !21
  store i1 %t27, ptr %l14, !tbaa !21
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t29 = load i1, ptr %l14, !tbaa !21
  %t30 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr @.d52 }, { i64, ptr } %t28, i1 %t29)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l16
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb8, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l15
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  br label %bb9
bb8:
  %t36 = load i32, ptr %l16, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  store i32 %t44, ptr %l17, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i32, ptr %l17, !tbaa !23
  %t46 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t45, 0
  store { i32, { i64, ptr } } %t46, ptr %rv
  br label %ret
bb9:
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t47, ptr %lp3
  %t48 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t49 = load ptr, ptr %lp3
  store { i64, ptr } %t48, ptr %t49, !tbaa !27
  %t50 = load i1, ptr %l1, !tbaa !21
  store i1 %t50, ptr %l18, !tbaa !21
  %t51 = load i1, ptr %l18, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l19, !tbaa !21
  %t53 = load i1, ptr %l19, !tbaa !21
  br i1 %t53, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load ptr, ptr %lp3
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l20, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t56, 1
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l22, !tbaa !27
  %t59 = load i1, ptr %l1, !tbaa !21
  store i1 %t59, ptr %l23, !tbaa !21
  %t60 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t61 = load i1, ptr %l23, !tbaa !21
  %t62 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 6, ptr @.d53 }, { i64, ptr } %t60, i1 %t61)
  %t63 = extractvalue { i32, { i64, ptr } } %t62, 1
  %t64 = extractvalue { i32, { i64, ptr } } %t62, 0
  store i32 %t64, ptr %l25
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb14, label %ok.66
ok.66:
  store { i64, ptr } %t63, ptr %l24
  br label %bb13
bb13:
  %t67 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t67, ptr %l21, !tbaa !27
  br label %bb15
bb14:
  %t68 = load i32, ptr %l25, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  store i32 %t76, ptr %l26, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l26, !tbaa !23
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t77, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb15:
  %t79 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t79, ptr %l4, !tbaa !27
  %t80 = load ptr, ptr %lp3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l27, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t82, ptr %l28, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t83 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  call void @__olang_sb_put(ptr %s3, ptr %t84, i64 %t85)
  %t86 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t86, i64 %t87)
  %t88 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  call void @__olang_sb_put(ptr %s3, ptr %t89, i64 %t90)
  %t91 = load ptr, ptr %s3
  %t92 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t93 = load i64, ptr %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t91, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l29, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t98 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t97, 1
  store { i32, { i64, ptr } } %t98, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i32
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca { i64, ptr }
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %t4)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  store ptr %l4, ptr %l15, !tbaa !29
  %t7 = load ptr, ptr %l15, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %t7)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  store i32 %t15, ptr %l18, !tbaa !23
  %t16 = load i32, ptr %l18, !tbaa !23
  %t17 = icmp eq i32 %t16, 1
  store i1 %t17, ptr %l19, !tbaa !21
  %t18 = load i1, ptr %l19, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb86
bb9:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr @.d56 })
  store i1 %t22, ptr %l21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t24, ptr %l23, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t25, { i64, ptr } { i64 16, ptr @.d57 })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l25
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb14, label %ok.30
ok.30:
  store i64 %t27, ptr %l24
  br label %bb13
bb12:
  br label %bb36
bb13:
  %t31 = load i64, ptr %l24, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb16
bb16:
  %t32 = load i64, ptr %l22, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l26, !tbaa !24
  %t34 = load i64, ptr %l26, !tbaa !24
  %t35 = icmp sgt i64 %t34, 0
  store i1 %t35, ptr %l27, !tbaa !21
  %t36 = load i1, ptr %l27, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l30, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t38, { i64, ptr } { i64 1, ptr @.d58 })
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l32
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb20, label %ok.43
ok.43:
  store i64 %t40, ptr %l31
  br label %bb19
bb18:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb23
bb19:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t45 = load i64, ptr %l6, !tbaa !24
  store i64 %t45, ptr %l33, !tbaa !24
  %t46 = load i64, ptr %l29, !tbaa !24
  %t47 = load i64, ptr %l33, !tbaa !24
  %t48 = icmp eq i64 %t46, %t47
  store i1 %t48, ptr %l34, !tbaa !21
  %t49 = load i1, ptr %l34, !tbaa !21
  store i1 %t49, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l35, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l36, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 1, 0
  store i1 %t55, ptr %l39, !tbaa !21
  %t56 = load i1, ptr %l39, !tbaa !21
  br i1 %t56, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = icmp sle i64 1, %t57
  store i1 %t58, ptr %l40, !tbaa !21
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb28:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  store i1 %t62, ptr %l41, !tbaa !21
  %t63 = load i1, ptr %l41, !tbaa !21
  br i1 %t63, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb30:
  %t64 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = getelementptr i8, ptr %t65, i64 1
  %t68 = sub i64 %t66, 1
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  store { i64, ptr } %t70, ptr %l42, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t71 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t71, i64 %t72)
  %t73 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  call void @__olang_sb_put(ptr %s5, ptr %t74, i64 %t75)
  %t76 = extractvalue { i64, ptr } { i64 14, ptr @.d61 }, 1
  %t77 = extractvalue { i64, ptr } { i64 14, ptr @.d61 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t76, i64 %t77)
  %t78 = load ptr, ptr %s5
  %t79 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t80 = load i64, ptr %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t78, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  store { i64, ptr } %t83, ptr %l43, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  %t91 = load ptr, ptr %l35, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t91, { i64, ptr } %t92)
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb32:
  store ptr %l3, ptr %l45, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t93, ptr %l46, !tbaa !27
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t94, { i64, ptr } %t95)
  br label %bb33
bb33:
  store ptr %l3, ptr %l47, !tbaa !29
  %t96 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t96, { i64, ptr } { i64 9, ptr @.d62 })
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb36:
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t97, ptr %l48, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t98, { i64, ptr } { i64 7, ptr @.d63 })
  store i1 %t99, ptr %l49
  br label %bb37
bb37:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb38, label %bb39
bb38:
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t102, { i64, ptr } { i64 1, ptr @.d64 })
  store i1 %t103, ptr %l52
  br label %bb40
bb39:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb41
bb40:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb41
bb41:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t106, ptr %l54, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t108 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t107, { i64, ptr } { i64 6, ptr @.d65 })
  %t109 = extractvalue { i32, i64 } %t108, 1
  %t110 = extractvalue { i32, i64 } %t108, 0
  store i32 %t110, ptr %l56
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb45, label %ok.112
ok.112:
  store i64 %t109, ptr %l55
  br label %bb44
bb43:
  br label %bb82
bb44:
  %t113 = load i64, ptr %l55, !tbaa !24
  store i64 %t113, ptr %l53, !tbaa !24
  br label %bb47
bb45:
  br label %bb46
bb46:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb47
bb47:
  %t114 = load i64, ptr %l53, !tbaa !24
  store i64 %t114, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  store i64 %t115, ptr %l57, !tbaa !24
  %t116 = load i64, ptr %l57, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  store i1 %t117, ptr %l58, !tbaa !21
  %t118 = load i1, ptr %l58, !tbaa !21
  br i1 %t118, label %bb48, label %bb49
bb48:
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l60, !tbaa !24
  %t120 = load i64, ptr %l60, !tbaa !24
  store i64 %t120, ptr %l59, !tbaa !24
  br label %bb50
bb49:
  %t121 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t121, ptr %l61, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l62, !tbaa !24
  %t124 = load i64, ptr %l62, !tbaa !24
  %t125 = sub i64 %t124, 1
  store i64 %t125, ptr %l63, !tbaa !24
  %t126 = load i64, ptr %l63, !tbaa !24
  store i64 %t126, ptr %l59, !tbaa !24
  br label %bb50
bb50:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l8, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t128, ptr %l64, !tbaa !27
  %t129 = load i64, ptr %l8, !tbaa !24
  store i64 %t129, ptr %l65, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l66, !tbaa !24
  %t132 = icmp sge i64 0, 0
  store i1 %t132, ptr %l67, !tbaa !21
  %t133 = load i1, ptr %l67, !tbaa !21
  br i1 %t133, label %bb51, label %bb52
bb51:
  %t134 = load i64, ptr %l65, !tbaa !24
  %t135 = icmp sle i64 0, %t134
  store i1 %t135, ptr %l68, !tbaa !21
  %t136 = load i1, ptr %l68, !tbaa !21
  br i1 %t136, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb53:
  %t137 = load i64, ptr %l65, !tbaa !24
  %t138 = load i64, ptr %l66, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  store i1 %t139, ptr %l69, !tbaa !21
  %t140 = load i1, ptr %l69, !tbaa !21
  br i1 %t140, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb55:
  %t141 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = getelementptr i8, ptr %t142, i64 0
  %t145 = sub i64 %t143, 0
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  store { i64, ptr } %t147, ptr %l70, !tbaa !27
  %t148 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t148, ptr %l9, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t149, ptr %l71, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t150, ptr %l72, !tbaa !27
  store { i64, ptr } { i64 23, ptr @.d67 }, ptr %l73, !tbaa !27
  %t151 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t153 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t151, { i64, ptr } %t152)
  store i1 %t153, ptr %l74
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb57:
  %t154 = load i1, ptr %l74, !tbaa !21
  br i1 %t154, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb61
bb59:
  %t155 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t155, ptr %l76, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t156, ptr %l77, !tbaa !27
  store { i64, ptr } { i64 21, ptr @.d68 }, ptr %l78, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t159 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t157, { i64, ptr } %t158)
  store i1 %t159, ptr %l79
  br label %bb60
bb60:
  %t160 = load i1, ptr %l79, !tbaa !21
  store i1 %t160, ptr %l75, !tbaa !21
  br label %bb61
bb61:
  %t161 = load i1, ptr %l75, !tbaa !21
  store i1 %t161, ptr %l10, !tbaa !21
  store ptr %l3, ptr %l80, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t162, ptr %l81, !tbaa !27
  %t163 = load ptr, ptr %l80, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l81, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t163, { i64, ptr } %t164)
  br label %bb62
bb62:
  %t165 = load i64, ptr %l7, !tbaa !24
  store i64 %t165, ptr %l82, !tbaa !24
  %t166 = load i64, ptr %l82, !tbaa !24
  %t167 = icmp sge i64 %t166, 0
  store i1 %t167, ptr %l83, !tbaa !21
  %t168 = load i1, ptr %l83, !tbaa !21
  br i1 %t168, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l3, ptr %l84, !tbaa !29
  %t169 = load i1, ptr %l10, !tbaa !21
  store i1 %t169, ptr %l85, !tbaa !21
  %t170 = load i1, ptr %l85, !tbaa !21
  br i1 %t170, label %bb65, label %bb66
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l3, ptr %l98, !tbaa !29
  %t171 = load i1, ptr %l10, !tbaa !21
  store i1 %t171, ptr %l99, !tbaa !21
  %t172 = load i1, ptr %l99, !tbaa !21
  br i1 %t172, label %bb76, label %bb77
bb65:
  store { i64, ptr } { i64 3, ptr @.d69 }, ptr %l86, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 3, ptr @.d70 }, ptr %l86, !tbaa !27
  br label %bb67
bb67:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t173, { i64, ptr } %t174)
  br label %bb68
bb68:
  store ptr %l3, ptr %l87, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t175, ptr %l88, !tbaa !27
  %t176 = load i64, ptr %l7, !tbaa !24
  store i64 %t176, ptr %l89, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t177, ptr %l90, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t178, ptr %l91, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l92, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l93, !tbaa !24
  %t183 = load i64, ptr %l89, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  store i1 %t184, ptr %l94, !tbaa !21
  %t185 = load i1, ptr %l94, !tbaa !21
  br i1 %t185, label %bb69, label %bb70
bb69:
  %t186 = load i64, ptr %l89, !tbaa !24
  %t187 = load i64, ptr %l92, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  store i1 %t188, ptr %l95, !tbaa !21
  %t189 = load i1, ptr %l95, !tbaa !21
  br i1 %t189, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb71:
  %t190 = load i64, ptr %l92, !tbaa !24
  %t191 = load i64, ptr %l93, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  store i1 %t192, ptr %l96, !tbaa !21
  %t193 = load i1, ptr %l96, !tbaa !21
  br i1 %t193, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb73:
  %t194 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l89, !tbaa !24
  %t197 = load i64, ptr %l92, !tbaa !24
  %t198 = getelementptr i8, ptr %t195, i64 %t196
  %t199 = sub i64 %t197, %t196
  %t200 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  store { i64, ptr } %t201, ptr %l97, !tbaa !27
  %t202 = load ptr, ptr %l87, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l97, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t202, { i64, ptr } %t203)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb76:
  store { i64, ptr } { i64 4, ptr @.d72 }, ptr %l100, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 4, ptr @.d73 }, ptr %l100, !tbaa !27
  br label %bb78
bb78:
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t204, { i64, ptr } %t205)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s8)
  br label %bb80
bb80:
  store ptr %l3, ptr %l101, !tbaa !29
  %t206 = load ptr, ptr %l101, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t206, i8 10)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb82:
  store ptr %l3, ptr %l102, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t207, ptr %l103, !tbaa !27
  %t208 = load ptr, ptr %l102, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l103, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t208, { i64, ptr } %t209)
  br label %bb83
bb83:
  store ptr %l3, ptr %l104, !tbaa !29
  %t210 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t210, i8 10)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb85:
  br label %bb3
bb86:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l3, ptr %l105, !tbaa !29
  %t211 = load i1, ptr %l2, !tbaa !21
  store i1 %t211, ptr %l106, !tbaa !21
  %t212 = load i1, ptr %l106, !tbaa !21
  br i1 %t212, label %bb87, label %bb88
bb87:
  store { i64, ptr } { i64 16, ptr @.d74 }, ptr %l107, !tbaa !27
  br label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr @.d75 }, ptr %l107, !tbaa !27
  br label %bb89
bb89:
  %t213 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t213, ptr %l108, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t214 = extractvalue { i64, ptr } { i64 41, ptr @.d76 }, 1
  %t215 = extractvalue { i64, ptr } { i64 41, ptr @.d76 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t214, i64 %t215)
  %t216 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  call void @__olang_sb_put(ptr %s9, ptr %t217, i64 %t218)
  %t219 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  call void @__olang_sb_put(ptr %s9, ptr %t220, i64 %t221)
  %t222 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 1
  %t223 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 0
  call void @__olang_sb_put(ptr %s9, ptr %t222, i64 %t223)
  %t224 = load ptr, ptr %s9
  %t225 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t226 = load i64, ptr %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t224, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l109, !tbaa !27
  call void @__olang_sb_done(ptr %s9)
  %t230 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l110, !tbaa !27
  %t237 = load ptr, ptr %l105, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l110, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t237, { i64, ptr } %t238)
  br label %bb90
bb90:
  store ptr %l3, ptr %l111, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t239, ptr %l112, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t240 = extractvalue { i64, ptr } { i64 40, ptr @.d78 }, 1
  %t241 = extractvalue { i64, ptr } { i64 40, ptr @.d78 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t240, i64 %t241)
  %t242 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 1
  %t244 = extractvalue { i64, ptr } %t242, 0
  call void @__olang_sb_put(ptr %s10, ptr %t243, i64 %t244)
  %t245 = extractvalue { i64, ptr } { i64 3, ptr @.d79 }, 1
  %t246 = extractvalue { i64, ptr } { i64 3, ptr @.d79 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t245, i64 %t246)
  %t247 = load ptr, ptr %s10
  %t248 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t249 = load i64, ptr %t248
  %t250 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t249)
  call void @llvm.memcpy.p0.p0.i64(ptr %t250, ptr %t247, i64 %t249, i1 false)
  %t251 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  store { i64, ptr } %t252, ptr %l113, !tbaa !27
  call void @__olang_sb_done(ptr %s10)
  %t253 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  %t255 = extractvalue { i64, ptr } %t253, 1
  %t256 = mul i64 %t254, 1
  %t257 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t256)
  call void @llvm.memcpy.p0.p0.i64(ptr %t257, ptr %t255, i64 %t256, i1 false)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l114, !tbaa !27
  %t260 = load ptr, ptr %l111, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l114, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t260, { i64, ptr } %t261)
  br label %bb91
bb91:
  store ptr %l3, ptr %l115, !tbaa !29
  %t262 = load ptr, ptr %l115, !tbaa !29
  %t263 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t262)
  store { i64, ptr } %t263, ptr %l116
  br label %bb92
bb92:
  %t264 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t264, ptr %l117, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l118, !tbaa !24
  %t267 = load i64, ptr %l118, !tbaa !24
  %t268 = mul i64 %t267, 1
  %t269 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l119, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l118, !tbaa !24
  %t277 = mul i64 %t276, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t273, ptr %t275, i64 %t277, i1 false)
  %t278 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t278, ptr %l117, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t279 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t279, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fruntime_2earchRow(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eArchs, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i64, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l11, !tbaa !21
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l13, !tbaa !24
  %t12 = load i64, ptr %l13, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l14, !tbaa !21
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l2, !tbaa !24
  store i64 %t15, ptr %l16, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %l17, !tbaa !24
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l18, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l19, !tbaa !24
  %t21 = load i64, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l20, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l21, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l22, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l22, !tbaa !24
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l23, !tbaa !24
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l15, !tbaa !24
  store i64 %t31, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l12, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l5, !tbaa !24
  store i64 %t33, ptr %l24, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l26, !tbaa !21
  %t38 = load i1, ptr %l26, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l27, !tbaa !21
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l1, !tbaa !24
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  store i64 %t42, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %l30, !tbaa !24
  %t44 = load i64, ptr %l29, !tbaa !24
  %t45 = load i64, ptr %l30, !tbaa !24
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  %t52 = load i64, ptr %l33, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eArchs, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %t54, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l35, !tbaa !27
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t58, ptr %v0, { i64, ptr } %t59, { i64, ptr } %t60)
  store i1 %t61, ptr %l36
  br label %bb11
bb11:
  %t62 = load i1, ptr %l36, !tbaa !21
  br i1 %t62, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l37, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i64, ptr %l37, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t65 = load i64, ptr %l5, !tbaa !24
  store i64 %t65, ptr %l38, !tbaa !24
  %t66 = load i64, ptr %l38, !tbaa !24
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l39, !tbaa !24
  %t68 = load i64, ptr %l39, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb16:
  call void @__olang_scope_close(ptr %s1)
  store i64 0, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i64, ptr %l40, !tbaa !24
  store i64 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fruntime_2edeclare(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i8
  %l81 = alloca i8
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i8
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i8
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca i8
  %l91 = alloca i1
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i8
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca i8
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i8
  %l101 = alloca i1
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i8
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i8
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i8
  %l115 = alloca i1
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i8
  %l139 = alloca i1
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i1
  %l144 = alloca i1
  %l145 = alloca i1
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i8
  %l159 = alloca i1
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i1
  %l170 = alloca i1
  %l171 = alloca i1
  %l172 = alloca { i64, ptr }
  %l173 = alloca i64
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l176 = alloca i32
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i1
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca i1
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l194 = alloca i64
  %l195 = alloca i32
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i1
  %l201 = alloca i1
  %l202 = alloca i1
  %l203 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l207 = alloca i64
  %l208 = alloca i64
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca i1
  %l214 = alloca i1
  %l215 = alloca i1
  %l216 = alloca { i64, ptr }
  %l217 = alloca { i64, ptr }
  %l218 = alloca i1
  %l219 = alloca i64
  %l220 = alloca { i64, ptr }
  %l221 = alloca i64
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l225 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i1
  %l229 = alloca i1
  %l230 = alloca i1
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i64
  %l240 = alloca i64
  %l241 = alloca i1
  %l242 = alloca i1
  %l243 = alloca i1
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca i1
  %l247 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca i64
  %l252 = alloca i1
  %l253 = alloca i1
  %l254 = alloca i1
  %l255 = alloca { i64, ptr }
  %l256 = alloca i64
  %l257 = alloca { i64, ptr }
  %l258 = alloca i64
  %l259 = alloca i32
  %l260 = alloca { i64, ptr }
  %l261 = alloca i64
  %l262 = alloca i64
  %l263 = alloca i64
  %l264 = alloca { i64, ptr }
  %l265 = alloca i64
  %l266 = alloca i1
  %l267 = alloca i64
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca i64
  %l272 = alloca { i64, ptr }
  %l273 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca { i64, ptr }
  %l276 = alloca i64
  %l277 = alloca i64
  %l278 = alloca i64
  %l279 = alloca i1
  %l280 = alloca i1
  %l281 = alloca i1
  %l282 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l284 = alloca i64
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca i64
  %l288 = alloca i1
  %l289 = alloca i1
  %l290 = alloca i1
  %l291 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.builder
  %s21room = alloca [64 x i8], align 8
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.builder
  %s24room = alloca [64 x i8], align 8
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.builder
  %s26room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 8, ptr @.d80 })
  store i1 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i1, ptr %l18, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l20, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t6, { i64, ptr } { i64 1, ptr @.d81 })
  store i1 %t7, ptr %l21
  br label %bb4
bb4:
  %t8 = load i1, ptr %l21, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l23, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t10, ptr %l24, !tbaa !27
  store { i64, ptr } { i64 8, ptr @.d82 }, ptr %l25, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t13 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t11, { i64, ptr } %t12)
  store i1 %t13, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t14 = load i1, ptr %l26, !tbaa !21
  store i1 %t14, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t15 = load i1, ptr %l22, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb11:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l28, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 1, ptr @.d83 })
  store i1 %t19, ptr %l29
  br label %bb12
bb12:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb13, label %bb14
bb13:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t21, ptr %l31, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t22, ptr %l32, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d84 }, ptr %l33, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t25 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t24)
  store i1 %t25, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t26 = load i1, ptr %l34, !tbaa !21
  store i1 %t26, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t27 = load i1, ptr %l30, !tbaa !21
  store i1 %t27, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s1
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l35, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l36, !tbaa !27
  %t31 = load ptr, ptr %l35, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t31, { i64, ptr } %t32)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l37, !tbaa !29
  %t34 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t34, i8 10)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t35, ptr %l38, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t36, { i64, ptr } { i64 16, ptr @.d85 })
  store i1 %t37, ptr %l39
  br label %bb23
bb23:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l41, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t40, { i64, ptr } { i64 15, ptr @.d86 })
  store i1 %t41, ptr %l42
  br label %bb26
bb26:
  %t42 = load i1, ptr %l42, !tbaa !21
  store i1 %t42, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t43 = load i1, ptr %l40, !tbaa !21
  br i1 %t43, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l44, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t45, ptr %l45, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d87 }, ptr %l46, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t48 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t46, { i64, ptr } %t47)
  store i1 %t48, ptr %l47
  br label %bb30
bb30:
  %t49 = load i1, ptr %l47, !tbaa !21
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb35
bb33:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t51, ptr %l49, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t52, ptr %l50, !tbaa !27
  store { i64, ptr } { i64 11, ptr @.d88 }, ptr %l51, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t55 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t53, { i64, ptr } %t54)
  store i1 %t55, ptr %l52
  br label %bb34
bb34:
  %t56 = load i1, ptr %l52, !tbaa !21
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb35
bb35:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t58, ptr %l53, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 7, ptr @.d89 })
  store i1 %t60, ptr %l54
  br label %bb39
bb39:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t62, ptr %l56, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s3, { i64, ptr } %t63, { i64, ptr } { i64 1, ptr @.d90 })
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l58
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb43, label %ok.68
ok.68:
  store i64 %t65, ptr %l57
  br label %bb42
bb41:
  br label %bb148
bb42:
  %t69 = load i64, ptr %l57, !tbaa !24
  store i64 %t69, ptr %l55, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t70 = load i64, ptr %l55, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l59, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l60, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  store i64 %t73, ptr %l61, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l62, !tbaa !24
  %t76 = icmp sge i64 7, 0
  store i1 %t76, ptr %l63, !tbaa !21
  %t77 = load i1, ptr %l63, !tbaa !21
  br i1 %t77, label %bb46, label %bb47
bb46:
  %t78 = load i64, ptr %l61, !tbaa !24
  %t79 = icmp sle i64 7, %t78
  store i1 %t79, ptr %l64, !tbaa !21
  %t80 = load i1, ptr %l64, !tbaa !21
  br i1 %t80, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb48:
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = load i64, ptr %l62, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  store i1 %t83, ptr %l65, !tbaa !21
  %t84 = load i1, ptr %l65, !tbaa !21
  br i1 %t84, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb50:
  %t85 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 7
  %t89 = sub i64 %t87, 7
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  store { i64, ptr } %t91, ptr %l66, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t92 = extractvalue { i64, ptr } { i64 8, ptr @.d92 }, 1
  %t93 = extractvalue { i64, ptr } { i64 8, ptr @.d92 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t92, i64 %t93)
  %t94 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  call void @__olang_sb_put(ptr %s5, ptr %t95, i64 %t96)
  %t97 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t97, i64 %t98)
  %t99 = load ptr, ptr %s5
  %t100 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t99, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l67, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t105 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l68, !tbaa !27
  %t112 = load ptr, ptr %l59, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l68, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t112, { i64, ptr } %t113)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb52:
  store i64 0, ptr %l3, !tbaa !24
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l69, !tbaa !24
  %t115 = load i64, ptr %l69, !tbaa !24
  %t116 = add i64 %t115, 1
  store i64 %t116, ptr %l70, !tbaa !24
  %t117 = load i64, ptr %l70, !tbaa !24
  store i64 %t117, ptr %l4, !tbaa !24
  store i1 true, ptr %l5, !tbaa !21
  %t118 = load i64, ptr %l2, !tbaa !24
  store i64 %t118, ptr %l71, !tbaa !24
  %t119 = load i64, ptr %l71, !tbaa !24
  %t120 = add i64 %t119, 1
  store i64 %t120, ptr %l72, !tbaa !24
  %t121 = load i64, ptr %l72, !tbaa !24
  store i64 %t121, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load i64, ptr %l6, !tbaa !24
  store i64 %t122, ptr %l73, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t123, ptr %l74, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  store i64 %t125, ptr %l75, !tbaa !24
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = load i64, ptr %l75, !tbaa !24
  %t128 = icmp slt i64 %t126, %t127
  store i1 %t128, ptr %l76, !tbaa !21
  %t129 = load i1, ptr %l76, !tbaa !21
  %t130 = xor i1 %t129, true
  store i1 %t130, ptr %l77, !tbaa !21
  %t131 = load i1, ptr %l77, !tbaa !21
  br i1 %t131, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb129
bb55:
  br label %bb56
bb56:
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t132, ptr %l78, !tbaa !27
  %t133 = load i64, ptr %l6, !tbaa !24
  store i64 %t133, ptr %l79, !tbaa !24
  %t134 = load i64, ptr %l79, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i8, ptr %t136, i64 %t134
  %t138 = load i8, ptr %t137, !tbaa !32
  store i8 %t138, ptr %l80, !tbaa !22
  %t139 = load i8, ptr %l80, !tbaa !22
  store i8 %t139, ptr %l7, !tbaa !22
  %t140 = load i8, ptr %l7, !tbaa !22
  store i8 %t140, ptr %l81, !tbaa !22
  %t141 = load i8, ptr %l81, !tbaa !22
  %t142 = icmp eq i8 %t141, 40
  store i1 %t142, ptr %l82, !tbaa !21
  %t143 = load i1, ptr %l82, !tbaa !21
  br i1 %t143, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb59
bb58:
  %t144 = load i8, ptr %l7, !tbaa !22
  store i8 %t144, ptr %l84, !tbaa !22
  %t145 = load i8, ptr %l84, !tbaa !22
  %t146 = icmp eq i8 %t145, 91
  store i1 %t146, ptr %l85, !tbaa !21
  %t147 = load i1, ptr %l85, !tbaa !21
  store i1 %t147, ptr %l83, !tbaa !21
  br label %bb59
bb59:
  %t148 = load i1, ptr %l83, !tbaa !21
  br i1 %t148, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb62
bb61:
  %t149 = load i8, ptr %l7, !tbaa !22
  store i8 %t149, ptr %l87, !tbaa !22
  %t150 = load i8, ptr %l87, !tbaa !22
  %t151 = icmp eq i8 %t150, 123
  store i1 %t151, ptr %l88, !tbaa !21
  %t152 = load i1, ptr %l88, !tbaa !21
  store i1 %t152, ptr %l86, !tbaa !21
  br label %bb62
bb62:
  %t153 = load i1, ptr %l86, !tbaa !21
  br i1 %t153, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb65
bb64:
  %t154 = load i8, ptr %l7, !tbaa !22
  store i8 %t154, ptr %l90, !tbaa !22
  %t155 = load i8, ptr %l90, !tbaa !22
  %t156 = icmp eq i8 %t155, 60
  store i1 %t156, ptr %l91, !tbaa !21
  %t157 = load i1, ptr %l91, !tbaa !21
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb65
bb65:
  %t158 = load i1, ptr %l89, !tbaa !21
  br i1 %t158, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s7
  %t159 = load i64, ptr %l3, !tbaa !24
  store i64 %t159, ptr %l92, !tbaa !24
  %t160 = load i64, ptr %l92, !tbaa !24
  %t161 = add i64 %t160, 1
  store i64 %t161, ptr %l93, !tbaa !24
  %t162 = load i64, ptr %l93, !tbaa !24
  store i64 %t162, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb127
bb67:
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load i8, ptr %l7, !tbaa !22
  store i8 %t163, ptr %l94, !tbaa !22
  %t164 = load i8, ptr %l94, !tbaa !22
  %t165 = icmp eq i8 %t164, 93
  store i1 %t165, ptr %l95, !tbaa !21
  %t166 = load i1, ptr %l95, !tbaa !21
  br i1 %t166, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb70
bb69:
  %t167 = load i8, ptr %l7, !tbaa !22
  store i8 %t167, ptr %l97, !tbaa !22
  %t168 = load i8, ptr %l97, !tbaa !22
  %t169 = icmp eq i8 %t168, 125
  store i1 %t169, ptr %l98, !tbaa !21
  %t170 = load i1, ptr %l98, !tbaa !21
  store i1 %t170, ptr %l96, !tbaa !21
  br label %bb70
bb70:
  %t171 = load i1, ptr %l96, !tbaa !21
  br i1 %t171, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb73
bb72:
  %t172 = load i8, ptr %l7, !tbaa !22
  store i8 %t172, ptr %l100, !tbaa !22
  %t173 = load i8, ptr %l100, !tbaa !22
  %t174 = icmp eq i8 %t173, 62
  store i1 %t174, ptr %l101, !tbaa !21
  %t175 = load i1, ptr %l101, !tbaa !21
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb73
bb73:
  %t176 = load i1, ptr %l99, !tbaa !21
  br i1 %t176, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s9
  %t177 = load i64, ptr %l3, !tbaa !24
  store i64 %t177, ptr %l102, !tbaa !24
  %t178 = load i64, ptr %l102, !tbaa !24
  %t179 = sub i64 %t178, 1
  store i64 %t179, ptr %l103, !tbaa !24
  %t180 = load i64, ptr %l103, !tbaa !24
  store i64 %t180, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb126
bb75:
  store %olang.scope zeroinitializer, ptr %s10
  %t181 = load i8, ptr %l7, !tbaa !22
  store i8 %t181, ptr %l104, !tbaa !22
  %t182 = load i8, ptr %l104, !tbaa !22
  %t183 = icmp eq i8 %t182, 41
  store i1 %t183, ptr %l105, !tbaa !21
  %t184 = load i1, ptr %l105, !tbaa !21
  br i1 %t184, label %bb76, label %bb77
bb76:
  %t185 = load i64, ptr %l3, !tbaa !24
  store i64 %t185, ptr %l107, !tbaa !24
  %t186 = load i64, ptr %l107, !tbaa !24
  %t187 = icmp sgt i64 %t186, 0
  store i1 %t187, ptr %l108, !tbaa !21
  %t188 = load i1, ptr %l108, !tbaa !21
  store i1 %t188, ptr %l106, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb78
bb78:
  %t189 = load i1, ptr %l106, !tbaa !21
  br i1 %t189, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s11
  %t190 = load i64, ptr %l3, !tbaa !24
  store i64 %t190, ptr %l109, !tbaa !24
  %t191 = load i64, ptr %l109, !tbaa !24
  %t192 = sub i64 %t191, 1
  store i64 %t192, ptr %l110, !tbaa !24
  %t193 = load i64, ptr %l110, !tbaa !24
  store i64 %t193, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb125
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t194 = load i8, ptr %l7, !tbaa !22
  store i8 %t194, ptr %l111, !tbaa !22
  %t195 = load i8, ptr %l111, !tbaa !22
  %t196 = icmp eq i8 %t195, 44
  store i1 %t196, ptr %l112, !tbaa !21
  %t197 = load i1, ptr %l112, !tbaa !21
  br i1 %t197, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb83
bb82:
  %t198 = load i8, ptr %l7, !tbaa !22
  store i8 %t198, ptr %l114, !tbaa !22
  %t199 = load i8, ptr %l114, !tbaa !22
  %t200 = icmp eq i8 %t199, 41
  store i1 %t200, ptr %l115, !tbaa !21
  %t201 = load i1, ptr %l115, !tbaa !21
  store i1 %t201, ptr %l113, !tbaa !21
  br label %bb83
bb83:
  %t202 = load i1, ptr %l113, !tbaa !21
  br i1 %t202, label %bb84, label %bb85
bb84:
  %t203 = load i64, ptr %l3, !tbaa !24
  store i64 %t203, ptr %l117, !tbaa !24
  %t204 = load i64, ptr %l117, !tbaa !24
  %t205 = icmp eq i64 %t204, 0
  store i1 %t205, ptr %l118, !tbaa !21
  %t206 = load i1, ptr %l118, !tbaa !21
  store i1 %t206, ptr %l116, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb86
bb86:
  %t207 = load i1, ptr %l116, !tbaa !21
  br i1 %t207, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s13
  %t208 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t208, ptr %l119, !tbaa !27
  %t209 = load i64, ptr %l4, !tbaa !24
  store i64 %t209, ptr %l120, !tbaa !24
  %t210 = load i64, ptr %l6, !tbaa !24
  store i64 %t210, ptr %l121, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 0
  store i64 %t212, ptr %l122, !tbaa !24
  %t213 = load i64, ptr %l120, !tbaa !24
  %t214 = icmp sge i64 %t213, 0
  store i1 %t214, ptr %l123, !tbaa !21
  %t215 = load i1, ptr %l123, !tbaa !21
  br i1 %t215, label %bb89, label %bb90
bb88:
  br label %bb124
bb89:
  %t216 = load i64, ptr %l120, !tbaa !24
  %t217 = load i64, ptr %l121, !tbaa !24
  %t218 = icmp sle i64 %t216, %t217
  store i1 %t218, ptr %l124, !tbaa !21
  %t219 = load i1, ptr %l124, !tbaa !21
  br i1 %t219, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb91:
  %t220 = load i64, ptr %l121, !tbaa !24
  %t221 = load i64, ptr %l122, !tbaa !24
  %t222 = icmp sle i64 %t220, %t221
  store i1 %t222, ptr %l125, !tbaa !21
  %t223 = load i1, ptr %l125, !tbaa !21
  br i1 %t223, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb93:
  %t224 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = load i64, ptr %l120, !tbaa !24
  %t227 = load i64, ptr %l121, !tbaa !24
  %t228 = getelementptr i8, ptr %t225, i64 %t226
  %t229 = sub i64 %t227, %t226
  %t230 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l126, !tbaa !27
  %t232 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t233 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, { i64, ptr } %t232)
  store { i64, ptr } %t233, ptr %l127
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb95:
  %t234 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t234, ptr %l8, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t235, ptr %l129, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t237 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s13, { i64, ptr } %t236, { i64, ptr } { i64 1, ptr @.d95 })
  %t238 = extractvalue { i32, i64 } %t237, 1
  %t239 = extractvalue { i32, i64 } %t237, 0
  store i32 %t239, ptr %l131
  %t240 = icmp ne i32 %t239, 0
  br i1 %t240, label %bb97, label %ok.241
ok.241:
  store i64 %t238, ptr %l130
  br label %bb96
bb96:
  %t242 = load i64, ptr %l130, !tbaa !24
  store i64 %t242, ptr %l128, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  store i64 -1, ptr %l128, !tbaa !24
  br label %bb99
bb99:
  %t243 = load i64, ptr %l128, !tbaa !24
  store i64 %t243, ptr %l9, !tbaa !24
  %t244 = load i64, ptr %l9, !tbaa !24
  store i64 %t244, ptr %l132, !tbaa !24
  %t245 = load i64, ptr %l132, !tbaa !24
  %t246 = icmp sge i64 %t245, 0
  store i1 %t246, ptr %l133, !tbaa !21
  %t247 = load i1, ptr %l133, !tbaa !21
  br i1 %t247, label %bb100, label %bb101
bb100:
  %t248 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t248, ptr %l135, !tbaa !27
  %t249 = load i64, ptr %l9, !tbaa !24
  store i64 %t249, ptr %l136, !tbaa !24
  %t250 = load i64, ptr %l136, !tbaa !24
  %t251 = add i64 %t250, 1
  store i64 %t251, ptr %l137, !tbaa !24
  %t252 = load i64, ptr %l137, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr i8, ptr %t254, i64 %t252
  %t256 = load i8, ptr %t255, !tbaa !32
  store i8 %t256, ptr %l138, !tbaa !22
  %t257 = load i8, ptr %l138, !tbaa !22
  %t258 = icmp eq i8 %t257, 37
  store i1 %t258, ptr %l139, !tbaa !21
  %t259 = load i1, ptr %l139, !tbaa !21
  store i1 %t259, ptr %l134, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb102
bb102:
  %t260 = load i1, ptr %l134, !tbaa !21
  br i1 %t260, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s14
  %t261 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t261, ptr %l140, !tbaa !27
  %t262 = load i64, ptr %l9, !tbaa !24
  store i64 %t262, ptr %l141, !tbaa !24
  %t263 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t263, 0
  store i64 %t264, ptr %l142, !tbaa !24
  %t265 = icmp sge i64 0, 0
  store i1 %t265, ptr %l143, !tbaa !21
  %t266 = load i1, ptr %l143, !tbaa !21
  br i1 %t266, label %bb105, label %bb106
bb104:
  br label %bb112
bb105:
  %t267 = load i64, ptr %l141, !tbaa !24
  %t268 = icmp sle i64 0, %t267
  store i1 %t268, ptr %l144, !tbaa !21
  %t269 = load i1, ptr %l144, !tbaa !21
  br i1 %t269, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb107:
  %t270 = load i64, ptr %l141, !tbaa !24
  %t271 = load i64, ptr %l142, !tbaa !24
  %t272 = icmp sle i64 %t270, %t271
  store i1 %t272, ptr %l145, !tbaa !21
  %t273 = load i1, ptr %l145, !tbaa !21
  br i1 %t273, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb109:
  %t274 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l141, !tbaa !24
  %t277 = getelementptr i8, ptr %t275, i64 0
  %t278 = sub i64 %t276, 0
  %t279 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t280 = insertvalue { i64, ptr } %t279, ptr %t277, 1
  store { i64, ptr } %t280, ptr %l146, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t282 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t281)
  store { i64, ptr } %t282, ptr %l147
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb111:
  %t283 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t283, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb112
bb112:
  %t284 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t284, ptr %l148, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t285, 0
  store i64 %t286, ptr %l149, !tbaa !24
  %t287 = load i64, ptr %l149, !tbaa !24
  %t288 = icmp sgt i64 %t287, 0
  store i1 %t288, ptr %l150, !tbaa !21
  %t289 = load i1, ptr %l150, !tbaa !21
  br i1 %t289, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s15
  %t290 = load i1, ptr %l5, !tbaa !21
  store i1 %t290, ptr %l151, !tbaa !21
  %t291 = load i1, ptr %l151, !tbaa !21
  %t292 = xor i1 %t291, true
  store i1 %t292, ptr %l152, !tbaa !21
  %t293 = load i1, ptr %l152, !tbaa !21
  br i1 %t293, label %bb115, label %bb116
bb114:
  br label %bb120
bb115:
  store %olang.scope zeroinitializer, ptr %s16
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l153, !tbaa !29
  %t295 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s16, ptr %t295, { i64, ptr } { i64 2, ptr @.d97 })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb118:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l154, !tbaa !29
  %t297 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t297, ptr %l155, !tbaa !27
  %t298 = load ptr, ptr %l154, !tbaa !29
  %t299 = load { i64, ptr }, ptr %l155, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t298, { i64, ptr } %t299)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s15)
  br label %bb120
bb120:
  store i1 false, ptr %l5, !tbaa !21
  %t300 = load i64, ptr %l6, !tbaa !24
  store i64 %t300, ptr %l156, !tbaa !24
  %t301 = load i64, ptr %l156, !tbaa !24
  %t302 = add i64 %t301, 1
  store i64 %t302, ptr %l157, !tbaa !24
  %t303 = load i64, ptr %l157, !tbaa !24
  store i64 %t303, ptr %l4, !tbaa !24
  %t304 = load i8, ptr %l7, !tbaa !22
  store i8 %t304, ptr %l158, !tbaa !22
  %t305 = load i8, ptr %l158, !tbaa !22
  %t306 = icmp eq i8 %t305, 41
  store i1 %t306, ptr %l159, !tbaa !21
  %t307 = load i1, ptr %l159, !tbaa !21
  br i1 %t307, label %bb121, label %bb122
bb121:
  store %olang.scope zeroinitializer, ptr %s17
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  br label %bb129
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s13)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s12)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s10)
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s8)
  br label %bb127
bb127:
  %t308 = load i64, ptr %l6, !tbaa !24
  store i64 %t308, ptr %l160, !tbaa !24
  %t309 = load i64, ptr %l160, !tbaa !24
  %t310 = add i64 %t309, 1
  store i64 %t310, ptr %l161, !tbaa !24
  %t311 = load i64, ptr %l161, !tbaa !24
  store i64 %t311, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb128
bb128:
  br label %bb53
bb129:
  %t312 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t312, ptr %l162, !tbaa !27
  %t313 = load i64, ptr %l6, !tbaa !24
  store i64 %t313, ptr %l163, !tbaa !24
  %t314 = load i64, ptr %l163, !tbaa !24
  %t315 = add i64 %t314, 1
  store i64 %t315, ptr %l164, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t316, ptr %l165, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t317, ptr %l166, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 0
  store i64 %t319, ptr %l167, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l168, !tbaa !24
  %t322 = load i64, ptr %l164, !tbaa !24
  %t323 = icmp sge i64 %t322, 0
  store i1 %t323, ptr %l169, !tbaa !21
  %t324 = load i1, ptr %l169, !tbaa !21
  br i1 %t324, label %bb130, label %bb131
bb130:
  %t325 = load i64, ptr %l164, !tbaa !24
  %t326 = load i64, ptr %l167, !tbaa !24
  %t327 = icmp sle i64 %t325, %t326
  store i1 %t327, ptr %l170, !tbaa !21
  %t328 = load i1, ptr %l170, !tbaa !21
  br i1 %t328, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb132:
  %t329 = load i64, ptr %l167, !tbaa !24
  %t330 = load i64, ptr %l168, !tbaa !24
  %t331 = icmp sle i64 %t329, %t330
  store i1 %t331, ptr %l171, !tbaa !21
  %t332 = load i1, ptr %l171, !tbaa !21
  br i1 %t332, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb134:
  %t333 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l164, !tbaa !24
  %t336 = load i64, ptr %l167, !tbaa !24
  %t337 = getelementptr i8, ptr %t334, i64 %t335
  %t338 = sub i64 %t336, %t335
  %t339 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t337, 1
  store { i64, ptr } %t340, ptr %l172, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t341, ptr %l10, !tbaa !27
  %t342 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t342, ptr %l174, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t344 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t343, { i64, ptr } { i64 1, ptr @.d99 })
  %t345 = extractvalue { i32, i64 } %t344, 1
  %t346 = extractvalue { i32, i64 } %t344, 0
  store i32 %t346, ptr %l176
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb137, label %ok.348
ok.348:
  store i64 %t345, ptr %l175
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb136:
  %t349 = load i64, ptr %l175, !tbaa !24
  store i64 %t349, ptr %l173, !tbaa !24
  br label %bb139
bb137:
  br label %bb138
bb138:
  %t350 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t350, ptr %l177, !tbaa !27
  %t351 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t352 = extractvalue { i64, ptr } %t351, 0
  store i64 %t352, ptr %l178, !tbaa !24
  %t353 = load i64, ptr %l178, !tbaa !24
  store i64 %t353, ptr %l173, !tbaa !24
  br label %bb139
bb139:
  %t354 = load i64, ptr %l173, !tbaa !24
  store i64 %t354, ptr %l11, !tbaa !24
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l179, !tbaa !29
  %t356 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t356, ptr %l180, !tbaa !27
  %t357 = load i64, ptr %l11, !tbaa !24
  store i64 %t357, ptr %l181, !tbaa !24
  %t358 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t358, 0
  store i64 %t359, ptr %l182, !tbaa !24
  %t360 = icmp sge i64 0, 0
  store i1 %t360, ptr %l183, !tbaa !21
  %t361 = load i1, ptr %l183, !tbaa !21
  br i1 %t361, label %bb140, label %bb141
bb140:
  %t362 = load i64, ptr %l181, !tbaa !24
  %t363 = icmp sle i64 0, %t362
  store i1 %t363, ptr %l184, !tbaa !21
  %t364 = load i1, ptr %l184, !tbaa !21
  br i1 %t364, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb142:
  %t365 = load i64, ptr %l181, !tbaa !24
  %t366 = load i64, ptr %l182, !tbaa !24
  %t367 = icmp sle i64 %t365, %t366
  store i1 %t367, ptr %l185, !tbaa !21
  %t368 = load i1, ptr %l185, !tbaa !21
  br i1 %t368, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb144:
  %t369 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = load i64, ptr %l181, !tbaa !24
  %t372 = getelementptr i8, ptr %t370, i64 0
  %t373 = sub i64 %t371, 0
  %t374 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t372, 1
  store { i64, ptr } %t375, ptr %l186, !tbaa !27
  %t376 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t377 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t376)
  store { i64, ptr } %t377, ptr %l187
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb146:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t378 = extractvalue { i64, ptr } { i64 1, ptr @.d101 }, 1
  %t379 = extractvalue { i64, ptr } { i64 1, ptr @.d101 }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t378, i64 %t379)
  %t380 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = extractvalue { i64, ptr } %t380, 0
  call void @__olang_sb_put(ptr %s18, ptr %t381, i64 %t382)
  %t383 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 1
  %t384 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t383, i64 %t384)
  %t385 = load ptr, ptr %s18
  %t386 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t387 = load i64, ptr %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t387)
  call void @llvm.memcpy.p0.p0.i64(ptr %t388, ptr %t385, i64 %t387, i1 false)
  %t389 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  store { i64, ptr } %t390, ptr %l188, !tbaa !27
  call void @__olang_sb_done(ptr %s18)
  %t391 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 0
  %t393 = extractvalue { i64, ptr } %t391, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  store { i64, ptr } %t397, ptr %l189, !tbaa !27
  %t398 = load ptr, ptr %l179, !tbaa !29
  %t399 = load { i64, ptr }, ptr %l189, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t398, { i64, ptr } %t399)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb148:
  %t400 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t400, ptr %l190, !tbaa !27
  %t401 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t402 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t401, { i64, ptr } { i64 1, ptr @.d103 })
  store i1 %t402, ptr %l191
  br label %bb149
bb149:
  %t403 = load i1, ptr %l191, !tbaa !21
  br i1 %t403, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s19
  %t404 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t404, ptr %l193, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t406 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t405, { i64, ptr } { i64 3, ptr @.d104 })
  %t407 = extractvalue { i32, i64 } %t406, 1
  %t408 = extractvalue { i32, i64 } %t406, 0
  store i32 %t408, ptr %l195
  %t409 = icmp ne i32 %t408, 0
  br i1 %t409, label %bb153, label %ok.410
ok.410:
  store i64 %t407, ptr %l194
  br label %bb152
bb151:
  br label %bb221
bb152:
  %t411 = load i64, ptr %l194, !tbaa !24
  store i64 %t411, ptr %l192, !tbaa !24
  br label %bb155
bb153:
  br label %bb154
bb154:
  store %olang.scope zeroinitializer, ptr %s20
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb155:
  %t412 = load i64, ptr %l192, !tbaa !24
  store i64 %t412, ptr %l12, !tbaa !24
  %t413 = load ptr, ptr %l0, !tbaa !29
  store ptr %t413, ptr %l196, !tbaa !29
  %t414 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t414, ptr %l197, !tbaa !27
  %t415 = load i64, ptr %l12, !tbaa !24
  store i64 %t415, ptr %l198, !tbaa !24
  %t416 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t416, 0
  store i64 %t417, ptr %l199, !tbaa !24
  %t418 = icmp sge i64 0, 0
  store i1 %t418, ptr %l200, !tbaa !21
  %t419 = load i1, ptr %l200, !tbaa !21
  br i1 %t419, label %bb156, label %bb157
bb156:
  %t420 = load i64, ptr %l198, !tbaa !24
  %t421 = icmp sle i64 0, %t420
  store i1 %t421, ptr %l201, !tbaa !21
  %t422 = load i1, ptr %l201, !tbaa !21
  br i1 %t422, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb158:
  %t423 = load i64, ptr %l198, !tbaa !24
  %t424 = load i64, ptr %l199, !tbaa !24
  %t425 = icmp sle i64 %t423, %t424
  store i1 %t425, ptr %l202, !tbaa !21
  %t426 = load i1, ptr %l202, !tbaa !21
  br i1 %t426, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb160:
  %t427 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = load i64, ptr %l198, !tbaa !24
  %t430 = getelementptr i8, ptr %t428, i64 0
  %t431 = sub i64 %t429, 0
  %t432 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t430, 1
  store { i64, ptr } %t433, ptr %l203, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s21
  store ptr %s21room, ptr %s21
  %t434 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t435 = extractvalue { i64, ptr } %t434, 1
  %t436 = extractvalue { i64, ptr } %t434, 0
  call void @__olang_sb_put(ptr %s21, ptr %t435, i64 %t436)
  %t437 = extractvalue { i64, ptr } { i64 12, ptr @.d106 }, 1
  %t438 = extractvalue { i64, ptr } { i64 12, ptr @.d106 }, 0
  call void @__olang_sb_put(ptr %s21, ptr %t437, i64 %t438)
  %t439 = load ptr, ptr %s21
  %t440 = getelementptr %olang.builder, ptr %s21, i32 0, i32 1
  %t441 = load i64, ptr %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t441)
  call void @llvm.memcpy.p0.p0.i64(ptr %t442, ptr %t439, i64 %t441, i1 false)
  %t443 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t444 = insertvalue { i64, ptr } %t443, ptr %t442, 1
  store { i64, ptr } %t444, ptr %l204, !tbaa !27
  call void @__olang_sb_done(ptr %s21)
  %t445 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 0
  %t447 = extractvalue { i64, ptr } %t445, 1
  %t448 = mul i64 %t446, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t448)
  call void @llvm.memcpy.p0.p0.i64(ptr %t449, ptr %t447, i64 %t448, i1 false)
  %t450 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  store { i64, ptr } %t451, ptr %l205, !tbaa !27
  %t452 = load ptr, ptr %l196, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l205, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t452, { i64, ptr } %t453)
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb162:
  %t454 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t454, ptr %l206, !tbaa !27
  %t455 = load i64, ptr %l12, !tbaa !24
  store i64 %t455, ptr %l207, !tbaa !24
  %t456 = load i64, ptr %l207, !tbaa !24
  %t457 = add i64 %t456, 3
  store i64 %t457, ptr %l208, !tbaa !24
  %t458 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t458, ptr %l209, !tbaa !27
  %t459 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t459, ptr %l210, !tbaa !27
  %t460 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t460, 0
  store i64 %t461, ptr %l211, !tbaa !24
  %t462 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t463 = extractvalue { i64, ptr } %t462, 0
  store i64 %t463, ptr %l212, !tbaa !24
  %t464 = load i64, ptr %l208, !tbaa !24
  %t465 = icmp sge i64 %t464, 0
  store i1 %t465, ptr %l213, !tbaa !21
  %t466 = load i1, ptr %l213, !tbaa !21
  br i1 %t466, label %bb163, label %bb164
bb163:
  %t467 = load i64, ptr %l208, !tbaa !24
  %t468 = load i64, ptr %l211, !tbaa !24
  %t469 = icmp sle i64 %t467, %t468
  store i1 %t469, ptr %l214, !tbaa !21
  %t470 = load i1, ptr %l214, !tbaa !21
  br i1 %t470, label %bb165, label %bb166
bb164:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb165:
  %t471 = load i64, ptr %l211, !tbaa !24
  %t472 = load i64, ptr %l212, !tbaa !24
  %t473 = icmp sle i64 %t471, %t472
  store i1 %t473, ptr %l215, !tbaa !21
  %t474 = load i1, ptr %l215, !tbaa !21
  br i1 %t474, label %bb167, label %bb168
bb166:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb167:
  %t475 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = load i64, ptr %l208, !tbaa !24
  %t478 = load i64, ptr %l211, !tbaa !24
  %t479 = getelementptr i8, ptr %t476, i64 %t477
  %t480 = sub i64 %t478, %t477
  %t481 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t479, 1
  store { i64, ptr } %t482, ptr %l216, !tbaa !27
  %t483 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t483, ptr %l13, !tbaa !27
  %t484 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t484, ptr %l217, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t486 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t485, { i64, ptr } { i64 13, ptr @.d108 })
  store i1 %t486, ptr %l218
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb169:
  %t487 = load i1, ptr %l218, !tbaa !21
  br i1 %t487, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s22
  %t488 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t488, ptr %l220, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t490 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s22, { i64, ptr } %t489, { i64, ptr } { i64 1, ptr @.d109 })
  %t491 = extractvalue { i32, i64 } %t490, 1
  %t492 = extractvalue { i32, i64 } %t490, 0
  store i32 %t492, ptr %l222
  %t493 = icmp ne i32 %t492, 0
  br i1 %t493, label %bb173, label %ok.494
ok.494:
  store i64 %t491, ptr %l221
  br label %bb172
bb171:
  br label %bb189
bb172:
  %t495 = load i64, ptr %l221, !tbaa !24
  store i64 %t495, ptr %l219, !tbaa !24
  br label %bb175
bb173:
  br label %bb174
bb174:
  store %olang.scope zeroinitializer, ptr %s23
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb175:
  %t496 = load i64, ptr %l219, !tbaa !24
  store i64 %t496, ptr %l14, !tbaa !24
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l223, !tbaa !29
  %t498 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t498, ptr %l224, !tbaa !27
  %t499 = load i64, ptr %l14, !tbaa !24
  store i64 %t499, ptr %l225, !tbaa !24
  %t500 = load i64, ptr %l225, !tbaa !24
  %t501 = add i64 %t500, 1
  store i64 %t501, ptr %l226, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t503 = extractvalue { i64, ptr } %t502, 0
  store i64 %t503, ptr %l227, !tbaa !24
  %t504 = icmp sge i64 0, 0
  store i1 %t504, ptr %l228, !tbaa !21
  %t505 = load i1, ptr %l228, !tbaa !21
  br i1 %t505, label %bb176, label %bb177
bb176:
  %t506 = load i64, ptr %l226, !tbaa !24
  %t507 = icmp sle i64 0, %t506
  store i1 %t507, ptr %l229, !tbaa !21
  %t508 = load i1, ptr %l229, !tbaa !21
  br i1 %t508, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb178:
  %t509 = load i64, ptr %l226, !tbaa !24
  %t510 = load i64, ptr %l227, !tbaa !24
  %t511 = icmp sle i64 %t509, %t510
  store i1 %t511, ptr %l230, !tbaa !21
  %t512 = load i1, ptr %l230, !tbaa !21
  br i1 %t512, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb180:
  %t513 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = load i64, ptr %l226, !tbaa !24
  %t516 = getelementptr i8, ptr %t514, i64 0
  %t517 = sub i64 %t515, 0
  %t518 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t519 = insertvalue { i64, ptr } %t518, ptr %t516, 1
  store { i64, ptr } %t519, ptr %l231, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s24
  store ptr %s24room, ptr %s24
  %t520 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t521 = extractvalue { i64, ptr } %t520, 1
  %t522 = extractvalue { i64, ptr } %t520, 0
  call void @__olang_sb_put(ptr %s24, ptr %t521, i64 %t522)
  %t523 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 1
  %t524 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 0
  call void @__olang_sb_put(ptr %s24, ptr %t523, i64 %t524)
  %t525 = load ptr, ptr %s24
  %t526 = getelementptr %olang.builder, ptr %s24, i32 0, i32 1
  %t527 = load i64, ptr %t526
  %t528 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t527)
  call void @llvm.memcpy.p0.p0.i64(ptr %t528, ptr %t525, i64 %t527, i1 false)
  %t529 = insertvalue { i64, ptr } undef, i64 %t527, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  store { i64, ptr } %t530, ptr %l232, !tbaa !27
  call void @__olang_sb_done(ptr %s24)
  %t531 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  %t533 = extractvalue { i64, ptr } %t531, 1
  %t534 = mul i64 %t532, 1
  %t535 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t534)
  call void @llvm.memcpy.p0.p0.i64(ptr %t535, ptr %t533, i64 %t534, i1 false)
  %t536 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t535, 1
  store { i64, ptr } %t537, ptr %l233, !tbaa !27
  %t538 = load ptr, ptr %l223, !tbaa !29
  %t539 = load { i64, ptr }, ptr %l233, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t538, { i64, ptr } %t539)
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb182:
  %t540 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t540, ptr %l234, !tbaa !27
  %t541 = load i64, ptr %l14, !tbaa !24
  store i64 %t541, ptr %l235, !tbaa !24
  %t542 = load i64, ptr %l235, !tbaa !24
  %t543 = add i64 %t542, 2
  store i64 %t543, ptr %l236, !tbaa !24
  %t544 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t544, ptr %l237, !tbaa !27
  %t545 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t545, ptr %l238, !tbaa !27
  %t546 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t546, 0
  store i64 %t547, ptr %l239, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l240, !tbaa !24
  %t550 = load i64, ptr %l236, !tbaa !24
  %t551 = icmp sge i64 %t550, 0
  store i1 %t551, ptr %l241, !tbaa !21
  %t552 = load i1, ptr %l241, !tbaa !21
  br i1 %t552, label %bb183, label %bb184
bb183:
  %t553 = load i64, ptr %l236, !tbaa !24
  %t554 = load i64, ptr %l239, !tbaa !24
  %t555 = icmp sle i64 %t553, %t554
  store i1 %t555, ptr %l242, !tbaa !21
  %t556 = load i1, ptr %l242, !tbaa !21
  br i1 %t556, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb185:
  %t557 = load i64, ptr %l239, !tbaa !24
  %t558 = load i64, ptr %l240, !tbaa !24
  %t559 = icmp sle i64 %t557, %t558
  store i1 %t559, ptr %l243, !tbaa !21
  %t560 = load i1, ptr %l243, !tbaa !21
  br i1 %t560, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb187:
  %t561 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = load i64, ptr %l236, !tbaa !24
  %t564 = load i64, ptr %l239, !tbaa !24
  %t565 = getelementptr i8, ptr %t562, i64 %t563
  %t566 = sub i64 %t564, %t563
  %t567 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t565, 1
  store { i64, ptr } %t568, ptr %l244, !tbaa !27
  %t569 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t569, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb189:
  %t570 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t570, ptr %l245, !tbaa !27
  %t571 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t572 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t571, { i64, ptr } { i64 13, ptr @.d113 })
  store i1 %t572, ptr %l246
  br label %bb190
bb190:
  %t573 = load i1, ptr %l246, !tbaa !21
  br i1 %t573, label %bb191, label %bb192
bb191:
  store %olang.scope zeroinitializer, ptr %s25
  %t574 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t574, ptr %l247, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t575, ptr %l248, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t576, ptr %l249, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t577, 0
  store i64 %t578, ptr %l250, !tbaa !24
  %t579 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t579, 0
  store i64 %t580, ptr %l251, !tbaa !24
  %t581 = icmp sge i64 13, 0
  store i1 %t581, ptr %l252, !tbaa !21
  %t582 = load i1, ptr %l252, !tbaa !21
  br i1 %t582, label %bb193, label %bb194
bb192:
  br label %bb199
bb193:
  %t583 = load i64, ptr %l250, !tbaa !24
  %t584 = icmp sle i64 13, %t583
  store i1 %t584, ptr %l253, !tbaa !21
  %t585 = load i1, ptr %l253, !tbaa !21
  br i1 %t585, label %bb195, label %bb196
bb194:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb195:
  %t586 = load i64, ptr %l250, !tbaa !24
  %t587 = load i64, ptr %l251, !tbaa !24
  %t588 = icmp sle i64 %t586, %t587
  store i1 %t588, ptr %l254, !tbaa !21
  %t589 = load i1, ptr %l254, !tbaa !21
  br i1 %t589, label %bb197, label %bb198
bb196:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb197:
  %t590 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = load i64, ptr %l250, !tbaa !24
  %t593 = getelementptr i8, ptr %t591, i64 13
  %t594 = sub i64 %t592, 13
  %t595 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t593, 1
  store { i64, ptr } %t596, ptr %l255, !tbaa !27
  %t597 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t597, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s25)
  br label %bb199
bb198:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb199:
  %t598 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t598, ptr %l257, !tbaa !27
  %t599 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t600 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t599, { i64, ptr } { i64 1, ptr @.d115 })
  %t601 = extractvalue { i32, i64 } %t600, 1
  %t602 = extractvalue { i32, i64 } %t600, 0
  store i32 %t602, ptr %l259
  %t603 = icmp ne i32 %t602, 0
  br i1 %t603, label %bb201, label %ok.604
ok.604:
  store i64 %t601, ptr %l258
  br label %bb200
bb200:
  %t605 = load i64, ptr %l258, !tbaa !24
  store i64 %t605, ptr %l256, !tbaa !24
  br label %bb203
bb201:
  br label %bb202
bb202:
  %t606 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t606, ptr %l260, !tbaa !27
  %t607 = load { i64, ptr }, ptr %l260, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t607, 0
  store i64 %t608, ptr %l261, !tbaa !24
  %t609 = load i64, ptr %l261, !tbaa !24
  store i64 %t609, ptr %l256, !tbaa !24
  br label %bb203
bb203:
  %t610 = load i64, ptr %l256, !tbaa !24
  store i64 %t610, ptr %l15, !tbaa !24
  %t611 = load i64, ptr %l15, !tbaa !24
  store i64 %t611, ptr %l262, !tbaa !24
  %t612 = load i64, ptr %l262, !tbaa !24
  %t613 = add i64 %t612, 1
  store i64 %t613, ptr %l263, !tbaa !24
  %t614 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t614, ptr %l264, !tbaa !27
  %t615 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t615, 0
  store i64 %t616, ptr %l265, !tbaa !24
  %t617 = load i64, ptr %l263, !tbaa !24
  %t618 = load i64, ptr %l265, !tbaa !24
  %t619 = icmp slt i64 %t617, %t618
  store i1 %t619, ptr %l266, !tbaa !21
  %t620 = load i1, ptr %l266, !tbaa !21
  br i1 %t620, label %bb204, label %bb205
bb204:
  %t621 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t621, ptr %l268, !tbaa !27
  %t622 = load i64, ptr %l15, !tbaa !24
  store i64 %t622, ptr %l269, !tbaa !24
  %t623 = load i64, ptr %l269, !tbaa !24
  %t624 = add i64 %t623, 1
  store i64 %t624, ptr %l270, !tbaa !24
  %t625 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t626 = load i64, ptr %l270, !tbaa !24
  %t627 = call i64 @compiler_2fruntime_2etypeEnd(ptr %v1, { i64, ptr } %t625, i64 %t626)
  store i64 %t627, ptr %l271
  br label %bb206
bb205:
  %t628 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t628, ptr %l272, !tbaa !27
  %t629 = load { i64, ptr }, ptr %l272, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t629, 0
  store i64 %t630, ptr %l273, !tbaa !24
  %t631 = load i64, ptr %l273, !tbaa !24
  store i64 %t631, ptr %l267, !tbaa !24
  br label %bb207
bb206:
  %t632 = load i64, ptr %l271, !tbaa !24
  store i64 %t632, ptr %l267, !tbaa !24
  br label %bb207
bb207:
  %t633 = load i64, ptr %l267, !tbaa !24
  store i64 %t633, ptr %l16, !tbaa !24
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l274, !tbaa !29
  %t635 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t635, ptr %l275, !tbaa !27
  %t636 = load i64, ptr %l15, !tbaa !24
  store i64 %t636, ptr %l276, !tbaa !24
  %t637 = load i64, ptr %l276, !tbaa !24
  %t638 = add i64 %t637, 1
  store i64 %t638, ptr %l277, !tbaa !24
  %t639 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t639, 0
  store i64 %t640, ptr %l278, !tbaa !24
  %t641 = icmp sge i64 0, 0
  store i1 %t641, ptr %l279, !tbaa !21
  %t642 = load i1, ptr %l279, !tbaa !21
  br i1 %t642, label %bb208, label %bb209
bb208:
  %t643 = load i64, ptr %l277, !tbaa !24
  %t644 = icmp sle i64 0, %t643
  store i1 %t644, ptr %l280, !tbaa !21
  %t645 = load i1, ptr %l280, !tbaa !21
  br i1 %t645, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb210:
  %t646 = load i64, ptr %l277, !tbaa !24
  %t647 = load i64, ptr %l278, !tbaa !24
  %t648 = icmp sle i64 %t646, %t647
  store i1 %t648, ptr %l281, !tbaa !21
  %t649 = load i1, ptr %l281, !tbaa !21
  br i1 %t649, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb212:
  %t650 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = load i64, ptr %l277, !tbaa !24
  %t653 = getelementptr i8, ptr %t651, i64 0
  %t654 = sub i64 %t652, 0
  %t655 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t653, 1
  store { i64, ptr } %t656, ptr %l282, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t657, ptr %l283, !tbaa !27
  %t658 = load i64, ptr %l15, !tbaa !24
  store i64 %t658, ptr %l284, !tbaa !24
  %t659 = load i64, ptr %l284, !tbaa !24
  %t660 = add i64 %t659, 1
  store i64 %t660, ptr %l285, !tbaa !24
  %t661 = load i64, ptr %l16, !tbaa !24
  store i64 %t661, ptr %l286, !tbaa !24
  %t662 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 0
  store i64 %t663, ptr %l287, !tbaa !24
  %t664 = load i64, ptr %l285, !tbaa !24
  %t665 = icmp sge i64 %t664, 0
  store i1 %t665, ptr %l288, !tbaa !21
  %t666 = load i1, ptr %l288, !tbaa !21
  br i1 %t666, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb214:
  %t667 = load i64, ptr %l285, !tbaa !24
  %t668 = load i64, ptr %l286, !tbaa !24
  %t669 = icmp sle i64 %t667, %t668
  store i1 %t669, ptr %l289, !tbaa !21
  %t670 = load i1, ptr %l289, !tbaa !21
  br i1 %t670, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb216:
  %t671 = load i64, ptr %l286, !tbaa !24
  %t672 = load i64, ptr %l287, !tbaa !24
  %t673 = icmp sle i64 %t671, %t672
  store i1 %t673, ptr %l290, !tbaa !21
  %t674 = load i1, ptr %l290, !tbaa !21
  br i1 %t674, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb218:
  %t675 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = load i64, ptr %l285, !tbaa !24
  %t678 = load i64, ptr %l286, !tbaa !24
  %t679 = getelementptr i8, ptr %t676, i64 %t677
  %t680 = sub i64 %t678, %t677
  %t681 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t679, 1
  store { i64, ptr } %t682, ptr %l291, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s26
  store ptr %s26room, ptr %s26
  %t683 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t684 = extractvalue { i64, ptr } %t683, 1
  %t685 = extractvalue { i64, ptr } %t683, 0
  call void @__olang_sb_put(ptr %s26, ptr %t684, i64 %t685)
  %t686 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t687 = extractvalue { i64, ptr } %t686, 1
  %t688 = extractvalue { i64, ptr } %t686, 0
  call void @__olang_sb_put(ptr %s26, ptr %t687, i64 %t688)
  %t689 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 1
  %t690 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 0
  call void @__olang_sb_put(ptr %s26, ptr %t689, i64 %t690)
  %t691 = load ptr, ptr %s26
  %t692 = getelementptr %olang.builder, ptr %s26, i32 0, i32 1
  %t693 = load i64, ptr %t692
  %t694 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t693)
  call void @llvm.memcpy.p0.p0.i64(ptr %t694, ptr %t691, i64 %t693, i1 false)
  %t695 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t696 = insertvalue { i64, ptr } %t695, ptr %t694, 1
  store { i64, ptr } %t696, ptr %l292, !tbaa !27
  call void @__olang_sb_done(ptr %s26)
  %t697 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t697, 0
  %t699 = extractvalue { i64, ptr } %t697, 1
  %t700 = mul i64 %t698, 1
  %t701 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t700)
  call void @llvm.memcpy.p0.p0.i64(ptr %t701, ptr %t699, i64 %t700, i1 false)
  %t702 = insertvalue { i64, ptr } undef, i64 %t698, 0
  %t703 = insertvalue { i64, ptr } %t702, ptr %t701, 1
  store { i64, ptr } %t703, ptr %l293, !tbaa !27
  %t704 = load ptr, ptr %l274, !tbaa !29
  %t705 = load { i64, ptr }, ptr %l293, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t704, { i64, ptr } %t705)
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb220:
  call void @__olang_scope_close(ptr %s19)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fruntime_2edirective(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 3, ptr @.d118 })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  store i1 %t5, ptr %l6, !tbaa !21
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 -1, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i64, ptr %l7, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t10, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = icmp sge i64 3, 0
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sle i64 3, %t17
  store i1 %t18, ptr %l14, !tbaa !21
  %t19 = load i1, ptr %l14, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb7:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  store i1 %t22, ptr %l15, !tbaa !21
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb9:
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 3
  %t28 = sub i64 %t26, 3
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t31, ptr %l1, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t33, ptr %l2, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l19, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t36 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 1, ptr @.d120 })
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l21
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb12, label %ok.40
ok.40:
  store i64 %t37, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb11:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb14
bb14:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  store i1 %t45, ptr %l23, !tbaa !21
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = icmp sge i64 0, 0
  store i1 %t51, ptr %l27, !tbaa !21
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb16:
  br label %bb23
bb17:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  store i1 %t54, ptr %l28, !tbaa !21
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb19:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  store i1 %t58, ptr %l29, !tbaa !21
  %t59 = load i1, ptr %l29, !tbaa !21
  br i1 %t59, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb21:
  %t60 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l30, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t67, ptr %l2, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb23:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 2, ptr @.d122 })
  store i1 %t70, ptr %l32
  br label %bb24
bb24:
  %t71 = load i1, ptr %l32, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t72 = load i64, ptr %l33, !tbaa !24
  store i64 %t72, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l34, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t74, { i64, ptr } { i64 4, ptr @.d123 })
  store i1 %t75, ptr %l35
  br label %bb28
bb28:
  %t76 = load i1, ptr %l35, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 1, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i64, ptr %l36, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t79, { i64, ptr } { i64 3, ptr @.d124 })
  store i1 %t80, ptr %l38
  br label %bb32
bb32:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  store i64 2, ptr %l39, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i64, ptr %l39, !tbaa !24
  store i64 %t82, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  store i64 -1, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t83 = load i64, ptr %l40, !tbaa !24
  store i64 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fruntime_2efact(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactNames, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l9, !tbaa !24
  %t4 = load i64, ptr %l9, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l12, !tbaa !21
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l15, !tbaa !21
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l19, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = load i64, ptr %l23, !tbaa !24
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l27, !tbaa !21
  %t38 = load i1, ptr %l27, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l28, !tbaa !21
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  store i64 %t41, ptr %l29, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l32, !tbaa !24
  %t47 = load i64, ptr %l29, !tbaa !24
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l33, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  store i64 %t51, ptr %l34, !tbaa !24
  %t52 = load i64, ptr %l34, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactNames, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %t54, i64 %t52
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !37
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  %t58 = load ptr, ptr @__olang_prog_scope
  %t59 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t58, ptr %v0, { i64, ptr } %t59, { i64, ptr } %t60)
  store i1 %t61, ptr %l37
  br label %bb11
bb11:
  %t62 = load i1, ptr %l37, !tbaa !21
  br i1 %t62, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l38, !tbaa !24
  %t65 = icmp eq i64 %t64, 0
  store i1 %t65, ptr %l39, !tbaa !21
  %t66 = load i1, ptr %l39, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb13:
  br label %bb17
bb14:
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactX86, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i64, ptr %t70, i64 %t68
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %l42, !tbaa !24
  %t73 = load i64, ptr %l42, !tbaa !24
  store i64 %t73, ptr %l40, !tbaa !24
  br label %bb16
bb15:
  %t74 = load i64, ptr %l7, !tbaa !24
  store i64 %t74, ptr %l43, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eFactArm, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i64, ptr %t77, i64 %t75
  %t79 = load i64, ptr %t78, !tbaa !34
  store i64 %t79, ptr %l44, !tbaa !24
  %t80 = load i64, ptr %l44, !tbaa !24
  store i64 %t80, ptr %l40, !tbaa !24
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i64, ptr %l40, !tbaa !24
  %t82 = insertvalue { i32, i64 } zeroinitializer, i64 %t81, 1
  store { i32, i64 } %t82, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load i64, ptr %l6, !tbaa !24
  store i64 %t83, ptr %l45, !tbaa !24
  %t84 = load i64, ptr %l45, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l46, !tbaa !24
  %t86 = load i64, ptr %l46, !tbaa !24
  store i64 %t86, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %l47, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l47, !tbaa !23
  %t88 = insertvalue { i32, i64 } zeroinitializer, i32 %t87, 0
  store { i32, i64 } %t88, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @compiler_2fruntime_2emalformed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i32
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = extractvalue { i64, ptr } { i64 7, ptr @.d125 }, 1
  %t5 = extractvalue { i64, ptr } { i64 7, ptr @.d125 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t4, i64 %t5)
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t13 = call i64 @__olang_fmt_i64(ptr %t12, i64 %t11)
  call void @__olang_sb_add(ptr %s1, i64 %t13)
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d127 }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr @.d127 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t14, i64 %t15)
  %t16 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l7, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t33 = call i32 @std_2fio_2ePrintErrln(ptr %s0, { i64, ptr } %t32)
  store i32 %t33, ptr %l8
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb2, label %ok.35
ok.35:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t36 = load i32, ptr %l8, !tbaa !23
  %t37 = ashr i32 %t36, 16
  store i32 %t37, ptr %l9, !tbaa !23
  %t38 = load i32, ptr %l9, !tbaa !23
  %t39 = icmp eq i32 %t38, 1
  store i1 %t39, ptr %l10, !tbaa !21
  %t40 = load i1, ptr %l10, !tbaa !21
  br i1 %t40, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t41 = load i32, ptr %l8, !tbaa !23
  %t42 = lshr i32 %t41, 16
  %t43 = and i32 %t41, 65535
  %t44 = icmp eq i32 %t42, 1
  %t45 = select i1 %t44, i32 0, i32 0
  %t46 = icmp eq i32 %t41, 0
  %t47 = shl i32 %t45, 16
  %t48 = or i32 %t47, %t43
  %t49 = select i1 %t46, i32 0, i32 %t48
  store i32 %t49, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l11, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  store i32 65536, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i32, ptr %l12, !tbaa !23
  store i32 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 7, ptr @.d128 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  store i1 %t5, ptr %l3, !tbaa !21
  %t6 = load i1, ptr %l3, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 16, ptr @.d129 })
  store i1 %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 15, ptr @.d130 })
  store i1 %t14, ptr %l9
  br label %bb8
bb8:
  %t15 = load i1, ptr %l9, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l10, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t18, ptr %l11, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d131 }, ptr %l13, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } %t21)
  store i1 %t22, ptr %l14
  br label %bb13
bb13:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb15:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t24, ptr %l16, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t25, ptr %l17, !tbaa !27
  store { i64, ptr } { i64 10, ptr @.d132 }, ptr %l18, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t28 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t26, { i64, ptr } %t27)
  store i1 %t28, ptr %l19
  br label %bb16
bb16:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fruntime_2etypeEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i8
  %l20 = alloca i8
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i8
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i8
  %l63 = alloca i1
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i8
  %l99 = alloca i8
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i8
  %l103 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i8
  %l106 = alloca i1
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i8
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca i8
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca i8
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i1
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l18, !tbaa !24
  %t3 = load i64, ptr %l18, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t3
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l19, !tbaa !22
  %t8 = load i8, ptr %l19, !tbaa !22
  store i8 %t8, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  store i8 %t9, ptr %l20, !tbaa !22
  %t10 = load i8, ptr %l20, !tbaa !22
  %t11 = icmp ne i8 %t10, 91
  store i1 %t11, ptr %l21, !tbaa !21
  %t12 = load i1, ptr %l21, !tbaa !21
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t13 = load i8, ptr %l2, !tbaa !22
  store i8 %t13, ptr %l23, !tbaa !22
  %t14 = load i8, ptr %l23, !tbaa !22
  %t15 = icmp ne i8 %t14, 123
  store i1 %t15, ptr %l24, !tbaa !21
  %t16 = load i1, ptr %l24, !tbaa !21
  store i1 %t16, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l22, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load i8, ptr %l2, !tbaa !22
  store i8 %t18, ptr %l26, !tbaa !22
  %t19 = load i8, ptr %l26, !tbaa !22
  %t20 = icmp ne i8 %t19, 60
  store i1 %t20, ptr %l27, !tbaa !21
  %t21 = load i1, ptr %l27, !tbaa !21
  store i1 %t21, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l28, !tbaa !24
  %t24 = load i64, ptr %l28, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l29, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l30, !tbaa !24
  %t28 = load i64, ptr %l30, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %l31, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l32, !tbaa !24
  %t31 = load i64, ptr %l31, !tbaa !24
  %t32 = load i64, ptr %l32, !tbaa !24
  %t33 = icmp sgt i64 %t31, %t32
  store i1 %t33, ptr %l33, !tbaa !21
  %t34 = load i1, ptr %l33, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb8:
  br label %bb27
bb9:
  %t35 = load i64, ptr %l5, !tbaa !24
  store i64 %t35, ptr %l35, !tbaa !24
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = icmp sgt i64 %t36, 0
  store i1 %t37, ptr %l36, !tbaa !21
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  store i64 %t39, ptr %l38, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  store i64 %t40, ptr %l39, !tbaa !24
  %t41 = load i64, ptr %l38, !tbaa !24
  %t42 = load i64, ptr %l39, !tbaa !24
  %t43 = sub i64 %t41, %t42
  store i64 %t43, ptr %l40, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l41, !tbaa !24
  %t45 = load i64, ptr %l40, !tbaa !24
  %t46 = load i64, ptr %l41, !tbaa !24
  %t47 = add i64 %t45, %t46
  store i64 %t47, ptr %l42, !tbaa !24
  %t48 = load i64, ptr %l42, !tbaa !24
  %t49 = sub i64 %t48, 1
  store i64 %t49, ptr %l43, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  store i64 %t50, ptr %l44, !tbaa !24
  %t51 = load i64, ptr %l43, !tbaa !24
  %t52 = load i64, ptr %l44, !tbaa !24
  %t53 = sdiv i64 %t51, %t52
  store i64 %t53, ptr %l45, !tbaa !24
  %t54 = load i64, ptr %l45, !tbaa !24
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l37, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l34, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l7, !tbaa !24
  store i64 %t57, ptr %l46, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  store i64 %t58, ptr %l47, !tbaa !24
  %t59 = load i64, ptr %l46, !tbaa !24
  %t60 = load i64, ptr %l47, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  store i1 %t61, ptr %l48, !tbaa !21
  %t62 = load i1, ptr %l48, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l49, !tbaa !21
  %t64 = load i1, ptr %l49, !tbaa !21
  br i1 %t64, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t65 = load i64, ptr %l3, !tbaa !24
  store i64 %t65, ptr %l50, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  store i64 %t66, ptr %l51, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  store i64 %t67, ptr %l52, !tbaa !24
  %t68 = load i64, ptr %l51, !tbaa !24
  %t69 = load i64, ptr %l52, !tbaa !24
  %t70 = mul i64 %t68, %t69
  store i64 %t70, ptr %l53, !tbaa !24
  %t71 = load i64, ptr %l50, !tbaa !24
  %t72 = load i64, ptr %l53, !tbaa !24
  %t73 = add i64 %t71, %t72
  store i64 %t73, ptr %l54, !tbaa !24
  %t74 = load i64, ptr %l54, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l55, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l56, !tbaa !24
  %t77 = load i64, ptr %l56, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t77
  %t81 = load i8, ptr %t80, !tbaa !32
  store i8 %t81, ptr %l57, !tbaa !22
  %t82 = load i8, ptr %l57, !tbaa !22
  %t83 = icmp eq i8 %t82, 32
  store i1 %t83, ptr %l58, !tbaa !21
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb21
bb20:
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l60, !tbaa !27
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %l61, !tbaa !24
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t87
  %t91 = load i8, ptr %t90, !tbaa !32
  store i8 %t91, ptr %l62, !tbaa !22
  %t92 = load i8, ptr %l62, !tbaa !22
  %t93 = icmp eq i8 %t92, 44
  store i1 %t93, ptr %l63, !tbaa !21
  %t94 = load i1, ptr %l63, !tbaa !21
  store i1 %t94, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l59, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t96 = load i64, ptr %l8, !tbaa !24
  store i64 %t96, ptr %l64, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t97 = load i64, ptr %l64, !tbaa !24
  store i64 %t97, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l7, !tbaa !24
  store i64 %t98, ptr %l65, !tbaa !24
  %t99 = load i64, ptr %l65, !tbaa !24
  %t100 = add i64 %t99, 1
  store i64 %t100, ptr %l66, !tbaa !24
  %t101 = load i64, ptr %l66, !tbaa !24
  store i64 %t101, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb26:
  call void @__olang_scope_close(ptr %s2)
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t102, ptr %l67, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l68, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t105 = load i64, ptr %l68, !tbaa !24
  store i64 %t105, ptr %rv
  br label %ret
bb27:
  store i64 0, ptr %l9, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l69, !tbaa !24
  %t107 = load i64, ptr %l69, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l70, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l71, !tbaa !24
  %t111 = load i64, ptr %l71, !tbaa !24
  store i64 %t111, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  store i64 %t112, ptr %l72, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  store i64 %t113, ptr %l73, !tbaa !24
  %t114 = load i64, ptr %l72, !tbaa !24
  %t115 = load i64, ptr %l73, !tbaa !24
  %t116 = icmp sgt i64 %t114, %t115
  store i1 %t116, ptr %l74, !tbaa !21
  %t117 = load i1, ptr %l74, !tbaa !21
  br i1 %t117, label %bb28, label %bb29
bb28:
  %t118 = load i64, ptr %l12, !tbaa !24
  store i64 %t118, ptr %l76, !tbaa !24
  %t119 = load i64, ptr %l76, !tbaa !24
  %t120 = icmp sgt i64 %t119, 0
  store i1 %t120, ptr %l77, !tbaa !21
  %t121 = load i1, ptr %l77, !tbaa !21
  br i1 %t121, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb33
bb30:
  %t122 = load i64, ptr %l11, !tbaa !24
  store i64 %t122, ptr %l79, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  store i64 %t123, ptr %l80, !tbaa !24
  %t124 = load i64, ptr %l79, !tbaa !24
  %t125 = load i64, ptr %l80, !tbaa !24
  %t126 = sub i64 %t124, %t125
  store i64 %t126, ptr %l81, !tbaa !24
  %t127 = load i64, ptr %l12, !tbaa !24
  store i64 %t127, ptr %l82, !tbaa !24
  %t128 = load i64, ptr %l81, !tbaa !24
  %t129 = load i64, ptr %l82, !tbaa !24
  %t130 = add i64 %t128, %t129
  store i64 %t130, ptr %l83, !tbaa !24
  %t131 = load i64, ptr %l83, !tbaa !24
  %t132 = sub i64 %t131, 1
  store i64 %t132, ptr %l84, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  store i64 %t133, ptr %l85, !tbaa !24
  %t134 = load i64, ptr %l84, !tbaa !24
  %t135 = load i64, ptr %l85, !tbaa !24
  %t136 = sdiv i64 %t134, %t135
  store i64 %t136, ptr %l86, !tbaa !24
  %t137 = load i64, ptr %l86, !tbaa !24
  store i64 %t137, ptr %l78, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb32
bb32:
  %t138 = load i64, ptr %l78, !tbaa !24
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb33
bb33:
  %t139 = load i64, ptr %l75, !tbaa !24
  store i64 %t139, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t140 = load i64, ptr %l14, !tbaa !24
  store i64 %t140, ptr %l87, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  store i64 %t141, ptr %l88, !tbaa !24
  %t142 = load i64, ptr %l87, !tbaa !24
  %t143 = load i64, ptr %l88, !tbaa !24
  %t144 = icmp slt i64 %t142, %t143
  store i1 %t144, ptr %l89, !tbaa !21
  %t145 = load i1, ptr %l89, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l90, !tbaa !21
  %t147 = load i1, ptr %l90, !tbaa !21
  br i1 %t147, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb36:
  br label %bb37
bb37:
  %t148 = load i64, ptr %l10, !tbaa !24
  store i64 %t148, ptr %l91, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  store i64 %t149, ptr %l92, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  store i64 %t150, ptr %l93, !tbaa !24
  %t151 = load i64, ptr %l92, !tbaa !24
  %t152 = load i64, ptr %l93, !tbaa !24
  %t153 = mul i64 %t151, %t152
  store i64 %t153, ptr %l94, !tbaa !24
  %t154 = load i64, ptr %l91, !tbaa !24
  %t155 = load i64, ptr %l94, !tbaa !24
  %t156 = add i64 %t154, %t155
  store i64 %t156, ptr %l95, !tbaa !24
  %t157 = load i64, ptr %l95, !tbaa !24
  store i64 %t157, ptr %l15, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t158, ptr %l96, !tbaa !27
  %t159 = load i64, ptr %l15, !tbaa !24
  store i64 %t159, ptr %l97, !tbaa !24
  %t160 = load i64, ptr %l97, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t160
  %t164 = load i8, ptr %t163, !tbaa !32
  store i8 %t164, ptr %l98, !tbaa !22
  %t165 = load i8, ptr %l98, !tbaa !22
  store i8 %t165, ptr %l16, !tbaa !22
  %t166 = load i8, ptr %l16, !tbaa !22
  store i8 %t166, ptr %l99, !tbaa !22
  %t167 = load i8, ptr %l99, !tbaa !22
  %t168 = icmp eq i8 %t167, 91
  store i1 %t168, ptr %l100, !tbaa !21
  %t169 = load i1, ptr %l100, !tbaa !21
  br i1 %t169, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb40
bb39:
  %t170 = load i8, ptr %l16, !tbaa !22
  store i8 %t170, ptr %l102, !tbaa !22
  %t171 = load i8, ptr %l102, !tbaa !22
  %t172 = icmp eq i8 %t171, 123
  store i1 %t172, ptr %l103, !tbaa !21
  %t173 = load i1, ptr %l103, !tbaa !21
  store i1 %t173, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t174 = load i1, ptr %l101, !tbaa !21
  br i1 %t174, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb43
bb42:
  %t175 = load i8, ptr %l16, !tbaa !22
  store i8 %t175, ptr %l105, !tbaa !22
  %t176 = load i8, ptr %l105, !tbaa !22
  %t177 = icmp eq i8 %t176, 60
  store i1 %t177, ptr %l106, !tbaa !21
  %t178 = load i1, ptr %l106, !tbaa !21
  store i1 %t178, ptr %l104, !tbaa !21
  br label %bb43
bb43:
  %t179 = load i1, ptr %l104, !tbaa !21
  br i1 %t179, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t180 = load i64, ptr %l9, !tbaa !24
  store i64 %t180, ptr %l107, !tbaa !24
  %t181 = load i64, ptr %l107, !tbaa !24
  %t182 = add i64 %t181, 1
  store i64 %t182, ptr %l108, !tbaa !24
  %t183 = load i64, ptr %l108, !tbaa !24
  store i64 %t183, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb58
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t184 = load i8, ptr %l16, !tbaa !22
  store i8 %t184, ptr %l109, !tbaa !22
  %t185 = load i8, ptr %l109, !tbaa !22
  %t186 = icmp eq i8 %t185, 93
  store i1 %t186, ptr %l110, !tbaa !21
  %t187 = load i1, ptr %l110, !tbaa !21
  br i1 %t187, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  %t188 = load i8, ptr %l16, !tbaa !22
  store i8 %t188, ptr %l112, !tbaa !22
  %t189 = load i8, ptr %l112, !tbaa !22
  %t190 = icmp eq i8 %t189, 125
  store i1 %t190, ptr %l113, !tbaa !21
  %t191 = load i1, ptr %l113, !tbaa !21
  store i1 %t191, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l111, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb51
bb50:
  %t193 = load i8, ptr %l16, !tbaa !22
  store i8 %t193, ptr %l115, !tbaa !22
  %t194 = load i8, ptr %l115, !tbaa !22
  %t195 = icmp eq i8 %t194, 62
  store i1 %t195, ptr %l116, !tbaa !21
  %t196 = load i1, ptr %l116, !tbaa !21
  store i1 %t196, ptr %l114, !tbaa !21
  br label %bb51
bb51:
  %t197 = load i1, ptr %l114, !tbaa !21
  br i1 %t197, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t198 = load i64, ptr %l9, !tbaa !24
  store i64 %t198, ptr %l117, !tbaa !24
  %t199 = load i64, ptr %l117, !tbaa !24
  %t200 = sub i64 %t199, 1
  store i64 %t200, ptr %l118, !tbaa !24
  %t201 = load i64, ptr %l118, !tbaa !24
  store i64 %t201, ptr %l9, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  store i64 %t202, ptr %l119, !tbaa !24
  %t203 = load i64, ptr %l119, !tbaa !24
  %t204 = icmp eq i64 %t203, 0
  store i1 %t204, ptr %l120, !tbaa !21
  %t205 = load i1, ptr %l120, !tbaa !21
  br i1 %t205, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t206 = load i64, ptr %l15, !tbaa !24
  store i64 %t206, ptr %l121, !tbaa !24
  %t207 = load i64, ptr %l121, !tbaa !24
  %t208 = add i64 %t207, 1
  store i64 %t208, ptr %l122, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i64, ptr %l122, !tbaa !24
  store i64 %t209, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s12
  %t210 = load i64, ptr %l14, !tbaa !24
  store i64 %t210, ptr %l123, !tbaa !24
  %t211 = load i64, ptr %l123, !tbaa !24
  %t212 = add i64 %t211, 1
  store i64 %t212, ptr %l124, !tbaa !24
  %t213 = load i64, ptr %l124, !tbaa !24
  store i64 %t213, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb34
bb60:
  call void @__olang_scope_close(ptr %s6)
  %t214 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t214, ptr %l125, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l126, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t217 = load i64, ptr %l126, !tbaa !24
  store i64 %t217, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @olang_2einit_2ecompiler_2fruntime() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fruntime_2eArchs_2einit()
  br label %bb1
bb1:
  call void @compiler_2fruntime_2eFactNames_2einit()
  br label %bb2
bb2:
  call void @compiler_2fruntime_2eFactX86_2einit()
  br label %bb3
bb3:
  call void @compiler_2fruntime_2eFactArm_2einit()
  br label %bb4
bb4:
  call void @compiler_2fruntime_2eHeaderTbaa_2einit()
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

@.d0 = private constant [6 x i8] c"x86_64"
@.d1 = private constant [7 x i8] c"aarch64"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
@.c2 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:287: reached unreachable code\0A\00"
@.d3 = private constant [1 x i8] c"}"
@.c4 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:293: slice bounds out of range\0A\00"
@.d5 = private constant [28 x i8] c"define available_externally "
declare void @__olang_sb_put(ptr, ptr, i64)
@.d6 = private constant [1 x i8] c"\0A"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d7 = private constant [17 x i8] c"target triple = \22"
@.d8 = private constant [3 x i8] c"\22\0A\0A"
@.d9 = private constant [19 x i8] c"\0A!20 = !{!\22olang\22}\0A"
@.d10 = private constant [10 x i8] c"STAT_BYTES"
@.d11 = private constant [9 x i8] c"STAT_MODE"
@.d12 = private constant [9 x i8] c"STAT_SIZE"
@.d13 = private constant [13 x i8] c"STAT_MTIM_SEC"
@.d14 = private constant [14 x i8] c"STAT_MTIM_NSEC"
@.d15 = private constant [11 x i8] c"DIRENT_NAME"
@.d16 = private constant [24 x i8] c"SPAWN_FILE_ACTIONS_BYTES"
@.d17 = private constant [18 x i8] c"PTHREAD_ATTR_BYTES"
@.d18 = private constant [13 x i8] c"JMP_BUF_BYTES"
@.d19 = private constant [15 x i8] c"SIGACTION_BYTES"
@.d20 = private constant [15 x i8] c"SIGACTION_FLAGS"
@.d21 = private constant [15 x i8] c"FFI_DEFAULT_ABI"
@.d22 = private constant [9 x i8] c"/runtime/"
@.d23 = private constant [7 x i8] c"olang: "
@.d24 = private constant [23 x i8] c": cannot open this file"
@.d25 = private constant [22 x i8] c"\22; @if\22 inside another"
@.c26 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:81: slice bounds out of range\0A\00"
@.d27 = private constant [1 x i8] c"!"
@.c28 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:83: slice bounds out of range\0A\00"
@.d29 = private constant [1 x i8] c" "
@.c30 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:85: slice bounds out of range\0A\00"
@.d31 = private constant [3 x i8] c"san"
@.d32 = private constant [53 x i8] c"a condition that is neither \22san\22 nor an architecture"
@.d33 = private constant [3 x i8] c"san"
@.d34 = private constant [30 x i8] c"\22; @else\22 with no \22; @if\22 open"
@.d35 = private constant [29 x i8] c"\22; @end\22 with no \22; @if\22 open"
@.d36 = private constant [1 x i8] c";"
@.d37 = private constant [2 x i8] c"@@"
@.c38 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:122: slice bounds out of range\0A\00"
@.c39 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:123: slice bounds out of range\0A\00"
@.d40 = private constant [2 x i8] c"@@"
@.d41 = private constant [31 x i8] c"an \22@@\22 with no \22@@\22 closing it"
@.c42 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:126: slice bounds out of range\0A\00"
@.d43 = private constant [42 x i8] c"an @@NAME@@ the compiler knows no fact for"
@.c44 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:128: reached unreachable code\0A\00"
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.c45 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:131: slice bounds out of range\0A\00"
@.d46 = private constant [24 x i8] c"\22; @if\22 with no \22; @end\22"
@.d47 = private constant [66 x i8] c"!49 = !{!\22scopehdr\22, !20, i64 0}\0A!50 = !{!\22chunkhdr\22, !20, i64 0}\0A"
@.d48 = private constant [50 x i8] c"!59 = !{!49, !49, i64 0}\0A!60 = !{!50, !50, i64 0}\0A"
@.d49 = private constant [17 x i8] c"target triple = \22"
@.d50 = private constant [3 x i8] c"\22\0A\0A"
@.d51 = private constant [10 x i8] c"dyncall.ll"
@.d52 = private constant [10 x i8] c"runtime.ll"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d53 = private constant [6 x i8] c"san.ll"
@.d54 = private constant [1 x i8] c"\0A"
@.c55 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:154: reached unreachable code\0A\00"
@.d56 = private constant [1 x i8] c"@"
@.d57 = private constant [16 x i8] c" = linkonce_odr "
@.d58 = private constant [1 x i8] c" "
@.c59 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:158: slice bounds out of range\0A\00"
@.d60 = private constant [1 x i8] c"$"
@.d61 = private constant [14 x i8] c" = comdat any\0A"
@.d62 = private constant [9 x i8] c", comdat\0A"
@.d63 = private constant [7 x i8] c"define "
@.d64 = private constant [1 x i8] c"{"
@.d65 = private constant [6 x i8] c" !dbg "
@.c66 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:167: slice bounds out of range\0A\00"
@.d67 = private constant [23 x i8] c"@__olang_crash_handler("
@.d68 = private constant [21 x i8] c"@__olang_san_handler("
@.d69 = private constant [3 x i8] c" #1"
@.d70 = private constant [3 x i8] c" #0"
@.c71 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:172: slice bounds out of range\0A\00"
@.d72 = private constant [4 x i8] c"#1 {"
@.d73 = private constant [4 x i8] c"#0 {"
@.d74 = private constant [16 x i8] c"sanitize_thread "
@.d75 = private constant [0 x i8] c""
@.d76 = private constant [41 x i8] c"\0Aattributes #0 = { null_pointer_is_valid "
@.d77 = private constant [3 x i8] c" }\0A"
@.d78 = private constant [40 x i8] c"attributes #1 = { null_pointer_is_valid "
@.d79 = private constant [3 x i8] c" }\0A"
@.d80 = private constant [8 x i8] c"declare "
@.d81 = private constant [1 x i8] c"%"
@.d82 = private constant [8 x i8] c" = type "
@.d83 = private constant [1 x i8] c"@"
@.d84 = private constant [12 x i8] c" = external "
@.d85 = private constant [16 x i8] c"define internal "
@.d86 = private constant [15 x i8] c"define private "
@.d87 = private constant [12 x i8] c" = internal "
@.d88 = private constant [11 x i8] c" = private "
@.d89 = private constant [7 x i8] c"define "
@.d90 = private constant [1 x i8] c"("
@.c91 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:228: slice bounds out of range\0A\00"
@.d92 = private constant [8 x i8] c"declare "
@.d93 = private constant [1 x i8] c"("
@.c94 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:239: slice bounds out of range\0A\00"
@.d95 = private constant [1 x i8] c" "
@.c96 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:241: slice bounds out of range\0A\00"
@.d97 = private constant [2 x i8] c", "
@.c98 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:253: slice bounds out of range\0A\00"
@.d99 = private constant [1 x i8] c"{"
@.c100 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:255: slice bounds out of range\0A\00"
@.d101 = private constant [1 x i8] c")"
@.d102 = private constant [1 x i8] c"\0A"
@.d103 = private constant [1 x i8] c"@"
@.d104 = private constant [3 x i8] c" = "
@.c105 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:260: slice bounds out of range\0A\00"
@.d106 = private constant [12 x i8] c" = external "
@.c107 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:261: slice bounds out of range\0A\00"
@.d108 = private constant [13 x i8] c"thread_local("
@.d109 = private constant [1 x i8] c")"
@.c110 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:264: slice bounds out of range\0A\00"
@.d111 = private constant [1 x i8] c" "
@.c112 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:265: slice bounds out of range\0A\00"
@.d113 = private constant [13 x i8] c"unnamed_addr "
@.c114 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:267: slice bounds out of range\0A\00"
@.d115 = private constant [1 x i8] c" "
@.c116 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:270: slice bounds out of range\0A\00"
@.d117 = private constant [1 x i8] c"\0A"
@.d118 = private constant [3 x i8] c"; @"
@.c119 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:51: slice bounds out of range\0A\00"
@.d120 = private constant [1 x i8] c" "
@.c121 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:54: slice bounds out of range\0A\00"
@.d122 = private constant [2 x i8] c"if"
@.d123 = private constant [4 x i8] c"else"
@.d124 = private constant [3 x i8] c"end"
@.d125 = private constant [7 x i8] c"olang: "
@.d126 = private constant [1 x i8] c":"
@.d127 = private constant [2 x i8] c": "
@.d128 = private constant [7 x i8] c"define "
@.d129 = private constant [16 x i8] c"define internal "
@.d130 = private constant [15 x i8] c"define private "
@.d131 = private constant [12 x i8] c"alwaysinline"
@.d132 = private constant [10 x i8] c"inlinehint"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
