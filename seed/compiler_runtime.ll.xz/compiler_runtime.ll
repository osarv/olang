; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2fruntime_2eArchs = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eArchs.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eArchs.k2 }>, align 32
@G_2ecompiler_2fruntime_2eArchs.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\78\38\36\5F\36\34" }>, align 8
@G_2ecompiler_2fruntime_2eArchs.k2 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\61\61\72\63\68\36\34" }>, align 8
@G_2ecompiler_2fruntime_2eFactArm = constant <{ [120 x i8] }> <{ [120 x i8] c"\80\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\38\01\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\B8\01\00\00\00\00\00\00\A0\01\00\00\00\00\00\00\B0\01\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eFactNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k1, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k2, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k3, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k4, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k5, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k6, [8 x i8] c"\18\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k7, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k8, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k10, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k11, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k12, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k13, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k14, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k15 }>, align 64
@G_2ecompiler_2fruntime_2eFactNames.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\54\41\54\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k2 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\54\41\54\5F\4D\4F\44\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k3 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\54\41\54\5F\53\49\5A\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k4 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\53\54\41\54\5F\4D\54\49\4D\5F\53\45\43" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k5 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\53\54\41\54\5F\4D\54\49\4D\5F\4E\53\45\43" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k6 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\44\49\52\45\4E\54\5F\4E\41\4D\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k7 = internal constant <{ [24 x i8] }> <{ [24 x i8] c"\53\50\41\57\4E\5F\46\49\4C\45\5F\41\43\54\49\4F\4E\53\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k8 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\50\54\48\52\45\41\44\5F\41\54\54\52\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k9 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\4A\4D\50\5F\42\55\46\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\53\49\47\41\43\54\49\4F\4E\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k11 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\53\49\47\41\43\54\49\4F\4E\5F\46\4C\41\47\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k12 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\46\46\49\5F\44\45\46\41\55\4C\54\5F\41\42\49" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k13 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\55\43\5F\50\43" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k14 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\55\43\5F\46\50" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k15 = internal constant <{ [5 x i8] }> <{ [5 x i8] c"\55\43\5F\53\50" }>, align 8
@G_2ecompiler_2fruntime_2eFactX86 = constant <{ [120 x i8] }> <{ [120 x i8] c"\90\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\38\00\00\00\00\00\00\00\C8\00\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\A8\00\00\00\00\00\00\00\78\00\00\00\00\00\00\00\A0\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eHeaderTbaa = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eHeaderTbaa.k1 }>, align 8
@G_2ecompiler_2fruntime_2eHeaderTbaa.k1 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\21\34\39\20\3D\20\21\7B\21\22\73\63\6F\70\65\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\30\20\3D\20\21\7B\21\22\63\68\75\6E\6B\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\39\20\3D\20\21\7B\21\34\39\2C\20\21\34\39\2C\20\69\36\34\20\30\7D\0A\21\36\30\20\3D\20\21\7B\21\35\30\2C\20\21\35\30\2C\20\69\36\34\20\30\7D\0A" }>, align 64
define dso_local { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l7
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l7
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l11
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l11, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  br label %bb30
bb7:
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %l4, !tbaa !27
  %t19 = load i1, ptr %l2, !tbaa !21
  br i1 %t19, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t21)
  br label %bb10
bb9:
  %t24 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t26 = call i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %t24)
  store i1 %t26, ptr %l21
  br label %bb16
bb10:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb11
bb11:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t28, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t30, ptr %l19
  br label %bb12
bb12:
  %t31 = load i1, ptr %l19, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb16:
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l22, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t34, 0
  store i64 %t37, ptr %l26, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l27, !tbaa !24
  %t40 = icmp sge i64 7, 0
  br i1 %t40, label %bb19, label %bb20
bb18:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fruntime_2edeclare(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t42)
  br label %bb26
bb19:
  %t45 = load i64, ptr %l26, !tbaa !24
  %t46 = icmp sle i64 7, %t45
  br i1 %t46, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb21:
  %t48 = load i64, ptr %l26, !tbaa !24
  %t49 = load i64, ptr %l27, !tbaa !24
  %t50 = icmp sle i64 %t48, %t49
  br i1 %t50, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb23:
  %t52 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l26, !tbaa !24
  %t55 = getelementptr i8, ptr %t53, i64 7
  %t56 = sub i64 %t54, 7
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t80 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t80, { i64, ptr } %t79)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_4678f23b07212b71_6204d41da44925a5)
  unreachable
bb25:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb3
bb30:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb31
bb31:
  %t84 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t84, ptr %l38
  br label %bb32
bb32:
  %t85 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t85, ptr %l39, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l40, !tbaa !24
  %t88 = load i64, ptr %l40, !tbaa !24
  %t89 = mul i64 %t88, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  %t91 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l41, !tbaa !27
  %t93 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l40, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  %t99 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t99, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  store i1 %a3, ptr %l3
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = load i1, ptr %l3, !tbaa !21
  %t3 = load i1, ptr %l5, !tbaa !21
  %t7 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t1, i1 %t2, i1 false, i1 %t3)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l14
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  br label %bb3
bb2:
  %t13 = load i32, ptr %l14, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t24, ptr %l6, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = load i1, ptr %l3, !tbaa !21
  %t27 = load i1, ptr %l5, !tbaa !21
  %t31 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t25, i1 %t26, i1 true, i1 %t27)
  %t32 = extractvalue { i32, { i64, ptr } } %t31, 1
  %t33 = extractvalue { i32, { i64, ptr } } %t31, 0
  store i32 %t33, ptr %l21
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb5, label %ok.35, !prof !99
ok.35:
  store { i64, ptr } %t32, ptr %l20
  br label %bb4
bb4:
  %t36 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t36, ptr %l16, !tbaa !27
  br label %bb6
bb5:
  %t37 = load i32, ptr %l21, !tbaa !23
  %t38 = lshr i32 %t37, 16
  %t39 = and i32 %t37, 65535
  %t40 = icmp eq i32 %t38, 1
  %t41 = select i1 %t40, i32 1, i32 0
  %t42 = icmp eq i32 %t37, 0
  %t43 = shl i32 %t41, 16
  %t44 = or i32 %t43, %t39
  %t45 = select i1 %t42, i32 0, i32 %t44
  call void @__olang_scope_close(ptr %s0)
  %t47 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t45, 0
  store { i32, { i64, ptr } } %t47, ptr %rv
  br label %ret
bb6:
  %t48 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  store { i64, ptr } %a0, ptr %l23, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t52 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s0, { i64, ptr } %t50)
  store { i64, ptr } %t52, ptr %l25
  br label %bb7
bb7:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t57 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t69 = extractvalue { i64, ptr } %t53, 1
  %t70 = extractvalue { i64, ptr } %t53, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t76 = extractvalue { i64, ptr } %t54, 1
  %t77 = extractvalue { i64, ptr } %t54, 0
  %t78 = add i64 %t74, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t55, i64 %t56)
  %t80 = getelementptr i8, ptr %t79, i64 %t56
  call void @olang_textcopy(ptr %t80, ptr %t58, i64 %t59)
  %t81 = getelementptr i8, ptr %t80, i64 %t59
  call void @olang_textcopy(ptr %t81, ptr %t61, i64 %t62)
  %t82 = getelementptr i8, ptr %t81, i64 %t62
  call void @olang_textcopy(ptr %t82, ptr %t65, i64 %t66)
  %t83 = getelementptr i8, ptr %t82, i64 %t66
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t72, i64 %t73)
  %t85 = getelementptr i8, ptr %t84, i64 %t73
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t79, 1
  %t95 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t87, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t95, ptr %l32
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t97 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t96, 1
  store { i32, { i64, ptr } } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/text:LineIter"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l36 = alloca i1
  %l40 = alloca i32
  %l42 = alloca i1
  %l47 = alloca i64
  %l48 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca %"std/prelude/text:LineIter"
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l56 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca i64
  %l75 = alloca i64
  %l81 = alloca i32
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l92 = alloca { i64, ptr }
  %l94 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca i64
  %l105 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l119 = alloca i1
  %l121 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i32
  %l133 = alloca i1
  %l134 = alloca i1
  %l138 = alloca i1
  %l147 = alloca i1
  %l151 = alloca i32
  %l161 = alloca i32
  %l166 = alloca { i64, ptr }
  %l167 = alloca i1
  %l172 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i32
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca i64
  %l188 = alloca { i64, ptr }
  %l190 = alloca i64
  %l193 = alloca i64
  %l194 = alloca i64
  %l199 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i32
  %l207 = alloca i32
  %l209 = alloca i64
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca i64
  %l218 = alloca i64
  %l219 = alloca i32
  %l221 = alloca i1
  %l224 = alloca i32
  %l230 = alloca { i64, ptr }
  %l232 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l245 = alloca i32
  %l248 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l28
  br label %bb1
bb1:
  %t3 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t6 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t21 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t19)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l34
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25, !prof !99
ok.25:
  store { i64, ptr } %t22, ptr %l33
  br label %bb2
bb2:
  %t26 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t26, ptr %l31, !tbaa !27
  br label %bb9
bb3:
  %t27 = load i32, ptr %l34, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  store i1 %t30, ptr %l36, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t35, i64 %t36)
  %t43 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t43, ptr %t38, i64 %t39)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = call i32 @std_2fio_2ePrintErrln(ptr %s2, { i64, ptr } %t52)
  store i32 %t54, ptr %l40
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  br label %bb5
bb5:
  br label %bb8
bb6:
  %t57 = load i32, ptr %l40, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l42, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t62 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t62, ptr %rv
  br label %ret
bb9:
  %t63 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = call i64 @compiler_2fruntime_2earchRow(ptr %v1, { i64, ptr } %t67)
  store i64 %t69, ptr %l47
  br label %bb10
bb10:
  %t70 = load i64, ptr %l47, !tbaa !24
  store i64 %t70, ptr %l7, !tbaa !24
  %t71 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t71, ptr %l48
  br label %bb11
bb11:
  %t72 = load %"std/prelude/text:StringBuilder", ptr %l48
  store %"std/prelude/text:StringBuilder" %t72, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t73)
  store %"std/prelude/text:LineIter" %t75, ptr %l50
  br label %bb12
bb12:
  %t76 = load %"std/prelude/text:LineIter", ptr %l50
  store %"std/prelude/text:LineIter" %t76, ptr %l14
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l14)
  %t79 = extractvalue { i32, { i64, ptr } } %t78, 1
  %t80 = extractvalue { i32, { i64, ptr } } %t78, 0
  store i32 %t80, ptr %l54
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb15, label %ok.82, !prof !99
ok.82:
  store { i64, ptr } %t79, ptr %l53
  br label %bb14
bb14:
  %t83 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t83, ptr %l51, !tbaa !27
  br label %bb17
bb15:
  %t84 = load i32, ptr %l54, !tbaa !23
  %t85 = ashr i32 %t84, 16
  %t87 = icmp eq i32 %t85, 1
  store i1 %t87, ptr %l56, !tbaa !21
  br label %bb16
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb174
bb17:
  %t88 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t88, ptr %l15, !tbaa !27
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l9, !tbaa !24
  br i1 %a3, label %bb18, label %bb19
bb18:
  %t95 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t95, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t97, ptr %l62
  br label %bb20
bb19:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb21
bb20:
  %t98 = load i1, ptr %l62, !tbaa !21
  store i1 %t98, ptr %l60, !tbaa !21
  br label %bb21
bb21:
  %t99 = load i1, ptr %l60, !tbaa !21
  br i1 %t99, label %bb22, label %bb23
bb22:
  %t100 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t100, ptr %l64, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t101, 0
  store i64 %t104, ptr %l67, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l68, !tbaa !24
  %t107 = icmp sge i64 8, 0
  br i1 %t107, label %bb24, label %bb25
bb23:
  %t109 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t109, ptr %l63, !tbaa !27
  br label %bb30
bb24:
  %t111 = load i64, ptr %l67, !tbaa !24
  %t112 = icmp sle i64 8, %t111
  br i1 %t112, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb26:
  %t114 = load i64, ptr %l67, !tbaa !24
  %t115 = load i64, ptr %l68, !tbaa !24
  %t116 = icmp sle i64 %t114, %t115
  br i1 %t116, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb28:
  %t118 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l67, !tbaa !24
  %t121 = getelementptr i8, ptr %t119, i64 8
  %t122 = sub i64 %t120, 8
  %t123 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t121, 1
  store { i64, ptr } %t124, ptr %l63, !tbaa !27
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f)
  unreachable
bb30:
  %t126 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t126, ptr %l16, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t129 = call i64 @compiler_2fruntime_2edirective(ptr %s0, { i64, ptr } %t127)
  store i64 %t129, ptr %l75
  br label %bb31
bb31:
  %t130 = load i64, ptr %l75, !tbaa !24
  store i64 %t130, ptr %l17, !tbaa !24
  %t131 = load i64, ptr %l17, !tbaa !24
  %t133 = icmp eq i64 %t131, 0
  br i1 %t133, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t135 = load i1, ptr %l10, !tbaa !21
  br i1 %t135, label %bb34, label %bb35
bb33:
  br label %bb86
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t137 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s8, { i64, ptr } %t137, i64 %t138, { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i32 %t141, ptr %l81
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb37, label %ok.143, !prof !99
ok.143:
  br label %bb36
bb35:
  br label %bb39
bb36:
  br label %bb38
bb37:
  %t144 = load i32, ptr %l81, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t154 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t152, 0
  store { i32, { i64, ptr } } %t154, ptr %rv
  br label %ret
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  %t155 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t155, ptr %l83, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t156, 0
  store i64 %t159, ptr %l86, !tbaa !24
  %t160 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l87, !tbaa !24
  %t162 = icmp sge i64 6, 0
  br i1 %t162, label %bb40, label %bb41
bb40:
  %t164 = load i64, ptr %l86, !tbaa !24
  %t165 = icmp sle i64 6, %t164
  br i1 %t165, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb42:
  %t167 = load i64, ptr %l86, !tbaa !24
  %t168 = load i64, ptr %l87, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  br i1 %t169, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb44:
  %t171 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l86, !tbaa !24
  %t174 = getelementptr i8, ptr %t172, i64 6
  %t175 = sub i64 %t173, 6
  %t176 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  %t179 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t177)
  store { i64, ptr } %t179, ptr %l92
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2)
  unreachable
bb46:
  %t180 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t180, ptr %l18, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t183 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t181, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t183, ptr %l94
  br label %bb47
bb47:
  %t184 = load i1, ptr %l94, !tbaa !21
  store i1 %t184, ptr %l19, !tbaa !21
  %t185 = load i1, ptr %l19, !tbaa !21
  br i1 %t185, label %bb48, label %bb49
bb48:
  %t187 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t187, ptr %l96, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t188, 0
  store i64 %t191, ptr %l99, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l100, !tbaa !24
  %t194 = icmp sge i64 1, 0
  br i1 %t194, label %bb50, label %bb51
bb49:
  br label %bb56
bb50:
  %t196 = load i64, ptr %l99, !tbaa !24
  %t197 = icmp sle i64 1, %t196
  br i1 %t197, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb52:
  %t199 = load i64, ptr %l99, !tbaa !24
  %t200 = load i64, ptr %l100, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  br i1 %t201, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb54:
  %t203 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = load i64, ptr %l99, !tbaa !24
  %t206 = getelementptr i8, ptr %t204, i64 1
  %t207 = sub i64 %t205, 1
  %t208 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  store { i64, ptr } %t209, ptr %l18, !tbaa !27
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71)
  unreachable
bb56:
  %t211 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t213 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s7, { i64, ptr } %t211, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  %t214 = extractvalue { i32, i64 } %t213, 1
  %t215 = extractvalue { i32, i64 } %t213, 0
  store i32 %t215, ptr %l108
  %t216 = icmp ne i32 %t215, 0
  br i1 %t216, label %bb58, label %ok.217, !prof !99
ok.217:
  store i64 %t214, ptr %l107
  br label %bb57
bb57:
  %t218 = load i64, ptr %l107, !tbaa !24
  store i64 %t218, ptr %l105, !tbaa !24
  br label %bb60
bb58:
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l105, !tbaa !24
  br label %bb60
bb60:
  %t219 = load i64, ptr %l105, !tbaa !24
  store i64 %t219, ptr %l20, !tbaa !24
  %t220 = load i64, ptr %l20, !tbaa !24
  %t222 = icmp sge i64 %t220, 0
  br i1 %t222, label %bb61, label %bb62
bb61:
  %t224 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t224, ptr %l111, !tbaa !27
  %t225 = load i64, ptr %l20, !tbaa !24
  store i64 %t225, ptr %l112, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 0
  store i64 %t227, ptr %l113, !tbaa !24
  %t228 = icmp sge i64 0, 0
  br i1 %t228, label %bb63, label %bb64
bb62:
  br label %bb69
bb63:
  %t230 = load i64, ptr %l112, !tbaa !24
  %t231 = icmp sle i64 0, %t230
  br i1 %t231, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb65:
  %t233 = load i64, ptr %l112, !tbaa !24
  %t234 = load i64, ptr %l113, !tbaa !24
  %t235 = icmp sle i64 %t233, %t234
  br i1 %t235, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb67:
  %t237 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = load i64, ptr %l112, !tbaa !24
  %t240 = getelementptr i8, ptr %t238, i64 0
  %t241 = sub i64 %t239, 0
  %t242 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  store { i64, ptr } %t243, ptr %l18, !tbaa !27
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5fea096add1795b8_392858cd9c11d804)
  unreachable
bb69:
  %t245 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t247 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t245, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t247, ptr %l119
  br label %bb70
bb70:
  %t248 = load i1, ptr %l119, !tbaa !21
  %t249 = xor i1 %t248, true
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t254 = insertvalue { i64, ptr } undef, i64 2, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr @G_2ecompiler_2fruntime_2eArchs, 1
  %t257 = load ptr, ptr @__olang_prog_scope
  %t260 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t257, ptr %s0, { i64, ptr } %t255, { i64, ptr } %t251)
  store i1 %t260, ptr %l126
  br label %bb73
bb72:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb74
bb73:
  %t261 = load i1, ptr %l126, !tbaa !21
  %t262 = xor i1 %t261, true
  store i1 %t262, ptr %l121, !tbaa !21
  br label %bb74
bb74:
  %t264 = load i1, ptr %l121, !tbaa !21
  br i1 %t264, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s11
  %t265 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t266 = load i64, ptr %l9, !tbaa !24
  %t269 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s11, { i64, ptr } %t265, i64 %t266, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i32 %t269, ptr %l130
  %t270 = icmp ne i32 %t269, 0
  br i1 %t270, label %bb78, label %ok.271, !prof !99
ok.271:
  br label %bb77
bb76:
  br label %bb80
bb77:
  br label %bb79
bb78:
  %t272 = load i32, ptr %l130, !tbaa !23
  %t273 = lshr i32 %t272, 16
  %t274 = and i32 %t272, 65535
  %t275 = icmp eq i32 %t273, 1
  %t276 = select i1 %t275, i32 1, i32 0
  %t277 = icmp eq i32 %t272, 0
  %t278 = shl i32 %t276, 16
  %t279 = or i32 %t278, %t274
  %t280 = select i1 %t277, i32 0, i32 %t279
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t282 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t280, 0
  store { i32, { i64, ptr } } %t282, ptr %rv
  br label %ret
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb80
bb80:
  %t283 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t285 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t283, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t285, ptr %l133
  br label %bb81
bb81:
  %t286 = load i1, ptr %l133, !tbaa !21
  br i1 %t286, label %bb82, label %bb83
bb82:
  store i1 %a2, ptr %l134, !tbaa !21
  br label %bb85
bb83:
  %t289 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t293 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t289, { i64, ptr } %t290)
  store i1 %t293, ptr %l138
  br label %bb84
bb84:
  %t294 = load i1, ptr %l138, !tbaa !21
  store i1 %t294, ptr %l134, !tbaa !21
  br label %bb85
bb85:
  %t295 = load i1, ptr %l134, !tbaa !21
  %t297 = load i1, ptr %l19, !tbaa !21
  %t300 = icmp ne i1 %t295, %t297
  store i1 %t300, ptr %l12, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  %t302 = load i64, ptr %l9, !tbaa !24
  store i64 %t302, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb86:
  %t304 = load i64, ptr %l17, !tbaa !24
  %t306 = icmp eq i64 %t304, 1
  br i1 %t306, label %bb87, label %bb88
bb87:
  %t308 = load i1, ptr %l10, !tbaa !21
  %t310 = xor i1 %t308, true
  br i1 %t310, label %bb89, label %bb90
bb88:
  br label %bb98
bb89:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb91
bb90:
  %t312 = load i1, ptr %l11, !tbaa !21
  store i1 %t312, ptr %l147, !tbaa !21
  br label %bb91
bb91:
  %t314 = load i1, ptr %l147, !tbaa !21
  br i1 %t314, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s13
  %t315 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t316 = load i64, ptr %l9, !tbaa !24
  %t319 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s13, { i64, ptr } %t315, i64 %t316, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d16, i32 0, i32 1) })
  store i32 %t319, ptr %l151
  %t320 = icmp ne i32 %t319, 0
  br i1 %t320, label %bb95, label %ok.321, !prof !99
ok.321:
  br label %bb94
bb93:
  br label %bb97
bb94:
  br label %bb96
bb95:
  %t322 = load i32, ptr %l151, !tbaa !23
  %t323 = lshr i32 %t322, 16
  %t324 = and i32 %t322, 65535
  %t325 = icmp eq i32 %t323, 1
  %t326 = select i1 %t325, i32 1, i32 0
  %t327 = icmp eq i32 %t322, 0
  %t328 = shl i32 %t326, 16
  %t329 = or i32 %t328, %t324
  %t330 = select i1 %t327, i32 0, i32 %t329
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t332 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t330, 0
  store { i32, { i64, ptr } } %t332, ptr %rv
  br label %ret
bb96:
  call void @__olang_scope_close(ptr %s13)
  br label %bb97
bb97:
  %t333 = load i1, ptr %l12, !tbaa !21
  %t335 = xor i1 %t333, true
  store i1 %t335, ptr %l12, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb98:
  %t337 = load i64, ptr %l17, !tbaa !24
  %t339 = icmp eq i64 %t337, 2
  br i1 %t339, label %bb99, label %bb100
bb99:
  %t341 = load i1, ptr %l10, !tbaa !21
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb101, label %bb102
bb100:
  br label %bb107
bb101:
  store %olang.scope zeroinitializer, ptr %s15
  %t345 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t346 = load i64, ptr %l9, !tbaa !24
  %t349 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s15, { i64, ptr } %t345, i64 %t346, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d17, i32 0, i32 1) })
  store i32 %t349, ptr %l161
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb104, label %ok.351, !prof !99
ok.351:
  br label %bb103
bb102:
  br label %bb106
bb103:
  br label %bb105
bb104:
  %t352 = load i32, ptr %l161, !tbaa !23
  %t353 = lshr i32 %t352, 16
  %t354 = and i32 %t352, 65535
  %t355 = icmp eq i32 %t353, 1
  %t356 = select i1 %t355, i32 1, i32 0
  %t357 = icmp eq i32 %t352, 0
  %t358 = shl i32 %t356, 16
  %t359 = or i32 %t358, %t354
  %t360 = select i1 %t357, i32 0, i32 %t359
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t362 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t360, 0
  store { i32, { i64, ptr } } %t362, ptr %rv
  br label %ret
bb105:
  call void @__olang_scope_close(ptr %s15)
  br label %bb106
bb106:
  store i1 false, ptr %l10, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb107:
  %t363 = load i1, ptr %l12, !tbaa !21
  %t365 = xor i1 %t363, true
  br i1 %t365, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb109:
  br label %bb110
bb110:
  %t367 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t369 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t367)
  store { i64, ptr } %t369, ptr %l166
  br label %bb111
bb111:
  %t370 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t371 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t370, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t371, ptr %l167
  br label %bb112
bb112:
  %t372 = load i1, ptr %l167, !tbaa !21
  br i1 %t372, label %bb113, label %bb114
bb113:
  %t373 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t373)
  br label %bb115
bb114:
  br label %bb117
bb115:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 10)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb117:
  %t377 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t377, ptr %l23, !tbaa !27
  br label %bb118
bb118:
  store %olang.scope zeroinitializer, ptr %s18
  %t379 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t381 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t379, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  %t382 = extractvalue { i32, i64 } %t381, 1
  %t383 = extractvalue { i32, i64 } %t381, 0
  store i32 %t383, ptr %l175
  %t384 = icmp ne i32 %t383, 0
  br i1 %t384, label %bb120, label %ok.385, !prof !99
ok.385:
  store i64 %t382, ptr %l174
  br label %bb119
bb119:
  %t386 = load i64, ptr %l174, !tbaa !24
  store i64 %t386, ptr %l172, !tbaa !24
  br label %bb122
bb120:
  br label %bb121
bb121:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l172, !tbaa !24
  br label %bb122
bb122:
  %t387 = load i64, ptr %l172, !tbaa !24
  store i64 %t387, ptr %l24, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  %t390 = icmp slt i64 %t388, 0
  br i1 %t390, label %bb123, label %bb124
bb123:
  %t392 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l8, { i64, ptr } %t392)
  br label %bb125
bb124:
  br label %bb126
bb125:
  call void @__olang_scope_close(ptr %s18)
  br label %bb171
bb126:
  store ptr %l8, ptr %l180, !tbaa !29
  %t395 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t395, ptr %l181, !tbaa !27
  %t396 = load i64, ptr %l24, !tbaa !24
  store i64 %t396, ptr %l182, !tbaa !24
  %t397 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  store i64 %t398, ptr %l183, !tbaa !24
  %t399 = icmp sge i64 0, 0
  br i1 %t399, label %bb127, label %bb128
bb127:
  %t401 = load i64, ptr %l182, !tbaa !24
  %t402 = icmp sle i64 0, %t401
  br i1 %t402, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb129:
  %t404 = load i64, ptr %l182, !tbaa !24
  %t405 = load i64, ptr %l183, !tbaa !24
  %t406 = icmp sle i64 %t404, %t405
  br i1 %t406, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb131:
  %t408 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = load i64, ptr %l182, !tbaa !24
  %t411 = getelementptr i8, ptr %t409, i64 0
  %t412 = sub i64 %t410, 0
  %t413 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t414 = insertvalue { i64, ptr } %t413, ptr %t411, 1
  %t415 = load ptr, ptr %l180, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t415, { i64, ptr } %t414)
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b)
  unreachable
bb133:
  %t417 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t417, ptr %l188, !tbaa !27
  %t418 = load i64, ptr %l24, !tbaa !24
  %t420 = add i64 %t418, 2
  store i64 %t420, ptr %l190, !tbaa !24
  %t421 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t424 = extractvalue { i64, ptr } %t421, 0
  store i64 %t424, ptr %l193, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 0
  store i64 %t426, ptr %l194, !tbaa !24
  %t427 = load i64, ptr %l190, !tbaa !24
  %t428 = icmp sge i64 %t427, 0
  br i1 %t428, label %bb134, label %bb135
bb134:
  %t430 = load i64, ptr %l190, !tbaa !24
  %t431 = load i64, ptr %l193, !tbaa !24
  %t432 = icmp sle i64 %t430, %t431
  br i1 %t432, label %bb136, label %bb137
bb135:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb136:
  %t434 = load i64, ptr %l193, !tbaa !24
  %t435 = load i64, ptr %l194, !tbaa !24
  %t436 = icmp sle i64 %t434, %t435
  br i1 %t436, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb138:
  %t438 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = load i64, ptr %l190, !tbaa !24
  %t441 = load i64, ptr %l193, !tbaa !24
  %t442 = getelementptr i8, ptr %t439, i64 %t440
  %t443 = sub i64 %t441, %t440
  %t444 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t442, 1
  store { i64, ptr } %t445, ptr %l25, !tbaa !27
  %t447 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t449 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t447, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) })
  %t450 = extractvalue { i32, i64 } %t449, 1
  %t451 = extractvalue { i32, i64 } %t449, 0
  store i32 %t451, ptr %l202
  %t452 = icmp ne i32 %t451, 0
  br i1 %t452, label %bb141, label %ok.453, !prof !99
ok.453:
  store i64 %t450, ptr %l201
  br label %bb140
bb139:
  call void @__olang_check_failed(ptr @olang_loc_70ff22b8cac083da_c5bb23930b7510e)
  unreachable
bb140:
  %t454 = load i64, ptr %l201, !tbaa !24
  store i64 %t454, ptr %l199, !tbaa !24
  br label %bb143
bb141:
  br label %bb142
bb142:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l199, !tbaa !24
  br label %bb143
bb143:
  %t455 = load i64, ptr %l199, !tbaa !24
  store i64 %t455, ptr %l26, !tbaa !24
  %t456 = load i64, ptr %l26, !tbaa !24
  %t458 = icmp slt i64 %t456, 0
  br i1 %t458, label %bb144, label %bb145
bb144:
  store %olang.scope zeroinitializer, ptr %s20
  %t460 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t461 = load i64, ptr %l9, !tbaa !24
  %t464 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s20, { i64, ptr } %t460, i64 %t461, { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t464, ptr %l207
  %t465 = icmp ne i32 %t464, 0
  br i1 %t465, label %bb147, label %ok.466, !prof !99
ok.466:
  br label %bb146
bb145:
  br label %bb149
bb146:
  br label %bb148
bb147:
  %t467 = load i32, ptr %l207, !tbaa !23
  %t468 = lshr i32 %t467, 16
  %t469 = and i32 %t467, 65535
  %t470 = icmp eq i32 %t468, 1
  %t471 = select i1 %t470, i32 1, i32 0
  %t472 = icmp eq i32 %t467, 0
  %t473 = shl i32 %t471, 16
  %t474 = or i32 %t473, %t469
  %t475 = select i1 %t472, i32 0, i32 %t474
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t477 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t475, 0
  store { i32, { i64, ptr } } %t477, ptr %rv
  br label %ret
bb148:
  call void @__olang_scope_close(ptr %s20)
  br label %bb149
bb149:
  %t478 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t478, ptr %l210, !tbaa !27
  %t479 = load i64, ptr %l26, !tbaa !24
  store i64 %t479, ptr %l211, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t480, 0
  store i64 %t481, ptr %l212, !tbaa !24
  %t482 = icmp sge i64 0, 0
  br i1 %t482, label %bb150, label %bb151
bb150:
  %t484 = load i64, ptr %l211, !tbaa !24
  %t485 = icmp sle i64 0, %t484
  br i1 %t485, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb152:
  %t487 = load i64, ptr %l211, !tbaa !24
  %t488 = load i64, ptr %l212, !tbaa !24
  %t489 = icmp sle i64 %t487, %t488
  br i1 %t489, label %bb154, label %bb155
bb153:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb154:
  %t491 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = load i64, ptr %l211, !tbaa !24
  %t494 = getelementptr i8, ptr %t492, i64 0
  %t495 = sub i64 %t493, 0
  %t496 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t494, 1
  %t498 = load i64, ptr %l7, !tbaa !24
  %t501 = call { i32, i64 } @compiler_2fruntime_2efact(ptr %s0, { i64, ptr } %t497, i64 %t498)
  %t502 = extractvalue { i32, i64 } %t501, 1
  %t503 = extractvalue { i32, i64 } %t501, 0
  store i32 %t503, ptr %l219
  %t504 = icmp ne i32 %t503, 0
  br i1 %t504, label %bb157, label %ok.505, !prof !99
ok.505:
  store i64 %t502, ptr %l218
  br label %bb156
bb155:
  call void @__olang_check_failed(ptr @olang_loc_fb2acf0450ba6c79_597b56b8350f036d)
  unreachable
bb156:
  %t506 = load i64, ptr %l218, !tbaa !24
  store i64 %t506, ptr %l209, !tbaa !24
  br label %bb162
bb157:
  %t507 = load i32, ptr %l219, !tbaa !23
  %t508 = ashr i32 %t507, 16
  %t510 = icmp eq i32 %t508, 1
  store i1 %t510, ptr %l221, !tbaa !21
  br label %bb158
bb158:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s21
  %t511 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t512 = load i64, ptr %l9, !tbaa !24
  %t515 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s21, { i64, ptr } %t511, i64 %t512, { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i32 %t515, ptr %l224
  %t516 = icmp ne i32 %t515, 0
  br i1 %t516, label %bb160, label %ok.517, !prof !99
ok.517:
  br label %bb159
bb159:
  br label %bb161
bb160:
  %t518 = load i32, ptr %l224, !tbaa !23
  %t519 = lshr i32 %t518, 16
  %t520 = and i32 %t518, 65535
  %t521 = icmp eq i32 %t519, 1
  %t522 = select i1 %t521, i32 1, i32 0
  %t523 = icmp eq i32 %t518, 0
  %t524 = shl i32 %t522, 16
  %t525 = or i32 %t524, %t520
  %t526 = select i1 %t523, i32 0, i32 %t525
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t528 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t526, 0
  store { i32, { i64, ptr } } %t528, ptr %rv
  br label %ret
bb161:
  call void @__olang_check_failed(ptr @olang_loc_950f08410a2cb2bb_86fc761ab025eedf)
  unreachable
bb162:
  %t529 = load i64, ptr %l209, !tbaa !24
  %t532 = call i64 @__olang_fmt_i64(ptr null, i64 %t529)
  %t533 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t532)
  %t534 = call i64 @__olang_fmt_i64(ptr %t533, i64 %t529)
  %t535 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t536 = insertvalue { i64, ptr } %t535, ptr %t533, 1
  %t538 = extractvalue { i64, ptr } %t536, 0
  %t539 = extractvalue { i64, ptr } %t536, 1
  %t540 = mul i64 %t538, 1
  %t541 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t540)
  call void @llvm.memcpy.p0.p0.i64(ptr %t541, ptr %t539, i64 %t540, i1 false)
  %t542 = insertvalue { i64, ptr } undef, i64 %t538, 0
  %t543 = insertvalue { i64, ptr } %t542, ptr %t541, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l8, { i64, ptr } %t543)
  br label %bb163
bb163:
  %t546 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t546, ptr %l230, !tbaa !27
  %t547 = load i64, ptr %l26, !tbaa !24
  %t549 = add i64 %t547, 2
  store i64 %t549, ptr %l232, !tbaa !24
  %t550 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t550, 0
  store i64 %t553, ptr %l235, !tbaa !24
  %t554 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t554, 0
  store i64 %t555, ptr %l236, !tbaa !24
  %t556 = load i64, ptr %l232, !tbaa !24
  %t557 = icmp sge i64 %t556, 0
  br i1 %t557, label %bb164, label %bb165
bb164:
  %t559 = load i64, ptr %l232, !tbaa !24
  %t560 = load i64, ptr %l235, !tbaa !24
  %t561 = icmp sle i64 %t559, %t560
  br i1 %t561, label %bb166, label %bb167
bb165:
  call void @__olang_check_failed(ptr @olang_loc_854a38a00260b8ab_4f9c9ff368cf0b17)
  unreachable
bb166:
  %t563 = load i64, ptr %l235, !tbaa !24
  %t564 = load i64, ptr %l236, !tbaa !24
  %t565 = icmp sle i64 %t563, %t564
  br i1 %t565, label %bb168, label %bb169
bb167:
  call void @__olang_check_failed(ptr @olang_loc_854a38a00260b8ab_4f9c9ff368cf0b17)
  unreachable
bb168:
  %t567 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !27
  %t569 = load i64, ptr %l232, !tbaa !24
  %t570 = load i64, ptr %l235, !tbaa !24
  %t571 = getelementptr i8, ptr %t568, i64 %t569
  %t572 = sub i64 %t570, %t569
  %t573 = insertvalue { i64, ptr } undef, i64 %t572, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t571, 1
  store { i64, ptr } %t574, ptr %l23, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb170
bb169:
  call void @__olang_check_failed(ptr @olang_loc_854a38a00260b8ab_4f9c9ff368cf0b17)
  unreachable
bb170:
  br label %bb118
bb171:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l8, i8 10)
  br label %bb172
bb172:
  call void @__olang_scope_close(ptr %s6)
  br label %bb173
bb173:
  br label %bb13
bb174:
  %t577 = load i1, ptr %l10, !tbaa !21
  br i1 %t577, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s23
  %t579 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t580 = load i64, ptr %l13, !tbaa !24
  %t583 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s23, { i64, ptr } %t579, i64 %t580, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i32 %t583, ptr %l245
  %t584 = icmp ne i32 %t583, 0
  br i1 %t584, label %bb178, label %ok.585, !prof !99
ok.585:
  br label %bb177
bb176:
  br label %bb180
bb177:
  br label %bb179
bb178:
  %t586 = load i32, ptr %l245, !tbaa !23
  %t587 = lshr i32 %t586, 16
  %t588 = and i32 %t586, 65535
  %t589 = icmp eq i32 %t587, 1
  %t590 = select i1 %t589, i32 1, i32 0
  %t591 = icmp eq i32 %t586, 0
  %t592 = shl i32 %t590, 16
  %t593 = or i32 %t592, %t588
  %t594 = select i1 %t591, i32 0, i32 %t593
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t596 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t594, 0
  store { i32, { i64, ptr } } %t596, ptr %rv
  br label %ret
bb179:
  call void @__olang_scope_close(ptr %s23)
  br label %bb180
bb180:
  %t598 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l8)
  store { i64, ptr } %t598, ptr %l248
  br label %bb181
bb181:
  %t599 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t599, ptr %l249, !tbaa !27
  %t600 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t601 = extractvalue { i64, ptr } %t600, 0
  store i64 %t601, ptr %l250, !tbaa !24
  %t602 = load i64, ptr %l250, !tbaa !24
  %t603 = mul i64 %t602, 1
  %t604 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t603)
  %t605 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t606 = insertvalue { i64, ptr } %t605, ptr %t604, 1
  store { i64, ptr } %t606, ptr %l251, !tbaa !27
  %t607 = getelementptr { i64, ptr }, ptr %l251, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t610 = load ptr, ptr %t609, !tbaa !27
  %t611 = load i64, ptr %l250, !tbaa !24
  %t612 = mul i64 %t611, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t608, ptr %t610, i64 %t612, i1 false)
  %t613 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t613, ptr %l249, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t614 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t615 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t614, 1
  store { i32, { i64, ptr } } %t615, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %a1, i1 %a3, i1 false, i1 %a5)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  br label %bb3
bb2:
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb3:
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t27 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %a0, 1
  %t31 = extractvalue { i64, ptr } %a0, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = extractvalue { i64, ptr } %t24, 1
  %t38 = extractvalue { i64, ptr } %t24, 0
  %t39 = add i64 %t35, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = getelementptr i8, ptr %t41, i64 %t31
  call void @olang_textcopy(ptr %t42, ptr %t33, i64 %t34)
  %t43 = getelementptr i8, ptr %t42, i64 %t34
  call void @olang_textcopy(ptr %t43, ptr %t37, i64 %t38)
  %t44 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t40, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t58 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v3, ptr %v2, ptr %v3, { i64, ptr } %t52, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t58, ptr %l20
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t59, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l3 = alloca i1
  %lp4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l29 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca { i64, ptr }
  %l44 = alloca i64
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load i1, ptr %l1, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  %t9 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d26, i32 0, i32 1) }, { i64, ptr } %t3, i1 %t4, i1 %t5)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13, !prof !99
ok.13:
  store { i64, ptr } %t10, ptr %l10
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t14, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t23, 0
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb5:
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t26, 1
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb6:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = load i1, ptr %l1, !tbaa !21
  %t30 = load i1, ptr %l3, !tbaa !21
  %t34 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } %t28, i1 %t29, i1 %t30)
  %t35 = extractvalue { i32, { i64, ptr } } %t34, 1
  %t36 = extractvalue { i32, { i64, ptr } } %t34, 0
  store i32 %t36, ptr %l18
  %t37 = icmp ne i32 %t36, 0
  br i1 %t37, label %bb8, label %ok.38, !prof !99
ok.38:
  store { i64, ptr } %t35, ptr %l17
  br label %bb7
bb7:
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t39, ptr %l13, !tbaa !27
  br label %bb9
bb8:
  %t40 = load i32, ptr %l18, !tbaa !23
  %t41 = lshr i32 %t40, 16
  %t42 = and i32 %t40, 65535
  %t43 = icmp eq i32 %t41, 1
  %t44 = select i1 %t43, i32 1, i32 0
  %t45 = icmp eq i32 %t40, 0
  %t46 = shl i32 %t44, 16
  %t47 = or i32 %t46, %t42
  %t48 = select i1 %t45, i32 0, i32 %t47
  %t50 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t48, 0
  store { i32, { i64, ptr } } %t50, ptr %rv
  br label %ret
bb9:
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t51, ptr %lp4
  %t52 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t53 = load ptr, ptr %lp4
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load i1, ptr %l1, !tbaa !21
  br i1 %t54, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t56 = load ptr, ptr %lp4
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l21, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = load i1, ptr %l1, !tbaa !21
  %t60 = load i1, ptr %l3, !tbaa !21
  %t64 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s2, ptr %v0, ptr %s2, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } %t58, i1 %t59, i1 %t60)
  %t65 = extractvalue { i32, { i64, ptr } } %t64, 1
  %t66 = extractvalue { i32, { i64, ptr } } %t64, 0
  store i32 %t66, ptr %l27
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb13, label %ok.68, !prof !99
ok.68:
  store { i64, ptr } %t65, ptr %l26
  br label %bb12
bb11:
  br label %bb18
bb12:
  %t69 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t69, ptr %l22, !tbaa !27
  br label %bb14
bb13:
  %t70 = load i32, ptr %l27, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s2)
  %t80 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t78, 0
  store { i32, { i64, ptr } } %t80, ptr %rv
  br label %ret
bb14:
  %t81 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 1
  %t89 = extractvalue { i64, ptr } %t87, 0
  %t90 = add i64 %t86, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t82, i64 %t83)
  %t92 = getelementptr i8, ptr %t91, i64 %t83
  call void @olang_textcopy(ptr %t92, ptr %t84, i64 %t85)
  %t93 = getelementptr i8, ptr %t92, i64 %t85
  call void @olang_textcopy(ptr %t93, ptr %t88, i64 %t89)
  %t94 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t91, 1
  store { i64, ptr } %t95, ptr %l29, !tbaa !27
  %t96 = load ptr, ptr %lp4
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l31, !tbaa !24
  %t102 = load i64, ptr %l31, !tbaa !24
  %t103 = icmp eq i64 %t98, %t102
  br i1 %t103, label %bb15, label %bb16
bb15:
  %t105 = load ptr, ptr %lp4
  %t106 = getelementptr { i64, ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l31, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  br label %bb17
bb16:
  %t112 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t113 = load ptr, ptr %lp4
  store { i64, ptr } %t112, ptr %t113, !tbaa !27
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t114 = load i1, ptr %l3, !tbaa !21
  br i1 %t114, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load ptr, ptr %lp4
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l34, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t119 = load i1, ptr %l1, !tbaa !21
  %t120 = load i1, ptr %l3, !tbaa !21
  %t124 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s4, ptr %v0, ptr %s4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d30, i32 0, i32 1) }, { i64, ptr } %t118, i1 %t119, i1 %t120)
  %t125 = extractvalue { i32, { i64, ptr } } %t124, 1
  %t126 = extractvalue { i32, { i64, ptr } } %t124, 0
  store i32 %t126, ptr %l40
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb22, label %ok.128, !prof !99
ok.128:
  store { i64, ptr } %t125, ptr %l39
  br label %bb21
bb20:
  br label %bb27
bb21:
  %t129 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t129, ptr %l35, !tbaa !27
  br label %bb23
bb22:
  %t130 = load i32, ptr %l40, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  call void @__olang_scope_close(ptr %s4)
  %t140 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t138, 0
  store { i32, { i64, ptr } } %t140, ptr %rv
  br label %ret
bb23:
  %t141 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t152, ptr %t144, i64 %t145)
  %t153 = getelementptr i8, ptr %t152, i64 %t145
  call void @olang_textcopy(ptr %t153, ptr %t148, i64 %t149)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t151, 1
  store { i64, ptr } %t155, ptr %l42, !tbaa !27
  %t156 = load ptr, ptr %lp4
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t159 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l44, !tbaa !24
  %t162 = load i64, ptr %l44, !tbaa !24
  %t163 = icmp eq i64 %t158, %t162
  br i1 %t163, label %bb24, label %bb25
bb24:
  %t165 = load ptr, ptr %lp4
  %t166 = getelementptr { i64, ptr }, ptr %t165, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l44, !tbaa !24
  %t171 = mul i64 %t170, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t167, ptr %t169, i64 %t171, i1 false)
  br label %bb26
bb25:
  %t172 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t173 = load ptr, ptr %lp4
  store { i64, ptr } %t172, ptr %t173, !tbaa !27
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t174 = load ptr, ptr %lp4
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  %t177 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t175, 1
  store { i32, { i64, ptr } } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l19, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb84
bb7:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t19, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t21, ptr %l21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t23, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d33, i32 0, i32 1) })
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l25
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb12, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l24
  br label %bb11
bb10:
  br label %bb34
bb11:
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l22, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb14
bb14:
  %t31 = load i64, ptr %l22, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb15, label %bb16
bb15:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t38 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t36, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  %t39 = extractvalue { i32, i64 } %t38, 1
  %t40 = extractvalue { i32, i64 } %t38, 0
  store i32 %t40, ptr %l32
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb18, label %ok.42, !prof !99
ok.42:
  store i64 %t39, ptr %l31
  br label %bb17
bb16:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb21
bb17:
  %t43 = load i64, ptr %l31, !tbaa !24
  store i64 %t43, ptr %l29, !tbaa !24
  br label %bb20
bb18:
  br label %bb19
bb19:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb20
bb20:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = icmp eq i64 %t45, %t44
  store i1 %t47, ptr %l28, !tbaa !21
  br label %bb21
bb21:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l35, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l37, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = icmp sge i64 1, 0
  br i1 %t54, label %bb24, label %bb25
bb23:
  br label %bb33
bb24:
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = icmp sle i64 1, %t56
  br i1 %t57, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb26:
  %t59 = load i64, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l38, !tbaa !24
  %t61 = icmp sle i64 %t59, %t60
  br i1 %t61, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb28:
  %t63 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l37, !tbaa !24
  %t66 = getelementptr i8, ptr %t64, i64 1
  %t67 = sub i64 %t65, 1
  %t68 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  %t70 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = getelementptr i8, ptr %t79, i64 %t71
  call void @olang_textcopy(ptr %t80, ptr %t73, i64 %t74)
  %t81 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t86 = extractvalue { i64, ptr } %t83, 1
  %t87 = mul i64 %t85, 1
  %t88 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t86, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t91 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t91, { i64, ptr } %t90)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_48912347760bc49b_7f197caf3eb31ff7)
  unreachable
bb30:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t93)
  br label %bb31
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb83
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb34:
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t97, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t99, ptr %l49
  br label %bb35
bb35:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb36, label %bb37
bb36:
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t101, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t103, ptr %l52
  br label %bb38
bb37:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb39
bb38:
  %t104 = load i1, ptr %l52, !tbaa !21
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb39
bb39:
  %t105 = load i1, ptr %l50, !tbaa !21
  br i1 %t105, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t106 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t108 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t106, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) })
  %t109 = extractvalue { i32, i64 } %t108, 1
  %t110 = extractvalue { i32, i64 } %t108, 0
  store i32 %t110, ptr %l56
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb43, label %ok.112, !prof !99
ok.112:
  store i64 %t109, ptr %l55
  br label %bb42
bb41:
  br label %bb80
bb42:
  %t113 = load i64, ptr %l55, !tbaa !24
  store i64 %t113, ptr %l53, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb45
bb45:
  %t114 = load i64, ptr %l53, !tbaa !24
  store i64 %t114, ptr %l7, !tbaa !24
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = icmp sge i64 %t115, 0
  br i1 %t117, label %bb46, label %bb47
bb46:
  %t119 = load i64, ptr %l7, !tbaa !24
  store i64 %t119, ptr %l59, !tbaa !24
  br label %bb48
bb47:
  %t121 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = sub i64 %t123, 1
  store i64 %t125, ptr %l59, !tbaa !24
  br label %bb48
bb48:
  %t127 = load i64, ptr %l59, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t128, ptr %l64, !tbaa !27
  store i64 %t127, ptr %l65, !tbaa !24
  %t130 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l66, !tbaa !24
  %t132 = icmp sge i64 0, 0
  br i1 %t132, label %bb49, label %bb50
bb49:
  %t134 = load i64, ptr %l65, !tbaa !24
  %t135 = icmp sle i64 0, %t134
  br i1 %t135, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb51:
  %t137 = load i64, ptr %l65, !tbaa !24
  %t138 = load i64, ptr %l66, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb53:
  %t141 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = getelementptr i8, ptr %t142, i64 0
  %t145 = sub i64 %t143, 0
  %t146 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t144, 1
  store { i64, ptr } %t147, ptr %l9, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l73, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t153 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t149, { i64, ptr } %t152)
  store i1 %t153, ptr %l74
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_606763d33345b49e_888ff486d8884e9a)
  unreachable
bb55:
  %t154 = load i1, ptr %l74, !tbaa !21
  br i1 %t154, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb59
bb57:
  %t155 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l78, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t159 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t155, { i64, ptr } %t158)
  store i1 %t159, ptr %l79
  br label %bb58
bb58:
  %t160 = load i1, ptr %l79, !tbaa !21
  store i1 %t160, ptr %l75, !tbaa !21
  br label %bb59
bb59:
  %t161 = load i1, ptr %l75, !tbaa !21
  store i1 %t161, ptr %l10, !tbaa !21
  %t162 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t162)
  br label %bb60
bb60:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = icmp sge i64 %t165, 0
  br i1 %t167, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l3, ptr %l84, !tbaa !29
  %t169 = load i1, ptr %l10, !tbaa !21
  br i1 %t169, label %bb63, label %bb64
bb62:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l3, ptr %l98, !tbaa !29
  %t171 = load i1, ptr %l10, !tbaa !21
  br i1 %t171, label %bb74, label %bb75
bb63:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb65
bb64:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %l86, !tbaa !27
  br label %bb65
bb65:
  %t173 = load ptr, ptr %l84, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t173, { i64, ptr } %t174)
  br label %bb66
bb66:
  store ptr %l3, ptr %l87, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t175, ptr %l88, !tbaa !27
  %t176 = load i64, ptr %l7, !tbaa !24
  store i64 %t176, ptr %l89, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t177, 0
  store i64 %t180, ptr %l92, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l93, !tbaa !24
  %t183 = load i64, ptr %l89, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  br i1 %t184, label %bb67, label %bb68
bb67:
  %t186 = load i64, ptr %l89, !tbaa !24
  %t187 = load i64, ptr %l92, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  br i1 %t188, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb69:
  %t190 = load i64, ptr %l92, !tbaa !24
  %t191 = load i64, ptr %l93, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  br i1 %t192, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb71:
  %t194 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l89, !tbaa !24
  %t197 = load i64, ptr %l92, !tbaa !24
  %t198 = getelementptr i8, ptr %t195, i64 %t196
  %t199 = sub i64 %t197, %t196
  %t200 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t202 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t202, { i64, ptr } %t201)
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39)
  unreachable
bb73:
  call void @__olang_scope_close(ptr %s7)
  br label %bb78
bb74:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb76
bb75:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %l100, !tbaa !27
  br label %bb76
bb76:
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t204, { i64, ptr } %t205)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s8)
  br label %bb78
bb78:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb83
bb80:
  %t207 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t207)
  br label %bb81
bb81:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s2)
  br label %bb83
bb83:
  br label %bb3
bb84:
  store ptr %l3, ptr %l105, !tbaa !29
  br i1 %a2, label %bb85, label %bb86
bb85:
  store { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb87
bb86:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l107, !tbaa !27
  br label %bb87
bb87:
  %t213 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t214 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t216 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = add i64 %t215, %t218
  %t221 = extractvalue { i64, ptr } %t213, 1
  %t222 = extractvalue { i64, ptr } %t213, 0
  %t223 = add i64 %t219, %t222
  %t224 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t227 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t226)
  call void @olang_textcopy(ptr %t227, ptr %t214, i64 %t215)
  %t228 = getelementptr i8, ptr %t227, i64 %t215
  call void @olang_textcopy(ptr %t228, ptr %t217, i64 %t218)
  %t229 = getelementptr i8, ptr %t228, i64 %t218
  call void @olang_textcopy(ptr %t229, ptr %t221, i64 %t222)
  %t230 = getelementptr i8, ptr %t229, i64 %t222
  call void @olang_textcopy(ptr %t230, ptr %t224, i64 %t225)
  %t231 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t227, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = extractvalue { i64, ptr } %t232, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t240 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t240, { i64, ptr } %t239)
  br label %bb88
bb88:
  %t242 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t243 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t246 = extractvalue { i64, ptr } %t242, 1
  %t247 = extractvalue { i64, ptr } %t242, 0
  %t248 = add i64 %t244, %t247
  %t249 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t243, i64 %t244)
  %t253 = getelementptr i8, ptr %t252, i64 %t244
  call void @olang_textcopy(ptr %t253, ptr %t246, i64 %t247)
  %t254 = getelementptr i8, ptr %t253, i64 %t247
  call void @olang_textcopy(ptr %t254, ptr %t249, i64 %t250)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t252, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = mul i64 %t258, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t261, ptr %t259, i64 %t260, i1 false)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t263)
  br label %bb89
bb89:
  %t267 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t267, ptr %l116
  br label %bb90
bb90:
  %t268 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t268, ptr %l117, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l118, !tbaa !24
  %t271 = load i64, ptr %l118, !tbaa !24
  %t272 = mul i64 %t271, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t272)
  %t274 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  store { i64, ptr } %t275, ptr %l119, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l118, !tbaa !24
  %t281 = mul i64 %t280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %t279, i64 %t281, i1 false)
  %t282 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t282, ptr %l117, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t283, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fruntime_2earchRow(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs
  store i64 2, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs, i64 0, i64 %t50
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t55, ptr %v0, { i64, ptr } %t53, { i64, ptr } %a0)
  store i1 %t58, ptr %l36
  br label %bb11
bb11:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fruntime_2edeclare(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l106 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i32
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i64
  %l147 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i64
  %l173 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l187 = alloca { i64, ptr }
  %l191 = alloca i1
  %l192 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i32
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca i64
  %l199 = alloca i64
  %l206 = alloca { i64, ptr }
  %l208 = alloca i64
  %l211 = alloca i64
  %l212 = alloca i64
  %l218 = alloca i1
  %l219 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca i64
  %l227 = alloca i64
  %l234 = alloca { i64, ptr }
  %l236 = alloca i64
  %l239 = alloca i64
  %l240 = alloca i64
  %l246 = alloca i1
  %l247 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca i64
  %l256 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i32
  %l267 = alloca i64
  %l271 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca { i64, ptr }
  %l277 = alloca i64
  %l278 = alloca i64
  %l282 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i1, ptr %l18, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t7, ptr %l21
  br label %bb4
bb4:
  %t8 = load i1, ptr %l21, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t13 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t9, { i64, ptr } %t12)
  store i1 %t13, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t14 = load i1, ptr %l26, !tbaa !21
  store i1 %t14, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t15 = load i1, ptr %l22, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb11:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t19, ptr %l29
  br label %bb12
bb12:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb13, label %bb14
bb13:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t25 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } %t24)
  store i1 %t25, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t26 = load i1, ptr %l34, !tbaa !21
  store i1 %t26, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t27 = load i1, ptr %l30, !tbaa !21
  store i1 %t27, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t29, { i64, ptr } %t30)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t33, i8 10)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t37, ptr %l39
  br label %bb23
bb23:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t41, ptr %l42
  br label %bb26
bb26:
  %t42 = load i1, ptr %l42, !tbaa !21
  store i1 %t42, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t43 = load i1, ptr %l40, !tbaa !21
  br i1 %t43, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t48 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t44, { i64, ptr } %t47)
  store i1 %t48, ptr %l47
  br label %bb30
bb30:
  %t49 = load i1, ptr %l47, !tbaa !21
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb35
bb33:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t55 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } %t54)
  store i1 %t55, ptr %l52
  br label %bb34
bb34:
  %t56 = load i1, ptr %l52, !tbaa !21
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb35
bb35:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) })
  store i1 %t60, ptr %l54
  br label %bb39
bb39:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s3, { i64, ptr } %t62, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) })
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l58
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb43, label %ok.68, !prof !99
ok.68:
  store i64 %t65, ptr %l57
  br label %bb42
bb41:
  br label %bb148
bb42:
  %t69 = load i64, ptr %l57, !tbaa !24
  store i64 %t69, ptr %l55, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t70 = load i64, ptr %l55, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l59, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l60, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  store i64 %t73, ptr %l61, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l62, !tbaa !24
  %t76 = icmp sge i64 7, 0
  br i1 %t76, label %bb46, label %bb47
bb46:
  %t78 = load i64, ptr %l61, !tbaa !24
  %t79 = icmp sle i64 7, %t78
  br i1 %t79, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb48:
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = load i64, ptr %l62, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb50:
  %t85 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 7
  %t89 = sub i64 %t87, 7
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t95 = extractvalue { i64, ptr } %t91, 1
  %t96 = extractvalue { i64, ptr } %t91, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t92, i64 %t93)
  %t102 = getelementptr i8, ptr %t101, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = getelementptr i8, ptr %t102, i64 %t96
  call void @olang_textcopy(ptr %t103, ptr %t98, i64 %t99)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t101, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = extractvalue { i64, ptr } %t105, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t113, { i64, ptr } %t112)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_ea39e132cd3efa0c_1aef6a820179ae38)
  unreachable
bb52:
  store i64 0, ptr %l3, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l4, !tbaa !24
  store i1 true, ptr %l5, !tbaa !21
  %t119 = load i64, ptr %l2, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t129 = icmp slt i64 %t123, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb54, label %bb55
bb54:
  br label %bb129
bb55:
  br label %bb56
bb56:
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l78, !tbaa !27
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  store i8 %t139, ptr %l7, !tbaa !22
  %t141 = load i8, ptr %l7, !tbaa !22
  %t143 = icmp eq i8 %t141, 40
  br i1 %t143, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb59
bb58:
  %t145 = load i8, ptr %l7, !tbaa !22
  %t147 = icmp eq i8 %t145, 91
  store i1 %t147, ptr %l83, !tbaa !21
  br label %bb59
bb59:
  %t149 = load i1, ptr %l83, !tbaa !21
  br i1 %t149, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb62
bb61:
  %t150 = load i8, ptr %l7, !tbaa !22
  %t152 = icmp eq i8 %t150, 123
  store i1 %t152, ptr %l86, !tbaa !21
  br label %bb62
bb62:
  %t154 = load i1, ptr %l86, !tbaa !21
  br i1 %t154, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb65
bb64:
  %t155 = load i8, ptr %l7, !tbaa !22
  %t157 = icmp eq i8 %t155, 60
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb65
bb65:
  %t159 = load i1, ptr %l89, !tbaa !21
  br i1 %t159, label %bb66, label %bb67
bb66:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb127
bb67:
  %t164 = load i8, ptr %l7, !tbaa !22
  %t166 = icmp eq i8 %t164, 93
  br i1 %t166, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb70
bb69:
  %t168 = load i8, ptr %l7, !tbaa !22
  %t170 = icmp eq i8 %t168, 125
  store i1 %t170, ptr %l96, !tbaa !21
  br label %bb70
bb70:
  %t172 = load i1, ptr %l96, !tbaa !21
  br i1 %t172, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb73
bb72:
  %t173 = load i8, ptr %l7, !tbaa !22
  %t175 = icmp eq i8 %t173, 62
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb73
bb73:
  %t177 = load i1, ptr %l99, !tbaa !21
  br i1 %t177, label %bb74, label %bb75
bb74:
  %t178 = load i64, ptr %l3, !tbaa !24
  %t180 = sub i64 %t178, 1
  store i64 %t180, ptr %l3, !tbaa !24
  br label %bb126
bb75:
  %t182 = load i8, ptr %l7, !tbaa !22
  %t184 = icmp eq i8 %t182, 41
  br i1 %t184, label %bb76, label %bb77
bb76:
  %t186 = load i64, ptr %l3, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  store i1 %t188, ptr %l106, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb78
bb78:
  %t190 = load i1, ptr %l106, !tbaa !21
  br i1 %t190, label %bb79, label %bb80
bb79:
  %t191 = load i64, ptr %l3, !tbaa !24
  %t193 = sub i64 %t191, 1
  store i64 %t193, ptr %l3, !tbaa !24
  br label %bb125
bb80:
  %t195 = load i8, ptr %l7, !tbaa !22
  %t197 = icmp eq i8 %t195, 44
  br i1 %t197, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb83
bb82:
  %t199 = load i8, ptr %l7, !tbaa !22
  %t201 = icmp eq i8 %t199, 41
  store i1 %t201, ptr %l113, !tbaa !21
  br label %bb83
bb83:
  %t203 = load i1, ptr %l113, !tbaa !21
  br i1 %t203, label %bb84, label %bb85
bb84:
  %t204 = load i64, ptr %l3, !tbaa !24
  %t206 = icmp eq i64 %t204, 0
  store i1 %t206, ptr %l116, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb86
bb86:
  %t208 = load i1, ptr %l116, !tbaa !21
  br i1 %t208, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s13
  %t209 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t209, ptr %l119, !tbaa !27
  %t210 = load i64, ptr %l4, !tbaa !24
  store i64 %t210, ptr %l120, !tbaa !24
  %t211 = load i64, ptr %l6, !tbaa !24
  store i64 %t211, ptr %l121, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l122, !tbaa !24
  %t214 = load i64, ptr %l120, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb89, label %bb90
bb88:
  br label %bb124
bb89:
  %t217 = load i64, ptr %l120, !tbaa !24
  %t218 = load i64, ptr %l121, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb91:
  %t221 = load i64, ptr %l121, !tbaa !24
  %t222 = load i64, ptr %l122, !tbaa !24
  %t223 = icmp sle i64 %t221, %t222
  br i1 %t223, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb93:
  %t225 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l120, !tbaa !24
  %t228 = load i64, ptr %l121, !tbaa !24
  %t229 = getelementptr i8, ptr %t226, i64 %t227
  %t230 = sub i64 %t228, %t227
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, { i64, ptr } %t232)
  store { i64, ptr } %t234, ptr %l127
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415)
  unreachable
bb95:
  %t235 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t235, ptr %l8, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t238 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s13, { i64, ptr } %t236, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d66, i32 0, i32 1) })
  %t239 = extractvalue { i32, i64 } %t238, 1
  %t240 = extractvalue { i32, i64 } %t238, 0
  store i32 %t240, ptr %l131
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb97, label %ok.242, !prof !99
ok.242:
  store i64 %t239, ptr %l130
  br label %bb96
bb96:
  %t243 = load i64, ptr %l130, !tbaa !24
  store i64 %t243, ptr %l128, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l128, !tbaa !24
  br label %bb99
bb99:
  %t244 = load i64, ptr %l128, !tbaa !24
  store i64 %t244, ptr %l9, !tbaa !24
  %t245 = load i64, ptr %l9, !tbaa !24
  %t247 = icmp sge i64 %t245, 0
  br i1 %t247, label %bb100, label %bb101
bb100:
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l135, !tbaa !27
  %t250 = load i64, ptr %l9, !tbaa !24
  %t252 = add i64 %t250, 1
  %t254 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i8, ptr %t255, i64 %t252
  %t257 = load i8, ptr %t256, !tbaa !32
  %t259 = icmp eq i8 %t257, 37
  store i1 %t259, ptr %l134, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb102
bb102:
  %t261 = load i1, ptr %l134, !tbaa !21
  br i1 %t261, label %bb103, label %bb104
bb103:
  %t262 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t262, ptr %l140, !tbaa !27
  %t263 = load i64, ptr %l9, !tbaa !24
  store i64 %t263, ptr %l141, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l142, !tbaa !24
  %t266 = icmp sge i64 0, 0
  br i1 %t266, label %bb105, label %bb106
bb104:
  br label %bb112
bb105:
  %t268 = load i64, ptr %l141, !tbaa !24
  %t269 = icmp sle i64 0, %t268
  br i1 %t269, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb107:
  %t271 = load i64, ptr %l141, !tbaa !24
  %t272 = load i64, ptr %l142, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb109:
  %t275 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = load i64, ptr %l141, !tbaa !24
  %t278 = getelementptr i8, ptr %t276, i64 0
  %t279 = sub i64 %t277, 0
  %t280 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t283 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t281)
  store { i64, ptr } %t283, ptr %l147
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_9d9b73c28e4e3d9a_299346768faaee36)
  unreachable
bb111:
  %t284 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t284, ptr %l8, !tbaa !27
  br label %bb112
bb112:
  %t285 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = icmp sgt i64 %t287, 0
  br i1 %t289, label %bb113, label %bb114
bb113:
  %t291 = load i1, ptr %l5, !tbaa !21
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb115, label %bb116
bb114:
  br label %bb120
bb115:
  store %olang.scope zeroinitializer, ptr %s16
  %t295 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s16, ptr %t295, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb118:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t297, { i64, ptr } %t298)
  br label %bb119
bb119:
  br label %bb120
bb120:
  store i1 false, ptr %l5, !tbaa !21
  %t301 = load i64, ptr %l6, !tbaa !24
  %t303 = add i64 %t301, 1
  store i64 %t303, ptr %l4, !tbaa !24
  %t305 = load i8, ptr %l7, !tbaa !22
  %t307 = icmp eq i8 %t305, 41
  br i1 %t307, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s13)
  br label %bb129
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s13)
  br label %bb124
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t309 = load i64, ptr %l6, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l6, !tbaa !24
  br label %bb128
bb128:
  br label %bb53
bb129:
  %t313 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t313, ptr %l162, !tbaa !27
  %t314 = load i64, ptr %l6, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l164, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t317, 0
  store i64 %t320, ptr %l167, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l168, !tbaa !24
  %t323 = load i64, ptr %l164, !tbaa !24
  %t324 = icmp sge i64 %t323, 0
  br i1 %t324, label %bb130, label %bb131
bb130:
  %t326 = load i64, ptr %l164, !tbaa !24
  %t327 = load i64, ptr %l167, !tbaa !24
  %t328 = icmp sle i64 %t326, %t327
  br i1 %t328, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb132:
  %t330 = load i64, ptr %l167, !tbaa !24
  %t331 = load i64, ptr %l168, !tbaa !24
  %t332 = icmp sle i64 %t330, %t331
  br i1 %t332, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb134:
  %t334 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l164, !tbaa !24
  %t337 = load i64, ptr %l167, !tbaa !24
  %t338 = getelementptr i8, ptr %t335, i64 %t336
  %t339 = sub i64 %t337, %t336
  %t340 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t338, 1
  store { i64, ptr } %t341, ptr %l10, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t345 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t343, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d68, i32 0, i32 1) })
  %t346 = extractvalue { i32, i64 } %t345, 1
  %t347 = extractvalue { i32, i64 } %t345, 0
  store i32 %t347, ptr %l176
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb137, label %ok.349, !prof !99
ok.349:
  store i64 %t346, ptr %l175
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @olang_loc_9424fbeaf4790ef7_29a43c91e82e5293)
  unreachable
bb136:
  %t350 = load i64, ptr %l175, !tbaa !24
  store i64 %t350, ptr %l173, !tbaa !24
  br label %bb139
bb137:
  br label %bb138
bb138:
  call void @__olang_ert_req_clear()
  %t351 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  store i64 %t353, ptr %l173, !tbaa !24
  br label %bb139
bb139:
  %t355 = load i64, ptr %l173, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l179, !tbaa !29
  %t357 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t357, ptr %l180, !tbaa !27
  store i64 %t355, ptr %l181, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l182, !tbaa !24
  %t361 = icmp sge i64 0, 0
  br i1 %t361, label %bb140, label %bb141
bb140:
  %t363 = load i64, ptr %l181, !tbaa !24
  %t364 = icmp sle i64 0, %t363
  br i1 %t364, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb142:
  %t366 = load i64, ptr %l181, !tbaa !24
  %t367 = load i64, ptr %l182, !tbaa !24
  %t368 = icmp sle i64 %t366, %t367
  br i1 %t368, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb144:
  %t370 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = load i64, ptr %l181, !tbaa !24
  %t373 = getelementptr i8, ptr %t371, i64 0
  %t374 = sub i64 %t372, 0
  %t375 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t373, 1
  %t378 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t376)
  store { i64, ptr } %t378, ptr %l187
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_15c1087a8dcee578_9616249aba3f0cc)
  unreachable
bb146:
  %t379 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t381 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t379, i64 %t380)
  %t389 = getelementptr i8, ptr %t388, i64 %t380
  call void @olang_textcopy(ptr %t389, ptr %t382, i64 %t383)
  %t390 = getelementptr i8, ptr %t389, i64 %t383
  call void @olang_textcopy(ptr %t390, ptr %t385, i64 %t386)
  %t391 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t388, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = extractvalue { i64, ptr } %t392, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l179, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t400, { i64, ptr } %t399)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb148:
  %t402 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t404 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t402, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) })
  store i1 %t404, ptr %l191
  br label %bb149
bb149:
  %t405 = load i1, ptr %l191, !tbaa !21
  br i1 %t405, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s19
  %t406 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t408 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t406, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) })
  %t409 = extractvalue { i32, i64 } %t408, 1
  %t410 = extractvalue { i32, i64 } %t408, 0
  store i32 %t410, ptr %l195
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb153, label %ok.412, !prof !99
ok.412:
  store i64 %t409, ptr %l194
  br label %bb152
bb151:
  br label %bb221
bb152:
  %t413 = load i64, ptr %l194, !tbaa !24
  store i64 %t413, ptr %l192, !tbaa !24
  br label %bb155
bb153:
  br label %bb154
bb154:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb155:
  %t414 = load i64, ptr %l192, !tbaa !24
  store i64 %t414, ptr %l12, !tbaa !24
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l196, !tbaa !29
  %t416 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t416, ptr %l197, !tbaa !27
  %t417 = load i64, ptr %l12, !tbaa !24
  store i64 %t417, ptr %l198, !tbaa !24
  %t418 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 0
  store i64 %t419, ptr %l199, !tbaa !24
  %t420 = icmp sge i64 0, 0
  br i1 %t420, label %bb156, label %bb157
bb156:
  %t422 = load i64, ptr %l198, !tbaa !24
  %t423 = icmp sle i64 0, %t422
  br i1 %t423, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb158:
  %t425 = load i64, ptr %l198, !tbaa !24
  %t426 = load i64, ptr %l199, !tbaa !24
  %t427 = icmp sle i64 %t425, %t426
  br i1 %t427, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb160:
  %t429 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = load i64, ptr %l198, !tbaa !24
  %t432 = getelementptr i8, ptr %t430, i64 0
  %t433 = sub i64 %t431, 0
  %t434 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t440 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t441 = add i64 %t438, %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t437, i64 %t438)
  %t443 = getelementptr i8, ptr %t442, i64 %t438
  call void @olang_textcopy(ptr %t443, ptr %t439, i64 %t440)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t442, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = load ptr, ptr %l196, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t453, { i64, ptr } %t452)
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @olang_loc_37b9d9dde30c0555_b630301b751c84f9)
  unreachable
bb162:
  %t455 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t455, ptr %l206, !tbaa !27
  %t456 = load i64, ptr %l12, !tbaa !24
  %t458 = add i64 %t456, 3
  store i64 %t458, ptr %l208, !tbaa !24
  %t459 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t459, 0
  store i64 %t462, ptr %l211, !tbaa !24
  %t463 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 0
  store i64 %t464, ptr %l212, !tbaa !24
  %t465 = load i64, ptr %l208, !tbaa !24
  %t466 = icmp sge i64 %t465, 0
  br i1 %t466, label %bb163, label %bb164
bb163:
  %t468 = load i64, ptr %l208, !tbaa !24
  %t469 = load i64, ptr %l211, !tbaa !24
  %t470 = icmp sle i64 %t468, %t469
  br i1 %t470, label %bb165, label %bb166
bb164:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb165:
  %t472 = load i64, ptr %l211, !tbaa !24
  %t473 = load i64, ptr %l212, !tbaa !24
  %t474 = icmp sle i64 %t472, %t473
  br i1 %t474, label %bb167, label %bb168
bb166:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb167:
  %t476 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = load i64, ptr %l208, !tbaa !24
  %t479 = load i64, ptr %l211, !tbaa !24
  %t480 = getelementptr i8, ptr %t477, i64 %t478
  %t481 = sub i64 %t479, %t478
  %t482 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t480, 1
  store { i64, ptr } %t483, ptr %l13, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t487 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t485, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d74, i32 0, i32 1) })
  store i1 %t487, ptr %l218
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_2446b89a84efdb76_2c0483cfef229c5a)
  unreachable
bb169:
  %t488 = load i1, ptr %l218, !tbaa !21
  br i1 %t488, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s22
  %t489 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t491 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s22, { i64, ptr } %t489, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  %t492 = extractvalue { i32, i64 } %t491, 1
  %t493 = extractvalue { i32, i64 } %t491, 0
  store i32 %t493, ptr %l222
  %t494 = icmp ne i32 %t493, 0
  br i1 %t494, label %bb173, label %ok.495, !prof !99
ok.495:
  store i64 %t492, ptr %l221
  br label %bb172
bb171:
  br label %bb189
bb172:
  %t496 = load i64, ptr %l221, !tbaa !24
  store i64 %t496, ptr %l219, !tbaa !24
  br label %bb175
bb173:
  br label %bb174
bb174:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb175:
  %t497 = load i64, ptr %l219, !tbaa !24
  store i64 %t497, ptr %l14, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l223, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t499, ptr %l224, !tbaa !27
  %t500 = load i64, ptr %l14, !tbaa !24
  %t502 = add i64 %t500, 1
  store i64 %t502, ptr %l226, !tbaa !24
  %t503 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  store i64 %t504, ptr %l227, !tbaa !24
  %t505 = icmp sge i64 0, 0
  br i1 %t505, label %bb176, label %bb177
bb176:
  %t507 = load i64, ptr %l226, !tbaa !24
  %t508 = icmp sle i64 0, %t507
  br i1 %t508, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb178:
  %t510 = load i64, ptr %l226, !tbaa !24
  %t511 = load i64, ptr %l227, !tbaa !24
  %t512 = icmp sle i64 %t510, %t511
  br i1 %t512, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb180:
  %t514 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = load i64, ptr %l226, !tbaa !24
  %t517 = getelementptr i8, ptr %t515, i64 0
  %t518 = sub i64 %t516, 0
  %t519 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t517, 1
  %t522 = extractvalue { i64, ptr } %t520, 1
  %t523 = extractvalue { i64, ptr } %t520, 0
  %t524 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t526 = add i64 %t523, %t525
  %t527 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t526)
  call void @olang_textcopy(ptr %t527, ptr %t522, i64 %t523)
  %t528 = getelementptr i8, ptr %t527, i64 %t523
  call void @olang_textcopy(ptr %t528, ptr %t524, i64 %t525)
  %t529 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t527, 1
  %t532 = extractvalue { i64, ptr } %t530, 0
  %t533 = extractvalue { i64, ptr } %t530, 1
  %t534 = mul i64 %t532, 1
  %t535 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t534)
  call void @llvm.memcpy.p0.p0.i64(ptr %t535, ptr %t533, i64 %t534, i1 false)
  %t536 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t535, 1
  %t538 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t538, { i64, ptr } %t537)
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7)
  unreachable
bb182:
  %t540 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t540, ptr %l234, !tbaa !27
  %t541 = load i64, ptr %l14, !tbaa !24
  %t543 = add i64 %t541, 2
  store i64 %t543, ptr %l236, !tbaa !24
  %t544 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t544, 0
  store i64 %t547, ptr %l239, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l240, !tbaa !24
  %t550 = load i64, ptr %l236, !tbaa !24
  %t551 = icmp sge i64 %t550, 0
  br i1 %t551, label %bb183, label %bb184
bb183:
  %t553 = load i64, ptr %l236, !tbaa !24
  %t554 = load i64, ptr %l239, !tbaa !24
  %t555 = icmp sle i64 %t553, %t554
  br i1 %t555, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb185:
  %t557 = load i64, ptr %l239, !tbaa !24
  %t558 = load i64, ptr %l240, !tbaa !24
  %t559 = icmp sle i64 %t557, %t558
  br i1 %t559, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb187:
  %t561 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = load i64, ptr %l236, !tbaa !24
  %t564 = load i64, ptr %l239, !tbaa !24
  %t565 = getelementptr i8, ptr %t562, i64 %t563
  %t566 = sub i64 %t564, %t563
  %t567 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t565, 1
  store { i64, ptr } %t568, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0)
  unreachable
bb189:
  %t570 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t572 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t570, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t572, ptr %l246
  br label %bb190
bb190:
  %t573 = load i1, ptr %l246, !tbaa !21
  br i1 %t573, label %bb191, label %bb192
bb191:
  %t574 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t574, ptr %l247, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t575, 0
  store i64 %t578, ptr %l250, !tbaa !24
  %t579 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t579, 0
  store i64 %t580, ptr %l251, !tbaa !24
  %t581 = icmp sge i64 13, 0
  br i1 %t581, label %bb193, label %bb194
bb192:
  br label %bb199
bb193:
  %t583 = load i64, ptr %l250, !tbaa !24
  %t584 = icmp sle i64 13, %t583
  br i1 %t584, label %bb195, label %bb196
bb194:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb195:
  %t586 = load i64, ptr %l250, !tbaa !24
  %t587 = load i64, ptr %l251, !tbaa !24
  %t588 = icmp sle i64 %t586, %t587
  br i1 %t588, label %bb197, label %bb198
bb196:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb197:
  %t590 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = load i64, ptr %l250, !tbaa !24
  %t593 = getelementptr i8, ptr %t591, i64 13
  %t594 = sub i64 %t592, 13
  %t595 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t593, 1
  store { i64, ptr } %t596, ptr %l13, !tbaa !27
  br label %bb199
bb198:
  call void @__olang_check_failed(ptr @olang_loc_383c318151cd7051_6709cfbf24f79c8d)
  unreachable
bb199:
  %t598 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t600 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t598, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) })
  %t601 = extractvalue { i32, i64 } %t600, 1
  %t602 = extractvalue { i32, i64 } %t600, 0
  store i32 %t602, ptr %l259
  %t603 = icmp ne i32 %t602, 0
  br i1 %t603, label %bb201, label %ok.604, !prof !99
ok.604:
  store i64 %t601, ptr %l258
  br label %bb200
bb200:
  %t605 = load i64, ptr %l258, !tbaa !24
  store i64 %t605, ptr %l256, !tbaa !24
  br label %bb203
bb201:
  br label %bb202
bb202:
  call void @__olang_ert_req_clear()
  %t606 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  store i64 %t608, ptr %l256, !tbaa !24
  br label %bb203
bb203:
  %t610 = load i64, ptr %l256, !tbaa !24
  store i64 %t610, ptr %l15, !tbaa !24
  %t611 = load i64, ptr %l15, !tbaa !24
  %t613 = add i64 %t611, 1
  %t614 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t619 = icmp slt i64 %t613, %t616
  br i1 %t619, label %bb204, label %bb205
bb204:
  %t621 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t622 = load i64, ptr %l15, !tbaa !24
  %t624 = add i64 %t622, 1
  %t627 = call i64 @compiler_2fruntime_2etypeEnd(ptr %v1, { i64, ptr } %t621, i64 %t624)
  store i64 %t627, ptr %l271
  br label %bb206
bb205:
  %t628 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t628, 0
  store i64 %t630, ptr %l267, !tbaa !24
  br label %bb207
bb206:
  %t632 = load i64, ptr %l271, !tbaa !24
  store i64 %t632, ptr %l267, !tbaa !24
  br label %bb207
bb207:
  %t633 = load i64, ptr %l267, !tbaa !24
  store i64 %t633, ptr %l16, !tbaa !24
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l274, !tbaa !29
  %t635 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t635, ptr %l275, !tbaa !27
  %t636 = load i64, ptr %l15, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l277, !tbaa !24
  %t639 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t639, 0
  store i64 %t640, ptr %l278, !tbaa !24
  %t641 = icmp sge i64 0, 0
  br i1 %t641, label %bb208, label %bb209
bb208:
  %t643 = load i64, ptr %l277, !tbaa !24
  %t644 = icmp sle i64 0, %t643
  br i1 %t644, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb210:
  %t646 = load i64, ptr %l277, !tbaa !24
  %t647 = load i64, ptr %l278, !tbaa !24
  %t648 = icmp sle i64 %t646, %t647
  br i1 %t648, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb212:
  %t650 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = load i64, ptr %l277, !tbaa !24
  %t653 = getelementptr i8, ptr %t651, i64 0
  %t654 = sub i64 %t652, 0
  %t655 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t653, 1
  store { i64, ptr } %t656, ptr %l282, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t657, ptr %l283, !tbaa !27
  %t658 = load i64, ptr %l15, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l285, !tbaa !24
  %t661 = load i64, ptr %l16, !tbaa !24
  store i64 %t661, ptr %l286, !tbaa !24
  %t662 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 0
  store i64 %t663, ptr %l287, !tbaa !24
  %t664 = load i64, ptr %l285, !tbaa !24
  %t665 = icmp sge i64 %t664, 0
  br i1 %t665, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb214:
  %t667 = load i64, ptr %l285, !tbaa !24
  %t668 = load i64, ptr %l286, !tbaa !24
  %t669 = icmp sle i64 %t667, %t668
  br i1 %t669, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb216:
  %t671 = load i64, ptr %l286, !tbaa !24
  %t672 = load i64, ptr %l287, !tbaa !24
  %t673 = icmp sle i64 %t671, %t672
  br i1 %t673, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb218:
  %t675 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = load i64, ptr %l285, !tbaa !24
  %t678 = load i64, ptr %l286, !tbaa !24
  %t679 = getelementptr i8, ptr %t676, i64 %t677
  %t680 = sub i64 %t678, %t677
  %t681 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t679, 1
  %t683 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t684 = extractvalue { i64, ptr } %t683, 1
  %t685 = extractvalue { i64, ptr } %t683, 0
  %t687 = extractvalue { i64, ptr } %t682, 1
  %t688 = extractvalue { i64, ptr } %t682, 0
  %t689 = add i64 %t685, %t688
  %t690 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t691 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t692 = add i64 %t689, %t691
  %t693 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t692)
  call void @olang_textcopy(ptr %t693, ptr %t684, i64 %t685)
  %t694 = getelementptr i8, ptr %t693, i64 %t685
  call void @olang_textcopy(ptr %t694, ptr %t687, i64 %t688)
  %t695 = getelementptr i8, ptr %t694, i64 %t688
  call void @olang_textcopy(ptr %t695, ptr %t690, i64 %t691)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t693, 1
  %t699 = extractvalue { i64, ptr } %t697, 0
  %t700 = extractvalue { i64, ptr } %t697, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t705 = load ptr, ptr %l274, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t705, { i64, ptr } %t704)
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @olang_loc_b26c87ed9711b455_3749eb6f37e52fe9)
  unreachable
bb220:
  call void @__olang_scope_close(ptr %s19)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fruntime_2edirective(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d80, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = icmp sge i64 3, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sle i64 3, %t17
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb7:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb9:
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 3
  %t28 = sub i64 %t26, 3
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l21
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb12, label %ok.40, !prof !99
ok.40:
  store i64 %t37, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_6a493f8daef1bb51_6724bcad8f2aca45)
  unreachable
bb11:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb14
bb14:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp sge i64 %t43, 0
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb17, label %bb18
bb16:
  br label %bb23
bb17:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb19:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb21:
  %t60 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l2, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ba67ff79a761d864_bc768279035b5e68)
  unreachable
bb23:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t70, ptr %l32
  br label %bb24
bb24:
  %t71 = load i1, ptr %l32, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t75, ptr %l35
  br label %bb28
bb28:
  %t76 = load i1, ptr %l35, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i64 1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t80, ptr %l38
  br label %bb32
bb32:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i64 2, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fruntime_2efact(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca [15 x { i64, ptr }]
  %l13 = alloca i64
  %l16 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i64
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr @G_2ecompiler_2fruntime_2eFactNames, i64 240, i1 false)
  %t1 = load [15 x { i64, ptr }], ptr %l8
  store i64 15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = getelementptr [15 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eFactNames, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l37
  br label %bb11
bb11:
  %t58 = load i1, ptr %l37, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t61 = icmp eq i64 %a1, 0
  br i1 %t61, label %bb14, label %bb15
bb13:
  br label %bb17
bb14:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr [15 x i64], ptr @G_2ecompiler_2fruntime_2eFactX86, i64 0, i64 %t63
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb16
bb15:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = getelementptr [15 x i64], ptr @G_2ecompiler_2fruntime_2eFactArm, i64 0, i64 %t68
  %t71 = load i64, ptr %t70, !tbaa !34
  store i64 %t71, ptr %l40, !tbaa !24
  br label %bb16
bb16:
  %t73 = load i64, ptr %l40, !tbaa !24
  %t74 = insertvalue { i32, i64 } zeroinitializer, i64 %t73, 1
  store { i32, i64 } %t74, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb7
bb19:
  %t80 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @compiler_2fruntime_2emalformed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l8 = alloca i32
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t5 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t4, i64 %t5)
  %t24 = getelementptr i8, ptr %t23, i64 %t5
  call void @olang_textcopy(ptr %t24, ptr %t7, i64 %t8)
  %t25 = getelementptr i8, ptr %t24, i64 %t8
  call void @olang_textcopy(ptr %t25, ptr %t10, i64 %t11)
  %t26 = getelementptr i8, ptr %t25, i64 %t11
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %a1)
  %t28 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t28, ptr %t16, i64 %t17)
  %t29 = getelementptr i8, ptr %t28, i64 %t17
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t23, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = call i32 @std_2fio_2ePrintErrln(ptr %s0, { i64, ptr } %t38)
  store i32 %t40, ptr %l8
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb2, label %ok.42, !prof !99
ok.42:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t43 = load i32, ptr %l8, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  store i1 %t46, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d89, i32 0, i32 1) })
  store i1 %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store i1 %t14, ptr %l9
  br label %bb8
bb8:
  %t15 = load i1, ptr %l9, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } %t21)
  store i1 %t22, ptr %l14
  br label %bb13
bb13:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb15:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t28 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } %t27)
  store i1 %t28, ptr %l19
  br label %bb16
bb16:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fruntime_2etypeEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l75 = alloca i64
  %l78 = alloca i64
  %l96 = alloca { i64, ptr }
  %l101 = alloca i1
  %l104 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = icmp ne i8 %t9, 91
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp ne i8 %t13, 123
  store i1 %t15, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l22, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load i8, ptr %l2, !tbaa !22
  %t20 = icmp ne i8 %t18, 60
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb9, label %bb10
bb8:
  br label %bb27
bb9:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l37, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l34, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l55, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t76
  %t81 = load i8, ptr %t80, !tbaa !32
  %t83 = icmp eq i8 %t81, 32
  br i1 %t83, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb21
bb20:
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l60, !tbaa !27
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = icmp eq i8 %t91, 44
  store i1 %t93, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l59, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t96 = load i64, ptr %l8, !tbaa !24
  store i64 %t96, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %rv
  br label %ret
bb27:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb33
bb30:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l78, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb32
bb32:
  %t138 = load i64, ptr %l78, !tbaa !24
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb33
bb33:
  %t139 = load i64, ptr %l75, !tbaa !24
  store i64 %t139, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb35, label %bb36
bb35:
  br label %bb60
bb36:
  br label %bb37
bb37:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l15, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t158, ptr %l96, !tbaa !27
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t159
  %t164 = load i8, ptr %t163, !tbaa !32
  store i8 %t164, ptr %l16, !tbaa !22
  %t166 = load i8, ptr %l16, !tbaa !22
  %t168 = icmp eq i8 %t166, 91
  br i1 %t168, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb40
bb39:
  %t170 = load i8, ptr %l16, !tbaa !22
  %t172 = icmp eq i8 %t170, 123
  store i1 %t172, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t174 = load i1, ptr %l101, !tbaa !21
  br i1 %t174, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb43
bb42:
  %t175 = load i8, ptr %l16, !tbaa !22
  %t177 = icmp eq i8 %t175, 60
  store i1 %t177, ptr %l104, !tbaa !21
  br label %bb43
bb43:
  %t179 = load i1, ptr %l104, !tbaa !21
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l9, !tbaa !24
  br label %bb58
bb45:
  %t184 = load i8, ptr %l16, !tbaa !22
  %t186 = icmp eq i8 %t184, 93
  br i1 %t186, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  %t188 = load i8, ptr %l16, !tbaa !22
  %t190 = icmp eq i8 %t188, 125
  store i1 %t190, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l111, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb51
bb50:
  %t193 = load i8, ptr %l16, !tbaa !22
  %t195 = icmp eq i8 %t193, 62
  store i1 %t195, ptr %l114, !tbaa !21
  br label %bb51
bb51:
  %t197 = load i1, ptr %l114, !tbaa !21
  br i1 %t197, label %bb52, label %bb53
bb52:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = sub i64 %t198, 1
  store i64 %t200, ptr %l9, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t204 = icmp eq i64 %t202, 0
  br i1 %t204, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  %t206 = load i64, ptr %l15, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t210 = load i64, ptr %l14, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l14, !tbaa !24
  br label %bb34
bb60:
  %t214 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
@.d1 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"define available_externally " }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d3 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22\0A\0A" }>, align 8
@.d5 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\0A!20 = !{!\22olang\22}\0A" }>, align 8
@.d6 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/runtime/" }>, align 8
@.d7 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d8 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c": cannot open this file" }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"; @prof " }>, align 8
@.d10 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"\22; @if\22 inside another" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"san" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d14 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a condition that is neither \22san\22 nor an architecture" }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"san" }>, align 8
@.d16 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"\22; @else\22 with no \22; @if\22 open" }>, align 8
@.d17 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"\22; @end\22 with no \22; @if\22 open" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c";" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"@@" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"@@" }>, align 8
@.d21 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"an \22@@\22 with no \22@@\22 closing it" }>, align 8
@.d22 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"an @@NAME@@ the compiler knows no fact for" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d23 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"\22; @if\22 with no \22; @end\22" }>, align 8
@.d24 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22\0A\0A" }>, align 8
@.d26 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"dyncall.ll" }>, align 8
@.d27 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"runtime.ll" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d28 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"san.ll" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d30 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prof.ll" }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d33 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = linkonce_odr " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d36 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" = comdat any\0A" }>, align 8
@.d37 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", comdat\0A" }>, align 8
@.d38 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" !dbg " }>, align 8
@.d41 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"@__olang_crash_handler(" }>, align 8
@.d42 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"@__olang_san_handler(" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" #1" }>, align 8
@.d44 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" #0" }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#1 {" }>, align 8
@.d46 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"#0 {" }>, align 8
@.d47 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"sanitize_thread " }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"\0Aattributes #0 = { null_pointer_is_valid " }>, align 8
@.d50 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" nounwind }\0A" }>, align 8
@.d51 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"attributes #1 = { null_pointer_is_valid " }>, align 8
@.d52 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" nounwind }\0A" }>, align 8
@.d53 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d55 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = type " }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d57 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = external " }>, align 8
@.d58 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"define internal " }>, align 8
@.d59 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"define private " }>, align 8
@.d60 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = internal " }>, align 8
@.d61 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = private " }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d64 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"declare " }>, align 8
@.d65 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d66 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d67 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d68 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d73 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = external " }>, align 8
@.d74 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"thread_local(" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d76 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d77 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unnamed_addr " }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d80 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"; @" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"if" }>, align 8
@.d83 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"else" }>, align 8
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"end" }>, align 8
@.d85 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d87 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d88 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d89 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"define internal " }>, align 8
@.d90 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"define private " }>, align 8
@.d91 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"alwaysinline" }>, align 8
@.d92 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"inlinehint" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_4678f23b07212b71_6204d41da44925a5 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6e9edb7ac3cc3a13_be559f1d61e4dd6f = external constant [0 x i8]
@olang_loc_6e8de55f6b48d5b6_301f420811d0f7f2 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
@olang_loc_37c6cc80b337eb95_eeee9a64b49e7a71 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5fea096add1795b8_392858cd9c11d804 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b0282b0bffd0a537_97cbf26a9ab19d0b = external constant [0 x i8]
@olang_loc_70ff22b8cac083da_c5bb23930b7510e = external constant [0 x i8]
@olang_loc_fb2acf0450ba6c79_597b56b8350f036d = external constant [0 x i8]
@olang_loc_950f08410a2cb2bb_86fc761ab025eedf = external constant [0 x i8]
@olang_loc_854a38a00260b8ab_4f9c9ff368cf0b17 = external constant [0 x i8]
@olang_loc_48912347760bc49b_7f197caf3eb31ff7 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_606763d33345b49e_888ff486d8884e9a = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_dc19f5cc01bc83fd_c395ac342fa7af39 = external constant [0 x i8]
@olang_loc_ea39e132cd3efa0c_1aef6a820179ae38 = external constant [0 x i8]
@olang_loc_d8a12b6fe56d9e39_f2cc2d97d79a0415 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_9d9b73c28e4e3d9a_299346768faaee36 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)
@olang_loc_9424fbeaf4790ef7_29a43c91e82e5293 = external constant [0 x i8]
@olang_loc_15c1087a8dcee578_9616249aba3f0cc = external constant [0 x i8]
@olang_loc_37b9d9dde30c0555_b630301b751c84f9 = external constant [0 x i8]
@olang_loc_2446b89a84efdb76_2c0483cfef229c5a = external constant [0 x i8]
@olang_loc_d4a9c3df34bd8bd3_6b2d8c232432bdb7 = external constant [0 x i8]
@olang_loc_885af16d4a3d8d64_d0eb96c61f9dafb0 = external constant [0 x i8]
@olang_loc_383c318151cd7051_6709cfbf24f79c8d = external constant [0 x i8]
@olang_loc_b26c87ed9711b455_3749eb6f37e52fe9 = external constant [0 x i8]
@olang_loc_6a493f8daef1bb51_6724bcad8f2aca45 = external constant [0 x i8]
@olang_loc_ba67ff79a761d864_bc768279035b5e68 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
