; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
@G_2ecompiler_2fruntime_2eArchs = constant <{ [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eArchs.k1, [8 x i8] c"\07\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eArchs.k2 }>, align 32
@G_2ecompiler_2fruntime_2eArchs.k1 = internal constant <{ [6 x i8] }> <{ [6 x i8] c"\78\38\36\5F\36\34" }>, align 8
@G_2ecompiler_2fruntime_2eArchs.k2 = internal constant <{ [7 x i8] }> <{ [7 x i8] c"\61\61\72\63\68\36\34" }>, align 8
@G_2ecompiler_2fruntime_2eFactArm = constant <{ [96 x i8] }> <{ [96 x i8] c"\80\00\00\00\00\00\00\00\10\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\40\00\00\00\00\00\00\00\38\01\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eFactNames = constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k1, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k2, [8 x i8] c"\09\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k3, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k4, [8 x i8] c"\0E\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k5, [8 x i8] c"\0B\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k6, [8 x i8] c"\18\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k7, [8 x i8] c"\12\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k8, [8 x i8] c"\0D\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k9, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k10, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k11, [8 x i8] c"\0F\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eFactNames.k12 }>, align 64
@G_2ecompiler_2fruntime_2eFactNames.k1 = internal constant <{ [10 x i8] }> <{ [10 x i8] c"\53\54\41\54\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k2 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\54\41\54\5F\4D\4F\44\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k3 = internal constant <{ [9 x i8] }> <{ [9 x i8] c"\53\54\41\54\5F\53\49\5A\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k4 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\53\54\41\54\5F\4D\54\49\4D\5F\53\45\43" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k5 = internal constant <{ [14 x i8] }> <{ [14 x i8] c"\53\54\41\54\5F\4D\54\49\4D\5F\4E\53\45\43" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k6 = internal constant <{ [11 x i8] }> <{ [11 x i8] c"\44\49\52\45\4E\54\5F\4E\41\4D\45" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k7 = internal constant <{ [24 x i8] }> <{ [24 x i8] c"\53\50\41\57\4E\5F\46\49\4C\45\5F\41\43\54\49\4F\4E\53\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k8 = internal constant <{ [18 x i8] }> <{ [18 x i8] c"\50\54\48\52\45\41\44\5F\41\54\54\52\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k9 = internal constant <{ [13 x i8] }> <{ [13 x i8] c"\4A\4D\50\5F\42\55\46\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k10 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\53\49\47\41\43\54\49\4F\4E\5F\42\59\54\45\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k11 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\53\49\47\41\43\54\49\4F\4E\5F\46\4C\41\47\53" }>, align 8
@G_2ecompiler_2fruntime_2eFactNames.k12 = internal constant <{ [15 x i8] }> <{ [15 x i8] c"\46\46\49\5F\44\45\46\41\55\4C\54\5F\41\42\49" }>, align 8
@G_2ecompiler_2fruntime_2eFactX86 = constant <{ [96 x i8] }> <{ [96 x i8] c"\90\00\00\00\00\00\00\00\18\00\00\00\00\00\00\00\30\00\00\00\00\00\00\00\58\00\00\00\00\00\00\00\60\00\00\00\00\00\00\00\13\00\00\00\00\00\00\00\50\00\00\00\00\00\00\00\38\00\00\00\00\00\00\00\C8\00\00\00\00\00\00\00\98\00\00\00\00\00\00\00\88\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00" }>, align 64
@G_2ecompiler_2fruntime_2eHeaderTbaa = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\74\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fruntime_2eHeaderTbaa.k1 }>, align 8
@G_2ecompiler_2fruntime_2eHeaderTbaa.k1 = internal constant <{ [116 x i8] }> <{ [116 x i8] c"\21\34\39\20\3D\20\21\7B\21\22\73\63\6F\70\65\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\30\20\3D\20\21\7B\21\22\63\68\75\6E\6B\68\64\72\22\2C\20\21\32\30\2C\20\69\36\34\20\30\7D\0A\21\35\39\20\3D\20\21\7B\21\34\39\2C\20\21\34\39\2C\20\69\36\34\20\30\7D\0A\21\36\30\20\3D\20\21\7B\21\35\30\2C\20\21\35\30\2C\20\69\36\34\20\30\7D\0A" }>, align 64
define dso_local void @compiler_2fruntime_2eArchs_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 6, ptr @.d0 }, 0
  %t2 = insertvalue [2 x { i64, ptr }] %t1, { i64, ptr } { i64 7, ptr @.d1 }, 1
  store [2 x { i64, ptr }] %t2, ptr @G_2ecompiler_2fruntime_2eArchs
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fruntime_2eDecls(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i1
  %l3 = alloca %"std/prelude/text:LineIter"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l5
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i1 false, ptr %l2, !tbaa !21
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l7
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l7
  store %"std/prelude/text:LineIter" %t6, ptr %l3
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l3)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l11
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l10
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t13, ptr %l8, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l11, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb9:
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t20 = load i1, ptr %l2, !tbaa !21
  br i1 %t20, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t22)
  br label %bb12
bb11:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t27 = call i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %t25)
  store i1 %t27, ptr %l21
  br label %bb18
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb13
bb13:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t29, { i64, ptr } { i64 1, ptr @.d3 })
  store i1 %t31, ptr %l19
  br label %bb14
bb14:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb15, label %bb16
bb15:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb18:
  %t33 = load i1, ptr %l21, !tbaa !21
  br i1 %t33, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l1, ptr %l22, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t34, ptr %l23, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t35, 0
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = icmp sge i64 7, 0
  br i1 %t41, label %bb21, label %bb22
bb20:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fruntime_2edeclare(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t43)
  br label %bb28
bb21:
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp sle i64 7, %t46
  br i1 %t47, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb23:
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb25:
  %t53 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l26, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 7
  %t57 = sub i64 %t55, 7
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } { i64 28, ptr @.d5 }, 1
  %t61 = extractvalue { i64, ptr } { i64 28, ptr @.d5 }, 0
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 1
  %t67 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 0
  %t68 = add i64 %t65, %t67
  %t69 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t60, i64 %t61)
  %t70 = getelementptr i8, ptr %t69, i64 %t61
  call void @olang_textcopy(ptr %t70, ptr %t63, i64 %t64)
  %t71 = getelementptr i8, ptr %t70, i64 %t64
  call void @olang_textcopy(ptr %t71, ptr %t66, i64 %t67)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t69, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = extractvalue { i64, ptr } %t73, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t81 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t81, { i64, ptr } %t80)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb27:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  br label %bb3
bb32:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 10)
  br label %bb33
bb33:
  %t85 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t85, ptr %l38
  br label %bb34
bb34:
  %t86 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t86, ptr %l39, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l40, !tbaa !24
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = mul i64 %t89, 1
  %t91 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t90)
  %t92 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l41, !tbaa !27
  %t94 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l40, !tbaa !24
  %t99 = mul i64 %t98, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t95, ptr %t97, i64 %t99, i1 false)
  %t100 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t100, ptr %l39, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t101 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eDyncallIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t2 = load i1, ptr %l3, !tbaa !21
  %t5 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t1, i1 %t2, i1 false)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l12, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = load i1, ptr %l3, !tbaa !21
  %t27 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %t23, i1 %t24, i1 true)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb5, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l17
  br label %bb4
bb4:
  %t32 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  br label %bb6
bb5:
  %t33 = load i32, ptr %l18, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  call void @__olang_scope_close(ptr %s0)
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t41, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb6:
  %t44 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t44, ptr %l6, !tbaa !27
  store { i64, ptr } %a0, ptr %l20, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = call { i64, ptr } @compiler_2fruntime_2eDecls(ptr %s0, ptr %s0, { i64, ptr } %t46)
  store { i64, ptr } %t48, ptr %l22
  br label %bb7
bb7:
  %t49 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t50 = load { i64, ptr }, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  %t51 = extractvalue { i64, ptr } { i64 17, ptr @.d7 }, 1
  %t52 = extractvalue { i64, ptr } { i64 17, ptr @.d7 }, 0
  %t53 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 1
  %t58 = extractvalue { i64, ptr } { i64 3, ptr @.d8 }, 0
  %t59 = add i64 %t56, %t58
  %t60 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t65 = extractvalue { i64, ptr } %t49, 1
  %t66 = extractvalue { i64, ptr } %t49, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 19, ptr @.d9 }, 1
  %t69 = extractvalue { i64, ptr } { i64 19, ptr @.d9 }, 0
  %t70 = add i64 %t67, %t69
  %t72 = extractvalue { i64, ptr } %t50, 1
  %t73 = extractvalue { i64, ptr } %t50, 0
  %t74 = add i64 %t70, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t51, i64 %t52)
  %t76 = getelementptr i8, ptr %t75, i64 %t52
  call void @olang_textcopy(ptr %t76, ptr %t54, i64 %t55)
  %t77 = getelementptr i8, ptr %t76, i64 %t55
  call void @olang_textcopy(ptr %t77, ptr %t57, i64 %t58)
  %t78 = getelementptr i8, ptr %t77, i64 %t58
  call void @olang_textcopy(ptr %t78, ptr %t61, i64 %t62)
  %t79 = getelementptr i8, ptr %t78, i64 %t62
  call void @olang_textcopy(ptr %t79, ptr %t65, i64 %t66)
  %t80 = getelementptr i8, ptr %t79, i64 %t66
  call void @olang_textcopy(ptr %t80, ptr %t68, i64 %t69)
  %t81 = getelementptr i8, ptr %t80, i64 %t69
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t75, 1
  %t91 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %s0, ptr %v2, ptr %v3, { i64, ptr } %t83, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t91, ptr %l29
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t92 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t93 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t92, 1
  store { i32, { i64, ptr } } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fruntime_2eFactArm_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [12 x i64] undef, i64 128, 0
  %t2 = insertvalue [12 x i64] %t1, i64 16, 1
  %t3 = insertvalue [12 x i64] %t2, i64 48, 2
  %t4 = insertvalue [12 x i64] %t3, i64 88, 3
  %t5 = insertvalue [12 x i64] %t4, i64 96, 4
  %t6 = insertvalue [12 x i64] %t5, i64 19, 5
  %t7 = insertvalue [12 x i64] %t6, i64 80, 6
  %t8 = insertvalue [12 x i64] %t7, i64 64, 7
  %t9 = insertvalue [12 x i64] %t8, i64 312, 8
  %t10 = insertvalue [12 x i64] %t9, i64 152, 9
  %t11 = insertvalue [12 x i64] %t10, i64 136, 10
  %t12 = insertvalue [12 x i64] %t11, i64 1, 11
  store [12 x i64] %t12, ptr @G_2ecompiler_2fruntime_2eFactArm
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fruntime_2eFactNames_2einit() #0 {
entry:
  %l0 = alloca [12 x { i64, ptr }]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 0
  store { i64, ptr } { i64 10, ptr @.d10 }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 1
  store { i64, ptr } { i64 9, ptr @.d11 }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 2
  store { i64, ptr } { i64 9, ptr @.d12 }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 3
  store { i64, ptr } { i64 13, ptr @.d13 }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 4
  store { i64, ptr } { i64 14, ptr @.d14 }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 5
  store { i64, ptr } { i64 11, ptr @.d15 }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 6
  store { i64, ptr } { i64 24, ptr @.d16 }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 7
  store { i64, ptr } { i64 18, ptr @.d17 }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 8
  store { i64, ptr } { i64 13, ptr @.d18 }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 9
  store { i64, ptr } { i64 15, ptr @.d19 }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 10
  store { i64, ptr } { i64 15, ptr @.d20 }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l0, i64 0, i64 11
  store { i64, ptr } { i64 15, ptr @.d21 }, ptr %t12, !tbaa !37
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fruntime_2eFactNames, ptr %l0, i64 192, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fruntime_2eFactX86_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [12 x i64] undef, i64 144, 0
  %t2 = insertvalue [12 x i64] %t1, i64 24, 1
  %t3 = insertvalue [12 x i64] %t2, i64 48, 2
  %t4 = insertvalue [12 x i64] %t3, i64 88, 3
  %t5 = insertvalue [12 x i64] %t4, i64 96, 4
  %t6 = insertvalue [12 x i64] %t5, i64 19, 5
  %t7 = insertvalue [12 x i64] %t6, i64 80, 6
  %t8 = insertvalue [12 x i64] %t7, i64 56, 7
  %t9 = insertvalue [12 x i64] %t8, i64 200, 8
  %t10 = insertvalue [12 x i64] %t9, i64 152, 9
  %t11 = insertvalue [12 x i64] %t10, i64 136, 10
  %t12 = insertvalue [12 x i64] %t11, i64 2, 11
  store [12 x i64] %t12, ptr @G_2ecompiler_2fruntime_2eFactX86
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l18 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l39 = alloca i32
  %l47 = alloca i64
  %l48 = alloca %"std/prelude/text:StringBuilder"
  %l50 = alloca %"std/prelude/text:LineIter"
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l61 = alloca i64
  %l67 = alloca i32
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l78 = alloca { i64, ptr }
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l91 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l105 = alloca i1
  %l107 = alloca i1
  %l112 = alloca i1
  %l116 = alloca i32
  %l119 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l133 = alloca i1
  %l137 = alloca i32
  %l147 = alloca i32
  %l152 = alloca { i64, ptr }
  %l153 = alloca i1
  %l158 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca { i64, ptr }
  %l168 = alloca i64
  %l169 = alloca i64
  %l174 = alloca { i64, ptr }
  %l176 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i64
  %l185 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i32
  %l193 = alloca i32
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %l197 = alloca i64
  %l198 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i32
  %l211 = alloca i32
  %l217 = alloca { i64, ptr }
  %l219 = alloca i64
  %l222 = alloca i64
  %l223 = alloca i64
  %l232 = alloca i32
  %l235 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l26
  br label %bb1
bb1:
  %t3 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 1
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t6 = extractvalue { i64, ptr } { i64 9, ptr @.d22 }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr @.d22 }, 0
  %t8 = add i64 %t5, %t7
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = add i64 %t8, %t11
  %t13 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t4, i64 %t5)
  %t14 = getelementptr i8, ptr %t13, i64 %t5
  call void @olang_textcopy(ptr %t14, ptr %t6, i64 %t7)
  %t15 = getelementptr i8, ptr %t14, i64 %t7
  call void @olang_textcopy(ptr %t15, ptr %t10, i64 %t11)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t13, 1
  store { i64, ptr } %t17, ptr %l3, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t21 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t19)
  %t22 = extractvalue { i32, { i64, ptr } } %t21, 1
  %t23 = extractvalue { i32, { i64, ptr } } %t21, 0
  store i32 %t23, ptr %l32
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb3, label %ok.25
ok.25:
  store { i64, ptr } %t22, ptr %l31
  br label %bb2
bb2:
  %t26 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t26, ptr %l29, !tbaa !27
  br label %bb13
bb3:
  %t27 = load i32, ptr %l32, !tbaa !23
  %t28 = ashr i32 %t27, 16
  %t30 = icmp eq i32 %t28, 1
  br i1 %t30, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t32 = load i32, ptr %l32, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 0, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t40, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 7, ptr @.d23 }, 1
  %t45 = extractvalue { i64, ptr } { i64 7, ptr @.d23 }, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 23, ptr @.d24 }, 1
  %t51 = extractvalue { i64, ptr } { i64 23, ptr @.d24 }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t44, i64 %t45)
  %t54 = getelementptr i8, ptr %t53, i64 %t45
  call void @olang_textcopy(ptr %t54, ptr %t47, i64 %t48)
  %t55 = getelementptr i8, ptr %t54, i64 %t48
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t66 = call i32 @std_2fio_2ePrintErrln(ptr %s2, { i64, ptr } %t64)
  store i32 %t66, ptr %l39
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb8, label %ok.68
ok.68:
  br label %bb7
bb7:
  br label %bb12
bb8:
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = ashr i32 %t69, 16
  %t72 = icmp eq i32 %t70, 1
  br i1 %t72, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = lshr i32 %t74, 16
  %t76 = and i32 %t74, 65535
  %t77 = icmp eq i32 %t75, 1
  %t78 = select i1 %t77, i32 0, i32 0
  %t79 = icmp eq i32 %t74, 0
  %t80 = shl i32 %t78, 16
  %t81 = or i32 %t80, %t76
  %t82 = select i1 %t79, i32 0, i32 %t81
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t84 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t82, 0
  store { i32, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t86 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t86, ptr %rv
  br label %ret
bb13:
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = call i64 @compiler_2fruntime_2earchRow(ptr %v1, { i64, ptr } %t91)
  store i64 %t93, ptr %l47
  br label %bb14
bb14:
  %t94 = load i64, ptr %l47, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t95, ptr %l48
  br label %bb15
bb15:
  %t96 = load %"std/prelude/text:StringBuilder", ptr %l48
  store %"std/prelude/text:StringBuilder" %t96, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t97)
  store %"std/prelude/text:LineIter" %t99, ptr %l50
  br label %bb16
bb16:
  %t100 = load %"std/prelude/text:LineIter", ptr %l50
  store %"std/prelude/text:LineIter" %t100, ptr %l13
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %l13)
  %t103 = extractvalue { i32, { i64, ptr } } %t102, 1
  %t104 = extractvalue { i32, { i64, ptr } } %t102, 0
  store i32 %t104, ptr %l54
  %t105 = icmp ne i32 %t104, 0
  br i1 %t105, label %bb19, label %ok.106
ok.106:
  store { i64, ptr } %t103, ptr %l53
  br label %bb18
bb18:
  %t107 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t107, ptr %l51, !tbaa !27
  br label %bb23
bb19:
  %t108 = load i32, ptr %l54, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  br i1 %t111, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t113 = load i32, ptr %l54, !tbaa !23
  %t114 = lshr i32 %t113, 16
  %t115 = and i32 %t113, 65535
  %t116 = icmp eq i32 %t114, 1
  %t117 = select i1 %t116, i32 0, i32 0
  %t118 = icmp eq i32 %t113, 0
  %t119 = shl i32 %t117, 16
  %t120 = or i32 %t119, %t115
  %t121 = select i1 %t118, i32 0, i32 %t120
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t123 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t121, 0
  store { i32, { i64, ptr } } %t123, ptr %rv
  br label %ret
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb169
bb23:
  %t124 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t124, ptr %l14, !tbaa !27
  %t125 = load i64, ptr %l8, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l8, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t131 = call i64 @compiler_2fruntime_2edirective(ptr %s0, { i64, ptr } %t129)
  store i64 %t131, ptr %l61
  br label %bb24
bb24:
  %t132 = load i64, ptr %l61, !tbaa !24
  store i64 %t132, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l15, !tbaa !24
  %t135 = icmp eq i64 %t133, 0
  br i1 %t135, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t137 = load i1, ptr %l9, !tbaa !21
  br i1 %t137, label %bb27, label %bb28
bb26:
  br label %bb79
bb27:
  store %olang.scope zeroinitializer, ptr %s8
  %t139 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = load i64, ptr %l8, !tbaa !24
  %t143 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s8, { i64, ptr } %t139, i64 %t140, { i64, ptr } { i64 22, ptr @.d25 })
  store i32 %t143, ptr %l67
  %t144 = icmp ne i32 %t143, 0
  br i1 %t144, label %bb30, label %ok.145
ok.145:
  br label %bb29
bb28:
  br label %bb32
bb29:
  br label %bb31
bb30:
  %t146 = load i32, ptr %l67, !tbaa !23
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t156 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t154, 0
  store { i32, { i64, ptr } } %t156, ptr %rv
  br label %ret
bb31:
  call void @__olang_scope_close(ptr %s8)
  br label %bb32
bb32:
  %t157 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t157, ptr %l69, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t158, 0
  store i64 %t161, ptr %l72, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l73, !tbaa !24
  %t164 = icmp sge i64 6, 0
  br i1 %t164, label %bb33, label %bb34
bb33:
  %t166 = load i64, ptr %l72, !tbaa !24
  %t167 = icmp sle i64 6, %t166
  br i1 %t167, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb35:
  %t169 = load i64, ptr %l72, !tbaa !24
  %t170 = load i64, ptr %l73, !tbaa !24
  %t171 = icmp sle i64 %t169, %t170
  br i1 %t171, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb37:
  %t173 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l72, !tbaa !24
  %t176 = getelementptr i8, ptr %t174, i64 6
  %t177 = sub i64 %t175, 6
  %t178 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t179)
  store { i64, ptr } %t181, ptr %l78
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb39:
  %t182 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t182, ptr %l16, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t185 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s7, { i64, ptr } %t183, { i64, ptr } { i64 1, ptr @.d27 })
  store i1 %t185, ptr %l80
  br label %bb40
bb40:
  %t186 = load i1, ptr %l80, !tbaa !21
  store i1 %t186, ptr %l17, !tbaa !21
  %t187 = load i1, ptr %l17, !tbaa !21
  br i1 %t187, label %bb41, label %bb42
bb41:
  %t189 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t189, ptr %l82, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t190, 0
  store i64 %t193, ptr %l85, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l86, !tbaa !24
  %t196 = icmp sge i64 1, 0
  br i1 %t196, label %bb43, label %bb44
bb42:
  br label %bb49
bb43:
  %t198 = load i64, ptr %l85, !tbaa !24
  %t199 = icmp sle i64 1, %t198
  br i1 %t199, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb45:
  %t201 = load i64, ptr %l85, !tbaa !24
  %t202 = load i64, ptr %l86, !tbaa !24
  %t203 = icmp sle i64 %t201, %t202
  br i1 %t203, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb47:
  %t205 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = load i64, ptr %l85, !tbaa !24
  %t208 = getelementptr i8, ptr %t206, i64 1
  %t209 = sub i64 %t207, 1
  %t210 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t208, 1
  store { i64, ptr } %t211, ptr %l16, !tbaa !27
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb49:
  %t213 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t215 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s7, { i64, ptr } %t213, { i64, ptr } { i64 1, ptr @.d29 })
  %t216 = extractvalue { i32, i64 } %t215, 1
  %t217 = extractvalue { i32, i64 } %t215, 0
  store i32 %t217, ptr %l94
  %t218 = icmp ne i32 %t217, 0
  br i1 %t218, label %bb51, label %ok.219
ok.219:
  store i64 %t216, ptr %l93
  br label %bb50
bb50:
  %t220 = load i64, ptr %l93, !tbaa !24
  store i64 %t220, ptr %l91, !tbaa !24
  br label %bb53
bb51:
  br label %bb52
bb52:
  store i64 -1, ptr %l91, !tbaa !24
  br label %bb53
bb53:
  %t221 = load i64, ptr %l91, !tbaa !24
  store i64 %t221, ptr %l18, !tbaa !24
  %t222 = load i64, ptr %l18, !tbaa !24
  %t224 = icmp sge i64 %t222, 0
  br i1 %t224, label %bb54, label %bb55
bb54:
  %t226 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t226, ptr %l97, !tbaa !27
  %t227 = load i64, ptr %l18, !tbaa !24
  store i64 %t227, ptr %l98, !tbaa !24
  %t228 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t228, 0
  store i64 %t229, ptr %l99, !tbaa !24
  %t230 = icmp sge i64 0, 0
  br i1 %t230, label %bb56, label %bb57
bb55:
  br label %bb62
bb56:
  %t232 = load i64, ptr %l98, !tbaa !24
  %t233 = icmp sle i64 0, %t232
  br i1 %t233, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb58:
  %t235 = load i64, ptr %l98, !tbaa !24
  %t236 = load i64, ptr %l99, !tbaa !24
  %t237 = icmp sle i64 %t235, %t236
  br i1 %t237, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb60:
  %t239 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = load i64, ptr %l98, !tbaa !24
  %t242 = getelementptr i8, ptr %t240, i64 0
  %t243 = sub i64 %t241, 0
  %t244 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t242, 1
  store { i64, ptr } %t245, ptr %l16, !tbaa !27
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
bb62:
  %t247 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t249 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t247, { i64, ptr } { i64 3, ptr @.d31 })
  store i1 %t249, ptr %l105
  br label %bb63
bb63:
  %t250 = load i1, ptr %l105, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb64, label %bb65
bb64:
  %t253 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t256 = insertvalue { i64, ptr } undef, i64 2, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr @G_2ecompiler_2fruntime_2eArchs, 1
  %t259 = load ptr, ptr @__olang_prog_scope
  %t262 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t259, ptr %s0, { i64, ptr } %t257, { i64, ptr } %t253)
  store i1 %t262, ptr %l112
  br label %bb66
bb65:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb67
bb66:
  %t263 = load i1, ptr %l112, !tbaa !21
  %t264 = xor i1 %t263, true
  store i1 %t264, ptr %l107, !tbaa !21
  br label %bb67
bb67:
  %t266 = load i1, ptr %l107, !tbaa !21
  br i1 %t266, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t267 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t268 = load i64, ptr %l8, !tbaa !24
  %t271 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s11, { i64, ptr } %t267, i64 %t268, { i64, ptr } { i64 53, ptr @.d32 })
  store i32 %t271, ptr %l116
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb71, label %ok.273
ok.273:
  br label %bb70
bb69:
  br label %bb73
bb70:
  br label %bb72
bb71:
  %t274 = load i32, ptr %l116, !tbaa !23
  %t275 = lshr i32 %t274, 16
  %t276 = and i32 %t274, 65535
  %t277 = icmp eq i32 %t275, 1
  %t278 = select i1 %t277, i32 1, i32 0
  %t279 = icmp eq i32 %t274, 0
  %t280 = shl i32 %t278, 16
  %t281 = or i32 %t280, %t276
  %t282 = select i1 %t279, i32 0, i32 %t281
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t284 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t282, 0
  store { i32, { i64, ptr } } %t284, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t285 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t287 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s7, { i64, ptr } %t285, { i64, ptr } { i64 3, ptr @.d33 })
  store i1 %t287, ptr %l119
  br label %bb74
bb74:
  %t288 = load i1, ptr %l119, !tbaa !21
  br i1 %t288, label %bb75, label %bb76
bb75:
  store i1 %a2, ptr %l120, !tbaa !21
  br label %bb78
bb76:
  %t291 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t291, { i64, ptr } %t292)
  store i1 %t295, ptr %l124
  br label %bb77
bb77:
  %t296 = load i1, ptr %l124, !tbaa !21
  store i1 %t296, ptr %l120, !tbaa !21
  br label %bb78
bb78:
  %t297 = load i1, ptr %l120, !tbaa !21
  %t299 = load i1, ptr %l17, !tbaa !21
  %t302 = icmp ne i1 %t297, %t299
  store i1 %t302, ptr %l11, !tbaa !21
  store i1 true, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t304 = load i64, ptr %l8, !tbaa !24
  store i64 %t304, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb79:
  %t306 = load i64, ptr %l15, !tbaa !24
  %t308 = icmp eq i64 %t306, 1
  br i1 %t308, label %bb80, label %bb81
bb80:
  %t310 = load i1, ptr %l9, !tbaa !21
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb82, label %bb83
bb81:
  br label %bb91
bb82:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb84
bb83:
  %t314 = load i1, ptr %l10, !tbaa !21
  store i1 %t314, ptr %l133, !tbaa !21
  br label %bb84
bb84:
  %t316 = load i1, ptr %l133, !tbaa !21
  br i1 %t316, label %bb85, label %bb86
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t317 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t318 = load i64, ptr %l8, !tbaa !24
  %t321 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s13, { i64, ptr } %t317, i64 %t318, { i64, ptr } { i64 30, ptr @.d34 })
  store i32 %t321, ptr %l137
  %t322 = icmp ne i32 %t321, 0
  br i1 %t322, label %bb88, label %ok.323
ok.323:
  br label %bb87
bb86:
  br label %bb90
bb87:
  br label %bb89
bb88:
  %t324 = load i32, ptr %l137, !tbaa !23
  %t325 = lshr i32 %t324, 16
  %t326 = and i32 %t324, 65535
  %t327 = icmp eq i32 %t325, 1
  %t328 = select i1 %t327, i32 1, i32 0
  %t329 = icmp eq i32 %t324, 0
  %t330 = shl i32 %t328, 16
  %t331 = or i32 %t330, %t326
  %t332 = select i1 %t329, i32 0, i32 %t331
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t334 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t332, 0
  store { i32, { i64, ptr } } %t334, ptr %rv
  br label %ret
bb89:
  call void @__olang_scope_close(ptr %s13)
  br label %bb90
bb90:
  %t335 = load i1, ptr %l11, !tbaa !21
  %t337 = xor i1 %t335, true
  store i1 %t337, ptr %l11, !tbaa !21
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb91:
  %t339 = load i64, ptr %l15, !tbaa !24
  %t341 = icmp eq i64 %t339, 2
  br i1 %t341, label %bb92, label %bb93
bb92:
  %t343 = load i1, ptr %l9, !tbaa !21
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb94, label %bb95
bb93:
  br label %bb100
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  %t347 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t348 = load i64, ptr %l8, !tbaa !24
  %t351 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s15, { i64, ptr } %t347, i64 %t348, { i64, ptr } { i64 29, ptr @.d35 })
  store i32 %t351, ptr %l147
  %t352 = icmp ne i32 %t351, 0
  br i1 %t352, label %bb97, label %ok.353
ok.353:
  br label %bb96
bb95:
  br label %bb99
bb96:
  br label %bb98
bb97:
  %t354 = load i32, ptr %l147, !tbaa !23
  %t355 = lshr i32 %t354, 16
  %t356 = and i32 %t354, 65535
  %t357 = icmp eq i32 %t355, 1
  %t358 = select i1 %t357, i32 1, i32 0
  %t359 = icmp eq i32 %t354, 0
  %t360 = shl i32 %t358, 16
  %t361 = or i32 %t360, %t356
  %t362 = select i1 %t359, i32 0, i32 %t361
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t364 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t362, 0
  store { i32, { i64, ptr } } %t364, ptr %rv
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb99
bb99:
  store i1 false, ptr %l9, !tbaa !21
  store i1 true, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb100:
  %t365 = load i1, ptr %l11, !tbaa !21
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb101, label %bb102
bb101:
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb102:
  br label %bb103
bb103:
  %t369 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t371 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %s0, { i64, ptr } %t369)
  store { i64, ptr } %t371, ptr %l152
  br label %bb104
bb104:
  %t372 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t373 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s6, { i64, ptr } %t372, { i64, ptr } { i64 1, ptr @.d36 })
  store i1 %t373, ptr %l153
  br label %bb105
bb105:
  %t374 = load i1, ptr %l153, !tbaa !21
  br i1 %t374, label %bb106, label %bb107
bb106:
  %t375 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t375)
  br label %bb108
bb107:
  br label %bb110
bb108:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l7, i8 10)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb110:
  %t379 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t379, ptr %l21, !tbaa !27
  br label %bb111
bb111:
  store %olang.scope zeroinitializer, ptr %s18
  %t381 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t383 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t381, { i64, ptr } { i64 2, ptr @.d37 })
  %t384 = extractvalue { i32, i64 } %t383, 1
  %t385 = extractvalue { i32, i64 } %t383, 0
  store i32 %t385, ptr %l161
  %t386 = icmp ne i32 %t385, 0
  br i1 %t386, label %bb113, label %ok.387
ok.387:
  store i64 %t384, ptr %l160
  br label %bb112
bb112:
  %t388 = load i64, ptr %l160, !tbaa !24
  store i64 %t388, ptr %l158, !tbaa !24
  br label %bb115
bb113:
  br label %bb114
bb114:
  store i64 -1, ptr %l158, !tbaa !24
  br label %bb115
bb115:
  %t389 = load i64, ptr %l158, !tbaa !24
  store i64 %t389, ptr %l22, !tbaa !24
  %t390 = load i64, ptr %l22, !tbaa !24
  %t392 = icmp slt i64 %t390, 0
  br i1 %t392, label %bb116, label %bb117
bb116:
  %t394 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t394)
  br label %bb118
bb117:
  br label %bb119
bb118:
  call void @__olang_scope_close(ptr %s18)
  br label %bb166
bb119:
  store ptr %l7, ptr %l166, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t397, ptr %l167, !tbaa !27
  %t398 = load i64, ptr %l22, !tbaa !24
  store i64 %t398, ptr %l168, !tbaa !24
  %t399 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 0
  store i64 %t400, ptr %l169, !tbaa !24
  %t401 = icmp sge i64 0, 0
  br i1 %t401, label %bb120, label %bb121
bb120:
  %t403 = load i64, ptr %l168, !tbaa !24
  %t404 = icmp sle i64 0, %t403
  br i1 %t404, label %bb122, label %bb123
bb121:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb122:
  %t406 = load i64, ptr %l168, !tbaa !24
  %t407 = load i64, ptr %l169, !tbaa !24
  %t408 = icmp sle i64 %t406, %t407
  br i1 %t408, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb124:
  %t410 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !27
  %t412 = load i64, ptr %l168, !tbaa !24
  %t413 = getelementptr i8, ptr %t411, i64 0
  %t414 = sub i64 %t412, 0
  %t415 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t413, 1
  %t417 = load ptr, ptr %l166, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t417, { i64, ptr } %t416)
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @.c38)
  unreachable
bb126:
  %t419 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t419, ptr %l174, !tbaa !27
  %t420 = load i64, ptr %l22, !tbaa !24
  %t422 = add i64 %t420, 2
  store i64 %t422, ptr %l176, !tbaa !24
  %t423 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t423, 0
  store i64 %t426, ptr %l179, !tbaa !24
  %t427 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  store i64 %t428, ptr %l180, !tbaa !24
  %t429 = load i64, ptr %l176, !tbaa !24
  %t430 = icmp sge i64 %t429, 0
  br i1 %t430, label %bb127, label %bb128
bb127:
  %t432 = load i64, ptr %l176, !tbaa !24
  %t433 = load i64, ptr %l179, !tbaa !24
  %t434 = icmp sle i64 %t432, %t433
  br i1 %t434, label %bb129, label %bb130
bb128:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb129:
  %t436 = load i64, ptr %l179, !tbaa !24
  %t437 = load i64, ptr %l180, !tbaa !24
  %t438 = icmp sle i64 %t436, %t437
  br i1 %t438, label %bb131, label %bb132
bb130:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb131:
  %t440 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = load i64, ptr %l176, !tbaa !24
  %t443 = load i64, ptr %l179, !tbaa !24
  %t444 = getelementptr i8, ptr %t441, i64 %t442
  %t445 = sub i64 %t443, %t442
  %t446 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t444, 1
  store { i64, ptr } %t447, ptr %l23, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t451 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s0, ptr %s18, { i64, ptr } %t449, { i64, ptr } { i64 2, ptr @.d40 })
  %t452 = extractvalue { i32, i64 } %t451, 1
  %t453 = extractvalue { i32, i64 } %t451, 0
  store i32 %t453, ptr %l188
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb134, label %ok.455
ok.455:
  store i64 %t452, ptr %l187
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @.c39)
  unreachable
bb133:
  %t456 = load i64, ptr %l187, !tbaa !24
  store i64 %t456, ptr %l185, !tbaa !24
  br label %bb136
bb134:
  br label %bb135
bb135:
  store i64 -1, ptr %l185, !tbaa !24
  br label %bb136
bb136:
  %t457 = load i64, ptr %l185, !tbaa !24
  store i64 %t457, ptr %l24, !tbaa !24
  %t458 = load i64, ptr %l24, !tbaa !24
  %t460 = icmp slt i64 %t458, 0
  br i1 %t460, label %bb137, label %bb138
bb137:
  store %olang.scope zeroinitializer, ptr %s20
  %t462 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t463 = load i64, ptr %l8, !tbaa !24
  %t466 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s20, { i64, ptr } %t462, i64 %t463, { i64, ptr } { i64 31, ptr @.d41 })
  store i32 %t466, ptr %l193
  %t467 = icmp ne i32 %t466, 0
  br i1 %t467, label %bb140, label %ok.468
ok.468:
  br label %bb139
bb138:
  br label %bb142
bb139:
  br label %bb141
bb140:
  %t469 = load i32, ptr %l193, !tbaa !23
  %t470 = lshr i32 %t469, 16
  %t471 = and i32 %t469, 65535
  %t472 = icmp eq i32 %t470, 1
  %t473 = select i1 %t472, i32 1, i32 0
  %t474 = icmp eq i32 %t469, 0
  %t475 = shl i32 %t473, 16
  %t476 = or i32 %t475, %t471
  %t477 = select i1 %t474, i32 0, i32 %t476
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t479 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t477, 0
  store { i32, { i64, ptr } } %t479, ptr %rv
  br label %ret
bb141:
  call void @__olang_scope_close(ptr %s20)
  br label %bb142
bb142:
  %t480 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t480, ptr %l196, !tbaa !27
  %t481 = load i64, ptr %l24, !tbaa !24
  store i64 %t481, ptr %l197, !tbaa !24
  %t482 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t483 = extractvalue { i64, ptr } %t482, 0
  store i64 %t483, ptr %l198, !tbaa !24
  %t484 = icmp sge i64 0, 0
  br i1 %t484, label %bb143, label %bb144
bb143:
  %t486 = load i64, ptr %l197, !tbaa !24
  %t487 = icmp sle i64 0, %t486
  br i1 %t487, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb145:
  %t489 = load i64, ptr %l197, !tbaa !24
  %t490 = load i64, ptr %l198, !tbaa !24
  %t491 = icmp sle i64 %t489, %t490
  br i1 %t491, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb147:
  %t493 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t494 = load ptr, ptr %t493, !tbaa !27
  %t495 = load i64, ptr %l197, !tbaa !24
  %t496 = getelementptr i8, ptr %t494, i64 0
  %t497 = sub i64 %t495, 0
  %t498 = insertvalue { i64, ptr } undef, i64 %t497, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr %t496, 1
  %t500 = load i64, ptr %l6, !tbaa !24
  %t503 = call { i32, i64 } @compiler_2fruntime_2efact(ptr %s0, { i64, ptr } %t499, i64 %t500)
  %t504 = extractvalue { i32, i64 } %t503, 1
  %t505 = extractvalue { i32, i64 } %t503, 0
  store i32 %t505, ptr %l205
  %t506 = icmp ne i32 %t505, 0
  br i1 %t506, label %bb150, label %ok.507
ok.507:
  store i64 %t504, ptr %l204
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
bb149:
  %t508 = load i64, ptr %l204, !tbaa !24
  store i64 %t508, ptr %l195, !tbaa !24
  br label %bb157
bb150:
  %t509 = load i32, ptr %l205, !tbaa !23
  %t510 = ashr i32 %t509, 16
  %t512 = icmp eq i32 %t510, 1
  br i1 %t512, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  %t514 = load i32, ptr %l205, !tbaa !23
  %t515 = lshr i32 %t514, 16
  %t516 = and i32 %t514, 65535
  %t517 = icmp eq i32 %t515, 1
  %t518 = select i1 %t517, i32 1, i32 0
  %t519 = icmp eq i32 %t514, 0
  %t520 = shl i32 %t518, 16
  %t521 = or i32 %t520, %t516
  %t522 = select i1 %t519, i32 0, i32 %t521
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t524 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t522, 0
  store { i32, { i64, ptr } } %t524, ptr %rv
  br label %ret
bb153:
  store %olang.scope zeroinitializer, ptr %s21
  %t525 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t526 = load i64, ptr %l8, !tbaa !24
  %t529 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s21, { i64, ptr } %t525, i64 %t526, { i64, ptr } { i64 42, ptr @.d43 })
  store i32 %t529, ptr %l211
  %t530 = icmp ne i32 %t529, 0
  br i1 %t530, label %bb155, label %ok.531
ok.531:
  br label %bb154
bb154:
  br label %bb156
bb155:
  %t532 = load i32, ptr %l211, !tbaa !23
  %t533 = lshr i32 %t532, 16
  %t534 = and i32 %t532, 65535
  %t535 = icmp eq i32 %t533, 1
  %t536 = select i1 %t535, i32 1, i32 0
  %t537 = icmp eq i32 %t532, 0
  %t538 = shl i32 %t536, 16
  %t539 = or i32 %t538, %t534
  %t540 = select i1 %t537, i32 0, i32 %t539
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t542 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t540, 0
  store { i32, { i64, ptr } } %t542, ptr %rv
  br label %ret
bb156:
  call void @__olang_check_failed(ptr @.c44)
  unreachable
bb157:
  %t543 = load i64, ptr %l195, !tbaa !24
  %t546 = call i64 @__olang_fmt_i64(ptr null, i64 %t543)
  %t547 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t546)
  %t548 = call i64 @__olang_fmt_i64(ptr %t547, i64 %t543)
  %t549 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t547, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = extractvalue { i64, ptr } %t550, 1
  %t554 = mul i64 %t552, 1
  %t555 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t555, ptr %t553, i64 %t554, i1 false)
  %t556 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %l7, { i64, ptr } %t557)
  br label %bb158
bb158:
  %t560 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t560, ptr %l217, !tbaa !27
  %t561 = load i64, ptr %l24, !tbaa !24
  %t563 = add i64 %t561, 2
  store i64 %t563, ptr %l219, !tbaa !24
  %t564 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t564, 0
  store i64 %t567, ptr %l222, !tbaa !24
  %t568 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  store i64 %t569, ptr %l223, !tbaa !24
  %t570 = load i64, ptr %l219, !tbaa !24
  %t571 = icmp sge i64 %t570, 0
  br i1 %t571, label %bb159, label %bb160
bb159:
  %t573 = load i64, ptr %l219, !tbaa !24
  %t574 = load i64, ptr %l222, !tbaa !24
  %t575 = icmp sle i64 %t573, %t574
  br i1 %t575, label %bb161, label %bb162
bb160:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb161:
  %t577 = load i64, ptr %l222, !tbaa !24
  %t578 = load i64, ptr %l223, !tbaa !24
  %t579 = icmp sle i64 %t577, %t578
  br i1 %t579, label %bb163, label %bb164
bb162:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb163:
  %t581 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t582 = load ptr, ptr %t581, !tbaa !27
  %t583 = load i64, ptr %l219, !tbaa !24
  %t584 = load i64, ptr %l222, !tbaa !24
  %t585 = getelementptr i8, ptr %t582, i64 %t583
  %t586 = sub i64 %t584, %t583
  %t587 = insertvalue { i64, ptr } undef, i64 %t586, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t585, 1
  store { i64, ptr } %t588, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s18)
  br label %bb165
bb164:
  call void @__olang_check_failed(ptr @.c45)
  unreachable
bb165:
  br label %bb111
bb166:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l7, i8 10)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s6)
  br label %bb168
bb168:
  br label %bb17
bb169:
  %t591 = load i1, ptr %l9, !tbaa !21
  br i1 %t591, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s23
  %t593 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t594 = load i64, ptr %l12, !tbaa !24
  %t597 = call i32 @compiler_2fruntime_2emalformed(ptr %s0, ptr %s23, { i64, ptr } %t593, i64 %t594, { i64, ptr } { i64 24, ptr @.d46 })
  store i32 %t597, ptr %l232
  %t598 = icmp ne i32 %t597, 0
  br i1 %t598, label %bb173, label %ok.599
ok.599:
  br label %bb172
bb171:
  br label %bb175
bb172:
  br label %bb174
bb173:
  %t600 = load i32, ptr %l232, !tbaa !23
  %t601 = lshr i32 %t600, 16
  %t602 = and i32 %t600, 65535
  %t603 = icmp eq i32 %t601, 1
  %t604 = select i1 %t603, i32 1, i32 0
  %t605 = icmp eq i32 %t600, 0
  %t606 = shl i32 %t604, 16
  %t607 = or i32 %t606, %t602
  %t608 = select i1 %t605, i32 0, i32 %t607
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t610 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t608, 0
  store { i32, { i64, ptr } } %t610, ptr %rv
  br label %ret
bb174:
  call void @__olang_scope_close(ptr %s23)
  br label %bb175
bb175:
  %t612 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l7)
  store { i64, ptr } %t612, ptr %l235
  br label %bb176
bb176:
  %t613 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t613, ptr %l236, !tbaa !27
  %t614 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t615 = extractvalue { i64, ptr } %t614, 0
  store i64 %t615, ptr %l237, !tbaa !24
  %t616 = load i64, ptr %l237, !tbaa !24
  %t617 = mul i64 %t616, 1
  %t618 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t617)
  %t619 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  store { i64, ptr } %t620, ptr %l238, !tbaa !27
  %t621 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t624 = load ptr, ptr %t623, !tbaa !27
  %t625 = load i64, ptr %l237, !tbaa !24
  %t626 = mul i64 %t625, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t622, ptr %t624, i64 %t626, i1 false)
  %t627 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t627, ptr %l236, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t628 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t629 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t628, 1
  store { i32, { i64, ptr } } %t629, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fruntime_2eHeaderTbaa_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 66, ptr @.d47 }, 1
  %t2 = extractvalue { i64, ptr } { i64 66, ptr @.d47 }, 0
  %t3 = extractvalue { i64, ptr } { i64 50, ptr @.d48 }, 1
  %t4 = extractvalue { i64, ptr } { i64 50, ptr @.d48 }, 0
  %t5 = add i64 %t2, %t4
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call ptr @__olang_scope_alloc(ptr %t6, i64 %t5)
  call void @olang_textcopy(ptr %t7, ptr %t1, i64 %t2)
  %t8 = getelementptr i8, ptr %t7, i64 %t2
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t7, 1
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } %t10, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %t12, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr @G_2ecompiler_2fruntime_2eHeaderTbaa, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eIr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = call { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v1, ptr %s0, { i64, ptr } %a1, i1 %a3, i1 false)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t10, ptr %l6, !tbaa !27
  br label %bb3
bb2:
  %t11 = load i32, ptr %l10, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  call void @__olang_scope_close(ptr %s0)
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t19, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb3:
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = extractvalue { i64, ptr } { i64 17, ptr @.d49 }, 1
  %t26 = extractvalue { i64, ptr } { i64 17, ptr @.d49 }, 0
  %t28 = extractvalue { i64, ptr } %a0, 1
  %t29 = extractvalue { i64, ptr } %a0, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 3, ptr @.d50 }, 1
  %t32 = extractvalue { i64, ptr } { i64 3, ptr @.d50 }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %t22, 1
  %t36 = extractvalue { i64, ptr } %t22, 0
  %t37 = add i64 %t33, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t25, i64 %t26)
  %t39 = getelementptr i8, ptr %t38, i64 %t26
  call void @olang_textcopy(ptr %t39, ptr %t28, i64 %t29)
  %t40 = getelementptr i8, ptr %t39, i64 %t29
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t38, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t56 = call { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v3, ptr %v2, ptr %v3, { i64, ptr } %t50, { i64, ptr } %a2, i1 %a4)
  store { i64, ptr } %t56, ptr %l18
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t57, 1
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fruntime_2eText(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %lp3 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br i1 %a2, label %bb1, label %bb2
bb1:
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = load i1, ptr %l1, !tbaa !21
  %t7 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr @.d51 }, { i64, ptr } %t3, i1 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l9
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  br label %bb5
bb4:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  call void @__olang_scope_close(ptr %s0)
  %t23 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t21, 0
  store { i32, { i64, ptr } } %t23, ptr %rv
  br label %ret
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t24, 1
  store { i32, { i64, ptr } } %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = load i1, ptr %l1, !tbaa !21
  %t30 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %v1, ptr %v0, ptr %v1, { i64, ptr } { i64 10, ptr @.d52 }, { i64, ptr } %t26, i1 %t27)
  %t31 = extractvalue { i32, { i64, ptr } } %t30, 1
  %t32 = extractvalue { i32, { i64, ptr } } %t30, 0
  store i32 %t32, ptr %l16
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb8, label %ok.34
ok.34:
  store { i64, ptr } %t31, ptr %l15
  br label %bb7
bb7:
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  br label %bb9
bb8:
  %t36 = load i32, ptr %l16, !tbaa !23
  %t37 = lshr i32 %t36, 16
  %t38 = and i32 %t36, 65535
  %t39 = icmp eq i32 %t37, 1
  %t40 = select i1 %t39, i32 1, i32 0
  %t41 = icmp eq i32 %t36, 0
  %t42 = shl i32 %t40, 16
  %t43 = or i32 %t42, %t38
  %t44 = select i1 %t41, i32 0, i32 %t43
  call void @__olang_scope_close(ptr %s0)
  %t46 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t44, 0
  store { i32, { i64, ptr } } %t46, ptr %rv
  br label %ret
bb9:
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t47, ptr %lp3
  %t48 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t49 = load ptr, ptr %lp3
  store { i64, ptr } %t48, ptr %t49, !tbaa !27
  %t50 = load i1, ptr %l1, !tbaa !21
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load ptr, ptr %lp3
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t55, 1
  store { i32, { i64, ptr } } %t57, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = load i1, ptr %l1, !tbaa !21
  %t62 = call { i32, { i64, ptr } } @compiler_2fruntime_2eFill(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 6, ptr @.d53 }, { i64, ptr } %t58, i1 %t59)
  %t63 = extractvalue { i32, { i64, ptr } } %t62, 1
  %t64 = extractvalue { i32, { i64, ptr } } %t62, 0
  store i32 %t64, ptr %l25
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb14, label %ok.66
ok.66:
  store { i64, ptr } %t63, ptr %l24
  br label %bb13
bb13:
  %t67 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t67, ptr %l21, !tbaa !27
  br label %bb15
bb14:
  %t68 = load i32, ptr %l25, !tbaa !23
  %t69 = lshr i32 %t68, 16
  %t70 = and i32 %t68, 65535
  %t71 = icmp eq i32 %t69, 1
  %t72 = select i1 %t71, i32 1, i32 0
  %t73 = icmp eq i32 %t68, 0
  %t74 = shl i32 %t72, 16
  %t75 = or i32 %t74, %t70
  %t76 = select i1 %t73, i32 0, i32 %t75
  call void @__olang_scope_close(ptr %s0)
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t76, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb15:
  %t79 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t80 = load ptr, ptr %lp3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = extractvalue { i64, ptr } %t81, 0
  %t86 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 1
  %t87 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 0
  %t88 = add i64 %t85, %t87
  %t90 = extractvalue { i64, ptr } %t79, 1
  %t91 = extractvalue { i64, ptr } %t79, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t84, i64 %t85)
  %t94 = getelementptr i8, ptr %t93, i64 %t85
  call void @olang_textcopy(ptr %t94, ptr %t86, i64 %t87)
  %t95 = getelementptr i8, ptr %t94, i64 %t87
  call void @olang_textcopy(ptr %t95, ptr %t90, i64 %t91)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  call void @__olang_scope_close(ptr %s0)
  %t99 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t97, 1
  store { i32, { i64, ptr } } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fruntime_2eWithAttributes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca %"std/prelude/text:LineIter"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca %"std/prelude/text:LineIter"
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i1
  %l29 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i32
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i32
  %l59 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i1
  %l75 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l84 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l98 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t2, ptr %l3
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l13
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l13
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %l4)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l17
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12
ok.12:
  store { i64, ptr } %t9, ptr %l16
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l14, !tbaa !27
  br label %bb9
bb5:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb86
bb9:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t19, ptr %l5, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr @.d56 })
  store i1 %t22, ptr %l21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l21, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t24, { i64, ptr } { i64 16, ptr @.d57 })
  %t27 = extractvalue { i32, i64 } %t26, 1
  %t28 = extractvalue { i32, i64 } %t26, 0
  store i32 %t28, ptr %l25
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb14, label %ok.30
ok.30:
  store i64 %t27, ptr %l24
  br label %bb13
bb12:
  br label %bb36
bb13:
  %t31 = load i64, ptr %l24, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb16
bb16:
  %t32 = load i64, ptr %l22, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb17, label %bb18
bb17:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t39 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s3, { i64, ptr } %t37, { i64, ptr } { i64 1, ptr @.d58 })
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l32
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb20, label %ok.43
ok.43:
  store i64 %t40, ptr %l31
  br label %bb19
bb18:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb23
bb19:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l29, !tbaa !24
  br label %bb22
bb20:
  br label %bb21
bb21:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb22
bb22:
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l29, !tbaa !24
  %t48 = icmp eq i64 %t46, %t45
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb23
bb23:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l35, !tbaa !29
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l36, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 1, 0
  br i1 %t55, label %bb26, label %bb27
bb25:
  br label %bb35
bb26:
  %t57 = load i64, ptr %l37, !tbaa !24
  %t58 = icmp sle i64 1, %t57
  br i1 %t58, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb28:
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = icmp sle i64 %t60, %t61
  br i1 %t62, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb30:
  %t64 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l37, !tbaa !24
  %t67 = getelementptr i8, ptr %t65, i64 1
  %t68 = sub i64 %t66, 1
  %t69 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t74 = extractvalue { i64, ptr } %t70, 1
  %t75 = extractvalue { i64, ptr } %t70, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 14, ptr @.d61 }, 1
  %t78 = extractvalue { i64, ptr } { i64 14, ptr @.d61 }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t92 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t92, { i64, ptr } %t91)
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb32:
  %t94 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t94)
  br label %bb33
bb33:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 9, ptr @.d62 })
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb36:
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s2, { i64, ptr } %t98, { i64, ptr } { i64 7, ptr @.d63 })
  store i1 %t100, ptr %l49
  br label %bb37
bb37:
  %t101 = load i1, ptr %l49, !tbaa !21
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t102 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s2, { i64, ptr } %t102, { i64, ptr } { i64 1, ptr @.d64 })
  store i1 %t104, ptr %l52
  br label %bb40
bb39:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb41
bb40:
  %t105 = load i1, ptr %l52, !tbaa !21
  store i1 %t105, ptr %l50, !tbaa !21
  br label %bb41
bb41:
  %t106 = load i1, ptr %l50, !tbaa !21
  br i1 %t106, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t109 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s6, { i64, ptr } %t107, { i64, ptr } { i64 6, ptr @.d65 })
  %t110 = extractvalue { i32, i64 } %t109, 1
  %t111 = extractvalue { i32, i64 } %t109, 0
  store i32 %t111, ptr %l56
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb45, label %ok.113
ok.113:
  store i64 %t110, ptr %l55
  br label %bb44
bb43:
  br label %bb82
bb44:
  %t114 = load i64, ptr %l55, !tbaa !24
  store i64 %t114, ptr %l53, !tbaa !24
  br label %bb47
bb45:
  br label %bb46
bb46:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb47
bb47:
  %t115 = load i64, ptr %l53, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = icmp sge i64 %t116, 0
  br i1 %t118, label %bb48, label %bb49
bb48:
  %t120 = load i64, ptr %l7, !tbaa !24
  store i64 %t120, ptr %l59, !tbaa !24
  br label %bb50
bb49:
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = sub i64 %t124, 1
  store i64 %t126, ptr %l59, !tbaa !24
  br label %bb50
bb50:
  %t128 = load i64, ptr %l59, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t129, ptr %l64, !tbaa !27
  store i64 %t128, ptr %l65, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l66, !tbaa !24
  %t133 = icmp sge i64 0, 0
  br i1 %t133, label %bb51, label %bb52
bb51:
  %t135 = load i64, ptr %l65, !tbaa !24
  %t136 = icmp sle i64 0, %t135
  br i1 %t136, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb53:
  %t138 = load i64, ptr %l65, !tbaa !24
  %t139 = load i64, ptr %l66, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb55:
  %t142 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l65, !tbaa !24
  %t145 = getelementptr i8, ptr %t143, i64 0
  %t146 = sub i64 %t144, 0
  %t147 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  store { i64, ptr } %t148, ptr %l9, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 23, ptr @.d67 }, ptr %l73, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t154 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t150, { i64, ptr } %t153)
  store i1 %t154, ptr %l74
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb57:
  %t155 = load i1, ptr %l74, !tbaa !21
  br i1 %t155, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb61
bb59:
  %t156 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 21, ptr @.d68 }, ptr %l78, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t160 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s6, { i64, ptr } %t156, { i64, ptr } %t159)
  store i1 %t160, ptr %l79
  br label %bb60
bb60:
  %t161 = load i1, ptr %l79, !tbaa !21
  store i1 %t161, ptr %l75, !tbaa !21
  br label %bb61
bb61:
  %t162 = load i1, ptr %l75, !tbaa !21
  store i1 %t162, ptr %l10, !tbaa !21
  %t163 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t163)
  br label %bb62
bb62:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l3, ptr %l84, !tbaa !29
  %t170 = load i1, ptr %l10, !tbaa !21
  br i1 %t170, label %bb65, label %bb66
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l3, ptr %l98, !tbaa !29
  %t172 = load i1, ptr %l10, !tbaa !21
  br i1 %t172, label %bb76, label %bb77
bb65:
  store { i64, ptr } { i64 3, ptr @.d69 }, ptr %l86, !tbaa !27
  br label %bb67
bb66:
  store { i64, ptr } { i64 3, ptr @.d70 }, ptr %l86, !tbaa !27
  br label %bb67
bb67:
  %t174 = load ptr, ptr %l84, !tbaa !29
  %t175 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t174, { i64, ptr } %t175)
  br label %bb68
bb68:
  store ptr %l3, ptr %l87, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t176, ptr %l88, !tbaa !27
  %t177 = load i64, ptr %l7, !tbaa !24
  store i64 %t177, ptr %l89, !tbaa !24
  %t178 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t178, 0
  store i64 %t181, ptr %l92, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l93, !tbaa !24
  %t184 = load i64, ptr %l89, !tbaa !24
  %t185 = icmp sge i64 %t184, 0
  br i1 %t185, label %bb69, label %bb70
bb69:
  %t187 = load i64, ptr %l89, !tbaa !24
  %t188 = load i64, ptr %l92, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb71:
  %t191 = load i64, ptr %l92, !tbaa !24
  %t192 = load i64, ptr %l93, !tbaa !24
  %t193 = icmp sle i64 %t191, %t192
  br i1 %t193, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb73:
  %t195 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l89, !tbaa !24
  %t198 = load i64, ptr %l92, !tbaa !24
  %t199 = getelementptr i8, ptr %t196, i64 %t197
  %t200 = sub i64 %t198, %t197
  %t201 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t199, 1
  %t203 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t203, { i64, ptr } %t202)
  br label %bb75
bb74:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb75:
  call void @__olang_scope_close(ptr %s7)
  br label %bb80
bb76:
  store { i64, ptr } { i64 4, ptr @.d72 }, ptr %l100, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 4, ptr @.d73 }, ptr %l100, !tbaa !27
  br label %bb78
bb78:
  %t205 = load ptr, ptr %l98, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l100, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %t205, { i64, ptr } %t206)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s8)
  br label %bb80
bb80:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb82:
  %t208 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t208)
  br label %bb83
bb83:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 10)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s2)
  br label %bb85
bb85:
  br label %bb3
bb86:
  store ptr %l3, ptr %l105, !tbaa !29
  br i1 %a2, label %bb87, label %bb88
bb87:
  store { i64, ptr } { i64 16, ptr @.d74 }, ptr %l107, !tbaa !27
  br label %bb89
bb88:
  store { i64, ptr } { i64 0, ptr @.d75 }, ptr %l107, !tbaa !27
  br label %bb89
bb89:
  %t214 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = extractvalue { i64, ptr } { i64 41, ptr @.d76 }, 1
  %t216 = extractvalue { i64, ptr } { i64 41, ptr @.d76 }, 0
  %t217 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t220 = add i64 %t216, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 1
  %t226 = extractvalue { i64, ptr } { i64 3, ptr @.d77 }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t215, i64 %t216)
  %t229 = getelementptr i8, ptr %t228, i64 %t216
  call void @olang_textcopy(ptr %t229, ptr %t218, i64 %t219)
  %t230 = getelementptr i8, ptr %t229, i64 %t219
  call void @olang_textcopy(ptr %t230, ptr %t222, i64 %t223)
  %t231 = getelementptr i8, ptr %t230, i64 %t223
  call void @olang_textcopy(ptr %t231, ptr %t225, i64 %t226)
  %t232 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t228, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t241, { i64, ptr } %t240)
  br label %bb90
bb90:
  %t243 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t244 = extractvalue { i64, ptr } { i64 40, ptr @.d78 }, 1
  %t245 = extractvalue { i64, ptr } { i64 40, ptr @.d78 }, 0
  %t247 = extractvalue { i64, ptr } %t243, 1
  %t248 = extractvalue { i64, ptr } %t243, 0
  %t249 = add i64 %t245, %t248
  %t250 = extractvalue { i64, ptr } { i64 3, ptr @.d79 }, 1
  %t251 = extractvalue { i64, ptr } { i64 3, ptr @.d79 }, 0
  %t252 = add i64 %t249, %t251
  %t253 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t252)
  call void @olang_textcopy(ptr %t253, ptr %t244, i64 %t245)
  %t254 = getelementptr i8, ptr %t253, i64 %t245
  call void @olang_textcopy(ptr %t254, ptr %t247, i64 %t248)
  %t255 = getelementptr i8, ptr %t254, i64 %t248
  call void @olang_textcopy(ptr %t255, ptr %t250, i64 %t251)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t253, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = extractvalue { i64, ptr } %t257, 1
  %t261 = mul i64 %t259, 1
  %t262 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t261)
  call void @llvm.memcpy.p0.p0.i64(ptr %t262, ptr %t260, i64 %t261, i1 false)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t264)
  br label %bb91
bb91:
  %t268 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l3)
  store { i64, ptr } %t268, ptr %l116
  br label %bb92
bb92:
  %t269 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t269, ptr %l117, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  store i64 %t271, ptr %l118, !tbaa !24
  %t272 = load i64, ptr %l118, !tbaa !24
  %t273 = mul i64 %t272, 1
  %t274 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  store { i64, ptr } %t276, ptr %l119, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = load i64, ptr %l118, !tbaa !24
  %t282 = mul i64 %t281, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t278, ptr %t280, i64 %t282, i1 false)
  %t283 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t283, ptr %l117, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t284 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t284, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fruntime_2earchRow(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l36 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs
  store i64 2, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp sgt i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l12, !tbaa !24
  br label %bb6
bb3:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = sub i64 %t14, %t15
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t24 = sub i64 %t22, 1
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sdiv i64 %t24, %t25
  store i64 %t28, ptr %l15, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb5
bb5:
  %t30 = load i64, ptr %l15, !tbaa !24
  store i64 %t30, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l12, !tbaa !24
  store i64 %t31, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t40 = load i64, ptr %l1, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = mul i64 %t41, %t42
  %t48 = add i64 %t40, %t45
  store i64 %t48, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t52 = getelementptr [2 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eArchs, i64 0, i64 %t50
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t55, ptr %v0, { i64, ptr } %t53, { i64, ptr } %a0)
  store i1 %t58, ptr %l36
  br label %bb11
bb11:
  %t59 = load i1, ptr %l36, !tbaa !21
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t60 = load i64, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t60, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l5, !tbaa !24
  br label %bb7
bb16:
  store i64 0, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fruntime_2edeclare(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i32
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l96 = alloca i1
  %l99 = alloca i1
  %l106 = alloca i1
  %l113 = alloca i1
  %l116 = alloca i1
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i32
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i64
  %l147 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l164 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i64
  %l173 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i32
  %l179 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l187 = alloca { i64, ptr }
  %l191 = alloca i1
  %l192 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i32
  %l196 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l198 = alloca i64
  %l199 = alloca i64
  %l206 = alloca { i64, ptr }
  %l208 = alloca i64
  %l211 = alloca i64
  %l212 = alloca i64
  %l218 = alloca i1
  %l219 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i32
  %l223 = alloca ptr
  %l224 = alloca { i64, ptr }
  %l226 = alloca i64
  %l227 = alloca i64
  %l234 = alloca { i64, ptr }
  %l236 = alloca i64
  %l239 = alloca i64
  %l240 = alloca i64
  %l246 = alloca i1
  %l247 = alloca { i64, ptr }
  %l250 = alloca i64
  %l251 = alloca i64
  %l256 = alloca i64
  %l258 = alloca i64
  %l259 = alloca i32
  %l267 = alloca i64
  %l271 = alloca i64
  %l274 = alloca ptr
  %l275 = alloca { i64, ptr }
  %l277 = alloca i64
  %l278 = alloca i64
  %l282 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l285 = alloca i64
  %l286 = alloca i64
  %l287 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 8, ptr @.d80 })
  store i1 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i1, ptr %l18, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb3:
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 1, ptr @.d81 })
  store i1 %t7, ptr %l21
  br label %bb4
bb4:
  %t8 = load i1, ptr %l21, !tbaa !21
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 8, ptr @.d82 }, ptr %l25, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t13 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t9, { i64, ptr } %t12)
  store i1 %t13, ptr %l26
  br label %bb7
bb6:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t14 = load i1, ptr %l26, !tbaa !21
  store i1 %t14, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t15 = load i1, ptr %l22, !tbaa !21
  store i1 %t15, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l19, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb11:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 1, ptr @.d83 })
  store i1 %t19, ptr %l29
  br label %bb12
bb12:
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb13, label %bb14
bb13:
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d84 }, ptr %l33, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t25 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } %t24)
  store i1 %t25, ptr %l34
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb15:
  %t26 = load i1, ptr %l34, !tbaa !21
  store i1 %t26, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t27 = load i1, ptr %l30, !tbaa !21
  store i1 %t27, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb18, label %bb19
bb18:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t29, { i64, ptr } %t30)
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t33 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t33, i8 10)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb22:
  %t35 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t35, { i64, ptr } { i64 16, ptr @.d85 })
  store i1 %t37, ptr %l39
  br label %bb23
bb23:
  %t38 = load i1, ptr %l39, !tbaa !21
  br i1 %t38, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t39, { i64, ptr } { i64 15, ptr @.d86 })
  store i1 %t41, ptr %l42
  br label %bb26
bb26:
  %t42 = load i1, ptr %l42, !tbaa !21
  store i1 %t42, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t43 = load i1, ptr %l40, !tbaa !21
  br i1 %t43, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb31
bb29:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d87 }, ptr %l46, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t48 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t44, { i64, ptr } %t47)
  store i1 %t48, ptr %l47
  br label %bb30
bb30:
  %t49 = load i1, ptr %l47, !tbaa !21
  store i1 %t49, ptr %l43, !tbaa !21
  br label %bb31
bb31:
  %t50 = load i1, ptr %l43, !tbaa !21
  br i1 %t50, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb35
bb33:
  %t51 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 11, ptr @.d88 }, ptr %l51, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t55 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t51, { i64, ptr } %t54)
  store i1 %t55, ptr %l52
  br label %bb34
bb34:
  %t56 = load i1, ptr %l52, !tbaa !21
  store i1 %t56, ptr %l48, !tbaa !21
  br label %bb35
bb35:
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb37:
  br label %bb38
bb38:
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 7, ptr @.d89 })
  store i1 %t60, ptr %l54
  br label %bb39
bb39:
  %t61 = load i1, ptr %l54, !tbaa !21
  br i1 %t61, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t64 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s3, { i64, ptr } %t62, { i64, ptr } { i64 1, ptr @.d90 })
  %t65 = extractvalue { i32, i64 } %t64, 1
  %t66 = extractvalue { i32, i64 } %t64, 0
  store i32 %t66, ptr %l58
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb43, label %ok.68
ok.68:
  store i64 %t65, ptr %l57
  br label %bb42
bb41:
  br label %bb148
bb42:
  %t69 = load i64, ptr %l57, !tbaa !24
  store i64 %t69, ptr %l55, !tbaa !24
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t70 = load i64, ptr %l55, !tbaa !24
  store i64 %t70, ptr %l2, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l59, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l60, !tbaa !27
  %t73 = load i64, ptr %l2, !tbaa !24
  store i64 %t73, ptr %l61, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l62, !tbaa !24
  %t76 = icmp sge i64 7, 0
  br i1 %t76, label %bb46, label %bb47
bb46:
  %t78 = load i64, ptr %l61, !tbaa !24
  %t79 = icmp sle i64 7, %t78
  br i1 %t79, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb48:
  %t81 = load i64, ptr %l61, !tbaa !24
  %t82 = load i64, ptr %l62, !tbaa !24
  %t83 = icmp sle i64 %t81, %t82
  br i1 %t83, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb50:
  %t85 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l61, !tbaa !24
  %t88 = getelementptr i8, ptr %t86, i64 7
  %t89 = sub i64 %t87, 7
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } { i64 8, ptr @.d92 }, 1
  %t93 = extractvalue { i64, ptr } { i64 8, ptr @.d92 }, 0
  %t95 = extractvalue { i64, ptr } %t91, 1
  %t96 = extractvalue { i64, ptr } %t91, 0
  %t97 = add i64 %t93, %t96
  %t98 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr @.d93 }, 0
  %t100 = add i64 %t97, %t99
  %t101 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t100)
  call void @olang_textcopy(ptr %t101, ptr %t92, i64 %t93)
  %t102 = getelementptr i8, ptr %t101, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = getelementptr i8, ptr %t102, i64 %t96
  call void @olang_textcopy(ptr %t103, ptr %t98, i64 %t99)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t101, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = extractvalue { i64, ptr } %t105, 1
  %t109 = mul i64 %t107, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t109)
  call void @llvm.memcpy.p0.p0.i64(ptr %t110, ptr %t108, i64 %t109, i1 false)
  %t111 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  %t113 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t113, { i64, ptr } %t112)
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @.c91)
  unreachable
bb52:
  store i64 0, ptr %l3, !tbaa !24
  %t115 = load i64, ptr %l2, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l4, !tbaa !24
  store i1 true, ptr %l5, !tbaa !21
  %t119 = load i64, ptr %l2, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l6, !tbaa !24
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t129 = icmp slt i64 %t123, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s6)
  br label %bb129
bb55:
  br label %bb56
bb56:
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l78, !tbaa !27
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t134
  %t139 = load i8, ptr %t138, !tbaa !32
  store i8 %t139, ptr %l7, !tbaa !22
  %t141 = load i8, ptr %l7, !tbaa !22
  %t143 = icmp eq i8 %t141, 40
  br i1 %t143, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb59
bb58:
  %t145 = load i8, ptr %l7, !tbaa !22
  %t147 = icmp eq i8 %t145, 91
  store i1 %t147, ptr %l83, !tbaa !21
  br label %bb59
bb59:
  %t149 = load i1, ptr %l83, !tbaa !21
  br i1 %t149, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb62
bb61:
  %t150 = load i8, ptr %l7, !tbaa !22
  %t152 = icmp eq i8 %t150, 123
  store i1 %t152, ptr %l86, !tbaa !21
  br label %bb62
bb62:
  %t154 = load i1, ptr %l86, !tbaa !21
  br i1 %t154, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb65
bb64:
  %t155 = load i8, ptr %l7, !tbaa !22
  %t157 = icmp eq i8 %t155, 60
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb65
bb65:
  %t159 = load i1, ptr %l89, !tbaa !21
  br i1 %t159, label %bb66, label %bb67
bb66:
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  store i64 %t162, ptr %l3, !tbaa !24
  br label %bb127
bb67:
  %t164 = load i8, ptr %l7, !tbaa !22
  %t166 = icmp eq i8 %t164, 93
  br i1 %t166, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb70
bb69:
  %t168 = load i8, ptr %l7, !tbaa !22
  %t170 = icmp eq i8 %t168, 125
  store i1 %t170, ptr %l96, !tbaa !21
  br label %bb70
bb70:
  %t172 = load i1, ptr %l96, !tbaa !21
  br i1 %t172, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb73
bb72:
  %t173 = load i8, ptr %l7, !tbaa !22
  %t175 = icmp eq i8 %t173, 62
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb73
bb73:
  %t177 = load i1, ptr %l99, !tbaa !21
  br i1 %t177, label %bb74, label %bb75
bb74:
  %t178 = load i64, ptr %l3, !tbaa !24
  %t180 = sub i64 %t178, 1
  store i64 %t180, ptr %l3, !tbaa !24
  br label %bb126
bb75:
  %t182 = load i8, ptr %l7, !tbaa !22
  %t184 = icmp eq i8 %t182, 41
  br i1 %t184, label %bb76, label %bb77
bb76:
  %t186 = load i64, ptr %l3, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  store i1 %t188, ptr %l106, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb78
bb78:
  %t190 = load i1, ptr %l106, !tbaa !21
  br i1 %t190, label %bb79, label %bb80
bb79:
  %t191 = load i64, ptr %l3, !tbaa !24
  %t193 = sub i64 %t191, 1
  store i64 %t193, ptr %l3, !tbaa !24
  br label %bb125
bb80:
  %t195 = load i8, ptr %l7, !tbaa !22
  %t197 = icmp eq i8 %t195, 44
  br i1 %t197, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb83
bb82:
  %t199 = load i8, ptr %l7, !tbaa !22
  %t201 = icmp eq i8 %t199, 41
  store i1 %t201, ptr %l113, !tbaa !21
  br label %bb83
bb83:
  %t203 = load i1, ptr %l113, !tbaa !21
  br i1 %t203, label %bb84, label %bb85
bb84:
  %t204 = load i64, ptr %l3, !tbaa !24
  %t206 = icmp eq i64 %t204, 0
  store i1 %t206, ptr %l116, !tbaa !21
  br label %bb86
bb85:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb86
bb86:
  %t208 = load i1, ptr %l116, !tbaa !21
  br i1 %t208, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s13
  %t209 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t209, ptr %l119, !tbaa !27
  %t210 = load i64, ptr %l4, !tbaa !24
  store i64 %t210, ptr %l120, !tbaa !24
  %t211 = load i64, ptr %l6, !tbaa !24
  store i64 %t211, ptr %l121, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  store i64 %t213, ptr %l122, !tbaa !24
  %t214 = load i64, ptr %l120, !tbaa !24
  %t215 = icmp sge i64 %t214, 0
  br i1 %t215, label %bb89, label %bb90
bb88:
  br label %bb124
bb89:
  %t217 = load i64, ptr %l120, !tbaa !24
  %t218 = load i64, ptr %l121, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb91:
  %t221 = load i64, ptr %l121, !tbaa !24
  %t222 = load i64, ptr %l122, !tbaa !24
  %t223 = icmp sle i64 %t221, %t222
  br i1 %t223, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb93:
  %t225 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = load i64, ptr %l120, !tbaa !24
  %t228 = load i64, ptr %l121, !tbaa !24
  %t229 = getelementptr i8, ptr %t226, i64 %t227
  %t230 = sub i64 %t228, %t227
  %t231 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t229, 1
  %t234 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v1, { i64, ptr } %t232)
  store { i64, ptr } %t234, ptr %l127
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb95:
  %t235 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t235, ptr %l8, !tbaa !27
  %t236 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t238 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s13, { i64, ptr } %t236, { i64, ptr } { i64 1, ptr @.d95 })
  %t239 = extractvalue { i32, i64 } %t238, 1
  %t240 = extractvalue { i32, i64 } %t238, 0
  store i32 %t240, ptr %l131
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb97, label %ok.242
ok.242:
  store i64 %t239, ptr %l130
  br label %bb96
bb96:
  %t243 = load i64, ptr %l130, !tbaa !24
  store i64 %t243, ptr %l128, !tbaa !24
  br label %bb99
bb97:
  br label %bb98
bb98:
  store i64 -1, ptr %l128, !tbaa !24
  br label %bb99
bb99:
  %t244 = load i64, ptr %l128, !tbaa !24
  store i64 %t244, ptr %l9, !tbaa !24
  %t245 = load i64, ptr %l9, !tbaa !24
  %t247 = icmp sge i64 %t245, 0
  br i1 %t247, label %bb100, label %bb101
bb100:
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l135, !tbaa !27
  %t250 = load i64, ptr %l9, !tbaa !24
  %t252 = add i64 %t250, 1
  %t254 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr i8, ptr %t255, i64 %t252
  %t257 = load i8, ptr %t256, !tbaa !32
  %t259 = icmp eq i8 %t257, 37
  store i1 %t259, ptr %l134, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb102
bb102:
  %t261 = load i1, ptr %l134, !tbaa !21
  br i1 %t261, label %bb103, label %bb104
bb103:
  %t262 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t262, ptr %l140, !tbaa !27
  %t263 = load i64, ptr %l9, !tbaa !24
  store i64 %t263, ptr %l141, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l142, !tbaa !24
  %t266 = icmp sge i64 0, 0
  br i1 %t266, label %bb105, label %bb106
bb104:
  br label %bb112
bb105:
  %t268 = load i64, ptr %l141, !tbaa !24
  %t269 = icmp sle i64 0, %t268
  br i1 %t269, label %bb107, label %bb108
bb106:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb107:
  %t271 = load i64, ptr %l141, !tbaa !24
  %t272 = load i64, ptr %l142, !tbaa !24
  %t273 = icmp sle i64 %t271, %t272
  br i1 %t273, label %bb109, label %bb110
bb108:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb109:
  %t275 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = load i64, ptr %l141, !tbaa !24
  %t278 = getelementptr i8, ptr %t276, i64 0
  %t279 = sub i64 %t277, 0
  %t280 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t283 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t281)
  store { i64, ptr } %t283, ptr %l147
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @.c96)
  unreachable
bb111:
  %t284 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t284, ptr %l8, !tbaa !27
  br label %bb112
bb112:
  %t285 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t289 = icmp sgt i64 %t287, 0
  br i1 %t289, label %bb113, label %bb114
bb113:
  %t291 = load i1, ptr %l5, !tbaa !21
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb115, label %bb116
bb114:
  br label %bb120
bb115:
  store %olang.scope zeroinitializer, ptr %s16
  %t295 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s16, ptr %t295, { i64, ptr } { i64 2, ptr @.d97 })
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_scope_close(ptr %s16)
  br label %bb118
bb118:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t297, { i64, ptr } %t298)
  br label %bb119
bb119:
  br label %bb120
bb120:
  store i1 false, ptr %l5, !tbaa !21
  %t301 = load i64, ptr %l6, !tbaa !24
  %t303 = add i64 %t301, 1
  store i64 %t303, ptr %l4, !tbaa !24
  %t305 = load i8, ptr %l7, !tbaa !22
  %t307 = icmp eq i8 %t305, 41
  br i1 %t307, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s6)
  br label %bb129
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s13)
  br label %bb124
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t309 = load i64, ptr %l6, !tbaa !24
  %t311 = add i64 %t309, 1
  store i64 %t311, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb128
bb128:
  br label %bb53
bb129:
  %t313 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t313, ptr %l162, !tbaa !27
  %t314 = load i64, ptr %l6, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l164, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t317, 0
  store i64 %t320, ptr %l167, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l168, !tbaa !24
  %t323 = load i64, ptr %l164, !tbaa !24
  %t324 = icmp sge i64 %t323, 0
  br i1 %t324, label %bb130, label %bb131
bb130:
  %t326 = load i64, ptr %l164, !tbaa !24
  %t327 = load i64, ptr %l167, !tbaa !24
  %t328 = icmp sle i64 %t326, %t327
  br i1 %t328, label %bb132, label %bb133
bb131:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb132:
  %t330 = load i64, ptr %l167, !tbaa !24
  %t331 = load i64, ptr %l168, !tbaa !24
  %t332 = icmp sle i64 %t330, %t331
  br i1 %t332, label %bb134, label %bb135
bb133:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb134:
  %t334 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = load i64, ptr %l164, !tbaa !24
  %t337 = load i64, ptr %l167, !tbaa !24
  %t338 = getelementptr i8, ptr %t335, i64 %t336
  %t339 = sub i64 %t337, %t336
  %t340 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t338, 1
  store { i64, ptr } %t341, ptr %l10, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t345 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v1, ptr %s3, { i64, ptr } %t343, { i64, ptr } { i64 1, ptr @.d99 })
  %t346 = extractvalue { i32, i64 } %t345, 1
  %t347 = extractvalue { i32, i64 } %t345, 0
  store i32 %t347, ptr %l176
  %t348 = icmp ne i32 %t347, 0
  br i1 %t348, label %bb137, label %ok.349
ok.349:
  store i64 %t346, ptr %l175
  br label %bb136
bb135:
  call void @__olang_check_failed(ptr @.c98)
  unreachable
bb136:
  %t350 = load i64, ptr %l175, !tbaa !24
  store i64 %t350, ptr %l173, !tbaa !24
  br label %bb139
bb137:
  br label %bb138
bb138:
  %t351 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  store i64 %t353, ptr %l173, !tbaa !24
  br label %bb139
bb139:
  %t355 = load i64, ptr %l173, !tbaa !24
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l179, !tbaa !29
  %t357 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t357, ptr %l180, !tbaa !27
  store i64 %t355, ptr %l181, !tbaa !24
  %t359 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 0
  store i64 %t360, ptr %l182, !tbaa !24
  %t361 = icmp sge i64 0, 0
  br i1 %t361, label %bb140, label %bb141
bb140:
  %t363 = load i64, ptr %l181, !tbaa !24
  %t364 = icmp sle i64 0, %t363
  br i1 %t364, label %bb142, label %bb143
bb141:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb142:
  %t366 = load i64, ptr %l181, !tbaa !24
  %t367 = load i64, ptr %l182, !tbaa !24
  %t368 = icmp sle i64 %t366, %t367
  br i1 %t368, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb144:
  %t370 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = load i64, ptr %l181, !tbaa !24
  %t373 = getelementptr i8, ptr %t371, i64 0
  %t374 = sub i64 %t372, 0
  %t375 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t373, 1
  %t378 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v1, { i64, ptr } %t376)
  store { i64, ptr } %t378, ptr %l187
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @.c100)
  unreachable
bb146:
  %t379 = extractvalue { i64, ptr } { i64 1, ptr @.d101 }, 1
  %t380 = extractvalue { i64, ptr } { i64 1, ptr @.d101 }, 0
  %t381 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = add i64 %t380, %t383
  %t385 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr @.d102 }, 0
  %t387 = add i64 %t384, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t379, i64 %t380)
  %t389 = getelementptr i8, ptr %t388, i64 %t380
  call void @olang_textcopy(ptr %t389, ptr %t382, i64 %t383)
  %t390 = getelementptr i8, ptr %t389, i64 %t383
  call void @olang_textcopy(ptr %t390, ptr %t385, i64 %t386)
  %t391 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t388, 1
  %t394 = extractvalue { i64, ptr } %t392, 0
  %t395 = extractvalue { i64, ptr } %t392, 1
  %t396 = mul i64 %t394, 1
  %t397 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t396)
  call void @llvm.memcpy.p0.p0.i64(ptr %t397, ptr %t395, i64 %t396, i1 false)
  %t398 = insertvalue { i64, ptr } undef, i64 %t394, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t400 = load ptr, ptr %l179, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s3, ptr %t400, { i64, ptr } %t399)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb148:
  %t402 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t404 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t402, { i64, ptr } { i64 1, ptr @.d103 })
  store i1 %t404, ptr %l191
  br label %bb149
bb149:
  %t405 = load i1, ptr %l191, !tbaa !21
  br i1 %t405, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s19
  %t406 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t408 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t406, { i64, ptr } { i64 3, ptr @.d104 })
  %t409 = extractvalue { i32, i64 } %t408, 1
  %t410 = extractvalue { i32, i64 } %t408, 0
  store i32 %t410, ptr %l195
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb153, label %ok.412
ok.412:
  store i64 %t409, ptr %l194
  br label %bb152
bb151:
  br label %bb221
bb152:
  %t413 = load i64, ptr %l194, !tbaa !24
  store i64 %t413, ptr %l192, !tbaa !24
  br label %bb155
bb153:
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb155:
  %t414 = load i64, ptr %l192, !tbaa !24
  store i64 %t414, ptr %l12, !tbaa !24
  %t415 = load ptr, ptr %l0, !tbaa !29
  store ptr %t415, ptr %l196, !tbaa !29
  %t416 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t416, ptr %l197, !tbaa !27
  %t417 = load i64, ptr %l12, !tbaa !24
  store i64 %t417, ptr %l198, !tbaa !24
  %t418 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 0
  store i64 %t419, ptr %l199, !tbaa !24
  %t420 = icmp sge i64 0, 0
  br i1 %t420, label %bb156, label %bb157
bb156:
  %t422 = load i64, ptr %l198, !tbaa !24
  %t423 = icmp sle i64 0, %t422
  br i1 %t423, label %bb158, label %bb159
bb157:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb158:
  %t425 = load i64, ptr %l198, !tbaa !24
  %t426 = load i64, ptr %l199, !tbaa !24
  %t427 = icmp sle i64 %t425, %t426
  br i1 %t427, label %bb160, label %bb161
bb159:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb160:
  %t429 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = load i64, ptr %l198, !tbaa !24
  %t432 = getelementptr i8, ptr %t430, i64 0
  %t433 = sub i64 %t431, 0
  %t434 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = extractvalue { i64, ptr } { i64 12, ptr @.d106 }, 1
  %t440 = extractvalue { i64, ptr } { i64 12, ptr @.d106 }, 0
  %t441 = add i64 %t438, %t440
  %t442 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t441)
  call void @olang_textcopy(ptr %t442, ptr %t437, i64 %t438)
  %t443 = getelementptr i8, ptr %t442, i64 %t438
  call void @olang_textcopy(ptr %t443, ptr %t439, i64 %t440)
  %t444 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr %t442, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = extractvalue { i64, ptr } %t445, 1
  %t449 = mul i64 %t447, 1
  %t450 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t449)
  call void @llvm.memcpy.p0.p0.i64(ptr %t450, ptr %t448, i64 %t449, i1 false)
  %t451 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  %t453 = load ptr, ptr %l196, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t453, { i64, ptr } %t452)
  br label %bb162
bb161:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb162:
  %t455 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t455, ptr %l206, !tbaa !27
  %t456 = load i64, ptr %l12, !tbaa !24
  %t458 = add i64 %t456, 3
  store i64 %t458, ptr %l208, !tbaa !24
  %t459 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t462 = extractvalue { i64, ptr } %t459, 0
  store i64 %t462, ptr %l211, !tbaa !24
  %t463 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t463, 0
  store i64 %t464, ptr %l212, !tbaa !24
  %t465 = load i64, ptr %l208, !tbaa !24
  %t466 = icmp sge i64 %t465, 0
  br i1 %t466, label %bb163, label %bb164
bb163:
  %t468 = load i64, ptr %l208, !tbaa !24
  %t469 = load i64, ptr %l211, !tbaa !24
  %t470 = icmp sle i64 %t468, %t469
  br i1 %t470, label %bb165, label %bb166
bb164:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb165:
  %t472 = load i64, ptr %l211, !tbaa !24
  %t473 = load i64, ptr %l212, !tbaa !24
  %t474 = icmp sle i64 %t472, %t473
  br i1 %t474, label %bb167, label %bb168
bb166:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb167:
  %t476 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = load i64, ptr %l208, !tbaa !24
  %t479 = load i64, ptr %l211, !tbaa !24
  %t480 = getelementptr i8, ptr %t477, i64 %t478
  %t481 = sub i64 %t479, %t478
  %t482 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t480, 1
  store { i64, ptr } %t483, ptr %l13, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t487 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t485, { i64, ptr } { i64 13, ptr @.d108 })
  store i1 %t487, ptr %l218
  br label %bb169
bb168:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb169:
  %t488 = load i1, ptr %l218, !tbaa !21
  br i1 %t488, label %bb170, label %bb171
bb170:
  store %olang.scope zeroinitializer, ptr %s22
  %t489 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t491 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s22, { i64, ptr } %t489, { i64, ptr } { i64 1, ptr @.d109 })
  %t492 = extractvalue { i32, i64 } %t491, 1
  %t493 = extractvalue { i32, i64 } %t491, 0
  store i32 %t493, ptr %l222
  %t494 = icmp ne i32 %t493, 0
  br i1 %t494, label %bb173, label %ok.495
ok.495:
  store i64 %t492, ptr %l221
  br label %bb172
bb171:
  br label %bb189
bb172:
  %t496 = load i64, ptr %l221, !tbaa !24
  store i64 %t496, ptr %l219, !tbaa !24
  br label %bb175
bb173:
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb175:
  %t497 = load i64, ptr %l219, !tbaa !24
  store i64 %t497, ptr %l14, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l223, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t499, ptr %l224, !tbaa !27
  %t500 = load i64, ptr %l14, !tbaa !24
  %t502 = add i64 %t500, 1
  store i64 %t502, ptr %l226, !tbaa !24
  %t503 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  store i64 %t504, ptr %l227, !tbaa !24
  %t505 = icmp sge i64 0, 0
  br i1 %t505, label %bb176, label %bb177
bb176:
  %t507 = load i64, ptr %l226, !tbaa !24
  %t508 = icmp sle i64 0, %t507
  br i1 %t508, label %bb178, label %bb179
bb177:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb178:
  %t510 = load i64, ptr %l226, !tbaa !24
  %t511 = load i64, ptr %l227, !tbaa !24
  %t512 = icmp sle i64 %t510, %t511
  br i1 %t512, label %bb180, label %bb181
bb179:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb180:
  %t514 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t515 = load ptr, ptr %t514, !tbaa !27
  %t516 = load i64, ptr %l226, !tbaa !24
  %t517 = getelementptr i8, ptr %t515, i64 0
  %t518 = sub i64 %t516, 0
  %t519 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t517, 1
  %t522 = extractvalue { i64, ptr } %t520, 1
  %t523 = extractvalue { i64, ptr } %t520, 0
  %t524 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 1
  %t525 = extractvalue { i64, ptr } { i64 1, ptr @.d111 }, 0
  %t526 = add i64 %t523, %t525
  %t527 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t526)
  call void @olang_textcopy(ptr %t527, ptr %t522, i64 %t523)
  %t528 = getelementptr i8, ptr %t527, i64 %t523
  call void @olang_textcopy(ptr %t528, ptr %t524, i64 %t525)
  %t529 = insertvalue { i64, ptr } undef, i64 %t526, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t527, 1
  %t532 = extractvalue { i64, ptr } %t530, 0
  %t533 = extractvalue { i64, ptr } %t530, 1
  %t534 = mul i64 %t532, 1
  %t535 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t534)
  call void @llvm.memcpy.p0.p0.i64(ptr %t535, ptr %t533, i64 %t534, i1 false)
  %t536 = insertvalue { i64, ptr } undef, i64 %t532, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t535, 1
  %t538 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s22, ptr %t538, { i64, ptr } %t537)
  br label %bb182
bb181:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb182:
  %t540 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t540, ptr %l234, !tbaa !27
  %t541 = load i64, ptr %l14, !tbaa !24
  %t543 = add i64 %t541, 2
  store i64 %t543, ptr %l236, !tbaa !24
  %t544 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t547 = extractvalue { i64, ptr } %t544, 0
  store i64 %t547, ptr %l239, !tbaa !24
  %t548 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t549 = extractvalue { i64, ptr } %t548, 0
  store i64 %t549, ptr %l240, !tbaa !24
  %t550 = load i64, ptr %l236, !tbaa !24
  %t551 = icmp sge i64 %t550, 0
  br i1 %t551, label %bb183, label %bb184
bb183:
  %t553 = load i64, ptr %l236, !tbaa !24
  %t554 = load i64, ptr %l239, !tbaa !24
  %t555 = icmp sle i64 %t553, %t554
  br i1 %t555, label %bb185, label %bb186
bb184:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb185:
  %t557 = load i64, ptr %l239, !tbaa !24
  %t558 = load i64, ptr %l240, !tbaa !24
  %t559 = icmp sle i64 %t557, %t558
  br i1 %t559, label %bb187, label %bb188
bb186:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb187:
  %t561 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = load i64, ptr %l236, !tbaa !24
  %t564 = load i64, ptr %l239, !tbaa !24
  %t565 = getelementptr i8, ptr %t562, i64 %t563
  %t566 = sub i64 %t564, %t563
  %t567 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t568 = insertvalue { i64, ptr } %t567, ptr %t565, 1
  store { i64, ptr } %t568, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s22)
  br label %bb189
bb188:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb189:
  %t570 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t572 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s19, { i64, ptr } %t570, { i64, ptr } { i64 13, ptr @.d113 })
  store i1 %t572, ptr %l246
  br label %bb190
bb190:
  %t573 = load i1, ptr %l246, !tbaa !21
  br i1 %t573, label %bb191, label %bb192
bb191:
  %t574 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t574, ptr %l247, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t578 = extractvalue { i64, ptr } %t575, 0
  store i64 %t578, ptr %l250, !tbaa !24
  %t579 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t580 = extractvalue { i64, ptr } %t579, 0
  store i64 %t580, ptr %l251, !tbaa !24
  %t581 = icmp sge i64 13, 0
  br i1 %t581, label %bb193, label %bb194
bb192:
  br label %bb199
bb193:
  %t583 = load i64, ptr %l250, !tbaa !24
  %t584 = icmp sle i64 13, %t583
  br i1 %t584, label %bb195, label %bb196
bb194:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb195:
  %t586 = load i64, ptr %l250, !tbaa !24
  %t587 = load i64, ptr %l251, !tbaa !24
  %t588 = icmp sle i64 %t586, %t587
  br i1 %t588, label %bb197, label %bb198
bb196:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb197:
  %t590 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = load i64, ptr %l250, !tbaa !24
  %t593 = getelementptr i8, ptr %t591, i64 13
  %t594 = sub i64 %t592, 13
  %t595 = insertvalue { i64, ptr } undef, i64 %t594, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t593, 1
  store { i64, ptr } %t596, ptr %l13, !tbaa !27
  br label %bb199
bb198:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb199:
  %t598 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t600 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s19, { i64, ptr } %t598, { i64, ptr } { i64 1, ptr @.d115 })
  %t601 = extractvalue { i32, i64 } %t600, 1
  %t602 = extractvalue { i32, i64 } %t600, 0
  store i32 %t602, ptr %l259
  %t603 = icmp ne i32 %t602, 0
  br i1 %t603, label %bb201, label %ok.604
ok.604:
  store i64 %t601, ptr %l258
  br label %bb200
bb200:
  %t605 = load i64, ptr %l258, !tbaa !24
  store i64 %t605, ptr %l256, !tbaa !24
  br label %bb203
bb201:
  br label %bb202
bb202:
  %t606 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t608 = extractvalue { i64, ptr } %t606, 0
  store i64 %t608, ptr %l256, !tbaa !24
  br label %bb203
bb203:
  %t610 = load i64, ptr %l256, !tbaa !24
  store i64 %t610, ptr %l15, !tbaa !24
  %t611 = load i64, ptr %l15, !tbaa !24
  %t613 = add i64 %t611, 1
  %t614 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t616 = extractvalue { i64, ptr } %t614, 0
  %t619 = icmp slt i64 %t613, %t616
  br i1 %t619, label %bb204, label %bb205
bb204:
  %t621 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t622 = load i64, ptr %l15, !tbaa !24
  %t624 = add i64 %t622, 1
  %t627 = call i64 @compiler_2fruntime_2etypeEnd(ptr %v1, { i64, ptr } %t621, i64 %t624)
  store i64 %t627, ptr %l271
  br label %bb206
bb205:
  %t628 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t628, 0
  store i64 %t630, ptr %l267, !tbaa !24
  br label %bb207
bb206:
  %t632 = load i64, ptr %l271, !tbaa !24
  store i64 %t632, ptr %l267, !tbaa !24
  br label %bb207
bb207:
  %t633 = load i64, ptr %l267, !tbaa !24
  store i64 %t633, ptr %l16, !tbaa !24
  %t634 = load ptr, ptr %l0, !tbaa !29
  store ptr %t634, ptr %l274, !tbaa !29
  %t635 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t635, ptr %l275, !tbaa !27
  %t636 = load i64, ptr %l15, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l277, !tbaa !24
  %t639 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t639, 0
  store i64 %t640, ptr %l278, !tbaa !24
  %t641 = icmp sge i64 0, 0
  br i1 %t641, label %bb208, label %bb209
bb208:
  %t643 = load i64, ptr %l277, !tbaa !24
  %t644 = icmp sle i64 0, %t643
  br i1 %t644, label %bb210, label %bb211
bb209:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb210:
  %t646 = load i64, ptr %l277, !tbaa !24
  %t647 = load i64, ptr %l278, !tbaa !24
  %t648 = icmp sle i64 %t646, %t647
  br i1 %t648, label %bb212, label %bb213
bb211:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb212:
  %t650 = getelementptr { i64, ptr }, ptr %l275, i32 0, i32 1
  %t651 = load ptr, ptr %t650, !tbaa !27
  %t652 = load i64, ptr %l277, !tbaa !24
  %t653 = getelementptr i8, ptr %t651, i64 0
  %t654 = sub i64 %t652, 0
  %t655 = insertvalue { i64, ptr } undef, i64 %t654, 0
  %t656 = insertvalue { i64, ptr } %t655, ptr %t653, 1
  store { i64, ptr } %t656, ptr %l282, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t657, ptr %l283, !tbaa !27
  %t658 = load i64, ptr %l15, !tbaa !24
  %t660 = add i64 %t658, 1
  store i64 %t660, ptr %l285, !tbaa !24
  %t661 = load i64, ptr %l16, !tbaa !24
  store i64 %t661, ptr %l286, !tbaa !24
  %t662 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t663 = extractvalue { i64, ptr } %t662, 0
  store i64 %t663, ptr %l287, !tbaa !24
  %t664 = load i64, ptr %l285, !tbaa !24
  %t665 = icmp sge i64 %t664, 0
  br i1 %t665, label %bb214, label %bb215
bb213:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb214:
  %t667 = load i64, ptr %l285, !tbaa !24
  %t668 = load i64, ptr %l286, !tbaa !24
  %t669 = icmp sle i64 %t667, %t668
  br i1 %t669, label %bb216, label %bb217
bb215:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb216:
  %t671 = load i64, ptr %l286, !tbaa !24
  %t672 = load i64, ptr %l287, !tbaa !24
  %t673 = icmp sle i64 %t671, %t672
  br i1 %t673, label %bb218, label %bb219
bb217:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb218:
  %t675 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = load i64, ptr %l285, !tbaa !24
  %t678 = load i64, ptr %l286, !tbaa !24
  %t679 = getelementptr i8, ptr %t676, i64 %t677
  %t680 = sub i64 %t678, %t677
  %t681 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t682 = insertvalue { i64, ptr } %t681, ptr %t679, 1
  %t683 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t684 = extractvalue { i64, ptr } %t683, 1
  %t685 = extractvalue { i64, ptr } %t683, 0
  %t687 = extractvalue { i64, ptr } %t682, 1
  %t688 = extractvalue { i64, ptr } %t682, 0
  %t689 = add i64 %t685, %t688
  %t690 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 1
  %t691 = extractvalue { i64, ptr } { i64 1, ptr @.d117 }, 0
  %t692 = add i64 %t689, %t691
  %t693 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t692)
  call void @olang_textcopy(ptr %t693, ptr %t684, i64 %t685)
  %t694 = getelementptr i8, ptr %t693, i64 %t685
  call void @olang_textcopy(ptr %t694, ptr %t687, i64 %t688)
  %t695 = getelementptr i8, ptr %t694, i64 %t688
  call void @olang_textcopy(ptr %t695, ptr %t690, i64 %t691)
  %t696 = insertvalue { i64, ptr } undef, i64 %t692, 0
  %t697 = insertvalue { i64, ptr } %t696, ptr %t693, 1
  %t699 = extractvalue { i64, ptr } %t697, 0
  %t700 = extractvalue { i64, ptr } %t697, 1
  %t701 = mul i64 %t699, 1
  %t702 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t701)
  call void @llvm.memcpy.p0.p0.i64(ptr %t702, ptr %t700, i64 %t701, i1 false)
  %t703 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t702, 1
  %t705 = load ptr, ptr %l274, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s19, ptr %t705, { i64, ptr } %t704)
  br label %bb220
bb219:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb220:
  call void @__olang_scope_close(ptr %s19)
  br label %bb221
bb221:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fruntime_2edirective(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l5 = alloca i1
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l32 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 3, ptr @.d118 })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l8, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l11, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l12, !tbaa !24
  %t15 = icmp sge i64 3, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = icmp sle i64 3, %t17
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb7:
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb9:
  %t24 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l11, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 3
  %t28 = sub i64 %t26, 3
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l2, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s0, { i64, ptr } %t34, { i64, ptr } { i64 1, ptr @.d120 })
  %t37 = extractvalue { i32, i64 } %t36, 1
  %t38 = extractvalue { i32, i64 } %t36, 0
  store i32 %t38, ptr %l21
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb12, label %ok.40
ok.40:
  store i64 %t37, ptr %l20
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c119)
  unreachable
bb11:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l18, !tbaa !24
  br label %bb14
bb14:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp sge i64 %t43, 0
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l24, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l25, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb17, label %bb18
bb16:
  br label %bb23
bb17:
  %t53 = load i64, ptr %l25, !tbaa !24
  %t54 = icmp sle i64 0, %t53
  br i1 %t54, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb19:
  %t56 = load i64, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l26, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb21:
  %t60 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l25, !tbaa !24
  %t63 = getelementptr i8, ptr %t61, i64 0
  %t64 = sub i64 %t62, 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t63, 1
  store { i64, ptr } %t66, ptr %l2, !tbaa !27
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @.c121)
  unreachable
bb23:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 2, ptr @.d122 })
  store i1 %t70, ptr %l32
  br label %bb24
bb24:
  %t71 = load i1, ptr %l32, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i64 0, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 4, ptr @.d123 })
  store i1 %t75, ptr %l35
  br label %bb28
bb28:
  %t76 = load i1, ptr %l35, !tbaa !21
  br i1 %t76, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s0)
  store i64 1, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 3, ptr @.d124 })
  store i1 %t80, ptr %l38
  br label %bb32
bb32:
  %t81 = load i1, ptr %l38, !tbaa !21
  br i1 %t81, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i64 2, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @compiler_2fruntime_2efact(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca [12 x { i64, ptr }]
  %l13 = alloca i64
  %l16 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr @G_2ecompiler_2fruntime_2eFactNames, i64 192, i1 false)
  %t1 = load [12 x { i64, ptr }], ptr %l8
  store i64 12, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t3 = load i64, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t51 = getelementptr [12 x { i64, ptr }], ptr @G_2ecompiler_2fruntime_2eFactNames, i64 0, i64 %t49
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !37
  %t54 = load ptr, ptr @__olang_prog_scope
  %t57 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t54, ptr %v0, { i64, ptr } %t52, { i64, ptr } %a0)
  store i1 %t57, ptr %l37
  br label %bb11
bb11:
  %t58 = load i1, ptr %l37, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t61 = icmp eq i64 %a1, 0
  br i1 %t61, label %bb14, label %bb15
bb13:
  br label %bb17
bb14:
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr [12 x i64], ptr @G_2ecompiler_2fruntime_2eFactX86, i64 0, i64 %t63
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l40, !tbaa !24
  br label %bb16
bb15:
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = getelementptr [12 x i64], ptr @G_2ecompiler_2fruntime_2eFactArm, i64 0, i64 %t68
  %t71 = load i64, ptr %t70, !tbaa !34
  store i64 %t71, ptr %l40, !tbaa !24
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t73 = load i64, ptr %l40, !tbaa !24
  %t74 = insertvalue { i32, i64 } zeroinitializer, i64 %t73, 1
  store { i32, i64 } %t74, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t75 = load i64, ptr %l6, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l6, !tbaa !24
  br label %bb7
bb19:
  %t80 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @compiler_2fruntime_2emalformed(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l8 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = extractvalue { i64, ptr } { i64 7, ptr @.d125 }, 1
  %t5 = extractvalue { i64, ptr } { i64 7, ptr @.d125 }, 0
  %t7 = extractvalue { i64, ptr } %a0, 1
  %t8 = extractvalue { i64, ptr } %a0, 0
  %t9 = add i64 %t5, %t8
  %t10 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr @.d126 }, 0
  %t12 = add i64 %t9, %t11
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 2, ptr @.d127 }, 1
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d127 }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a2, 1
  %t21 = extractvalue { i64, ptr } %a2, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t4, i64 %t5)
  %t24 = getelementptr i8, ptr %t23, i64 %t5
  call void @olang_textcopy(ptr %t24, ptr %t7, i64 %t8)
  %t25 = getelementptr i8, ptr %t24, i64 %t8
  call void @olang_textcopy(ptr %t25, ptr %t10, i64 %t11)
  %t26 = getelementptr i8, ptr %t25, i64 %t11
  %t27 = call i64 @__olang_fmt_i64(ptr %t26, i64 %a1)
  %t28 = getelementptr i8, ptr %t26, i64 %t14
  call void @olang_textcopy(ptr %t28, ptr %t16, i64 %t17)
  %t29 = getelementptr i8, ptr %t28, i64 %t17
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t23, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  %t40 = call i32 @std_2fio_2ePrintErrln(ptr %s0, { i64, ptr } %t38)
  store i32 %t40, ptr %l8
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb2, label %ok.42
ok.42:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t43 = load i32, ptr %l8, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t48 = load i32, ptr %l8, !tbaa !23
  %t49 = lshr i32 %t48, 16
  %t50 = and i32 %t48, 65535
  %t51 = icmp eq i32 %t49, 1
  %t52 = select i1 %t51, i32 0, i32 0
  %t53 = icmp eq i32 %t48, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t50
  %t56 = select i1 %t53, i32 0, i32 %t55
  call void @__olang_scope_close(ptr %s0)
  store i32 %t56, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fruntime_2emodulesInline(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l4 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l9 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 7, ptr @.d128 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 16, ptr @.d129 })
  store i1 %t9, ptr %l6
  br label %bb4
bb4:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb9
bb7:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t12, { i64, ptr } { i64 15, ptr @.d130 })
  store i1 %t14, ptr %l9
  br label %bb8
bb8:
  %t15 = load i1, ptr %l9, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb9
bb9:
  %t16 = load i1, ptr %l7, !tbaa !21
  br i1 %t16, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 12, ptr @.d131 }, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t18, { i64, ptr } %t21)
  store i1 %t22, ptr %l14
  br label %bb13
bb13:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb15:
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 10, ptr @.d132 }, ptr %l18, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t28 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t24, { i64, ptr } %t27)
  store i1 %t28, ptr %l19
  br label %bb16
bb16:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l15, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fruntime_2etypeEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %l25 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca { i64, ptr }
  %l75 = alloca i64
  %l78 = alloca i64
  %l96 = alloca { i64, ptr }
  %l101 = alloca i1
  %l104 = alloca i1
  %l111 = alloca i1
  %l114 = alloca i1
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l17, !tbaa !27
  %t2 = load i64, ptr %l1, !tbaa !24
  %t4 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i8, ptr %t5, i64 %t2
  %t7 = load i8, ptr %t6, !tbaa !32
  store i8 %t7, ptr %l2, !tbaa !22
  %t9 = load i8, ptr %l2, !tbaa !22
  %t11 = icmp ne i8 %t9, 91
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i8, ptr %l2, !tbaa !22
  %t15 = icmp ne i8 %t13, 123
  store i1 %t15, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l22, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t18 = load i8, ptr %l2, !tbaa !22
  %t20 = icmp ne i8 %t18, 60
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l25, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb9, label %bb10
bb8:
  br label %bb27
bb9:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb11:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l37, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb13
bb13:
  %t55 = load i64, ptr %l37, !tbaa !24
  store i64 %t55, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t56 = load i64, ptr %l34, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb17:
  br label %bb18
bb18:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l55, !tbaa !27
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t76
  %t81 = load i8, ptr %t80, !tbaa !32
  %t83 = icmp eq i8 %t81, 32
  br i1 %t83, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb21
bb20:
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l60, !tbaa !27
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = icmp eq i8 %t91, 44
  store i1 %t93, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l59, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t96 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  store i64 %t96, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t98 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l7, !tbaa !24
  br label %bb15
bb26:
  %t102 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %rv
  br label %ret
bb27:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t112 = load i64, ptr %l11, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = icmp sgt i64 %t112, %t113
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t120 = icmp sgt i64 %t118, 0
  br i1 %t120, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb33
bb30:
  %t122 = load i64, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t126 = sub i64 %t122, %t123
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = add i64 %t126, %t127
  %t132 = sub i64 %t130, 1
  %t133 = load i64, ptr %l12, !tbaa !24
  %t136 = sdiv i64 %t132, %t133
  store i64 %t136, ptr %l78, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb32
bb32:
  %t138 = load i64, ptr %l78, !tbaa !24
  store i64 %t138, ptr %l75, !tbaa !24
  br label %bb33
bb33:
  %t139 = load i64, ptr %l75, !tbaa !24
  store i64 %t139, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp slt i64 %t140, %t141
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb36:
  br label %bb37
bb37:
  %t148 = load i64, ptr %l10, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t150 = load i64, ptr %l12, !tbaa !24
  %t153 = mul i64 %t149, %t150
  %t156 = add i64 %t148, %t153
  store i64 %t156, ptr %l15, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t158, ptr %l96, !tbaa !27
  %t159 = load i64, ptr %l15, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i8, ptr %t162, i64 %t159
  %t164 = load i8, ptr %t163, !tbaa !32
  store i8 %t164, ptr %l16, !tbaa !22
  %t166 = load i8, ptr %l16, !tbaa !22
  %t168 = icmp eq i8 %t166, 91
  br i1 %t168, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb40
bb39:
  %t170 = load i8, ptr %l16, !tbaa !22
  %t172 = icmp eq i8 %t170, 123
  store i1 %t172, ptr %l101, !tbaa !21
  br label %bb40
bb40:
  %t174 = load i1, ptr %l101, !tbaa !21
  br i1 %t174, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb43
bb42:
  %t175 = load i8, ptr %l16, !tbaa !22
  %t177 = icmp eq i8 %t175, 60
  store i1 %t177, ptr %l104, !tbaa !21
  br label %bb43
bb43:
  %t179 = load i1, ptr %l104, !tbaa !21
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t180 = load i64, ptr %l9, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l9, !tbaa !24
  br label %bb58
bb45:
  %t184 = load i8, ptr %l16, !tbaa !22
  %t186 = icmp eq i8 %t184, 93
  br i1 %t186, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  %t188 = load i8, ptr %l16, !tbaa !22
  %t190 = icmp eq i8 %t188, 125
  store i1 %t190, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t192 = load i1, ptr %l111, !tbaa !21
  br i1 %t192, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb51
bb50:
  %t193 = load i8, ptr %l16, !tbaa !22
  %t195 = icmp eq i8 %t193, 62
  store i1 %t195, ptr %l114, !tbaa !21
  br label %bb51
bb51:
  %t197 = load i1, ptr %l114, !tbaa !21
  br i1 %t197, label %bb52, label %bb53
bb52:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = sub i64 %t198, 1
  store i64 %t200, ptr %l9, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t204 = icmp eq i64 %t202, 0
  br i1 %t204, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  %t206 = load i64, ptr %l15, !tbaa !24
  %t208 = add i64 %t206, 1
  call void @__olang_scope_close(ptr %s7)
  store i64 %t208, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb59
bb59:
  %t210 = load i64, ptr %l14, !tbaa !24
  %t212 = add i64 %t210, 1
  store i64 %t212, ptr %l14, !tbaa !24
  br label %bb34
bb60:
  %t214 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @olang_2einit_2ecompiler_2fruntime() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fruntime_2eArchs_2einit()
  br label %bb1
bb1:
  call void @compiler_2fruntime_2eFactNames_2einit()
  br label %bb2
bb2:
  call void @compiler_2fruntime_2eFactX86_2einit()
  br label %bb3
bb3:
  call void @compiler_2fruntime_2eFactArm_2einit()
  br label %bb4
bb4:
  call void @compiler_2fruntime_2eHeaderTbaa_2einit()
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

@.d0 = private constant [6 x i8] c"x86_64"
@.d1 = private constant [7 x i8] c"aarch64"
declare void @__olang_check_failed(ptr)
@.c2 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:287: reached unreachable code\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d3 = private constant [1 x i8] c"}"
@.c4 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:293: slice bounds out of range\0A\00"
@.d5 = private constant [28 x i8] c"define available_externally "
@.d6 = private constant [1 x i8] c"\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant [17 x i8] c"target triple = \22"
@.d8 = private constant [3 x i8] c"\22\0A\0A"
@.d9 = private constant [19 x i8] c"\0A!20 = !{!\22olang\22}\0A"
@.d10 = private constant [10 x i8] c"STAT_BYTES"
@.d11 = private constant [9 x i8] c"STAT_MODE"
@.d12 = private constant [9 x i8] c"STAT_SIZE"
@.d13 = private constant [13 x i8] c"STAT_MTIM_SEC"
@.d14 = private constant [14 x i8] c"STAT_MTIM_NSEC"
@.d15 = private constant [11 x i8] c"DIRENT_NAME"
@.d16 = private constant [24 x i8] c"SPAWN_FILE_ACTIONS_BYTES"
@.d17 = private constant [18 x i8] c"PTHREAD_ATTR_BYTES"
@.d18 = private constant [13 x i8] c"JMP_BUF_BYTES"
@.d19 = private constant [15 x i8] c"SIGACTION_BYTES"
@.d20 = private constant [15 x i8] c"SIGACTION_FLAGS"
@.d21 = private constant [15 x i8] c"FFI_DEFAULT_ABI"
@.d22 = private constant [9 x i8] c"/runtime/"
@.d23 = private constant [7 x i8] c"olang: "
@.d24 = private constant [23 x i8] c": cannot open this file"
@.d25 = private constant [22 x i8] c"\22; @if\22 inside another"
@.c26 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:81: slice bounds out of range\0A\00"
@.d27 = private constant [1 x i8] c"!"
@.c28 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:83: slice bounds out of range\0A\00"
@.d29 = private constant [1 x i8] c" "
@.c30 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:85: slice bounds out of range\0A\00"
@.d31 = private constant [3 x i8] c"san"
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d32 = private constant [53 x i8] c"a condition that is neither \22san\22 nor an architecture"
@.d33 = private constant [3 x i8] c"san"
@.d34 = private constant [30 x i8] c"\22; @else\22 with no \22; @if\22 open"
@.d35 = private constant [29 x i8] c"\22; @end\22 with no \22; @if\22 open"
@.d36 = private constant [1 x i8] c";"
@.d37 = private constant [2 x i8] c"@@"
@.c38 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:122: slice bounds out of range\0A\00"
@.c39 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:123: slice bounds out of range\0A\00"
@.d40 = private constant [2 x i8] c"@@"
@.d41 = private constant [31 x i8] c"an \22@@\22 with no \22@@\22 closing it"
@.c42 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:126: slice bounds out of range\0A\00"
@.d43 = private constant [42 x i8] c"an @@NAME@@ the compiler knows no fact for"
@.c44 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:128: reached unreachable code\0A\00"
declare i64 @__olang_fmt_i64(ptr, i64)
@.c45 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:131: slice bounds out of range\0A\00"
@.d46 = private constant [24 x i8] c"\22; @if\22 with no \22; @end\22"
@.d47 = private constant [66 x i8] c"!49 = !{!\22scopehdr\22, !20, i64 0}\0A!50 = !{!\22chunkhdr\22, !20, i64 0}\0A"
@.d48 = private constant [50 x i8] c"!59 = !{!49, !49, i64 0}\0A!60 = !{!50, !50, i64 0}\0A"
@.d49 = private constant [17 x i8] c"target triple = \22"
@.d50 = private constant [3 x i8] c"\22\0A\0A"
@.d51 = private constant [10 x i8] c"dyncall.ll"
@.d52 = private constant [10 x i8] c"runtime.ll"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d53 = private constant [6 x i8] c"san.ll"
@.d54 = private constant [1 x i8] c"\0A"
@.c55 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:154: reached unreachable code\0A\00"
@.d56 = private constant [1 x i8] c"@"
@.d57 = private constant [16 x i8] c" = linkonce_odr "
@.d58 = private constant [1 x i8] c" "
@.c59 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:158: slice bounds out of range\0A\00"
@.d60 = private constant [1 x i8] c"$"
@.d61 = private constant [14 x i8] c" = comdat any\0A"
@.d62 = private constant [9 x i8] c", comdat\0A"
@.d63 = private constant [7 x i8] c"define "
@.d64 = private constant [1 x i8] c"{"
@.d65 = private constant [6 x i8] c" !dbg "
@.c66 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:167: slice bounds out of range\0A\00"
@.d67 = private constant [23 x i8] c"@__olang_crash_handler("
@.d68 = private constant [21 x i8] c"@__olang_san_handler("
@.d69 = private constant [3 x i8] c" #1"
@.d70 = private constant [3 x i8] c" #0"
@.c71 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:172: slice bounds out of range\0A\00"
@.d72 = private constant [4 x i8] c"#1 {"
@.d73 = private constant [4 x i8] c"#0 {"
@.d74 = private constant [16 x i8] c"sanitize_thread "
@.d75 = private constant [0 x i8] c""
@.d76 = private constant [41 x i8] c"\0Aattributes #0 = { null_pointer_is_valid "
@.d77 = private constant [3 x i8] c" }\0A"
@.d78 = private constant [40 x i8] c"attributes #1 = { null_pointer_is_valid "
@.d79 = private constant [3 x i8] c" }\0A"
@.d80 = private constant [8 x i8] c"declare "
@.d81 = private constant [1 x i8] c"%"
@.d82 = private constant [8 x i8] c" = type "
@.d83 = private constant [1 x i8] c"@"
@.d84 = private constant [12 x i8] c" = external "
@.d85 = private constant [16 x i8] c"define internal "
@.d86 = private constant [15 x i8] c"define private "
@.d87 = private constant [12 x i8] c" = internal "
@.d88 = private constant [11 x i8] c" = private "
@.d89 = private constant [7 x i8] c"define "
@.d90 = private constant [1 x i8] c"("
@.c91 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:228: slice bounds out of range\0A\00"
@.d92 = private constant [8 x i8] c"declare "
@.d93 = private constant [1 x i8] c"("
@.c94 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:239: slice bounds out of range\0A\00"
@.d95 = private constant [1 x i8] c" "
@.c96 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:241: slice bounds out of range\0A\00"
@.d97 = private constant [2 x i8] c", "
@.c98 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:253: slice bounds out of range\0A\00"
@.d99 = private constant [1 x i8] c"{"
@.c100 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:255: slice bounds out of range\0A\00"
@.d101 = private constant [1 x i8] c")"
@.d102 = private constant [1 x i8] c"\0A"
@.d103 = private constant [1 x i8] c"@"
@.d104 = private constant [3 x i8] c" = "
@.c105 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:260: slice bounds out of range\0A\00"
@.d106 = private constant [12 x i8] c" = external "
@.c107 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:261: slice bounds out of range\0A\00"
@.d108 = private constant [13 x i8] c"thread_local("
@.d109 = private constant [1 x i8] c")"
@.c110 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:264: slice bounds out of range\0A\00"
@.d111 = private constant [1 x i8] c" "
@.c112 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:265: slice bounds out of range\0A\00"
@.d113 = private constant [13 x i8] c"unnamed_addr "
@.c114 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:267: slice bounds out of range\0A\00"
@.d115 = private constant [1 x i8] c" "
@.c116 = private unnamed_addr constant [55 x i8] c"compiler/runtime.olang:270: slice bounds out of range\0A\00"
@.d117 = private constant [1 x i8] c"\0A"
@.d118 = private constant [3 x i8] c"; @"
@.c119 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:51: slice bounds out of range\0A\00"
@.d120 = private constant [1 x i8] c" "
@.c121 = private unnamed_addr constant [54 x i8] c"compiler/runtime.olang:54: slice bounds out of range\0A\00"
@.d122 = private constant [2 x i8] c"if"
@.d123 = private constant [4 x i8] c"else"
@.d124 = private constant [3 x i8] c"end"
@.d125 = private constant [7 x i8] c"olang: "
@.d126 = private constant [1 x i8] c":"
@.d127 = private constant [2 x i8] c": "
@.d128 = private constant [7 x i8] c"define "
@.d129 = private constant [16 x i8] c"define internal "
@.d130 = private constant [15 x i8] c"define private "
@.d131 = private constant [12 x i8] c"alwaysinline"
@.d132 = private constant [10 x i8] c"inlinehint"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErrln(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eHas_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
