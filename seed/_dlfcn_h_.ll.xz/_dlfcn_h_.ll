; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"<dlfcn.h>:Dl_info" = type { ptr, ptr, ptr, ptr }
%"<dlfcn.h>:Dl_serinfo" = type { [4 x i64] }
%"<dlfcn.h>:Dl_serpath" = type { ptr, i32 }
%"<dlfcn.h>:dl_find_object" = type { i64, ptr, ptr, ptr, ptr, [7 x i64] }
@G_2e_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__COUNT = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__DBASE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eLM__ID__BASE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eLM__ID__NEWLM = constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__BINDING__MASK = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DEEPBIND = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__CONFIGADDR = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__LINKMAP = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__LMID = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__MAX = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__ORIGIN = constant <{ [4 x i8] }> <{ [4 x i8] c"\06\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PHDR = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILENAME = constant <{ [4 x i8] }> <{ [4 x i8] c"\07\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILEOUT = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFO = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFOSIZE = constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__DATA = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__MODID = constant <{ [4 x i8] }> <{ [4 x i8] c"\09\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DL__LINKMAP = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__DL__SYMENT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__GLOBAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__LAZY = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__LOCAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__NODELETE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__NOLOAD = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3cdlfcn_2eh_3e_2eRTLD__NOW = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
define dso_local void @_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__COUNT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__COUNT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__DBASE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__DBASE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eLM__ID__BASE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cdlfcn_2eh_3e_2eLM__ID__BASE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eLM__ID__NEWLM_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 -1, ptr @G_2e_3cdlfcn_2eh_3e_2eLM__ID__NEWLM, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__BINDING__MASK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__BINDING__MASK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DEEPBIND_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DEEPBIND, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__CONFIGADDR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__CONFIGADDR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__LINKMAP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__LINKMAP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__LMID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__LMID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__MAX_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 11, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__MAX, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__ORIGIN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 6, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__ORIGIN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__PHDR_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 11, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PHDR, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILENAME_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 7, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILENAME, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILEOUT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILEOUT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFOSIZE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 5, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFOSIZE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFO_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFO, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__DATA_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 10, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__DATA, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__MODID_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 9, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__MODID, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DL__LINKMAP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DL__LINKMAP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__DL__SYMENT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__DL__SYMENT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__GLOBAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 256, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__GLOBAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__LAZY_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__LAZY, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__LOCAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__LOCAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__NODELETE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4096, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__NODELETE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__NOLOAD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__NOLOAD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3cdlfcn_2eh_3e_2eRTLD__NOW_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3cdlfcn_2eh_3e_2eRTLD__NOW, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local %"<dlfcn.h>:Dl_info" @_3cdlfcn_2eh_3e_3aDl__info_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<dlfcn.h>:Dl_info"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<dlfcn.h>:Dl_info" undef, ptr null, 0
  %t4 = insertvalue %"<dlfcn.h>:Dl_info" %t2, ptr null, 1
  %t6 = insertvalue %"<dlfcn.h>:Dl_info" %t4, ptr null, 2
  %t8 = insertvalue %"<dlfcn.h>:Dl_info" %t6, ptr null, 3
  store %"<dlfcn.h>:Dl_info" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"<dlfcn.h>:Dl_info", ptr %rv
  ret %"<dlfcn.h>:Dl_info" %rr
}

define dso_local %"<dlfcn.h>:Dl_serinfo" @_3cdlfcn_2eh_3e_3aDl__serinfo_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<dlfcn.h>:Dl_serinfo"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [4 x i64] undef, i64 0, 0
  %t2 = insertvalue [4 x i64] %t1, i64 0, 1
  %t3 = insertvalue [4 x i64] %t2, i64 0, 2
  %t4 = insertvalue [4 x i64] %t3, i64 0, 3
  %t7 = insertvalue %"<dlfcn.h>:Dl_serinfo" undef, [4 x i64] %t4, 0
  store %"<dlfcn.h>:Dl_serinfo" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"<dlfcn.h>:Dl_serinfo", ptr %rv
  ret %"<dlfcn.h>:Dl_serinfo" %rr
}

define dso_local %"<dlfcn.h>:Dl_serpath" @_3cdlfcn_2eh_3e_3aDl__serpath_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<dlfcn.h>:Dl_serpath"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"<dlfcn.h>:Dl_serpath" undef, ptr null, 0
  %t4 = insertvalue %"<dlfcn.h>:Dl_serpath" %t2, i32 0, 1
  store %"<dlfcn.h>:Dl_serpath" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"<dlfcn.h>:Dl_serpath", ptr %rv
  ret %"<dlfcn.h>:Dl_serpath" %rr
}

define dso_local %"<dlfcn.h>:dl_find_object" @_3cdlfcn_2eh_3e_3adl__find__object_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"<dlfcn.h>:dl_find_object"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [7 x i64] undef, i64 0, 0
  %t2 = insertvalue [7 x i64] %t1, i64 0, 1
  %t3 = insertvalue [7 x i64] %t2, i64 0, 2
  %t4 = insertvalue [7 x i64] %t3, i64 0, 3
  %t5 = insertvalue [7 x i64] %t4, i64 0, 4
  %t6 = insertvalue [7 x i64] %t5, i64 0, 5
  %t7 = insertvalue [7 x i64] %t6, i64 0, 6
  %t10 = insertvalue %"<dlfcn.h>:dl_find_object" undef, i64 0, 0
  %t12 = insertvalue %"<dlfcn.h>:dl_find_object" %t10, ptr null, 1
  %t14 = insertvalue %"<dlfcn.h>:dl_find_object" %t12, ptr null, 2
  %t16 = insertvalue %"<dlfcn.h>:dl_find_object" %t14, ptr null, 3
  %t18 = insertvalue %"<dlfcn.h>:dl_find_object" %t16, ptr null, 4
  %t20 = insertvalue %"<dlfcn.h>:dl_find_object" %t18, [7 x i64] %t7, 5
  store %"<dlfcn.h>:dl_find_object" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"<dlfcn.h>:dl_find_object", ptr %rv
  ret %"<dlfcn.h>:dl_find_object" %rr
}

define dso_local void @olang_2einit_2e_3cdlfcn_2eh_3e() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DL__SYMENT_2einit()
  br label %bb1
bb1:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DL__LINKMAP_2einit()
  br label %bb2
bb2:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__LMID_2einit()
  br label %bb3
bb3:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__LINKMAP_2einit()
  br label %bb4
bb4:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__CONFIGADDR_2einit()
  br label %bb5
bb5:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFO_2einit()
  br label %bb6
bb6:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__SERINFOSIZE_2einit()
  br label %bb7
bb7:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__ORIGIN_2einit()
  br label %bb8
bb8:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILENAME_2einit()
  br label %bb9
bb9:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__PROFILEOUT_2einit()
  br label %bb10
bb10:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__MODID_2einit()
  br label %bb11
bb11:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__TLS__DATA_2einit()
  br label %bb12
bb12:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__PHDR_2einit()
  br label %bb13
bb13:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DI__MAX_2einit()
  br label %bb14
bb14:
  call void @_3cdlfcn_2eh_3e_2eRTLD__LAZY_2einit()
  br label %bb15
bb15:
  call void @_3cdlfcn_2eh_3e_2eRTLD__NOW_2einit()
  br label %bb16
bb16:
  call void @_3cdlfcn_2eh_3e_2eRTLD__BINDING__MASK_2einit()
  br label %bb17
bb17:
  call void @_3cdlfcn_2eh_3e_2eRTLD__NOLOAD_2einit()
  br label %bb18
bb18:
  call void @_3cdlfcn_2eh_3e_2eRTLD__DEEPBIND_2einit()
  br label %bb19
bb19:
  call void @_3cdlfcn_2eh_3e_2eRTLD__GLOBAL_2einit()
  br label %bb20
bb20:
  call void @_3cdlfcn_2eh_3e_2eRTLD__LOCAL_2einit()
  br label %bb21
bb21:
  call void @_3cdlfcn_2eh_3e_2eRTLD__NODELETE_2einit()
  br label %bb22
bb22:
  call void @_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__DBASE_2einit()
  br label %bb23
bb23:
  call void @_3cdlfcn_2eh_3e_2eDLFO__STRUCT__HAS__EH__COUNT_2einit()
  br label %bb24
bb24:
  call void @_3cdlfcn_2eh_3e_2eLM__ID__BASE_2einit()
  br label %bb25
bb25:
  call void @_3cdlfcn_2eh_3e_2eLM__ID__NEWLM_2einit()
  br label %bb26
bb26:
  br label %ret
ret:
  ret void
}


!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
