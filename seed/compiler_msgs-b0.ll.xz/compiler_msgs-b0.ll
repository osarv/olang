; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/msgs:Nearest" = type { { i64, ptr }, { i64, ptr }, i64 }
define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyMethodScopes(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 196, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %t9, 1
  %t25 = extractvalue { i64, ptr } %t9, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l4
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l11
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d5, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t63, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t68, ptr %l16
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnyNotMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 195, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = extractvalue { i64, ptr } %t37, 0
  %t42 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t46 = extractvalue { i64, ptr } %a2, 1
  %t47 = extractvalue { i64, ptr } %a2, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load i64, ptr %l10
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call ptr @__olang_held_alloc(ptr %t53, i64 %t51)
  call void @olang_textcopy(ptr %t54, ptr %t40, i64 %t41)
  %t55 = getelementptr i8, ptr %t54, i64 %t41
  call void @olang_textcopy(ptr %t55, ptr %t42, i64 %t43)
  %t56 = getelementptr i8, ptr %t55, i64 %t43
  call void @olang_textcopy(ptr %t56, ptr %t46, i64 %t47)
  %t57 = getelementptr i8, ptr %t56, i64 %t47
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t54, 1
  %t61 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t61, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d11, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t64, ptr %l16
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayTypeHoldsItself(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 166, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l4
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v3)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l9, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v3)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t29 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %a1, 1
  %t33 = extractvalue { i64, ptr } %a1, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = extractvalue { i64, ptr } %a2, 1
  %t40 = extractvalue { i64, ptr } %a2, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = load i64, ptr %l9
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  call void @olang_textcopy(ptr %t47, ptr %t29, i64 %t30)
  %t48 = getelementptr i8, ptr %t47, i64 %t30
  call void @olang_textcopy(ptr %t48, ptr %t32, i64 %t33)
  %t49 = getelementptr i8, ptr %t48, i64 %t33
  call void @olang_textcopy(ptr %t49, ptr %t35, i64 %t36)
  %t50 = getelementptr i8, ptr %t49, i64 %t36
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l15
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBareDefer(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 93, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l7
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l11, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t60 = extractvalue { i64, ptr } %t55, 1
  %t61 = extractvalue { i64, ptr } %t55, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = extractvalue { i64, ptr } %t56, 1
  %t68 = extractvalue { i64, ptr } %t56, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load i64, ptr %l12
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call ptr @__olang_held_alloc(ptr %t74, i64 %t72)
  call void @olang_textcopy(ptr %t75, ptr %t57, i64 %t58)
  %t76 = getelementptr i8, ptr %t75, i64 %t58
  call void @olang_textcopy(ptr %t76, ptr %t60, i64 %t61)
  %t77 = getelementptr i8, ptr %t76, i64 %t61
  call void @olang_textcopy(ptr %t77, ptr %t63, i64 %t64)
  %t78 = getelementptr i8, ptr %t77, i64 %t64
  call void @olang_textcopy(ptr %t78, ptr %t67, i64 %t68)
  %t79 = getelementptr i8, ptr %t78, i64 %t68
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t75, 1
  %t83 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t83, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, { i64, ptr } %t84, { i64, ptr } %t85, { i64, ptr } %t81)
  store %"compiler/diagmsg:Msg" %t87, ptr %l18
  br label %bb7
bb7:
  %t88 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t88, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBorrowSplitParam(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 399, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t31, 1
  %t37 = extractvalue { i64, ptr } %t31, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 83, ptr getelementptr inbounds (<{ i64, [83 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t32, 1
  %t44 = extractvalue { i64, ptr } %t32, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l7
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t36, i64 %t37)
  %t53 = getelementptr i8, ptr %t52, i64 %t37
  call void @olang_textcopy(ptr %t53, ptr %t39, i64 %t40)
  %t54 = getelementptr i8, ptr %t53, i64 %t40
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t51, 1
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t59, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 80, ptr getelementptr inbounds (<{ i64, [80 x i8] }>, ptr @.d32, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l13
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuildDefaultBare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 151, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %t7, 1
  %t14 = extractvalue { i64, ptr } %t7, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a1, 1
  %t21 = extractvalue { i64, ptr } %a1, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t9, 1
  %t28 = extractvalue { i64, ptr } %t9, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load i64, ptr %l4
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_held_alloc(ptr %t34, i64 %t32)
  call void @olang_textcopy(ptr %t35, ptr %t10, i64 %t11)
  %t36 = getelementptr i8, ptr %t35, i64 %t11
  call void @olang_textcopy(ptr %t36, ptr %t13, i64 %t14)
  %t37 = getelementptr i8, ptr %t36, i64 %t14
  call void @olang_textcopy(ptr %t37, ptr %t16, i64 %t17)
  %t38 = getelementptr i8, ptr %t37, i64 %t17
  call void @olang_textcopy(ptr %t38, ptr %t20, i64 %t21)
  %t39 = getelementptr i8, ptr %t38, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t35, 1
  store { i64, ptr } %t43, ptr %l10, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = call ptr @__olang_region_make(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l13, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t54, ptr %l15
  br label %bb5
bb5:
  %t55 = load i1, ptr %l15, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb8
bb8:
  %t58 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t60 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = add i64 %t66, %t69
  %t71 = load i64, ptr %l11
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call ptr @__olang_held_alloc(ptr %t72, i64 %t70)
  call void @olang_textcopy(ptr %t73, ptr %t58, i64 %t59)
  %t74 = getelementptr i8, ptr %t73, i64 %t59
  call void @olang_textcopy(ptr %t74, ptr %t61, i64 %t62)
  %t75 = getelementptr i8, ptr %t74, i64 %t62
  call void @olang_textcopy(ptr %t75, ptr %t64, i64 %t65)
  %t76 = getelementptr i8, ptr %t75, i64 %t65
  call void @olang_textcopy(ptr %t76, ptr %t68, i64 %t69)
  %t77 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t73, 1
  %t80 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t81 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t83 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t80, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, { i64, ptr } %t81, { i64, ptr } %t78, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t83, ptr %l20
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t84 = load %"compiler/diagmsg:Msg", ptr %l20
  store %"compiler/diagmsg:Msg" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderExpected(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 328, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %a2, 1
  %t45 = extractvalue { i64, ptr } %a2, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t38, 1
  %t52 = extractvalue { i64, ptr } %t38, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = extractvalue { i64, ptr } %t39, 1
  %t59 = extractvalue { i64, ptr } %t39, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t65 = extractvalue { i64, ptr } %t40, 1
  %t66 = extractvalue { i64, ptr } %t40, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load i64, ptr %l11
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = call ptr @__olang_held_alloc(ptr %t72, i64 %t70)
  call void @olang_textcopy(ptr %t73, ptr %t41, i64 %t42)
  %t74 = getelementptr i8, ptr %t73, i64 %t42
  call void @olang_textcopy(ptr %t74, ptr %t44, i64 %t45)
  %t75 = getelementptr i8, ptr %t74, i64 %t45
  call void @olang_textcopy(ptr %t75, ptr %t47, i64 %t48)
  %t76 = getelementptr i8, ptr %t75, i64 %t48
  call void @olang_textcopy(ptr %t76, ptr %t51, i64 %t52)
  %t77 = getelementptr i8, ptr %t76, i64 %t52
  call void @olang_textcopy(ptr %t77, ptr %t54, i64 %t55)
  %t78 = getelementptr i8, ptr %t77, i64 %t55
  call void @olang_textcopy(ptr %t78, ptr %t58, i64 %t59)
  %t79 = getelementptr i8, ptr %t78, i64 %t59
  call void @olang_textcopy(ptr %t79, ptr %t61, i64 %t62)
  %t80 = getelementptr i8, ptr %t79, i64 %t62
  call void @olang_textcopy(ptr %t80, ptr %t65, i64 %t66)
  %t81 = getelementptr i8, ptr %t80, i64 %t66
  call void @olang_textcopy(ptr %t81, ptr %t68, i64 %t69)
  %t82 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t73, 1
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t86 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t88, ptr %l19
  br label %bb5
bb5:
  %t89 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t89, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderOwnerBare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 329, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l5
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v4)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l10, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v4)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t28 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %a1, 1
  %t35 = extractvalue { i64, ptr } %a1, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %t28, 1
  %t42 = extractvalue { i64, ptr } %t28, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = extractvalue { i64, ptr } %a2, 1
  %t49 = extractvalue { i64, ptr } %a2, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t55 = extractvalue { i64, ptr } %t30, 1
  %t56 = extractvalue { i64, ptr } %t30, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = load i64, ptr %l10
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call ptr @__olang_held_alloc(ptr %t62, i64 %t60)
  call void @olang_textcopy(ptr %t63, ptr %t31, i64 %t32)
  %t64 = getelementptr i8, ptr %t63, i64 %t32
  call void @olang_textcopy(ptr %t64, ptr %t34, i64 %t35)
  %t65 = getelementptr i8, ptr %t64, i64 %t35
  call void @olang_textcopy(ptr %t65, ptr %t37, i64 %t38)
  %t66 = getelementptr i8, ptr %t65, i64 %t38
  call void @olang_textcopy(ptr %t66, ptr %t41, i64 %t42)
  %t67 = getelementptr i8, ptr %t66, i64 %t42
  call void @olang_textcopy(ptr %t67, ptr %t44, i64 %t45)
  %t68 = getelementptr i8, ptr %t67, i64 %t45
  call void @olang_textcopy(ptr %t68, ptr %t48, i64 %t49)
  %t69 = getelementptr i8, ptr %t68, i64 %t49
  call void @olang_textcopy(ptr %t69, ptr %t51, i64 %t52)
  %t70 = getelementptr i8, ptr %t69, i64 %t52
  call void @olang_textcopy(ptr %t70, ptr %t55, i64 %t56)
  %t71 = getelementptr i8, ptr %t70, i64 %t56
  call void @olang_textcopy(ptr %t71, ptr %t58, i64 %t59)
  %t72 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t63, 1
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t78 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t78, ptr %l18
  br label %bb5
bb5:
  %t79 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderResult(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 324, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t15, i64 %t16)
  %t27 = getelementptr i8, ptr %t26, i64 %t16
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = extractvalue { i64, ptr } %t37, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l9
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d62, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t58, ptr %l14
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBuilderTakesOwner(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 325, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l9
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d68, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l14
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaseTypeArgsNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l14 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l25 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 574, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l3
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l10, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l11, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l14, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l17, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l14, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb5, label %bb6
bb5:
  %t47 = load i64, ptr %l14, !tbaa !24
  %t48 = load i64, ptr %l17, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb7:
  %t51 = load i64, ptr %l17, !tbaa !24
  %t52 = load i64, ptr %l18, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb9:
  %t55 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l14, !tbaa !24
  %t58 = load i64, ptr %l17, !tbaa !24
  %t59 = getelementptr i8, ptr %t56, i64 %t57
  %t60 = sub i64 %t58, %t57
  %t61 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t63 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t73 = extractvalue { i64, ptr } %t62, 1
  %t74 = extractvalue { i64, ptr } %t62, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load i64, ptr %l8
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = call ptr @__olang_held_alloc(ptr %t80, i64 %t78)
  call void @olang_textcopy(ptr %t81, ptr %t63, i64 %t64)
  %t82 = getelementptr i8, ptr %t81, i64 %t64
  call void @olang_textcopy(ptr %t82, ptr %t66, i64 %t67)
  %t83 = getelementptr i8, ptr %t82, i64 %t67
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t81, 1
  %t89 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t92 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t89, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d75, i32 0, i32 1) }, { i64, ptr } %t90, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, { i64, ptr } %t87)
  store %"compiler/diagmsg:Msg" %t92, ptr %l25
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_78fb4d3249708b2_e3f9318f90ab6b26)
  unreachable
bb11:
  %t93 = load %"compiler/diagmsg:Msg", ptr %l25
  store %"compiler/diagmsg:Msg" %t93, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eColumnNamedLikeMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 930, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %a1, 1
  %t12 = extractvalue { i64, ptr } %a1, 0
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %t8, 1
  %t18 = extractvalue { i64, ptr } %t8, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a0, 1
  %t25 = extractvalue { i64, ptr } %a0, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l4
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l11
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t63, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t68, ptr %l16
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCommutesClash(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 263, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a1, 1
  %t21 = extractvalue { i64, ptr } %a1, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load i64, ptr %l5
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_held_alloc(ptr %t34, i64 %t32)
  call void @olang_textcopy(ptr %t35, ptr %t10, i64 %t11)
  %t36 = getelementptr i8, ptr %t35, i64 %t11
  call void @olang_textcopy(ptr %t36, ptr %t13, i64 %t14)
  %t37 = getelementptr i8, ptr %t36, i64 %t14
  call void @olang_textcopy(ptr %t37, ptr %t16, i64 %t17)
  %t38 = getelementptr i8, ptr %t37, i64 %t17
  call void @olang_textcopy(ptr %t38, ptr %t20, i64 %t21)
  %t39 = getelementptr i8, ptr %t38, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t35, 1
  store { i64, ptr } %t43, ptr %l11, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v4)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l12, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = call ptr @__olang_region_make(ptr %v4)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t52 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %a3, 1
  %t56 = extractvalue { i64, ptr } %a3, 0
  %t57 = add i64 %t53, %t56
  %t58 = load i64, ptr %l12
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t52, i64 %t53)
  %t61 = getelementptr i8, ptr %t60, i64 %t53
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d89, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t63, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d90, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t68, ptr %l17
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintClosed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 158, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l6
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v5)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l13, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v5)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t46 = extractvalue { i64, ptr } %a3, 1
  %t47 = extractvalue { i64, ptr } %a3, 0
  %t48 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t52 = extractvalue { i64, ptr } %a4, 1
  %t53 = extractvalue { i64, ptr } %a4, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l13
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t60, 1
  %t67 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t68 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t70 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t67, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d95, i32 0, i32 1) }, { i64, ptr } %t68, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t70, ptr %l19
  br label %bb5
bb5:
  %t71 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintSealed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 157, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l6
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v5)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l13, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v5)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t46 = extractvalue { i64, ptr } %a3, 1
  %t47 = extractvalue { i64, ptr } %a3, 0
  %t48 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t52 = extractvalue { i64, ptr } %a4, 1
  %t53 = extractvalue { i64, ptr } %a4, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l13
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t60, 1
  %t67 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t68 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t70 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t67, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) }, { i64, ptr } %t68, { i64, ptr } %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t70, ptr %l19
  br label %bb5
bb5:
  %t71 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t71, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintUnmetBuilder(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 342, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l5
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v4)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v4)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t44 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %a3, 1
  %t48 = extractvalue { i64, ptr } %a3, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load i64, ptr %l12
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t50, i64 %t51)
  %t58 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t55, 1
  %t61 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t61, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t64, ptr %l17
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eConstraintUnmetMethod(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 156, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l5
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v4)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v4)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t44 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %a3, 1
  %t48 = extractvalue { i64, ptr } %a3, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load i64, ptr %l12
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t50, i64 %t51)
  %t58 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t55, 1
  %t61 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t61, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d110, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } %t59, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t64, ptr %l17
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCopyShape(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 269, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t31, 1
  %t37 = extractvalue { i64, ptr } %t31, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t32, 1
  %t44 = extractvalue { i64, ptr } %t32, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l7
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t36, i64 %t37)
  %t53 = getelementptr i8, ptr %t52, i64 %t37
  call void @olang_textcopy(ptr %t53, ptr %t39, i64 %t40)
  %t54 = getelementptr i8, ptr %t53, i64 %t40
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t51, 1
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t59, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d116, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d117, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l13
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorFieldNamesVar(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 411, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l5
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l10, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l11, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v4)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t43 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %a2, 1
  %t47 = extractvalue { i64, ptr } %a2, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %a3, 1
  %t54 = extractvalue { i64, ptr } %a3, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = load i64, ptr %l11
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  call void @olang_textcopy(ptr %t61, ptr %t43, i64 %t44)
  %t62 = getelementptr i8, ptr %t61, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t53, i64 %t54)
  %t65 = getelementptr i8, ptr %t64, i64 %t54
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t61, 1
  %t69 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t69, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) }, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t72, ptr %l17
  br label %bb5
bb5:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCtorVarOfGeneric(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 413, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t38 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d128, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d128, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %a2, 1
  %t42 = extractvalue { i64, ptr } %a2, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l10
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d131, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l15
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructCopiedHeld(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 184, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = extractvalue { i64, ptr } %t7, 0
  %t12 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = load i64, ptr %l3
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_held_alloc(ptr %t20, i64 %t18)
  call void @olang_textcopy(ptr %t21, ptr %t10, i64 %t11)
  %t22 = getelementptr i8, ptr %t21, i64 %t11
  call void @olang_textcopy(ptr %t22, ptr %t12, i64 %t13)
  %t23 = getelementptr i8, ptr %t22, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l8, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v2)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l9, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = call ptr @__olang_region_make(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %t33, 1
  %t38 = extractvalue { i64, ptr } %t33, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = load i64, ptr %l9
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = call ptr @__olang_held_alloc(ptr %t44, i64 %t42)
  call void @olang_textcopy(ptr %t45, ptr %t34, i64 %t35)
  %t46 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t46, ptr %t37, i64 %t38)
  %t47 = getelementptr i8, ptr %t46, i64 %t38
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  store { i64, ptr } %t49, ptr %l13, !tbaa !27
  %t51 = call ptr @__olang_scope_hold(ptr %v2)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l14, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = call ptr @__olang_region_make(ptr %v2)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t58 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %t57, 1
  %t62 = extractvalue { i64, ptr } %t57, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load i64, ptr %l14
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  call void @olang_textcopy(ptr %t69, ptr %t58, i64 %t59)
  %t70 = getelementptr i8, ptr %t69, i64 %t59
  call void @olang_textcopy(ptr %t70, ptr %t61, i64 %t62)
  %t71 = getelementptr i8, ptr %t70, i64 %t62
  call void @olang_textcopy(ptr %t71, ptr %t64, i64 %t65)
  %t72 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t69, 1
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t79 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d137, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } %t77, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t79, ptr %l19
  br label %bb7
bb7:
  %t80 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructTypeByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 183, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = extractvalue { i64, ptr } %t7, 0
  %t12 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t39 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %t37, 1
  %t43 = extractvalue { i64, ptr } %t37, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %t38, 1
  %t50 = extractvalue { i64, ptr } %t38, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l9
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t42, i64 %t43)
  %t59 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t59, ptr %t45, i64 %t46)
  %t60 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d143, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d144, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l15
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l35 = alloca i1
  %l42 = alloca i64
  %l48 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i64
  %l70 = alloca i64
  %l73 = alloca i1
  %l94 = alloca i64
  %l97 = alloca i64
  %l122 = alloca i64
  %l125 = alloca i64
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l150 = alloca i8
  %l151 = alloca { i64, ptr }
  %l155 = alloca i8
  %l157 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i64
  %l176 = alloca i64
  %l188 = alloca i64
  %l191 = alloca i64
  %l200 = alloca i64
  %l203 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 60
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 60
  store i1 %t11, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l35, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 99, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l42, !tbaa !24
  %t20 = load i64, ptr %l42, !tbaa !24
  %t21 = icmp sge i64 %t20, 0
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l42, !tbaa !24
  %t24 = icmp sle i64 %t23, 1152921504606846975
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_d93addea5b815da9_e849c161ff4e7de5)
  unreachable
bb9:
  %t26 = load i64, ptr %l42, !tbaa !24
  %t27 = mul i64 %t26, 8
  %t28 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l2, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l48, !tbaa !24
  %t37 = load i64, ptr %l48, !tbaa !24
  %t38 = icmp sge i64 %t37, 0
  br i1 %t38, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d93addea5b815da9_e849c161ff4e7de5)
  unreachable
bb11:
  %t40 = load i64, ptr %l48, !tbaa !24
  %t41 = icmp sle i64 %t40, 1152921504606846975
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_fced1ba34c6512dc_349b310d7afbfd78)
  unreachable
bb13:
  %t43 = load i64, ptr %l48, !tbaa !24
  %t44 = mul i64 %t43, 8
  %t45 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_fced1ba34c6512dc_349b310d7afbfd78)
  unreachable
bb15:
  %t61 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb20
bb17:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l61, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb19
bb19:
  %t81 = load i64, ptr %l61, !tbaa !24
  store i64 %t81, ptr %l58, !tbaa !24
  br label %bb20
bb20:
  %t82 = load i64, ptr %l58, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t83, 1
  store i64 %t84, ptr %l70, !tbaa !24
  %t85 = load i64, ptr %l7, !tbaa !24
  %t86 = icmp slt i64 %t85, 2147483648
  %t87 = load i64, ptr %l8, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  %t91 = and i1 %t86, %t88
  store i1 %t91, ptr %l73, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr i64, ptr %t115, i64 %t110
  store i64 %t111, ptr %t116, !tbaa !34
  br label %bb25
bb25:
  %t117 = load i64, ptr %l8, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l8, !tbaa !24
  br label %bb21
bb26:
  store i64 1, ptr %l10, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t129 = load i64, ptr %l10, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb27, label %bb28
bb27:
  %t134 = load i64, ptr %l12, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb32
bb29:
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l12, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l97, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb31
bb31:
  %t154 = load i64, ptr %l97, !tbaa !24
  store i64 %t154, ptr %l94, !tbaa !24
  br label %bb32
bb32:
  %t155 = load i64, ptr %l94, !tbaa !24
  store i64 %t155, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb33
bb33:
  %t156 = load i64, ptr %l14, !tbaa !24
  %t157 = load i64, ptr %l13, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb34, label %bb35
bb34:
  br label %bb73
bb35:
  br label %bb36
bb36:
  %t164 = load i64, ptr %l10, !tbaa !24
  %t165 = load i64, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l15, !tbaa !24
  %t174 = load i64, ptr %l15, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 0
  store i64 %t174, ptr %t178, !tbaa !34
  store i64 1, ptr %l16, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t183 = add i64 %t181, 1
  store i64 %t183, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t185 = load i64, ptr %l17, !tbaa !24
  %t186 = load i64, ptr %l16, !tbaa !24
  %t189 = icmp sgt i64 %t185, %t186
  br i1 %t189, label %bb37, label %bb38
bb37:
  %t191 = load i64, ptr %l18, !tbaa !24
  %t193 = icmp sgt i64 %t191, 0
  br i1 %t193, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb42
bb39:
  %t195 = load i64, ptr %l17, !tbaa !24
  %t196 = load i64, ptr %l16, !tbaa !24
  %t199 = sub i64 %t195, %t196
  %t200 = load i64, ptr %l18, !tbaa !24
  %t203 = add i64 %t199, %t200
  %t205 = sub i64 %t203, 1
  %t206 = load i64, ptr %l18, !tbaa !24
  %t209 = sdiv i64 %t205, %t206
  store i64 %t209, ptr %l125, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb41
bb41:
  %t211 = load i64, ptr %l125, !tbaa !24
  store i64 %t211, ptr %l122, !tbaa !24
  br label %bb42
bb42:
  %t212 = load i64, ptr %l122, !tbaa !24
  store i64 %t212, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb43
bb43:
  %t213 = load i64, ptr %l20, !tbaa !24
  %t214 = load i64, ptr %l19, !tbaa !24
  %t217 = icmp slt i64 %t213, %t214
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  %t221 = load i64, ptr %l16, !tbaa !24
  %t222 = load i64, ptr %l20, !tbaa !24
  %t223 = load i64, ptr %l18, !tbaa !24
  %t226 = mul i64 %t222, %t223
  %t229 = add i64 %t221, %t226
  store i64 %t229, ptr %l21, !tbaa !24
  %t231 = load i64, ptr %l21, !tbaa !24
  %t233 = sub i64 %t231, 1
  %t235 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr i64, ptr %t236, i64 %t233
  %t238 = load i64, ptr %t237, !tbaa !34
  store i64 %t238, ptr %l145, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t239, ptr %l146, !tbaa !27
  %t240 = load i64, ptr %l15, !tbaa !24
  %t242 = sub i64 %t240, 1
  %t244 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr i8, ptr %t245, i64 %t242
  %t247 = load i8, ptr %t246, !tbaa !32
  %t249 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t247)
  store i8 %t249, ptr %l150
  br label %bb47
bb47:
  %t250 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t250, ptr %l151, !tbaa !27
  %t251 = load i64, ptr %l21, !tbaa !24
  %t253 = sub i64 %t251, 1
  %t255 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = getelementptr i8, ptr %t256, i64 %t253
  %t258 = load i8, ptr %t257, !tbaa !32
  %t260 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t258)
  store i8 %t260, ptr %l155
  br label %bb48
bb48:
  %t261 = load i8, ptr %l150, !tbaa !22
  %t262 = load i8, ptr %l155, !tbaa !22
  %t263 = icmp eq i8 %t261, %t262
  br i1 %t263, label %bb49, label %bb50
bb49:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb51
bb50:
  store i64 1, ptr %l157, !tbaa !24
  br label %bb51
bb51:
  %t265 = load i64, ptr %l145, !tbaa !24
  %t266 = load i64, ptr %l157, !tbaa !24
  %t267 = add i64 %t265, %t266
  store i64 %t267, ptr %l22, !tbaa !24
  %t269 = load i64, ptr %l21, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr i64, ptr %t272, i64 %t269
  %t274 = load i64, ptr %t273, !tbaa !34
  %t276 = add i64 %t274, 1
  store i64 %t276, ptr %l23, !tbaa !24
  %t278 = load i64, ptr %l21, !tbaa !24
  %t280 = sub i64 %t278, 1
  %t282 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr i64, ptr %t283, i64 %t280
  %t285 = load i64, ptr %t284, !tbaa !34
  %t287 = add i64 %t285, 1
  store i64 %t287, ptr %l24, !tbaa !24
  %t289 = load i64, ptr %l22, !tbaa !24
  %t290 = load i64, ptr %l23, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  br i1 %t293, label %bb52, label %bb53
bb52:
  %t295 = load i64, ptr %l22, !tbaa !24
  store i64 %t295, ptr %l169, !tbaa !24
  br label %bb54
bb53:
  %t297 = load i64, ptr %l23, !tbaa !24
  store i64 %t297, ptr %l169, !tbaa !24
  br label %bb54
bb54:
  %t299 = load i64, ptr %l169, !tbaa !24
  store i64 %t299, ptr %l25, !tbaa !24
  %t300 = load i64, ptr %l21, !tbaa !24
  store i64 %t300, ptr %l172, !tbaa !24
  %t301 = load i64, ptr %l25, !tbaa !24
  %t302 = load i64, ptr %l24, !tbaa !24
  %t305 = icmp slt i64 %t301, %t302
  br i1 %t305, label %bb55, label %bb56
bb55:
  %t307 = load i64, ptr %l25, !tbaa !24
  store i64 %t307, ptr %l176, !tbaa !24
  br label %bb57
bb56:
  %t309 = load i64, ptr %l24, !tbaa !24
  store i64 %t309, ptr %l176, !tbaa !24
  br label %bb57
bb57:
  %t311 = load i64, ptr %l176, !tbaa !24
  %t312 = load i64, ptr %l172, !tbaa !24
  %t313 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i64, ptr %t314, i64 %t312
  store i64 %t311, ptr %t315, !tbaa !34
  br label %bb58
bb58:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = add i64 %t316, 1
  store i64 %t319, ptr %l20, !tbaa !24
  br label %bb43
bb59:
  store i64 0, ptr %l26, !tbaa !24
  %t321 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t325 = add i64 %t323, 1
  store i64 %t325, ptr %l27, !tbaa !24
  store i64 1, ptr %l28, !tbaa !24
  %t327 = load i64, ptr %l27, !tbaa !24
  %t328 = load i64, ptr %l26, !tbaa !24
  %t331 = icmp sgt i64 %t327, %t328
  br i1 %t331, label %bb60, label %bb61
bb60:
  %t333 = load i64, ptr %l28, !tbaa !24
  %t335 = icmp sgt i64 %t333, 0
  br i1 %t335, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l188, !tbaa !24
  br label %bb65
bb62:
  %t337 = load i64, ptr %l27, !tbaa !24
  %t338 = load i64, ptr %l26, !tbaa !24
  %t341 = sub i64 %t337, %t338
  %t342 = load i64, ptr %l28, !tbaa !24
  %t345 = add i64 %t341, %t342
  %t347 = sub i64 %t345, 1
  %t348 = load i64, ptr %l28, !tbaa !24
  %t351 = sdiv i64 %t347, %t348
  store i64 %t351, ptr %l191, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l191, !tbaa !24
  br label %bb64
bb64:
  %t353 = load i64, ptr %l191, !tbaa !24
  store i64 %t353, ptr %l188, !tbaa !24
  br label %bb65
bb65:
  %t354 = load i64, ptr %l188, !tbaa !24
  store i64 %t354, ptr %l29, !tbaa !24
  store i64 0, ptr %l30, !tbaa !24
  %t355 = load i64, ptr %l29, !tbaa !24
  %t356 = sub i64 %t355, 1
  store i64 %t356, ptr %l200, !tbaa !24
  %t357 = load i64, ptr %l29, !tbaa !24
  %t358 = icmp slt i64 %t357, 2147483648
  %t359 = load i64, ptr %l30, !tbaa !24
  %t360 = icmp sge i64 %t359, 0
  %t363 = and i1 %t358, %t360
  store i1 %t363, ptr %l203, !tbaa !21
  br label %bb66
bb66:
  %t364 = load i64, ptr %l30, !tbaa !24
  %t365 = load i64, ptr %l29, !tbaa !24
  %t368 = icmp slt i64 %t364, %t365
  %t370 = xor i1 %t368, true
  br i1 %t370, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t372 = load i64, ptr %l26, !tbaa !24
  %t373 = load i64, ptr %l30, !tbaa !24
  %t374 = load i64, ptr %l28, !tbaa !24
  %t377 = mul i64 %t373, %t374
  %t380 = add i64 %t372, %t377
  store i64 %t380, ptr %l31, !tbaa !24
  %t382 = load i64, ptr %l31, !tbaa !24
  %t383 = load i64, ptr %l31, !tbaa !24
  %t385 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr i64, ptr %t386, i64 %t383
  %t388 = load i64, ptr %t387, !tbaa !34
  %t391 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr i64, ptr %t392, i64 %t382
  store i64 %t388, ptr %t393, !tbaa !34
  br label %bb70
bb70:
  %t394 = load i64, ptr %l30, !tbaa !24
  %t397 = add i64 %t394, 1
  store i64 %t397, ptr %l30, !tbaa !24
  br label %bb66
bb71:
  br label %bb72
bb72:
  %t399 = load i64, ptr %l14, !tbaa !24
  %t402 = add i64 %t399, 1
  store i64 %t402, ptr %l14, !tbaa !24
  br label %bb33
bb73:
  %t404 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t408 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr i64, ptr %t409, i64 %t406
  %t411 = load i64, ptr %t410, !tbaa !34
  call void @__olang_scope_close(ptr %s0)
  store i64 %t411, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropRegistered(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l21 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 295, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 99, ptr getelementptr inbounds (<{ i64, [99 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d149, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d149, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l10
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  store { i64, ptr } %t57, ptr %l14, !tbaa !27
  %t59 = call ptr @__olang_scope_hold(ptr %v3)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l15, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t61, label %bb5, label %bb6
bb5:
  %t63 = call ptr @__olang_region_make(ptr %v3)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t67 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t68 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t70 = extractvalue { i64, ptr } %t65, 1
  %t71 = extractvalue { i64, ptr } %t65, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = extractvalue { i64, ptr } %a2, 1
  %t78 = extractvalue { i64, ptr } %a2, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = load i64, ptr %l15
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = call ptr @__olang_held_alloc(ptr %t84, i64 %t82)
  call void @olang_textcopy(ptr %t85, ptr %t67, i64 %t68)
  %t86 = getelementptr i8, ptr %t85, i64 %t68
  call void @olang_textcopy(ptr %t86, ptr %t70, i64 %t71)
  %t87 = getelementptr i8, ptr %t86, i64 %t71
  call void @olang_textcopy(ptr %t87, ptr %t73, i64 %t74)
  %t88 = getelementptr i8, ptr %t87, i64 %t74
  call void @olang_textcopy(ptr %t88, ptr %t77, i64 %t78)
  %t89 = getelementptr i8, ptr %t88, i64 %t78
  call void @olang_textcopy(ptr %t89, ptr %t80, i64 %t81)
  %t90 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t85, 1
  %t93 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t94 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t97 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t93, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d153, i32 0, i32 1) }, { i64, ptr } %t94, { i64, ptr } %t95, { i64, ptr } %t91)
  store %"compiler/diagmsg:Msg" %t97, ptr %l21
  br label %bb7
bb7:
  %t98 = load %"compiler/diagmsg:Msg", ptr %l21
  store %"compiler/diagmsg:Msg" %t98, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDropTempRegistered(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 296, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l3
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l8
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l12, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v2)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l13, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v2)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t56 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %a1, 1
  %t60 = extractvalue { i64, ptr } %a1, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l13
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t56, i64 %t57)
  %t68 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t73 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t74 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t73, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d160, i32 0, i32 1) }, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } %t71)
  store %"compiler/diagmsg:Msg" %t77, ptr %l18
  br label %bb7
bb7:
  %t78 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eEffectBeyond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 734, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = load i64, ptr %l5
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_held_alloc(ptr %t20, i64 %t18)
  call void @olang_textcopy(ptr %t21, ptr %t10, i64 %t11)
  %t22 = getelementptr i8, ptr %t21, i64 %t11
  call void @olang_textcopy(ptr %t22, ptr %t12, i64 %t13)
  %t23 = getelementptr i8, ptr %t22, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v4)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l11, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = call ptr @__olang_region_make(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %a2, 1
  %t39 = extractvalue { i64, ptr } %a2, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t45 = extractvalue { i64, ptr } %t34, 1
  %t46 = extractvalue { i64, ptr } %t34, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l11
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t35, i64 %t36)
  %t54 = getelementptr i8, ptr %t53, i64 %t36
  call void @olang_textcopy(ptr %t54, ptr %t38, i64 %t39)
  %t55 = getelementptr i8, ptr %t54, i64 %t39
  call void @olang_textcopy(ptr %t55, ptr %t41, i64 %t42)
  %t56 = getelementptr i8, ptr %t55, i64 %t42
  call void @olang_textcopy(ptr %t56, ptr %t45, i64 %t46)
  %t57 = getelementptr i8, ptr %t56, i64 %t46
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t53, 1
  store { i64, ptr } %t59, ptr %l16, !tbaa !27
  %t61 = call ptr @__olang_scope_hold(ptr %v4)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l17, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t63, label %bb5, label %bb6
bb5:
  %t65 = call ptr @__olang_region_make(ptr %v4)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t68 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t71 = extractvalue { i64, ptr } %t67, 1
  %t72 = extractvalue { i64, ptr } %t67, 0
  %t73 = add i64 %t69, %t72
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t76 = add i64 %t73, %t75
  %t77 = load i64, ptr %l17
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call ptr @__olang_held_alloc(ptr %t78, i64 %t76)
  call void @olang_textcopy(ptr %t79, ptr %t68, i64 %t69)
  %t80 = getelementptr i8, ptr %t79, i64 %t69
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t79, 1
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t86 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t89 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d166, i32 0, i32 1) }, { i64, ptr } %t86, { i64, ptr } %t87, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t89, ptr %l22
  br label %bb7
bb7:
  %t90 = load %"compiler/diagmsg:Msg", ptr %l22
  store %"compiler/diagmsg:Msg" %t90, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eElemsType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 519, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t15, i64 %t16)
  %t27 = getelementptr i8, ptr %t26, i64 %t16
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = extractvalue { i64, ptr } %t37, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l9
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d171, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d172, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l14
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local { i64, ptr } @compiler_2fmsgs_2eEsc(ptr %v0, i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l30 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp eq i8 %t1, 9
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t21 = load i8, ptr %l0, !tbaa !22
  %t23 = icmp eq i8 %t21, 10
  br i1 %t23, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) }, ptr %l11, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %l12, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l13, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = mul i64 %t28, 1
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  store { i64, ptr } %t32, ptr %l14, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = mul i64 %t37, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t34, ptr %t36, i64 %t38, i1 false)
  %t39 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t40 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t41 = load i8, ptr %l0, !tbaa !22
  %t43 = icmp eq i8 %t41, 13
  br i1 %t43, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d175, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %l18, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  store i64 %t47, ptr %l19, !tbaa !24
  %t48 = load i64, ptr %l19, !tbaa !24
  %t49 = mul i64 %t48, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  store { i64, ptr } %t52, ptr %l20, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = load i64, ptr %l19, !tbaa !24
  %t58 = mul i64 %t57, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %t56, i64 %t58, i1 false)
  %t59 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t59, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t60, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t61 = load i8, ptr %l0, !tbaa !22
  %t63 = icmp eq i8 %t61, 0
  br i1 %t63, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t65, ptr %l24, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l25, !tbaa !24
  %t68 = load i64, ptr %l25, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l26, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l25, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t79, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t81 = load i8, ptr %l0, !tbaa !22
  %t84 = icmp ult i8 %t81, 32
  br i1 %t84, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  %t86 = load i8, ptr %l0, !tbaa !22
  %t89 = icmp uge i8 %t86, 127
  store i1 %t89, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t91 = load i1, ptr %l30, !tbaa !21
  br i1 %t91, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t92 = load i8, ptr %l0, !tbaa !22
  store i8 %t92, ptr %l35, !tbaa !22
  %t94 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 16)
  %t95 = extractvalue { i32, i64 } %t94, 1
  %t96 = extractvalue { i32, i64 } %t94, 0
  store i32 %t96, ptr %l37
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb19, label %ok.98, !prof !99
ok.98:
  store i64 %t95, ptr %l36
  br label %bb18
bb17:
  br label %bb22
bb18:
  %t99 = load i8, ptr %l35, !tbaa !22
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = call { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %s5, i8 %t99, i64 %t100)
  store { i64, ptr } %t101, ptr %l38
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_d2d351cc5daaf8b6_b531c4af6261323a)
  unreachable
bb20:
  %t102 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s5, ptr %s5, { i64, ptr } %t102, i64 2, i8 48)
  store { i64, ptr } %t105, ptr %l40
  br label %bb21
bb21:
  %t106 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t106, 0
  store i64 %t107, ptr %l41, !tbaa !24
  %t108 = load i64, ptr %l41, !tbaa !24
  %t109 = mul i64 %t108, 1
  %t110 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l42, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = load i64, ptr %l41, !tbaa !24
  %t118 = mul i64 %t117, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t114, ptr %t116, i64 %t118, i1 false)
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t121 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t119, i64 %t120)
  %t126 = getelementptr i8, ptr %t125, i64 %t120
  call void @olang_textcopy(ptr %t126, ptr %t122, i64 %t123)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t128, ptr %rv
  br label %ret
bb22:
  %t130 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t130, ptr %l44
  br label %bb23
bb23:
  %t131 = load %"std/prelude/text:StringBuilder", ptr %l44
  store %"std/prelude/text:StringBuilder" %t131, ptr %l2
  %t132 = load i8, ptr %l0, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l2, i8 %t132)
  br label %bb24
bb24:
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %l2)
  store { i64, ptr } %t136, ptr %l48
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactNoFunction(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 926, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d178, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d178, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l2
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v1)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d179, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 66, ptr getelementptr inbounds (<{ i64, [66 x i8] }>, ptr @.d179, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %t27, 1
  %t33 = extractvalue { i64, ptr } %t27, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = extractvalue { i64, ptr } %t28, 1
  %t40 = extractvalue { i64, ptr } %t28, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = load i64, ptr %l7
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  call void @olang_textcopy(ptr %t47, ptr %t29, i64 %t30)
  %t48 = getelementptr i8, ptr %t47, i64 %t30
  call void @olang_textcopy(ptr %t48, ptr %t32, i64 %t33)
  %t49 = getelementptr i8, ptr %t48, i64 %t33
  call void @olang_textcopy(ptr %t49, ptr %t35, i64 %t36)
  %t50 = getelementptr i8, ptr %t49, i64 %t36
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d182, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l13
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldOfEnum(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 539, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  %t32 = call ptr @__olang_scope_hold(ptr %v3)
  %t33 = ptrtoint ptr %t32 to i64
  store i64 %t33, ptr %l11, !tbaa !24
  %t34 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t34, label %bb3, label %bb4
bb3:
  %t36 = call ptr @__olang_region_make(ptr %v3)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %t38, 1
  %t43 = extractvalue { i64, ptr } %t38, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = load i64, ptr %l11
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call ptr @__olang_held_alloc(ptr %t49, i64 %t47)
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = getelementptr i8, ptr %t51, i64 %t43
  call void @olang_textcopy(ptr %t52, ptr %t45, i64 %t46)
  %t53 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t50, 1
  %t56 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t57 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t60 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v2, ptr %v3, ptr %v3, i32 %t56, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d188, i32 0, i32 1) }, { i64, ptr } %t57, { i64, ptr } %t58, { i64, ptr } %t54)
  store %"compiler/diagmsg:Msg" %t60, ptr %l16
  br label %bb5
bb5:
  %t61 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t61, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFieldUnassigned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 764, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l4
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v3)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l9, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v3)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = extractvalue { i64, ptr } %a1, 1
  %t34 = extractvalue { i64, ptr } %a1, 0
  %t35 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load i64, ptr %l9
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_held_alloc(ptr %t39, i64 %t37)
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l14, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = call ptr @__olang_region_make(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t52 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %a2, 1
  %t56 = extractvalue { i64, ptr } %a2, 0
  %t57 = add i64 %t53, %t56
  %t58 = load i64, ptr %l14
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t52, i64 %t53)
  %t61 = getelementptr i8, ptr %t60, i64 %t53
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d193, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t67, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t69, ptr %l19
  br label %bb7
bb7:
  %t70 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFnTypeDefaultConflict(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 422, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %t7, 1
  %t15 = extractvalue { i64, ptr } %t7, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %t9, 1
  %t29 = extractvalue { i64, ptr } %t9, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = load i64, ptr %l5
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_held_alloc(ptr %t39, i64 %t37)
  call void @olang_textcopy(ptr %t40, ptr %t11, i64 %t12)
  %t41 = getelementptr i8, ptr %t40, i64 %t12
  call void @olang_textcopy(ptr %t41, ptr %t14, i64 %t15)
  %t42 = getelementptr i8, ptr %t41, i64 %t15
  call void @olang_textcopy(ptr %t42, ptr %t17, i64 %t18)
  %t43 = getelementptr i8, ptr %t42, i64 %t18
  call void @olang_textcopy(ptr %t43, ptr %t21, i64 %t22)
  %t44 = getelementptr i8, ptr %t43, i64 %t22
  call void @olang_textcopy(ptr %t44, ptr %t24, i64 %t25)
  %t45 = getelementptr i8, ptr %t44, i64 %t25
  call void @olang_textcopy(ptr %t45, ptr %t28, i64 %t29)
  %t46 = getelementptr i8, ptr %t45, i64 %t29
  call void @olang_textcopy(ptr %t46, ptr %t31, i64 %t32)
  %t47 = getelementptr i8, ptr %t46, i64 %t32
  call void @olang_textcopy(ptr %t47, ptr %t35, i64 %t36)
  %t48 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t40, 1
  store { i64, ptr } %t49, ptr %l12, !tbaa !27
  %t51 = call ptr @__olang_scope_hold(ptr %v4)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l13, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t53, label %bb3, label %bb4
bb3:
  %t55 = call ptr @__olang_region_make(ptr %v4)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t57, 1
  %t63 = extractvalue { i64, ptr } %t57, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t69 = extractvalue { i64, ptr } %t58, 1
  %t70 = extractvalue { i64, ptr } %t58, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load i64, ptr %l13
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  call void @olang_textcopy(ptr %t77, ptr %t59, i64 %t60)
  %t78 = getelementptr i8, ptr %t77, i64 %t60
  call void @olang_textcopy(ptr %t78, ptr %t62, i64 %t63)
  %t79 = getelementptr i8, ptr %t78, i64 %t63
  call void @olang_textcopy(ptr %t79, ptr %t65, i64 %t66)
  %t80 = getelementptr i8, ptr %t79, i64 %t66
  call void @olang_textcopy(ptr %t80, ptr %t69, i64 %t70)
  %t81 = getelementptr i8, ptr %t80, i64 %t70
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t77, 1
  %t85 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t86 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t85, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d201, i32 0, i32 1) }, { i64, ptr } %t86, { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d202, i32 0, i32 1) }, { i64, ptr } %t83)
  store %"compiler/diagmsg:Msg" %t88, ptr %l19
  br label %bb5
bb5:
  %t89 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t89, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 235, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l2
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v1)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %t27, 1
  %t33 = extractvalue { i64, ptr } %t27, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = extractvalue { i64, ptr } %t28, 1
  %t40 = extractvalue { i64, ptr } %t28, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d206, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d206, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = load i64, ptr %l7
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  call void @olang_textcopy(ptr %t47, ptr %t29, i64 %t30)
  %t48 = getelementptr i8, ptr %t47, i64 %t30
  call void @olang_textcopy(ptr %t48, ptr %t32, i64 %t33)
  %t49 = getelementptr i8, ptr %t48, i64 %t33
  call void @olang_textcopy(ptr %t49, ptr %t35, i64 %t36)
  %t50 = getelementptr i8, ptr %t49, i64 %t36
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d207, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d208, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l13
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFreshParamRepoint(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 641, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d209, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d210, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d210, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 128, ptr getelementptr inbounds (<{ i64, [128 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 128, ptr getelementptr inbounds (<{ i64, [128 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l7
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l11, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t57 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t60 = extractvalue { i64, ptr } %t55, 1
  %t61 = extractvalue { i64, ptr } %t55, 0
  %t62 = add i64 %t58, %t61
  %t63 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t65 = add i64 %t62, %t64
  %t67 = extractvalue { i64, ptr } %t56, 1
  %t68 = extractvalue { i64, ptr } %t56, 0
  %t69 = add i64 %t65, %t68
  %t70 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d215, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 81, ptr getelementptr inbounds (<{ i64, [81 x i8] }>, ptr @.d215, i32 0, i32 1) }, 0
  %t72 = add i64 %t69, %t71
  %t73 = load i64, ptr %l12
  %t74 = inttoptr i64 %t73 to ptr
  %t75 = call ptr @__olang_held_alloc(ptr %t74, i64 %t72)
  call void @olang_textcopy(ptr %t75, ptr %t57, i64 %t58)
  %t76 = getelementptr i8, ptr %t75, i64 %t58
  call void @olang_textcopy(ptr %t76, ptr %t60, i64 %t61)
  %t77 = getelementptr i8, ptr %t76, i64 %t61
  call void @olang_textcopy(ptr %t77, ptr %t63, i64 %t64)
  %t78 = getelementptr i8, ptr %t77, i64 %t64
  call void @olang_textcopy(ptr %t78, ptr %t67, i64 %t68)
  %t79 = getelementptr i8, ptr %t78, i64 %t68
  call void @olang_textcopy(ptr %t79, ptr %t70, i64 %t71)
  %t80 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t75, 1
  %t83 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t83, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d216, i32 0, i32 1) }, { i64, ptr } %t84, { i64, ptr } %t85, { i64, ptr } %t81)
  store %"compiler/diagmsg:Msg" %t87, ptr %l18
  br label %bb7
bb7:
  %t88 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t88, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFromBitsWidth(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 341, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %t8, 1
  %t18 = extractvalue { i64, ptr } %t8, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l4
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l10, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v3)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l11, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d219, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d219, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t43, 1
  %t48 = extractvalue { i64, ptr } %t43, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = load i64, ptr %l11
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  call void @olang_textcopy(ptr %t55, ptr %t44, i64 %t45)
  %t56 = getelementptr i8, ptr %t55, i64 %t45
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t50, i64 %t51)
  %t58 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t55, 1
  %t61 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t61, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d221, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) }, { i64, ptr } %t59)
  store %"compiler/diagmsg:Msg" %t64, ptr %l16
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 189, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l2
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v1)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %t27, 1
  %t33 = extractvalue { i64, ptr } %t27, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t39 = extractvalue { i64, ptr } %t28, 1
  %t40 = extractvalue { i64, ptr } %t28, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = load i64, ptr %l7
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  call void @olang_textcopy(ptr %t47, ptr %t29, i64 %t30)
  %t48 = getelementptr i8, ptr %t47, i64 %t30
  call void @olang_textcopy(ptr %t48, ptr %t32, i64 %t33)
  %t49 = getelementptr i8, ptr %t48, i64 %t33
  call void @olang_textcopy(ptr %t49, ptr %t35, i64 %t36)
  %t50 = getelementptr i8, ptr %t49, i64 %t36
  call void @olang_textcopy(ptr %t50, ptr %t39, i64 %t40)
  %t51 = getelementptr i8, ptr %t50, i64 %t40
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t47, 1
  %t55 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d227, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l13
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclMismatch(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 190, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t15, i64 %t16)
  %t27 = getelementptr i8, ptr %t26, i64 %t16
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t38 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %a2, 1
  %t42 = extractvalue { i64, ptr } %a2, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l10
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t55, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d233, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d234, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l15
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncTypeBeyond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l20 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 733, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l10
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  store { i64, ptr } %t57, ptr %l14, !tbaa !27
  %t59 = call ptr @__olang_scope_hold(ptr %v3)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l15, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t61, label %bb5, label %bb6
bb5:
  %t63 = call ptr @__olang_region_make(ptr %v3)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = extractvalue { i64, ptr } %t65, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = load i64, ptr %l15
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  call void @olang_textcopy(ptr %t77, ptr %t66, i64 %t67)
  %t78 = getelementptr i8, ptr %t77, i64 %t67
  call void @olang_textcopy(ptr %t78, ptr %t69, i64 %t70)
  %t79 = getelementptr i8, ptr %t78, i64 %t70
  call void @olang_textcopy(ptr %t79, ptr %t72, i64 %t73)
  %t80 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t77, 1
  %t83 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t84 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t87 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t83, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d242, i32 0, i32 1) }, { i64, ptr } %t84, { i64, ptr } %t85, { i64, ptr } %t81)
  store %"compiler/diagmsg:Msg" %t87, ptr %l20
  br label %bb7
bb7:
  %t88 = load %"compiler/diagmsg:Msg", ptr %l20
  store %"compiler/diagmsg:Msg" %t88, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenErrorNotDeclared(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 579, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d243, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d243, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l2
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l6, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v1)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t28 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d244, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d244, i32 0, i32 1) }, 0
  %t31 = extractvalue { i64, ptr } %t27, 1
  %t32 = extractvalue { i64, ptr } %t27, 0
  %t33 = add i64 %t29, %t32
  %t34 = load i64, ptr %l7
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call ptr @__olang_held_alloc(ptr %t35, i64 %t33)
  call void @olang_textcopy(ptr %t36, ptr %t28, i64 %t29)
  %t37 = getelementptr i8, ptr %t36, i64 %t29
  call void @olang_textcopy(ptr %t37, ptr %t31, i64 %t32)
  %t38 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  store { i64, ptr } %t39, ptr %l11, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v1)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l12, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = call ptr @__olang_region_make(ptr %v1)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l12
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t65 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t65, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d247, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t67, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t69, ptr %l17
  br label %bb7
bb7:
  %t70 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eGenericNeeds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 922, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %t9, 1
  %t25 = extractvalue { i64, ptr } %t9, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l4
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t49 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t48, 1
  %t60 = extractvalue { i64, ptr } %t48, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l11
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t49, i64 %t50)
  %t68 = getelementptr i8, ptr %t67, i64 %t50
  call void @olang_textcopy(ptr %t68, ptr %t52, i64 %t53)
  %t69 = getelementptr i8, ptr %t68, i64 %t53
  call void @olang_textcopy(ptr %t69, ptr %t55, i64 %t56)
  %t70 = getelementptr i8, ptr %t69, i64 %t56
  call void @olang_textcopy(ptr %t70, ptr %t59, i64 %t60)
  %t71 = getelementptr i8, ptr %t70, i64 %t60
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t67, 1
  %t75 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t78 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d254, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d255, i32 0, i32 1) }, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t78, ptr %l17
  br label %bb5
bb5:
  %t79 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t79, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eImmutMutRef(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 277, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 49, ptr getelementptr inbounds (<{ i64, [49 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l7
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l11, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %t55, 1
  %t60 = extractvalue { i64, ptr } %t55, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l12
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t56, i64 %t57)
  %t68 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t73 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d262, i32 0, i32 1) }, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } %t71)
  store %"compiler/diagmsg:Msg" %t77, ptr %l17
  br label %bb7
bb7:
  %t78 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIndexProven(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 490, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l2, !tbaa !24
  %t10 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = call i64 @__olang_fmt_i64(ptr null, i64 %a1)
  %t21 = add i64 %t18, %t20
  %t22 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d265, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d265, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t9)
  %t27 = add i64 %t24, %t26
  %t28 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = load i64, ptr %l4
  %t32 = inttoptr i64 %t31 to ptr
  %t33 = call ptr @__olang_held_alloc(ptr %t32, i64 %t30)
  call void @olang_textcopy(ptr %t33, ptr %t10, i64 %t11)
  %t34 = getelementptr i8, ptr %t33, i64 %t11
  call void @olang_textcopy(ptr %t34, ptr %t13, i64 %t14)
  %t35 = getelementptr i8, ptr %t34, i64 %t14
  call void @olang_textcopy(ptr %t35, ptr %t16, i64 %t17)
  %t36 = getelementptr i8, ptr %t35, i64 %t17
  %t37 = call i64 @__olang_fmt_i64(ptr %t36, i64 %a1)
  %t38 = getelementptr i8, ptr %t36, i64 %t20
  call void @olang_textcopy(ptr %t38, ptr %t22, i64 %t23)
  %t39 = getelementptr i8, ptr %t38, i64 %t23
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t9)
  %t41 = getelementptr i8, ptr %t39, i64 %t26
  call void @olang_textcopy(ptr %t41, ptr %t28, i64 %t29)
  %t42 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t33, 1
  store { i64, ptr } %t43, ptr %l10, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v1)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = call ptr @__olang_region_make(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t54 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t53)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = load i64, ptr %l11
  %t63 = inttoptr i64 %t62 to ptr
  %t64 = call ptr @__olang_held_alloc(ptr %t63, i64 %t61)
  call void @olang_textcopy(ptr %t64, ptr %t54, i64 %t55)
  %t65 = getelementptr i8, ptr %t64, i64 %t55
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t53)
  %t67 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t64, 1
  %t71 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t72 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t71, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d269, i32 0, i32 1) }, { i64, ptr } %t72, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d270, i32 0, i32 1) }, { i64, ptr } %t69)
  store %"compiler/diagmsg:Msg" %t74, ptr %l17
  br label %bb5
bb5:
  %t75 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaCapturesItself(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 444, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 79, ptr getelementptr inbounds (<{ i64, [79 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %t31, 1
  %t36 = extractvalue { i64, ptr } %t31, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l7
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l11, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v1)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v1)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %t55, 1
  %t60 = extractvalue { i64, ptr } %t55, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 146, ptr getelementptr inbounds (<{ i64, [146 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 146, ptr getelementptr inbounds (<{ i64, [146 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l12
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t56, i64 %t57)
  %t68 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t73 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t74 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t73, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d277, i32 0, i32 1) }, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } %t71)
  store %"compiler/diagmsg:Msg" %t77, ptr %l17
  br label %bb7
bb7:
  %t78 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLambdaKeepsOuter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 732, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t31, 1
  %t37 = extractvalue { i64, ptr } %t31, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t32, 1
  %t44 = extractvalue { i64, ptr } %t32, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l7
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t36, i64 %t37)
  %t53 = getelementptr i8, ptr %t52, i64 %t37
  call void @olang_textcopy(ptr %t53, ptr %t39, i64 %t40)
  %t54 = getelementptr i8, ptr %t53, i64 %t40
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t51, 1
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t59, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d283, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } %t57, { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d284, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t62, ptr %l13
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLaneSumNarrows(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l20 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 917, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t41, 1
  %t45 = extractvalue { i64, ptr } %t41, 0
  %t46 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t50 = extractvalue { i64, ptr } %t42, 1
  %t51 = extractvalue { i64, ptr } %t42, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l9
  %t57 = inttoptr i64 %t56 to ptr
  %t58 = call ptr @__olang_held_alloc(ptr %t57, i64 %t55)
  call void @olang_textcopy(ptr %t58, ptr %t44, i64 %t45)
  %t59 = getelementptr i8, ptr %t58, i64 %t45
  call void @olang_textcopy(ptr %t59, ptr %t46, i64 %t47)
  %t60 = getelementptr i8, ptr %t59, i64 %t47
  call void @olang_textcopy(ptr %t60, ptr %t50, i64 %t51)
  %t61 = getelementptr i8, ptr %t60, i64 %t51
  call void @olang_textcopy(ptr %t61, ptr %t53, i64 %t54)
  %t62 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t58, 1
  store { i64, ptr } %t63, ptr %l14, !tbaa !27
  %t65 = call ptr @__olang_scope_hold(ptr %v2)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l15, !tbaa !24
  %t67 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t67, label %bb5, label %bb6
bb5:
  %t69 = call ptr @__olang_region_make(ptr %v2)
  %t70 = ptrtoint ptr %t69 to i64
  store i64 %t70, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = extractvalue { i64, ptr } %t71, 0
  %t77 = add i64 %t73, %t76
  %t78 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = load i64, ptr %l15
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  call void @olang_textcopy(ptr %t83, ptr %t72, i64 %t73)
  %t84 = getelementptr i8, ptr %t83, i64 %t73
  call void @olang_textcopy(ptr %t84, ptr %t75, i64 %t76)
  %t85 = getelementptr i8, ptr %t84, i64 %t76
  call void @olang_textcopy(ptr %t85, ptr %t78, i64 %t79)
  %t86 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t89 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t90 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t89, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d292, i32 0, i32 1) }, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t87)
  store %"compiler/diagmsg:Msg" %t93, ptr %l20
  br label %bb7
bb7:
  %t94 = load %"compiler/diagmsg:Msg", ptr %l20
  store %"compiler/diagmsg:Msg" %t94, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkToValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 642, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l9
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d298, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d299, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l14
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLitCompare(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 547, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d300, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l9
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d305, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d306, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l14
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralMixed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 601, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = load i64, ptr %l6
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_held_alloc(ptr %t39, i64 %t37)
  call void @olang_textcopy(ptr %t40, ptr %t11, i64 %t12)
  %t41 = getelementptr i8, ptr %t40, i64 %t12
  call void @olang_textcopy(ptr %t41, ptr %t14, i64 %t15)
  %t42 = getelementptr i8, ptr %t41, i64 %t15
  call void @olang_textcopy(ptr %t42, ptr %t17, i64 %t18)
  %t43 = getelementptr i8, ptr %t42, i64 %t18
  call void @olang_textcopy(ptr %t43, ptr %t21, i64 %t22)
  %t44 = getelementptr i8, ptr %t43, i64 %t22
  call void @olang_textcopy(ptr %t44, ptr %t24, i64 %t25)
  %t45 = getelementptr i8, ptr %t44, i64 %t25
  call void @olang_textcopy(ptr %t45, ptr %t28, i64 %t29)
  %t46 = getelementptr i8, ptr %t45, i64 %t29
  call void @olang_textcopy(ptr %t46, ptr %t31, i64 %t32)
  %t47 = getelementptr i8, ptr %t46, i64 %t32
  call void @olang_textcopy(ptr %t47, ptr %t35, i64 %t36)
  %t48 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t40, 1
  store { i64, ptr } %t49, ptr %l13, !tbaa !27
  %t51 = call ptr @__olang_scope_hold(ptr %v5)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l14, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t53, label %bb3, label %bb4
bb3:
  %t55 = call ptr @__olang_region_make(ptr %v5)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l14, !tbaa !24
  br label %bb4
bb4:
  %t58 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d310, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d310, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %a4, 1
  %t62 = extractvalue { i64, ptr } %a4, 0
  %t63 = add i64 %t59, %t62
  %t64 = load i64, ptr %l14
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = call ptr @__olang_held_alloc(ptr %t65, i64 %t63)
  call void @olang_textcopy(ptr %t66, ptr %t58, i64 %t59)
  %t67 = getelementptr i8, ptr %t66, i64 %t59
  call void @olang_textcopy(ptr %t67, ptr %t61, i64 %t62)
  %t68 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t66, 1
  %t71 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t72 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t71, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d311, i32 0, i32 1) }, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d312, i32 0, i32 1) }, { i64, ptr } %t69)
  store %"compiler/diagmsg:Msg" %t74, ptr %l19
  br label %bb5
bb5:
  %t75 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralNoFromIter(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 597, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d313, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d313, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t36 = extractvalue { i64, ptr } %t31, 1
  %t37 = extractvalue { i64, ptr } %t31, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %t32, 1
  %t44 = extractvalue { i64, ptr } %t32, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l7
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t33, i64 %t34)
  %t52 = getelementptr i8, ptr %t51, i64 %t34
  call void @olang_textcopy(ptr %t52, ptr %t36, i64 %t37)
  %t53 = getelementptr i8, ptr %t52, i64 %t37
  call void @olang_textcopy(ptr %t53, ptr %t39, i64 %t40)
  %t54 = getelementptr i8, ptr %t53, i64 %t40
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t51, 1
  %t59 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d318, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 105, ptr getelementptr inbounds (<{ i64, [105 x i8] }>, ptr @.d319, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l13
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLiteralUnique(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 598, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l3
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t32 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d322, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 58, ptr getelementptr inbounds (<{ i64, [58 x i8] }>, ptr @.d322, i32 0, i32 1) }, 0
  %t35 = extractvalue { i64, ptr } %a1, 1
  %t36 = extractvalue { i64, ptr } %a1, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d323, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d323, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l8
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t43, 1
  store { i64, ptr } %t47, ptr %l12, !tbaa !27
  %t49 = call ptr @__olang_scope_hold(ptr %v2)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l13, !tbaa !24
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t51, label %bb5, label %bb6
bb5:
  %t53 = call ptr @__olang_region_make(ptr %v2)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t56 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %t55, 1
  %t60 = extractvalue { i64, ptr } %t55, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l13
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t56, i64 %t57)
  %t68 = getelementptr i8, ptr %t67, i64 %t57
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t67, 1
  %t73 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t74 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t77 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t73, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d326, i32 0, i32 1) }, { i64, ptr } %t74, { i64, ptr } %t75, { i64, ptr } %t71)
  store %"compiler/diagmsg:Msg" %t77, ptr %l18
  br label %bb7
bb7:
  %t78 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t78, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLostLoopWrite(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca i64
  %l30 = alloca { i64, ptr }
  %l34 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 639, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  br i1 %a1, label %bb3, label %bb4
bb3:
  %t37 = call ptr @__olang_scope_hold(ptr %v1)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb5, label %bb6
bb4:
  %t41 = load i1, ptr %l2, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb5:
  %t43 = call ptr @__olang_region_make(ptr %v1)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 93, ptr getelementptr inbounds (<{ i64, [93 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l12
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t46, i64 %t47)
  %t58 = getelementptr i8, ptr %t57, i64 %t47
  call void @olang_textcopy(ptr %t58, ptr %t49, i64 %t50)
  %t59 = getelementptr i8, ptr %t58, i64 %t50
  call void @olang_textcopy(ptr %t59, ptr %t52, i64 %t53)
  %t60 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  store { i64, ptr } %t61, ptr %l11, !tbaa !27
  br label %bb14
bb7:
  %t64 = call ptr @__olang_scope_hold(ptr %v1)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l19, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t66, label %bb9, label %bb10
bb8:
  %t68 = call ptr @__olang_scope_hold(ptr %v1)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l24, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t70, label %bb11, label %bb12
bb9:
  %t72 = call ptr @__olang_region_make(ptr %v1)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t78 = extractvalue { i64, ptr } %t74, 1
  %t79 = extractvalue { i64, ptr } %t74, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load i64, ptr %l19
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_held_alloc(ptr %t85, i64 %t83)
  call void @olang_textcopy(ptr %t86, ptr %t75, i64 %t76)
  %t87 = getelementptr i8, ptr %t86, i64 %t76
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l18, !tbaa !27
  br label %bb13
bb11:
  %t93 = call ptr @__olang_region_make(ptr %v1)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l24, !tbaa !24
  br label %bb12
bb12:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t99 = extractvalue { i64, ptr } %t95, 1
  %t100 = extractvalue { i64, ptr } %t95, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = load i64, ptr %l24
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_held_alloc(ptr %t106, i64 %t104)
  call void @olang_textcopy(ptr %t107, ptr %t96, i64 %t97)
  %t108 = getelementptr i8, ptr %t107, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  call void @olang_textcopy(ptr %t109, ptr %t102, i64 %t103)
  %t110 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  store { i64, ptr } %t111, ptr %l18, !tbaa !27
  br label %bb13
bb13:
  %t114 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t114, ptr %l11, !tbaa !27
  br label %bb14
bb14:
  %t115 = load i1, ptr %l2, !tbaa !21
  br i1 %t115, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d336, i32 0, i32 1) }, ptr %l30, !tbaa !27
  br label %bb17
bb16:
  %t117 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t118 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t121 = extractvalue { i64, ptr } %t117, 1
  %t122 = extractvalue { i64, ptr } %t117, 0
  %t123 = add i64 %t119, %t122
  %t124 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d338, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d338, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t127 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t126)
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t121, i64 %t122)
  %t129 = getelementptr i8, ptr %t128, i64 %t122
  call void @olang_textcopy(ptr %t129, ptr %t124, i64 %t125)
  %t130 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t127, 1
  store { i64, ptr } %t131, ptr %l30, !tbaa !27
  br label %bb17
bb17:
  %t134 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t138 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t134, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d339, i32 0, i32 1) }, { i64, ptr } %t135, { i64, ptr } %t136, { i64, ptr } %t137)
  store %"compiler/diagmsg:Msg" %t138, ptr %l34
  br label %bb18
bb18:
  %t139 = load %"compiler/diagmsg:Msg", ptr %l34
  store %"compiler/diagmsg:Msg" %t139, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLostParamWrite(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l37 = alloca { i64, ptr }
  %l42 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 640, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = load i1, ptr %l2, !tbaa !21
  br i1 %t35, label %bb3, label %bb4
bb3:
  %t37 = call ptr @__olang_scope_hold(ptr %v1)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb5, label %bb6
bb4:
  %t41 = load i1, ptr %l1, !tbaa !21
  br i1 %t41, label %bb7, label %bb8
bb5:
  %t43 = call ptr @__olang_region_make(ptr %v1)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l12, !tbaa !24
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 106, ptr getelementptr inbounds (<{ i64, [106 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l12
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t46, i64 %t47)
  %t58 = getelementptr i8, ptr %t57, i64 %t47
  call void @olang_textcopy(ptr %t58, ptr %t49, i64 %t50)
  %t59 = getelementptr i8, ptr %t58, i64 %t50
  call void @olang_textcopy(ptr %t59, ptr %t52, i64 %t53)
  %t60 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  store { i64, ptr } %t61, ptr %l11, !tbaa !27
  br label %bb14
bb7:
  %t64 = call ptr @__olang_scope_hold(ptr %v1)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l19, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t66, label %bb9, label %bb10
bb8:
  %t68 = call ptr @__olang_scope_hold(ptr %v1)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l24, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t70, label %bb11, label %bb12
bb9:
  %t72 = call ptr @__olang_region_make(ptr %v1)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l19, !tbaa !24
  br label %bb10
bb10:
  %t74 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t78 = extractvalue { i64, ptr } %t74, 1
  %t79 = extractvalue { i64, ptr } %t74, 0
  %t80 = add i64 %t76, %t79
  %t81 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t82 = extractvalue { i64, ptr } { i64 103, ptr getelementptr inbounds (<{ i64, [103 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t83 = add i64 %t80, %t82
  %t84 = load i64, ptr %l19
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call ptr @__olang_held_alloc(ptr %t85, i64 %t83)
  call void @olang_textcopy(ptr %t86, ptr %t75, i64 %t76)
  %t87 = getelementptr i8, ptr %t86, i64 %t76
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l18, !tbaa !27
  br label %bb13
bb11:
  %t93 = call ptr @__olang_region_make(ptr %v1)
  %t94 = ptrtoint ptr %t93 to i64
  store i64 %t94, ptr %l24, !tbaa !24
  br label %bb12
bb12:
  %t95 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t96 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t99 = extractvalue { i64, ptr } %t95, 1
  %t100 = extractvalue { i64, ptr } %t95, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = load i64, ptr %l24
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_held_alloc(ptr %t106, i64 %t104)
  call void @olang_textcopy(ptr %t107, ptr %t96, i64 %t97)
  %t108 = getelementptr i8, ptr %t107, i64 %t97
  call void @olang_textcopy(ptr %t108, ptr %t99, i64 %t100)
  %t109 = getelementptr i8, ptr %t108, i64 %t100
  call void @olang_textcopy(ptr %t109, ptr %t102, i64 %t103)
  %t110 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t107, 1
  store { i64, ptr } %t111, ptr %l18, !tbaa !27
  br label %bb13
bb13:
  %t114 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t114, ptr %l11, !tbaa !27
  br label %bb14
bb14:
  %t115 = load i1, ptr %l2, !tbaa !21
  br i1 %t115, label %bb15, label %bb16
bb15:
  %t117 = call ptr @__olang_scope_hold(ptr %v1)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l31, !tbaa !24
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t119, label %bb17, label %bb18
bb16:
  %t121 = load i1, ptr %l1, !tbaa !21
  br i1 %t121, label %bb19, label %bb20
bb17:
  %t123 = call ptr @__olang_region_make(ptr %v1)
  %t124 = ptrtoint ptr %t123 to i64
  store i64 %t124, ptr %l31, !tbaa !24
  br label %bb18
bb18:
  %t125 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t126 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t129 = extractvalue { i64, ptr } %t125, 1
  %t130 = extractvalue { i64, ptr } %t125, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = load i64, ptr %l31
  %t136 = inttoptr i64 %t135 to ptr
  %t137 = call ptr @__olang_held_alloc(ptr %t136, i64 %t134)
  call void @olang_textcopy(ptr %t137, ptr %t126, i64 %t127)
  %t138 = getelementptr i8, ptr %t137, i64 %t127
  call void @olang_textcopy(ptr %t138, ptr %t129, i64 %t130)
  %t139 = getelementptr i8, ptr %t138, i64 %t130
  call void @olang_textcopy(ptr %t139, ptr %t132, i64 %t133)
  %t140 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t137, 1
  store { i64, ptr } %t141, ptr %l30, !tbaa !27
  br label %bb22
bb19:
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t146 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t149 = extractvalue { i64, ptr } %t144, 1
  %t150 = extractvalue { i64, ptr } %t144, 0
  %t151 = add i64 %t147, %t150
  %t152 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t156 = extractvalue { i64, ptr } %t145, 1
  %t157 = extractvalue { i64, ptr } %t145, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t146, i64 %t147)
  %t163 = getelementptr i8, ptr %t162, i64 %t147
  call void @olang_textcopy(ptr %t163, ptr %t149, i64 %t150)
  %t164 = getelementptr i8, ptr %t163, i64 %t150
  call void @olang_textcopy(ptr %t164, ptr %t152, i64 %t153)
  %t165 = getelementptr i8, ptr %t164, i64 %t153
  call void @olang_textcopy(ptr %t165, ptr %t156, i64 %t157)
  %t166 = getelementptr i8, ptr %t165, i64 %t157
  call void @olang_textcopy(ptr %t166, ptr %t159, i64 %t160)
  %t167 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t162, 1
  store { i64, ptr } %t168, ptr %l37, !tbaa !27
  br label %bb21
bb20:
  store { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d354, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb21
bb21:
  %t171 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t171, ptr %l30, !tbaa !27
  br label %bb22
bb22:
  %t172 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t173 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t176 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t172, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d355, i32 0, i32 1) }, { i64, ptr } %t173, { i64, ptr } %t174, { i64, ptr } %t175)
  store %"compiler/diagmsg:Msg" %t176, ptr %l42
  br label %bb23
bb23:
  %t177 = load %"compiler/diagmsg:Msg", ptr %l42
  store %"compiler/diagmsg:Msg" %t177, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMayBeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 543, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a1, 1
  %t21 = extractvalue { i64, ptr } %a1, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d358, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d358, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d359, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d359, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load i64, ptr %l5
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_held_alloc(ptr %t34, i64 %t32)
  call void @olang_textcopy(ptr %t35, ptr %t10, i64 %t11)
  %t36 = getelementptr i8, ptr %t35, i64 %t11
  call void @olang_textcopy(ptr %t36, ptr %t13, i64 %t14)
  %t37 = getelementptr i8, ptr %t36, i64 %t14
  call void @olang_textcopy(ptr %t37, ptr %t16, i64 %t17)
  %t38 = getelementptr i8, ptr %t37, i64 %t17
  call void @olang_textcopy(ptr %t38, ptr %t20, i64 %t21)
  %t39 = getelementptr i8, ptr %t38, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t35, 1
  store { i64, ptr } %t43, ptr %l11, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v4)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l12, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = call ptr @__olang_region_make(ptr %v4)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t52 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %a3, 1
  %t56 = extractvalue { i64, ptr } %a3, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = load i64, ptr %l12
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call ptr @__olang_held_alloc(ptr %t62, i64 %t60)
  call void @olang_textcopy(ptr %t63, ptr %t52, i64 %t53)
  %t64 = getelementptr i8, ptr %t63, i64 %t53
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d362, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d363, i32 0, i32 1) }, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t72, ptr %l17
  br label %bb5
bb5:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNarrowedWrite(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 541, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d364, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %t41, 1
  %t47 = extractvalue { i64, ptr } %t41, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t42, 1
  %t54 = extractvalue { i64, ptr } %t42, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = load i64, ptr %l9
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  call void @olang_textcopy(ptr %t61, ptr %t43, i64 %t44)
  %t62 = getelementptr i8, ptr %t61, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t53, i64 %t54)
  %t65 = getelementptr i8, ptr %t64, i64 %t54
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t61, 1
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d370, i32 0, i32 1) }, { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d371, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t72, ptr %l15
  br label %bb5
bb5:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLimit(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l23 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 812, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l4
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l9, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l12, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t38, 0
  store i64 %t41, ptr %l15, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l16, !tbaa !24
  %t44 = icmp sge i64 3, 0
  br i1 %t44, label %bb5, label %bb6
bb5:
  %t46 = load i64, ptr %l15, !tbaa !24
  %t47 = icmp sle i64 3, %t46
  br i1 %t47, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_558e38b2b979820_b81e4d452591bbd4)
  unreachable
bb7:
  %t49 = load i64, ptr %l15, !tbaa !24
  %t50 = load i64, ptr %l16, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_558e38b2b979820_b81e4d452591bbd4)
  unreachable
bb9:
  %t53 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l15, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 3
  %t57 = sub i64 %t55, 3
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = extractvalue { i64, ptr } %t59, 0
  %t63 = load i64, ptr %l10
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call ptr @__olang_held_alloc(ptr %t64, i64 %t62)
  call void @olang_textcopy(ptr %t65, ptr %t61, i64 %t62)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d374, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } %t67, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t72, ptr %l23
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_558e38b2b979820_b81e4d452591bbd4)
  unreachable
bb11:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l23
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotInModulePrelude(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 357, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d375, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d375, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = load i64, ptr %l4
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_held_alloc(ptr %t20, i64 %t18)
  call void @olang_textcopy(ptr %t21, ptr %t10, i64 %t11)
  %t22 = getelementptr i8, ptr %t21, i64 %t11
  call void @olang_textcopy(ptr %t22, ptr %t12, i64 %t13)
  %t23 = getelementptr i8, ptr %t22, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l9, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v3)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l10, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = call ptr @__olang_region_make(ptr %v3)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d376, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d376, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t33, 1
  %t39 = extractvalue { i64, ptr } %t33, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d377, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d377, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t45 = extractvalue { i64, ptr } %a2, 1
  %t46 = extractvalue { i64, ptr } %a2, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d378, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d378, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l10
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t35, i64 %t36)
  %t54 = getelementptr i8, ptr %t53, i64 %t36
  call void @olang_textcopy(ptr %t54, ptr %t38, i64 %t39)
  %t55 = getelementptr i8, ptr %t54, i64 %t39
  call void @olang_textcopy(ptr %t55, ptr %t41, i64 %t42)
  %t56 = getelementptr i8, ptr %t55, i64 %t42
  call void @olang_textcopy(ptr %t56, ptr %t45, i64 %t46)
  %t57 = getelementptr i8, ptr %t56, i64 %t46
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t53, 1
  %t61 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t61, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d379, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d380, i32 0, i32 1) }, { i64, ptr } %t59)
  store %"compiler/diagmsg:Msg" %t64, ptr %l16
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotTheOperator(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 258, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l6
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v5)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l13, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v5)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t49 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %a3, 1
  %t53 = extractvalue { i64, ptr } %a3, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %a4, 1
  %t60 = extractvalue { i64, ptr } %a4, 0
  %t61 = add i64 %t57, %t60
  %t62 = load i64, ptr %l13
  %t63 = inttoptr i64 %t62 to ptr
  %t64 = call ptr @__olang_held_alloc(ptr %t63, i64 %t61)
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t52, i64 %t53)
  %t66 = getelementptr i8, ptr %t65, i64 %t53
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t59, i64 %t60)
  %t68 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t64, 1
  %t71 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t72 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t71, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d386, i32 0, i32 1) }, { i64, ptr } %t72, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t74, ptr %l19
  br label %bb5
bb5:
  %t75 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteDeclareWhere(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l12 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 793, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %t7, 1
  %t15 = extractvalue { i64, ptr } %t7, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d389, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d389, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %t9, 1
  %t29 = extractvalue { i64, ptr } %t9, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a2, 1
  %t36 = extractvalue { i64, ptr } %a2, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l4
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t11, i64 %t12)
  %t44 = getelementptr i8, ptr %t43, i64 %t12
  call void @olang_textcopy(ptr %t44, ptr %t14, i64 %t15)
  %t45 = getelementptr i8, ptr %t44, i64 %t15
  call void @olang_textcopy(ptr %t45, ptr %t17, i64 %t18)
  %t46 = getelementptr i8, ptr %t45, i64 %t18
  call void @olang_textcopy(ptr %t46, ptr %t21, i64 %t22)
  %t47 = getelementptr i8, ptr %t46, i64 %t22
  call void @olang_textcopy(ptr %t47, ptr %t24, i64 %t25)
  %t48 = getelementptr i8, ptr %t47, i64 %t25
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t38, i64 %t39)
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t43, 1
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d392, i32 0, i32 1) }, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t57, ptr %l12
  br label %bb3
bb3:
  %t58 = load %"compiler/diagmsg:Msg", ptr %l12
  store %"compiler/diagmsg:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralLocal(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 473, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d394, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d395, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d395, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l5
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t11, i64 %t12)
  %t44 = getelementptr i8, ptr %t43, i64 %t12
  call void @olang_textcopy(ptr %t44, ptr %t14, i64 %t15)
  %t45 = getelementptr i8, ptr %t44, i64 %t15
  call void @olang_textcopy(ptr %t45, ptr %t17, i64 %t18)
  %t46 = getelementptr i8, ptr %t45, i64 %t18
  call void @olang_textcopy(ptr %t46, ptr %t21, i64 %t22)
  %t47 = getelementptr i8, ptr %t46, i64 %t22
  call void @olang_textcopy(ptr %t47, ptr %t24, i64 %t25)
  %t48 = getelementptr i8, ptr %t47, i64 %t25
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t38, i64 %t39)
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t43, 1
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d399, i32 0, i32 1) }, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t57, ptr %l13
  br label %bb3
bb3:
  %t58 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRange(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l5 = alloca i32
  %l6 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 474, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t12 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t15 = extractvalue { i64, ptr } %a0, 1
  %t16 = extractvalue { i64, ptr } %a0, 0
  %t17 = add i64 %t13, %t16
  %t18 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t19 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t20 = add i64 %t17, %t19
  %t22 = extractvalue { i64, ptr } %a1, 1
  %t23 = extractvalue { i64, ptr } %a1, 0
  %t24 = add i64 %t20, %t23
  %t25 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t29 = extractvalue { i64, ptr } %a2, 1
  %t30 = extractvalue { i64, ptr } %a2, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = extractvalue { i64, ptr } %a3, 1
  %t37 = extractvalue { i64, ptr } %a3, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d404, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d404, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t43 = extractvalue { i64, ptr } %a4, 1
  %t44 = extractvalue { i64, ptr } %a4, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = load i64, ptr %l6
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call ptr @__olang_held_alloc(ptr %t50, i64 %t48)
  call void @olang_textcopy(ptr %t51, ptr %t12, i64 %t13)
  %t52 = getelementptr i8, ptr %t51, i64 %t13
  call void @olang_textcopy(ptr %t52, ptr %t15, i64 %t16)
  %t53 = getelementptr i8, ptr %t52, i64 %t16
  call void @olang_textcopy(ptr %t53, ptr %t18, i64 %t19)
  %t54 = getelementptr i8, ptr %t53, i64 %t19
  call void @olang_textcopy(ptr %t54, ptr %t22, i64 %t23)
  %t55 = getelementptr i8, ptr %t54, i64 %t23
  call void @olang_textcopy(ptr %t55, ptr %t25, i64 %t26)
  %t56 = getelementptr i8, ptr %t55, i64 %t26
  call void @olang_textcopy(ptr %t56, ptr %t29, i64 %t30)
  %t57 = getelementptr i8, ptr %t56, i64 %t30
  call void @olang_textcopy(ptr %t57, ptr %t32, i64 %t33)
  %t58 = getelementptr i8, ptr %t57, i64 %t33
  call void @olang_textcopy(ptr %t58, ptr %t36, i64 %t37)
  %t59 = getelementptr i8, ptr %t58, i64 %t37
  call void @olang_textcopy(ptr %t59, ptr %t39, i64 %t40)
  %t60 = getelementptr i8, ptr %t59, i64 %t40
  call void @olang_textcopy(ptr %t60, ptr %t43, i64 %t44)
  %t61 = getelementptr i8, ptr %t60, i64 %t44
  call void @olang_textcopy(ptr %t61, ptr %t46, i64 %t47)
  %t62 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t51, 1
  %t65 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t67 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t65, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d406, i32 0, i32 1) }, { i64, ptr } %t63, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t67, ptr %l15
  br label %bb3
bb3:
  %t68 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t68, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteLiteralRangeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 475, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l5
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t11, i64 %t12)
  %t44 = getelementptr i8, ptr %t43, i64 %t12
  call void @olang_textcopy(ptr %t44, ptr %t14, i64 %t15)
  %t45 = getelementptr i8, ptr %t44, i64 %t15
  call void @olang_textcopy(ptr %t45, ptr %t17, i64 %t18)
  %t46 = getelementptr i8, ptr %t45, i64 %t18
  call void @olang_textcopy(ptr %t46, ptr %t21, i64 %t22)
  %t47 = getelementptr i8, ptr %t46, i64 %t22
  call void @olang_textcopy(ptr %t47, ptr %t24, i64 %t25)
  %t48 = getelementptr i8, ptr %t47, i64 %t25
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t38, i64 %t39)
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t43, 1
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d412, i32 0, i32 1) }, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t57, ptr %l13
  br label %bb3
bb3:
  %t58 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 382, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d413, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d413, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d414, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d414, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d415, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d415, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l5
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t11, i64 %t12)
  %t44 = getelementptr i8, ptr %t43, i64 %t12
  call void @olang_textcopy(ptr %t44, ptr %t14, i64 %t15)
  %t45 = getelementptr i8, ptr %t44, i64 %t15
  call void @olang_textcopy(ptr %t45, ptr %t17, i64 %t18)
  %t46 = getelementptr i8, ptr %t45, i64 %t18
  call void @olang_textcopy(ptr %t46, ptr %t21, i64 %t22)
  %t47 = getelementptr i8, ptr %t46, i64 %t22
  call void @olang_textcopy(ptr %t47, ptr %t24, i64 %t25)
  %t48 = getelementptr i8, ptr %t47, i64 %t25
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t38, i64 %t39)
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t43, 1
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t55, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d418, i32 0, i32 1) }, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d393, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t57, ptr %l13
  br label %bb3
bb3:
  %t58 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullableMeetsNoTrait(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 407, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d419, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d419, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l5
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v4)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l10, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v4)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t30 = extractvalue { i64, ptr } %a2, 1
  %t31 = extractvalue { i64, ptr } %a2, 0
  %t32 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = extractvalue { i64, ptr } %a1, 1
  %t37 = extractvalue { i64, ptr } %a1, 0
  %t38 = add i64 %t34, %t37
  %t39 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = load i64, ptr %l10
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call ptr @__olang_held_alloc(ptr %t43, i64 %t41)
  call void @olang_textcopy(ptr %t44, ptr %t30, i64 %t31)
  %t45 = getelementptr i8, ptr %t44, i64 %t31
  call void @olang_textcopy(ptr %t45, ptr %t32, i64 %t33)
  %t46 = getelementptr i8, ptr %t45, i64 %t33
  call void @olang_textcopy(ptr %t46, ptr %t36, i64 %t37)
  %t47 = getelementptr i8, ptr %t46, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t44, 1
  store { i64, ptr } %t49, ptr %l15, !tbaa !27
  %t51 = call ptr @__olang_scope_hold(ptr %v4)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l16, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = call ptr @__olang_region_make(ptr %v4)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t58 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %a3, 1
  %t62 = extractvalue { i64, ptr } %a3, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load i64, ptr %l16
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  call void @olang_textcopy(ptr %t69, ptr %t58, i64 %t59)
  %t70 = getelementptr i8, ptr %t69, i64 %t59
  call void @olang_textcopy(ptr %t70, ptr %t61, i64 %t62)
  %t71 = getelementptr i8, ptr %t70, i64 %t62
  call void @olang_textcopy(ptr %t71, ptr %t64, i64 %t65)
  %t72 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t69, 1
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t79 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t75, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d424, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } %t77, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t79, ptr %l21
  br label %bb7
bb7:
  %t80 = load %"compiler/diagmsg:Msg", ptr %l21
  store %"compiler/diagmsg:Msg" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePartKept(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 673, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %t41, 1
  %t47 = extractvalue { i64, ptr } %t41, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t42, 1
  %t54 = extractvalue { i64, ptr } %t42, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = load i64, ptr %l9
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  call void @olang_textcopy(ptr %t61, ptr %t43, i64 %t44)
  %t62 = getelementptr i8, ptr %t61, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t53, i64 %t54)
  %t65 = getelementptr i8, ptr %t64, i64 %t54
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t61, 1
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d431, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d432, i32 0, i32 1) }, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t72, ptr %l15
  br label %bb5
bb5:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 312, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t39 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d435, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d435, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %a2, 1
  %t43 = extractvalue { i64, ptr } %a2, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d436, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d436, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %a3, 1
  %t50 = extractvalue { i64, ptr } %a3, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l11
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t42, i64 %t43)
  %t59 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t59, ptr %t45, i64 %t46)
  %t60 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d438, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d439, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l17
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolPrivate(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 313, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l5
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l11, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v4)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l12, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v4)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t48 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %a3, 1
  %t52 = extractvalue { i64, ptr } %a3, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d444, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d444, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l12
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d445, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d446, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l17
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadMaybeNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 552, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l5
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l10, !tbaa !27
  store { i64, ptr } %a3, ptr %l11, !tbaa !27
  %t36 = call ptr @__olang_scope_hold(ptr %v4)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l12, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t38, label %bb3, label %bb4
bb3:
  %t40 = call ptr @__olang_region_make(ptr %v4)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t43 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 76, ptr getelementptr inbounds (<{ i64, [76 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %a2, 1
  %t47 = extractvalue { i64, ptr } %a2, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load i64, ptr %l12
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call ptr @__olang_held_alloc(ptr %t53, i64 %t51)
  call void @olang_textcopy(ptr %t54, ptr %t43, i64 %t44)
  %t55 = getelementptr i8, ptr %t54, i64 %t44
  call void @olang_textcopy(ptr %t55, ptr %t46, i64 %t47)
  %t56 = getelementptr i8, ptr %t55, i64 %t47
  call void @olang_textcopy(ptr %t56, ptr %t49, i64 %t50)
  %t57 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t54, 1
  %t60 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t61 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v3, ptr %v4, ptr %v4, i32 %t60, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d452, i32 0, i32 1) }, { i64, ptr } %t61, { i64, ptr } %t62, { i64, ptr } %t58)
  store %"compiler/diagmsg:Msg" %t64, ptr %l17
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyCopyArg(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 376, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l5
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l10, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l11, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v4)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t42 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %a2, 1
  %t46 = extractvalue { i64, ptr } %a2, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d456, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d456, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l11
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  %t59 = call ptr @__olang_scope_hold(ptr %v4)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l16, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t61, label %bb5, label %bb6
bb5:
  %t63 = call ptr @__olang_region_make(ptr %v4)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t66 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %a3, 1
  %t70 = extractvalue { i64, ptr } %a3, 0
  %t71 = add i64 %t67, %t70
  %t72 = load i64, ptr %l16
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_held_alloc(ptr %t73, i64 %t71)
  call void @olang_textcopy(ptr %t74, ptr %t66, i64 %t67)
  %t75 = getelementptr i8, ptr %t74, i64 %t67
  call void @olang_textcopy(ptr %t75, ptr %t69, i64 %t70)
  %t76 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  %t79 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t80 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t83 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t79, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d458, i32 0, i32 1) }, { i64, ptr } %t80, { i64, ptr } %t81, { i64, ptr } %t77)
  store %"compiler/diagmsg:Msg" %t83, ptr %l21
  br label %bb7
bb7:
  %t84 = load %"compiler/diagmsg:Msg", ptr %l21
  store %"compiler/diagmsg:Msg" %t84, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyFuncValue(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 379, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } %a0, 1
  %t10 = extractvalue { i64, ptr } %a0, 0
  %t11 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l4
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l8, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v3)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l9, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v3)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t28 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d460, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d460, i32 0, i32 1) }, 0
  %t31 = extractvalue { i64, ptr } %a1, 1
  %t32 = extractvalue { i64, ptr } %a1, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load i64, ptr %l9
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = call ptr @__olang_held_alloc(ptr %t38, i64 %t36)
  call void @olang_textcopy(ptr %t39, ptr %t28, i64 %t29)
  %t40 = getelementptr i8, ptr %t39, i64 %t29
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t39, 1
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l14, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = call ptr @__olang_region_make(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t52 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %a2, 1
  %t56 = extractvalue { i64, ptr } %a2, 0
  %t57 = add i64 %t53, %t56
  %t58 = load i64, ptr %l14
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t52, i64 %t53)
  %t61 = getelementptr i8, ptr %t60, i64 %t53
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d463, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t67, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t69, ptr %l19
  br label %bb7
bb7:
  %t70 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadOnlyRefKept(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 375, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t42 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %a2, 1
  %t46 = extractvalue { i64, ptr } %a2, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l10
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t59, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d469, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } %t57, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d470, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t62, ptr %l15
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReadUnassigned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 763, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d471, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d471, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d472, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d472, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l4
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v3)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l9, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v3)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t33 = extractvalue { i64, ptr } %a1, 1
  %t34 = extractvalue { i64, ptr } %a1, 0
  %t35 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d473, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d473, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load i64, ptr %l9
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_held_alloc(ptr %t39, i64 %t37)
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  store { i64, ptr } %t43, ptr %l13, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l14, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = call ptr @__olang_region_make(ptr %v3)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t52 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %a2, 1
  %t56 = extractvalue { i64, ptr } %a2, 0
  %t57 = add i64 %t53, %t56
  %t58 = load i64, ptr %l14
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t52, i64 %t53)
  %t61 = getelementptr i8, ptr %t60, i64 %t53
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t69 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d475, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } %t67, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t69, ptr %l19
  br label %bb7
bb7:
  %t70 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eReflDescNoMember(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 895, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d478, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d478, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t42 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d479, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d479, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %a2, 1
  %t46 = extractvalue { i64, ptr } %a2, 0
  %t47 = add i64 %t43, %t46
  %t48 = load i64, ptr %l10
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call ptr @__olang_held_alloc(ptr %t49, i64 %t47)
  call void @olang_textcopy(ptr %t50, ptr %t42, i64 %t43)
  %t51 = getelementptr i8, ptr %t50, i64 %t43
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  %t55 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d480, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t58, ptr %l15
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftProven(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store i32 492, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d481, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d481, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = call i64 @__olang_fmt_i64(ptr null, i64 %a2)
  %t29 = add i64 %t26, %t28
  %t30 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = call i64 @__olang_fmt_i64(ptr null, i64 %t10)
  %t35 = add i64 %t32, %t34
  %t36 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = load i64, ptr %l5
  %t40 = inttoptr i64 %t39 to ptr
  %t41 = call ptr @__olang_held_alloc(ptr %t40, i64 %t38)
  call void @olang_textcopy(ptr %t41, ptr %t11, i64 %t12)
  %t42 = getelementptr i8, ptr %t41, i64 %t12
  call void @olang_textcopy(ptr %t42, ptr %t14, i64 %t15)
  %t43 = getelementptr i8, ptr %t42, i64 %t15
  call void @olang_textcopy(ptr %t43, ptr %t17, i64 %t18)
  %t44 = getelementptr i8, ptr %t43, i64 %t18
  call void @olang_textcopy(ptr %t44, ptr %t21, i64 %t22)
  %t45 = getelementptr i8, ptr %t44, i64 %t22
  call void @olang_textcopy(ptr %t45, ptr %t24, i64 %t25)
  %t46 = getelementptr i8, ptr %t45, i64 %t25
  %t47 = call i64 @__olang_fmt_i64(ptr %t46, i64 %a2)
  %t48 = getelementptr i8, ptr %t46, i64 %t28
  call void @olang_textcopy(ptr %t48, ptr %t30, i64 %t31)
  %t49 = getelementptr i8, ptr %t48, i64 %t31
  %t50 = call i64 @__olang_fmt_i64(ptr %t49, i64 %t10)
  %t51 = getelementptr i8, ptr %t49, i64 %t34
  call void @olang_textcopy(ptr %t51, ptr %t36, i64 %t37)
  %t52 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t41, 1
  store { i64, ptr } %t53, ptr %l12, !tbaa !27
  %t55 = call ptr @__olang_scope_hold(ptr %v2)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l13, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t57, label %bb3, label %bb4
bb3:
  %t59 = call ptr @__olang_region_make(ptr %v2)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = sub i64 %t61, 1
  %t64 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t67 = call i64 @__olang_fmt_i64(ptr null, i64 %t63)
  %t68 = add i64 %t65, %t67
  %t69 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t72 = load i64, ptr %l13
  %t73 = inttoptr i64 %t72 to ptr
  %t74 = call ptr @__olang_held_alloc(ptr %t73, i64 %t71)
  call void @olang_textcopy(ptr %t74, ptr %t64, i64 %t65)
  %t75 = getelementptr i8, ptr %t74, i64 %t65
  %t76 = call i64 @__olang_fmt_i64(ptr %t75, i64 %t63)
  %t77 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t77, ptr %t69, i64 %t70)
  %t78 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t74, 1
  %t81 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t82 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t84 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t81, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d488, i32 0, i32 1) }, { i64, ptr } %t82, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d489, i32 0, i32 1) }, { i64, ptr } %t79)
  store %"compiler/diagmsg:Msg" %t84, ptr %l19
  br label %bb5
bb5:
  %t85 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnResultAsRef(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 723, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d491, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t9, i64 %t10)
  %t25 = getelementptr i8, ptr %t24, i64 %t10
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t15, i64 %t16)
  %t27 = getelementptr i8, ptr %t26, i64 %t16
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l10, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d492, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d492, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %a2, 1
  %t43 = extractvalue { i64, ptr } %a2, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d493, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d493, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %a3, 1
  %t50 = extractvalue { i64, ptr } %a3, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l11
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t42, i64 %t43)
  %t59 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t59, ptr %t45, i64 %t46)
  %t60 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t65, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d495, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d496, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l17
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetForeignMode(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 30, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = extractvalue { i64, ptr } %t37, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l9
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d501, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } %t53, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d502, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t58, ptr %l14
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l17 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 35, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l2
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l6, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v1)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l7, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v1)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t33 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d505, i32 0, i32 1) })
  store i1 %t33, ptr %l10
  br label %bb5
bb5:
  %t34 = load i1, ptr %l10, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d506, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb8
bb7:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t36 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t39 = extractvalue { i64, ptr } %t35, 1
  %t40 = extractvalue { i64, ptr } %t35, 0
  %t41 = add i64 %t37, %t40
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  %t44 = add i64 %t41, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t36, i64 %t37)
  %t46 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t46, ptr %t39, i64 %t40)
  %t47 = getelementptr i8, ptr %t46, i64 %t40
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  store { i64, ptr } %t49, ptr %l11, !tbaa !27
  br label %bb8
bb8:
  %t52 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l7
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = getelementptr i8, ptr %t60, i64 %t54
  call void @olang_textcopy(ptr %t61, ptr %t55, i64 %t56)
  %t62 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d510, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d511, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l17
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMemberMissing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 162, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %a1, 1
  %t18 = extractvalue { i64, ptr } %a1, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l4
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t11, i64 %t12)
  %t33 = getelementptr i8, ptr %t32, i64 %t12
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t17, i64 %t18)
  %t35 = getelementptr i8, ptr %t34, i64 %t18
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t24, i64 %t25)
  %t37 = getelementptr i8, ptr %t36, i64 %t25
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t51 = extractvalue { i64, ptr } %t47, 1
  %t52 = extractvalue { i64, ptr } %t47, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = load i64, ptr %l11
  %t58 = inttoptr i64 %t57 to ptr
  %t59 = call ptr @__olang_held_alloc(ptr %t58, i64 %t56)
  call void @olang_textcopy(ptr %t59, ptr %t48, i64 %t49)
  %t60 = getelementptr i8, ptr %t59, i64 %t49
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t59, 1
  %t65 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d517, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d518, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l16
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l16
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMethodBeyond(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l24 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 933, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %t8, 1
  %t18 = extractvalue { i64, ptr } %t8, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d520, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d520, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l6
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l12, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v5)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l13, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v5)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l13, !tbaa !24
  br label %bb4
bb4:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t46 = extractvalue { i64, ptr } %a3, 1
  %t47 = extractvalue { i64, ptr } %a3, 0
  %t48 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t52 = extractvalue { i64, ptr } %t44, 1
  %t53 = extractvalue { i64, ptr } %t44, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t58 = load i64, ptr %l13
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = call ptr @__olang_held_alloc(ptr %t59, i64 %t57)
  call void @olang_textcopy(ptr %t60, ptr %t46, i64 %t47)
  %t61 = getelementptr i8, ptr %t60, i64 %t47
  call void @olang_textcopy(ptr %t61, ptr %t48, i64 %t49)
  %t62 = getelementptr i8, ptr %t61, i64 %t49
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = getelementptr i8, ptr %t62, i64 %t53
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t60, 1
  store { i64, ptr } %t65, ptr %l18, !tbaa !27
  %t67 = call ptr @__olang_scope_hold(ptr %v5)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l19, !tbaa !24
  %t69 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t69, label %bb5, label %bb6
bb5:
  %t71 = call ptr @__olang_region_make(ptr %v5)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t74 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %a4, 1
  %t78 = extractvalue { i64, ptr } %a4, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = load i64, ptr %l19
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = call ptr @__olang_held_alloc(ptr %t84, i64 %t82)
  call void @olang_textcopy(ptr %t85, ptr %t74, i64 %t75)
  %t86 = getelementptr i8, ptr %t85, i64 %t75
  call void @olang_textcopy(ptr %t86, ptr %t77, i64 %t78)
  %t87 = getelementptr i8, ptr %t86, i64 %t78
  call void @olang_textcopy(ptr %t87, ptr %t80, i64 %t81)
  %t88 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t85, 1
  %t91 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t92 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t95 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t91, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d525, i32 0, i32 1) }, { i64, ptr } %t92, { i64, ptr } %t93, { i64, ptr } %t89)
  store %"compiler/diagmsg:Msg" %t95, ptr %l24
  br label %bb7
bb7:
  %t96 = load %"compiler/diagmsg:Msg", ptr %l24
  store %"compiler/diagmsg:Msg" %t96, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMethodBeyondField(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 934, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %a0, 1
  %t12 = extractvalue { i64, ptr } %a0, 0
  %t13 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t15 = add i64 %t12, %t14
  %t17 = extractvalue { i64, ptr } %t8, 1
  %t18 = extractvalue { i64, ptr } %t8, 0
  %t19 = add i64 %t15, %t18
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  %t22 = add i64 %t19, %t21
  %t24 = extractvalue { i64, ptr } %a2, 1
  %t25 = extractvalue { i64, ptr } %a2, 0
  %t26 = add i64 %t22, %t25
  %t27 = load i64, ptr %l5
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_held_alloc(ptr %t28, i64 %t26)
  call void @olang_textcopy(ptr %t29, ptr %t11, i64 %t12)
  %t30 = getelementptr i8, ptr %t29, i64 %t12
  call void @olang_textcopy(ptr %t30, ptr %t13, i64 %t14)
  %t31 = getelementptr i8, ptr %t30, i64 %t14
  call void @olang_textcopy(ptr %t31, ptr %t17, i64 %t18)
  %t32 = getelementptr i8, ptr %t31, i64 %t18
  call void @olang_textcopy(ptr %t32, ptr %t20, i64 %t21)
  %t33 = getelementptr i8, ptr %t32, i64 %t21
  call void @olang_textcopy(ptr %t33, ptr %t24, i64 %t25)
  %t34 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t29, 1
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t37 = call ptr @__olang_scope_hold(ptr %v4)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l12, !tbaa !24
  %t39 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t39, label %bb3, label %bb4
bb3:
  %t41 = call ptr @__olang_region_make(ptr %v4)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t48 = extractvalue { i64, ptr } %a3, 1
  %t49 = extractvalue { i64, ptr } %a3, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t55 = extractvalue { i64, ptr } %t44, 1
  %t56 = extractvalue { i64, ptr } %t44, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d530, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d530, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = load i64, ptr %l12
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call ptr @__olang_held_alloc(ptr %t62, i64 %t60)
  call void @olang_textcopy(ptr %t63, ptr %t45, i64 %t46)
  %t64 = getelementptr i8, ptr %t63, i64 %t46
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  call void @olang_textcopy(ptr %t65, ptr %t51, i64 %t52)
  %t66 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t66, ptr %t55, i64 %t56)
  %t67 = getelementptr i8, ptr %t66, i64 %t56
  call void @olang_textcopy(ptr %t67, ptr %t58, i64 %t59)
  %t68 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t63, 1
  %t71 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t72 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t74 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t71, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d531, i32 0, i32 1) }, { i64, ptr } %t72, { i64, ptr } %t69, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d532, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t74, ptr %l18
  br label %bb5
bb5:
  %t75 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t75, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitMethodEffect(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l27 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store i32 932, ptr %l5
  %t1 = call ptr @__olang_scope_hold(ptr %v5)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v5)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t7, 1
  %t15 = extractvalue { i64, ptr } %t7, 0
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d533, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d533, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %t8, 1
  %t21 = extractvalue { i64, ptr } %t8, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d534, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d534, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d535, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d535, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t34 = extractvalue { i64, ptr } %t10, 1
  %t35 = extractvalue { i64, ptr } %t10, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d533, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d533, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = extractvalue { i64, ptr } %t11, 1
  %t42 = extractvalue { i64, ptr } %t11, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d536, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d536, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = extractvalue { i64, ptr } %t12, 1
  %t49 = extractvalue { i64, ptr } %t12, 0
  %t50 = add i64 %t46, %t49
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = load i64, ptr %l6
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = call ptr @__olang_held_alloc(ptr %t55, i64 %t53)
  call void @olang_textcopy(ptr %t56, ptr %t14, i64 %t15)
  %t57 = getelementptr i8, ptr %t56, i64 %t15
  call void @olang_textcopy(ptr %t57, ptr %t16, i64 %t17)
  %t58 = getelementptr i8, ptr %t57, i64 %t17
  call void @olang_textcopy(ptr %t58, ptr %t20, i64 %t21)
  %t59 = getelementptr i8, ptr %t58, i64 %t21
  call void @olang_textcopy(ptr %t59, ptr %t23, i64 %t24)
  %t60 = getelementptr i8, ptr %t59, i64 %t24
  call void @olang_textcopy(ptr %t60, ptr %t27, i64 %t28)
  %t61 = getelementptr i8, ptr %t60, i64 %t28
  call void @olang_textcopy(ptr %t61, ptr %t30, i64 %t31)
  %t62 = getelementptr i8, ptr %t61, i64 %t31
  call void @olang_textcopy(ptr %t62, ptr %t34, i64 %t35)
  %t63 = getelementptr i8, ptr %t62, i64 %t35
  call void @olang_textcopy(ptr %t63, ptr %t37, i64 %t38)
  %t64 = getelementptr i8, ptr %t63, i64 %t38
  call void @olang_textcopy(ptr %t64, ptr %t41, i64 %t42)
  %t65 = getelementptr i8, ptr %t64, i64 %t42
  call void @olang_textcopy(ptr %t65, ptr %t44, i64 %t45)
  %t66 = getelementptr i8, ptr %t65, i64 %t45
  call void @olang_textcopy(ptr %t66, ptr %t48, i64 %t49)
  %t67 = getelementptr i8, ptr %t66, i64 %t49
  call void @olang_textcopy(ptr %t67, ptr %t51, i64 %t52)
  %t68 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t56, 1
  store { i64, ptr } %t69, ptr %l15, !tbaa !27
  %t71 = call ptr @__olang_scope_hold(ptr %v5)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l16, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t73, label %bb3, label %bb4
bb3:
  %t75 = call ptr @__olang_region_make(ptr %v5)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l16, !tbaa !24
  br label %bb4
bb4:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t78 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d538, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d538, i32 0, i32 1) }, 0
  %t81 = extractvalue { i64, ptr } %t77, 1
  %t82 = extractvalue { i64, ptr } %t77, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load i64, ptr %l16
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call ptr @__olang_held_alloc(ptr %t88, i64 %t86)
  call void @olang_textcopy(ptr %t89, ptr %t78, i64 %t79)
  %t90 = getelementptr i8, ptr %t89, i64 %t79
  call void @olang_textcopy(ptr %t90, ptr %t81, i64 %t82)
  %t91 = getelementptr i8, ptr %t90, i64 %t82
  call void @olang_textcopy(ptr %t91, ptr %t84, i64 %t85)
  %t92 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t89, 1
  store { i64, ptr } %t93, ptr %l20, !tbaa !27
  %t95 = call ptr @__olang_scope_hold(ptr %v5)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l21, !tbaa !24
  %t97 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t97, label %bb5, label %bb6
bb5:
  %t99 = call ptr @__olang_region_make(ptr %v5)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t101 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t103 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d540, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d540, i32 0, i32 1) }, 0
  %t106 = extractvalue { i64, ptr } %t101, 1
  %t107 = extractvalue { i64, ptr } %t101, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t113 = extractvalue { i64, ptr } %t102, 1
  %t114 = extractvalue { i64, ptr } %t102, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = load i64, ptr %l21
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call ptr @__olang_held_alloc(ptr %t120, i64 %t118)
  call void @olang_textcopy(ptr %t121, ptr %t103, i64 %t104)
  %t122 = getelementptr i8, ptr %t121, i64 %t104
  call void @olang_textcopy(ptr %t122, ptr %t106, i64 %t107)
  %t123 = getelementptr i8, ptr %t122, i64 %t107
  call void @olang_textcopy(ptr %t123, ptr %t109, i64 %t110)
  %t124 = getelementptr i8, ptr %t123, i64 %t110
  call void @olang_textcopy(ptr %t124, ptr %t113, i64 %t114)
  %t125 = getelementptr i8, ptr %t124, i64 %t114
  call void @olang_textcopy(ptr %t125, ptr %t116, i64 %t117)
  %t126 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t121, 1
  %t129 = load i32, ptr %l5, !range !{i32 0, i32 949}
  %t130 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t133 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v5, ptr %v5, ptr %v5, ptr %v5, ptr %v5, i32 %t129, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d543, i32 0, i32 1) }, { i64, ptr } %t130, { i64, ptr } %t131, { i64, ptr } %t127)
  store %"compiler/diagmsg:Msg" %t133, ptr %l27
  br label %bb7
bb7:
  %t134 = load %"compiler/diagmsg:Msg", ptr %l27
  store %"compiler/diagmsg:Msg" %t134, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeDefaultUnmet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l22 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 218, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d544, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d544, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %t7, 1
  %t14 = extractvalue { i64, ptr } %t7, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d545, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d545, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %t8, 1
  %t21 = extractvalue { i64, ptr } %t8, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d546, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t9, 1
  %t28 = extractvalue { i64, ptr } %t9, 0
  %t29 = add i64 %t25, %t28
  %t30 = load i64, ptr %l4
  %t31 = inttoptr i64 %t30 to ptr
  %t32 = call ptr @__olang_held_alloc(ptr %t31, i64 %t29)
  call void @olang_textcopy(ptr %t32, ptr %t10, i64 %t11)
  %t33 = getelementptr i8, ptr %t32, i64 %t11
  call void @olang_textcopy(ptr %t33, ptr %t13, i64 %t14)
  %t34 = getelementptr i8, ptr %t33, i64 %t14
  call void @olang_textcopy(ptr %t34, ptr %t16, i64 %t17)
  %t35 = getelementptr i8, ptr %t34, i64 %t17
  call void @olang_textcopy(ptr %t35, ptr %t20, i64 %t21)
  %t36 = getelementptr i8, ptr %t35, i64 %t21
  call void @olang_textcopy(ptr %t36, ptr %t23, i64 %t24)
  %t37 = getelementptr i8, ptr %t36, i64 %t24
  call void @olang_textcopy(ptr %t37, ptr %t27, i64 %t28)
  %t38 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t32, 1
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v3)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t43, label %bb3, label %bb4
bb3:
  %t45 = call ptr @__olang_region_make(ptr %v3)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t47 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t49 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d547, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d547, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d548, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d548, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t48, 1
  %t60 = extractvalue { i64, ptr } %t48, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d549, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d549, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l11
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t49, i64 %t50)
  %t68 = getelementptr i8, ptr %t67, i64 %t50
  call void @olang_textcopy(ptr %t68, ptr %t52, i64 %t53)
  %t69 = getelementptr i8, ptr %t68, i64 %t53
  call void @olang_textcopy(ptr %t69, ptr %t55, i64 %t56)
  %t70 = getelementptr i8, ptr %t69, i64 %t56
  call void @olang_textcopy(ptr %t70, ptr %t59, i64 %t60)
  %t71 = getelementptr i8, ptr %t70, i64 %t60
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t67, 1
  store { i64, ptr } %t73, ptr %l16, !tbaa !27
  %t75 = call ptr @__olang_scope_hold(ptr %v3)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l17, !tbaa !24
  %t77 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t77, label %bb5, label %bb6
bb5:
  %t79 = call ptr @__olang_region_make(ptr %v3)
  %t80 = ptrtoint ptr %t79 to i64
  store i64 %t80, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t82 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t85 = extractvalue { i64, ptr } %t81, 1
  %t86 = extractvalue { i64, ptr } %t81, 0
  %t87 = add i64 %t83, %t86
  %t88 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = load i64, ptr %l17
  %t92 = inttoptr i64 %t91 to ptr
  %t93 = call ptr @__olang_held_alloc(ptr %t92, i64 %t90)
  call void @olang_textcopy(ptr %t93, ptr %t82, i64 %t83)
  %t94 = getelementptr i8, ptr %t93, i64 %t83
  call void @olang_textcopy(ptr %t94, ptr %t85, i64 %t86)
  %t95 = getelementptr i8, ptr %t94, i64 %t86
  call void @olang_textcopy(ptr %t95, ptr %t88, i64 %t89)
  %t96 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t93, 1
  %t99 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t100 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t103 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t99, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, { i64, ptr } %t100, { i64, ptr } %t101, { i64, ptr } %t97)
  store %"compiler/diagmsg:Msg" %t103, ptr %l22
  br label %bb7
bb7:
  %t104 = load %"compiler/diagmsg:Msg", ptr %l22
  store %"compiler/diagmsg:Msg" %t104, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeVarNotInferable(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 215, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d553, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d553, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d554, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d554, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d555, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d555, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d556, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d556, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d557, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d557, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l9
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t59, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d558, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d559, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l14
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnionMemberNoField(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 948, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %t37, 1
  %t43 = extractvalue { i64, ptr } %t37, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %t38, 1
  %t50 = extractvalue { i64, ptr } %t38, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l9
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t42, i64 %t43)
  %t59 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t59, ptr %t45, i64 %t46)
  %t60 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t65, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d565, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d566, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l15
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueAfter(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 284, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d570, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 77, ptr getelementptr inbounds (<{ i64, [77 x i8] }>, ptr @.d570, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d571, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d571, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l9
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t59, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d572, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } %t57, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t62, ptr %l14
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueAlias(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l21 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 293, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d573, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d573, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t43 = extractvalue { i64, ptr } %a1, 1
  %t44 = extractvalue { i64, ptr } %a1, 0
  %t45 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t48 = load i64, ptr %l10
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call ptr @__olang_held_alloc(ptr %t49, i64 %t47)
  call void @olang_textcopy(ptr %t50, ptr %t43, i64 %t44)
  %t51 = getelementptr i8, ptr %t50, i64 %t44
  call void @olang_textcopy(ptr %t51, ptr %t45, i64 %t46)
  %t52 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  store { i64, ptr } %t53, ptr %l14, !tbaa !27
  %t55 = call ptr @__olang_scope_hold(ptr %v3)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l15, !tbaa !24
  %t57 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t57, label %bb5, label %bb6
bb5:
  %t59 = call ptr @__olang_region_make(ptr %v3)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t63 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d577, i32 0, i32 1) }, 1
  %t64 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d577, i32 0, i32 1) }, 0
  %t66 = extractvalue { i64, ptr } %t61, 1
  %t67 = extractvalue { i64, ptr } %t61, 0
  %t68 = add i64 %t64, %t67
  %t69 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t70 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t71 = add i64 %t68, %t70
  %t73 = extractvalue { i64, ptr } %t62, 1
  %t74 = extractvalue { i64, ptr } %t62, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d579, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d579, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = load i64, ptr %l15
  %t80 = inttoptr i64 %t79 to ptr
  %t81 = call ptr @__olang_held_alloc(ptr %t80, i64 %t78)
  call void @olang_textcopy(ptr %t81, ptr %t63, i64 %t64)
  %t82 = getelementptr i8, ptr %t81, i64 %t64
  call void @olang_textcopy(ptr %t82, ptr %t66, i64 %t67)
  %t83 = getelementptr i8, ptr %t82, i64 %t67
  call void @olang_textcopy(ptr %t83, ptr %t69, i64 %t70)
  %t84 = getelementptr i8, ptr %t83, i64 %t70
  call void @olang_textcopy(ptr %t84, ptr %t73, i64 %t74)
  %t85 = getelementptr i8, ptr %t84, i64 %t74
  call void @olang_textcopy(ptr %t85, ptr %t76, i64 %t77)
  %t86 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t81, 1
  %t89 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t90 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t89, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d580, i32 0, i32 1) }, { i64, ptr } %t90, { i64, ptr } %t91, { i64, ptr } %t87)
  store %"compiler/diagmsg:Msg" %t93, ptr %l21
  br label %bb7
bb7:
  %t94 = load %"compiler/diagmsg:Msg", ptr %l21
  store %"compiler/diagmsg:Msg" %t94, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l19 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 283, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d581, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d581, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t14 = load i64, ptr %l3
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = call ptr @__olang_held_alloc(ptr %t15, i64 %t13)
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t11, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t16, 1
  store { i64, ptr } %t19, ptr %l7, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v2)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l8, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = call ptr @__olang_region_make(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t29 = extractvalue { i64, ptr } %a1, 1
  %t30 = extractvalue { i64, ptr } %a1, 0
  %t31 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d582, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d582, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = load i64, ptr %l8
  %t35 = inttoptr i64 %t34 to ptr
  %t36 = call ptr @__olang_held_alloc(ptr %t35, i64 %t33)
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = getelementptr i8, ptr %t36, i64 %t30
  call void @olang_textcopy(ptr %t37, ptr %t31, i64 %t32)
  %t38 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  store { i64, ptr } %t39, ptr %l12, !tbaa !27
  %t41 = call ptr @__olang_scope_hold(ptr %v2)
  %t42 = ptrtoint ptr %t41 to i64
  store i64 %t42, ptr %l13, !tbaa !24
  %t43 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t43, label %bb5, label %bb6
bb5:
  %t45 = call ptr @__olang_region_make(ptr %v2)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t47 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t49 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d583, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d583, i32 0, i32 1) }, 0
  %t52 = extractvalue { i64, ptr } %t47, 1
  %t53 = extractvalue { i64, ptr } %t47, 0
  %t54 = add i64 %t50, %t53
  %t55 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d584, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d584, i32 0, i32 1) }, 0
  %t57 = add i64 %t54, %t56
  %t59 = extractvalue { i64, ptr } %t48, 1
  %t60 = extractvalue { i64, ptr } %t48, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d585, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d585, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = load i64, ptr %l13
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call ptr @__olang_held_alloc(ptr %t66, i64 %t64)
  call void @olang_textcopy(ptr %t67, ptr %t49, i64 %t50)
  %t68 = getelementptr i8, ptr %t67, i64 %t50
  call void @olang_textcopy(ptr %t68, ptr %t52, i64 %t53)
  %t69 = getelementptr i8, ptr %t68, i64 %t53
  call void @olang_textcopy(ptr %t69, ptr %t55, i64 %t56)
  %t70 = getelementptr i8, ptr %t69, i64 %t56
  call void @olang_textcopy(ptr %t70, ptr %t59, i64 %t60)
  %t71 = getelementptr i8, ptr %t70, i64 %t60
  call void @olang_textcopy(ptr %t71, ptr %t62, i64 %t63)
  %t72 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t67, 1
  %t75 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t79 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t75, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d586, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } %t77, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t79, ptr %l19
  br label %bb7
bb7:
  %t80 = load %"compiler/diagmsg:Msg", ptr %l19
  store %"compiler/diagmsg:Msg" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueFill(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 285, ptr %l1
  %t1 = call ptr @__olang_scope_hold(ptr %v1)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l2, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l2, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d587, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d587, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d588, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d588, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d589, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d589, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l2
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l7, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v1)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l8, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v1)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d590, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d590, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d591, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d591, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t54 = extractvalue { i64, ptr } %t42, 1
  %t55 = extractvalue { i64, ptr } %t42, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d592, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d592, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = extractvalue { i64, ptr } %t43, 1
  %t62 = extractvalue { i64, ptr } %t43, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d593, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d593, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load i64, ptr %l8
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  call void @olang_textcopy(ptr %t69, ptr %t44, i64 %t45)
  %t70 = getelementptr i8, ptr %t69, i64 %t45
  call void @olang_textcopy(ptr %t70, ptr %t47, i64 %t48)
  %t71 = getelementptr i8, ptr %t70, i64 %t48
  call void @olang_textcopy(ptr %t71, ptr %t50, i64 %t51)
  %t72 = getelementptr i8, ptr %t71, i64 %t51
  call void @olang_textcopy(ptr %t72, ptr %t54, i64 %t55)
  %t73 = getelementptr i8, ptr %t72, i64 %t55
  call void @olang_textcopy(ptr %t73, ptr %t57, i64 %t58)
  %t74 = getelementptr i8, ptr %t73, i64 %t58
  call void @olang_textcopy(ptr %t74, ptr %t61, i64 %t62)
  %t75 = getelementptr i8, ptr %t74, i64 %t62
  call void @olang_textcopy(ptr %t75, ptr %t64, i64 %t65)
  %t76 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t69, 1
  %t79 = load i32, ptr %l1, !range !{i32 0, i32 949}
  %t80 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t79, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d594, i32 0, i32 1) }, { i64, ptr } %t80, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d595, i32 0, i32 1) }, { i64, ptr } %t77)
  store %"compiler/diagmsg:Msg" %t82, ptr %l15
  br label %bb5
bb5:
  %t83 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueImmutPart(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 281, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = extractvalue { i64, ptr } %t7, 0
  %t12 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d596, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d596, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a0, 1
  %t17 = extractvalue { i64, ptr } %a0, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d597, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d597, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t38 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d598, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d598, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %t37, 1
  %t42 = extractvalue { i64, ptr } %t37, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d599, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d599, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = load i64, ptr %l9
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = call ptr @__olang_held_alloc(ptr %t48, i64 %t46)
  call void @olang_textcopy(ptr %t49, ptr %t38, i64 %t39)
  %t50 = getelementptr i8, ptr %t49, i64 %t39
  call void @olang_textcopy(ptr %t50, ptr %t41, i64 %t42)
  %t51 = getelementptr i8, ptr %t50, i64 %t42
  call void @olang_textcopy(ptr %t51, ptr %t44, i64 %t45)
  %t52 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t55 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t58 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t55, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d600, i32 0, i32 1) }, { i64, ptr } %t56, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d601, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t58, ptr %l14
  br label %bb5
bb5:
  %t59 = load %"compiler/diagmsg:Msg", ptr %l14
  store %"compiler/diagmsg:Msg" %t59, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueLentHere(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l18 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i32 292, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d602, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d602, i32 0, i32 1) }, 0
  %t11 = extractvalue { i64, ptr } %t7, 1
  %t12 = extractvalue { i64, ptr } %t7, 0
  %t13 = add i64 %t9, %t12
  %t14 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d603, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 55, ptr getelementptr inbounds (<{ i64, [55 x i8] }>, ptr @.d603, i32 0, i32 1) }, 0
  %t16 = add i64 %t13, %t15
  %t17 = load i64, ptr %l3
  %t18 = inttoptr i64 %t17 to ptr
  %t19 = call ptr @__olang_held_alloc(ptr %t18, i64 %t16)
  call void @olang_textcopy(ptr %t19, ptr %t8, i64 %t9)
  %t20 = getelementptr i8, ptr %t19, i64 %t9
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  store { i64, ptr } %t23, ptr %l7, !tbaa !27
  %t25 = call ptr @__olang_scope_hold(ptr %v2)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l8, !tbaa !24
  %t27 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t27, label %bb3, label %bb4
bb3:
  %t29 = call ptr @__olang_region_make(ptr %v2)
  %t30 = ptrtoint ptr %t29 to i64
  store i64 %t30, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t33 = extractvalue { i64, ptr } %a1, 1
  %t34 = extractvalue { i64, ptr } %a1, 0
  %t35 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d604, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d604, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = load i64, ptr %l8
  %t39 = inttoptr i64 %t38 to ptr
  %t40 = call ptr @__olang_held_alloc(ptr %t39, i64 %t37)
  call void @olang_textcopy(ptr %t40, ptr %t33, i64 %t34)
  %t41 = getelementptr i8, ptr %t40, i64 %t34
  call void @olang_textcopy(ptr %t41, ptr %t35, i64 %t36)
  %t42 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t40, 1
  store { i64, ptr } %t43, ptr %l12, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v2)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l13, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb5, label %bb6
bb5:
  %t49 = call ptr @__olang_region_make(ptr %v2)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t52 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d605, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d605, i32 0, i32 1) }, 0
  %t55 = extractvalue { i64, ptr } %t51, 1
  %t56 = extractvalue { i64, ptr } %t51, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d606, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d606, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = load i64, ptr %l13
  %t62 = inttoptr i64 %t61 to ptr
  %t63 = call ptr @__olang_held_alloc(ptr %t62, i64 %t60)
  call void @olang_textcopy(ptr %t63, ptr %t52, i64 %t53)
  %t64 = getelementptr i8, ptr %t63, i64 %t53
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t73 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t69, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d607, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } %t71, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t73, ptr %l18
  br label %bb7
bb7:
  %t74 = load %"compiler/diagmsg:Msg", ptr %l18
  store %"compiler/diagmsg:Msg" %t74, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUniqueNeedsCopy(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 298, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = extractvalue { i64, ptr } %t7, 0
  %t12 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d608, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d608, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %t8, 1
  %t17 = extractvalue { i64, ptr } %t8, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d609, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d609, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = load i64, ptr %l3
  %t23 = inttoptr i64 %t22 to ptr
  %t24 = call ptr @__olang_held_alloc(ptr %t23, i64 %t21)
  call void @olang_textcopy(ptr %t24, ptr %t10, i64 %t11)
  %t25 = getelementptr i8, ptr %t24, i64 %t11
  call void @olang_textcopy(ptr %t25, ptr %t12, i64 %t13)
  %t26 = getelementptr i8, ptr %t25, i64 %t13
  call void @olang_textcopy(ptr %t26, ptr %t16, i64 %t17)
  %t27 = getelementptr i8, ptr %t26, i64 %t17
  call void @olang_textcopy(ptr %t27, ptr %t19, i64 %t20)
  %t28 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t24, 1
  store { i64, ptr } %t29, ptr %l8, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l9, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d610, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d610, i32 0, i32 1) }, 0
  %t42 = extractvalue { i64, ptr } %t37, 1
  %t43 = extractvalue { i64, ptr } %t37, 0
  %t44 = add i64 %t40, %t43
  %t45 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d611, i32 0, i32 1) }, 1
  %t46 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d611, i32 0, i32 1) }, 0
  %t47 = add i64 %t44, %t46
  %t49 = extractvalue { i64, ptr } %t38, 1
  %t50 = extractvalue { i64, ptr } %t38, 0
  %t51 = add i64 %t47, %t50
  %t52 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d612, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d612, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = load i64, ptr %l9
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t39, i64 %t40)
  %t58 = getelementptr i8, ptr %t57, i64 %t40
  call void @olang_textcopy(ptr %t58, ptr %t42, i64 %t43)
  %t59 = getelementptr i8, ptr %t58, i64 %t43
  call void @olang_textcopy(ptr %t59, ptr %t45, i64 %t46)
  %t60 = getelementptr i8, ptr %t59, i64 %t46
  call void @olang_textcopy(ptr %t60, ptr %t49, i64 %t50)
  %t61 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t61, ptr %t52, i64 %t53)
  %t62 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t68 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t65, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d613, i32 0, i32 1) }, { i64, ptr } %t66, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d614, i32 0, i32 1) }, { i64, ptr } %t63)
  store %"compiler/diagmsg:Msg" %t68, ptr %l15
  br label %bb5
bb5:
  %t69 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t69, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeStd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 138, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d615, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d615, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d616, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d616, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d617, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d617, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d618, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d618, i32 0, i32 1) }, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = add i64 %t45, %t48
  %t50 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d619, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d619, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t54 = extractvalue { i64, ptr } %t42, 1
  %t55 = extractvalue { i64, ptr } %t42, 0
  %t56 = add i64 %t52, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d620, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d620, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = extractvalue { i64, ptr } %a2, 1
  %t62 = extractvalue { i64, ptr } %a2, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d621, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d621, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load i64, ptr %l10
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  call void @olang_textcopy(ptr %t69, ptr %t44, i64 %t45)
  %t70 = getelementptr i8, ptr %t69, i64 %t45
  call void @olang_textcopy(ptr %t70, ptr %t47, i64 %t48)
  %t71 = getelementptr i8, ptr %t70, i64 %t48
  call void @olang_textcopy(ptr %t71, ptr %t50, i64 %t51)
  %t72 = getelementptr i8, ptr %t71, i64 %t51
  call void @olang_textcopy(ptr %t72, ptr %t54, i64 %t55)
  %t73 = getelementptr i8, ptr %t72, i64 %t55
  call void @olang_textcopy(ptr %t73, ptr %t57, i64 %t58)
  %t74 = getelementptr i8, ptr %t73, i64 %t58
  call void @olang_textcopy(ptr %t74, ptr %t61, i64 %t62)
  %t75 = getelementptr i8, ptr %t74, i64 %t62
  call void @olang_textcopy(ptr %t75, ptr %t64, i64 %t65)
  %t76 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t69, 1
  %t79 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t80 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t82 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t79, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d622, i32 0, i32 1) }, { i64, ptr } %t80, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d623, i32 0, i32 1) }, { i64, ptr } %t77)
  store %"compiler/diagmsg:Msg" %t82, ptr %l17
  br label %bb5
bb5:
  %t83 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l13 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 101, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t11 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d624, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d624, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %a0, 1
  %t15 = extractvalue { i64, ptr } %a0, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d625, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d625, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t21 = extractvalue { i64, ptr } %a1, 1
  %t22 = extractvalue { i64, ptr } %a1, 0
  %t23 = add i64 %t19, %t22
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d626, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d626, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t28 = extractvalue { i64, ptr } %a2, 1
  %t29 = extractvalue { i64, ptr } %a2, 0
  %t30 = add i64 %t26, %t29
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d627, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d627, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t35 = extractvalue { i64, ptr } %a3, 1
  %t36 = extractvalue { i64, ptr } %a3, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d628, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d628, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = load i64, ptr %l5
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = call ptr @__olang_held_alloc(ptr %t42, i64 %t40)
  call void @olang_textcopy(ptr %t43, ptr %t11, i64 %t12)
  %t44 = getelementptr i8, ptr %t43, i64 %t12
  call void @olang_textcopy(ptr %t44, ptr %t14, i64 %t15)
  %t45 = getelementptr i8, ptr %t44, i64 %t15
  call void @olang_textcopy(ptr %t45, ptr %t17, i64 %t18)
  %t46 = getelementptr i8, ptr %t45, i64 %t18
  call void @olang_textcopy(ptr %t46, ptr %t21, i64 %t22)
  %t47 = getelementptr i8, ptr %t46, i64 %t22
  call void @olang_textcopy(ptr %t47, ptr %t24, i64 %t25)
  %t48 = getelementptr i8, ptr %t47, i64 %t25
  call void @olang_textcopy(ptr %t48, ptr %t28, i64 %t29)
  %t49 = getelementptr i8, ptr %t48, i64 %t29
  call void @olang_textcopy(ptr %t49, ptr %t31, i64 %t32)
  %t50 = getelementptr i8, ptr %t49, i64 %t32
  call void @olang_textcopy(ptr %t50, ptr %t35, i64 %t36)
  %t51 = getelementptr i8, ptr %t50, i64 %t36
  call void @olang_textcopy(ptr %t51, ptr %t38, i64 %t39)
  %t52 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t43, 1
  %t55 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t55, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d629, i32 0, i32 1) }, { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d630, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d631, i32 0, i32 1) }, { i64, ptr } %t53)
  store %"compiler/diagmsg:Msg" %t57, ptr %l13
  br label %bb3
bb3:
  %t58 = load %"compiler/diagmsg:Msg", ptr %l13
  store %"compiler/diagmsg:Msg" %t58, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueBeyondType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l21 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 731, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } %a0, 1
  %t11 = extractvalue { i64, ptr } %a0, 0
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d632, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d632, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t16 = extractvalue { i64, ptr } %a1, 1
  %t17 = extractvalue { i64, ptr } %a1, 0
  %t18 = add i64 %t14, %t17
  %t19 = load i64, ptr %l5
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_held_alloc(ptr %t20, i64 %t18)
  call void @olang_textcopy(ptr %t21, ptr %t10, i64 %t11)
  %t22 = getelementptr i8, ptr %t21, i64 %t11
  call void @olang_textcopy(ptr %t22, ptr %t12, i64 %t13)
  %t23 = getelementptr i8, ptr %t22, i64 %t13
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t21, 1
  store { i64, ptr } %t25, ptr %l10, !tbaa !27
  %t27 = call ptr @__olang_scope_hold(ptr %v4)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l11, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = call ptr @__olang_region_make(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb4
bb4:
  %t34 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d633, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d633, i32 0, i32 1) }, 0
  %t37 = extractvalue { i64, ptr } %a2, 1
  %t38 = extractvalue { i64, ptr } %a2, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d634, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d634, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t43 = load i64, ptr %l11
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = call ptr @__olang_held_alloc(ptr %t44, i64 %t42)
  call void @olang_textcopy(ptr %t45, ptr %t34, i64 %t35)
  %t46 = getelementptr i8, ptr %t45, i64 %t35
  call void @olang_textcopy(ptr %t46, ptr %t37, i64 %t38)
  %t47 = getelementptr i8, ptr %t46, i64 %t38
  call void @olang_textcopy(ptr %t47, ptr %t40, i64 %t41)
  %t48 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t45, 1
  store { i64, ptr } %t49, ptr %l15, !tbaa !27
  %t51 = call ptr @__olang_scope_hold(ptr %v4)
  %t52 = ptrtoint ptr %t51 to i64
  store i64 %t52, ptr %l16, !tbaa !24
  %t53 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t53, label %bb5, label %bb6
bb5:
  %t55 = call ptr @__olang_region_make(ptr %v4)
  %t56 = ptrtoint ptr %t55 to i64
  store i64 %t56, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t58 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d635, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d635, i32 0, i32 1) }, 0
  %t61 = extractvalue { i64, ptr } %a3, 1
  %t62 = extractvalue { i64, ptr } %a3, 0
  %t63 = add i64 %t59, %t62
  %t64 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d636, i32 0, i32 1) }, 1
  %t65 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d636, i32 0, i32 1) }, 0
  %t66 = add i64 %t63, %t65
  %t67 = load i64, ptr %l16
  %t68 = inttoptr i64 %t67 to ptr
  %t69 = call ptr @__olang_held_alloc(ptr %t68, i64 %t66)
  call void @olang_textcopy(ptr %t69, ptr %t58, i64 %t59)
  %t70 = getelementptr i8, ptr %t69, i64 %t59
  call void @olang_textcopy(ptr %t70, ptr %t61, i64 %t62)
  %t71 = getelementptr i8, ptr %t70, i64 %t62
  call void @olang_textcopy(ptr %t71, ptr %t64, i64 %t65)
  %t72 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t69, 1
  %t75 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t76 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t79 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t75, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d637, i32 0, i32 1) }, { i64, ptr } %t76, { i64, ptr } %t77, { i64, ptr } %t73)
  store %"compiler/diagmsg:Msg" %t79, ptr %l21
  br label %bb7
bb7:
  %t80 = load %"compiler/diagmsg:Msg", ptr %l21
  store %"compiler/diagmsg:Msg" %t80, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eVecViewGivenGrowing(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l17 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 784, ptr %l4
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t10 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d638, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d638, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a0, 1
  %t14 = extractvalue { i64, ptr } %a0, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d639, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d639, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = extractvalue { i64, ptr } %a1, 1
  %t21 = extractvalue { i64, ptr } %a1, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d640, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d640, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %a2, 1
  %t28 = extractvalue { i64, ptr } %a2, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d641, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d641, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = load i64, ptr %l5
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_held_alloc(ptr %t34, i64 %t32)
  call void @olang_textcopy(ptr %t35, ptr %t10, i64 %t11)
  %t36 = getelementptr i8, ptr %t35, i64 %t11
  call void @olang_textcopy(ptr %t36, ptr %t13, i64 %t14)
  %t37 = getelementptr i8, ptr %t36, i64 %t14
  call void @olang_textcopy(ptr %t37, ptr %t16, i64 %t17)
  %t38 = getelementptr i8, ptr %t37, i64 %t17
  call void @olang_textcopy(ptr %t38, ptr %t20, i64 %t21)
  %t39 = getelementptr i8, ptr %t38, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t35, 1
  store { i64, ptr } %t43, ptr %l11, !tbaa !27
  %t45 = call ptr @__olang_scope_hold(ptr %v4)
  %t46 = ptrtoint ptr %t45 to i64
  store i64 %t46, ptr %l12, !tbaa !24
  %t47 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t47, label %bb3, label %bb4
bb3:
  %t49 = call ptr @__olang_region_make(ptr %v4)
  %t50 = ptrtoint ptr %t49 to i64
  store i64 %t50, ptr %l12, !tbaa !24
  br label %bb4
bb4:
  %t53 = extractvalue { i64, ptr } %a3, 1
  %t54 = extractvalue { i64, ptr } %a3, 0
  %t55 = load i64, ptr %l12
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = call ptr @__olang_held_alloc(ptr %t56, i64 %t54)
  call void @olang_textcopy(ptr %t57, ptr %t53, i64 %t54)
  %t58 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = load i32, ptr %l4, !range !{i32 0, i32 949}
  %t62 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t64 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v4, ptr %v4, ptr %v4, ptr %v4, ptr %v4, i32 %t61, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d642, i32 0, i32 1) }, { i64, ptr } %t62, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d643, i32 0, i32 1) }, { i64, ptr } %t59)
  store %"compiler/diagmsg:Msg" %t64, ptr %l17
  br label %bb5
bb5:
  %t65 = load %"compiler/diagmsg:Msg", ptr %l17
  store %"compiler/diagmsg:Msg" %t65, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWholeCaseNamed(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i32 527, ptr %l2
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d644, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d644, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %t7, 1
  %t13 = extractvalue { i64, ptr } %t7, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d645, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d645, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %t8, 1
  %t20 = extractvalue { i64, ptr } %t8, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d646, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d646, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l3
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l8, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l9, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v2)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t43 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d647, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d647, i32 0, i32 1) }, 0
  %t46 = extractvalue { i64, ptr } %t41, 1
  %t47 = extractvalue { i64, ptr } %t41, 0
  %t48 = add i64 %t44, %t47
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d648, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d648, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t42, 1
  %t54 = extractvalue { i64, ptr } %t42, 0
  %t55 = add i64 %t51, %t54
  %t56 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d649, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d649, i32 0, i32 1) }, 0
  %t58 = add i64 %t55, %t57
  %t59 = load i64, ptr %l9
  %t60 = inttoptr i64 %t59 to ptr
  %t61 = call ptr @__olang_held_alloc(ptr %t60, i64 %t58)
  call void @olang_textcopy(ptr %t61, ptr %t43, i64 %t44)
  %t62 = getelementptr i8, ptr %t61, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  call void @olang_textcopy(ptr %t63, ptr %t49, i64 %t50)
  %t64 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t64, ptr %t53, i64 %t54)
  %t65 = getelementptr i8, ptr %t64, i64 %t54
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t61, 1
  %t69 = load i32, ptr %l2, !range !{i32 0, i32 949}
  %t70 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t69, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d650, i32 0, i32 1) }, { i64, ptr } %t70, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d651, i32 0, i32 1) }, { i64, ptr } %t67)
  store %"compiler/diagmsg:Msg" %t72, ptr %l15
  br label %bb5
bb5:
  %t73 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eWriteThroughNull(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca i32
  %l4 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l15 = alloca %"compiler/diagmsg:Msg"
  %rv = alloca %"compiler/diagmsg:Msg"
  br label %start
start:
  br label %bb0
bb0:
  store i32 646, ptr %l3
  %t1 = call ptr @__olang_scope_hold(ptr %v3)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v3)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d652, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d652, i32 0, i32 1) }, 0
  %t12 = extractvalue { i64, ptr } %a0, 1
  %t13 = extractvalue { i64, ptr } %a0, 0
  %t14 = add i64 %t10, %t13
  %t15 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d653, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d653, i32 0, i32 1) }, 0
  %t17 = add i64 %t14, %t16
  %t19 = extractvalue { i64, ptr } %a1, 1
  %t20 = extractvalue { i64, ptr } %a1, 0
  %t21 = add i64 %t17, %t20
  %t22 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d654, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d654, i32 0, i32 1) }, 0
  %t24 = add i64 %t21, %t23
  %t25 = load i64, ptr %l4
  %t26 = inttoptr i64 %t25 to ptr
  %t27 = call ptr @__olang_held_alloc(ptr %t26, i64 %t24)
  call void @olang_textcopy(ptr %t27, ptr %t9, i64 %t10)
  %t28 = getelementptr i8, ptr %t27, i64 %t10
  call void @olang_textcopy(ptr %t28, ptr %t12, i64 %t13)
  %t29 = getelementptr i8, ptr %t28, i64 %t13
  call void @olang_textcopy(ptr %t29, ptr %t15, i64 %t16)
  %t30 = getelementptr i8, ptr %t29, i64 %t16
  call void @olang_textcopy(ptr %t30, ptr %t19, i64 %t20)
  %t31 = getelementptr i8, ptr %t30, i64 %t20
  call void @olang_textcopy(ptr %t31, ptr %t22, i64 %t23)
  %t32 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t27, 1
  store { i64, ptr } %t33, ptr %l9, !tbaa !27
  %t35 = call ptr @__olang_scope_hold(ptr %v3)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l10, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t39 = call ptr @__olang_region_make(ptr %v3)
  %t40 = ptrtoint ptr %t39 to i64
  store i64 %t40, ptr %l10, !tbaa !24
  br label %bb4
bb4:
  %t42 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d655, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d655, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %a2, 1
  %t46 = extractvalue { i64, ptr } %a2, 0
  %t47 = add i64 %t43, %t46
  %t48 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d656, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d656, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t51 = load i64, ptr %l10
  %t52 = inttoptr i64 %t51 to ptr
  %t53 = call ptr @__olang_held_alloc(ptr %t52, i64 %t50)
  call void @olang_textcopy(ptr %t53, ptr %t42, i64 %t43)
  %t54 = getelementptr i8, ptr %t53, i64 %t43
  call void @olang_textcopy(ptr %t54, ptr %t45, i64 %t46)
  %t55 = getelementptr i8, ptr %t54, i64 %t46
  call void @olang_textcopy(ptr %t55, ptr %t48, i64 %t49)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t53, 1
  %t59 = load i32, ptr %l3, !range !{i32 0, i32 949}
  %t60 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t62 = call %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t59, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d657, i32 0, i32 1) }, { i64, ptr } %t60, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d658, i32 0, i32 1) }, { i64, ptr } %t57)
  store %"compiler/diagmsg:Msg" %t62, ptr %l15
  br label %bb5
bb5:
  %t63 = load %"compiler/diagmsg:Msg", ptr %l15
  store %"compiler/diagmsg:Msg" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diagmsg:Msg", ptr %rv
  ret %"compiler/diagmsg:Msg" %rr
}

define dso_local void @compiler_2fmsgs_2ecompiler_2fmsgs_3aNearest_2eOfferBuilder(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l35 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l71 = alloca i1
  %l77 = alloca i1
  %l79 = alloca { i64, ptr }
  %l82 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l112 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v1, { i64, ptr } %t1, i8 46)
  %t5 = extractvalue { i32, i64 } %t4, 1
  %t6 = extractvalue { i32, i64 } %t4, 0
  store i32 %t6, ptr %l13
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t9 = load i64, ptr %l12, !tbaa !24
  store i64 %t9, ptr %l9, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = icmp sge i64 0, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load i64, ptr %l15, !tbaa !24
  %t18 = icmp sle i64 0, %t17
  br i1 %t18, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_af0cd4b2e246af5e_f7dc695b2384058a)
  unreachable
bb7:
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = load i64, ptr %l16, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_af0cd4b2e246af5e_f7dc695b2384058a)
  unreachable
bb9:
  %t24 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 0
  %t28 = sub i64 %t26, 0
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t32, ptr %l21, !tbaa !27
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t36, 0
  store i64 %t39, ptr %l26, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l23, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_af0cd4b2e246af5e_f7dc695b2384058a)
  unreachable
bb11:
  %t45 = load i64, ptr %l23, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_afe78659650a85b_d80bf1f42ea79867)
  unreachable
bb13:
  %t49 = load i64, ptr %l26, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  br i1 %t51, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_afe78659650a85b_d80bf1f42ea79867)
  unreachable
bb15:
  %t53 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = load i64, ptr %l26, !tbaa !24
  %t57 = getelementptr i8, ptr %t54, i64 %t55
  %t58 = sub i64 %t56, %t55
  %t59 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp eq i64 %t64, 0
  br i1 %t66, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_afe78659650a85b_d80bf1f42ea79867)
  unreachable
bb17:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb19
bb18:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/msgs:Nearest", ptr %t71, i32 0, i32 0
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t79 = icmp sge i64 %t70, %t76
  store i1 %t79, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t81 = load i1, ptr %l35, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb22
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/msgs:Nearest", ptr %t82, i32 0, i32 2
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = icmp eq i64 %t85, 0
  store i1 %t87, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t89 = load i1, ptr %l42, !tbaa !21
  br i1 %t89, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  br label %bb25
bb25:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/msgs:Nearest", ptr %t90, i32 0, i32 0
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t97 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %t93, { i64, ptr } %t94)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l51
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb27, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l50
  br label %bb26
bb26:
  %t102 = load i64, ptr %l50, !tbaa !24
  store i64 %t102, ptr %l46, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb29:
  %t103 = load i64, ptr %l46, !tbaa !24
  store i64 %t103, ptr %l5, !tbaa !24
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t110 = add i64 %t104, %t107
  store i64 %t110, ptr %l6, !tbaa !24
  %t112 = load i64, ptr %l5, !tbaa !24
  %t114 = icmp eq i64 %t112, 0
  br i1 %t114, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb33
bb31:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/msgs:Nearest", ptr %t116, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l60, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = sub i64 %t120, 1
  %t124 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t127)
  store i1 %t129, ptr %l64
  br label %bb32
bb32:
  %t130 = load i1, ptr %l64, !tbaa !21
  store i1 %t130, ptr %l58, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l58, !tbaa !21
  br i1 %t131, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb37
bb35:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/msgs:Nearest", ptr %t132, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l67, !tbaa !27
  %t136 = load i64, ptr %l5, !tbaa !24
  %t138 = sub i64 %t136, 1
  %t140 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i8, ptr %t141, i64 %t138
  %t143 = load i8, ptr %t142, !tbaa !32
  %t145 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t143)
  store i1 %t145, ptr %l71
  br label %bb36
bb36:
  %t146 = load i1, ptr %l71, !tbaa !21
  store i1 %t146, ptr %l65, !tbaa !21
  br label %bb37
bb37:
  %t147 = load i1, ptr %l65, !tbaa !21
  store i1 %t147, ptr %l7, !tbaa !21
  %t148 = load i64, ptr %l6, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/msgs:Nearest", ptr %t149, i32 0, i32 0
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t157 = icmp eq i64 %t148, %t154
  br i1 %t157, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb41
bb39:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/msgs:Nearest", ptr %t159, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l79, !tbaa !27
  %t163 = load i64, ptr %l6, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr i8, ptr %t166, i64 %t163
  %t168 = load i8, ptr %t167, !tbaa !32
  %t170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t168)
  store i1 %t170, ptr %l82
  br label %bb40
bb40:
  %t171 = load i1, ptr %l82, !tbaa !21
  store i1 %t171, ptr %l77, !tbaa !21
  br label %bb41
bb41:
  %t172 = load i1, ptr %l77, !tbaa !21
  store i1 %t172, ptr %l8, !tbaa !21
  %t173 = load i1, ptr %l7, !tbaa !21
  %t175 = xor i1 %t173, true
  br i1 %t175, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb44
bb43:
  %t177 = load i1, ptr %l8, !tbaa !21
  %t179 = xor i1 %t177, true
  store i1 %t179, ptr %l85, !tbaa !21
  br label %bb44
bb44:
  %t181 = load i1, ptr %l85, !tbaa !21
  br i1 %t181, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb60
bb46:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/msgs:Nearest", ptr %t182, i32 0, i32 0
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l90, !tbaa !27
  %t186 = load i64, ptr %l5, !tbaa !24
  store i64 %t186, ptr %l91, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l92, !tbaa !24
  %t189 = icmp sge i64 0, 0
  br i1 %t189, label %bb47, label %bb48
bb47:
  %t191 = load i64, ptr %l91, !tbaa !24
  %t192 = icmp sle i64 0, %t191
  br i1 %t192, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb49:
  %t194 = load i64, ptr %l91, !tbaa !24
  %t195 = load i64, ptr %l92, !tbaa !24
  %t196 = icmp sle i64 %t194, %t195
  br i1 %t196, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb51:
  %t198 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l91, !tbaa !24
  %t201 = getelementptr i8, ptr %t199, i64 0
  %t202 = sub i64 %t200, 0
  %t203 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t201, 1
  store { i64, ptr } %t204, ptr %l96, !tbaa !27
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/msgs:Nearest", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l98, !tbaa !27
  %t209 = load i64, ptr %l6, !tbaa !24
  store i64 %t209, ptr %l99, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/msgs:Nearest", ptr %t210, i32 0, i32 0
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 0
  store i64 %t216, ptr %l103, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t218 = extractvalue { i64, ptr } %t217, 0
  store i64 %t218, ptr %l104, !tbaa !24
  %t219 = load i64, ptr %l99, !tbaa !24
  %t220 = icmp sge i64 %t219, 0
  br i1 %t220, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb53:
  %t222 = load i64, ptr %l99, !tbaa !24
  %t223 = load i64, ptr %l103, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb55:
  %t226 = load i64, ptr %l103, !tbaa !24
  %t227 = load i64, ptr %l104, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb57:
  %t230 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l99, !tbaa !24
  %t233 = load i64, ptr %l103, !tbaa !24
  %t234 = getelementptr i8, ptr %t231, i64 %t232
  %t235 = sub i64 %t233, %t232
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t238 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = extractvalue { i64, ptr } %t237, 1
  %t243 = extractvalue { i64, ptr } %t237, 0
  %t244 = add i64 %t240, %t243
  %t245 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t244)
  call void @olang_textcopy(ptr %t245, ptr %t239, i64 %t240)
  %t246 = getelementptr i8, ptr %t245, i64 %t240
  call void @olang_textcopy(ptr %t246, ptr %t242, i64 %t243)
  %t247 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t245, 1
  %t250 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t253 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %v1, { i64, ptr } %t248, { i64, ptr } %t250)
  store i1 %t253, ptr %l112
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_94d222cfeceaa960_f4d92a1033be80bc)
  unreachable
bb59:
  %t254 = load i1, ptr %l112, !tbaa !21
  %t255 = xor i1 %t254, true
  store i1 %t255, ptr %l88, !tbaa !21
  br label %bb60
bb60:
  %t257 = load i1, ptr %l88, !tbaa !21
  br i1 %t257, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb62:
  br label %bb63
bb63:
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l114, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t260 = load ptr, ptr %l114, !tbaa !29
  %t261 = getelementptr %"compiler/msgs:Nearest", ptr %t260, i32 0, i32 1
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l116, !tbaa !27
  %t264 = load ptr, ptr %l114, !tbaa !29
  %t265 = getelementptr %"compiler/msgs:Nearest", ptr %t264, i32 0, i32 1
  store { i64, ptr } %t259, ptr %t265, !tbaa !27
  %t266 = load i1, ptr @olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1
  br i1 %t266, label %bb64, label %bb65
bb64:
  %t268 = load { i64, ptr }, ptr %l116
  %t269 = extractvalue { i64, ptr } %t268, 1
  call void @__olang_region_release(ptr %t269)
  store { i64, ptr } zeroinitializer, ptr %l116
  br label %bb65
bb65:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/msgs:Nearest", ptr %t270, i32 0, i32 2
  store i64 0, ptr %t272, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d0 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d1 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" cannot be called through an 'any " }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e3 = weak hidden constant i1 false
@.d3 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"it says where its references live as " }>, align 8
@.d4 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"'s signature does not" }>, align 8
@.d5 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T32a, T22" }>, align 8
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d7 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be an 'any " }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d9 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" is closed, met by " }>, align 8
@.d10 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" alone" }>, align 8
@.d11 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T32a, T31a" }>, align 8
@.d12 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" holds itself through the array it is declared over" }>, align 8
@olang_2esole_2ecompiler_2fdiagmsg_3aMsg_2e4 = weak hidden constant i1 false
@.d13 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"hold the array in a struct: 'type " }>, align 8
@.d14 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" struct(items " }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"&)'" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T29" }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d19 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"' takes a block or a one-line body" }>, align 8
@.d20 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"one way to write each thing: '" }>, align 8
@.d21 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c": stmt' is the one-statement form (S1b)" }>, align 8
@.d22 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d23 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c": stmt', or '" }>, align 8
@.d24 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" { ... }'" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S19" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d27 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is not held by reference" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"use '" }>, align 8
@.d29 = private constant <{ i64, [83 x i8] }> <{ i64 0, [83 x i8] c"' itself, or take its value where it is mentioned last, declaring its type ('w T = " }>, align 8
@.d30 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"')" }>, align 8
@.d31 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"O17a, T13b" }>, align 8
@.d32 = private constant <{ i64, [80 x i8] }> <{ i64 0, [80 x i8] c"it holds references to the caller's storage while its own storage is this call's" }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"-define " }>, align 8
@.d34 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" gives it no value, and " }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d36 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c" - only a Bool is true by its name alone" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"String" }>, align 8
@.d38 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"443" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"text" }>, align 8
@.d40 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"give it a value: -define " }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B10c" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d43 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" makes a " }>, align 8
@.d44 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c" its module declares and takes none" }>, align 8
@.d45 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"declare it as the type's builder, 'fn " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d47 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"(...)', and call it '" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(...)'" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D19a" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c" is generic, and a builder's owner is written with its arguments" }>, align 8
@.d52 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"write 'fn " }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d54 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"(...)' for every instance, 'fn " }>, align 8
@.d55 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"(...)' for one" }>, align 8
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D19" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a builder of " }>, align 8
@.d59 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" gives one value of it, not " }>, align 8
@.d60 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"its result is " }>, align 8
@.d61 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c", a reference to it or an instance of it" }>, align 8
@.d62 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D19" }>, align 8
@.d63 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"a builder of " }>, align 8
@.d64 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" takes no value of it, and " }>, align 8
@.d65 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" does" }>, align 8
@.d66 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"make it a method, 'fn (x " }>, align 8
@.d67 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c") ...', or a function of the module" }>, align 8
@.d68 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D19" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"the type arguments of " }>, align 8
@.d71 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" cannot be inferred from this case" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d72 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"write them, '" }>, align 8
@.d73 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"<...>." }>, align 8
@.d74 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"', or give it a type to land in" }>, align 8
@.d75 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10c" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'s field '" }>, align 8
@.d78 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"' would be a column of " }>, align 8
@.d79 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" named like its method" }>, align 8
@.d80 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a field may not share a method's name '" }>, align 8
@.d81 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' (M19)" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T7e" }>, align 8
@.d83 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"rename the field" }>, align 8
@.d84 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"'commutes' here makes " }>, align 8
@.d85 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" between " }>, align 8
@.d86 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d87 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" ambiguous" }>, align 8
@.d88 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"it would call this method or " }>, align 8
@.d89 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31c" }>, align 8
@.d90 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"remove 'commutes'" }>, align 8
@.d91 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d92 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d93 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" is closed, met by " }>, align 8
@.d94 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" alone" }>, align 8
@.d95 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"G19, T31a" }>, align 8
@.d96 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d97 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d98 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" is sealed - only the types its own module gives '" }>, align 8
@.d99 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"' satisfy it" }>, align 8
@.d100 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"G19, T31" }>, align 8
@.d101 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d102 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d103 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"it has no builder " }>, align 8
@.d104 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" that fits" }>, align 8
@.d105 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T30b" }>, align 8
@.d106 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" does not satisfy the constraint " }>, align 8
@.d107 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" on " }>, align 8
@.d108 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"it has no method " }>, align 8
@.d109 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" that fits" }>, align 8
@.d110 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G19" }>, align 8
@.d111 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"Copy takes nothing but its receiver, read through a read-only reference, gives a new " }>, align 8
@.d112 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" and cannot fail" }>, align 8
@.d113 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"write 'fn (x " }>, align 8
@.d114 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"&) Copy() " }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d116 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E31d" }>, align 8
@.d117 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"this Copy has the wrong shape" }>, align 8
@.d118 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"the type of field " }>, align 8
@.d119 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" names " }>, align 8
@.d120 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c", which only the constructor introduces" }>, align 8
@.d121 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"for a field to hold it, declare it the type's parameter: 'type " }>, align 8
@.d122 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d123 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c">'" }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is not one of " }>, align 8
@.d127 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"'s parameters" }>, align 8
@.d128 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"add " }>, align 8
@.d129 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" to the type's list" }>, align 8
@.d130 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"G10d" }>, align 8
@.d131 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"a generic type's constructor introduces none of its own" }>, align 8
@.d132 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c" has a destructor to run and copies, and so does " }>, align 8
@.d133 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"a copy of " }>, align 8
@.d134 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c" would copy what it holds past its count (its Copy)" }>, align 8
@.d135 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"hold them by reference, " }>, align 8
@.d136 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"&" }>, align 8
@.d137 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C11" }>, align 8
@.d138 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" has a destructor to run, and " }>, align 8
@.d139 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" keeps values of it" }>, align 8
@.d140 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d141 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"&, or keep them in a Vec<" }>, align 8
@.d142 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d143 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"C11" }>, align 8
@.d144 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"no holder ends them there" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d146 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"' may be ended after '" }>, align 8
@.d147 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"', which it may hold a reference to" }>, align 8
@.d148 = private constant <{ i64, [99 x i8] }> <{ i64 0, [99 x i8] c"it holds a value where its call landed, ended as that scope closes, so its destructors could read '" }>, align 8
@.d149 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"' already ended" }>, align 8
@.d150 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"declare it by value, '" }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d152 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" = ...', and its block ends it first" }>, align 8
@.d153 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"O15, O16" }>, align 8
@.d154 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"this value may be ended after '" }>, align 8
@.d155 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"', which it may hold a reference to" }>, align 8
@.d156 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"it is held where its call lands, ended as that scope closes, so its destructors could read '" }>, align 8
@.d157 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"' already ended" }>, align 8
@.d158 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"declare it by value first, 'x " }>, align 8
@.d159 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" = ...', and give the call that" }>, align 8
@.d160 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"O15, O16" }>, align 8
@.d161 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" may " }>, align 8
@.d162 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d163 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"', the type it is held as here, promises '" }>, align 8
@.d164 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"give a function that does not, or hold it as a type without '" }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d166 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22b" }>, align 8
@.d167 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"this array pattern's elements are " }>, align 8
@.d168 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c", and what is matched holds " }>, align 8
@.d169 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"write 'Array<" }>, align 8
@.d170 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c">[...]'" }>, align 8
@.d171 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13h" }>, align 8
@.d172 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d173 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d174 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d175 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cr" }>, align 8
@.d176 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C0" }>, align 8
@.d177 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cx" }>, align 8
@.d178 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" is read through a function" }>, align 8
@.d179 = private constant <{ i64, [66 x i8] }> <{ i64 0, [66 x i8] c"write it through a function's name or a function's descriptor ('f." }>, align 8
@.d180 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"', 'd." }>, align 8
@.d181 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"' in a walk of 'm.Functions')" }>, align 8
@.d182 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G42" }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" is an enum, and its payload's '" }>, align 8
@.d185 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"' is read through a case" }>, align 8
@.d186 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"read it where a test narrows it to the case, 'if e == Case { e." }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }'" }>, align 8
@.d188 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8d" }>, align 8
@.d189 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"the field '" }>, align 8
@.d190 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"' is not assigned on every path through the constructor" }>, align 8
@.d191 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" has no zero value" }>, align 8
@.d192 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"assign it on each path, or give it a value" }>, align 8
@.d193 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13d" }>, align 8
@.d194 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d195 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" defaults to " }>, align 8
@.d196 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" here, but to " }>, align 8
@.d197 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" in " }>, align 8
@.d198 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"give " }>, align 8
@.d199 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" the default '= " }>, align 8
@.d200 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"', or none" }>, align 8
@.d201 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T21d" }>, align 8
@.d202 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"a call through the value takes the function type's default" }>, align 8
@.d203 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" is an extern type, held only by reference" }>, align 8
@.d204 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d205 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"&', or '" }>, align 8
@.d206 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"?&' where it may be null" }>, align 8
@.d207 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"X10" }>, align 8
@.d208 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d209 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d210 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"' is linked to a new value: the caller still sees what it passed" }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d212 = private constant <{ i64, [128 x i8] }> <{ i64 0, [128 x i8] c"' is a reference parameter, and '~' links the callee's own copy of it (S4f) - to storage built here, which the caller never sees" }>, align 8
@.d213 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"write through the reference - '" }>, align 8
@.d214 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = ...' or '" }>, align 8
@.d215 = private constant <{ i64, [81 x i8] }> <{ i64 0, [81 x i8] c".f = ...' - return the new value, or build a scratch value in a local, 't := ...'" }>, align 8
@.d216 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S4e" }>, align 8
@.d217 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c".FromBits takes the " }>, align 8
@.d218 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" of its width, and this is a " }>, align 8
@.d219 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"convert it first: '" }>, align 8
@.d220 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(x)'" }>, align 8
@.d221 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E33" }>, align 8
@.d222 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d223 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c" is a function type, held only by reference" }>, align 8
@.d224 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d225 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"&', or '" }>, align 8
@.d226 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"?&' where it may be null" }>, align 8
@.d227 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T21b" }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"expected " }>, align 8
@.d230 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d231 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d232 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"(f)' to make one the other" }>, align 8
@.d233 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T21b, T29" }>, align 8
@.d234 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a declared function type is a type of its own" }>, align 8
@.d235 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"a value of type '" }>, align 8
@.d236 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"' may do what '" }>, align 8
@.d237 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"' does not say" }>, align 8
@.d238 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"it may do '" }>, align 8
@.d239 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"', and which functions it holds is not known here" }>, align 8
@.d240 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d241 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"' after the signature of the type it is held as, or give a function directly" }>, align 8
@.d242 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22b" }>, align 8
@.d243 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c" can escape here, but the generator's result does not say so" }>, align 8
@.d244 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"the generator's result must say it fails with " }>, align 8
@.d245 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"write 'Iterator<T ? " }>, align 8
@.d246 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c">', or catch it" }>, align 8
@.d247 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"R9, D18" }>, align 8
@.d248 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" needs " }>, align 8
@.d249 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", and " }>, align 8
@.d250 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" has none" }>, align 8
@.d251 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"declare it for " }>, align 8
@.d252 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", or call " }>, align 8
@.d253 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" with a type that has it" }>, align 8
@.d254 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G18" }>, align 8
@.d255 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d256 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"'mut' on " }>, align 8
@.d257 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which is immut" }>, align 8
@.d258 = private constant <{ i64, [49 x i8] }> <{ i64 0, [49 x i8] c"'mut' makes a reference writable, and nothing of " }>, align 8
@.d259 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" changes after its constructor" }>, align 8
@.d260 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"read it through '" }>, align 8
@.d261 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d262 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13a" }>, align 8
@.d263 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"index '" }>, align 8
@.d264 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' is " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d265 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c", outside the array's " }>, align 8
@.d266 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d267 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"index within 0 to " }>, align 8
@.d268 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c", or write '.Get(i)' to have it checked where it runs" }>, align 8
@.d269 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E16h" }>, align 8
@.d270 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"its value is known while compiling" }>, align 8
@.d271 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"this lambda captures '" }>, align 8
@.d272 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"' and is assigned to it" }>, align 8
@.d273 = private constant <{ i64, [79 x i8] }> <{ i64 0, [79 x i8] c"the capture is a copy made as the lambda is, so it holds the earlier value of '" }>, align 8
@.d274 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"', never this lambda" }>, align 8
@.d275 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"for a recursive function write a top-level 'fn " }>, align 8
@.d276 = private constant <{ i64, [146 x i8] }> <{ i64 0, [146 x i8] c"(...)' and pass it what it would capture, or capture a reference holding the function ('h mut Holder& = Holder(...)'; 'h.f = fn ... h.f(...) ...')" }>, align 8
@.d277 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D16c" }>, align 8
@.d278 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"this lambda keeps '" }>, align 8
@.d279 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"' in what it captured from an outer scope" }>, align 8
@.d280 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"that scope outlives where the lambda lives, and 'keeps " }>, align 8
@.d281 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"' says only that '" }>, align 8
@.d282 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"' outlives the lambda" }>, align 8
@.d283 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22b" }>, align 8
@.d284 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"capture from one scope, or hold the lambda in a local and call it there" }>, align 8
@.d285 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'Sum<" }>, align 8
@.d286 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c">' would narrow the " }>, align 8
@.d287 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" elements" }>, align 8
@.d288 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" does not widen to " }>, align 8
@.d289 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" with nothing lost (T6b)" }>, align 8
@.d290 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"name a type " }>, align 8
@.d291 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c" widens to, or convert the operands first" }>, align 8
@.d292 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E39" }>, align 8
@.d293 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"'~' links a reference, and '" }>, align 8
@.d294 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' holds a value (" }>, align 8
@.d295 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d296 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"write '=' to store into '" }>, align 8
@.d297 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d298 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S4f" }>, align 8
@.d299 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d300 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d301 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"' compares two literals, so it is " }>, align 8
@.d302 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" on every build" }>, align 8
@.d303 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d304 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d305 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8a" }>, align 8
@.d306 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d307 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"the items have no common type: " }>, align 8
@.d308 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" is " }>, align 8
@.d309 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d310 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"write the type in front, as " }>, align 8
@.d311 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E20" }>, align 8
@.d312 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d313 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"a literal makes " }>, align 8
@.d314 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c", which has no FromIter" }>, align 8
@.d315 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"for an array of " }>, align 8
@.d316 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", write Array<" }>, align 8
@.d317 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c">[...]" }>, align 8
@.d318 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E19" }>, align 8
@.d319 = private constant <{ i64, [105 x i8] }> <{ i64 0, [105 x i8] c"a literal makes the type written before its '[' or expected where it stands, through that type's FromIter" }>, align 8
@.d320 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"a literal or comprehension of " }>, align 8
@.d321 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" holds unique values" }>, align 8
@.d322 = private constant <{ i64, [58 x i8] }> <{ i64 0, [58 x i8] c"it hands its FromIter a walk of references to the values (" }>, align 8
@.d323 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"), and unique values are never copied" }>, align 8
@.d324 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"make the " }>, align 8
@.d325 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" and add each value by its own call (Push, Put)" }>, align 8
@.d326 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"E19, T13b" }>, align 8
@.d327 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the write to '" }>, align 8
@.d328 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is lost: nothing reads '" }>, align 8
@.d329 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' after it" }>, align 8
@.d330 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d331 = private constant <{ i64, [93 x i8] }> <{ i64 0, [93 x i8] c"' is the reference the element holds, and '~' links the name (S4f), never writing the element" }>, align 8
@.d332 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d333 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"' holds a copy of the turn's count (S9a), and nothing reads it again this turn" }>, align 8
@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d335 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c"' is a copy of the element's value (S9a), and nothing reads it again this turn" }>, align 8
@.d336 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"keep a count of your own in a local declared before the loop" }>, align 8
@.d337 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"write the element where it is - 'for i, " }>, align 8
@.d338 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" in a: a[i] = ...' or 'a[i].f = ...' - or store the value somewhere read later" }>, align 8
@.d339 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S9g" }>, align 8
@.d340 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the write to '" }>, align 8
@.d341 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is lost: nothing reads '" }>, align 8
@.d342 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' after it" }>, align 8
@.d343 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d344 = private constant <{ i64, [106 x i8] }> <{ i64 0, [106 x i8] c"' was linked to the callee's own storage (S4f), so a write through it never reaches what the caller passed" }>, align 8
@.d345 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d346 = private constant <{ i64, [103 x i8] }> <{ i64 0, [103 x i8] c"' is a reference, and '~' links the callee's own copy of it (S4f), never writing what the caller passed" }>, align 8
@.d347 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d348 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"' is the callee's own copy (D9), and nothing reads it again" }>, align 8
@.d349 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"write through '" }>, align 8
@.d350 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"' before linking it, or return the new value" }>, align 8
@.d351 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"write through the reference - '" }>, align 8
@.d352 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" = ...' or '" }>, align 8
@.d353 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c".f = ...' - or return the new value" }>, align 8
@.d354 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"return the new value, or take a 'mut' reference to change the caller's" }>, align 8
@.d355 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S4e" }>, align 8
@.d356 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d357 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' is a " }>, align 8
@.d358 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", which may be null, and " }>, align 8
@.d359 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" never is" }>, align 8
@.d360 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"test it first ('if x is not null'), or write '" }>, align 8
@.d361 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!'" }>, align 8
@.d362 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d363 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d364 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d365 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"' is narrowed to " }>, align 8
@.d366 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c", and what it reads there is a copy of the payload" }>, align 8
@.d367 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"assign the whole case, '" }>, align 8
@.d368 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d369 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"(...)', or change a copy a match binds and assign the case back" }>, align 8
@.d370 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S8d" }>, align 8
@.d371 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"a narrowed payload field is read, never written or lent writably" }>, align 8
@.d372 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" has no limit '" }>, align 8
@.d373 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d374 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E36" }>, align 8
@.d375 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" declares no " }>, align 8
@.d376 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"the prelude's " }>, align 8
@.d377 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" needs no module: write '" }>, align 8
@.d378 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d379 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"M9" }>, align 8
@.d380 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d381 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d382 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" takes " }>, align 8
@.d383 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" besides its receiver" }>, align 8
@.d384 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"it is an ordinary method, not the one " }>, align 8
@.d385 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" calls, which takes " }>, align 8
@.d386 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"E31" }>, align 8
@.d387 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d388 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"' is declared here, in a block that closes first - declare it where '" }>, align 8
@.d389 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' lives, '" }>, align 8
@.d390 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d391 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"&', and assign it here" }>, align 8
@.d392 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d393 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d394 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d395 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' is " }>, align 8
@.d396 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c", its literal's own type - declare the type it should have, '" }>, align 8
@.d397 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d398 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" = ...'" }>, align 8
@.d399 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d400 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the range's literals make '" }>, align 8
@.d401 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"' " }>, align 8
@.d402 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" - write '" }>, align 8
@.d403 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d404 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c")' here for " }>, align 8
@.d405 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" values" }>, align 8
@.d406 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d407 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"the range's literals make '" }>, align 8
@.d408 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"' " }>, align 8
@.d409 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" - convert its end, '" }>, align 8
@.d410 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"(...)', for " }>, align 8
@.d411 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" values" }>, align 8
@.d412 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d413 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d414 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' copies '" }>, align 8
@.d415 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"', reached read-only, so it is read-only - '" }>, align 8
@.d416 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d417 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c".Clone()' would be one of its own" }>, align 8
@.d418 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d419 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" may be null, so it meets no trait" }>, align 8
@.d420 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" must meet " }>, align 8
@.d421 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" here" }>, align 8
@.d422 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d423 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which never is" }>, align 8
@.d424 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d425 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d426 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"' lives where '" }>, align 8
@.d427 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' does, which closes first" }>, align 8
@.d428 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"keep a copy ('$" }>, align 8
@.d429 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"'), or keep what '" }>, align 8
@.d430 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"' was made from" }>, align 8
@.d431 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"O20" }>, align 8
@.d432 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d433 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" declares " }>, align 8
@.d434 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c" twice, public and private" }>, align 8
@.d435 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"keep one: " }>, align 8
@.d436 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", or " }>, align 8
@.d437 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" for its own module only" }>, align 8
@.d438 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6b" }>, align 8
@.d439 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d440 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" needs " }>, align 8
@.d441 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d442 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", which is private to its module" }>, align 8
@.d443 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"declare it " }>, align 8
@.d444 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" to use it here" }>, align 8
@.d445 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"M6b" }>, align 8
@.d446 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d447 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d448 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"' is a " }>, align 8
@.d449 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which may be null" }>, align 8
@.d450 = private constant <{ i64, [76 x i8] }> <{ i64 0, [76 x i8] c"read through it where a test says it is not ('if x is not null'), or write '" }>, align 8
@.d451 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!'" }>, align 8
@.d452 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"T2c" }>, align 8
@.d453 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d454 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"' writes through or keeps its parameter '" }>, align 8
@.d455 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"this " }>, align 8
@.d456 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" is a read-only copy" }>, align 8
@.d457 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"pass one of its own, made " }>, align 8
@.d458 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d459 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" cannot be a function value" }>, align 8
@.d460 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"it writes through or keeps its by-value parameter '" }>, align 8
@.d461 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"', and a caller of a function value may pass a read-only copy" }>, align 8
@.d462 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"work on one of its own, made " }>, align 8
@.d463 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d464 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d465 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' keeps what its parameter '" }>, align 8
@.d466 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"' reaches where it can be written" }>, align 8
@.d467 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"this " }>, align 8
@.d468 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" is read-only" }>, align 8
@.d469 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T25c" }>, align 8
@.d470 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"pass a writable one" }>, align 8
@.d471 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d472 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"' is read here before it is assigned on every path" }>, align 8
@.d473 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" has no zero value" }>, align 8
@.d474 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c"assign it on each path before this read, or give it a value" }>, align 8
@.d475 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"D13d" }>, align 8
@.d476 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"a " }>, align 8
@.d477 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" has no '" }>, align 8
@.d478 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d479 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"its members are " }>, align 8
@.d480 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G34" }>, align 8
@.d481 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"shifting " }>, align 8
@.d482 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" by '" }>, align 8
@.d483 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"', which is " }>, align 8
@.d484 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c", is outside its width of " }>, align 8
@.d485 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" bits" }>, align 8
@.d486 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"shift by 0 to " }>, align 8
@.d487 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c", or convert the value to a wider type first" }>, align 8
@.d488 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"E16h" }>, align 8
@.d489 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"the amount is known while compiling" }>, align 8
@.d490 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a spawn target has exactly the call's type " }>, align 8
@.d491 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", found " }>, align 8
@.d492 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"declare '" }>, align 8
@.d493 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"' to give " }>, align 8
@.d494 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", built where its result lands" }>, align 8
@.d495 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"P1g" }>, align 8
@.d496 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d497 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" runs on this machine, not on '-target " }>, align 8
@.d498 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d499 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"'-target " }>, align 8
@.d500 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"' is another architecture or system" }>, align 8
@.d501 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B12a" }>, align 8
@.d502 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"build, compile, test and run build for it" }>, align 8
@.d503 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"nothing here runs " }>, align 8
@.d504 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" programs" }>, align 8
@.d505 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d506 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"install Wine (wine64)" }>, align 8
@.d507 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"install qemu-user (qemu-" }>, align 8
@.d508 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d509 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c", or name an emulator with OLANG_EMULATOR" }>, align 8
@.d510 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"B12a" }>, align 8
@.d511 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d512 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" is listed by " }>, align 8
@.d513 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" but has no method " }>, align 8
@.d514 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" that fits" }>, align 8
@.d515 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"declare it, or leave " }>, align 8
@.d516 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" out" }>, align 8
@.d517 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T31a" }>, align 8
@.d518 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d519 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d520 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d521 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d522 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" says nothing of that" }>, align 8
@.d523 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d524 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"' after its signature in the trait" }>, align 8
@.d525 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T30c, T22b" }>, align 8
@.d526 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d527 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d528 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"no promise of " }>, align 8
@.d529 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d530 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" can say that" }>, align 8
@.d531 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T30c, T22b" }>, align 8
@.d532 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"call it directly, or through generic code" }>, align 8
@.d533 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"'s " }>, align 8
@.d534 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" may " }>, align 8
@.d535 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", and " }>, align 8
@.d536 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" promises '" }>, align 8
@.d537 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d538 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"every call through an 'any " }>, align 8
@.d539 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"&' relies on it" }>, align 8
@.d540 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"give " }>, align 8
@.d541 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c" a method that does not, or take '" }>, align 8
@.d542 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"' off the trait's method" }>, align 8
@.d543 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"T30c, T22b" }>, align 8
@.d544 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"type variable '" }>, align 8
@.d545 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"' of " }>, align 8
@.d546 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" defaults to " }>, align 8
@.d547 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"its constraint does not take " }>, align 8
@.d548 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", and nothing at the call gives " }>, align 8
@.d549 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" a type, so its default would" }>, align 8
@.d550 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"write the type: " }>, align 8
@.d551 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"<...>(...), or say where the value goes, as 't T = ...'" }>, align 8
@.d552 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"G4a" }>, align 8
@.d553 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"type variable " }>, align 8
@.d554 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" of " }>, align 8
@.d555 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c" appears in no parameter's type" }>, align 8
@.d556 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"write " }>, align 8
@.d557 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"<...>(...)" }>, align 8
@.d558 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"G4" }>, align 8
@.d559 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"so the call writes it" }>, align 8
@.d560 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"'s '" }>, align 8
@.d561 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"' is a member of a C union, not a field" }>, align 8
@.d562 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"read it with '" }>, align 8
@.d563 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"()', write it with 'set_" }>, align 8
@.d564 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(v)'" }>, align 8
@.d565 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"X18a" }>, align 8
@.d566 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"a union's members share its bytes, so none is a place of its own: each is copied out and in (T36)" }>, align 8
@.d567 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d568 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"' is handed on here, and " }>, align 8
@.d569 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is unique" }>, align 8
@.d570 = private constant <{ i64, [77 x i8] }> <{ i64 0, [77 x i8] c"a unique value given by value lands once more only at its last mention, and '" }>, align 8
@.d571 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"' is mentioned after" }>, align 8
@.d572 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d573 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d574 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"' is handed on here, and '" }>, align 8
@.d575 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"', which reaches it, is used after" }>, align 8
@.d576 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is unique" }>, align 8
@.d577 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"use '" }>, align 8
@.d578 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"' before handing '" }>, align 8
@.d579 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"' on, or no longer after" }>, align 8
@.d580 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d581 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c" is unique, and this value is held elsewhere" }>, align 8
@.d582 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" holds one of its own" }>, align 8
@.d583 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"write a reference ('" }>, align 8
@.d584 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"&'), or make a new " }>, align 8
@.d585 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" here" }>, align 8
@.d586 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d587 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Array<" }>, align 8
@.d588 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c">(n, fill) copies its fill, and " }>, align 8
@.d589 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is unique" }>, align 8
@.d590 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"make each element with a comprehension ('" }>, align 8
@.d591 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d592 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"(...) for i in range n]'), or hold references ('Array<" }>, align 8
@.d593 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&>')" }>, align 8
@.d594 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d595 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"the fill is copied into every element" }>, align 8
@.d596 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" is unique, so it is no part of " }>, align 8
@.d597 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c", which is immut" }>, align 8
@.d598 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"hold a reference, '" }>, align 8
@.d599 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"&'" }>, align 8
@.d600 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d601 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"an immut value is copied freely, a unique one never" }>, align 8
@.d602 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d603 = private constant <{ i64, [55 x i8] }> <{ i64 0, [55 x i8] c"' is handed on here while the same call also reaches it" }>, align 8
@.d604 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c" is unique, so one value would be in two places" }>, align 8
@.d605 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"give the call '" }>, align 8
@.d606 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"' once, or hand it on in a call of its own" }>, align 8
@.d607 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T13b" }>, align 8
@.d608 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" needs a copy, and " }>, align 8
@.d609 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" is unique" }>, align 8
@.d610 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d611 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c" with a reference ('" }>, align 8
@.d612 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"&') or with a type that copies" }>, align 8
@.d613 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"T13b, G18" }>, align 8
@.d614 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"its values are never copied" }>, align 8
@.d615 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"unknown type " }>, align 8
@.d616 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" - std/" }>, align 8
@.d617 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" declares it" }>, align 8
@.d618 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"write 'import \22std/" }>, align 8
@.d619 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"\22' and '" }>, align 8
@.d620 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d621 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d622 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"T2" }>, align 8
@.d623 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"a type of another module is reached through its import (M10)" }>, align 8
@.d624 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d625 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" = " }>, align 8
@.d626 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"', or '" }>, align 8
@.d627 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" := " }>, align 8
@.d628 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d629 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"D12" }>, align 8
@.d630 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"a declaration's value follows '='" }>, align 8
@.d631 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d632 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d633 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"the function type of " }>, align 8
@.d634 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" says nothing of that" }>, align 8
@.d635 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"write '" }>, align 8
@.d636 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"' after its signature" }>, align 8
@.d637 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"T22b" }>, align 8
@.d638 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"this view of '" }>, align 8
@.d639 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"' is given to " }>, align 8
@.d640 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", which may grow '" }>, align 8
@.d641 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d642 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"M19g" }>, align 8
@.d643 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"the view would then be stale" }>, align 8
@.d644 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"case " }>, align 8
@.d645 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" carries one whole " }>, align 8
@.d646 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" and has no field names" }>, align 8
@.d647 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"match its fields with a struct pattern, '" }>, align 8
@.d648 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d649 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"(field = ...))'" }>, align 8
@.d650 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"S13b" }>, align 8
@.d651 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d652 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"'=' writes what '" }>, align 8
@.d653 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"' names, and it is a " }>, align 8
@.d654 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c", which may be null" }>, align 8
@.d655 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"test it first ('if x is not null'), write '" }>, align 8
@.d656 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"!', or link it with '~'" }>, align 8
@.d657 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"S4f" }>, align 8
@.d658 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fmsgs_3aNearest_2e1 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare %"compiler/diagmsg:Msg" @compiler_2fdiagmsg_3aMsg_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_78fb4d3249708b2_e3f9318f90ab6b26 = external constant [0 x i8]
@olang_loc_d93addea5b815da9_e849c161ff4e7de5 = external constant [0 x i8]
@olang_loc_fced1ba34c6512dc_349b310d7afbfd78 = external constant [0 x i8]
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1)
@olang_loc_d2d351cc5daaf8b6_b531c4af6261323a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_558e38b2b979820_b81e4d452591bbd4 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
@olang_loc_af0cd4b2e246af5e_f7dc695b2384058a = external constant [0 x i8]
@olang_loc_afe78659650a85b_d80bf1f42ea79867 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
@olang_loc_94d222cfeceaa960_f4d92a1033be80bc = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
